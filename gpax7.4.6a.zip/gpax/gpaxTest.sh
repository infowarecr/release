pm2 delete all
cd ~/gpax/api
pm2 start gpax_test.js --node-args="--inspect=9221"  --watch --ignore-watch="node_modules,.git" -- $1
pm2 flush
pm2 logs
