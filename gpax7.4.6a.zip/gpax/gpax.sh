pm2 delete all
cd ~/gpax/api
pm2 start gpax.js --node-args="--inspect=922$1"  --watch --ignore-watch="node_modules" -- 300$1
pm2 flush
pm2 logs
