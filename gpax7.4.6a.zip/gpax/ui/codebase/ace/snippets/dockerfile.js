define("ace/snippets/dockerfile",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="dockerfile"});                (function() {
                    window.require(["ace/snippets/dockerfile"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            