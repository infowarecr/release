var X = require('./x').start
var x = new X(this, 'mongodb://127.0.0.1:27017/gpa7', 'mongodb://127.0.0.1:27017/gpa7')
var req = {
  body: {
    bpd: '5cfaa03949d944368daafb71',
    key: 'StartEvent_1',
    project: '5b16ab6a8ef7e65cdf5e8b88',
    task: '1527849362566',
    user: {
      id: '5b103876e9ef3911b2086229',
      unit: '5b105f07bbbb9d106652930a'
    }
  }
}
x.invoke(req, null, result)

function result (res) {
  var req = {
    body: {
      bpi: res.bpi,
      key: res.key,
      cantidad: 5
    }
  }
  x.start(() => {
    x.invoke(req, null, result2)
  })
}

function result2 (res) {
  console.log(res)
}
