exports.Signal = Signal

function Signal () {
  this.get = async function (req, mongo, send) {
    var doc = await new Promise(resolve => {
      mongo.findId('signal', req.query._id, (err, signal) => {
        if (!err) {
          resolve(signal)
        }
      })
    })

    send(doc)
  }

  this.save = function (req, mongo, send) {
    var data = { id: mongo.newId() }
    for (let x in req.body) {
      data[x] = req.body[x]
    }
    if (mongo.isNativeId(data.id)) {
      data._id = data.id
      delete data.id
      mongo.save('signal', data, (err, result) => {
        if (err) {
          req.statusCode = 404
          send()
        } else {
          data.id = data._id
          send(data)
        }
      })
    } else {
      data._id = mongo.newId()
      delete data.id
      mongo.save('signal', data, (err, result) => {
        if (err) {
          req.statusCode = 404
          send()
        } else {
          data.id = data._id
          send(data)
        }
      })
    }
  }

  this.list = async function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    /* filering documents with user of session or unit of user of session and not hidden */
    var keys = {}
    /* apply filter in parameters */
    if (req.query.filter) {
      let query = {}
      for (let name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          if (name === 'name') {
            query['$text'] = {
              $search: req.query.filter[name]
            }
          }
        }
      }
      keys = query
    }
    var tags = await new Promise(resolve => {
      mongo.findOne('params', { name: 'signalTypes' }, (err, doc) => {
        if (err) resolve([])
        else if (doc) resolve(doc.options)
        else resolve([])
      })
    })
    /* read limit rows from skip position */
    mongo.findN('signal', skip, limit, keys, {}, { _id: 1 }, (err, docs) => {
      if (err || !docs) {
        send({ error: err })
      } else {
        docs.forEach((doc) => {
          var i = tags.findIndex((tag)=>{return tag.id.equals(doc.tag)})
          if (i !== -1) {
            doc.tagname = tags[i].value
            doc.tagcolor = tags[i].color
          }
          doc.id = doc._id.toString()
          delete doc._id
          reply.data.push(doc)
        })

        /* if continue is true, send data */
        if (req.query.continue) {
          send(reply)
        } else {
          /* add total_count to reply */
          mongo.count('signal', keys, (err, count) => {
            if (!err && count) {
              reply.total_count = count
            }
            send(reply)
          })
        }
      }
    })
  }

  this.delete = function (req, mongo, send) {
    mongo.deleteOne('signal', { _id: mongo.toId(req.body._id) }, (err, result) => {
      if (err || result.modifiedCount === 0) {
        req.statusCode = 404
        send()
      } else {
        send(data)
      }
    })
  }
}