var vm = require('vm')
var soap = require('soap')
exports.Server = Server

function Server () {
  this.getService = async function (req, mongo, send) {
    var doc = await new Promise(resolve => {
      mongo.find('server', { 'services.id': mongo.toId(req.query._id) }, { _id: 0, 'services.$': 1 }, (err, service) => {
        if (!err) {
          resolve(service[0].services[0])
        }
      })
    })

    send(doc)
  }

  this.save = function (req, mongo, send) {
    var data = req.body
    data._id = data.id
    delete data.id
    try {
      const runnable = new vm.Script(data.config)
      var context={config: {}}
      var ws = vm.createContext(context)
      runnable.runInContext(ws)
      data.services = context.config.services
      delete context.config.services
      data.properties=context.config
      mongo.save('server', data, (err) => {
        if (err) {
          req.statusCode = 404
          send()
        } else {
          data.id = data._id
          send(data)
        }
      })
    } catch (err) {
      send({error: err})
    }
  }

  this.list = function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    /* filering documents with user of session or unit of user of session and not hidden */
    var keys = {}
    /* apply filter in parameters */
    if (req.query.filter) {
      const query = {}
      for (const name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          if (name === 'name') {
            query.$text = {
              $search: req.query.filter[name]
            }
          }
        }
      }
      keys = query
    }
    /* read limit rows from skip position */
    mongo.findN('server', skip, limit, keys, {}, { _id: 1 }, (err, docs) => {
      if (err || !docs) {
        send({ error: err })
      } else {
        /* hash user actors of the documents set */
        docs.forEach((doc) => {
          doc.id = doc._id.toString()
          delete doc._id
          reply.data.push(doc)
        })

        /* if continue is true, send data */
        if (req.query.continue) {
          send(reply)
        } else {
          /* add total_count to reply */
          mongo.count('server', keys, (err, count) => {
            if (!err && count) {
              reply.total_count = count
            }
            send(reply)
          })
        }
      }
    })
  }

  this.delete = function (req, mongo, send) {
    mongo.deleteOne('server', { _id: mongo.toId(req.body._id) }, (err, result) => {
      if (err || result.modifiedCount === 0) {
        req.statusCode = 404
        send()
      } else {
        send()
      }
    })
  }

  /// /////////////////////////////////////////////////////////////////////////////////////////////
  /// //////revisar ya que los webservices no siempre traen la misma estructura en la descripcion/////
  /// ////////////////////////////////////////////////////////////////////////////////////////////////
  this.getServices = async function (req, mongo, send) {
    mongo.findId('server', req.query.server, (err, server) => {
      if (err) send({ error: err })
      else {
        try {
          soap.createClient(server.properties.host + '?wsdl', (err, client) => {
            var methods
            var availables = {}
            if (err) {
              send({ error: err.message })
            } else {
              var services = client.describe()
              if (services) {
                var name = Object.getOwnPropertyNames(services)[0]
                methods = services[name]
                if (methods[name + 'Soap']) {
                  methods = methods[name + 'Soap']
                } else if (methods[name + 'Soap12']) {
                  methods = methods[name + 'Soap12']
                }
              }
              for (const i in methods) {
                for (const y in methods[i]) {
                  if (methods[i][y].input) {
                    availables[y] = methods[i][y]
                  } else if (y === 'input') {
                    availables[i] = methods[i]
                  }
                }
              }
              server.services=availables
              server.config = server.properties
              server.config.services = availables
              mongo.save('server', server, (err) => {
                if (err) send({ error: err })
                else {
                  send(server)
                }
              })
            }
          })
        } catch (err) {
          send({error: err})
        }
      }
    })
  }
}
