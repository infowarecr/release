

exports.Debugger = Debugger

function Debugger () {
  this.save = function (req, mongo, send) {
    var data = { id: mongo.newId() }
    for (const x in req.body) {
      data[x] = req.body[x]
    }
    if (mongo.isNativeId(data.id)) {
      data._id = data.id
      delete data.id
      mongo.save('bpd', data, (err) => {
        if (err) {
          req.statusCode = 404
          send()
        } else {
          data.id = data._id
          send(data)
        }
      })
    } else {
      data._id = mongo.newId()
      delete data.id
      mongo.save('bpd', data, (err) => {
        if (err) {
          req.statusCode = 404
          send()
        } else {
          data.id = data._id
          send(data)
        }
      })
    }
  }

  this.list = function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    /* filering documents with user of session or unit of user of session and not hidden */
    var keys = {}
    /* apply filter in parameters */
    if (req.query.filter) {
      for (const name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          keys[name]=req.query.filter[name]
        }
      }
    }
    /* read limit rows from skip position */
    var pipeline = [
      { $match: keys }, {$sort: {'dates.start': -1}},
      {$lookup: {from: 'message',localField: 'bp.json.definitions.process.startEvent._message',foreignField: '_id',as: 'start'}},
      {$lookup: {from: 'message',localField: 'bp.json.definitions.process.endEvent._message',foreignField: '_id',as: 'end'}},
      {$lookup: {from: 'params',localField: 'tag',foreignField: 'options.id',as: 'tags'}},
      {$unwind: {path: '$start',preserveNullAndEmptyArrays: true}},
      {$unwind: {path: '$end',preserveNullAndEmptyArrays: true}},
      {$unwind: {path: '$tags',preserveNullAndEmptyArrays: true}},
      {
        $project: {
          id: '$_id', name: 1, bp: 1, status: 1, bpd: 1, tag: 1, config: 1,
          start: { $dateToString: { date: '$dates.start', format: '%Y-%m-%d %H:%M', timezone: 'America/Costa_Rica' } },
          end: { $dateToString: { date: '$dates.end', format: '%Y-%m-%d %H:%M', timezone: 'America/Costa_Rica' } },
          tagname: {$arrayElemAt: ['$tags.options.value',{$indexOfArray: [ '$tags.options.id' , '$tag']}]},
          tagcolor: {$arrayElemAt: ['$tags.options.color',{$indexOfArray: [ '$tags.options.id' , '$tag']}]}}},
      {$skip: skip }, {$limit: limit }
    ]
    mongo.aggregate('bpi', pipeline, {}, (err, docs) => {
      if (err || !docs) {
        send({ error: err })
      } else {
        reply.data=docs
        if (req.query.continue) {
          send(reply)
        } else {
          mongo.count('bpi', keys, (err, count) => {
            if (!err && count) {
              reply.total_count = count
            }
            send(reply)
          })
        }
      }
    })
  }

  this.delete = function (req, mongo, send) {
    mongo.deleteOne('bpd', { _id: mongo.toId(req.body._id) }, (err, result) => {
      if (err || result.modifiedCount === 0) {
        req.statusCode = 404
        send()
      } else {
        send()
      }
    })
  }

}
