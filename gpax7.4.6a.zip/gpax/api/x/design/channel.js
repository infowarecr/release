
exports.Channel = Channel

function Channel () {
  this.save = function (req, mongo, send) {
    var data = { id: mongo.newId() }
    for (const x in req.body) {
      data[x] = req.body[x]
    }
    if (mongo.isNativeId(data.id)) {
      data._id = data.id
      delete data.id
      mongo.save('channel', data, (err) => {
        if (err) {
          req.statusCode = 404
          send()
        } else {
          data.id = data._id
          send(data)
        }
      })
    } else {
      data._id = mongo.newId()
      delete data.id
      mongo.save('channel', data, (err) => {
        if (err) {
          req.statusCode = 404
          send()
        } else {
          data.id = data._id
          send(data)
        }
      })
    }
  }

  this.list = function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    /* filering documents with user of session or unit of user of session and not hidden */
    var keys = {}
    /* apply filter in parameters */
    if (req.query.filter) {
      const query = {}
      for (const name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          if (name === 'name') {
            query.$text = {
              $search: req.query.filter[name]
            }
          }
        }
      }
      keys = query
    }
    /* read limit rows from skip position */
    mongo.findN('channel', skip, limit, keys, {}, { _id: 1 }, (err, docs) => {
      if (err || !docs) {
        send({ error: err })
      } else {
        /* hash user actors of the documents set */
        docs.forEach((doc) => {
          doc.id = doc._id.toString()
          doc.config = doc.config ? doc.config : ''
          delete doc._id
          reply.data.push(doc)
        })

        /* if continue is true, send data */
        if (req.query.continue) {
          send(reply)
        } else {
          /* add total_count to reply */
          mongo.count('channel', keys, (err, count) => {
            if (!err && count) {
              reply.total_count = count
            }
            send(reply)
          })
        }
      }
    })
  }

  this.delete = function (req, mongo, send) {
    mongo.deleteOne('channel', { _id: mongo.toId(req.body._id) }, (err, result) => {
      if (err || result.modifiedCount === 0) {
        req.statusCode = 404
        send()
      } else {
        send()
      }
    })
  }
}
