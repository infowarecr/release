
class form {
  constructor (bpi, id) {
    this.bpi = bpi
    this.x = bpi.x
    this.id = id
  }

  load (next) {
    this.x.design.findId('form', this.id, (err, form) => {
      if (form) {
        this.form = form
      } else if (err) {
        err = { error: err }
      } else {
        err = { error: 'Form not found.' }
      }
      next(err)
    })
  }

  set (data) {
    this.data = data
  }

  save (next) {
    this.x.production.save(this.form.collection, this.data, (err, result) => {
      if (err) {
        err = { error: err }
      }
      next(err)
    })
  }

  compose () {
    var items = this.form.template.items
    if (this.data) {
      for (const i in this.data) {
        this.setValue(items, i, this.data[i])
      }
    }
    return items
  }

  // Private functions
  setValue (items, name, value) {
    for (const i in items) {
      const item = items[i]
      if (item.name === name) {
        switch (item.type) {
        case 'checkbox':
          item.checked = this.x.tags.util.bool(value)
          break
        case 'combo':
        case 'multiselect':
          for (const x in item.options) {
            const option = item.options[x]
            if (option.value === value || (value.length && value.indexOf(option.value) !== -1)) {
              option.checked = true
              option.selected = true
            }
          }
          break
        case 'image':
          item.url = value
          break
        case 'label':
          item.label = value
          break
        case 'radio':
        case 'select':
          for (const x in item.options) {
            const option = item.options[x]
            if (option.value === value) {
              option.selected = true
              break
            }
          }
          break
        case 'settings':
          for (const x in value) {
            item[x] = value[x]
          }
          break
        default:
          item.value = value
          break
        }
      }
      if (item.list) {
        this.setValue(item.list, name, value)
      }
    }
  }
}
exports.form = form
