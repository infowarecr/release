exports.codes = {
  LF: '\n',
  CR: '\r',
  TAB: String.fromCharCode(9),
  SEP1: String.fromCharCode(28),
  SEP2: String.fromCharCode(29),
  SEPARA: '~',
  SE: String.fromCharCode(240),
  NOP: String.fromCharCode(241),
  DM: String.fromCharCode(242),
  BREAK: String.fromCharCode(243),
  IP: String.fromCharCode(244),
  AO: String.fromCharCode(245),
  AYT: String.fromCharCode(246),
  EC: String.fromCharCode(247),
  EL: String.fromCharCode(248),
  GA: String.fromCharCode(249),
  SB: String.fromCharCode(250),
  WILL: String.fromCharCode(251),
  WONT: String.fromCharCode(252),
  DO: String.fromCharCode(253),
  DONT: String.fromCharCode(254),
  IAC: String.fromCharCode(255),
  TTER: String.fromCharCode(24),
  SEND: String.fromCharCode(1),
  IS: String.fromCharCode(0),
  SLOC: String.fromCharCode(23),
  INI: String.fromCharCode(20),
  ECHO: String.fromCharCode(1),
  BIN: String.fromCharCode(0),
  EOR: String.fromCharCode(25), // Si acepta enviar fin de registro vendrán 2 codes al final: 255 y 239.
  FIN: String.fromCharCode(239),
  SUPGA: String.fromCharCode(3),
  ASCII: String.fromCharCode(17),
  NENV: String.fromCharCode(39),
  VAR: String.fromCharCode(0),
  VALUE: String.fromCharCode(1),
  USVAR: String.fromCharCode(3),
  PAGUP: String.fromCharCode(25),
  PAGDWN: String.fromCharCode(22),
  toAscii: function (data) {
    var r = '';
    for (let i = 0; data && i < data.length; ++i) {
      r += String.fromCharCode(data[i]);
    }
    return r;
  },
  toHuman: function (data) {
    var r = '';
    for (let i = 0; data && i < data.length; ++i) {
      let value = String.fromCharCode(data[i]);
      switch (value) {
      case 9:
        r += '[TAB]';
        break;
      case 28: r += '[SEP1]';
        break;
      case 29: r += '[SEP2]';
        break;
      case '~': r += '[SEPARA]';
        break;
      case this.SE: r += '[SE]';
        break;
      case this.NOP: r += '[NOP]';
        break;
      case this.DM: r += '[DM]';
        break;
      case this.BREAK: r += '[BREAK]';
        break;
      case this.IP: r += '[IP]';
        break;
      case this.AO: r += '[AO]';
        break;
      case this.AYT: r += '[AYT]';
        break;
      case this.EC: r += '[EC]';
        break;
      case this.EL: r += '[EL]';
        break;
      case this.GA: r += '[GA]';
        break;
      case this.SB: r += '[SB]';
        break;
      case this.WILL: r += '[WILL]';
        break;
      case this.WONT: r += '[WONT]';
        break;
      case this.DO: r += '[DO]';
        break;
      case this.DONT: r += '[DONT]';
        break;
      case this.IAC: r += '[IAC]';
        break;
      case this.TTER: r += '[TTER]';
        break;
      case this.SEND: r += '[SEND]';
        break;
      case this.IS: r += '[IS]';
        break;
      case this.SLOC: r += '[SLOC]';
        break;
      case this.INI: r += '[INI]';
        break;
      case this.ECHO: r += '[ECHO]';
        break;
      case this.BIN: r += '[BIN]';
        break;
      case this.EOR: r += '[EOR]';
        break;
      case this.FIN: r += '[FIN]';
        break;
      case this.SUPGA: r += '[SUPGA]';
        break;
      case this.ASCII: r += '[ASCII]';
        break;
      case this.NENV: r += '[NENV]';
        break;
      case this.VAR: r += '[VAR]';
        break;
      case this.VALUE: r += '[VALUE]';
        break;
      case this.USVAR: r += '[USVAR]';
        break;
      case this.PAGUP: r += '[PAGUP]';
        break;
      case this.PAGDWN: r += '[PAGDWN]';
        break;
      default:
        r += value;
        break;
      }
    }
    return r;
  }
};