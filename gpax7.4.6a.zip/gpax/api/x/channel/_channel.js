var net = require('net')
const codes = require('../codes').codes

class Channel {
  constructor (config, startup) {
    this.config = config
    this.startup = startup
  }

  init () {
    this.server = net.createServer((client) => {
      console.log('client connected')
      this.client = client
      this.client.on('end', () => {
        console.log('client disconnected')
        this.client.destroy()
        delete this.client
      })
      this.client.on('data', (data) => {
        this.request = codes.toAscii(data)
        this.request = JSON.parse(this.request)
        if (this.request.ispec) {
          const cfg = this.config.services[this.request.ispec.toLowerCase()]
          if (cfg) {
            // Initialize workspace before proccess each message
            this.workspace = {}
            this.workspace.start = this.request
            this.workspace.initTime = new Date()
            this.msg = this.format(this.request.service, this.request.input, cfg)
            this.send2lincii(this.msg)
          } else {
            this.client.write({ error: 'Service \'' + this.request.ispec + '\' not found' })
          }
        } else {
          this.client.write({ error: 'Field \'ispec\' required' })
        }
      })
    })
    this.server.on('error', (err) => {
      console.log(err)
    })
    this.server.on('listening', () => {
      console.log('Listen ' + this.config.channel + '...')
    })
    this.server.listen(this.config.channel, '127.0.0.1')
  }
}

exports.Channel = Channel
