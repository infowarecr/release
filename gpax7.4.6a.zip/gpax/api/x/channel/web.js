var tags = require('../utils/tags').tags
var express = require('express')
var fs = require('fs')
var assert = require('assert')
var path = require('path')
var methodOverride = require('method-override')
var session = require('express-session')
var MongoDBStore = require('connect-mongodb-session')(session)
var bodyParser = require('body-parser')
var upload = require('express-fileupload')()
var helmet = require('helmet')
var Broadcast = require('./broadcast').Broadcast
var BPI = require('../bpi').BPI
var dirname = __dirname.substring(0, __dirname.lastIndexOf('/'))
dirname = dirname.substring(0, dirname.lastIndexOf('/'))

exports.Channel = Web

function Web (x, config) {
  this.x = x
  this.config = config

  this.start = function (next) {
    next()
  }

  this.call = function (req, res, next) {
    // Merge both (query & body), priority for body if have duplicates properties
    var event = req.path.substring(1)

    // If bp is authorized play it
    if (this.config.bpds.includes(data.bpd)) {
      new BPI(this).play({ key: event, data: data }, (reply) => {
        this.respond(req, res, reply)
      })
    } else {
      next()
    }
  }

  this.respond = function (req, res, reply) {
    // Write reply into log and send it to browser
    let log
    if (req.session && req.session._id) {
      log.user = req.session._id
    }
    // Stream have be piped to reponse stream
    if (reply && reply.pipe) {
      res.set('Content-Type', reply.contentType)
      if (reply.contentLength) {
        res.set('Content-Length', reply.contentLength)
      }
      res.once('finish', () => {
        log.output = { state: true, filename: req.query.filename, action: 'downloaded' }
        req.logger.save(log,req.mongo)
        res.end()
      })
      res.on('error', (err) => {
        log.output = err
        req.logger.save(log,req.mongo)
      })
      reply.pipe(res)
    } else {
      if (reply) {
        if (reply.error && reply.error.message) {
          reply.error = reply.error.message
        }
        log.output = reply
        res.send(reply)
      } else {
        log.output = { type: 'error', message: tags.msgNotReply }
        res.send({ error: tags.msgNotReply })
      }
      res.end()
      req.logger.save(log,req.mongo)
    }
  }

  this.stop = function (next) {
    this.server.close(next)
  }
}
