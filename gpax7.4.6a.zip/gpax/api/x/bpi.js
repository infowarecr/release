var vm = require('vm')
var BRT = require('./brt').BRT
var moment = require('moment')
var moment = require('moment')
var tags = require('../utils/tags').tags
var x2js = new (require('x2js'))()
var xml_js = require('xml-js');



class BPI {
  constructor (x, req, channel) {
    this.x = x
    this.req = req
    this.$session = req ? (req.session || {}):{}
    this.channel = channel
  }

  /*
   * event:{ bpd:<bpd id>, bpi:<bpi id>, _id:<doc id>, ...<other input fields>}
   */
  play (event, next) {
    this.load(event, (bpi) => {
      if (bpi) {
        this.bpi = bpi
        this.replies = []
        var sendReply = (reply) => {
          if (this.bpi.totalThreads === this.bpi.activeThreads.length + this.bpi.inactiveThreads.length) {
            this.save(event, this.replies.length > 0 ? this.replies : reply, () => {
              next(this.replies.length > 0 ? this.replies : reply)
            })
          } else {
            this.replies.push(reply)
          }
        }
        if (event.key) {
          this.bpi.trace.events.push({
            key: event.key,
            data: event,
            timeStamp: moment().format('MM DD YYYY, H:mm:ss a')
          })
          // This context variable catch condition results
          this.bpi.ws.__rslt = false
          this.step(event.key, event.data, sendReply)
        } else if (this.bpi.inactiveThreads.length > 0) {
          for (const i in this.bpi.inactiveThreads) {
            event.key = this.bpi.inactiveThreads[i]
            this.bpi.trace.events.push({
              key: event.key,
              data: event,
              timeStamp: moment().format('MM DD YYYY, H:mm:ss a')
            })
            this.step(event.key, event.data, sendReply, true)
          }
        } else if (this.bpi.key) {
          event.key = this.bpi.key
          this.bpi.trace.events.push({
            key: event.key,
            data: event,
            timeStamp: moment().format('MM DD YYYY, H:mm:ss a')
          })
          this.step(event.key, event.data, sendReply)
        }
      } else {
        next({ error: 'Unable to load the business process instance' })
        this.bpi = {}
      }
    })
  }

  step (key, data, next, isThread, fromGateway) {
    this.current = key
    var node = this.bpi.nodes[this.current]
    var todo
    if (node.__typeNode.includes('Gateway')) {
      todo = 'gateway'
    } else if (node.__typeNode.includes('Event')) {
      todo = 'event'
    } else {
      switch (node.__typeNode) {
      case 'subprocess':
        todo = 'subprocess'
        break
      case 'userTask':
        todo = 'userTask'
        break
      case 'scriptTask':
        todo = 'scriptTask'
        break
      case 'serviceTask':
        todo = 'serviceTask'
        break
      case 'businessRuleTask':
        todo = 'businessRuleTask'
        break
      case 'task':
        todo = 'task'
      }
    }
    if (todo) {
      this[todo](node, data, next, isThread, fromGateway)
    } else {
      next({ error: 'Unable to play node, type ' + node.__typeNode + ', name ' + node._name })
    }
  }
  getInput (key) {
    var data = this.bpi.ws[this.toVar(key)]
    if (!data) {
      data = this.bpi.ws[this.toVar(this.bpi.nodes[key]._name)]
    }
    return data && data.input ? data.input : data
  }
  setOutput (key, value, index, fromGateway) {
    var data = this.bpi.ws[this.toVar(key)]
    if (!data) {
      data = this.bpi.nodes[key] ? this.bpi.ws[this.toVar(this.bpi.nodes[key]._name)] : {}
    }
    if (data.output) {
      if (index === 0 || index) {
        if (!Array.isArray(data.output)) {
          data.output = []
        }
        data.output[index] = value
      } else {
        if (Array.isArray(data.output) && fromGateway) {
          data.output = data.output.concat(value)
        } else {
          data.output = value
        }
      }
    } else {
      var output = this.bpi.ws[this.toVar(key)]
      if (index === 0 || index) {
        if (!Array.isArray(output)) {
          output = []
        }
        output[index] = value
      } else {
        output = value
      }
    }
  }
  gateway (node, event, next, index /* optional */) {
    this.pushStep({
      key: node._id,
      timeStamp: moment().format('MM DD YYYY, H:mm:ss a')
    })
    var usedlink = (link) => {
      if (link._code && (link._code !== '' && link._code !== '//code...')) {
        try {
          this.eval('__rslt=' + link._code)
        } catch (error) {
          this.bpi.ws.__rslt = false
        }
        link.__used = this.bpi.ws.__rslt
      } else {
        link.__used = true
      }
      if (!link.__used) {
        this.bpi.threads = this.bpi.threads - 1
      } else {
        this.gatewayGo = true
        this.pushLink(link)
        this.links.push(link)
      }
    }
    var runlinks = (links) => {
      if (links.length > 1) {
        for (const i in links) {
          this.step(links[i]._targetRef, this.getInput(links[i]._targetRef), next, false, true)
        }
      } else {
        this.step(links[0]._targetRef, this.getInput(links[0]._targetRef), next, false, true)
      }
    }
    this.links = []
    this.bpi.key = node._id
    if (this.bpi.threads !== 0) {
      this.bpi.threads = this.bpi.threads - 1
      if ((this.bpi.totalThreads === this.bpi.activeThreads.length + this.bpi.inactiveThreads.length) && this.bpi.inactiveThreads.length > 0) {
        next()
      }
    }
    if (this.bpi.threads === 0) {
      this.gatewayGo = false
      this.bpi.activeThreads = []
      this.bpi.inactiveThreads = []
      if (node.outgoing) {
        let link
        if (node.outgoing.constructor === Array) {
          this.bpi.threads = node.outgoing.length
          for (const i in node.outgoing) {
            link = this.bpi.links[node.outgoing[i].__text]
            usedlink(link)
          }
          if (node.__typeNode.includes('exclusive') && this.links.length === 2 && node._default) {
            this.links = this.links.filter(function (x) {
              return x._id !== node._default
            })
            this.bpi.trace.links = this.bpi.trace.links.filter(function (x) {
              return x._id !== node._default
            })
            this.bpi.threads = 0
          }
        } else if (node.outgoing.constructor === Object) {
          this.bpi.threads = 1
          link = this.bpi.links[node.outgoing.__text]
          usedlink(link)
        }

        if (this.gatewayGo) {
          this.bpi.totalThreads = this.bpi.threads < 2 ? 0 : this.bpi.threads
          runlinks(this.links)
        }
      }
    }

    if (!this.gatewayGo) {
      next({ error: 'No condition was met at this gateway, type ' + node.__typeNode + ', name ' + node._name })
    }
  }

  event (node, data, next, isThread, fromGateway) {
    const step = {
      key: node._id,
      timeStamp: moment().format('MM DD YYYY, H:mm:ss a')
    }
    this.bpi.key = node._id
    if (node.__event) {
      if (data) {
        this.bpi.ws[this.toVar(node._name)] = data
        step.input = data
      }
      if (isThread) {
        this.bpi.activeThreads.push(node._id)
        this.bpi.inactiveThreads = this.bpi.inactiveThreads.filter(function (value) {
          return value === node._id
        })
      }
      this.pushStep(step)
      this.nextStep(node, next, fromGateway)
    } else {
      this.bpi.status = 'done'
      if (node._name && this.bpi.ws[this.toVar(node._name)]) {
        step.output = this.bpi.ws[this.toVar(node._name)]
        this.pushStep(step)
        next(this.bpi.ws[this.toVar(node._name)])
      } else {
        this.pushStep(step)
        next({ message: 'bpmn finished' })
      }
    }
  }

  // Call subprocess
  subprocess (node, event, next) {

  }

  // Call business rule task
  businessRuleTask (node, event, next) {
    var brt = new BRT(this, node.brt)
    brt.run(node.input, function (err, output) {
      if (err) {
        node.error = err
      } else {
        for (const field in output) {
          if (node.output[field]) {
            node.output[field] = output[field]
          }
        }
      }
      next()
    })
  }

  // Send to or receive from user form
  async userTask (node, data, next, isThread, fromGateway) {
    this.bpi.key = node._id
    if (data && (data.action === 'invoke')) {
      this.x.saveGUI(data, () => {
        this.pushStep({
          key: node._id,
          timeStamp: moment().format('MM DD YYYY, H:mm:ss a'),
          input: data
        })
        this.bpi.ws[this.toVar(node._name)] = data
        if (isThread) {
          this.bpi.activeThreads.push(node._id)
          this.bpi.inactiveThreads = this.bpi.inactiveThreads.filter(function (value) {
            return value === node._id
          })
        }
        this.nextStep(node, next, fromGateway)
      })
    } else if (data && (data.action === 'save')) {
      this.x.saveGUI(data, () => {
        if (isThread && !this.bpi.inactiveThreads.includes(node._id)) {
          this.bpi.inactiveThreads.push(node._id)
        }
        next()
      })
    } else {
      var gui = await new Promise(resolve => {
        this.x.getGUI({ 'event.bpi': this.bpi._id, 'event.key': node._id }, null, (gui) => {
          if (gui && !gui.error) {
            resolve(gui)
          } else {
            resolve(false)
          }
        })
      })
      // revisar if si falla algo
      if (gui) {
        if (data) gui.data = data
        next({ gui: gui })
      } else {
        gui = await new Promise(resolve => {
          this.x.design.findId('gui', node._form, (err, gui) => {
            if (!err) {
              resolve(gui)
            } else {
              resolve(false)
            }
          })
        })

        var doc = {
          _id: this.x.design.newId(),
          event: {
            bpi: this.bpi._id,
            key: node._id,
            status: 'draft'
          },
          code: gui.code,
          data: data ? data : gui.data
        }

        this.x.saveGUI(doc, () => {
          if (isThread && !this.bpi.inactiveThreads.includes(node._id)) {
            this.bpi.inactiveThreads.push(node._id)
          }
          next({ gui: doc })
        })
      }
    }
  }


  // Run script in bpi.context
  scriptTask (node, event, next, isThread, fromGateway) {
    this.bpi.key = node._id
    try {
      this.eval(node._code)
      if (isThread) {
        this.bpi.activeThreads.push(node._id)
        this.bpi.inactiveThreads = this.bpi.inactiveThreads.filter(function (value) {
          return value === node._id
        })
      }
      const step = {
        key: node._id,
        timeStamp: moment().format('MM DD YYYY, H:mm:ss a')
      }
      if (node._code !== '//code...') {
        step.code = node._code
      }
      this.pushStep(step)
      this.nextStep(node, next, fromGateway)
    } catch (error) {
      if (isThread && !this.bpi.inactiveThreads.includes(node._id)) {
        this.bpi.inactiveThreads.push(node._id)
      }
      this.pushStep({
        key: node._id,
        timeStamp: moment().format('MM DD YYYY, H:mm:ss a'),
        error: error.message
      })
      next({ error: error.message })
    }
  }

  // Run task
  task (node, event, next, isThread, fromGateway) {
    this.bpi.key = node._id
    if (isThread) {
      this.bpi.activeThreads.push(node._id)
      this.bpi.inactiveThreads = this.bpi.inactiveThreads.filter(function (value) {
        return value === node._id
      })
    }
    const step = {
      key: node._id,
      timeStamp: moment().format('MM DD YYYY, H:mm:ss a')
    }
    this.pushStep(step)
    this.nextStep(node, next, fromGateway)
  }

  // Get or Set device interface/sensor
  serviceTask (node, data, next, isThread, fromGateway) {
    this.bpi.key = node._id
    var result = (res) => {
      if (res.error) {
        if (isThread && !this.bpi.inactiveThreads.includes(node._id)) {
          this.bpi.inactiveThreads.push(node._id)
        }
        this.pushStep({
          key: node._id,
          timeStamp: moment().format('MM DD YYYY, H:mm:ss a'),
          error: res.error.toString()
        })
        next({ error: res.error.toString() })
      } else {
        if (node.standardLoopCharacteristics) {
          this.setOutput(node._name, res.output || res, this.bpi.ws.$index, fromGateway)
          this.pushStep({
            key: node._id,
            timeStamp: moment().format('MM DD YYYY, H:mm:ss a'),
            input: this.bpi.ws[this.toVar(node._name)].input || req.input,
            output: res.output || res
          })
          try {
            this.eval('__rslt=' + node._codeLoop)
          } catch (error) {
            this.bpi.ws.__rslt = false
          }
          if (this.bpi.ws.__rslt) {
            if (isThread) {
              this.bpi.activeThreads.push(node._id)
              this.bpi.inactiveThreads = this.bpi.inactiveThreads.filter(function (value) {
                return value === node._id
              })
            }
            this.bpi.ws.$index = 0
            this.nextStep(node, next, fromGateway)
          } else {
            this.bpi.ws.$index++
            this.assignment(this.lastAssignment)
            this.serviceTask(node, this.getInput(node._id), next, isThread)
          }
        } else {
          this.setOutput(node._name, res.output || res, false, fromGateway)
          if (isThread) {
            this.bpi.activeThreads.push(node._id)
            this.bpi.inactiveThreads = this.bpi.inactiveThreads.filter(function (value) {
              return value === node._id
            })
          }
          this.pushStep({
            key: node._id,
            timeStamp: moment().format('MM DD YYYY, H:mm:ss a'),
            input: this.bpi.ws[this.toVar(node._name)].input || req.input,
            output: res.output || res
          })
          this.nextStep(node, next, fromGateway)
        }
      }
    }
    var req = {
      to: node._server,
      service: node._service,
      input: data,
      bpi: this.bpi,
      callback: result
    }
    try {
      var srv = this.x.servers[node._server.toString()]
      srv.invoke(req)
    } catch (err) {
      if (isThread && !this.bpi.inactiveThreads.includes(node._id)) {
        this.bpi.inactiveThreads.push(node._id)
      }
      this.pushStep({
        key: node._id,
        timeStamp: moment().format('MM DD YYYY, H:mm:ss a'),
        error: err.message
      })
      next({ error: err.message })
    }
  }

  nextStep (node, next, fromGateway) {
    var link = this.nextLink(node)
    this.pushLink(link)
    this.step(link._targetRef, this.getInput(link._targetRef), next, false, fromGateway)
  }

  async save (event, reply, next) {
    // Once processed the event updates the business process instance (bpi)
    this.bpi.lastReply = reply
    this.bpi.dates.end = new Date()
    this.removeUtils(this.bpi.ws)
    this.x.production.save('bpi', this.bpi, (err) => {
      if (err) {
        err = { error: err }
      }
      next(err)
    })
  }

  load (event, next) {
    if (event.bpi) {
      this.x.production.findId('bpi', event.bpi, (err, bpi) => {
        if (!err && bpi) {
          this.addUtils(bpi.ws)
          next(bpi)
        } else {
          next()
        }
      })
    } else {
      this.x.design.findId('bpd', event.bpd, (err, bpd) => {
        if (!err && bpd) {
          var bpi = this.convert(bpd)
          bpi.name = event.name ? event.name : bpd.name
          bpi.tags = event.tags ? event.tags : bpd.tags
          bpi.status = 'processing'
          if (event.reference) {
            bpi._id = event.reference
          }
          const start = bpi.bp ? bpi.bp.definitions.process.startEvent : null
          if (start) {
            if (start.constructor === Array) {
              bpi.key = start[0]._id
            } else if (start.constructor === Object) {
              bpi.key = start._id
            }
          }
          next(bpi)
        } else {
          next()
        }
      })
    }
  }

  assignment (obj, path) {
    if (obj.data) {
      for (const i in obj.data) {
        this.assignment(obj.data[i], path ? path + '.' + obj.value : obj.value)
      }
    } if (obj.assignment) {
      if (path) {
        var target = this.toVar(path) + '.' + obj.value
      } else {
        target = this.toVar(obj.value)
      }
      try {
        this.eval(target + '=' + obj.assignment) //+ '\nif(' + target + ' instanceof Object && !' + target + ' instanceof Date) ' + target + '=Object.assign({},' + target + ')')
      }
      catch (e) {
        try {
          this.eval(target + '=\'' + obj.assignment + '\'')
        }
        catch (e) {
          console.log('{' + target + '=' + obj.assignment + '} ' + e)
        }
      }
      if (!this.trace.assignments) this.trace.assignments = []
      var assignment = {}
      assignment[target] = this.bpi.ws.__rslt
      this.trace.assignments.push(assignment)
    }
  }

  pushStep (step) {
    this.bpi.trace.steps.push(step)
  }
  nextLink (node) {
    return this.bpi.links[node.outgoing.__text]
  }
  pushLink (link) {
    this.trace = { _id: link._id, timeStamp: moment().format('MM DD YYYY, H:mm:ss a') }
    this.bpi.trace.links.push(this.trace)
    if (link._assignment) {
      this.lastAssignment = JSON.parse(link._assignment)[0]
      this.assignment(this.lastAssignment)
    }
  }

  convert (bpd) {
    var bpi
    var putNode = (key, node) => {
      node.__typeNode = key
      if (key.charAt(0) !== '_') {
        if (key !== 'sequenceFlow') {
          if (key === 'startEvent' || key === 'endEvent') {
            node.__event = !!node.outgoing
            node.__start = !node.incoming
          } else if (key === 'userTask') {
            node.__event = true
          }
          bpi.nodes[node._id] = node
          if (node._fields) {
            bpi.ws[this.toVar(node._name)] = typeof node._fields === 'string' ? JSON.parse(node._fields) : node._fields
          } else if (node._formObject) {
            var fields = typeof node._formObject === 'string' ? JSON.parse(node._formObject) : node._formObject
            for (const field in fields) {
              bpi.ws[this.toVar(field)] = fields[field]
            }
          }
        } else {
          bpi.links[node._id] = node
        }
      }
    }
    var json = x2js.xml2js(bpd.bp.xml || bpd.bp);
    bpi = {
      _id: this.x.production.newId(),
      bpd: bpd._id,
      bp: json,
      nodes: {},
      dates: { start: new Date() },
      links: {},
      ws: this.addUtils({}),
      trace: { links: [], events: [], steps: [] },
      threads: 0,
      totalThreads: 0,
      activeThreads: [],
      inactiveThreads: []
    }
    var process = bpi.bp.definitions.process
    var node
    for (const key in process) {
      if (typeof process[key] !== 'string') {
        if (process[key].constructor === Array) {
          for (const i in process[key]) {
            node = process[key][i]
            putNode(key, node)
          }
        } else if (process[key].constructor === Object) {
          node = process[key]
          putNode(key, node)
        }
      }
    }
    return bpi
    //})

  }

  // The following two functions must be updated to add and remove the same properties
  addUtils (ws) {
    ws.date2str = moment
    ws.$session = this.$session
    ws.$index = 0
    ws.encript = tags.util.crypto
    ws.xml2js = xml_js.xml2json
    ws.js2xml =xml_js.js2xml
    return ws
  }
  removeUtils (ws) {
    delete ws.date2str
    delete ws.$session
    delete ws.$index
    delete ws.encrypt
    delete ws.xml2js
    delete ws.js2xml
    return ws
  }
  toVar (name) {
    return name ? name.replace(new RegExp(' ', 'g'), '_') : ''
  }

  eval (script) {
    const runnable = new vm.Script(script)
    const context = vm.createContext(this.bpi.ws)
    runnable.runInContext(context)
  }
}
exports.BPI = BPI
