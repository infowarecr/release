
var request = require('request')
var Mongo = require('../utils/mongo').Mongo

exports.Background = Background
var environments = {
  development: {
    idpUrl: 'https://idp.comprobanteselectronicos.go.cr/auth/realms/rut-stag/protocol/openid-connect/token',
    logout: 'https://idp.comprobanteselectronicos.go.cr/auth/realms/rut-stag/protocol/openid-connect/logout',
    url: 'https://api.comprobanteselectronicos.go.cr/recepcion-sandbox/v1/',
    clientId: 'api-stag'
  },
  production: {
    idpUrl: 'https://idp.comprobanteselectronicos.go.cr/auth/realms/rut/protocol/openid-connect/token',
    logout: 'https://idp.comprobanteselectronicos.go.cr/auth/realms/rut/protocol/openid-connect/logout',
    url: 'https://api.comprobanteselectronicos.go.cr/recepcion/v1/',
    clientId: 'api-prod'
  }
}
var bac = new Background('invoice', environments.production)
bac.reprocessing()
function Background (collection, env) {
  this.collection = collection
  this.status = false
  this.pending = false
  this.delay = 1000
  this.environment = env
  this.thread = process.env.pm_id || '100'
  this.mongo = new Mongo('mongodb://127.0.0.1:27017/ebill')
  this.reprocessing = () => {
    this.mongo.find(this.collection, {
      statusHacienda: 'rechazado',
      company: { $nin: ['108920492', '105760619', '108060920', '108590222', '108860192', '109570433', '104600100', '3101403861', '107700112', '3102142607', '103931203', '115600506308', '900550042', '103800201'] }
    }, {}, { company: 1 }, (err, docs) => {
      if (err || !docs || (docs && docs.length === 0)) {
        this.status = false
        setTimeout(() => { this.getStatus() }, this.delay * 100)
      } else {
        this.getNext(docs, 0)
      }
    })
  }
  this.getNext = function (docs, i) {
    if (i >= docs.length) {
      this.status = false
      this.getStatus()
    } else {
      this.getHacienda(docs[i], this.mongo, this.collection, (err) => {
        if (err) console.log(err)
        this.getNext(docs, i + 1)
      })
    }
  }

  this.getHacienda = function (factura, mongo, collection, callback) {
    var ambient = this.environment
    var cedula = factura.company
    var envCompany = 'Produccion'
    mongo.findOne('company', { idNum: cedula, environment: envCompany }, (err, environment) => {
      if (err || !environment) {
        callback(new Error('Company not found'))
      } else {
        getinvoice(this)
      }

      async function getinvoice (th) {
        var token = await th.getToken(cedula, ambient, environment)
        if (token) {
          // Get status invoice
          var claveNumerica = factura.clave
          var options = {
            json: true,
            url: ambient.url + 'recepcion/' + claveNumerica, // + invoice.key,
            headers: {
              Authorization: 'bearer ' + token.access_token
            }
          }
          var start = new Date()
          request.get(options, (err, response, doc) => {
            var end = new Date()
            if (err) {
              mongo.save(collection, { _id: factura._id, statusError: err }, () => {
                callback()
              })
            } else if (doc !== null && response.statusCode === 200) {
              var obj = doc
              var result = Object.keys(obj).map(function (key) {
                return [Number(key), obj[key]]
              })
              var estado = result[2]
              if (estado[1] !== factura.statusHacienda) {
                var responseXml = result[3] ? result[3] : result[2]
                responseXml = responseXml[1]
                mongo.save(collection, { _id: factura._id, currentStatus: estado[1], currentResponseXml: responseXml }, () => {
                  callback()
                })
              } else { callback() }
            } else {
              console.log('getStatus:' + response.statusCode + ' ' + response.statusMessage + ' id ' + factura._id + ' [' + ((end.getTime() - start.getTime()) / 1000) + '] ' + end)
              callback()
            }
          })
        } else {
          callback()
        }
      }
    })
  }

  this.getToken = async function (cedula, ambient, environment) {
    return new Promise(resolve => {
      this.mongo.findOne('token', { company: cedula }, {}, async (err, tok) => {
        if (err) {
          resolve(false)
        } else {
          var seguir = true
          if (tok && tok.nextTokenDate && tok.nextTokenDate.getTime() > new Date().getTime()) {
            seguir = false
          }
          let refreshed = false
          let now = new Date().getTime()
          if (seguir) {
            if (!tok || (tok && tok.expires_in.getTime() < now + 100000)) {
              var closeToken = false
              if (tok && tok.expires_in.getTime() < now && tok.refresh_expires_in.getTime() > now) {
                await this.closeToken({ client_id: ambient.clientId, refresh_token: tok.token.refresh_token }, cedula)
                closeToken = true
              }
              var form
              if (!closeToken && tok && tok.refresh_expires_in.getTime() > now) {
                form = {
                  grant_type: 'refresh_token',
                  client_id: ambient.clientId,
                  refresh_token: tok.token.refresh_token
                }
                refreshed = true
              } else {
                form = {
                  grant_type: 'password',
                  client_id: ambient.clientId,
                  username: environment.user,
                  password: environment.password,
                  client_secret: '',
                  scope: ''
                }
              }
              request.post({ url: ambient.idpUrl, form: form }, (err, httpResponse, token) => {
                if (err) {
                  console.log('get token error: ' + err + ' company ' + cedula)
                  resolve(false)
                } else {
                  if (httpResponse.statusCode === 200) {
                    var tokens = JSON.parse(token)
                    now = new Date().getTime()
                    let expiresIn = now + (tokens.expires_in * 1000)
                    let refreshExpiresIn = now + (tokens.refresh_expires_in * 1000)
                    var docToken = {
                      creationDate: now,
                      company: cedula,
                      expires_in: new Date(expiresIn),
                      refresh_expires_in: new Date(refreshExpiresIn),
                      token: tokens
                    }
                    docToken.token.expires = docToken.expires_in
                    if (tok && tok._id) {
                      docToken._id = tok._id
                      !refreshed ? docToken.count = tok.count + 1 : docToken.count = tok.count
                    } else {
                      docToken._id = this.mongo.newId()
                      docToken.count = 1
                    }
                    this.mongo.save('token', docToken, () => {
                      console.log('Success get token for company ' + cedula)
                      resolve(docToken.token)
                    })
                  } else {
                    console.log('get token error: ' + httpResponse.statusCode + ' ' + httpResponse.statusMessage + ' company ' + cedula)
                    var nextTokenDate = new Date().getTime() + (3600 * 1000)
                    if (tok && tok._id) {
                      tok.nextTokenDate = new Date(nextTokenDate)
                      this.mongo.save('token', tok, () => {
                        resolve(false)
                      })
                    } else {
                      let newDate = new Date()
                      var obj = {
                        _id: this.mongo.newId(),
                        creationDate: newDate,
                        company: cedula,
                        expires_in: newDate,
                        refresh_expires_in: newDate,
                        nextTokenDate: new Date(nextTokenDate),
                        token: {}
                      }
                      this.mongo.save('token', obj, () => {
                        resolve(false)
                      })
                    }
                  }
                }
              })
            } else {
              tok.token.expires = tok.expires_in
              resolve(tok.token)
            }
          } else {
            resolve(false)
          }
        }
      })
    })
  }

  this.closeToken = async function (options, company) {
    return new Promise(resolve => {
      var env = environments['production']
      request.post({ url: env.logout, form: options }, (err, response, token) => {
        if (err) {
          console.log('close token error: ' + err + ' company' + company)
          resolve(false)
        } else {
          if (response.statusCode !== 204) {
            console.log('close token:' + response.statusCode + ' ' + response.statusMessage + ' company' + company)
            resolve(false)
          } else {
            resolve(true)
          }
        }
      })
    })
  }
}
