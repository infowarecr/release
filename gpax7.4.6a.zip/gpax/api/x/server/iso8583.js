class ISO8583 {
  getMethods () {
    return {
      autorize: {
        input: {
          cardNumber: 'N17',
          amount: 'M12'
        },
        output: {

        }
      }
    }
  }

  autorize (input, next) {
    // ...
    next(null, {})
  };
}
exports.ISO8583 = ISO8583
