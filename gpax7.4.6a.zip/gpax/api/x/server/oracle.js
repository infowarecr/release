var os = require('os')
var oracledb = require('oracledb')
if(os.platform().startsWith('win')) {
// On Windows and macOS, you can specify the directory containing your Oracle
// Client Libraries.  If this is not done, then a standard search heuristic is
// used, see the node-oracledb documentation.
  oracledb.initOracleClient({ libDir: '/oracle/instantclient_19_8' }); // Windows
} else {
  oracledb.initOracleClient({ libDir: '/opt/oracle/instantclient_19_8' });
}
var Server = require('./_server').Server

class Oracle extends Server {
  async start (next) {
    if (typeof this.services === 'string') {
      this.services = JSON.parse(this.services)
    }
    try {
      if (!this.properties.connectionTimeout) {
        this.properties.connectionTimeout=5000
      }
      this.pool = await oracledb.createPool(this.properties)
      try {
        this.connection = await this.pool.getConnection()
        next()
      } catch (err) {
        next(err)
      }
    } catch (err) {
      next(err)
    }
  }

  invoke (req) {
    this.result = req.callback
    var service = this.services[req.service]
    if (typeof service.input === 'string') {
      service.input = JSON.parse(service.input)
    }
    if (typeof service.output === 'string') {
      service.output = JSON.parse(service.output)
    }
    if (service) {
      this.callDB(service, req)
    } else {
      this.result({ error: 'Service \'' + this.req.service + '\' not found' })
    }
  }

  async callDB (cfg, req) {
    var input = req.input
    let sameValues = false
    if (input) {
      sameValues = this.check(req.input, cfg)
    } else {
      sameValues = true
    }

    if (!sameValues) {
      this.result({ error: 'incorrect values' })
    } else {
      try {
        var SP = ''
        var bindParameters = {}
        switch (cfg.type.toLowerCase()) {
        case 'sp':
          SP = req.service + '('
          for (const key in input) {
            SP += ':' + key + ','
            const type = cfg.input[key].split(':')[0]
            let length
            if (type === 'string') {
              length = Number(cfg.input[key].split(':')[1])
            } else {
              length = cfg.input[key].split(':')[1]
            }
            switch (type.toLowerCase()) {
            case 'string':
              if (length) {
                bindParameters[key] = input[key]
              } else {
                bindParameters[key] = input[key].toString()
              }
              break
            case 'number':
              bindParameters[key] = { dir: oracledb.BIND_IN, val: Number(input[key]), type: oracledb.NUMBER }
              break
            case 'decimal':
              bindParameters[key] = { dir: oracledb.BIND_IN, val: Number(input[key]), type: oracledb.BINARY_DOUBLE }
              break
            case 'smallint':
              bindParameters[key] = { dir: oracledb.BIND_IN, val: Number(input[key]), type: oracledb.BINARY_INTEGER }
              break
            case 'boolean':
              bindParameters[key] = { dir: oracledb.BIND_IN, val: input[key], type: oracledb.BOOLEAN }
              break
            case 'date':
              bindParameters[key] = { dir: oracledb.BIND_IN, val: input[key], type: oracledb.DB_TYPE_DATE }
              break
            case 'cursor':
              bindParameters[key] = { dir: oracledb.BIND_IN, val: input[key], type: oracledb.CURSOR }
              break
            }
          }

          for (const key in cfg.output) {
            SP += ':' + key + ','
            const type = cfg.output[key].split(':')[0]
            const length = Number(cfg.output[key].split(':')[1])
            switch (type.toLowerCase()) {
            case 'string':
              if (length) {
                bindParameters[key] = { dir: oracledb.BIND_OUT, type: oracledb.STRING, maxSize: length }
              } else {
                bindParameters[key] = { dir: oracledb.BIND_OUT, type: oracledb.STRING }
              }
              break
            case 'number':
              bindParameters[key] = { dir: oracledb.BIND_OUT, type: oracledb.NUMBER }
              break
            case 'decimal':
              //div = length.split(',')
              bindParameters[key] = { dir: oracledb.BIND_OUT, type: oracledb.BINARY_DOUBLE }
              break
            case 'smallint':
              bindParameters[key] = { dir: oracledb.BIND_OUT, type: oracledb.BINARY_INTEGER }
              break
            case 'boolean':
              bindParameters[key] = { dir: oracledb.BIND_OUT, type: oracledb.BOOLEAN }
              break
            case 'date':
              bindParameters[key] = { dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_DATE }
              break
            case 'cursor':
              bindParameters[key] = { dir: oracledb.BIND_OUT, type: oracledb.CURSOR }
              break
            }
          }
          SP = SP.substring(0, SP.length-1)
          SP += ');'
          break
        case 'query':
          /// falta contriur para ejecutar query////
          //pending = request.query(cfg.query)
          break
        }
        try {
          const result = await this.connection.execute(
            `BEGIN
              ${SP}
            END;`,
            bindParameters,
            {
              outFormat: oracledb.OUT_FORMAT_OBJECT
            }
          )
          if (result.rows && result.rows.length > 0) this.result({ recordsets: result.rows })
          else if (result.outBinds) {
            let array = []
            for (let key in result.outBinds) {
              var resultSet = result.outBinds[key]
              if (resultSet.getRow) {
                let row;
                while ((row = await resultSet.getRow())) {
                  array.push(row)
                }
              } else {
                array.push(result.outBinds)
                break
              }

            }
            this.result({ output: array })
          }
          else this.result(result)
        } catch (err) {
          var msg=err.message.split('\n')[0]
          this.result({ error: msg })
        }
      } catch (err) {
        this.result({ error: err })
      }
    }
  }

  check (data, cfg) {
    if (typeof data !== typeof cfg.input) {
      return false
    } else {
      for (const key in data) {
        switch (cfg.input[key]) {
        case 'string':
          if (typeof data[key] !== 'string') { return false }
          break
        case 'number':
        case 'decimal':
        case 'smallint':
          if (typeof Number(data[key]) !== 'number' && !(isFinite(data[key]))) { return false }
          break
        case 'array':
          if (data[key] && typeof data[key] !== 'object' && data[key].constructor !== Array) { return false }
          break
        case 'object':
          if (data[key] && typeof data[key] !== 'object' && data[key].constructor !== Object) { return false }
          break
        case 'boolean':
          if (typeof data[key] !== 'boolean') { return false }
          break
        case 'date':
          /* if (!(data[key] instanceof Date)) {
              return false
            } else {
              var timestamp = Date.parse(data[key])
              if (isNaN(timestamp) == false) {
                data[key] = new Date(timestamp);
              } else {
                return false
              }
            } */
          break
        }
      }
      return true
    }
  }
}
exports.Server = Oracle


//114880615
