var Server = require('./_server').Server

class Web extends Server {

}
exports.Server = Web