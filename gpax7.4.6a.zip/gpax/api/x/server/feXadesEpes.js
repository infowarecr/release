// Firma XAdES-EPES
// var exec = require('child_process').exec,
//   child;
// child = exec('java -jar FirmaXadesEpes-master/compilado/firmar-xades.jar FirmaXadesEpes-master/recursos/204510901.p12 1969 FirmaXadesEpes-master/recursos/factura.xml FirmaXadesEpes-master/recursos/factura-firmada.xml',
//   function(error, stdout, stderr) {
//     console.log('stdout: ' + stdout);
//     console.log('stderr: ' + stderr);
//     if (error !== null) { console.log('exec error: ' + error); }
//   });

exports.Xades = Xades

function Xades () {
  // Firma
  this.firmar = function () {
    var exec = require('child_process').exec

    var child
    child = exec('java -jar x/server/xades-signer-cr-master/xadessignercr/release/xadessignercr.jar sign x/server/FirmaXadesEpes-master/recursos/204510901.p12 1969 x/server/xades-signer-cr-master/test-data/enviar.xml x/server/xades-signer-cr-master/test-data/enviarout.xml',
      function (error, stdout, stderr) {
        console.log('stdout: ' + stdout)
        console.log('stderr: ' + stderr)
        // sender();
        if (error !== null) { console.log('exec error: ' + error) }
      })
  }

  function sender () {
    // SEND INVOICE
    var exec = require('child_process').exec

    var child
    child = exec('java -jar x/server/xades-signer-cr-master/xadessignercr/release/xadessignercr.jar send "https://api.comprobanteselectronicos.go.cr/recepcion-sandbox/v1" x/server/xades-signer-cr-master/test-data/enviarout.xml cpf-02-0451-0901@stag.comprobanteselectronicos.go.cr "_||qGpr-6)D=%VWm@$:n"',
      function (error, stdout, stderr) {
        console.log('stdout: ' + stdout)
        console.log('stderr: ' + stderr)
        if (error !== null) { console.log('exec error: ' + error) }
      })
  }

  function get () {
    // GET INVOICE
    var exec = require('child_process').exec

    var child
    child = exec('java -jar x/server/xades-signer-cr-master/xadessignercr/release/xadessignercr.jar query "https://api.comprobanteselectronicos.go.cr/recepcion-sandbox/v1" x/server/xades-signer-cr-master/test-data/enviarout.xml cpf-02-0451-0901@stag.comprobanteselectronicos.go.cr "_||qGpr-6)D=%VWm@$:n"',
      function (error, stdout, stderr) {
        console.log('stdout: ' + stdout)
        console.log('stderr: ' + stderr)
        if (error !== null) { console.log('exec error: ' + error) }
      })
  }
}

// function sender() {
//               //SEND INVOICE
//               var exec = require('child_process').exec,
//                 child;
//               child = exec('java -jar x/server/xades-signer-cr-master/xadessignercr/release/xadessignercr.jar send "https://api.comprobanteselectronicos.go.cr/recepcion-sandbox/v1" x/server/xades-signer-cr-master/test-data/enviarout.xml cpf-02-0451-0901@stag.comprobanteselectronicos.go.cr "_||qGpr-6)D=%VWm@$:n"',
//                 function(error, stdout, stderr) {
//                   if (error !== null) {
//                     send({ message: 'Ocurrio un error al enviar la factura' });
//                   }
//                   else {
//                     if (stderr) {
//                       console.log('stderr: ' + stderr);
//                     }
//                     else {
//                       var jsonMessage = JSON.parse(stdout);
//                       var voucherXml = jsonMessage.comprobanteXml;
//                       mongo.save("invoice", { _id: body._id, voucherXml: voucherXml }, (err, result) => {
//                         if (err) {
//                           //send({ error: tags.savingProblema });
//                         }
//                         send({ message: 'Factura enviada' });
//                         //getinvoice();
//                         console.log('stdout: ' + stdout);
//                       });
//                     }
//                     if (error !== null) { console.log('exec error: ' + error); }
//                   }
//                 });
//             }
