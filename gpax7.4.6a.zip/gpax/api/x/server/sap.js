var Server = require('./_server').Server

class SAP extends Server {

}
exports.Server = SAP