var Server = require('./_server').Server

class Virtual extends Server {

}
exports.Server = Virtual