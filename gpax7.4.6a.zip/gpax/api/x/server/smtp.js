var Server = require('./_server').Server

class Smtp extends Server {

}
exports.Server = Smtp