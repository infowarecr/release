var sql = require('mysql')
var Server = require('./_server').Server

class Mysql extends Server {
  async start (next) {
    if (typeof this.services === 'string') {
      this.services = JSON.parse(this.services)
    }

    try {
      this.pool = await new sql.ConnectionPool(this.properties).connect()
      next()
    } catch (err) {
      next(err)
    }
  }

  invoke (req) {
    this.result = req.callback
    var service = this.services[req.service]
    if (typeof service.input === 'string') {
      service.input = JSON.parse(service.input)
    }
    if (typeof service.output === 'string') {
      service.output = JSON.parse(service.output)
    }
    if (service) {
      this.callDB(service, req)
    } else {
      this.result({ error: 'Service \'' + this.req.service + '\' not found' })
    }
  }

  async callDB (cfg, req) {
    var input = req.input
    let sameValues = false
    if (input) {
      sameValues = this.check(req.input, cfg)
    } else {
      sameValues = true
    }

    if (!sameValues) {
      this.result({ error: 'incorrect values' })
    } else {
      try {
        const request = await this.pool.request()
        let div
        for (const key in input) {
          const type = cfg.input[key].split(':')[0]
          let length
          if (type === 'string') {
            length = Number(cfg.input[key].split(':')[1])
          } else {
            length = cfg.input[key].split(':')[1]
          }
          switch (type.toLowerCase()) {
          case 'string':
            request.input(key, sql.NVarChar(length), input[key])
            break
          case 'number':
            request.input(key, sql.Int, Number(input[key]))
            break
          case 'decimal':
            div = length.split(',')
            request.input(key, sql.Decimal(Number(div[0]), Number(div[1])), Number(input[key]))
            break
          case 'smallint':
            request.input(key, sql.SmallInt, Number(input[key]))
            break
          case 'boolean':
            request.input(key, sql.Bit, input[key])
            break
          case 'date':
            request.input(key, sql.DateTime, input[key])
            break
          }
        }

        for (const key in cfg.output) {
          const type = cfg.output[key].split(':')[0]
          const length = Number(cfg.output[key].split(':')[1])
          switch (type.toLowerCase()) {
          case 'string':
            request.output(key, sql.NVarChar(length))
            break
          case 'number':
            request.output(key, sql.Int)
            break
          case 'decimal':
            div = length.split(',')
            request.output(key, sql.Decimal(Number(div[0]), Number(div[1])))
            break
          case 'smallint':
            request.output(key, sql.SmallInt)
            break
          case 'boolean':
            request.output(key, sql.Bit)
            break
          case 'date':
            request.output(key, sql.DateTime)
            break
          }
        }
        let pending
        switch (cfg.type.toLowerCase()) {
        case 'sp':
          pending = request.execute(req.service)
          break
        case 'query':
          pending = request.query(cfg.query)
          break
        }
        try {
          const result = await pending
          if (result.recordsets.length > 0) this.result({ recordsets: result.recordsets })
          else if (result.output) this.result({ output: result.output })
          else this.result(result)
        } catch (err) {
          this.result({ error: err.message })
        }
      } catch (err) {
        this.result({ error: err })
      }
    }
  }

  check (data, cfg) {
    if (typeof data !== typeof cfg.input) {
      return false
    } else {
      for (const key in data) {
        switch (cfg.input[key]) {
        case 'string':
          if (typeof data[key] !== 'string') { return false }
          break
        case 'number':
        case 'decimal':
        case 'smallint':
          if (typeof Number(data[key]) !== 'number' && !(isFinite(data[key]))) { return false }
          break
        case 'array':
          if (data[key] && typeof data[key] !== 'object' && data[key].constructor !== Array) { return false }
          break
        case 'object':
          if (data[key] && typeof data[key] !== 'object' && data[key].constructor !== Object) { return false }
          break
        case 'boolean':
          if (typeof data[key] !== 'boolean') { return false }
          break
        case 'date':
          if (!(data[key] instanceof Date)) { return false }
          break
        }
      }
      return true
    }
  }
}
exports.Server = Mysql

