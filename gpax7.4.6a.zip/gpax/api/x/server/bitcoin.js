var blockchain = require('blockchain.info')
var Server = require('./_server').Server
class BitCoin extends Server {

  start (next) {
    let options = { apiCode: this.apiCode, apiHost: this.host }
    if (this.secondPassword && this.secondPassword.length > 0) {
      options.secondPassword = this.secondPassword
    }
    this.wallet = new blockchain.MyWallet(this.wallet, this.password, options)
    next()
  }
}

exports.Server = BitCoin