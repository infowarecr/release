var Server = require('./_server').Server

class Terminal extends Server {

}
exports.Server = Terminal