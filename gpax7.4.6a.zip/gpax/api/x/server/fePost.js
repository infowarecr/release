// Request Token
var request = require('request')

var fs = require('fs')

var path = require('path')

var xmlReader = require('read-xml')
var base64 = require('base-64')

/// /Request Token
var urlsandbox = 'https://api.comprobanteselectronicos.go.cr/recepcion-sandbox/v1/'
var idp_url = 'https://idp.comprobanteselectronicos.go.cr/auth/realms/rut-stag/protocol/openid-connect/token'
var idp_client_id = 'api-stag'
var user = 'cpf-02-0451-0901@stag.comprobanteselectronicos.go.cr'
var password = '_||qGpr-6)D=%VWm@$:n'

/* request.post({
    url: idp_url,
    form: {
      "grant_type": "password",
      "client_id": idp_client_id,
      "username": user,
      "password": password,
      'client_secret': '',
      'scope': ''
    }
  },
  function(err, httpResponse, body) {
    if (err) {
      console.log(err);
    }
    else {
      if (httpResponse.statusCode === 200) {
        var tokens = JSON.parse(body);
        //console.log(tokens);

        //get invoice.xml and encode to Base64
        var FILE = path.join(__dirname, '/xades-signer-cr-master/test-data/enviarout.xml');
        // pass a buffer or a path to a xml file
        var decodedXMLStream = fs.createReadStream(FILE).pipe(xmlReader.createStream());

        decodedXMLStream.on('encodingDetected', function(encoding) {
          //console.log('Encoding:', encoding);
          decodedXMLStream.on('data', function(xmlStr) {

            var comprobanteXml = base64.encode(xmlStr)

            console.log(comprobanteXml);

            var formData = {
              clave: "50619031800020451090100100001010000000004104510901",
              fecha: "2018-03-19T13:05:45-06:00",
              emisor: {
                tipoIdentificacion: "01",
                numeroIdentificacion: "204510901"
              },
              receptor: {
                tipoIdentificacion: "02",
                numeroIdentificacion: "3101260001"
              },
              comprobanteXml: comprobanteXml
            };

            var options = {
              url: urlsandbox + 'recepcion',
              json: true,
              body: formData,
              headers: {
                'Authorization': 'bearer ' + tokens.access_token,
                "content-type": "application/javascript"
              }
            }
            request.post(options, function(err, response, body) {
              if (response.statusCode === 202) {
                console.log(response.headers.location)
              }
              else {
                console.log(response.statusCode + " -> " + response.statusMessage);
              }
            });
          });
        });
      }
      else {
        console.log(httpResponse.statusCode + " -> " + httpResponse.statusMessage);
      }
    }
  }); */

var FILE = path.join(__dirname, '/xades-signer-cr-master/test-data/out.xml')
// pass a buffer or a path to a xml file
var decodedXMLStream = fs.createReadStream(FILE).pipe(xmlReader.createStream())

decodedXMLStream.on('encodingDetected', function (encoding) {
  // console.log('Encoding:', encoding);
  decodedXMLStream.on('data', function (xmlStr) {
    var comprobanteXml = base64.encode(xmlStr)

    console.log('done')
  })
})
