var request = require('request')
var base64 = require('base-64')
// var utf8 = require('utf8');
request.post({
  url: 'https://idp.comprobanteselectronicos.go.cr/auth/realms/rut/protocol/openid-connect/token',
  form: {
    'grant_type': 'password',
    'client_id': 'api-prod',
    'username': 'cpf-03-0163-0175@prod.comprobanteselectronicos.go.cr',
    'password': '^H(|I;TYYP3N/-:(mj=%',
    'client_secret': '',
    'scope': ''
  }
},
function (err, httpResponse, body) {
  if (err) {
    console.log(err)
  } else {
    if (httpResponse.statusCode === 200) {
      var tokens = JSON.parse(body)

      // Get status invoice
      var options = {
        json: true,
        // url: 'https://api.comprobanteselectronicos.go.cr/recepcion/v1/comprobantes?emisor=02003101396382', // &offset=90',
        url: 'https://api.comprobanteselectronicos.go.cr/recepcion/v1/recepcion/50614061900030163017500100001040000043454100001234',
        headers: {
          'Authorization': 'bearer ' + 'eyJhbGciOiJSUzI1NiJ9.eyJqdGkiOiJiNzgwYWMyZi0xZTBhLTRhOTEtOWFmNi0wYzQyZjQ1ZGE1MWQiLCJleHAiOjE1NjA1NTE1MDMsIm5iZiI6MCwiaWF0IjoxNTYwNTUxMjAzLCJpc3MiOiJodHRwczovL2lkcC5jb21wcm9iYW50ZXNlbGVjdHJvbmljb3MuZ28uY3IvYXV0aC9yZWFsbXMvcnV0IiwiYXVkIjoiYXBpLXByb2QiLCJzdWIiOiJiYTJhMDBiYS01ODM0LTQxZGEtYTk4My1hYzhlZjNkMmNkOTMiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJhcGktcHJvZCIsInNlc3Npb25fc3RhdGUiOiI0Zjg2MTQyYy0wNjE4LTQyZGItYjI3Zi04YTU0MzMwMjgzZWEiLCJjbGllbnRfc2Vzc2lvbiI6Ijk0NmQ1YzBkLWQwYmItNDFkNS04YTc5LTRmNDUxMDhlN2RhYSIsImFsbG93ZWQtb3JpZ2lucyI6W10sInJlc291cmNlX2FjY2VzcyI6eyJhY2NvdW50Ijp7InJvbGVzIjpbIm1hbmFnZS1hY2NvdW50Iiwidmlldy1wcm9maWxlIl19fSwibmFtZSI6IkdVSURPIE1FTkRFWiBDQVNUSUxMTyIsInByZWZlcnJlZF91c2VybmFtZSI6ImNwZi0wMy0wMTYzLTAxNzVAcHJvZC5jb21wcm9iYW50ZXNlbGVjdHJvbmljb3MuZ28uY3IiLCJwb2wiOiI1YjgwYjliOTllY2UzNjAzMmIwN2QyZWQiLCJnaXZlbl9uYW1lIjoiR1VJRE8iLCJmYW1pbHlfbmFtZSI6Ik1FTkRFWiBDQVNUSUxMTyIsInBvbGljeS1pZCI6IjU4YTYyMGEzNzZlYWUxNDA4Y2U1ZTdkZiIsImVtYWlsIjoiY3BmLTAzLTAxNjMtMDE3NUBwcm9kLmNvbXByb2JhbnRlc2VsZWN0cm9uaWNvcy5nby5jciJ9.Z38rO7Tq4uSYx5ATTKUik7GhtwjOY2J_No66M8DoKIDH1QZn7hVnY0DnkFmsHgask7DQ7QQy9kYRkY7oOtFQcYaxUSP7yvBiZn1OnRXbH-58Pi5hug_SDDBkvyI_2x8gx6sJvkdtMk4UcJDkgwtz7x6z7LhLuxL6Myq8M8Ejz_lKRhG99Ppvmtk-IoXoK-LvZoyGJGpHy_M64Z5EGctx2nvB4d9QCzPiEZezSCHONmNLeW0hd1ZyQu8-UxSHY9a50MI7ZWHUD1LWj_cm-YT0gH7wgApcO9gV8nHo71FlK4tmIaA7bm0wdGtW9953grthSBxebZEt3xnJT3NzDpp0nw'
        }
      }
      request.get(options, function (err, response, body) {
        if (err) {
          console.log(err)
        } else {
          var obj = body
          var result = Object.keys(obj).map(function (key) {
            return [Number(key), obj[key]]
          })
          var x = result[3]
          var bytes = base64.decode(x[1])
          if (response.statusCode === 200) {
            // console.log(body)
          } else {
            console.log(response.statusCode + ' -> ' + response.statusMessage)
          }
        }
      })
    } else {
      console.log(httpResponse.statusCode)
    }
  }
})

// Uso del token
// incluyéndolo en el encabezado Authorization:
// Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ik5HVEZ2ZEstZnl0aEV1Q...
