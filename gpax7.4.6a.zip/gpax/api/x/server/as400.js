var datos;

function copiar(bytes, contador) {
  for (let i int i = 0; i < contador; ++i) {
    datos[i] = (byte) bytes[i];
  }
  return contador;
}

function copiar(String hilera, int posicion) {
  for (int i = 0; i < hilera.length(); ++i, ++posicion) {
    datos[posicion] = (byte) hilera.charAt(i);
  }
  return posicion - 1;
}

function insertar(String trama, int pos, char[] pantalla, int len) {
  String r = trama.substring(0, len);
  char[] rc = r.toCharArray();
  for (int i = 0, p = pos; i < len; ++i, ++p) {
    pantalla[p] = rc[i];
  }
  return r;
}

function filtrarTrama(char[] data, int inicio, int longitud) {
  String xStr, yStr, trama = super.filtrarTrama(data, inicio, longitud);
  char[] pantalla = new char[1920];
  int l, p, x, y, posActual;
  // Inicializa la pantalla (80*24)
  Arrays.fill(pantalla, ' ');
  /*
   * Filtra la trama obtenida de acuerdo con los criterios de la emulación VT100
   */
  if (trama.length() > 0) {
    /*
     *  Copia a 's' los caracteres que no sean secuencias de escape y los ubica en la posición correspondiente de acuerdo a las secuencias de escape <esc>[x;yH
     */
    if (trama.length() > 0) {
      p = 0;
      posActual = 0;
      while (p < trama.length() && p !== -1) {
        // Busca la siguiente secuencia de escape
        p = trama.indexOf(Const.SECUENCIA_ESCAPE, p);
        if (p === -1) {
          insertar(trama, posActual, pantalla, trama.length());
          continue;
        }
        /*
         * Extrae de la trama los caracteres que están antes de la secuencia de escape
         */
        if (p > 0) {
          insertar(trama, posActual, pantalla, p);
          trama = trama.substring(p);
          posActual += p;
        }
        /*
         * Analiza la secuencia de escape para ver si es del tipo <esc>[x;yH ...
         */
        for (p = 2; Character.isDigit(trama.charAt(p)) || trama.charAt(p) === '?' || trama.charAt(p) === ';'; ++p)
        ;
        /*
         * Si se trata de una secuencia <esc>[x;yH rellena en la salida la matriz de 80x24 de acuerdo a las coordenadas
         */
        if (trama.charAt(p) === 'H') {
          /*
           * Obtiene los valores de las coordenadas x,y; y con estas calcula el numero de caracteres de relleno que debe usar para alcanzar la nueva  posicion
           */
          l = trama.indexOf(';');
          yStr = trama.substring(2, l);
          xStr = trama.substring(l + 1, p);
          y = new Integer(yStr) - 1;
          x = new Integer(xStr) - 1;
          posActual = (y * 80) + x;
        }
        trama = trama.substring(p + 1);
        p = 0;
      }
    }
  }
  trama = String.valueOf(pantalla);
  return trama;
}

function negociar() {
  int l;
  try {
    // El tiempo de espera será de 1 segundo durante la negociación
    conexion.setSoTimeout(1000);
    // Espera mensaje inicial del servidor
    l = bInput.read(datos, 0, datos.length);
    // Solicita negociar el nuevo ambiente según
    // http://rfc.net/rfc2877.html
    datos[0] = Caracteres.IAC;
    datos[1] = Caracteres.WILL;
    datos[2] = Caracteres.NENV;
    bOutput.write(datos, 0, 3);
    l = bInput.read(datos, 0, datos.length);
    // Envía usuario, clave y estación
    datos[0] = Caracteres.IAC;
    datos[1] = Caracteres.SB;
    datos[2] = Caracteres.NENV;
    datos[3] = Caracteres.IS;
    datos[4] = Caracteres.VAR;
    l = copiar("USER", 5);
    datos[++l] = Caracteres.VALUE;
    l = copiar(usuario, ++l);
    datos[++l] = Caracteres.USVAR;
    l = copiar("DEVNAME", ++l);
    datos[++l] = Caracteres.VALUE;
    l = copiar(estacion, ++l);
    datos[++l] = Caracteres.USVAR;
    l = copiar("IBMRSEED", ++l);
    datos[++l] = Caracteres.VALUE;
    datos[++l] = Caracteres.USVAR;
    l = copiar("IBMSUBSPW", ++l);
    datos[++l] = Caracteres.VALUE;
    l = copiar(clave, ++l);
    datos[++l] = Caracteres.IAC;
    datos[++l] = Caracteres.SE;
    bOutput.write(datos, 0, ++l);
    // Solicita negociar tipo de terminal
    datos[0] = Caracteres.IAC;
    datos[1] = Caracteres.WILL;
    datos[2] = Caracteres.TTER;
    bOutput.write(datos, 0, 3);
    l = bInput.read(datos, 0, datos.length);
    // Envía el tipo de terminal (VT100)
    datos[0] = Caracteres.IAC;
    datos[1] = Caracteres.SB;
    datos[2] = Caracteres.TTER;
    datos[3] = Caracteres.IS;
    l = copiar("VT100", 4);
    datos[++l] = Caracteres.IAC;
    datos[++l] = Caracteres.SE;
    bOutput.write(datos, 0, ++l);
    // Devuelve exactamente el resultado del Host
    l = bInput.read(datos, 0, datos.length);
    bOutput.write(datos, 0, l);
    // Lee la primer pantalla de datos
    conexion.setSoTimeout(espera);
    datos[0] = Caracteres.CR;
    bOutput.write(datos, 0, 1);
    l = bInput.read(datos, 0, datos.length);
  }
  catch (Exception ex) {
    Logger.write(ex, Logger.Severidad.ErrorCritico, logLevel);
  }
}
