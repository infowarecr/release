var client = require('restify-clients')
var Server = require('./_server').Server

class REST extends Server {
  constructor (x,config) {
    super(x,config)
    this.rest = client.createJsonClient(config.url)
  }
}

exports.Server = REST