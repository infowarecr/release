
var Mongo2 = require('../utils/mongo').Mongo
var Server = require('./_server').Server
// const mongodb = require('mongodb')
var ObjectID = require('bson-objectid')

class Mongo extends Server {
  constructor (x, config) {
    super(x,config)
    this.mongos = {}
  }

  getMongo (url) {
    if (!this.mongos[url]) {
      this.mongos[url] = new Mongo2(url)
    }
    return this.mongos[url]
  }

  start (next) {
    try {
      this.mongo = this.getMongo(this.host)
      next()
    }
    catch (err) {
      next(err)
    }
  }

  // Method to invoke service directly
  invoke (data) {
    this.result = data.callback
    this.input = data
    const cfg = this.services[this.input.service]
    const sameValues = this.check(data.input, cfg)
    if (!sameValues) {
      data.error = 'incorrect values'
      data.callback(data)
      return
    }
    if (cfg) {
      switch (cfg.operation) {
      case 'find':
        this.mongo.find(cfg.collection, this.input.keys, cfg.output, (err, doc) => {
          if (err || !doc) {
            this.result(this.input)
          } else {
            this.input.success = true
            this.input.output = doc[0]
            this.result(this.input)
          }
        })
        break
      case 'insert':
      case 'update':
        this.mongo.save(cfg.collection, this.input, (err, result) => {
          if (err) {
            this.result(this.input)
          } else {
            this.input.success = true
            // this.input.output = { inserted=true, error:0 }
            this.result(this.input)
          }
        })
        break
      case 'delete':
        this.mongo.deleteOne(cfg.collection, this.input.keys, (err, result) => {
          if (err || result.modifiedCount === 0) {
            this.result(this.input)
          } else {
            this.input.success = true
            // this.input.output = { deleted=true, error:0 }
            this.result(this.input)
          }
        })
        break
      }
    } else {
      this.input.error = 'Service \'' + this.input.service + '\' not found'
      this.result(this.input)
    }
  }

  check (data, cfg) {
    if (Object.keys(data).length !== Object.keys(cfg.input).length) {
      return false
    } else {
      for (const key in data) {
        if ((key === '_id' || cfg.input[key] === 'ObjectId') && !ObjectID.isValid(data[key])) {
          return false
        } else if (cfg.input[key] !== 'ObjectId') {
          switch (cfg.input[key]) {
          case 'string':
            if (typeof data[key] !== 'string') { return false }
            break
          case 'number':
            if (typeof data[key] !== 'number' && !(isFinite(data[key]))) { return false }
            break
          case 'array':
            if (data[key] && typeof data[key] !== 'object' && data[key].constructor !== Array) { return false }
            break
          case 'object':
            if (data[key] && typeof data[key] !== 'object' && data[key].constructor !== Object) { return false }
            break
          case 'boolean':
            if (typeof data[key] !== 'boolean') { return false }
            break
          case 'date':
            if (!(data[key] instanceof Date)) { return false }
            break
          }
        }
      }
      return true
    }
  }
}

exports.Server = Mongo
