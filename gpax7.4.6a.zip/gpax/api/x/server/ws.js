var soap = require('soap')
var Server = require('./_server').Server
class WS extends Server {
  start (next) {
    soap.createClient(this.properties.host+'?wsdl', (err) => {
      if (err) {
        next({ error: err })
      } else {
        next()
      }
    })
  }
  // Method to invoke service directly
  invoke (data) {
    this.result = data.callback
    this.request = data
    soap.createClient(this.properties.host + '?wsdl', (err, client) => {
      if (err) {
        data.error = 'No methods: ' + err
        this.result(data)
      } else {
        client[this.request.service](this.request.input, (err, result) => {
          console.log(client.lastRequest)
          if (err) {
            data.error = err
            this.result(data)
          } else {
            
            result = this.$replace(result)
            data.output = result
            data.success = true
            this.result(data)
          }
        })
      }
    })
  }

  $replace (field) {
    var type = typeof (field)
    if (!this.queue) {
      this.queue=[]
    }
    if (type === 'object') {
      if (this.queue.indexOf(field) === -1) {
        this.queue.push(field)
        for (const key in field) {
            if (key.includes('$')) {
              field[key.replace( new RegExp("\\$","gm"),"")] = field[key]
            } if (field[key]) {
              field[key] = this.$replace(field[key])
            }
          
        }
      }
    } else if (type === 'array') {
      for (let i = 0; i < field.length; ++i) {
        field[i] = this.$replace(field[i])
      }
    }
    return field
  }
  check (data, cfg) {
    if (Object.keys(data).length != Object.keys(cfg.input).length) {
      return false
    } else {
      for (let key in data) {
        switch (cfg.input[key]) {
        case 'string':
          if (typeof data[key] != 'string')
            return false
          break
        case 'number':
          if (typeof data[key] != 'number' && !(isFinite(data[key])))
            return false
          break
        case 'array':
          if (data[key] && typeof data[key] != 'object' && data[key].constructor != Array)
            return false
          break
        case 'object':
          if (data[key] && typeof data[key] != 'object' && data[key].constructor != Object)
            return false
          break
        case 'boolean':
          if (typeof data[key] != 'boolean')
            return false
          break
        case 'date':
          if (!(data[key] instanceof Date))
            return false
          break
        }
      }
      return true
    }
  }
}
exports.Server = WS
