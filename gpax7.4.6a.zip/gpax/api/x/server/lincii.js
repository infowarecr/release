const date = require('date-and-time')
const codes = require('../codes').codes
const net = require('net')
const vm = require('vm')
const Server = require('./_server').Server
class LincII extends Server {
  // Connect to LincII system inner UNISYS mainframe
  start (next) {
    try {
      this.workspace = {}
      this.status = 'starting'
      this.msg = ''
      this.sequence = 0
      this.requestDate = date.format(new Date(), 'DDMMMYY')
      this.actMonth = date.format(new Date(), 'YYMM')
      this.unisys = new net.Socket()
      // The "process" method analyzes each response of the lincii system and close event too
      this.unisys.on('connect', (data) => {
        next()
        this.process(data)
      })
      // The "process" method analyzes each response of the lincii system and close event too
      this.unisys.on('data', (data) => {
        this.process(data)
      })
      // Catch error event
      this.unisys.on('error', (err) => {
        next(err)
      })
      this.unisys.on('timeout', (err) => {
        next(err)
      })
      this.unisys.setTimeout(5000)
      this.unisys.connect({ port: 23, host: this.host || this.properties.host })
    }
    catch (err) {
      next(err)
    }
  }

  // Method to invoke service directly
  invoke (request) {
    this.result = request.callback
    this.request = request
    if (this.request.service) {
      const cfg = this.services[this.request.service.toLowerCase()]
      if (cfg) {
        // Initialize workspace before proccess each message
        this.workspace = {}
        this.workspace.start = this.request
        this.workspace.initTime = new Date()
        this.msg = this.format(this.request.service, { ...this.request.input }, cfg)
        this.send(this.msg)
      } else {
        this.result({ error: 'Service "' + this.request.service + '" not found' })
      }
    } else {
      this.resul({ error: 'Field "service" required' })
    }
  }

  // Send request to the LincII system and add the end of record if necessary
  send (data) {
    /* if (this.status != "connected") */ console.log(this.status + '<-' + data)//
    if (this.status === 'connected' || this.status === 'initiated') {
      data += codes.IAC + codes.FIN
    }
    this.unisys.write(data, 'ascii')
  }

  // Analyzes each response of the lincii system and close event too
  process (buff) {
    const data = codes.toAscii(buff)
    let p
    let result
    let cfg
    let json
    /* if (this.status != "connected") */ console.log(this.status + '->' + codes.toHuman(buff))//
    switch (this.status) {
    case 'starting':
      // Negotiating terminal type according to http://rfc.net/rfc930.html
      this.msg = codes.IAC + codes.WILL + codes.TTER
      // Negotiating terminal name according to http://rfc.net/rfc779.html
      this.msg += codes.IAC + codes.WILL + codes.SLOC
      this.send(this.msg)
      this.status = 'negotiating terminal'
      break
    case 'negotiating terminal':
      // Agreed to negotiate terminal type and station name
      if (data.includes(codes.IAC + codes.DO + codes.TTER) && data.includes(codes.IAC + codes.DO + codes.SLOC)) {
        // Request type of terminal "NETWORK-VIRTUAL-TERMINAL"
        this.msg = codes.IAC + codes.SB + codes.TTER + codes.IS + 'NETWORK-VIRTUAL-TERMINAL' + codes.IAC + codes.SE
        // Request to assign the station name
        this.msg += codes.IAC + codes.SB + codes.SLOC + this.properties.station + codes.IAC + codes.SE
        // Request binary transmission according to http://rfc.net/rfc856.html
        this.msg += codes.IAC + codes.WILL + codes.BIN + codes.IAC + codes.DO + codes.BIN
        // Request end of record according to http://rfc.net/rfc885.html
        this.msg += codes.IAC + codes.WILL + codes.EOR + codes.IAC + codes.DO + codes.EOR
        this.send(this.msg)
        this.status = 'negotiating EOR'
      }
      break
    case 'negotiating EOR':
      // Agreed type terminal and station name
      if (data.includes(codes.IAC + codes.DO + codes.EOR) && data.includes(codes.IAC + codes.DO + codes.BIN)) {
        this.status = 'initiated'
        // this.  send('?ON ' + this.properties.window);
        //this.listen()
      }
      // eslint-disable-next-line no-fallthrough
    case 'initiated':
      p = data.indexOf('INPUT REQUEST')
      if (p !== -1) {
        this.sequence = Number(data.substr(7, 6))
        this.requestDate = data.substr(13, 7)
        this.actMonth = data.substr(20, 4)
        this.status = 'connected'
        if (this.next) {
          this.next()
          delete this.next
          break
        }
      }
      // eslint-disable-next-line no-fallthrough
    case 'connected':
      result = data.substr(1)
      cfg = this.services[result.substr(0, 5).toLowerCase()]
      json = {}
      this.workspace.repeat = false
      if (cfg) {
        json = this.parse(result.substring(23), cfg)
        json.service = result.substr(0, 5).toLowerCase()
        this.workspace[json.service] = json
        if (cfg['while$']) {
          const context = vm.createContext(this.workspace)
          const script = new vm.Script('repeat=' + cfg['while$'])
          script.runInContext(context)
        }
      } else {
        json.error = 'Unknown answer'
        json.message = result
      }
      if (this.workspace.initTime) {
        if (cfg && cfg['repeat$']) {
          if (!this.response) {
            this.response = json
          } else {
            this.response[cfg['repeat$']] = this.response[cfg['repeat$']].concat(json[cfg['repeat$']])
          }
        } else {
          this.response = json
        }
        if (this.workspace.repeat) {
          this.send(this.format(json.service, json, cfg))
        } else {
          this.workspace.finishTime = new Date()
          this.workspace.duration = this.workspace.finishTime.getTime() - this.workspace.initTime.getTime()
          console.log('duration: ' + this.workspace.duration)
          if (this.result) {
            this.result(this.response)
          } else if (this.client) {
            this.client.write(JSON.stringify(this.response))
          }
          delete this.response
        }
      }
      break
    case 'closed':
      this.init()
      break
    }
  }

  // Apply format of service to input data
  format (service, data, cfg) {
    let msg = ''
    if (service) {
      this.sequence++
      msg += service.toUpperCase() + 'T' + this.apply('number:6', this.sequence) + this.requestDate + this.actMonth
    }
    for (const key in cfg) {
      if (!key.includes('$')) {
        const format = cfg[key]
        const value = data[key]
        if (value) {
          if (format.type) {
            const occurss = Number(format.type.split(':')[1])
            for (let index = 0; index < occurss; index++) {
              msg += this.format(undefined, data[key][index], format.item)
            }
          } else {
            msg += this.apply(format, value)
          }
        } else {
          msg += this.apply(format)
        }
      }
    }
    return msg
  }

  // Apply format (<type:length>) to value
  apply (format, value) {
    format = format.split(':')
    const type = format[0]
    let r, size, decimals, dec
    switch (type) {
    case 'string':
      size = Number(format[1])
      r = (value || '') + ' '.repeat(size)
      r = r.substr(0, size)
      break
    case 'number':
      format = format[1].split('.')
      size = Number(format[0])
      decimals = format.length === 2 ? Number(format[1]) : 0
      r = (value || 0) * 1
      if (decimals) {
        r = r * Math.pow(10, decimals)
      }
      r = '0'.repeat(size + decimals) + r
      r = r.substr(r.length - (size + decimals))
      break
    case 'decimal':
      format = format[1].split('.')
      size = Number(format[0])
      decimals = format.length === 2 ? Number(format[1]) : 0
      r = (value || 0) * 1
      dec = '0'.repeat(decimals)
      if (r % 1) { dec = ('' + r).split('.')[1] + '0'.repeat(decimals) }
      dec = dec.substr(0, decimals)
      r = r - r % 1
      r = '0'.repeat(size) + r + '.' + dec
      r = r.substr(r.length - (size + decimals))
      break
    case 'date':
      r = date.format(format[1], value)
      break
    }
    return r
  }

  // Apply service format to output (result)
  parse (result, cfg) {
    const out = {}; let p = 0
    var size
    var decimals
    for (const key in cfg) {
      if (!key.includes('$')) {
        if (cfg[key].split) {
          let format = cfg[key].split(':')
          const type = format[0]
          let value
          switch (type) {
          case 'string':
            size = Number(format[1])
            value = result.substr(p, size)
            p += size
            break
          case 'number':
          case 'decimal':
            format = format[1].split('.')
            size = Number(format[0])
            decimals = format.length === 2 ? Number(format[1]) : 0
            value = result.substr(p, size + decimals).trim()
            if (decimals && !value.includes('.')) {
              value = Number(value) / Math.pow(10, decimals)
            } else {
              value = Number(value)
            }
            p += size + decimals
            break
          case 'date':
            format = format[1]
            value = date.parse(result.substr(p, format.length), format)
            p += format.length
            break
          }
          out[key] = value
        } else if (cfg[key].type) {
          const occurss = Number(cfg[key].type.split(':')[1])
          let width = 0
          for (const i in cfg[key].item) {
            let size = cfg[key].item[i].split(':')
            if (size[1].includes('.')) {
              size = size[1].split('.')
              width += Number(size[0]) + Number(size[1])
            } else {
              width += Number(size[1])
            }
          }
          out[key] = []
          for (let i = 0; i < occurss; ++i) {
            out[key].push(this.parse(result.substr(p, width), cfg[key].item))
            p += width
          }
        }
      }
    }
    return out
  }

  // destroy the socket
  destroy () {
    if (this.unisys) {
      this.unisys.destroy()
      delete this.unisys
    }
    if (this.server) {
      this.server.close()
      delete this.server
    }
  }
}
exports.Server = LincII
