class Server {
  constructor (x, config) {
    this.x = x
    for (const field in config) {
      this[field] = config[field]
    }
  }

  // init must be implemented in descendants
  start (next) {
    console.log('start method not implemented')
  }

  // invoke must be implemented in descendants
  invoke (req) {
    console.log('invoke method not impemented')
  }
}
exports.Server = Server
