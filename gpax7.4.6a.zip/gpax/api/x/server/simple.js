var net = require('net')
var Server = require('./_server').Server

class Simple extends Server {
  start (next) {
    try {
      /*
     * Si el servidor opera en modalidad de transacción y ya tiene una acción asociada busca en la acción si contiene
     * elementos que quien el proceso de conexión
     */
      if (modoTransaccion && accion !== null) {
        /*
       * Si en la acción existe un campo "Servidor", lo asume como el Host destino
       */
        if (!nullOrEmpty(buscarValor(accion, Const.SERVIDOR))) {
          host = buscarValor(accion, Const.SERVIDOR).trim()
        }

        // Si en la acción existe el campo "Puerto", lo asume como el
        // Puerto del Host destino
        if (!nullOrEmpty(buscarValor(accion, Const.PUERTO))) {
          puerto = Integer.parseInt(buscarValor(accion, Const.PUERTO).trim())
        }
      }
      // Crea el Socket y lo conecta
      Logger.write('Servidor ' + nombre + ':', Logger.Severidad.Informacion, logLevel)
      Logger.write(' . Host=[' + host + ']', Logger.Severidad.Informacion, logLevel)
      Logger.write(' . Puerto=[' + puerto + ']', Logger.Severidad.Informacion, logLevel)
      if (ventana !== null && ventana.length() > 0) {
        Logger.write(' . ventana=' + ventana, Logger.Severidad.Informacion, logLevel)
      }
      if (estacion !== null && estacion.length() > 0) {
        Logger.write(' . Estacion=' + estacion, Logger.Severidad.Informacion, logLevel)
      }
      if (usuario !== null && usuario.length() > 0) {
        Logger.write(' . Usuario=' + usuario, Logger.Severidad.Informacion, logLevel)
      }
      if (clave !== null && clave.length() > 0) {
        Logger.write(' . Clave=' + EvaluadorExpresiones.repeat('*', clave.length()), Logger.Severidad.Informacion,
          logLevel)
      }
      conexion = new Socket(host, puerto)
      // Si logra activarlo procede a la negociación
      if (getActivo()) {
        try {
          bInput = conexion.getInputStream()
          bOutput = conexion.getOutputStream()
          if (ebcdic) {
            try {
              input = new BufferedReader(new InputStreamReader(bInput, EBCDIC))
              output = new PrintWriter(new OutputStreamWriter(bOutput, EBCDIC), true)
              charSet = EBCDIC
            } catch (e) {
              input = new BufferedReader(new InputStreamReader(bInput, 'Cp500'))
              output = new PrintWriter(new OutputStreamWriter(bOutput, 'Cp500'), true)
              charSet = 'Cp500'
            }
          } else if (codePage.length() > 0) {
            input = new BufferedReader(new InputStreamReader(bInput, codePage))
            output = new PrintWriter(new OutputStreamWriter(bOutput, codePage), true)
            charSet = codePage
          } else {
            input = new BufferedReader(new InputStreamReader(bInput))
            output = new PrintWriter(new OutputStreamWriter(bOutput), true)
          }
        } catch (e) {
          Logger.write(e, Logger.Severidad.Informacion, logLevel)
          input = new BufferedReader(new InputStreamReader(bInput))
          output = new PrintWriter(new OutputStreamWriter(bOutput), true)
        }
        negociar()
        conexion.setSoTimeout(espera)
      } else {
        conexion.close()
      }
      conexionComprobada = conexion.isConnected()
    } catch (ex) {
      Logger.write(ex, Logger.Severidad.Informacion, logLevel)
      resultado = ex.getMessage()
    }
    return this.getActivo()
  }

  desactivar () {
    try {
      if (conexion !== null) {
        conexion.close()
        conexion = null
        input = null
        output = null
      }
    } catch (ex) {
      resultado = ex.getMessage()
    }
  }

  enviarDatos (m) {
    var r = true
    try {
      if (enviarEOR) {
        output.println(m)
        Logger.write('=>' + new String(m.getBytes(charSet)) + '\r', Logger.Severidad.Informacion, logLevel)
      } else {
        output.print(m)
        output.flush()
        Logger.write('=>' + m.getBytes(charSet), Logger.Severidad.Informacion, logLevel)
      }
    } catch (ex) {
      r = false
      Logger.write(ex.getMessage(), Logger.Severidad.Error, logLevel)
    }
    return r
  }

  enviarMensaje () {
    var r = true
    try {
      longRes = 0
      respuesta = null
      if (accion !== null && conexion !== null && conexion.isConnected()) {
        /*
         * Si no es conexión por transacción purga el Socket antes de enviar el nuevo mensaje para evitar que se asuma
         * un eco como respuesta del mensaje que se enviará
         */
        if (!modoTransaccion) {
          try {
            while (input.ready()) {
              input.read()
            }
          } catch (ex) {
            if (!conexion.isConnected()) {
              this.init()
            }
          }
        }
        /*
       * Envía el mensaje
       */
        if (xml) {
          entrada = DOM.asXML(accion.elements().get(0))
        } else {
          entrada = XUtil.xmlToTrama(accion)
        }
        r = enviarDatos(entrada)
      }
      if (r) {
        resultado = Mensajes.vacio
      } else {
        resultado = Mensajes.timeOutEnviando
      }
    } catch (ex) {
      r = false
      resultado = ex.getMessage()
      for (const i = resultado.indexOf(Const.FIN_REGISTRO); i > 0;) {
        resultado = resultado.substring(i)
        i = resultado.indexOf(Const.FIN_REGISTRO)
      }
    }
    return r
  }

  esError (trama) {
    return false
  }

  extraerCampo (trama, ancho) {
    var s = ''
    if (bytesProcesados < 0) {
      bytesProcesados = 0
    }
    if (bytesProcesados + ancho >= trama.length()) {
      if (bytesProcesados < trama.length()) {
        s = trama.substring(bytesProcesados)
        bytesProcesados = trama.length()
      }
    } else {
      s = trama.substring(bytesProcesados, bytesProcesados + ancho)
      bytesProcesados += ancho
    }
    return s
  }

  filtrarTrama (datos, inicio, longitud) {
    var r = ''
    try {
      Logger.write('Inicio=' + inicio, Logger.Severidad.Error, logLevel)
      Logger.write('Longitud=' + longitud, Logger.Severidad.Error, logLevel)
      Logger.write('Datos=' + new String(datos, inicio, longitud), Logger.Severidad.Error, logLevel)
      r = new String(datos, inicio, longitud)
    } catch (ex) {
      Logger.write(ex, Logger.Severidad.Error, logLevel)
    }
    return r
  }

  finRegistro (penultimo, ultimo) {
    return ultimo === Caracteres.LF
  }

  getActivo () {
    var r
    try {
      r = conexion !== null && conexion.isConnected()
    } catch (ex) {
      r = false
      Logger.write(ex, Logger.Severidad.Error, logLevel)
    }
    return r
  }

  negociar () {
    /*
   * Este método se debe implementar en las subclases que interactuan como terminales virtuales
   */
  }

  recibirRespuesta () {
    var tmp = null
    var rslt = true
    var xmlError = null
    var l = 0
    try {
      conexion.setSoTimeout(espera)
      if (finRegistro) {
        resultado = input.readLine()
        if (xml) {
          try {
            tmp = DOM.parse(resultado)
          } catch (e) {
            Logger.write('Respuesta=' + resultado, Logger.Severidad.ErrorCritico, this.logLevel)
            xmlError = e.getMessage()
          }
        }
      } else {
        var datos = new char[10240]()
        resultado = ''
        try {
          do {
            l = input.read(datos, 0, datos.length)
            if (l > 0) {
              resultado += filtrarTrama(datos, 0, l)
            }
            Logger.write('Bytes=' + resultado.length(), Logger.Severidad.Informacion, logLevel)
            /*
           * Si es xml prueba si el proceso esta completo
           */
            if (xml) {
              try {
                tmp = DOM.parse(resultado)
                break
              } catch (e) {
                xmlError = e.getMessage()
              }
            }
            conexion.setSoTimeout(espera / 100)
          } while (l > 0 && (longTrama === 0 || longTrama > resultado.length()))
        } catch (ex) {
          Logger.write(ex.getLocalizedMessage(), Logger.Severidad.Error, logLevel)
        }
      }
    } catch (ex) {
      Logger.write(ex.getLocalizedMessage(), Logger.Severidad.Error, logLevel)
    }
    /*
   * Si obtuvo algún resultado procede a analizar la respuesta
   */
    if (resultado.length() > 0) {
      try {
        Logger.write('<=' + new String(resultado.getBytes(charSet)), Logger.Severidad.Informacion, logLevel)
      } catch (e) {
        Logger.write(e, Logger.Severidad.Error, logLevel)
      }
      respuesta = DOM.newDocument()
      bytesProcesados = 0
      if (xml) {
        respuesta = null
        errorXml = null
        if (tmp !== null) {
          if (tmp.getRootElement().getName().equals(salida.elements().get(0).getName())) {
            try {
              respuesta = DOM.parse('<' + salida.getName() + '/>')
              respuesta.getRootElement().add(tmp.getRootElement())
            } catch (ex) {
              Logger.write(ex, Logger.Severidad.Error, logLevel)
            }
          } else if (tmp.getRootElement().getName().equals(fallo.elements().get(0).getName())) {
            try {
              errorXml = DOM.parse('<' + fallo.getName() + '/>')
              errorXml.getRootElement().add(tmp.getRootElement())
            } catch (ex) {
              Logger.write(ex, Logger.Severidad.Error, logLevel)
            }
          }
        }
        if (respuesta === null && errorXml === null) {
          try {
            errorXml = DOM.parse('<' + fallo.getName() + '/>')
          } catch (ex) {
            Logger.write(ex, Logger.Severidad.Error, logLevel)
          }
          if (xmlError === null) {
            errorXml.addElement('Mensaje').setText('Respuesta desconocida.')
          } else {
            errorXml.addElement('Mensaje').setText(xmlError)
          }
          errorXml.addElement('Respuesta').setText(resultado)
        }
      } else {
        /*
       * Si el servidor no maneja XML, convierte el resultado en XML (respuesta)
       */
        if (resultado.endsWith(Const.FIN_REGISTRO)) {
          resultado = resultado.substring(0, resultado.length() - 2)
        }
        var resT = resultado
        if (esError(resT)) {
          respuesta = null
          try {
            errorXml = DOM.parse('<?xml version="1.0" encoding="utf-8"?><' + fallo.getName() + '/>')
          } catch (ex) {
            Logger.write(ex, Logger.Severidad.Error, logLevel)
          }
          XUtil.tramaToXml(resT, errorXml.getRootElement(), fallo)
        } else {
          try {
            respuesta = DOM.parse('<?xml version="1.0" encoding="utf-8"?><' + salida.getName() + '/>')
          } catch (ex) {
            Logger.write(ex, Logger.Severidad.Error, logLevel)
          }
          XUtil.tramaToXml(resT, respuesta.getRootElement(), salida)
        }
      }
    } else {
      rslt = false
      if (finRegistro && longRes > 0) {
        resultado = Mensajes.faltaFinRegistro
      } else {
        resultado = Mensajes.timeOutEsperando
      }
    }
    if (!rslt) {
      Logger.write('Rec:' + resultado, Logger.Severidad.Informacion, logLevel)
    }
    return rslt
  }

  reportarError () {
    if (xml) {
      /*
     * MARH: no se borra el contenido de errorXML, pues se definió al recibir la respuesta
     */
      respuesta = null
      if (accion !== null) {
        accion.addAttribute('error', 'true')
      }
      respuesta = null
    } else {
      super.reportarError()
    }
  }

  terminar () {
    this.desactivar ()
  }
}

exports.Server = Simple