var nodemailer = require('nodemailer')
var tags = require('../../utils/tags').tags
var Server = require('./_server').Server
var xml = require('xml2js')
class Util extends Server {
  start (next) {
    if (typeof this.services === 'string') {
      this.services = JSON.parse(this.services)
    }
    try {
      next()
    } catch (err) {
      next(err)
    }
  }
  invoke (req) {
    this.result = req.callback
    if (req.to.toString() !== this.id.toString()) {
    } else {
      var service = this.services[req.service]
      if (typeof service.input === 'string') {
        service.input = JSON.parse(service.input)
      }
      if (typeof service.output === 'string') {
        service.output = JSON.parse(service.output)
      }
      if (service) {
        switch (req.service.toLowerCase()) {
        case 'tospreadsheet':
          this.toSpreadSheet(service, req)
          break
        case 'sendmail':
          this.sendMail(service, req)
          break
        case 'notification':
          this.notification(service, req)
          break
        default:
          break
        }
      } else {
        this.result({ error: 'Service \'' + this.request.service + '\' not found' })
      }
    }
  }
  async toSpreadSheet (cfg, req) {
    var input = req.input
    var content = []

    if (input['data']) {
      input['data'].forEach(function (element, idx, array) {
        var baseData = {
          'styles': [
            [
              'wss1',
              ';#999999;;;;;;;;;;;;;;'
            ],
            [
              'wss2',
              ';;;;;;;;;;;;;;;'
            ],
            [
              'wss3',
              ';#a4c2f4;;;;;;;;;;;;;;'
            ],
            [
              'wss4',
              ';#cccccc;;;;;;bold;;;;;;;;'
            ]
          ],
          'table': {
            'frozenColumns': 0,
            'frozenRows': 0,
            'gridlines': 1,
            'headers': 1
          },
          'data': []
        }
        Object.getOwnPropertyNames(element[0]).forEach(function (val, idx, array) {
          baseData.data.push(
            [
              1,
              idx + 1,
              val,
              'wss4'
            ]
          )
        })
        var i = 2
        for (let y in element) {
          Object.getOwnPropertyNames(element[y]).forEach(function (val, idx, array) {
            baseData.data.push(
              [
                i,
                idx + 1,
                element[y][val],
                ''
              ]
            )
          })
          i++
        }
        content.push({
          name: 'Hoja ' + idx,
          content: baseData
        })
      })
    }

    var SS = {
      _id: this.x.production.newId(),
      name: req.bpi.name + ' -> toSpreadSheet',
      content: JSON.stringify(content),
      type: 'spreadsheet',
      status: 'draft'
    }
    if (input.project && input.project.match(/^[0-9a-fA-F]{24}$/)) {
      SS.project = input.project
    }
    if (input.task && input.task.match(/^[0-9a-fA-F]{24}$/)) {
      SS.task = input.task
    }
    if (input.user && input.user.match(/^[0-9a-fA-F]{24}$/)) {
      SS.actors = [
        {
          user: input.user.id,
          path: 'sent',
          role: 'reviser',
          unit: input.user.unit
        }
      ]
      SS.trigger = 'user'
    } else {
      var sett = await new Promise(resolve => {
        this.x.production.findOne('settings', { _id: 'settings' }, (err, sett) => {
          if (!err) {
            resolve(sett)
          }
        })
      })
      SS.actors = []
      if (sett.rpaUser) {
        SS.actors = [
          {
            user: sett.rpaUser,
            path: 'sent',
            role: 'reviser',
            unit: sett.rpaUnit
          }
        ]
      }
      if (sett.rpaUsers) {
        for (let k in sett.rpaUsers) {
          SS.actors.push({
            user: sett.rpaUsers[k].user,
            path: 'sent',
            role: 'reviser',
            unit: sett.rpaUsers[k].unit
          })
        }
      }
      SS.trigger = 'rpa'
    }
    this.x.production.save('document', SS, (err, result) => {
      if (err) {
        this.result({ error: err })
      } else {
        this.result({ id: SS._id, url: 'document.spreadsheet?_id=' + SS._id })
      }
    })
  }
  async sendMail (cfg, req) {
    var input = req.input
    this.x.production.findOne('settings', { _id: 'settings' }, (err, sett) => {
      if (err) throw err
      if (sett && sett.user && sett.password) {
        var password
        try {
          password = tags.util.Decipher(sett.password)
        } catch (err) {
          password = ''
        }
        let transporter = nodemailer.createTransport({
          host: sett.smtp,
          port: sett.port,
          secure: sett.security === 'ssl' || sett.security === 'tls/ssl', // true for 465, false for other ports
          auth: {
            user: sett.user,
            pass: password
          },
          tls: {
            rejectUnauthorized: false
          }
        })

        let message = {
          from: input.from ? input.from : sett.user,
          to: input.to,
          cc: input.copy,
          bcc: input.blindCopy,
          subject: input.subject,
          html: input.body
        }

        transporter.sendMail(message, (error, info) => {
          if (error) {
            this.result({ error: err })
          } else {
            this.result({ messageId: info.messageId, message: 'Message sent: ' + info.messageId })
          }
        })
      }
    })
  }
  async notification (cfg, req) {
    var input = req.input
    var doc = JSON.parse(JSON.stringify(input))
    doc._id = this.x.production.newId()
    doc.createdAt = new Date()
    if (!doc.actors || !doc.user) {
      doc.actors = []
      var sett = await new Promise(resolve => {
        this.x.production.findOne('settings', { _id: 'settings' }, (err, sett) => {
          if (!err) {
            resolve(sett)
          }
        })
      })
      if (sett.rpaUsers) {
        for (let k in sett.rpaUsers) {
          doc.actors.push({ user: sett.rpaUsers[k].user, seen: 0 })
        }
      }
      if (!doc.user && sett.rpaUser) {
        doc.user = sett.rpaUser
        doc.actors.push({ user: sett.rpaUser, seen: 0 })
      }
    }
    this.x.production.save('notification', doc, (err, result) => {
      if (err) {
        this.result({ error: err })
      } else {
        this.result({ id: doc.document.id, url: doc.path + '?_id=' + doc.document.id })
      }
    })
  }
  xml2js (cfg, req) {
    this.result(new xml.Builder().buildObject(req.input))
  }
  async js2xml (cfg, req) {
    xml.parseString(req.input, (err, object) => {
      if (err) {
        this.result({ error: err })
      } else {
        this.result(object)
      }
    })
  }
  check (data, cfg) {
    if (Object.keys(data).length !== Object.keys(cfg.input).length) {
      return false
    } else {
      for (let key in data) {
        switch (cfg.input[key]) {
        case 'string':
          if (typeof data[key] !== 'string' && !(data[key].toString().match(/^[0-9a-fA-F]{24}$/))) { return false }
          break
        case 'number':
        case 'decimal':
        case 'smallint':
          if (typeof Number(data[key]) !== 'number' && !(isFinite(data[key]))) { return false }
          break
        case 'array':
          if (data[key] && typeof data[key] !== 'object' && data[key].constructor !== Array) { return false }
          break
        case 'object':
          if (data[key] && typeof data[key] !== 'object' && data[key].constructor !== Object) { return false }
          break
        case 'boolean':
          if (typeof data[key] !== 'boolean') { return false }
          break
        case 'date':
          if (!(data[key] instanceof Date)) { return false }
          break
        case 'objectId':
          if (!data[key].toString().match(/^[0-9a-fA-F]{24}$/) && data[key].toLowerCase() !== 'objectid') { return false }
          break
        }
      }
      return true
    }
  }
}

exports.Server = Util