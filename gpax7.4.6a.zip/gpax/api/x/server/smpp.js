var Server = require('./_server').Server

class Smpp extends Server {

}
exports.Server = Smpp