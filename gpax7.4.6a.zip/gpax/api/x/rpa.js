/* eslint-disable no-console */
var tags = require('../utils/tags').tags
var JSONStream = require('JSONStream')
var dateformat = require('dateformat')
/* exported */

exports.RPA = RPA

function RPA () {
  this.list = function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    var keys = {
      'actors.user': req.session.context.user,
      'trigger': 'rpa'
    }
    mongo.find('params', { 'name': 'tag' }, { _id: 1, name: 1, options: 1 }, async (er, tagsDoc) => {
      if (tagsDoc.length > 0) {
        tagsDoc = tagsDoc[0].options
      }

      /* apply filter in parameters */
      if (req.query.filter) {
        let query = {}
        for (let name in req.query.filter) {
          if (req.query.filter[name].length > 0) {
            if (name === 'user') {
              query.actors = { $elemMatch: { user: mongo.toId(req.query.filter.user), path: 'sent', role: 'reviser' } }
            } else if (name === 'tagsname') {
              query.tags = mongo.toId(req.query.filter.tagsname)
            } else if (name === 'name') {
              let text = req.query.filter.name
              if (!text.includes('"') && (text.includes(' ') || text.includes('-') || text.includes('/') || text.includes(':'))) {
                query['$text'] = { $search: '"' + text.replace(/ /g, '" "') + '"' }
              } else {
                query['$text'] = { $search: text }
              }
            } else if (req.query.filter[name] !== 'default') {
              query[name] = req.query.filter[name].indexOf(',') !== -1 ? { $in: req.query.filter[name].split(',') } : new RegExp(req.query.filter[name].replace(/ /g, '.*'), 'i')
            }
          }
        }
        delete query.filterNames
        keys = { $and: [query, keys] }
      }
      var pipeline = []
      pipeline.push({ $match: keys })
      pipeline.push({ $skip: skip })
      pipeline.push({ $limit: limit })
      pipeline.push({ $sort: { _id: -1 } })
      mongo.aggregate('document', pipeline, {}, (err, docs) => {
        if (err) {
          send({ error: err })
        } else {
          var users = []
          for (let i in docs) {
            let doc = docs[i]
            var y = doc.actors.findIndex((x) => {
              if (x) { return x.role !== 'reviser' && x.user && x.user.equals && x.user.equals(req.session.context.user) }
            })
            if (y !== -1) {
              var actual = doc.actors[y]
              doc.actor = { user: doc.actors[y].user, path: actual.role === 'copy' ? 'referred' : actual.path }
            }
            if (!doc.actor) {
              doc.actor = doc.actors[0]
            }
            if (doc.actor && doc.actor.user) users.push(doc.actor.user)
          }
          mongo.toHash('user', {}, { _id: 1, name: 1 }, (er, users) => {
            if (docs) {
              for (let i = 0; i < docs.length; ++i) {
                var tagsId = docs[i].tags
                var usedTags = []
                if (tagsDoc.length > 0 && tagsId && tagsId.length > 0) {
                  for (let t = 0; t < tagsDoc.length; t++) {
                    if (tagsId.length) {
                      for (let o = 0; o < tagsId.length; o++) {
                        if (tagsDoc[t].id && tagsId[o] && tagsDoc[t].id.toString() === tagsId[o].toString()) {
                          usedTags.push(tagsDoc[t])
                        }
                      }
                    } else {
                      if (tagsDoc[t] && tagsId && tagsDoc[t].id.toString() === tagsId.toString()) {
                        usedTags.push(tagsDoc[t])
                      }
                    }
                  }
                }
                var doc = docs[i]
                if (doc.type === 'expense') { doc.status = 'expense' }
                var username
                if (doc.actor) {
                  var actor = doc.actor
                  username = actor.user && mongo.isNativeId(actor.user) && users[actor.user.toString()] ? users[actor.user.toString()].name : actor.user
                } else {
                  if (doc.user) { username = users[doc.user].name } else { username = '' }
                }
                reply.data.push(this.row(doc, req, actor, username, usedTags))
              }
            }
            /* if continue is true, send data */
            if (skip) {
              send(reply)
            } else {
              mongo.count('document', keys, (err, count) => {
                if (!err && count) {
                  reply.total_count = count
                }
                send(reply)
              })
            }
          })
        }
      })
    })
  }

  this.row = function (doc, req, actor, username, usedTags) {
    var issue = {}

    var deadline = {}
    for (let x in doc.dates) {
      if (doc.dates[x].type === 'issue') {
        issue = doc.dates[x]
      } else if (doc.dates[x].type === 'deadline') {
        deadline = doc.dates[x]
      }
    }
    var attachments = 'none'
    if (doc.files && doc.files.length > 0) {
      for (let x in doc.files) {
        if (doc.files[x]) {
          attachments = 'attachment'
        }
      }
    }
    let expired = doc.status === tags.processing && deadline.value && deadline.value.getTime() <= new Date().getTime() ? tags.expired : undefined
    var tagscolor = []
    var tagsname = []
    var filterNames = [usedTags[0] ? usedTags[0].value : '']
    for (let i in usedTags) {
      tagscolor.push(usedTags[i].color)
      tagsname.push(usedTags[i].value)
    }
    var row = {
      id: doc._id.toString(),
      attachments: attachments,
      expired: expired,
      css: expired || doc.status || tags.processing,
      status: doc.status ? doc.status : tags.processing,
      statusName: doc.status,
      role: actor.role,
      user: actor.user ? actor.user : doc.user,
      userName: username,
      sequence: doc.sequence && doc.sequence.text ? doc.sequence.text : '',
      name: doc.name,
      path: actor.path,
      pathName: actor.path,
      issue: issue.value ? tags.util.date2str(issue.value, 'yyyy/mm/dd', tags) : '',
      category: doc.category || '',
      deadline: deadline.value ? tags.util.date2str(deadline.value, 'yyyy/mm/dd', tags) : '',
      tagscolor: tagscolor,
      tagsname: tagsname,
      filterNames: filterNames,
      archived: doc.status && doc.status === 'archived' ? 'archived' : '',
      issued: doc.issued,
      actors: doc.actors,
      date: dateformat(doc._id.getTimestamp(), 'yyyy/mm/dd HH:MM:ss')
    }
    if (doc.type) { row.type = doc.type }
    if (doc.key) { row.key = doc.key }
    if (doc.documental) { row.documental = doc.documental }
    if (doc.bpi) { row.bpi = doc.bpi }
    if (doc.reference) { row.reference = doc.reference }
    return row
  }

  this.logs = function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    // Only bpi with timeStartEvent will be included
    var keys = { $and: [{ 'bp.definitions.process.startEvent.timerEventDefinition': { $exists: 1 } }] }
    if (req.query.filter && req.query.filter.date) {
      if (req.query.filter.date.start) {
        keys.$and.push({ _id: { $gte: mongo.newId(req.query.filter.date.start) } })
      }
      if (req.query.filter.date.end) {
        req.query.filter.date.end.setHours(23, 59, 59)
        keys.$and.push({ _id: { $lte: mongo.newId(req.query.filter.date.end) } })
      }
    }
    var pipeline = []
    pipeline.push({ $match: keys })
    pipeline.push({ $sort: { _id: -1 } })
    pipeline.push({ $skip: skip })
    pipeline.push({ $limit: limit })
    pipeline.push({ $addFields: { node: { $objectToArray: '$nodes' } } })
    pipeline.push({ $addFields: { step: { $arrayElemAt: ['$trace.steps.key', -2] } } })
    pipeline.push({ $addFields: { lastStep: { $filter: { input: '$node', as: 'item', cond: { $eq: ['$$item.k', '$step'] } } } } })
    pipeline.push({ $unwind: '$lastStep' })
    pipeline.push({
      $project: {
        _id: 1,
        name: 1,
        steps: { $size: '$trace.steps' },
        step: {
          $concat: ['$lastStep.v.__typeNode', { $ifNull: ['$lastStep.v._name', ''] }]
        },
        date: { $dateToString: { format: '%Y-%m-%d %H:%M', timezone: '-06:00', date: { $toDate: '$_id' } } }
      }
    })
    mongo.aggregate('bpi', pipeline, {}, (err, docs) => {
      if (err) {
        send({ error: err })
      } else {
        reply.data = docs
        if (skip) {
          send(reply)
        } else {
          mongo.count('bpi', keys, (err, count) => {
            if (!err && count) {
              reply.total_count = count
            }
            send(reply)
          })
        }
      }
    })
  }
  this.settings = function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    // Only bpd with timeStartEvent will be included
    var keys = { $and: [{ type: 'bpd', 'template.json.definitions.process.startEvent.timerEventDefinition': { $exists: 1 } }] }
    if (req.query.filter) {
      if (req.query.filter.status) {
        keys.$and.push({ $or: [{ status: req.query.filter.status }, { status: { $exists: 0 } }] })
      }
      if (req.query.filter.name) {
        keys.$and.push({ name: new RegExp(req.filter.status, 'i') })
      }
    }
    var pipeline = []
    pipeline.push({ $match: keys })
    pipeline.push({ $sort: { _id: -1 } })
    pipeline.push({ $skip: skip })
    pipeline.push({ $limit: limit })
    pipeline.push({ $project: { _id: 1, id: '$_id', name: 1, tags: 1, status: { $ifNull: [ '$status', 'active' ] } } })
    mongo.aggregate('template', pipeline, {}, (err, docs) => {
      if (err) {
        send({ error: err })
      } else {
        reply.data = docs
        if (skip) {
          send(reply)
        } else {
          mongo.count('template', keys, (err, count) => {
            if (!err && count) {
              reply.total_count = count
            }
            send(reply)
          })
        }
      }
    })
  }
}
