var base64 = require('base-64')
var request = require('request')
var xml2js = require('xml2js')
var parser = new xml2js.Parser()

exports.Background = Background
var environments = {
  development: {
    idpUrl: 'https://idp.comprobanteselectronicos.go.cr/auth/realms/rut-stag/protocol/openid-connect/token',
    logout: 'https://idp.comprobanteselectronicos.go.cr/auth/realms/rut-stag/protocol/openid-connect/logout',
    url: 'https://api.comprobanteselectronicos.go.cr/recepcion-sandbox/v1/',
    clientId: 'api-stag'
  },
  production: {
    idpUrl: 'https://idp.comprobanteselectronicos.go.cr/auth/realms/rut/protocol/openid-connect/token',
    logout: 'https://idp.comprobanteselectronicos.go.cr/auth/realms/rut/protocol/openid-connect/logout',
    //url: 'https://api.comprobanteselectronicos.go.cr/recepcion/v1/',
    url: 'https://api-sandbox.comprobanteselectronicos.go.cr/recepcion/v1',
    clientId: 'api-prod'
  }
}

function Background (collection, env) {
  this.collection = collection
  this.app = env.app
  this.status = false
  this.pending = false
  this.delay = 2500
  this.thread = process.env.pm_id || '100'
  this.setDatabase = mongo => {
    if (!this.mongo) {
      this.mongo = mongo
      this.sendPending2atv()
    }
    this.mongo = mongo
  }

  this.sendPending2atv = () => {
    if (!this.pending) {
      this.pending = true
      this.getStatus()
      this.mongo.findN(this.collection,0,500,
        {
          $and: [
            { atv: 'P', thread: this.thread },
            { $or: [{ processDateSend: { $exists: 0 } }, { processDateSend: { $lt: new Date() } }] }
          ]
        }, {}, { company: 1 },
        (err, docs) => {
          if (err || !docs || (docs && docs.length === 0)) {
            this.pending = false
            setTimeout(() => { this.sendPending2atv() }, this.delay * 10)
          } else {
            this.sendNext(docs, 0)
          }
        }
      )
    } else if (!this.status) {
      this.getStatus()
    }
  }
  this.sendNext = (docs, i) => {
    if (i >= docs.length) {
      this.pending = false
      setTimeout(() => { this.sendPending2atv() }, this.delay * 10)
    } else {
      this.sendHacienda(docs[i], this.mongo, this.collection, (err) => {
        if (err) {
          this.sendNext(docs, i + 1)
        } else {
          setTimeout(() => { this.sendNext(docs, i + 1) }, this.delay)
        }
      })
    }
  }
  this.sendHacienda = function (doc, mongo, collect, callback) {
    var ambient = environments[this.app.params.ebillEnvironment==='Produccion'?'production' : 'development']
    var envCompany = ''
    if (this.app.params && this.app.params.ebillEnvironment === 'Produccion') envCompany = 'Produccion'
    else envCompany = 'Pruebas'
    if (doc.fechaDocumento && new Date(doc.fechaDocumento) > new Date()) {
      callback(new Error('Date is bigger'))
    } else if (doc.voucherXml) {
      var xml = base64.decode(doc.voucherXml)
      mongo.findOne('company', { idNum: doc.company, environment: envCompany }, (err, environment) => {
        if (err || !environment) {
          callback(new Error('Company not found'))
        } else {
          sender(this, doc.voucherXml, xml, environment)
        }
      })
    } else {
      callback(new Error('Missing voucherXml'))
    }
    function sender (th, comprobanteXml, xmlStr, environment) {
      parser.parseString(xmlStr, async function (err, result) {
        if (err) throw err
        var token = await th.getToken(doc.company, ambient, environment)
        if (token) {
          try {
            var formData = {}

            if (doc.tipoDocumento === '01') {
              if (doc.Receptor.numeroIdentificacion !== '' && doc.Receptor.tipoIdentificacion !== '' && result.FacturaElectronica.Receptor) {
                formData = {
                  clave: result.FacturaElectronica.Clave[0],
                  fecha: result.FacturaElectronica.FechaEmision[0],
                  emisor: {
                    tipoIdentificacion: result.FacturaElectronica.Emisor[0].Identificacion[0].Tipo[0],
                    numeroIdentificacion: result.FacturaElectronica.Emisor[0].Identificacion[0].Numero[0]
                  },
                  receptor: {
                    tipoIdentificacion: result.FacturaElectronica.Receptor[0].Identificacion[0].Tipo[0],
                    numeroIdentificacion: result.FacturaElectronica.Receptor[0].Identificacion[0].Numero[0]
                  },
                  comprobanteXml: comprobanteXml
                }
              } else {
                formData = {
                  clave: result.FacturaElectronica.Clave[0],
                  fecha: result.FacturaElectronica.FechaEmision[0],
                  emisor: {
                    tipoIdentificacion: result.FacturaElectronica.Emisor[0].Identificacion[0].Tipo[0],
                    numeroIdentificacion: result.FacturaElectronica.Emisor[0].Identificacion[0].Numero[0]
                  },
                  comprobanteXml: comprobanteXml
                }
              }
            }

            if (doc.tipoDocumento === '04') {
              if (doc.Receptor.numeroIdentificacion !== '' && doc.Receptor.tipoIdentificacion !== '' && result.TiqueteElectronico.Receptor) {
                formData = {
                  clave: result.TiqueteElectronico.Clave[0],
                  fecha: result.TiqueteElectronico.FechaEmision[0],
                  emisor: {
                    tipoIdentificacion: result.TiqueteElectronico.Emisor[0].Identificacion[0].Tipo[0],
                    numeroIdentificacion: result.TiqueteElectronico.Emisor[0].Identificacion[0].Numero[0]
                  },
                  receptor: {
                    tipoIdentificacion: result.TiqueteElectronico.Receptor[0].Identificacion[0].Tipo[0],
                    numeroIdentificacion: result.TiqueteElectronico.Receptor[0].Identificacion[0].Numero[0]
                  },
                  comprobanteXml: comprobanteXml
                }
              } else {
                formData = {
                  clave: result.TiqueteElectronico.Clave[0],
                  fecha: result.TiqueteElectronico.FechaEmision[0],
                  emisor: {
                    tipoIdentificacion: result.TiqueteElectronico.Emisor[0].Identificacion[0].Tipo[0],
                    numeroIdentificacion: result.TiqueteElectronico.Emisor[0].Identificacion[0].Numero[0]
                  },
                  comprobanteXml: comprobanteXml
                }
              }
            }

            if (doc.tipoDocumento === '03') {
              if (doc.Receptor.numeroIdentificacion !== '' && doc.Receptor.tipoIdentificacion !== '' && result.NotaCreditoElectronica.Receptor) {
                formData = {
                  clave: result.NotaCreditoElectronica.Clave[0],
                  fecha: result.NotaCreditoElectronica.FechaEmision[0],
                  emisor: {
                    tipoIdentificacion: result.NotaCreditoElectronica.Emisor[0].Identificacion[0].Tipo[0],
                    numeroIdentificacion: result.NotaCreditoElectronica.Emisor[0].Identificacion[0].Numero[0]
                  },
                  receptor: {
                    tipoIdentificacion: result.NotaCreditoElectronica.Receptor[0].Identificacion[0].Tipo[0],
                    numeroIdentificacion: result.NotaCreditoElectronica.Receptor[0].Identificacion[0].Numero[0]
                  },
                  comprobanteXml: comprobanteXml
                }
              } else {
                formData = {
                  clave: result.NotaCreditoElectronica.Clave[0],
                  fecha: result.NotaCreditoElectronica.FechaEmision[0],
                  emisor: {
                    tipoIdentificacion: result.NotaCreditoElectronica.Emisor[0].Identificacion[0].Tipo[0],
                    numeroIdentificacion: result.NotaCreditoElectronica.Emisor[0].Identificacion[0].Numero[0]
                  },
                  comprobanteXml: comprobanteXml
                }
              }
            }

            if (doc.tipoDocumento === '02') {
              if (doc.Receptor.numeroIdentificacion !== '' && doc.Receptor.tipoIdentificacion !== '' && result.NotaDebitoElectronica.Receptor) {
                formData = {
                  clave: result.NotaDebitoElectronica.Clave[0],
                  fecha: result.NotaDebitoElectronica.FechaEmision[0],
                  emisor: {
                    tipoIdentificacion: result.NotaDebitoElectronica.Emisor[0].Identificacion[0].Tipo[0],
                    numeroIdentificacion: result.NotaDebitoElectronica.Emisor[0].Identificacion[0].Numero[0]
                  },
                  receptor: {
                    tipoIdentificacion: result.NotaDebitoElectronica.Receptor[0].Identificacion[0].Tipo[0],
                    numeroIdentificacion: result.NotaDebitoElectronica.Receptor[0].Identificacion[0].Numero[0]
                  },
                  comprobanteXml: comprobanteXml
                }
              } else {
                formData = {
                  clave: result.NotaDebitoElectronica.Clave[0],
                  fecha: result.NotaDebitoElectronica.FechaEmision[0],
                  emisor: {
                    tipoIdentificacion: result.NotaDebitoElectronica.Emisor[0].Identificacion[0].Tipo[0],
                    numeroIdentificacion: result.NotaDebitoElectronica.Emisor[0].Identificacion[0].Numero[0]
                  },
                  comprobanteXml: comprobanteXml
                }
              }
            }

            if (doc.tipoDocumento === '05' || doc.tipoDocumento === '06' || doc.tipoDocumento === '07') {
              formData = {
                clave: doc.clave.split('-')[0],
                fecha: result.MensajeReceptor.FechaEmisionDoc[0],
                emisor: {
                  tipoIdentificacion: doc.tipoEmisor,
                  numeroIdentificacion: result.MensajeReceptor.NumeroCedulaEmisor[0]
                },
                receptor: {
                  tipoIdentificacion: doc.tipoReceptor,
                  numeroIdentificacion: result.MensajeReceptor.NumeroCedulaReceptor[0]
                },
                consecutivoReceptor: result.MensajeReceptor.NumeroConsecutivoReceptor[0],
                comprobanteXml: comprobanteXml
              }
            }

            if (doc.tipoDocumento === '08') {
              formData = {
                clave: result.FacturaElectronicaCompra.Clave[0],
                fecha: result.FacturaElectronicaCompra.FechaEmision[0],
                emisor: {
                  tipoIdentificacion: result.FacturaElectronicaCompra.Emisor[0].Identificacion[0].Tipo[0],
                  numeroIdentificacion: result.FacturaElectronicaCompra.Emisor[0].Identificacion[0].Numero[0]
                },
                receptor: {
                  tipoIdentificacion: result.FacturaElectronicaCompra.Receptor[0].Identificacion[0].Tipo[0],
                  numeroIdentificacion: result.FacturaElectronicaCompra.Receptor[0].Identificacion[0].Numero[0]
                },
                comprobanteXml: comprobanteXml
              }
            }

            if (doc.tipoDocumento === '09') {
              if (doc.Receptor.numeroIdentificacion !== '' && doc.Receptor.tipoIdentificacion !== '' && result.FacturaElectronicaExportacion.Receptor) {
                formData = {
                  clave: result.FacturaElectronicaExportacion.Clave[0],
                  fecha: result.FacturaElectronicaExportacion.FechaEmision[0],
                  emisor: {
                    tipoIdentificacion: result.FacturaElectronicaExportacion.Emisor[0].Identificacion[0].Tipo[0],
                    numeroIdentificacion: result.FacturaElectronicaExportacion.Emisor[0].Identificacion[0].Numero[0]
                  },
                  receptor: {
                    tipoIdentificacion: result.FacturaElectronicaExportacion.Receptor[0].Identificacion[0].Tipo[0],
                    numeroIdentificacion: result.FacturaElectronicaExportacion.Receptor[0].Identificacion[0].Numero[0]
                  },
                  comprobanteXml: comprobanteXml
                }
              } else {
                formData = {
                  clave: result.FacturaElectronicaExportacion.Clave[0],
                  fecha: result.FacturaElectronicaExportacion.FechaEmision[0],
                  emisor: {
                    tipoIdentificacion: result.FacturaElectronicaExportacion.Emisor[0].Identificacion[0].Tipo[0],
                    numeroIdentificacion: result.FacturaElectronicaExportacion.Emisor[0].Identificacion[0].Numero[0]
                  },
                  comprobanteXml: comprobanteXml
                }
              }
            }

            var options = {
              url: ambient.url + 'recepcion',
              json: true,
              body: formData,
              headers: {
                Authorization: 'bearer ' + token.access_token,
                'content-type': 'application/javascript'
              }
            }
            var start = new Date()
            request.post(options, function (err, response) {
              var end = new Date()
              if (err) {
                console.log('send:' + err + ' #' + doc._id + ' [' + ((end.getTime() - start.getTime()) / 1000) + '] ')
                throw err
              }
              if (response.statusCode === 202) {
                mongo.save(
                  collect,
                  {
                    _id: doc._id,
                    processDate: new Date(),
                    ubicacion: response.headers.location,
                    response: '',
                    enviada: true,
                    atv: 'C'
                  },
                  err => {
                    if (err) {
                      callback()
                    } else {
                      callback()
                    }
                  }
                )
              } else if (response.statusCode !== 400) {
                if (token.expires) { console.log('send:' + response.statusCode + ' ' + response.statusMessage + ' #' + doc._id + ' [' + ((end.getTime() - start.getTime()) / 1000) + '] post time:' + start.toISOString() + ' token expires:' + token.expires.toISOString()) }
                var processDateSend = new Date().getTime() + (20 * 1000)
                mongo.save(collection, { _id: doc._id, processDateSend: new Date(processDateSend), response: response.statusCode + ' ' + response.statusMessage }, () => {
                  callback()
                })
              } else {
                mongo.save(
                  collect,
                  {
                    _id: doc._id,
                    processDate: new Date(),
                    response: response.statusCode + ' ' + response.statusMessage,
                    atv: (response.statusCode === 400) ? 'C' : 'E'
                  },
                  err => {
                    if (err) {
                      callback()
                    } else {
                      callback()
                    }
                  }
                )
              }
            })
          } catch (error) {
            callback(error)
          }
        } else {
          var processDateSend = new Date().getTime() + (3600 * 1000)
          mongo.updateAll(collection,
            {
              $and: [
                { atv: 'P', company: doc.company },
                { $or: [{ processDateSend: { $exists: 0 } }, { processDateSend: { $lt: new Date() } }] }
              ]
            },
            { $set: { processDateSend: new Date(processDateSend) } },
            () => {
              callback(new Error('Token blocked'))
            }
          )
        }
      })
    }
  }
  this.getStatus = function () {
    if (!this.status) {
      this.status = true
      this.mongo.findN(
        this.collection,0,500,
        {
          $and: [
            { thread: this.thread },
            {
              $and: [
                {
                  $or: [{ statusHacienda: { $exists: 0 } }, { statusHacienda: 'procesando' }]
                },
                {
                  $or: [{ processDateStatus: { $exists: 0 } }, { processDateStatus: { $lt: new Date() } }]
                }
              ]
            },
            { $or: [{ atv: { $exists: 0 } }, { atv: 'C' }, { response: /400/ }] },
            { voucherXml: { $exists: 1 } }
          ]
        }, {}, { company: 1 },
        (err, docs) => {
          if (err || !docs || (docs && docs.length === 0)) {
            this.status = false
            setTimeout(() => { this.getStatus() }, this.delay * 10)
          } else {
            this.getNext(docs, 0)
          }
        }
      )
    }
  }
  this.getNext = function (docs, i) {
    if (i >= docs.length) {
      this.status = false
      this.getStatus()
    } else {
      this.getHacienda(docs[i], this.mongo, this.collection, (err) => {
        if (err) {
          this.getNext(docs, i + 1)
        } else {
          setTimeout(() => { this.getNext(docs, i + 1) }, this.delay)
        }
      })
    }
  }

  this.getHacienda = function (factura, mongo, collection, callback) {
    var ambient = environments[this.app.params.ebillEnvironment==='Produccion'?'production' : 'development']
    var cedula = factura.company
    if (this.app.params && this.app.params.ebillEnvironment === 'Produccion') var envCompany = 'Produccion'
    else envCompany = 'Pruebas'
    mongo.findOne('company', { idNum: cedula, environment: envCompany }, (err, environment) => {
      if (err || !environment) {
        callback(new Error('Company not found'))
      } else {
        getinvoice(this)
      }

      async function getinvoice (th) {
        var token = await th.getToken(cedula, ambient, environment)
        if (token) {
          // Get status invoice
          var claveNumerica = factura.clave
          var options = {
            json: true,
            url: ambient.url + 'recepcion/' + claveNumerica, // + invoice.key,
            headers: {
              Authorization: 'bearer ' + token.access_token
            }
          }
          var start = new Date()
          request.get(options, (err, response, doc) => {
            var end = new Date()
            if (err) {
              mongo.save(collection,
                {
                  _id: factura._id,
                  statusError: err
                }, () => {
                  callback()
                })
            } else if (doc !== null && response.statusCode === 200) {
              var obj = doc
              var result = Object.keys(obj).map(function (key) {
                return [Number(key), obj[key]]
              })
              var estado = result[2]
              var responseXml = result[3] ? result[3] : result[2]
              responseXml = responseXml[1]
              var processDateStatus = new Date().getTime() + (20 * 1000)
              mongo.save(collection,
                {
                  _id: factura._id,
                  responseXml: responseXml,
                  statusHacienda: estado[1],
                  processDateStatus: new Date(processDateStatus)
                }, () => {
                  callback()
                })
            } else {
              console.log('getStatus:' + response.statusCode + ' ' + response.statusMessage + ' id ' + factura._id + ' [' + ((end.getTime() - start.getTime()) / 1000) + '] ' + end)
              processDateStatus = new Date().getTime() + (3600 * 1000)
              mongo.save(collection, {
                _id: factura._id,
                processDateStatus: new Date(processDateStatus),
                response: response.statusCode + ' ' + response.statusMessage + ' ' + response.headers['X-Error-Cause'],
              }, () => {
                callback()
              })
            }
          })
        } else {
          var processDateStatus = new Date().getTime() + (3600 * 1000)
          mongo.updateAll(collection,
            {
              $and: [
                { atv: 'C', company: cedula },
                { $or: [{ statusHacienda: { $exists: 0 } }, { statusHacienda: 'procesando' }] },
                { $or: [{ processDateStatus: { $exists: 0 } }, { processDateStatus: { $lt: new Date() } }] }
              ]
            },
            { $set: { processDateStatus: new Date(processDateStatus) } },
            () => {
              callback(new Error('Token blocked'))
            }
          )
        }
      }
    })
  }

  this.getToken = async function (cedula, ambient, environment) {
    return new Promise(resolve => {
      this.mongo.findOne('token', { company: cedula }, {}, async (err, tok) => {
        if (err) {
          resolve(false)
        } else {
          var seguir = true
          if (tok && tok.nextTokenDate && tok.nextTokenDate.getTime() > new Date().getTime()) {
            seguir = false
          }
          let refreshed = false
          let now = new Date().getTime()
          if (seguir) {
            if (!tok || (tok && tok.expires_in.getTime() < now + 100000)) {
              var closeToken = false
              if (tok && tok.expires_in.getTime() < now && tok.refresh_expires_in.getTime() > now) {
                await this.closeToken({ client_id: ambient.clientId, refresh_token: tok.token.refresh_token }, cedula)
                closeToken = true
              }
              var form
              if (!closeToken && tok && tok.refresh_expires_in.getTime() > now) {
                form = {
                  grant_type: 'refresh_token',
                  client_id: ambient.clientId,
                  refresh_token: tok.token.refresh_token
                }
                refreshed = true
              } else {
                form = {
                  grant_type: 'password',
                  client_id: ambient.clientId,
                  username: environment.user,
                  password: environment.password,
                  client_secret: '',
                  scope: ''
                }
              }
              request.post({ url: ambient.idpUrl, form: form }, (err, httpResponse, token) => {
                if (err) {
                  console.log('get token error: ' + err + ' company ' + cedula)
                  resolve(false)
                } else {
                  if (httpResponse.statusCode === 200) {
                    var tokens = JSON.parse(token)
                    now = new Date().getTime()
                    const expiresIn = now + (tokens.expires_in * 1000)
                    const refreshExpiresIn = now + (tokens.refresh_expires_in * 1000)
                    var docToken = {
                      creationDate: now,
                      company: cedula,
                      expires_in: new Date(expiresIn),
                      refresh_expires_in: new Date(refreshExpiresIn),
                      token: tokens
                    }
                    docToken.token.expires = docToken.expires_in
                    if (tok && tok._id) {
                      docToken._id = tok._id
                      !refreshed ? docToken.count = tok.count + 1 : docToken.count = tok.count
                    } else {
                      docToken._id = this.mongo.newId()
                      docToken.count = 1
                    }
                    this.mongo.save('token', docToken, () => {
                      console.log('Success get token for company ' + cedula)
                      resolve(docToken.token)
                    })
                  } else {
                    console.log('get token error: ' + httpResponse.statusCode + ' ' + httpResponse.statusMessage + ' company ' + cedula)
                    var nextTokenDate = new Date().getTime() + (3600 * 1000)
                    if (tok && tok._id) {
                      tok.nextTokenDate = new Date(nextTokenDate)
                      this.mongo.save('token', tok, () => {
                        resolve(false)
                      })
                    } else {
                      const newDate = new Date()
                      var obj = {
                        _id: this.mongo.newId(),
                        creationDate: newDate,
                        company: cedula,
                        expires_in: newDate,
                        refresh_expires_in: newDate,
                        nextTokenDate: new Date(nextTokenDate),
                        token: {}
                      }
                      this.mongo.save('token', obj, () => {
                        resolve(false)
                      })
                    }
                  }
                }
              })
            } else {
              tok.token.expires = tok.expires_in
              resolve(tok.token)
            }
          } else {
            resolve(false)
          }
        }
      })
    })
  }

  this.closeToken = async function (options, company) {
    return new Promise(resolve => {
      var env
      if (this.app.params && this.app.params.ebillEnvironment === 'Produccion') env = environments.production
      else env = environments.development
      request.post({ url: env.logout, form: options }, (err, response, token) => {
        if (err) {
          console.log('close token error: ' + err + ' company' + company)
          resolve(false)
        } else {
          if (response.statusCode !== 204) {
            console.log('close token:' + response.statusCode + ' ' + response.statusMessage + ' company' + company)
            resolve(false)
          } else {
            resolve(true)
          }
        }
      })
    })
  }
}
