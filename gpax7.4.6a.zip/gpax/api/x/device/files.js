var fs = require('fs')

exports.files = files

function files (brt) {
  this.brt = brt
  this.x = brt.x
  this.append = function (input, next) {
    fs.appendFile(input.path, input.data, (err) => {
      next({ err: err, result: err ? 'fail' : 'ok' })
    })
  }
  this.exists = function (input, next) {
    fs.exists(input.path, (exists) => {
      next({ result: exists })
    })
  }
  this.remove = function (input, next) {
    fs.unlink(input.path, (err) => {
      next({ err: err, result: err ? 'fail' : 'ok' })
    })
  }
  this.read = function (input, next) {
    fs.readFile(input.path, (err, data) => {
      next({ err: err, data: data })
    })
  }
  this.write = function (input, next) {
    fs.writeFile(input.path, input.data, (err) => {
      next({ err: err, result: err ? 'fail' : 'ok' })
    })
  }
}
