function Parking(config) {
  this.config = { port: "com1|usb2|concentradorIp" };
  this.getInterfaces() {
    return {
      getPlacesFree: {
        output: {
          places: []

        }
      }
    };
  };

  this.getPlacesFree(next){

    next(placesFree);
  };
};
