
class BRT {
  constructor (bpi, brtId) {
    this.bpi = bpi
    this.x = bpi.x
    this.brt = { _id: this.x.production.newId(), brt: this.x.production.toId(brtId) }
  }

  run (input, next) {
    this.x.design.findId('brt', this.brt._id, function (err, brtDoc) {
      if (err) {
        next(err)
      } else {

      }
    })
  }
}
exports.BRT = BRT
