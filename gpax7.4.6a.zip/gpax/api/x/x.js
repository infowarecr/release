var Logger = require('../utils/logger').Logger
var tags = require('../utils/tags').tags
var BPI = require('./bpi').BPI
// Constructor

class X {
  constructor () {
    this.started = false
    this.path=__dirname
  }

  // Start load solution [servers, devices & channels]
  start (designDB, productionDB, next) {
    if (this.started) {
      next()
    } else {
      this.started = true
      this.design = designDB
      this.production = productionDB
      this.logger = new Logger(this.production, tags)
      this.design.find('server', {}, (err, servers) => {
        if (err) {
          next(err)
        } else {
          this.design.toHash('gui', {}, { name: 1 }, (err, guis) => {
            if (guis) {
              this.guis = guis
            }
            if (!err && servers && servers.length > 0) {
              this.servers = {}
              this.loadServer(servers, 0, () => {
                next()
              })
            } else {
              next(err)
            }
          })
        }
      })
    }
  }

  invoke (req, mongo, send) {
    this.start(mongo, mongo, () => {
      var data = { ...req.body, ...req.query }
      new BPI(this,req).play(data, (reply) => {
        if (req.statusCode > 0) {
          send()
        } else {
          send(reply)
        }
      })
    })
  }

  async getGUI (req, mongo, send) {
    var form
    var err = await new Promise(resolve => {
      var keys = req.query ? { _id: this.production.toId(req.query._id) } : req
      this.production.find('tui', keys, (err, doc) => {
        if (err) {
          resolve(err)
        } else {
          form = doc ? doc[0] : null
          resolve()
        }
      })
    })
    if (err) {
      send({ error: err })
    } else {
      send(form)
    }
  }

  async saveGUI (doc, send) {
    await new Promise(resolve => {
      this.production.save('tui', doc, (err, result) => {
        if (!err) {
          resolve(result)
        }
      })
    })
    send()
  }

  stop (next) {
    this.stopChannel(this, Object.keys(this.channels), 0, () => {
      this.stopServer(this, Object.keys(this.servers), 0, () => {
        this.log.disconnect()
        this.design.disconnect()
        delete this.log
        delete this.design
        delete this.channels
        delete this.servers
        next()
      })
    })
  }

  async loadServer (servers, i, next) {
    for (let i in servers) {
      var config = servers[i]
      try {
        var path = this.path + '/server/' + config.type
        var Server = require(path).Server
        var server = new Server(this, config)
        server.start((err) => {
          if (err) {
            console.log('Server ' + config.name + ' error: ' + (err.error ? err.error : err))
          } else {
            console.log('Server '+config.name+ ' started...')
            this.servers[config._id] = server
          }
        })
      } catch (err) {
        console.log('Server ' + config.name + ' error: ' + err)
      }
    }
    next()
  }

  loadDevice (devices, i, next) {
    if (devices.length > i) {
      try {
        var Device = require('./device/' + devices[i].type).Server
        var device = new Device(this, devices[i])
        device.start((err) => {
          if (err) {
            this.logger.log({ error: err })
          } else {
            this.devices[devices[i]._id] = device
          }
          this.loadDevice(devices, i + 1, next)
        })
      } catch (err) {
        this.loadDevice(devices, i + 1, next)
      }
    } else {
      next()
    }
  }

  loadChannel (channels, i, next) {
    if (channels.length > i) {
      try {
        var Channel = require('./channel/' + channels[i].type).Channel
        var channel = new Channel(this, channels[i])
        channel.start((err) => {
          if (err) {
            this.logger.log({ error: err })
          } else {
            this.channels[channel.name] = channel
          }
          this.loadChannel(channels, i + 1, next)
        })
      } catch (err) {
        this.loadChannel(channels, i + 1, next)
      }
    } else {
      next()
    }
  }

  stopChannel (keys, i, next) {
    if (keys.length > i) {
      this.channels[keys[i]].stop(() => {
        next(this, keys, i + 1, next)
      })
    } else {
      next()
    }
  }

  stopServer (keys, i, next) {
    if (keys.length > i) {
      this.servers[keys[i]].stop(() => {
        next(this, i + 1, next)
      })
    } else {
      next()
    }
  }

  trace (req, mongo, send) {
    mongo.findId('bpi', req.query._id, (err, bpi) => {
      if (err) {
        send({ error: err })
      } else {
        var X2JS = require('x2js')
        var x2js = new X2JS()
        if (bpi) bpi.xml = x2js.js2xml(bpi.bp)
        send({ content: bpi })
      }
    })
  }
}
exports.X = X
