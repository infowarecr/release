var app = require('./utils/main')

app.init({
  session: 'mongodb://dev/sessions?replicaSet=gpaxio',
  user: 'mongodb://dev/users?replicaSet=gpaxio',
  notify: 'mongodb://dev/notify?replicaSet=gpaxio',
  log: 'mongodb://dev/logs?replicaSet=gpaxio',
  outlook: 'test.gpax.io',
  logger: 'full',
  host: '127.0.0.1',
  port: process.argv[2] || 8082,
  ebillEnvironment: 'Pruebas'
})
