var app = require('./utils/main')
app.init({
  session: 'mongodb://gpax1/sessions?replicaSet=gpaxio',
  user: 'mongodb://gpax1/support?replicaSet=gpaxio',
  notify: 'mongodb://gpax1/notify?replicaSet=gpaxio',
  log: 'mongodb://gpax1/logs?replicaSet=gpaxio',
  outlook: 'prod.gpax.io',
  logger: 'full',
  host: '127.0.0.1',
  port: process.argv[2] || 8081,
  ebillEnvironment: 'development'
})