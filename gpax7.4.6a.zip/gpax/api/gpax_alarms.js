
var moment = require('moment')
var tags = require('./utils/tags').tags
var nodemailer = require('nodemailer')
var CronJob = require('cron').CronJob
var urlUsers = process.argv[2]
var urlBase = process.argv[3]
if (!urlUsers || urlUsers.length === 0) {
  console.log('Invalid parameters: urlUsers -> expected')
  process.exit()
}
if (!urlBase || urlBase.length === 0) {
  console.log('Invalid parameters: urlBase -> expected')
  process.exit()
}
var Mongo = require('./utils/mongo').Mongo
// var url = 'mongo://dev:27017/';


/// // Cron Probado y funciona cada media noche////////////////////

console.log('Before job instantiation')
let job = new CronJob('0 6 * * *', function () {
  console.log('Running....')
  //run()
})

//alarmas comentarios
let job2 = new CronJob('*/1 * * * *', function () {
  //alarmComment()
})
//job.start()
//job2.start()

async function run () {
  var reminder = new Date().getDay()
  var mongoUsers = new Mongo(urlUsers)
  mongoUsers.distinct('user', 'database', { active: true }, async function (err, databases) {
    if (err) { throw err }
    // probar con gpa7
    //databases = ['mongodb://dev:27017/gpa7']
    //databases = ['mongodb://dev/gpax']
    var today = new Date()
    today = new Date(today.getFullYear(), today.getMonth(), today.getDate())
    console.log('Scanning '+databases.length+' databases...')
    for (let i in databases) {
      let mongo = new Mongo(databases[i])
      var sett = await new Promise(resolve => {
        mongo.findOne('settings', { _id: 'settings' }, async (err, sett) => {
          if (!err) {
            resolve(sett)
          } else {
            resolve(false)
          }
        })
      })
      if (sett && sett.checkNotification && sett.days >= 0) {
        var date
        let reminders = []
        if (sett.days > 0) {
          let days = sett.days
          date = moment()
          do {
            date.add(1, 'days')
            if (date.isoWeekday() !== 6 && date.isoWeekday() !== 7) {
              days = days - 1
            }
          } while (days)
        } else {
          date = moment()
        }
        // var from = moment('2019-07-16', 'YYYY-MM-DD')
        let from = moment(date)
        from.set('hour', 0)
        from.set('minute', 0)
        from.set('second', 0)
        from.set('millisecond', 0)
        var to = moment(date)
        to.set('hour', 23)
        to.set('minute', 59)
        to.set('second', 59)
        to.set('millisecond', 999)
        var notes = await new Promise(resolve => {
          mongo.find('note', { status: 'processing', dates: { $elemMatch: { type: 'deadline', value: { $lt: new Date(to.format('YYYY-MM-DD HH:mm')) } } } }, {}, { _id: 1, status: 1, name: 1, actors: 1 }, (err, notes) => {
            if (!err) {
              resolve(notes)
            } else {
              resolve(false)
            }
          })
        })
        // Tipos mensajes alarmas
        // 1 = 'VENCE'
        // 2 = 'SEGUIMIENTO'
        if (notes) {
          for (let x in notes) {
            let unit = []
            let reminder = {
              _id: mongo.newId(),
              'checkDate': '1',
              'checkPersonalized': '0',
              'checkRepetition': '0',
              'collection': 'note',
              'date': today,
              'description': 'Vence nota en ' + sett.days + ' días',
              'document': notes[x]._id,
              'friday': '0',
              'monday': '0',
              'name': 'Recordatorio vencimiento',
              'repetition': '',
              'saturday': '0',
              'sunday': '0',
              'thursday': '0',
              'tuesday': '0',
              'wednesday': '0',
              actors: []
            }
            for (let l in notes[x].actors) {
              reminder.actors.push({
                user: notes[x].actors[l].user,
                seen: 0,
                role: notes[x].actors[l].role
              })
              if (notes[x].actors[l].role === 'from') {
                reminder.user = notes[x].actors[l].user
              }
              if ((notes[x].actors[l].path === 'sent' || notes[x].actors[l].supervisor === '1') && notes[x].actors[l].unit) {
                unit.push(notes[x].actors[l].unit)
              }
            }
            //await parentsUnits(mongo, unit, reminder)
            reminders.push(reminder)
          }
        }
        var attacheds = await new Promise(resolve => {
          mongo.find('attached', { status: 'processing', dates: { $elemMatch: { type: 'deadline', value: { $lt: new Date(to.format('YYYY-MM-DD HH:mm')) } } } }, {}, { _id: 1, status: 1, name: 1, actors: 1 }, (err, attacheds) => {
            if (!err) {
              resolve(attacheds)
            } else {
              resolve(false)
            }
          })
        })
        if (attacheds) {
          for (let x in attacheds) {
            var unit = []
            let reminder = {
              _id: mongo.newId(),
              'checkDate': '1',
              'checkPersonalized': '0',
              'checkRepetition': '0',
              'collection': 'attached',
              'date': today,
              'description': 'Vence anexo en ' + sett.days + ' días',
              'document': attacheds[x]._id,
              'friday': '0',
              'monday': '0',
              'name': 'Recordatorio vencimiento',
              'repetition': '',
              'saturday': '0',
              'sunday': '0',
              'thursday': '0',
              'tuesday': '0',
              'wednesday': '0',
              actors: []
            }
            for (let l in attacheds[x].actors) {
              reminder.actors.push({
                user: attacheds[x].actors[l].user,
                seen: 0,
                role: attacheds[x].actors[l].role
              })
              if (attacheds[x].actors[l].role==='responsible') {
                reminder.user = attacheds[x].actors[l].user
                unit.push(attacheds[x].actors[l].unit)
              }
              if ((attacheds[x].actors[l].path === 'sent' || attacheds[x].actors[l].supervisor === '1') && attacheds[x].actors[l].unit) {
                unit.push(attacheds[x].actors[l].unit)
              }
            }
            //await parentsUnits(mongo, unit, reminder)
            reminders.push(reminder)
          }
        }
        var commitments = await new Promise(resolve => {
          mongo.find('commitment', { status: { $in: ['accepted', 'returned'] }, dates: { $elemMatch: { type: 'deadline', value: { $lt: new Date(to.format('YYYY-MM-DD HH:mm')) } } } }, {}, { _id: 1, status: 1, name: 1, actors: 1 }, (err, commitments) => {
            if (!err) {
              resolve(commitments)
            } else {
              resolve(false)
            }
          })
        })
        if (commitments) {
          for (let x in commitments) {
            let reminder = {
              _id: mongo.newId(),
              'checkDate': '1',
              'checkPersonalized': '0',
              'checkRepetition': '0',
              'collection': 'commitment',
              'date': today,
              'description': 'Vence anexo en ' + sett.days + ' días',
              'document': commitments[x]._id,
              'friday': '0',
              'monday': '0',
              'name': 'Recordatorio vencimiento',
              'repetition': '',
              'saturday': '0',
              'sunday': '0',
              'thursday': '0',
              'tuesday': '0',
              'wednesday': '0',
              actors: []
            }
            for (let l in commitments[x].actors) {
              if (commitments[x].actors[l].role === 'inCharge' || commitments[x].actors[l].role === 'responsible') {
                reminder.actors.push({
                  user: commitments[x].actors[l].user,
                  seen: 0,
                  role: commitments[x].actors[l].role
                })
                reminder.user = commitments[x].actors[l].user
                if (commitments[x].actors[l].unit) {
                  unit.push(commitments[x].actors[l].unit)
                }
              }
            }
            reminders.push(reminder)
          }
        }
        var commitments2 = await new Promise(resolve => {
          mongo.find('commitment', { status: { $in: ['accepted', 'returned', 'completed'] }, dates: { $elemMatch: { type: 'trackingDate', value: { $lt: new Date(to.format('YYYY-MM-DD HH:mm')) } } } }, {}, { _id: 1, status: 1, name: 1, actors: 1 }, (err, commitments2) => {
            if (!err) {
              resolve(commitments2)
            } else {
              resolve(false)
            }
          })
        })
        if (commitments2) {
          for (let x in commitments2) {
            let reminder = {
              _id: mongo.newId(),
              'checkDate': '1',
              'checkPersonalized': '0',
              'checkRepetition': '0',
              'collection': 'commitment',
              'date': today,
              'description': 'Vence anexo en ' + sett.days + ' días',
              'document': commitments2[x]._id,
              'friday': '0',
              'monday': '0',
              'name': 'Recordatorio seguimiento',
              'repetition': '',
              'saturday': '0',
              'sunday': '0',
              'thursday': '0',
              'tuesday': '0',
              'wednesday': '0',
              'type': 2,
              actors: []
            }
            for (let n in commitments2[x].actors) {
              if (commitments2[x].actors[n]) {
                if (commitments2[x].actors[n].role === 'supervisor') {
                  reminder.actors.push({
                    user: commitments2[x].actors[n].user,
                    seen: 0,
                    role: commitments2[x].actors[n].role
                  })
                  reminder.user = commitments2[x].actors[n].user
                  if (commitments2[x].actors[n].unit) {
                    unit.push(commitments2[x].actors[n].unit)
                  }
                }
              }
            }
            //await parentsUnits(mongo, unit, reminder)
            reminders.push(reminder)
          }
        }
        if (reminders.length) {
          for (let r in reminders) {
            var rem = await new Promise(resolve => {
              mongo.find('reminder', { document: reminders[r].document }, (err, rem) => {
                if (!err) {
                  resolve(rem)
                } else {
                  resolve(false)
                }
              })
            })
            if (rem && !rem.length) {
              await new Promise(resolve => {
                mongo.save('reminder', reminders[r], (err, result) => {
                  if (!err) {
                    resolve(result)
                  } else {
                    resolve(false)
                  }
                })
              })
            }
          }
        }
      }
      // /recordatorios/////////////
      var reminders = await new Promise(resolve => {
        mongo.find('reminder', { done: { $exists: 0 } }, (err, reminders) => {
          if (!err) {
            resolve(reminders)
          } else {
            resolve(false)
          }
        })
      })
      if (reminders) {
        for (var r in reminders) {
          let reminder = reminders[r]
          let path = ''
          switch (reminder.collection) {
          case 'note':
            path = 'note.note'
            break;
          case 'attached':
            path = 'note.attached'
            break;
          case 'commitment':
            path = 'note.commitment'
            break;
          case 'evidence':
            path = 'note.evidence'
            break;
          case 'document':
            path = 'document.document'
            break;
          }
          var doc = await new Promise(resolve => {
            mongo.findId(reminder.collection, reminder.document, (err, doc) => {
              if (!err) {
                resolve(doc)
              } else {
                resolve(false)
              }
            })
          })
          if (doc) {
            if (reminder.checkDate === '1') {
              let now = moment().startOf('minute')
              let dateReminder = moment(reminder.date).startOf('minute')
              if (dateReminder <= now) {
                let alarm = {
                  _id: mongo.newId(),
                  collection: reminder.collection,
                  createdAt: today,
                  dateAlarm: reminder.date,
                  document: {
                    id: doc._id,
                    name: doc.name,
                    status: doc.status
                  },
                  path: path,
                  type: reminder.type || 3,
                  actors: [{
                    user: reminder.user,
                    seen: 0
                  }],
                  user: reminder.user
                }
                if (reminder.actors) {
                  alarm.actors= reminder.actors
                }
                await new Promise(resolve => {
                  mongo.save('alarm', alarm, (err, result) => {
                    if (!err) {
                      resolve(result)
                    } else {
                      resolve(false)
                    }
                  })
                })
                reminder.done = '1'
                await new Promise(resolve => {
                  mongo.save('reminder', reminder, (err, result) => {
                    if (!err) {
                      resolve(result)
                    } else {
                      resolve(false)
                    }
                  })
                })
              }
            }
            if (reminder.checkPersonalized === '1') {
              let now = moment().startOf('day')
              let lastDate = reminder.lastDate ? moment(reminder.lastDate).startOf('day') : ''
              if ((reminder.monday === '1' && now.isoWeekday() !== 1) ||
              (reminder.tuesday === '1' && now.isoWeekday() !== 2) ||
              (reminder.wednesday === '1' && now.isoWeekday() !== 3) ||
              (reminder.thursday === '1' && now.isoWeekday() !== 4) ||
              (reminder.friday === '1' && now.isoWeekday() !== 5) ||
              (reminder.saturday === '1' && now.isoWeekday() !== 6) ||
              (reminder.sunday === '1' && now.isoWeekday() !== 7) && (!lastDate || (lastDate && lastDate !== now))) {
                let alarm = {
                  _id: mongo.newId(),
                  collection: reminder.collection,
                  createdAt: today,
                  dateAlarm: new Date(),
                  document: {
                    id: doc._id,
                    name: doc.name,
                    status: doc.status
                  },
                  path: path,
                  type: 3,
                  actors: [{
                    user: reminder.user,
                    seen: 0
                  }],
                  user: reminder.user
                }
                if (reminder.actors) {
                  alarm.actors= reminder.actors
                }
                await new Promise(resolve => {
                  mongo.save('alarm', alarm, (err, result) => {
                    if (!err) {
                      resolve(result)
                    } else {
                      resolve(false)
                    }
                  })
                })
                reminder.lastDate = new Date()
                await new Promise(resolve => {
                  mongo.save('reminder', reminder, (err, result) => {
                    if (!err) {
                      resolve(result)
                    } else {
                      resolve(false)
                    }
                  })
                })
              }
            }
            if (reminder.checkRepetition === '1') {
              let flag = false
              let now = moment().startOf('day')
              let lastDate = reminder.lastDate ? moment(reminder.lastDate).startOf('day') : ''
              if (reminder.repetition === 'daily' && (!lastDate || (lastDate && lastDate !== now))) {
                flag = true
              }
              if (reminder.repetition === 'weekly' && (!lastDate || (lastDate && lastDate.week() !== now.week()))) {
                flag = true
              }
              if (reminder.repetition === 'monthly' && (!lastDate || (lastDate && lastDate.month() !== now.month()))) {
                flag = true
              }
              if (reminder.repetition === 'annual' && (!lastDate || (lastDate && lastDate.year() !== now.year()))) {
                flag = true
              }
              if (flag) {
                let alarm = {
                  _id: mongo.newId(),
                  collection: reminder.collection,
                  createdAt: today,
                  dateAlarm: new Date(),
                  document: {
                    id: doc._id,
                    name: doc.name,
                    status: doc.status
                  },
                  path: path,
                  type: 3,
                  actors: [{
                    user: reminder.user,
                    seen: 0
                  }],
                  user: reminder.user
                }
                if (reminder.actors) {
                  alarm.actors= reminder.actors
                }
                await new Promise(resolve => {
                  mongo.save('alarm', alarm, (err, result) => {
                    if (!err) {
                      resolve(result)
                    } else {
                      resolve(false)
                    }
                  })
                })
                reminder.lastDate = new Date()
                await new Promise(resolve => {
                  mongo.save('reminder', reminder, (err, result) => {
                    if (!err) {
                      resolve(result)
                    } else {
                      resolve(false)
                    }
                  })
                })
              }
            }
          }

        }
      }
      if (sett && sett.user /* && sett.password  */ && sett.checkEmail === '1') {
        var emails = await new Promise(resolve => {
          mongo.aggregate('alarm', [
            { $match: { createdAt: today, reminder: { $ne: reminder } } },
            { $lookup: { localField: 'actors.user', foreignField: '_id', from: 'user', as: 'user' } },
            { $unwind: '$user' },
            { $match: { 'user.licensedUser': false, 'user.active': true } },
            { $group: { _id: '$user.email', count: { $sum: 1 } } }
          ], {}, (err, emails) => {
            if (!err) {
              resolve(emails)
            } else {
              resolve(false)
            }
          })
        })
        await new Promise(resolve => {
          mongo.updateAll('alarm', { createdAt: today, reminder: { $ne: reminder } }, { $set: { reminder: reminder } }, () => { resolve() })
        })
        // TODO emails.push (settings.copies)
        for (let i in emails) {
          var secure = false
          var password
          var transporter
          try {
            password = tags.util.Decipher(sett.password)
          } catch (err) {
            password = ''
          }
          if (sett.security === 'ssl') { secure = true }

          transporter = nodemailer.createTransport({
            host: sett.smtp,
            port: sett.port,
            secure: secure, // true for 465, false for other ports
            auth: {
              user: sett.user,
              pass: password
            },
            tls: {
              rejectUnauthorized: false
            }
          })

          // setup email data with unicode symbols
          var sendMessage = 'Tienes ' + emails[i].count + ' documentos con recordatorio. Accede a la ventana de alarmas en el GPAX para más información.'
          /* if (sett.sendMessage && sett.sendMessage.length > 0) {
                  sendMessage = sett.sendMessage
                } */
          let message = {
            from: sett.user, // sender address
            to: emails[i]._id, // list of receivers
            // cc: unlicensedCopy, // list of receivers
            subject: 'Recordatorio GPAX', // Subject line
            // text: 'Hello world?', // plain text body
            html: sendMessage + '<span class="h-entry p-name"><a class="u-url" href="' + urlBase + '">GPAX</a></span>⁠&nbsp;' // html body
          }

          // send mail with defined transport object
          transporter.sendMail(message, (error, info) => {
            if (error) {
              console.log(error)
            } else { console.log('Message sent: %s', info.messageId) }
          })
        }
      }
    }
  })
}

var parentsUnits = async (mongoDb, unit, reminder) => {
  while (unit.length) {
    let units = await new Promise(resolve => {
      mongoDb.find('unit', { parent: { $in: unit } }, { _id: 1, actors: 1 }, (err, units) => {
        if (!err) {
          resolve(units)
        } else {
          resolve(false)
        }
      })
    })
    unit = []
    if (units) {
      for (let i in units) {
        unit.push(units[i]._id)
        if (units[i].actors) {
          units[i].actors.forEach(a => {
            if (['manager', 'assistant'].includes(a.type[0])) {
              let actor = reminder.actors.findIndex((x) => {
                return x.user.toString() === a.user.toString()
              })
              if (actor === -1) {
                reminder.actors.push({
                  user: a.user,
                  seen: 0
                })
              }
            }
          })
        }
      }
    }
  }
}

//******************************************************************************* */
// ************Para generar las alarmas de los comentarios urgentes***************
//****************************************************************************** */

async function alarmComment () {
  let today = moment(new Date())
  var reminder = new Date().getDay()
  if ((today.hour() >= 6 && today.hour() <= 17) && (today.isoWeekday() !== 6 && today.isoWeekday() !== 7)) {
    var mongoUsers = new Mongo(urlUsers)
    mongoUsers.distinct('user', 'database', { active: true }, async function (err, databases) {
      if (err) { throw err }
      // probar con gpax
      // databases = ['mongodb://dev/gpax']
      console.log('Scanning ' + databases.length + ' databases...')
      for (let i in databases) {
        let mongo = new Mongo(databases[i])
        var sett = await new Promise(resolve => {
          mongo.findOne('settings', { _id: 'settings' }, async (err, sett) => {
            if (!err) {
              resolve(sett)
            } else {
              resolve(false)
            }
          })
        })
        let minutesAlarm = 30
        if (sett && sett.alarmComment && sett.alarmComment !== '0') minutesAlarm = Number(sett.alarmComment)
        var comments = await new Promise(resolve => {
          mongo.find('comment', { type: '1', 'unread.0': { $exists: 1 }, 'reminder': {$ne: reminder} }, (err, result) => {
            if (!err) {
              resolve(result)
            } else {
              resolve([])
            }
          })
        })
        mongo.updateAll('comment', { type: '1', 'unread.0': { $exists: 1 }, 'reminder': { $ne: reminder } }, {$set: { reminder: reminder}},() => {})
        let arrayAlarms = []
        for (let c in comments) {
          let comment = comments[c]
          if (comment.dateAlarm) {
            var date = moment(comment.dateAlarm)
            let today = new Date().getTime()
            date.add(minutesAlarm, 'minutes')
            if ((today > new Date(date).getTime()) && (date.hour() >= 6 && date.hour() <= 17) && (date.isoWeekday() !== 6 && date.isoWeekday() !== 7)) {
              comment.dateAlarm = new Date()
              await new Promise(resolve => { mongo.save('comment', comment, () => { resolve() }) })
              var existAlarm = await new Promise(resolve => {
                mongo.findOne('alarm', { 'document._id': comment._id }, {}, (err, result) => {
                  if (!err && result) {
                    resolve(result)
                  } else {
                    resolve(false)
                  }
                })
              })
              let alarm = {}
              if (!existAlarm) {
                let actors = []
                for (let u in comment.unread) {
                  actors.push({
                    user: comment.unread[u],
                    seen: 0,
                  })
                }
                comment.id = comment._id
                comment.name = comment.comment
                alarm = {
                  _id: mongo.newId(),
                  collection: 'comment',
                  createdAt: comment.dateAlarm,
                  dateAlarm: comment.dateAlarm,
                  document: comment,
                  path: comment.collection,
                  type: 3,
                  actors: actors,
                  user: comment.user
                }
              } else {
                alarm = existAlarm
                alarm.dateAlarm = comment.dateAlarm
              }
              arrayAlarms.push(alarm)
            }
          }
        }
        if (sett && sett.checkNotification === '1') {
          await new Promise(resolve => { mongo.insertMany('alarm', arrayAlarms, () => { resolve() }) })
        }
        let allEmails = []
        for (let a in arrayAlarms) {
          let alarm = arrayAlarms[a]
          for (let y in alarm.actors) {
            if (alarm.actors[y].seen === 0) {
              await new Promise(resolve => {
                mongo.findId('user', alarm.actors[y].user, (err, doc) => {
                  if (!err) {
                    if (doc && doc.email) allEmails.push(doc)
                    resolve(true)
                  } else {
                    resolve(false)
                  }
                })
              })
            }
          }
        }
        let emails = []
        for (let u in allEmails) {
          let index = emails.findIndex(x => {
            return x.email.toString() === allEmails[u].email.toString()
          })
          if (index === -1) {
            emails.push(allEmails[u])
          }
        }
        for (let i in emails) {
          if (sett && sett.user && sett.checkEmail === '1' || !emails[i].licensedUser) {
            var secure = false
            var password
            var transporter
            try {
              password = tags.util.Decipher(sett.password)
            } catch (err) {
              password = ''
            }
            if (sett.security === 'ssl') { secure = true }

            transporter = nodemailer.createTransport({
              host: sett.smtp,
              port: sett.port,
              secure: secure, // true for 465, false for other ports
              auth: {
                user: sett.user,
                pass: password
              },
              tls: {
                rejectUnauthorized: false
              }
            })

            // setup email data with unicode symbols
            var sendMessage = 'Tiene comentarios urgentes sin leer'
            let message = {
              from: sett.user, // sender address
              to: emails[i].email, // list of receivers
              subject: 'Recordatorio GPAX', // Subject line
              html: sendMessage + ' <span class="h-entry p-name"><a class="u-url" href="' + urlBase + '">GPAX</a></span>⁠&nbsp;' // html body
            }

            // send mail with defined transport object
            await new Promise(resolve => {
              transporter.sendMail(message, (error, info) => {
                if (error) {
                  console.log(error)
                } else { console.log('Message sent: %s', info.messageId) }
                resolve()
              })
            })
          }
        }
      }
    })
  }
}

let jobNew = new CronJob('*/59 * * * *', function (a,b,c,d,e) {
  alarmsNew()
})
jobNew.start()

async function alarmsNew () {
  var mongoUsers = new Mongo(urlUsers)
  mongoUsers.distinct('user', 'database', { active: true }, async function (err, databases) {
    if (err) { throw err }
    // probar con gpax
    databases = ['mongodb://dev/gpax']
    console.log('Scanning ' + databases.length + ' databases...')
    for (let i in databases) {
      let mongo = new Mongo(databases[i])
      var sett = await new Promise(resolve => {
        mongo.findOne('settings', { _id: 'settings' }, async (err, sett) => {
          if (!err) {
            resolve(sett)
          } else {
            resolve(false)
          }
        })
      })
      await new Promise(resolve => {
        mongo.find('user', { }, {}, async (err, users) => {
          if (users && users.length) {
            for (let u in users) {
              let user = users[u]

              if (user.email) {

                /****** Recordatorios de responsables */
                let ownerToday = []
                let ownerSettDays = []
                let ownerDeadline = []

                let ownerReminders = await new Promise(resolve => {
                  mongo.find('reminders', { 'owner.user': user._id, status: 'active' }, {}, async (err, rems) => {
                    if (rems && rems.length) {
                      resolve(rems)
                    } else {
                      resolve([])
                    }
                  })
                })

                for (let i in ownerReminders) {
                  let reminder = ownerReminders[i]
                  if (reminder.date) {
                    let now = new Date()
                    let diff = ''
                    if (sett && sett.days) {
                      //dateSett = moment(reminder.date).subtract(sett.days, 'days')
                      diff = moment(reminder.date).diff(now, 'days')
                      //dateSett = dateSett._d
                    }
                    if ((reminder.date.setHours(0, 0, 0) <= now.getTime()) && (reminder.date.setHours(23, 59, 59) >= now.getTime())) {
                      ownerToday.push(reminder)
                    } else if (sett && (diff <= sett.days) && (diff > 0)) {
                      ownerSettDays.push(reminder)
                    } else if (now.getTime() > reminder.date.setHours(23, 59, 59)) {
                      ownerDeadline.push(reminder)
                    }
                  }
                }

                let html = ''
                if (ownerToday.length || ownerSettDays.length || ownerDeadline.length) {
                  html = '<div> Tiene algunos recordatorios, para ver más detalles haga <span class="h-entry p-name"><a class="u-url" href="' + urlBase + '/#!/home.alarms">Click aqui</a></span> <br></div>'
                }

                if (sett && sett.user && html) {
                  var secure = false
                  var password
                  var transporter
                  try {
                    password = tags.util.Decipher(sett.password)
                  } catch (err) {
                    password = ''
                  }
                  if (sett.security === 'ssl') { secure = true }

                  transporter = nodemailer.createTransport({
                    host: sett.smtp,
                    port: sett.port,
                    secure: secure, // true for 465, false for other ports
                    auth: {
                      user: sett.user,
                      pass: password
                    },
                    tls: {
                      rejectUnauthorized: false
                    }
                  })

                  // setup email data with unicode symbols
                  let message = {
                    from: sett.user, // sender address
                    to: user.email, //'wil512on@gmail.com',// list of receivers
                    subject: 'GPAX Recordatorios', // Subject line
                    html: html
                  }

                  // send mail with defined transport object
                  await new Promise(resolve => {
                    transporter.sendMail(message, (error, info) => {
                      if (error) {
                        console.log(error)
                      } else { console.log('Message sent: %s', info.messageId) }
                      resolve()
                    })
                  })
                }
              }

              /****** recordatorios de departmentManager*/
              /*let departmentManagerDeadline = []

              let departmentManagerReminders = await new Promise(resolve => {
                mongo.find('reminders', { deparmentManager: { $in: [user._id] }, status: 'active' }, {}, async (err, rems) => {
                  if (rems && rems.length) {
                    resolve(rems)
                  } else {
                    resolve([])
                  }
                })
              })

              for (let i in departmentManagerReminders) {
                let reminder = departmentManagerReminders[i]
                if (reminder.date) {
                  let now = new Date()
                  if (now.getTime() > reminder.date.setHours(23, 59, 59)) {
                    departmentManagerDeadline.push(reminder)
                  }
                }
              }

              let html2 = ''
              if (departmentManagerDeadline.length) {
                html2 += '<div>Recordatorio: Los siguientes documentos estan vencidos <br>'
                for (let i in departmentManagerDeadline) {
                  let rem = departmentManagerDeadline[i]
                  let document = await new Promise(resolve => {
                    mongo.findId(rem.type, rem.document, { content: 0 }, (err, doc) => {
                      if (doc) {
                        resolve(doc)
                      } else {
                        resolve('')
                      }
                    })
                  })
                  if (document.name) {
                    html2 += document.name + ' <br>'
                  }
                }
              }

              if (html2) {
                html2 += '</div>'
              }

              if (sett && sett.user && html2) {
                var secure = false
                var password
                var transporter
                try {
                  password = tags.util.Decipher(sett.password)
                } catch (err) {
                  password = ''
                }
                if (sett.security === 'ssl') { secure = true }

                transporter = nodemailer.createTransport({
                  host: sett.smtp,
                  port: sett.port,
                  secure: secure, // true for 465, false for other ports
                  auth: {
                    user: sett.user,
                    pass: password
                  },
                  tls: {
                    rejectUnauthorized: false
                  }
                })

                // setup email data with unicode symbols
                let message = {
                  from: sett.user, // sender address
                  to: '',//emails[i].email, // list of receivers
                  subject: 'Recordatorio GPAX', // Subject line
                  html: html
                }

                // send mail with defined transport object
                await new Promise(resolve => {
                  transporter.sendMail(message, (error, info) => {
                    if (error) {
                      console.log(error)
                    } else { console.log('Message sent: %s', info.messageId) }
                    resolve()
                  })
                })
              }*/

              /****** recordatorios de revisores*/
              /*let reviserToday = []
              let reviserDeadline = []

              let reviserReminders = await new Promise(resolve => {
                mongo.find('reminders', { 'reviewer.user': user._id , status: 'active' }, {}, async (err, rems) => {
                  if (rems && rems.length) {
                    resolve(rems)
                  } else {
                    resolve([])
                  }
                })
              })

              for (let i in reviserReminders) {
                let reminder = reviserReminders[i]
                if (reminder.date) {
                  let now = new Date()
                  if ((reminder.date.setHours(0, 0, 0) <= now.getTime()) && (reminder.date.setHours(23, 59, 59) >= now.getTime())) {
                    reviserToday.push(reminder)
                  } else if (now.getTime() > reminder.date.setHours(23, 59, 59)) {
                    reviserDeadline.push(reminder)
                  }
                }
              }

              let html3 = ''
              if (reviserToday.length) {
                html3 += '<div> Recordatorio: Los siguientes documentos vencen hoy <br>'
                for (let i in reviserToday) {
                  let rem = reviserToday[i]
                  let document = await new Promise(resolve => {
                    mongo.findId(rem.type, rem.document, { content: 0 }, (err, doc) => {
                      if (doc) {
                        resolve(doc)
                      } else {
                        resolve('')
                      }
                    })
                  })
                  if (document.name) {
                    html3 += document.name + ' <br>'
                  }
                }
              }

              if (reviserDeadline.length) {
                html3 += 'Recordatorio: Los siguientes documentos estan vencidos <br>'
                for (let i in reviserDeadline) {
                  let rem = reviserDeadline[i]
                  let document = await new Promise(resolve => {
                    mongo.findId(rem.type, rem.document, { content: 0 }, (err, doc) => {
                      if (doc) {
                        resolve(doc)
                      } else {
                        resolve('')
                      }
                    })
                  })
                  if (document.name) {
                    html3 += document.name + ' <br>'
                  }
                }
              }

              if (html3) {
                html3 += '</div>'
              }

              if (sett && sett.user && html3) {
                var secure = false
                var password
                var transporter
                try {
                  password = tags.util.Decipher(sett.password)
                } catch (err) {
                  password = ''
                }
                if (sett.security === 'ssl') { secure = true }

                transporter = nodemailer.createTransport({
                  host: sett.smtp,
                  port: sett.port,
                  secure: secure, // true for 465, false for other ports
                  auth: {
                    user: sett.user,
                    pass: password
                  },
                  tls: {
                    rejectUnauthorized: false
                  }
                })

                // setup email data with unicode symbols
                let message = {
                  from: sett.user, // sender address
                  to: '',//emails[i].email, // list of receivers
                  subject: 'Recordatorio GPAX', // Subject line
                  html: html
                }

                // send mail with defined transport object
                await new Promise(resolve => {
                  transporter.sendMail(message, (error, info) => {
                    if (error) {
                      console.log(error)
                    } else { console.log('Message sent: %s', info.messageId) }
                    resolve()
                  })
                })
              }*/

              /****** recordatorios de supervisores*/
              /*let supervisorDeadline = []

              let supervisorReminders = await new Promise(resolve => {
                mongo.find('reminders', { 'supervisor.user': user._id , status: 'active' }, {}, async (err, rems) => {
                  if (rems && rems.length) {
                    resolve(rems)
                  } else {
                    resolve([])
                  }
                })
              })

              for (let i in supervisorReminders) {
                let reminder = supervisorReminders[i]
                if (reminder.date) {
                  let now = new Date()
                  if (now.getTime() > reminder.date.setHours(23, 59, 59)) {
                    supervisorDeadline.push(reminder)
                  }
                }
              }

              let html4 = ''
              if (supervisorDeadline.length) {
                html4 += '<div>Recordatorio: Los siguientes documentos estan vencidos <br>'
                for (let i in supervisorDeadline) {
                  let rem = supervisorDeadline[i]
                  let document = await new Promise(resolve => {
                    mongo.findId(rem.type, rem.document, { content: 0 }, (err, doc) => {
                      if (doc) {
                        resolve(doc)
                      } else {
                        resolve('')
                      }
                    })
                  })
                  if (document.name) {
                    html4 += document.name + ' <br>'
                  }
                }
              }

              if (html4) {
                html4 += '</div>'
              }

              if (sett && sett.user && html4) {
                var secure = false
                var password
                var transporter
                try {
                  password = tags.util.Decipher(sett.password)
                } catch (err) {
                  password = ''
                }
                if (sett.security === 'ssl') { secure = true }

                transporter = nodemailer.createTransport({
                  host: sett.smtp,
                  port: sett.port,
                  secure: secure, // true for 465, false for other ports
                  auth: {
                    user: sett.user,
                    pass: password
                  },
                  tls: {
                    rejectUnauthorized: false
                  }
                })

                // setup email data with unicode symbols
                let message = {
                  from: sett.user, // sender address
                  to: '',//emails[i].email, // list of receivers
                  subject: 'Recordatorio GPAX', // Subject line
                  html: html
                }

                // send mail with defined transport object
                await new Promise(resolve => {
                  transporter.sendMail(message, (error, info) => {
                    if (error) {
                      console.log(error)
                    } else { console.log('Message sent: %s', info.messageId) }
                    resolve()
                  })
                })
              }*/

            }

            /*if (sett && sett.user) {
              var secure = false
              var password
              var transporter
              try {
                password = tags.util.Decipher(sett.password)
              } catch (err) {
                password = ''
              }
              if (sett.security === 'ssl') { secure = true }

              transporter = nodemailer.createTransport({
                host: sett.smtp,
                port: sett.port,
                secure: secure, // true for 465, false for other ports
                auth: {
                  user: sett.user,
                  pass: password
                },
                tls: {
                  rejectUnauthorized: false
                }
              })

              // setup email data with unicode symbols
              let message = {
                from: sett.user, // sender address
                to: '',//emails[i].email, // list of receivers
                subject: 'Recordatorio GPAX', // Subject line
                html: ''//html
              }

              // send mail with defined transport object
              await new Promise(resolve => {
                transporter.sendMail(message, (error, info) => {
                  if (error) {
                    console.log(error)
                  } else { console.log('Message sent: %s', info.messageId) }
                  resolve()
                })
              })
            }*/

            resolve()
          } else {
            resolve()
          }
        })
      })
    }
  })
}

