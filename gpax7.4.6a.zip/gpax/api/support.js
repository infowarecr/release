var app = require('./utils/main')
var os = require('os')
app.init({
  session: 'mongodb://dev/sessions',
  user: 'mongodb://dev/support',
  log: 'mongodb://dev/logs',
  notify: 'mongodb://dev/notify',
  background: 'mongodb://dev/ebill',
  outlook: os.hostname(),
  logger: 'full',
  port: process.argv[2] || 8081
})
