var app = require('./utils/main')
var os = require('os')
app.init({
  session: 'mongodb://mongo,mongo2,mongo3/sessions?replicaSet=gpaxio',
  user: 'mongodb://mongo,mongo2,mongo3/users?replicaSet=gpaxio',
  notify: 'mongodb://mongo,mongo2,mongo3/notify?replicaSet=gpaxio',
  log: 'mongodb://mongo,mongo2,mongo3/logs?replicaSet=gpaxio',
  outlook: os.hostname(),
  logger: 'full',
  host: 'localhost',
  port: 8082
})
