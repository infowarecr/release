
var X = require('./x/x').X
var CronJob = require('cron').CronJob
var Mongo = require('./utils/mongo').Mongo
var events = {}
var url = process.argv.length > 2 ? process.argv[2] : 'mongodb://127.0.0.1:27017/gpax'
async function scheduleEvents () {
  var x = new X()
  var mongo = new Mongo(url)
  await new Promise(resolve => {
    mongo.find('bpd', { 'bp.json.definitions.process.startEvent.timerEventDefinition': { $exists: 1 } }, async (err, bpds) => {
      if (err) {
        console.log(err)
        resolve()
      } else if (bpds && bpds.length > 0) {
        for (const i in bpds) {
          const bpd = bpds[i]
          let startEvents = []
          if (!bpd.bp.json.definitions.process.startEvent.length) {
            startEvents.push(bpd.bp.json.definitions.process.startEvent)
          } else {
            startEvents = bpd.bp.json.definitions.startEvent
          }
          for (const j in startEvents) {
            const startEvent = startEvents[j]
            if (startEvent.timerEventDefinition) {
              let startString = ''
              if (startEvent._seconds !== 'no') {
                startString = startEvent._seconds + ' '
              }
              startString += startEvent._minutes
              startString += ' ' + startEvent._hours
              startString += ' ' + startEvent._days
              startString += ' ' + startEvent._months
              startString += ' ' + startEvent._weekDays
              const id = bpd._id.toString()
              if (!events[id] || events[id].startString !== startString) {
                if (events[id]) {
                  events[id].job.stop()
                }
                const req = { body: { bpd: bpd._id, key: startEvent._id } }
                // const job = new CronJob(startString, function () {
                req.body.date = new Date()
                x.invoke(req, mongo, (reply) => {
                  console.log(bpd.name + ' -> ' + JSON.stringify(reply))
                })
                // })
                // job.start()
                //events[id] = { startString: startString, job: job }
              }
            }
          }
        }
        resolve()
      }
    })
  })
  /* await new Promise(resolve => {
    mongo.find('plan', { type: 'processing', indicators: { $exists: 1 } }, async (err, plans) => {
      if (err) {
        console.log(err)
        resolve()
      } else if (plans && plans.length > 0) {
        for (const i in plans) {
          const plan = plans[i]
          for (var r in plan.indicators) {
            var indicator = plan.indicators[r]
            if (indicator.collection && indicator.script) {
              let script = JSON.stringify(indicator.script).replace(/#/g, '$')
              script = JSON.parse(script)
              indicator.script = script
              await new Promise(resolve => {
                mongo.aggregate(indicator.collection, indicator.script, (err, result) => {
                  if (err) {
                    console.log(err)
                    resolve()
                  } else {
                    // salvar resultado en indicador plan...
                    if (result.count) {
                      indicator.result = result.count
                    }
                    resolve()
                  }
                })
              })
            }
          }
          var g = plan.indicators
          // salvar plan con indicadores modificados
          await new Promise(resolve => {
            mongo.save('plan', { _id: plan._id, indicators: plan.indicators }, (err, result) => {
              if (err) {
                console.log(err)
                resolve()
              } else {
                resolve()
              }
            })
          })
        }
        resolve()
      }
    })
  }) */
  // Each minute search for changes in database for update scheduler
  setTimeout(() => { scheduleEvents() }, 60000)
  // indicadores
  // currencyValue
}

scheduleEvents()
