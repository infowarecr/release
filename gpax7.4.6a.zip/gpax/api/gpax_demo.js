var app = require('./utils/main')
app.init({
  session: 'mongodb://127.0.0.1/sessions',
  user: 'mongodb://127.0.0.1/users',
  notify: 'mongodb://127.0.0.1/notify',
  log: 'mongodb://127.0.0.1/logs',
  background: 'mongodb://127.0.0.1/ebill',
  outlook: 'demo.gpax.io',
  logger: 'basic',
  port: process.argv[2] || 8072,
  ebillEnvironment: 'Pruebas'
})
