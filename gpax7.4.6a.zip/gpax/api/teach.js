var app = require('./utils/main')
app.init({
  session: 'mongodb://10.0.0.1:27017/sessions',
  user: 'mongodb://10.0.0.1:27017/users',
  log: 'mongodb://10.0.0.1:27017/logs',
  notify: 'mongodb://10.0.0.1:27017/notify',
  logger: 'full',
  port: 8083
})
