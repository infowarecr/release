var Mongo = require('./utils/mongo').Mongo
var fs = require('fs')
var { EJSON } = require('bson')
var moment = require('moment')
var urlMongo = process.argv[2]
if (!urlMongo || urlMongo.length === 0) {
  console.log('Invalid parameters: urlMongo -> expected')
  process.exit()
}
runRestore()
async function runRestore() {
  let mongo = new Mongo(urlMongo)
  let databases = fs.readdirSync(__dirname + '/backup')
  for (let i in databases) {
    if (!databases[i].includes('databases.txt')) {
      let dbMongo = new Mongo(urlMongo.replace('restore', databases[i]))
      var docs = await new Promise(resolve => {
        mongo.find(databases[i], {}, {}, { _id: -1 }, (err, docs) => {
          if (!err) {
            resolve(docs)
          } else {
            resolve(false)
          }
        })
      })
      let dir = __dirname + '/backup/' + databases[i]
      let files = fs.readdirSync(dir).sort(function (a, b) {
        return fs.statSync(dir + '/' + a).mtime.getTime() -
          fs.statSync(dir + '/' + b).mtime.getTime()
      })
      if (docs && docs[0]) {
        let lastFileDate = moment(docs[0].lastFile.replace('.txt', ''), 'YYYYMMDD')._d
        if (files) {
          for (let f in files) {
            if (!files[f].includes('control')) {
              let date = moment(files[f].replace('.txt', ''), 'YYYYMMDD')._d
              if (lastFileDate < date) {
                if (fs.existsSync(__dirname + '/backup/' + databases[i] + '/' + files[f])) {
                  await readFile(__dirname + '/backup/' + databases[i] + '/' + files[f], dbMongo, mongo, files[f])
                }
              }
            }
          }
        }
        process.exit(0)
      } else {
        for (const f in files) {
          if (!files[f].includes('control')) {
            await readFile(dir + '/' + files[f], dbMongo, mongo, files[f])
          }
        }
        process.exit(0)
      }
    }
  }
}
async function readFile(path, dbMongo, mongo, filename) {
  //await new Promise(resolveEnd => {
  var lastLine = ''
  var lineReader = require('readline').createInterface({
    input: require('fs').createReadStream(path)
  })

  for await (const line of lineReader) {
    // Each line in the readline input will be successively available here as
    // `line`.
    let row = EJSON.parse(line, { relaxed: false })
    lastLine = row
    switch (row.operationType) {
      case 'insert':
        await new Promise(resolve => {
          dbMongo.insertMany(row.ns.coll, [row.fullDocument], (err, result) => {
            if (!err) {
              resolve(result)
            } else {
              resolve(false)
            }
          })
        })
        break
      case 'delete':
        await new Promise(resolve => {
          dbMongo.deleteOne(row.ns.coll, { _id: row.documentKey._id }, (err, result) => {
            if (!err) {
              resolve(result)
            } else {
              resolve(false)
            }
          })
        })
        break
      case 'update':
        let doc = {}
        if (!Array.isArray(row.updateDescription.updatedFields)) {
          doc.$set = row.updateDescription.updatedFields
        }
        if (Array.isArray(row.updateDescription.removedFields) && row.updateDescription.removedFields.length) {
          doc.$unset = row.updateDescription.removedFields
        }
        await new Promise(resolve => {
          dbMongo.update(row.ns.coll, { _id: row.documentKey._id }, doc, (err, result) => {
            if (!err) {
              resolve(result)
            } else {
              resolve(false)
            }
          })
        })
        break
    }
  }

  await new Promise(resolve => {
    mongo.save(dbMongo.dbname, {
      _id: mongo.newId(),
      token: lastLine._id._data,
      lastFile: filename
    }, (err, result) => {
      if (!err) {
        resolve(result)
      } else {
        resolve(false)
      }
    })
  })
}

/* {
  "_id": {
    "_data": "826196C3AF000000012B022C0100296E5A1004B9B4BA9C5449497694F3D73198F3983446645F696400645FAC522B79E97C044CBA15D10004"
  },
  "operationType": "update",
    "clusterTime": "7032023024572301313",
    "ns": {
    "db": "gpax",
      "coll": "document"
  },
  "documentKey": {
    "_id": "5fac522b79e97c044cba15d1"
  },
  "updateDescription": {
    "updatedFields": { "actor": { "user": "5f7b93e0e9302005df00c09a", "path": "sent", "role": "reviser", "unit": "5bd5b75ecd60684b31df87ab" }, "content": "<div style=\"text-align: center;\"><strong>Cédula de riesgo</strong></div><br>Con el fin de poder estandarizar el calculo de los riesgos del este proyecto se requiere el uso de la cédula de riesgos adjunta. Tome en cuenta que los riesgos se clasifican en tres categorias: Alto-Medio y Bajo. Una vez obtenido el resultado de la cedula de riesgo analice los riesgo relevantes y verifique su evaluación.<br><br><a class=\"fr-file\" href=\"/api/file.get?_id=5f973475e9302005df00c6d0&type=xlsx\" target=\"_blank\">Hoja de cálculo en LegajoAntilavadoDinero.xlsx</a><br><br><br>", "copy": "[]", "dates": [{ "type": "issue", "value": "2021-11-18T21:20:47.784Z" }], "proj": { "_id": "5fa9a6aa77ee252b9545c488", "name": "Antilavado PSM correcto" }, "status": "reviewed", "to": "[]", "userName": "Shirley Varela" },
    "removedFields": []
  }
} */