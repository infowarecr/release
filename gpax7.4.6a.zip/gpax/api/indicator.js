var moment = require('moment')
var ObjectId = require('mongodb').ObjectID

class Indicator {
  // Número de Auditorías realizadas/Total de auditorías planeadas
  // Horas de la auditoría real Vs Horas de la auditoría presupuestada
  plannedReal (req, mongo, send) {
    let pipeline = []
    if (req.query._id) {
      pipeline.push({
        $match: {
          plan: mongo.toId(req.query._id)
        }
      })
    }
    pipeline = pipeline.concat([{
      $lookup: {
        from: 'task',
        localField: '_id',
        foreignField: 'project',
        as: 'tasks'
      }
    },
    {
      $unwind: {
        path: '$tasks',
        preserveNullAndEmptyArrays: true
      }
    },
    {
      $match: {
        'tasks.type': 'task'
      }
    },
    {
      $group: {
        _id: '$_id',
        status: {
          $first: '$status'
        },
        duration: {
          $sum: {
            $toDouble: {
              $cond: [{
                $eq: ['$tasks.duration', '']
              }, 0, '$tasks.duration']
            }
          }
        }
      }
    },
    {
      $lookup: {
        from: 'time',
        localField: '_id',
        foreignField: 'project',
        as: 'time'
      }
    },
    {
      $unwind: {
        path: '$time',
        preserveNullAndEmptyArrays: true
      }
    },
    {
      $lookup: {
        from: 'user',
        localField: 'time.user',
        foreignField: '_id',
        as: 'user'
      }
    },
    {
      $unwind: {
        path: '$user',
        preserveNullAndEmptyArrays: true
      }
    },
    {
      $group: {
        _id: '$_id',
        status: {
          $first: '$status'
        },
        planeado: {
          $first: '$duration'
        },
        real: {
          $sum: {
            $toDouble: {
              $cond: [{
                $eq: ['$time.duration', '']
              }, 0, {
                $divide: [{
                  $toDouble: '$time.duration'
                }, 60]
              }]
            }
          }
        }
      }
    },
    {
      $group: {
        _id: null,
        plan: {
          $sum: {
            $toDouble: {
              $cond: [{
                $eq: ['$planeado', '']
              }, 0, {
                $divide: [{
                  $toDouble: '$planeado'
                }, 60]
              }]
            }
          }
        },
        real: {
          $sum: '$real'
        },
        planned: {
          $sum: 1
        },
        completed: {
          $sum: {
            $cond: {
              if: {
                $in: ['$status', ['completed', 'reviewed', 'archived']]
              },
              then: 1,
              else: 0
            }
          }
        }
      }
    },
    {
      $project: {
        plan: {
          $round: ['$plan', 2]
        },
        real: {
          $round: ['$real', 2]
        },
        planned: 1,
        completed: 1
      }
    }
    ])
    mongo.aggregate('project', pipeline, {}, (err, docs) => {
      if (err) {
        console.log(err)
        send({})
      } else {
        const result = docs[0] || {
          planned: 0,
          completed: 0,
          real: 1,
          plan: 0
        }
        send([
          [{
            value: result.planned - result.completed,
            total: result.planned,
            title: 'Pendientes'
          },
          {
            value: result.completed,
            total: result.planned,
            title: 'Completados'
          }
          ],
          [{
            value: result.real,
            total: result.plan,
            title: 'Reales',
            color: '#b4e5fb'
          },
          {
            value: result.plan,
            total: result.plan,
            title: 'Presupuestadas',
            color: '#47c6b9'
          }
          ]
        ])
      }
    })
  }

  // horas por Departamento
  departmentHours (req, mongo, send) {
    const keys = {
      status: {
        $ne: 'draft'
      }
    }
    if (req.query._id) {
      keys.plan = mongo.toId(req.query._id)
    }
    mongo.find('project', keys, {
      status: 1,
      duration: 1,
      unit: 1
    }, {}, async (err, docs) => {
      if (err) {
        console.log(err)
        send({})
      } else {
        const array = []
        const workDay = req.session.context.workDay
        for (const i in docs) {
          let real = 0
          if (docs[i].duration && docs[i].duration !== '') {
            let index = -1
            for (const a in array) {
              if (array[a][docs[i].unit.toString()]) {
                index = a
                break
              }
            }
            if (index === -1 && docs[i].unit) {
              const nameUnit = await new Promise(resolve => {
                mongo.findId('unit', docs[i].unit, {
                  name: 1
                }, (err, result) => {
                  if (err) {
                    console.log(err)
                    resolve('')
                  } else {
                    resolve(result.name)
                  }
                })
              })
              array.push({
                [docs[i].unit]: {
                  unit: docs[i].unit.toString(),
                  name: nameUnit,
                  planned: 0,
                  real: 0
                }
              })
            }
            const times = await new Promise(resolve => {
              mongo.find('time', {
                project: mongo.toId(docs[i]._id)
              }, {}, {}, (err, times) => {
                if (err) {
                  console.log(err)
                  resolve([])
                } else {
                  resolve(times)
                }
              })
            })
            for (const t in times) {
              real = real + parseFloat(times[t].duration || 0)
            }
            if (index !== -1) {
              array[index][docs[i].unit.toString()].real += real
              array[index][docs[i].unit.toString()].planned += parseFloat(docs[i].duration)
            } else {
              array[array.length - 1][docs[i].unit.toString()].real += real
              array[array.length - 1][docs[i].unit.toString()].planned += parseFloat(docs[i].duration)
            }
          }
        }
        for (const a in array) {
          for (const u in array[a]) {
            if (array[a][u].real) {
              array[a][u].real = array[a][u].real / workDay
            }
          }
        }
        send(array)
      }
    })
  }

  // horas por Auditor
  auditorHours (req, mongo, send) {
    const keys = {
      status: {
        $ne: 'draft'
      }
    }
    if (req.query._id) {
      keys.plan = mongo.toId(req.query._id)
    }
    mongo.find('project', keys, {
      status: 1,
      duration: 1,
      actors: 1,
      content: 1
    }, {}, async (err, docs) => {
      if (err) {
        console.log(err)
        send({})
      } else {
        const array = []
        for (const i in docs) {
          let real = 0
          if (docs[i].duration && docs[i].duration !== '') {
            for (const c in docs[i].actors) {
              let index = -1
              for (const a in array) {
                if (array[a][docs[i].actors[c].user.toString()]) {
                  index = a
                  break
                }
              }
              if (index === -1) {
                const user = await new Promise(resolve => {
                  mongo.findId('user', docs[i].actors[c].user, {
                    name: 1,
                    business: 1
                  }, (err, result) => {
                    if (err || !result) {
                      console.log(err)
                      resolve('')
                    } else {
                      resolve({
                        name: result.name,
                        business: result.business || ''
                      })
                    }
                  })
                })
                array.push({
                  [docs[i].actors[c].user]: {
                    user: docs[i].actors[c].user.toString(),
                    name: user.name,
                    workDay: user.business && user.business !== '' ? parseFloat(user.business.workDay) : 8,
                    planned: 0,
                    real: 0
                  }
                })
              }
              let planned = 0
              if (docs[i].content && docs[i].content.data) {
                for (const p in docs[i].content.data) {
                  if (docs[i].content.data[p].owner_id && docs[i].content.data[p].owner_id.toString() === docs[i].actors[c].user.toString()) {
                    planned = planned + docs[i].content.data[p].duration || 0
                  }
                }
              }
              const times = await new Promise(resolve => {
                mongo.find('time', {
                  project: mongo.toId(docs[i]._id),
                  user: mongo.toId(docs[i].actors[c].user)
                }, {}, {}, (err, times) => {
                  if (err) {
                    console.log(err)
                    resolve([])
                  } else {
                    resolve(times)
                  }
                })
              })
              for (const t in times) {
                real = real + parseFloat(times[t].duration || 0)
              }
              if (index !== -1) {
                array[index][docs[i].actors[c].user.toString()].real += real
                array[index][docs[i].actors[c].user.toString()].planned += planned
              } else {
                array[array.length - 1][docs[i].actors[c].user.toString()].real += real
                array[array.length - 1][docs[i].actors[c].user.toString()].planned += planned
              }
            }
          }
        }
        for (const a in array) {
          for (const u in array[a]) {
            if (array[a][u].real) {
              array[a][u].real = array[a][u].real / array[a][u].workDay
            }
          }
        }
        send(array)
      }
    })
  }

  // Número de recomendaciones atendidas/Total de recomendaciones comprometidas en el trimestre
  // Total de acuerdos atendidos/ total acuerdos programados
  async recommendations (req, mongo, send) {
    var settings = await new Promise(resolve => {
      mongo.findId('settings', 'settings', (err, doc) => {
        if (err || !doc) resolve({})
        else resolve(doc)
      })
    })
    let keys = await req.app.routes.attached.$keys(req, mongo)
    var units = settings.auditUnit
    if (!units || !units.length) units = [units]
    let auditCommitee = []
    if (settings.auditCommittee) {
      if (Array.isArray(settings.auditCommittee)) {
        auditCommitee = settings.auditCommittee
      } else {
        auditCommitee.push(settings.auditCommittee)
      }
    } else {
      if (Array.isArray(settings.auditCommitee)) {
        auditCommitee = settings.auditCommitee
      } else {
        auditCommitee.push(settings.auditCommitee)
      }
    }
    units.concat(auditCommitee)
    mongo.aggregate('attached', [{
      $lookup: {
        from: 'note',
        localField: 'reference',
        foreignField: '_id',
        as: 'note'
      }
    },
    {
      $unwind: '$note'
    },
    {
      $addFields: {
        confidential: '$note.confidential'
      }
    },
    {
      $lookup: {
        from: 'commitment',
        localField: '_id',
        foreignField: 'reference',
        as: 'commitments'
      }
    },
    {
      $unwind: '$commitments'
    },
    {
      $match: {
        $and: [{
          'commitments.status': 'accepted'
        }, keys]
      }
    },
    {
      $addFields: {
        actors: 1,
        status: 'status',
        date: {
          $arrayElemAt: [{
            $filter: {
              input: '$commitments.dates',
              as: 'date',
              cond: {
                $eq: ['$$date.type', 'deadline']
              }
            }
          }, 0]
        }
      }
    }
    ], {}, async (err, docs) => {
      if (err) {
        console.log(err)
        send({})
      } else {
        let others = 0
        let expired = 0
        const today = new Date()
        for (const i in docs) {
          others++
          if (docs[i].date && docs[i].date.value < today) {
            expired++
          }
        }
        send([
          [{
            value: expired,
            total: others,
            title: 'Vencidas'
          },
          {
            value: others - expired,
            total: others,
            title: 'No vencidas'
          }
          ],
          [{
            value: others,
            total: others,
            title: 'Emitidas'
          }, ]
        ])
      }
    })
  }

  // Horas de capacitación recibidas por auditor Vs Horas de capacitación requeridas para cada auditor
  async trainningHours (req, mongo, send) {
    var plan = await new Promise(resolve => {
      mongo.findOne('plan', {
        _id: mongo.toId(req.query._id)
      }, {}, (err, plan) => {
        if (err) console.log(err)
        resolve(plan)
      })
    })
    var pipeline = [{
      $match: {
        active: true,
        licensedUser: true
      }
    },
    {
      $unwind: {
        path: '$trainnings',
        preserveNullAndEmptyArrays: true
      }
    },
    {
      $group: {
        _id: '$_id',
        required: {
          $first: {
            $toDouble: {
              $cond: [{
                $eq: ['$business.trainingHours', '']
              },
              0,
              '$business.trainingHours'
              ]
            }
          }
        },
        received: {
          $sum: {
            $toDouble: {
              $cond: [{
                $and: [{
                  $gte: ['$trainnings.period.start', new Date(plan.period.start)]
                },
                {
                  $lte: ['$trainnings.period.end', new Date(plan.period.end)]
                },
                {
                  $ne: ['$trainnings.hourTrainning', '']
                }
                ]
              },
              '$trainnings.hourTrainning',
              0
              ]
            }
          }
        }
      }
    },
    {
      $group: {
        _id: null,
        left: {
          $sum: {
            $cond: [{
              $lt: ['$received', '$required']
            }, {
              $subtract: ['$required', '$received']
            }, 0]
          }
        },
        received: {
          $sum: {
            $ifNull: ['$received', 0]
          }
        },
        required: {
          $sum: {
            $toDouble: {
              $cond: [{
                $eq: ['$required', '']
              }, 0, '$required']
            }
          }
        }
      }
    }
    ]
    mongo.aggregate('user', pipeline, {}, (err, docs) => {
      if (err) {
        console.log(err || '')
        send({})
      } else {
        send([{
          value: docs[0].received, // - docs[0].left,
          title: 'Recibido'
        },
        {
          value: docs[0].required,
          title: 'Requerido'
        }
        ])
      }
    })
  }

  // Observaciones vencidas / total
  // Revision de respuestas en promedio
  observations (req, mongo, send) {
    mongo.findOne('plan', {
      _id: mongo.toId(req.query._id)
    }, {}, (err, plan) => {
      if (err) {
        console.log(err || '')
        send({})
      } else {
        mongo.find('attached', {
          'dates.type': 'answered',
          $and: [{
            dates: {
              $elemMatch: {
                type: 'issue',
                value: {
                  $gte: new Date(plan.period.start)
                }
              }
            }
          },
          {
            dates: {
              $elemMatch: {
                type: 'issue',
                value: {
                  $lte: new Date(plan.period.end)
                }
              }
            }
          }
          ]
        }, {}, async (err, docs) => {
          if (err) {
            console.log(err)
            send({})
          } else {
            let vencidos = 0
            let total = 0
            let time = 0
            let promedio = 0
            let simbolo = ''
            for (const i in docs) {
              total++
              let issue
              for (const d in docs[i].dates) {
                if (docs[i].dates[d].type === 'deadline' && new Date(docs[i].dates[d].value) < new Date() && (docs[i].status === 'processing' || docs[i].status === 'prepared')) {
                  vencidos++
                }
                if (docs[i].status === 'completed') {
                  let events = await new Promise(resolve => {
                    mongo.findOne('event', {
                      docId: docs[i]._id,
                      data: 'completed'
                    }, {}, async (err, event) => {
                      if (err || !event) {
                        if (err) console.log(err)
                        resolve(false)
                      } else {
                        let eventComm = await new Promise(resolve => {
                          mongo.findOne('commitment', {
                            reference: event.docId
                          }, {}, (err, comm) => {
                            if (err || !comm) {
                              if (err) console.log(err)
                              resolve(false)
                            } else {
                              mongo.findOne('event', {
                                docId: comm._id,
                                data: 'ready'
                              }, {}, async (err, eventComm) => {
                                if (err || !eventComm) {
                                  if (err) console.log(err)
                                  resolve(false)
                                } else {
                                  resolve(eventComm)
                                }
                              })
                            }
                          })
                        })
                        resolve({
                          attached: event,
                          commitment: eventComm
                        })
                      }
                    })
                  })
                  if (events.attached && events.commitment) {
                    time += events.attached.date - events.commitment.date
                  }
                }
              }
            }
            if (time) {
              promedio = moment.duration((time / docs.length), 'milliseconds').asDays()
              simbolo = 'd'
              if (promedio < 1) {
                promedio = moment.duration((time / docs.length), 'milliseconds').asHours()
                simbolo = 'h'
                if (promedio < 1) {
                  promedio = moment.duration((time / docs.length), 'milliseconds').asMinutes()
                  simbolo = 'm'
                }
              }
            }
            send([
              [{
                tiempo: promedio.toFixed(2) + simbolo
              }],
              [{
                value: vencidos,
                title: 'Vencidos'
              },
              {
                value: total,
                title: 'Total'
              }
              ]
            ])
          }
        })
      }
    })
  }

  async projectLate (req, mongo, send) {
    var hoy = new Date()

    function formatDate (date) {
      var d = new Date(date)
      var month = '' + (d.getMonth() + 1)
      var day = '' + d.getDate()
      var year = d.getFullYear()

      if (month.length < 2) {
        month = '0' + month
      }
      if (day.length < 2) {
        day = '0' + day
      }

      return [year, month, day].join('-')
    }
    //hoy = formatDate(hoy)
    var count = await new Promise(resolve => {
      var keys = {
        $and: [{
          $or: [{
            'actors.user': req.session.context.user
          }]
        },
        {
          $or: [{
            status: {
              $in: ['processing', 'paused']
            },
            'content.data': {
              $elemMatch: {
                type: 'task',
                status: {
                  $nin: ['suspended', 'done']
                },
                end_date: {
                  $lt: hoy
                }
              }
            }
          },
          {
            status: 'draft',
            'content.data': {
              $elemMatch: {
                type: 'task',
                start_date: {
                  $lt: hoy
                }
              }
            }
          }
          ]
        }
        ]
      }
      if (req.query.plan) {
        try {
          keys['$and'].push({
            plan: mongo.toId(req.query.plan)
          })
        } catch (error) {
          keys['$and'].push({
            plan: req.query.plan
          })
        }
      }
      if (req.session.context.memberUnits.length > 0) {
        keys.$and[0].$or.push({
          unit: {
            $in: req.session.context.memberUnits
          }
        })
      }
      if (req.session.context.dependentUnits.length > 0) {
        keys.$and[0].$or.push({
          unit: {
            $in: req.session.context.dependentUnits
          }
        })
      }

      var pipeline = [{
        $lookup: {
          from: 'task',
          localField: '_id',
          foreignField: 'project',
          as: 'Ttask'
        }
      },
      {
        $addFields: {
          condUno: {
            $size: {
              $filter: {
                input: '$Ttask',
                as: 'data',
                cond: {
                  $and: [{
                    $eq: ['$$data.type', 'task']
                  },
                  {
                    $in: ['$$data.status', ['processing', 'paused', 'draft']]
                  },
                  {
                    $lt: ['$$data.end_date', hoy]
                  }
                  ]
                }
              }
            }
          },
          condDos: {
            $size: {
              $filter: {
                input: '$Ttask',
                as: 'data',
                cond: {
                  $and: [{
                    $eq: ['$$data.type', 'task']
                  },
                  {
                    $lt: ['$$data.start_date', hoy]
                  }
                  ]
                }
              }
            }
          },
        }
      },
      {
        $match: {
          $and: [
            req.query.plan ? {
              plan: mongo.toId(req.query.plan)
            } : {},
            {
              $or: [{
                'actors.user': req.session.context.user
              },
              req.session.context.memberUnits.length > 0 ? {
                unit: {
                  $in: req.session.context.memberUnits
                }
              } : {},
              req.session.context.dependentUnits.length > 0 ? {
                unit: {
                  $in: req.session.context.dependentUnits
                }
              } : {}
              ]
            },
            {
              $or: [{
                $and: [{
                  status: {
                    $in: ['processing', 'paused']
                  }
                },
                {
                  condUno: {
                    $gt: 0
                  }
                }
                ]
              },
              {
                $and: [{
                  status: 'draft'
                },
                {
                  condDos: {
                    $gt: 0
                  }
                }
                ]
              }
              ]
            }
          ]
        }
      },
      {
        $group: {
          _id: null,
          myCount: {
            $sum: 1
          }
        }
      },
      ]

      mongo.aggregate('project', pipeline, {}, (err, data) => {
        if (err) throw err
        resolve(data)
      })
    })
    send({
      count: count[0] ? count[0].myCount : 0
    })
  }

  async countAttachedPending (req, mongo, send) {
    let key = {
      'options.value': 'Hallazgo'
    }
    var activePlan = req.query.plan
    var plan = await new Promise(resolve => {
      mongo.findOne('plan', {
        _id: mongo.toId(activePlan)
      }, {}, (err, plan) => {
        if (err) {
          console.log(err || '')
          resolve('')
        } else {
          resolve(plan)
        }
      })
    })
    var tag = await new Promise(resolve => {
      mongo.find('params', key, {
        'options.$': 1
      }, (err, tag) => {
        if (err) throw err
        resolve(tag)
      })
    })
    key.name = 'attachedTag'
    var tagAtta = await new Promise(resolve => {
      mongo.find('params', key, {
        'options.$': 1
      }, (err, tag) => {
        if (err) throw err
        resolve(tag)
      })
    })
    key.name = 'tag'
    var tagNot = await new Promise(resolve => {
      mongo.find('params', key, {
        'options.$': 1
      }, (err, tag) => {
        if (err) throw err
        resolve(tag)
      })
    })
    var count = 0
    var attacheds = 0
    var notes = 0
    if (plan) {
      if (tag.length) {
        count = await new Promise(resolve => {
          mongo.count('document', {
            tags: tag[0].options[0].id,
            $and: [{
              'dates.0.value': {
                $gte: new Date(plan.period.start)
              }
            },
            {
              'dates.0.value': {
                $lte: new Date(plan.period.end)
              }
            }
            ],
            status: 'processing'
          }, (err, count) => {
            if (err) throw err
            resolve(count)
          })
        })
      }
      if (tagNot.length) {
        notes = await new Promise(resolve => {
          mongo.count('note', {
            tags: tagNot[0].options[0].id,
            $and: [{
              'dates.0.value': {
                $gte: new Date(plan.period.start)
              }
            },
            {
              'dates.0.value': {
                $lte: new Date(plan.period.end)
              }
            }
            ],
            status: 'processing'
          }, (err, count) => {
            if (err) throw err
            resolve(count)
          })
        })
      }
      if (tagAtta.length) {
        attacheds = await new Promise(resolve => {
          mongo.count('attached', {
            attachedTag: tagAtta[0].options[0].id,
            $and: [{
              'dates.0.value': {
                $gte: new Date(plan.period.start)
              }
            },
            {
              'dates.0.value': {
                $lte: new Date(plan.period.end)
              }
            }
            ],
            status: 'processing'
          }, (err, count) => {
            if (err) throw err
            resolve(count)
          })
        })
      }
    }

    count = count + attacheds + notes
    send({
      count: count
    })
  }

  async countCommitmentPending (req, mongo, send) {
    var count = 0
    var activePlan = req.query.plan || req.session.context.activePlan.id.toString()
    var plan = await new Promise(resolve => {
      mongo.findOne('plan', {
        _id: mongo.toId(activePlan)
      }, {}, (err, plan) => {
        if (err) {
          console.log(err || '')
          resolve('')
        } else {
          resolve(plan)
        }
      })
    })
    count = await new Promise(resolve => {
      mongo.count('commitment', {
        $and: [{
          commitment: {
            $exists: true
          }
        },
        {
          status: {
            $in: ['processing', 'accepted']
          }
        },
        {
          'dates.0.value': {
            $gte: new Date(plan.period.start)
          }
        },
        {
          'dates.0.value': {
            $lte: new Date(plan.period.end)
          }
        }
        ]
      }, (err, count) => {
        if (err) throw err
        resolve(count)
      })
    })
    send({
      count: count
    })
  }

  async count (req, mongo, send) {
    var keys = {
      $or: [{
        unit: {
          $exists: 0
        }
      },
      {
        'actors.user': req.session.context.user,
        status: {
          $ne: 'archived'
        }
      },
      {
        $or: []
      }
      ]
    }
    if (req.query.plan) {
      try {
        keys.plan = mongo.toId(req.query.plan)
      } catch (error) {
        keys.plan = req.query.plan
      }
    }
    if (req.session.context.managerUnits.length > 0) {
      keys.$or[2].$or.push({
        unit: {
          $in: req.session.context.managerUnits
        }
      })
    }
    if (req.session.context.assistantUnits.length > 0) {
      keys.$or[2].$or.push({
        unit: {
          $in: req.session.context.assistantUnits
        }
      })
    }
    if (req.session.context.dependentUnits.length > 0) {
      keys.$or[2].$or.push({
        unit: {
          $in: req.session.context.dependentUnits
        }
      })
    }
    if (keys.$or[2].$or.length === 0) {
      keys.$or.pop()
    }
    var count = await new Promise(resolve => {
      mongo.count('project', keys, (err, count) => {
        if (err) throw err
        resolve(count)
      })
    })

    send({
      count: count
    })
  }

  // hallazgos - oportunidad de mejora
  async countDocumentsFinds (req, mongo, send) {
    // encontratar tag con el nombre
    let key = {
      'options.value': req.query.tag
    }
    if (req.query.tag === 'mejora') {
      key = {
        'options.value': {
          $in: [new RegExp('Oportunidad de mejora', 'i'), new RegExp('Oportunidades de mejora', 'i'), new RegExp('oportunidades de mejoras', 'i')]

        }
      }
    }
    var activePlan = req.query.plan
    var plan = await new Promise(resolve => {
      mongo.findOne('plan', {
        _id: mongo.toId(activePlan)
      }, {}, (err, plan) => {
        if (err) {
          console.log(err || '')
          resolve('')
        } else {
          resolve(plan)
        }
      })
    })
    var tag = await new Promise(resolve => {
      mongo.find('params', key, {
        'options.$': 1
      }, (err, tag) => {
        if (err) throw err
        resolve(tag)
      })
    })
    key.name = 'attachedTag'
    var tagAtta = await new Promise(resolve => {
      mongo.find('params', key, {
        'options.$': 1
      }, (err, tag) => {
        if (err) throw err
        resolve(tag)
      })
    })
    key.name = 'tag'
    var tagNot = await new Promise(resolve => {
      mongo.find('params', key, {
        'options.$': 1
      }, (err, tag) => {
        if (err) throw err
        resolve(tag)
      })
    })
    var count = 0
    var attacheds = 0
    var notes = 0
    if (plan) {
      if (tag.length) {
        count = await new Promise(resolve => {
          mongo.count('document', {
            tags: tag[0].options[0].id,
            $and: [{
              'dates.0.value': {
                $gte: new Date(plan.period.start)
              }
            },
            {
              'dates.0.value': {
                $lte: new Date(plan.period.end)
              }
            }
            ],
            status: {
              $ne: 'draft'
            }
          }, (err, count) => {
            if (err) throw err
            resolve(count)
          })
        })
      }
      if (tagNot.length) {
        notes = await new Promise(resolve => {
          mongo.count('note', {
            tags: tagNot[0].options[0].id,
            $and: [{
              'dates.0.value': {
                $gte: new Date(plan.period.start)
              }
            },
            {
              'dates.0.value': {
                $lte: new Date(plan.period.end)
              }
            }
            ],
            status: {
              $ne: 'draft'
            }
          }, (err, count) => {
            if (err) throw err
            resolve(count)
          })
        })
      }
      if (tagAtta.length) {
        attacheds = await new Promise(resolve => {
          mongo.count('attached', {
            attachedTag: tagAtta[0].options[0].id,
            $and: [{
              'dates.0.value': {
                $gte: new Date(plan.period.start)
              }
            },
            {
              'dates.0.value': {
                $lte: new Date(plan.period.end)
              }
            }
            ],
            status: {
              $ne: 'prepared'
            }
          }, (err, count) => {
            if (err) throw err
            resolve(count)
          })
        })
      }
    }

    count = count + attacheds + notes
    send({
      count: count
    })
  }

  async chartAuditado (req, mongo, send) {
    //anexos
    let atendidos = 0
    let rechazados = 0
    let conCompromiso = 0
    let vencidosConCompromiso = 0 //anexos con compromisos respondidos despues de su vencimiento
    let noVencidosConCompromiso = 0
    let pendientes = 0
    let vencidosPendientes = 0
    let noVencidosPendientes = 0
    let attacheds = await new Promise(resolve => {
      mongo.find('attached', {
        actors: {
          $elemMatch: {
            user: mongo.toId(req.query._id),
            role: 'responsible'
          }
        }
      }, {}, (err, atts) => {
        if (atts && atts.length) {
          resolve(atts)
        } else {
          resolve(false)
        }
      })
    })
    if (attacheds) {
      for (let i in attacheds) {
        let att = attacheds[i]
        if (att.status === 'answered') {
          conCompromiso++
          let comm = await new Promise(resolve => {
            mongo.find('commitment', {
              reference: att._id
            }, {}, (err, comm) => {
              if (comm && comm.length) {
                resolve(comm[0])
              } else {
                resolve(false)
              }
            })
          })
          if (comm) {
            let dateAnswered = ''
            let dateDeadline = ''
            for (let d in att.dates) {
              if (att.dates[d].type === 'deadline') dateDeadline = new Date(att.dates[d].value)
              if (att.dates[d].type === 'answered') dateAnswered = new Date(att.dates[d].value)
            }
            if (dateAnswered && dateDeadline && (dateAnswered > dateDeadline)) {
              vencidosConCompromiso++
            }
          }
        } else if (att.status === 'processing') {
          pendientes++
          for (let d in att.dates) {
            if (att.dates[d].type === 'deadline' && new Date(att.dates[d].value) < new Date()) {
              vencidosPendientes++
              break
            }
          }
        }
      }
      noVencidosConCompromiso = conCompromiso - vencidosConCompromiso
      noVencidosPendientes = pendientes - vencidosPendientes
    }
    var reply = [{
      id: '1',
      name: 'Hallazgos atendidos',
      count: atendidos,
      color: 'green'
    },
    {
      id: '2',
      name: 'Hallazgos rechazados',
      count: rechazados,
      color: 'red'
    },
    {
      id: '3',
      name: 'Hallazgos con compromiso',
      count: conCompromiso,
      color: 'blue'
    },
    {
      id: '4',
      name: 'Hallazgos pendientes',
      count: pendientes,
      color: 'purple'
    }
    ]
    var reply2 = [{
      id: '1',
      name: 'Hallazgos pendientes vencidos',
      count: vencidosPendientes,
      color: 'red'
    },
    {
      id: '2',
      name: 'Hallazgos pendientes dentro del plazo',
      count: noVencidosPendientes,
      color: 'green'
    },
    ]
    var reply3 = [{
      id: '1',
      name: 'Hallazgos vencidos con compromiso ',
      count: vencidosConCompromiso,
      color: 'red'
    },
    {
      id: '2',
      name: 'Hallazgos dentro del plazo con compromisos',
      count: noVencidosConCompromiso,
      color: 'green'
    },
    ]
    send([reply, reply2, reply3])
  }

  async projectWorksExecuted (req, mongo, send) {
    var keys = {
      $and: [{
        status: {
          $in: ['archived']
        }
      },

      ]
    }
    keys.duration = {
      $ne: ''
    }
    if (req.query._id) {
      keys.plan = mongo.toId(req.query._id)
    }

    var pipeline = []
    pipeline.push({
      $match: keys
    })
    pipeline.push({
      $unwind: {
        path: '$tag',
        preserveNullAndEmptyArrays: true
      }
    })
    pipeline.push({
      $addFields: {
        convertedDuration: {
          $toDouble: {
            $cond: [{
              $eq: ['$duration', '']
            }, 0, '$duration']
          }
        }
      }
    })
    pipeline.push({
      $project: {
        _id: 1,
        status: 1,
        tag: 1,
        duration: 1
      }
    })
    pipeline.push({
      $lookup: {
        from: 'params',
        localField: 'tag',
        foreignField: 'options.id',
        as: 'tg'
      }
    })
    pipeline.push({
      $addFields: {
        namesTag: {
          $ifNull: [{
            $arrayElemAt: ['$tg.options.value', {
              $indexOfArray: ['$tg.options.id', '$tag']
            }]
          },
          ['Sin etiqueta'] //proyectos sin etiqueta
          ]
        },
        idsTag: {
          $ifNull: [{
            $arrayElemAt: ['$tg.options.id', {
              $indexOfArray: ['$tg.options.id', '$tag']
            }]
          },
          []
          ]
        },
        colorsTag: {
          $ifNull: [{
            $arrayElemAt: ['$tg.options.color', {
              $indexOfArray: ['$tg.options.id', '$tag']
            }]
          },
          ['#e0e0e0'] // le pone gris a proyectos sin etiqueta
          ]
        },
      }
    })
    pipeline.push({
      $addFields: {
        tagName: {
          $ifNull: [{
            $arrayElemAt: ['$namesTag', {
              $indexOfArray: ['$idsTag', '$tag']
            }]
          },
          []
          ]
        },
        tagColor: {
          $ifNull: [{
            $arrayElemAt: ['$colorsTag', {
              $indexOfArray: ['$idsTag', '$tag']
            }]
          },
          []
          ]
        }
      }
    })
    pipeline.push({
      $group: {
        _id: '$tag',
        count: {
          $sum: 1
        },
        tag: {
          $first: '$tag'
        },
        tagName: {
          $first: '$tagName'
        },
        tagColor: {
          $first: '$tagColor'
        }
      }
    })
    mongo.aggregate('project', pipeline, {}, (err, data) => {
      if (err) throw err
      let sum = 0
      for (let d in data) {
        sum += data[d].count
      }
      for (let d in data) {
        data[d].porc = (data[d].count * 100) / sum
      }
      send(data)
    })
  }

  async projectChartDuration (req, mongo, send) {
    var reply = []
    var keys = {
      $and: [{
        status: {
          $ne: 'archived'
        }
      },
      {
        $or: [{
          unit: {
            $exists: 0
          }
        },
        {
          'actors.user': req.session.context.user
        },
        {
          $or: []
        }
        ]
      }
      ]
    }
    keys.duration = {
      $ne: ''
    }
    if (req.query._id) {
      keys.plan = mongo.toId(req.query._id)
    }
    if (req.query.date) {
      keys._id = {
        $gt: ObjectId.createFromTime(Date.now() / 1000 - 2160 * 60 * 60)
      }
    }
    if (req.session.context.managerUnits.length > 0) {
      keys.$and[1].$or[2].$or.push({
        unit: {
          $in: req.session.context.managerUnits
        }
      })
    }
    if (req.session.context.assistantUnits.length > 0) {
      keys.$and[1].$or[2].$or.push({
        unit: {
          $in: req.session.context.assistantUnits
        }
      })
    }
    if (req.session.context.dependentUnits.length > 0) {
      keys.$and[1].$or[2].$or.push({
        unit: {
          $in: req.session.context.dependentUnits
        }
      })
    }
    if (keys.$and[1].$or[2].$or.length === 0) {
      keys.$and[1].$or.pop()
    }
    var pipeline = []
    pipeline.push({
      $match: keys
    })
    pipeline.push({
      $unwind: {
        path: '$tag',
        preserveNullAndEmptyArrays: true
      }
    })
    pipeline.push({
      $addFields: {
        convertedDuration: {
          $toDouble: {
            $cond: [{
              $eq: ['$duration', '']
            }, 0, '$duration']
          }
        }
      }
    })
    pipeline.push({
      $project: {
        _id: 1,
        status: 1,
        tag: 1,
        duration: 1
      }
    })
    pipeline.push({
      $lookup: {
        from: 'params',
        localField: 'tag',
        foreignField: 'options.id',
        as: 'tg'
      }
    })
    mongo.aggregate('project', pipeline, {}, (err, data) => {
      if (err) throw err
      var duracionCompletada = 0
      var duracionPlaneada = 0
      var projectosCompletos = 0
      var projectosPlaneados = 0
      for (const i in data) {
        projectosPlaneados += 1
        if (data[i].status === 'completed') {
          projectosCompletos += 1
        }
        if (data[i].duration) {
          duracionPlaneada += parseFloat(data[i].duration)

          if (data[i].status === 'completed') {
            duracionCompletada += parseFloat(data[i].duration)
          }
        }
        if (data[i].tg.length > 0) {
          var index
          try {
            index = data[i].tg[0].options.findIndex((x) => {
              return x.id.toString().includes(data[i].tag.toString())
            })
          } catch (error) {
            index = false
          }

          if ((index || index === 0) && index !== -1) {
            if (reply.length > 0) {
              var index2
              try {
                index2 = reply.findIndex((x) => {
                  return x.id.toString().includes(data[i].tag.toString())
                })
              } catch (error) {
                index2 = false
              }
              if ((index2 || index2 === 0) && index2 !== -1) {
                if (data[i].status === 'completed') {
                  reply[index2].countC = reply[index2].countC + 1
                  reply[index2].duration += data[i].duration ? (Number(data[i].duration) / 60) / req.session.context.workDay : 0
                } else {
                  reply[index2].count = reply[index2].count + 1
                  reply[index2].duration += data[i].duration ? (Number(data[i].duration) / 60) / req.session.context.workDay : 0
                }
              } else if (index2 && index2 === -1) {
                var count1 = 0
                var count2 = 0
                if (data[i].status === 'completed') {
                  count2 = 1
                } else {
                  count1 = 1
                }
                if (data[i].tg[0]) {
                  reply.push({
                    id: data[i].tag,
                    name: data[i].tg[0].options[index].value,
                    color: data[i].tg[0].options[index].color,
                    count: count1,
                    countC: count2,
                    duration: data[i].duration ? (Number(data[i].duration) / 60) / req.session.context.workDay : 0
                  })
                }
              }
            } else {
              reply.push({
                id: data[i].tag,
                name: data[i].tg[0].options[index].value,
                color: data[i].tg[0].options[index].color,
                count: 0,
                countC: 0,
                duration: data[i].duration ? (Number(data[i].duration) / 60) / req.session.context.workDay : 0
              })
              if (data[i].status === 'completed') {
                reply[0].countC = 1
              } else {
                reply[0].count = 1
              }
            }
          }
        } else {
          if (data[i].status === 'completed') {
            count2 = 1
          } else {
            count1 = 1
          }
          var index3
          try {
            index3 = reply.findIndex((x) => {
              return x.id.toString().includes('Sin etiqueta')
            })
          } catch (error) {
            index3 = false
          }
          if ((index3 || index3 === 0) && index3 !== -1) {
            if (data[i].status === 'completed') {
              reply[index3].countC = reply[index3].countC + 1
              reply[index3].duration += data[i].duration ? (Number(data[i].duration) / 60) / req.session.context.workDay : 0
            } else {
              reply[index3].count = reply[index3].count + 1
              reply[index3].duration += data[i].duration ? (Number(data[i].duration) / 60) / req.session.context.workDay : 0
            }
          } else {
            reply.push({
              id: 'Sin etiqueta',
              name: 'Sin etiqueta',
              color: '#636363',
              count: count1,
              countC: count2,
              duration: data[i].duration ? (Number(data[i].duration) / 60) / req.session.context.workDay : 0
            })
          }
        }
      }
      var array2 = []
      var max = duracionPlaneada / 100
      var max2 = projectosPlaneados / 100
      var porcent = duracionCompletada / max
      var porcent2 = projectosCompletos / max2
      array2.push({
        Completada: porcent,
        Planeada: max ? 100 : 0,
        group: 'Tiempo'
      }, {
        Completada: porcent2,
        Planeada: max2 ? 100 : 0,
        group: 'Cant trab'
      })
      send([reply, array2])
    })
  }

  async commitmentByRisk (req, mongo, send) {
    var keys = await req.app.routes.commitment.$keys(req, mongo)
    keys.status = {
      $nin: ['done', 'completed', 'incomplete', 'annulled']
    }
    var myUnits
    if (req.session.context.licensedUser === false) {
      myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits)
    } else {
      myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits).concat(req.session.context.memberUnits)
    }
    var pipeline = [{
      $lookup: {
        from: 'attached',
        localField: 'reference',
        foreignField: '_id',
        as: 'att'
      }
    },
    {
      $unwind: '$att'
    },
    {
      $lookup: {
        from: 'note',
        localField: 'att.reference',
        foreignField: '_id',
        as: 'note'
      }
    },
    {
      $unwind: '$note'
    },
    {
      $lookup: {
        from: 'params',
        localField: 'att.tags',
        foreignField: 'options.id',
        as: 'par'
      }
    },
    {
      $addFields: {
        actor: {
          $filter: {
            input: '$actors',
            as: 'actor',
            cond: {
              $eq: ['$$actor.role', 'responsible']
            }
          }
        }
      }
    },
    {
      $lookup: {
        from: 'unit',
        localField: 'actor.unit',
        foreignField: '_id',
        as: 'unit'
      }
    },
    {
      $addFields: {
        options: {
          $arrayElemAt: ['$par.options', 0]
        },
        confidential: '$note.confidential',
        actors: '$att.actors',
        sequence: '$note.sequence',
        offline: {
          $arrayElemAt: [{
            $ifNull: ['$unit.offline', [false]]
          }, 0]
        }
      }
    },
    {
      $addFields: {
        isShow: {
          $function: {
            body: `function (offline, status, actors, user) {
                if (status === 'draft') {
                  for (let a in actors) {
                    let act = actors[a]
                    if ((hex_md5(user.toString()) === hex_md5(act.user.toString())) && offline && (act.role === 'from' || act.role === 'reviser' || act.role === 'supervisor') && (act.path === 'sent')) {
                      return true
                    }
                    if ((hex_md5(user.toString()) === hex_md5(act.user.toString())) && act.role === 'responsible') {
                      return true
                    }
                  }
                } else {
                  return true
                }
              }`,
            args: ['$offline', '$status', '$actors', req.session.context.user],
            lang: 'js'
          }
        }
      }
    },
    {
      $match: keys
    },
    {
      $match: {
        $or: [{
          isShow: true
        }, {
          actors: {
            $elemMatch: {
              unit: {
                $in: myUnits
              },
              path: {
                $ne: 'hidden'
              }
            }
          }
        }]
      }
    },
    {
      $addFields: {
        risk: {
          $arrayElemAt: [{
            $filter: {
              input: '$options',
              as: 'risk',
              cond: {
                $eq: ['$$risk.id', {
                  $arrayElemAt: ['$att.tags', 0]
                }]
              }
            }
          }, 0]
        }
      }
    },
    {
      $group: {
        _id: '$risk.value',
        cont: {
          $sum: 1
        }
      }
    },
    {
      $project: {
        _id: 0,
        id: '$_id',
        title: '$_id',
        value: '$cont'
      }
    },
    {
      $sort: {
        title: 1
      }
    }
    ]
    mongo.aggregate('commitment', pipeline, {}, async (err, docs) => {
      if (err) {
        send(err)
      } else {
        var total = 0
        docs.forEach((doc) => {
          total += doc.value
        })
        docs.forEach((doc) => {
          doc.total = total
        })
        send(docs)
      }
    })
  }

  async commitmentByUnit (req, mongo, send) {
    var keys = await req.app.routes.commitment.$keys(req, mongo)
    keys.status = {
      $nin: ['done', 'completed', 'incomplete', 'annulled']
    }
    var myUnits
    if (req.session.context.licensedUser === false) {
      myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits)
    } else {
      myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits).concat(req.session.context.memberUnits)
    }
    var units
    if (!req.session.context.licensedUser) {
      units = req.session.context.managerUnits.concat(req.session.context.assistantUnits)
    } else {
      units = await new Promise(resolve => {
        mongo.findOne('settings', {
          _id: 'settings'
        }, {
          directory: 1
        }, (er, doc) => {
          resolve(doc.directory)
        })
      })
    }
    units = await req.app.routes.note.$subunits(mongo, units)
    var pipeline = [{
      $lookup: {
        from: 'attached',
        localField: 'reference',
        foreignField: '_id',
        as: 'att'
      }
    },
    {
      $unwind: '$att'
    },
    {
      $lookup: {
        from: 'note',
        localField: 'att.reference',
        foreignField: '_id',
        as: 'note'
      }
    },
    {
      $unwind: '$note'
    },
    {
      $lookup: {
        from: 'params',
        localField: 'att.tags',
        foreignField: 'options.id',
        as: 'par'
      }
    },
    {
      $addFields: {
        actor: {
          $filter: {
            input: '$actors',
            as: 'actor',
            cond: {
              $eq: ['$$actor.role', 'responsible']
            }
          }
        }
      }
    },
    {
      $lookup: {
        from: 'unit',
        localField: 'actor.unit',
        foreignField: '_id',
        as: 'unit'
      }
    },
    {
      $addFields: {
        options: {
          $arrayElemAt: ['$par.options', 0]
        },
        confidential: '$note.confidential',
        actors: '$att.actors',
        sequence: '$note.sequence',
        offline: {
          $arrayElemAt: [{
            $ifNull: ['$unit.offline', [false]]
          }, 0]
        }
      }
    },
    {
      $addFields: {
        isShow: {
          $function: {
            body: `function (offline, status, actors, user) {
                if (status === 'draft') {
                  for (let a in actors) {
                    let act = actors[a]
                    if ((hex_md5(user.toString()) === hex_md5(act.user.toString())) && offline && (act.role === 'from' || act.role === 'reviser' || act.role === 'supervisor') && (act.path === 'sent')) {
                      return true
                    }
                    if ((hex_md5(user.toString()) === hex_md5(act.user.toString())) && act.role === 'responsible') {
                      return true
                    }
                  }
                } else {
                  return true
                }
              }`,
            args: ['$offline', '$status', '$actors', req.session.context.user],
            lang: 'js'
          }
        }
      }
    },
    {
      $match: keys
    },
    {
      $match: {
        $or: [{
          isShow: true
        }, {
          actors: {
            $elemMatch: {
              unit: {
                $in: myUnits
              },
              path: {
                $ne: 'hidden'
              }
            }
          }
        }]
      }
    },
    {
      $addFields: {
        risk: {
          $arrayElemAt: [{
            $filter: {
              input: '$options',
              as: 'risk',
              cond: {
                $eq: ['$$risk.id', {
                  $arrayElemAt: ['$att.tags', 0]
                }]
              }
            }
          }, 0]
        }
      }
    },
    {
      $addFields: {
        gerencia: {
          $arrayElemAt: [{
            $filter: {
              input: '$actors',
              as: 'actor',
              cond: {
                $eq: ['$$actor.role', 'responsible']
              }
            }
          }, 0]
        }
      }
    },
    {
      $addFields: {
        gerencia: {
          $filter: {
            input: units,
            as: 'director',
            cond: {
              $in: ['$gerencia.unit', '$$director.dependents']
            }
          }
        }
      }
    },
    {
      $lookup: {
        from: 'unit',
        localField: 'gerencia.unit',
        foreignField: '_id',
        as: 'gerencia'
      }
    },
    {
      $unwind: '$gerencia'
    },
    {
      $group: {
        _id: {
          code: '$gerencia.code',
          name: '$gerencia.name'
        },
        value: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'ALTO']
              },
              then: 1,
              else: 0
            }
          }
        },
        value2: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'MEDIO']
              },
              then: 1,
              else: 0
            }
          }
        },
        value3: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'OPORTUNIDAD DE MEJORA']
              },
              then: 1,
              else: 0
            }
          }
        },
        value4: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'MUY ALTO']
              },
              then: 1,
              else: 0
            }
          }
        },
        total: {
          $sum: 1
        }
      }
    },
    {
      $project: {
        _id: 0,
        nameUnit: '$_id.name',
        value: 1,
        value2: 1,
        value3: 1,
        value4: 1,
        total: 1
      }
    },
    {
      $sort: {
        nameUnit: 1
      }
    }
    ]
    mongo.aggregate('commitment', pipeline, {}, (err, docs) => {
      if (err) console.log(err)
      var total = {
        nameUnit: 'Total',
        value: 0,
        value2: 0,
        value3: 0,
        value4: 0,
        total: 0
      }
      if (docs && docs.forEach) {
        docs.forEach((doc) => {
          total.value += doc.value
          total.value2 += doc.value2
          total.value3 += doc.value3
          total.value4 += doc.value4
          total.total += doc.total
        })
      } else {docs=[]}
      docs.push(total)
      send(docs)
    })
  }

  async commitmentByEjecutor (req, mongo, send) {
    var keys = await req.app.routes.commitment.$keys(req, mongo)
    keys.status = {
      $nin: ['done', 'completed', 'incomplete', 'annulled']
    }
    var myUnits
    if (req.session.context.licensedUser === false) {
      myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits)
    } else {
      myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits).concat(req.session.context.memberUnits)
    }
    var pipeline = [{
      $lookup: {
        from: 'attached',
        localField: 'reference',
        foreignField: '_id',
        as: 'att'
      }
    },
    {
      $unwind: '$att'
    },
    {
      $lookup: {
        from: 'note',
        localField: 'att.reference',
        foreignField: '_id',
        as: 'note'
      }
    },
    {
      $unwind: '$note'
    },
    {
      $lookup: {
        from: 'params',
        localField: 'att.tags',
        foreignField: 'options.id',
        as: 'par'
      }
    },
    {
      $addFields: {
        actor: {
          $filter: {
            input: '$actors',
            as: 'actor',
            cond: {
              $eq: ['$$actor.role', 'responsible']
            }
          }
        }
      }
    },
    {
      $lookup: {
        from: 'unit',
        localField: 'actor.unit',
        foreignField: '_id',
        as: 'unit'
      }
    },
    {
      $addFields: {
        options: {
          $arrayElemAt: ['$par.options', 0]
        },
        confidential: '$note.confidential',
        actors: '$att.actors',
        sequence: '$note.sequence',
        offline: {
          $arrayElemAt: [{
            $ifNull: ['$unit.offline', [false]]
          }, 0]
        }
      }
    },
    {
      $addFields: {
        isShow: {
          $function: {
            body: `function (offline, status, actors, user) {
                if (status === 'draft') {
                  for (let a in actors) {
                    let act = actors[a]
                    if ((hex_md5(user.toString()) === hex_md5(act.user.toString())) && offline && (act.role === 'from' || act.role === 'reviser' || act.role === 'supervisor') && (act.path === 'sent')) {
                      return true
                    }
                    if ((hex_md5(user.toString()) === hex_md5(act.user.toString())) && act.role === 'responsible') {
                      return true
                    }
                  }
                } else {
                  return true
                }
              }`,
            args: ['$offline', '$status', '$actors', req.session.context.user],
            lang: 'js'
          }
        }
      }
    },
    {
      $match: keys
    },
    {
      $match: {
        $or: [{
          isShow: true
        }, {
          actors: {
            $elemMatch: {
              unit: {
                $in: myUnits
              },
              path: {
                $ne: 'hidden'
              }
            }
          }
        }]
      }
    },
    {
      $addFields: {
        risk: {
          $arrayElemAt: [{
            $filter: {
              input: '$options',
              as: 'risk',
              cond: {
                $eq: ['$$risk.id', {
                  $arrayElemAt: ['$att.tags', 0]
                }]
              }
            }
          }, 0]
        }
      }
    },
    {
      $addFields: {
        emisor: {
          $arrayElemAt: [{
            $filter: {
              input: '$actors',
              as: 'actor',
              cond: {
                $eq: ['$$actor.role', 'from']
              }
            }
          }, 0]
        }
      }
    },
    {
      $lookup: {
        from: 'unit',
        localField: 'emisor.unit',
        foreignField: '_id',
        as: 'ejecutor'
      }
    },
    {
      $unwind: '$ejecutor'
    },
    {
      $group: {
        _id: '$ejecutor.name',
        value: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'ALTO']
              },
              then: 1,
              else: 0
            }
          }
        },
        value2: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'MEDIO']
              },
              then: 1,
              else: 0
            }
          }
        },
        value3: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'OPORTUNIDAD DE MEJORA']
              },
              then: 1,
              else: 0
            }
          }
        },
        value4: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'MUY ALTO']
              },
              then: 1,
              else: 0
            }
          }
        },
        total: {
          $sum: 1
        }
      }
    },
    {
      $project: {
        _id: 0,
        nameUnit: '$_id',
        value: 1,
        value2: 1,
        value3: 1,
        value4: 1,
        total: 1
      }
    },
    {
      $sort: {
        nameUnit: 1
      }
    }
    ]
    mongo.aggregate('commitment', pipeline, {}, (err, docs) => {
      if (err) console.log(err)
      var total = {
        nameUnit: 'Total',
        value: 0,
        value2: 0,
        value3: 0,
        value4: 0,
        total: 0
      }
      if (!docs) {
        docs=[]
      }
      docs.forEach((doc) => {
        total.value += doc.value
        total.value2 += doc.value2
        total.value3 += doc.value3
        total.value4 += doc.value4
        total.total += doc.total
      })
      docs.push(total)
      send(docs)
    })
  }
  async commitmentByExpiration (req, mongo, send) {
    var today = new Date()
    var keys = await req.app.routes.commitment.$keys(req, mongo)
    keys.status = {
      $nin: ['done', 'completed', 'incomplete', 'annulled']
    }
    var myUnits
    if (req.session.context.licensedUser === false) {
      myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits)
    } else {
      myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits).concat(req.session.context.memberUnits)
    }
    var pipeline = [{
      $lookup: {
        from: 'attached',
        localField: 'reference',
        foreignField: '_id',
        as: 'att'
      }
    },
    {
      $unwind: '$att'
    },
    {
      $lookup: {
        from: 'note',
        localField: 'att.reference',
        foreignField: '_id',
        as: 'note'
      }
    },
    {
      $unwind: '$note'
    },
    {
      $lookup: {
        from: 'params',
        localField: 'att.tags',
        foreignField: 'options.id',
        as: 'par'
      }
    },
    {
      $addFields: {
        actor: {
          $filter: {
            input: '$actors',
            as: 'actor',
            cond: {
              $eq: ['$$actor.role', 'responsible']
            }
          }
        }
      }
    },
    {
      $lookup: {
        from: 'unit',
        localField: 'actor.unit',
        foreignField: '_id',
        as: 'unit'
      }
    },
    {
      $addFields: {
        options: {
          $arrayElemAt: ['$par.options', 0]
        },
        confidential: '$note.confidential',
        actors: '$att.actors',
        sequence: '$note.sequence',
        offline: {
          $arrayElemAt: [{
            $ifNull: ['$unit.offline', [false]]
          }, 0]
        }
      }
    },
    {
      $addFields: {
        isShow: {
          $function: {
            body: `function (offline, status, actors, user) {
                if (status === 'draft') {
                  for (let a in actors) {
                    let act = actors[a]
                    if ((hex_md5(user.toString()) === hex_md5(act.user.toString())) && offline && (act.role === 'from' || act.role === 'reviser' || act.role === 'supervisor') && (act.path === 'sent')) {
                      return true
                    }
                    if ((hex_md5(user.toString()) === hex_md5(act.user.toString())) && act.role === 'responsible') {
                      return true
                    }
                  }
                } else {
                  return true
                }
              }`,
            args: ['$offline', '$status', '$actors', req.session.context.user],
            lang: 'js'
          }
        }
      }
    },
    {
      $match: keys
    },
    {
      $match: {
        $or: [{
          isShow: true
        }, {
          actors: {
            $elemMatch: {
              unit: {
                $in: myUnits
              },
              path: {
                $ne: 'hidden'
              }
            }
          }
        }]
      }
    },
    {
      $addFields: {
        dates: {
          $arrayElemAt: [{
            $filter: {
              input: '$dates',
              as: 'date',
              cond: {
                $eq: ['$$date.type', 'deadline']
              }
            }
          }, 0]
        }
      }
    },
    {
      $addFields: {
        risk: {
          $arrayElemAt: [{
            $filter: {
              input: '$options',
              as: 'risk',
              cond: {
                $eq: ['$$risk.id', {
                  $arrayElemAt: ['$att.tags', 0]
                }]
              }
            }
          }, 0]
        }
      }
    },
    {
      $group: {
        _id: {
          $cond: {
            if: {
              $lt: ['$dates.value', today]
            },
            then: 'Vencidos',
            else: 'Emitidos'
          }
        },
        alto: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'ALTO']
              },
              then: 1,
              else: 0
            }
          }
        },
        medio: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'MEDIO']
              },
              then: 1,
              else: 0
            }
          }
        },
        bajo: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'OPORTUNIDAD DE MEJORA']
              },
              then: 1,
              else: 0
            }
          }
        },
        muyalto: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'MUY ALTO']
              },
              then: 1,
              else: 0
            }
          }
        },
      }
    },
    {
      $project: {
        _id: 0,
        id: '$_id',
        estado: '$_id',
        alto: 1,
        medio: 1,
        bajo: 1,
        muyalto: 1
      }
    },
    {
      $sort: {
        estado: -1
      }
    }
    ]
    mongo.aggregate('commitment', pipeline, {}, (err, docs) => {
      if (err) console.log(err)
      var total = {
        id: 'Total',
        estado: 'Emitidos',
        alto: 0,
        medio: 0,
        bajo: 0,
        muyalto: 0
      }
      if(!docs) docs=[]
      docs.forEach((doc) => {
        total.alto += doc.alto
        total.medio += doc.medio
        total.bajo += doc.bajo
        total.muyalto += doc.muyalto
      })
      docs.push(total)
      send(docs)
    })
  }

  async attachedByRisk (req, mongo, send) {
    var pipeline = [{
      $lookup: {
        from: 'note',
        localField: 'reference',
        foreignField: '_id',
        as: 'note'
      }
    },
    {
      $unwind: '$note'
    },
    {
      $lookup: {
        from: 'params',
        localField: 'tags',
        foreignField: 'options.id',
        as: 'par'
      }
    },
    {
      $addFields: {
        options: {
          $arrayElemAt: ['$par.options', 0]
        },
        confidential: '$note.confidential',
        actors: '$actors'
      }
    },
    {
      $match: {
        $and: [{
          status: {
            $in: ['processing', 'answered']
          }
        }, await req.app.routes.attached.$keys(req, mongo)]
      }
    },
    {
      $addFields: {
        risk: {
          $arrayElemAt: [{
            $filter: {
              input: '$options',
              as: 'risk',
              cond: {
                $eq: ['$$risk.id', {
                  $arrayElemAt: ['$tags', 0]
                }]
              }
            }
          }, 0]
        }
      }
    },
    {
      $group: {
        _id: '$risk.value',
        cont: {
          $sum: 1
        }
      }
    },
    {
      $project: {
        _id: 0,
        id: '$_id',
        title: '$_id',
        value: '$cont'
      }
    },
    {
      $sort: {
        title: 1
      }
    }
    ]
    mongo.aggregate('attached', pipeline, {}, async (err, docs) => {
      if (err) {
        send(err)
      } else {
        var total = 0
        docs.forEach((doc) => {
          total += doc.value
        })
        docs.forEach((doc) => {
          doc.total = total
        })
        send(docs)
      }
    })
  }

  async attachedByUnit (req, mongo, send) {
    var units
    if (!req.session.context.licensedUser) {
      units = req.session.context.managerUnits.concat(req.session.context.assistantUnits)
    } else {
      units = await new Promise(resolve => {
        mongo.findOne('settings', {
          _id: 'settings'
        }, {
          directory: 1
        }, (er, doc) => {
          resolve(doc.directory)
        })
      })
    }
    units = await req.app.routes.note.$subunits(mongo, units)
    var pipeline = [{
      $lookup: {
        from: 'note',
        localField: 'reference',
        foreignField: '_id',
        as: 'note'
      }
    },
    {
      $unwind: '$note'
    },
    {
      $lookup: {
        from: 'params',
        localField: 'tags',
        foreignField: 'options.id',
        as: 'par'
      }
    },
    {
      $addFields: {
        options: {
          $arrayElemAt: ['$par.options', 0]
        },
        confidential: '$note.confidential',
        actors: '$actors'
      }
    },
    {
      $match: {
        $and: [{
          status: {
            $in: ['processing', 'answered']
          }
        }, await req.app.routes.attached.$keys(req, mongo)]
      }
    },
    {
      $addFields: {
        risk: {
          $arrayElemAt: [{
            $filter: {
              input: '$options',
              as: 'risk',
              cond: {
                $eq: ['$$risk.id', {
                  $arrayElemAt: ['$tags', 0]
                }]
              }
            }
          }, 0]
        }
      }
    },
    {
      $addFields: {
        gerencia: {
          $arrayElemAt: [{
            $filter: {
              input: '$actors',
              as: 'actor',
              cond: {
                $eq: ['$$actor.role', 'responsible']
              }
            }
          }, 0]
        }
      }
    },
    {
      $addFields: {
        gerencia: {
          $filter: {
            input: units,
            as: 'director',
            cond: {
              $in: ['$gerencia.unit', '$$director.dependents']
            }
          }
        }
      }
    },
    {
      $lookup: {
        from: 'unit',
        localField: 'gerencia.unit',
        foreignField: '_id',
        as: 'gerencia'
      }
    },
    {
      $unwind: '$gerencia'
    },
    {
      $group: {
        _id: {
          code: '$gerencia.code',
          name: '$gerencia.name'
        },
        value: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'ALTO']
              },
              then: 1,
              else: 0
            }
          }
        },
        value2: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'MEDIO']
              },
              then: 1,
              else: 0
            }
          }
        },
        value3: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'OPORTUNIDAD DE MEJORA']
              },
              then: 1,
              else: 0
            }
          }
        },
        total: {
          $sum: 1
        }
      }
    },
    {
      $project: {
        _id: 0,
        nameUnit: '$_id.name',
        value: 1,
        value2: 1,
        value3: 1,
        total: 1
      }
    },
    {
      $sort: {
        nameUnit: 1
      }
    }
    ]
    mongo.aggregate('attached', pipeline, {}, (err, docs) => {
      if (err) console.log(err)
      var total = {
        nameUnit: 'Total',
        value: 0,
        value2: 0,
        value3: 0,
        total: 0
      }
      if (docs.forEach) {
        docs.forEach((doc) => {
          total.value += doc.value
          total.value2 += doc.value2
          total.value3 += doc.value3
          total.total += doc.total
        })
      }
      docs.push(total)
      send(docs)
    })
  }

  async attachedByEjecutor (req, mongo, send) {
    var pipeline = [{
      $lookup: {
        from: 'note',
        localField: 'reference',
        foreignField: '_id',
        as: 'note'
      }
    },
    {
      $unwind: '$note'
    },
    {
      $lookup: {
        from: 'params',
        localField: 'tags',
        foreignField: 'options.id',
        as: 'par'
      }
    },
    {
      $addFields: {
        options: {
          $arrayElemAt: ['$par.options', 0]
        },
        confidential: '$note.confidential',
        actors: '$actors'
      }
    },
    {
      $match: {
        $and: [{
          status: {
            $nin: ['done', 'completed']
          }
        }, await req.app.routes.attached.$keys(req, mongo)]
      }
    },
    {
      $addFields: {
        risk: {
          $arrayElemAt: [{
            $filter: {
              input: '$options',
              as: 'risk',
              cond: {
                $eq: ['$$risk.id', {
                  $arrayElemAt: ['$tags', 0]
                }]
              }
            }
          }, 0]
        }
      }
    },
    {
      $addFields: {
        emisor: {
          $arrayElemAt: [{
            $filter: {
              input: '$actors',
              as: 'actor',
              cond: {
                $eq: ['$$actor.role', 'from']
              }
            }
          }, 0]
        }
      }
    },
    {
      $lookup: {
        from: 'unit',
        localField: 'emisor.unit',
        foreignField: '_id',
        as: 'ejecutor'
      }
    },
    {
      $unwind: '$ejecutor'
    },
    {
      $group: {
        _id: '$ejecutor.name',
        value: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'ALTO']
              },
              then: 1,
              else: 0
            }
          }
        },
        value2: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'MEDIO']
              },
              then: 1,
              else: 0
            }
          }
        },
        value3: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'OPORTUNIDAD DE MEJORA']
              },
              then: 1,
              else: 0
            }
          }
        },
        total: {
          $sum: 1
        }
      }
    },
    {
      $project: {
        _id: 0,
        nameUnit: '$_id',
        value: 1,
        value2: 1,
        value3: 1,
        total: 1
      }
    },
    {
      $sort: {
        nameUnit: 1
      }
    }
    ]
    mongo.aggregate('attached', pipeline, {}, (err, docs) => {
      if (err) console.log(err)
      var total = {
        nameUnit: 'Total',
        value: 0,
        value2: 0,
        value3: 0,
        total: 0
      }
      docs.forEach((doc) => {
        total.value += doc.value
        total.value2 += doc.value2
        total.value3 += doc.value3
        total.total += doc.total
      })
      docs.push(total)
      send(docs)
    })
  }
  async attachedByExpiration (req, mongo, send) {
    var today = new Date()
    var pipeline = [{
      $lookup: {
        from: 'note',
        localField: 'reference',
        foreignField: '_id',
        as: 'note'
      }
    },
    {
      $unwind: '$note'
    },
    {
      $lookup: {
        from: 'params',
        localField: 'tags',
        foreignField: 'options.id',
        as: 'par'
      }
    },
    {
      $addFields: {
        options: {
          $arrayElemAt: ['$par.options', 0]
        },
        confidential: '$note.confidential',
        actors: '$actors'
      }
    },
    {
      $match: {
        $and: [{
          status: {
            $in: ['processing', 'answered']
          }
        }, await req.app.routes.commitment.$keys(req, mongo)]
      }
    },
    {
      $addFields: {
        dates: {
          $arrayElemAt: [{
            $filter: {
              input: '$dates',
              as: 'date',
              cond: {
                $eq: ['$$date.type', 'deadline']
              }
            }
          }, 0]
        }
      }
    },
    {
      $addFields: {
        risk: {
          $arrayElemAt: [{
            $filter: {
              input: '$options',
              as: 'risk',
              cond: {
                $eq: ['$$risk.id', {
                  $arrayElemAt: ['$tags', 0]
                }]
              }
            }
          }, 0]
        }
      }
    },
    {
      $group: {
        _id: {
          $cond: {
            if: {
              $lt: ['$dates.value', today]
            },
            then: 'Vencidos',
            else: 'Emitidos'
          }
        },
        alto: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'ALTO']
              },
              then: 1,
              else: 0
            }
          }
        },
        medio: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'MEDIO']
              },
              then: 1,
              else: 0
            }
          }
        },
        bajo: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'OPORTUNIDAD DE MEJORA']
              },
              then: 1,
              else: 0
            }
          }
        },
      }
    },
    {
      $project: {
        _id: 0,
        id: '$_id',
        estado: '$_id',
        alto: 1,
        medio: 1,
        bajo: 1
      }
    },
    {
      $sort: {
        estado: -1
      }
    }
    ]
    mongo.aggregate('attached', pipeline, {}, (err, docs) => {
      if (err) console.log(err)
      var total = {
        id: 'Total',
        estado: 'Emitidos',
        alto: 0,
        medio: 0,
        bajo: 0
      }
      docs.forEach((doc) => {
        total.alto += doc.alto
        total.medio += doc.medio
        total.bajo += doc.bajo
      })
      docs[1] = total
      docs.push(total)
      send(docs)
    })
  }

  async findingByRisk (req, mongo, send) {
    var pipeline = [{
      $lookup: {
        from: 'note',
        localField: 'reference',
        foreignField: '_id',
        as: 'note'
      }
    },
    {
      $unwind: '$note'
    },
    {
      $lookup: {
        from: 'params',
        localField: 'tags',
        foreignField: 'options.id',
        as: 'par'
      }
    },
    {
      $addFields: {
        options: {
          $arrayElemAt: ['$par.options', 0]
        },
        confidential: '$note.confidential',
        actors: '$actors'
      }
    },
    {
      $match: {
        $and: [{
          status: {
            $in: ['processing', 'answered']
          }
        }, await req.app.routes.attached.$keys(req, mongo)]
      }
    },
    {
      $addFields: {
        risk: {
          $arrayElemAt: [{
            $filter: {
              input: '$options',
              as: 'risk',
              cond: {
                $eq: ['$$risk.id', {
                  $arrayElemAt: ['$tags', 0]
                }]
              }
            }
          }, 0]
        }
      }
    },
    {
      $lookup: {
        from: 'document',
        localField: '_id',
        foreignField: 'links._id',
        as: 'obs'
      }
    },
    {
      $unwind: '$obs'
    },
    {
      $group: {
        _id: '$obs._id',
        risk: {
          $first: '$risk'
        }
      }
    },
    {
      $group: {
        _id: '$risk.value',
        cont: {
          $sum: 1
        }
      }
    },
    {
      $project: {
        _id: 0,
        id: '$_id',
        title: '$_id',
        value: '$cont'
      }
    },
    {
      $sort: {
        title: 1
      }
    }
    ]
    mongo.aggregate('attached', pipeline, {}, async (err, docs) => {
      if (err) {
        send(err)
      } else {
        var total = 0
        docs.forEach((doc) => {
          total += doc.value
        })
        docs.forEach((doc) => {
          doc.total = total
        })
        send(docs)
      }
    })
  }

  async findingByUnit (req, mongo, send) {
    var units
    if (!req.session.context.licensedUser) {
      units = req.session.context.managerUnits.concat(req.session.context.assistantUnits)
    } else {
      units = await new Promise(resolve => {
        mongo.findOne('settings', {
          _id: 'settings'
        }, {
          directory: 1
        }, (er, doc) => {
          resolve(doc.directory)
        })
      })
    }
    units = await req.app.routes.note.$subunits(mongo, units)
    var pipeline = [{
      $lookup: {
        from: 'note',
        localField: 'reference',
        foreignField: '_id',
        as: 'note'
      }
    },
    {
      $unwind: '$note'
    },
    {
      $lookup: {
        from: 'params',
        localField: 'tags',
        foreignField: 'options.id',
        as: 'par'
      }
    },
    {
      $addFields: {
        options: {
          $arrayElemAt: ['$par.options', 0]
        },
        confidential: '$note.confidential',
        actors: '$actors'
      }
    },
    {
      $match: {
        $and: [{
          status: {
            $in: ['processing', 'answered']
          }
        }, await req.app.routes.attached.$keys(req, mongo)]
      }
    },
    {
      $addFields: {
        risk: {
          $arrayElemAt: [{
            $filter: {
              input: '$options',
              as: 'risk',
              cond: {
                $eq: ['$$risk.id', {
                  $arrayElemAt: ['$tags', 0]
                }]
              }
            }
          }, 0]
        }
      }
    },
    {
      $addFields: {
        gerencia: {
          $arrayElemAt: [{
            $filter: {
              input: '$actors',
              as: 'actor',
              cond: {
                $eq: ['$$actor.role', 'responsible']
              }
            }
          }, 0]
        }
      }
    },
    {
      $addFields: {
        gerencia: {
          $filter: {
            input: units,
            as: 'director',
            cond: {
              $in: ['$gerencia.unit', '$$director.dependents']
            }
          }
        }
      }
    },
    {
      $lookup: {
        from: 'unit',
        localField: 'gerencia.unit',
        foreignField: '_id',
        as: 'gerencia'
      }
    },
    {
      $unwind: '$gerencia'
    },
    {
      $lookup: {
        from: 'document',
        localField: '_id',
        foreignField: 'links._id',
        as: 'obs'
      }
    },
    {
      $unwind: '$obs'
    },
    {
      $group: {
        _id: '$obs._id',
        gerencia: {
          $first: '$gerencia'
        },
        risk: {
          $first: '$risk'
        }
      }
    },
    {
      $group: {
        _id: {
          code: '$gerencia.code',
          name: '$gerencia.name'
        },
        value: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'ALTO']
              },
              then: 1,
              else: 0
            }
          }
        },
        value2: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'MEDIO']
              },
              then: 1,
              else: 0
            }
          }
        },
        value3: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'OPORTUNIDAD DE MEJORA']
              },
              then: 1,
              else: 0
            }
          }
        },
        total: {
          $sum: 1
        }
      }
    },
    {
      $project: {
        _id: 0,
        nameUnit: '$_id.name',
        value: 1,
        value2: 1,
        value3: 1,
        total: 1
      }
    },
    {
      $sort: {
        nameUnit: 1
      }
    }
    ]
    mongo.aggregate('attached', pipeline, {}, (err, docs) => {
      if (err) console.log(err)
      var total = {
        nameUnit: 'Total',
        value: 0,
        value2: 0,
        value3: 0,
        total: 0
      }
      if (docs.forEach) {
        docs.forEach((doc) => {
          total.value += doc.value
          total.value2 += doc.value2
          total.value3 += doc.value3
          total.total += doc.total
        })
      }
      docs.push(total)
      send(docs)
    })
  }

  async findingByEjecutor (req, mongo, send) {
    var pipeline = [{
      $lookup: {
        from: 'note',
        localField: 'reference',
        foreignField: '_id',
        as: 'note'
      }
    },
    {
      $unwind: '$note'
    },
    {
      $lookup: {
        from: 'params',
        localField: 'tags',
        foreignField: 'options.id',
        as: 'par'
      }
    },
    {
      $addFields: {
        options: {
          $arrayElemAt: ['$par.options', 0]
        },
        confidential: '$note.confidential',
        actors: '$actors'
      }
    },
    {
      $match: {
        $and: [{
          status: {
            $nin: ['done', 'completed']
          }
        }, await req.app.routes.attached.$keys(req, mongo)]
      }
    },
    {
      $addFields: {
        risk: {
          $arrayElemAt: [{
            $filter: {
              input: '$options',
              as: 'risk',
              cond: {
                $eq: ['$$risk.id', {
                  $arrayElemAt: ['$tags', 0]
                }]
              }
            }
          }, 0]
        }
      }
    },
    {
      $addFields: {
        emisor: {
          $arrayElemAt: [{
            $filter: {
              input: '$actors',
              as: 'actor',
              cond: {
                $eq: ['$$actor.role', 'from']
              }
            }
          }, 0]
        }
      }
    },
    {
      $lookup: {
        from: 'unit',
        localField: 'emisor.unit',
        foreignField: '_id',
        as: 'ejecutor'
      }
    },
    {
      $unwind: '$ejecutor'
    },
    {
      $lookup: {
        from: 'document',
        localField: '_id',
        foreignField: 'links._id',
        as: 'obs'
      }
    },
    {
      $unwind: '$obs'
    },
    {
      $group: {
        _id: '$obs._id',
        ejecutor: {
          $first: '$ejecutor'
        },
        risk: {
          $first: '$risk'
        }
      }
    },
    {
      $group: {
        _id: '$ejecutor.name',
        value: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'ALTO']
              },
              then: 1,
              else: 0
            }
          }
        },
        value2: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'MEDIO']
              },
              then: 1,
              else: 0
            }
          }
        },
        value3: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'OPORTUNIDAD DE MEJORA']
              },
              then: 1,
              else: 0
            }
          }
        },
        total: {
          $sum: 1
        }
      }
    },
    {
      $project: {
        _id: 0,
        nameUnit: '$_id',
        value: 1,
        value2: 1,
        value3: 1,
        total: 1
      }
    },
    {
      $sort: {
        nameUnit: 1
      }
    }
    ]
    mongo.aggregate('attached', pipeline, {}, (err, docs) => {
      if (err) console.log(err)
      var total = {
        nameUnit: 'Total',
        value: 0,
        value2: 0,
        value3: 0,
        total: 0
      }
      docs.forEach((doc) => {
        total.value += doc.value
        total.value2 += doc.value2
        total.value3 += doc.value3
        total.total += doc.total
      })
      docs.push(total)
      send(docs)
    })
  }
  async findingByExpiration (req, mongo, send) {
    var today = new Date()
    var pipeline = [{
      $lookup: {
        from: 'note',
        localField: 'reference',
        foreignField: '_id',
        as: 'note'
      }
    },
    {
      $unwind: '$note'
    },
    {
      $lookup: {
        from: 'params',
        localField: 'tags',
        foreignField: 'options.id',
        as: 'par'
      }
    },
    {
      $addFields: {
        options: {
          $arrayElemAt: ['$par.options', 0]
        },
        confidential: '$note.confidential',
        actors: '$actors'
      }
    },
    {
      $match: {
        $and: [{
          status: {
            $in: ['processing', 'answered']
          }
        }, await req.app.routes.commitment.$keys(req, mongo)]
      }
    },
    {
      $addFields: {
        dates: {
          $arrayElemAt: [{
            $filter: {
              input: '$dates',
              as: 'date',
              cond: {
                $eq: ['$$date.type', 'deadline']
              }
            }
          }, 0]
        }
      }
    },
    {
      $addFields: {
        risk: {
          $arrayElemAt: [{
            $filter: {
              input: '$options',
              as: 'risk',
              cond: {
                $eq: ['$$risk.id', {
                  $arrayElemAt: ['$tags', 0]
                }]
              }
            }
          }, 0]
        }
      }
    },
    {
      $lookup: {
        from: 'document',
        localField: '_id',
        foreignField: 'links._id',
        as: 'obs'
      }
    },
    {
      $unwind: '$obs'
    },
    {
      $group: {
        _id: '$obs._id',
        dates: {
          $first: '$dates'
        },
        risk: {
          $first: '$risk'
        }
      }
    },
    {
      $group: {
        _id: {
          $cond: {
            if: {
              $lt: ['$dates.value', today]
            },
            then: 'Vencidos',
            else: 'Emitidos'
          }
        },
        alto: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'ALTO']
              },
              then: 1,
              else: 0
            }
          }
        },
        medio: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'MEDIO']
              },
              then: 1,
              else: 0
            }
          }
        },
        bajo: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$risk.value', 'OPORTUNIDAD DE MEJORA']
              },
              then: 1,
              else: 0
            }
          }
        },
      }
    },
    {
      $project: {
        _id: 0,
        id: '$_id',
        estado: '$_id',
        alto: 1,
        medio: 1,
        bajo: 1
      }
    },
    {
      $sort: {
        estado: -1
      }
    }
    ]
    mongo.aggregate('attached', pipeline, {}, (err, docs) => {
      if (err) console.log(err)
      var total = {
        id: 'Total',
        estado: 'Emitidos',
        alto: 0,
        medio: 0,
        bajo: 0
      }
      docs.forEach((doc) => {
        total.alto += doc.alto
        total.medio += doc.medio
        total.bajo += doc.bajo
      })
      docs[1] = total
      docs.push(total)
      send(docs)
    })
  }

  async notesByStatus (req, mongo, send) {
    var pipeline = [{
      $lookup: {
        from: 'unit',
        pipeline: [{
          $project: {
            _id: 1,
            name: 1
          }
        }],
        as: 'tunit'
      }
    },
    {
      $addFields: {
        UnidadDe: {
          $filter: {
            input: {
              $ifNull: ['$actors', []]
            },
            as: 'data',
            cond: {
              $eq: ['$$data.role', 'from']
            }
          }
        },
        UnidadReviser: {
          $filter: {
            input: {
              $ifNull: ['$actors', []]
            },
            as: 'data',
            cond: {
              $eq: ['$$data.role', 'reviser']
            }
          }
        },
      }
    },
    {
      $addFields: {
        UnidadDe: {
          $ifNull: [{
            $arrayElemAt: ['$UnidadDe.unit', 0]
          }, {
            $arrayElemAt: ['$UnidadReviser.unit', 0]
          }]
        },
      }
    },
    {
      $addFields: {
        UnidadDe: {
          $ifNull: ['$UnidadDe', 0]
        },
      }
    },
    {
      $project: {
        _id: 1,
        UnidadDe: {
          $cond: {
            if: {
              $eq: ['$UnidadDe', 0]
            },
            then: '',
            else: {
              $ifNull: [{
                $arrayElemAt: ['$tunit.name', {
                  $indexOfArray: ['$tunit._id', '$UnidadDe']
                }]
              }, '']
            }
          }
        },
        dates: 1,
        status: 1
      }
    },
    {
      $match: {
        UnidadDe: {
          $ne: ''
        }
      }
    },
    {
      $group: {
        _id: '$UnidadDe',
        draft: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'draft']
              },
              then: 1,
              else: 0
            }
          }
        },
        processing: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'processing']
              },
              then: 1,
              else: 0
            }
          }
        },
        attended: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'attended']
              },
              then: 1,
              else: 0
            }
          }
        },
        archived: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'archived']
              },
              then: 1,
              else: 0
            }
          }
        },
        annulled: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'annulled']
              },
              then: 1,
              else: 0
            }
          }
        },
        total: {
          $sum: 1
        }
      }
    },
    {
      $project: {
        _id: 0,
        name: '$_id',
        draft: 1,
        processing: 1,
        attended: 1,
        archived: 1,
        annulled: 1,
        total: 1
      }
    },
    {
      $sort: {
        name: -1
      }
    }
    ]
    mongo.aggregate('note', pipeline, {}, async (err, docs) => {
      if (err) console.log(err)
      var total = {
        name: 'Total',
        draft: 0,
        processing: 0,
        attended: 0,
        archived: 0,
        annulled: 0,
        total: 0
      }
      docs.forEach((doc) => {
        total.draft += doc.draft
        total.processing += doc.processing
        total.attended += doc.attended
        total.archived += doc.archived
        total.annulled += doc.annulled
        total.total += doc.total
      })
      docs.push(total)
      send(docs)
    })
  }

  async notesByStatusReceiver (req, mongo, send) {
    var pipeline = [{
      $lookup: {
        from: 'unit',
        pipeline: [{
          $project: {
            _id: 1,
            name: 1
          }
        }],
        as: 'tunit'
      }
    },
    {
      $addFields: {
        UnidadPara: {
          $filter: {
            input: {
              $ifNull: ['$actors', []]
            },
            as: 'data',
            cond: {
              $eq: ['$$data.role', 'to']
            }
          }
        },
      }
    },
    {
      $addFields: {
        UnidadPara: {
          $ifNull: [{
            $arrayElemAt: ['$UnidadPara.unit', 0]
          }, 0]
        },
      }
    },
    {
      $addFields: {
        UnidadPara: {
          $ifNull: ['$UnidadPara', 0]
        },
      }
    },
    {
      $project: {
        _id: 1,
        UnidadPara: {
          $cond: {
            if: {
              $eq: ['$UnidadPara', 0]
            },
            then: '',
            else: {
              $ifNull: [{
                $arrayElemAt: ['$tunit.name', {
                  $indexOfArray: ['$tunit._id', '$UnidadPara']
                }]
              }, '']
            }
          }
        },
        dates: 1,
        status: 1
      }
    },
    {
      $match: {
        UnidadPara: {
          $ne: ''
        }
      }
    },
    {
      $group: {
        _id: '$UnidadPara',
        draft: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'draft']
              },
              then: 1,
              else: 0
            }
          }
        },
        processing: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'processing']
              },
              then: 1,
              else: 0
            }
          }
        },
        attended: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'attended']
              },
              then: 1,
              else: 0
            }
          }
        },
        archived: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'archived']
              },
              then: 1,
              else: 0
            }
          }
        },
        annulled: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'annulled']
              },
              then: 1,
              else: 0
            }
          }
        },
        total: {
          $sum: 1
        }
      }
    },
    {
      $project: {
        _id: 0,
        name: '$_id',
        draft: 1,
        processing: 1,
        attended: 1,
        archived: 1,
        annulled: 1,
        total: 1
      }
    },
    {
      $sort: {
        name: -1
      }
    }
    ]
    mongo.aggregate('note', pipeline, {}, async (err, docs) => {
      if (err) console.log(err)
      var total = {
        name: 'Total',
        draft: 0,
        processing: 0,
        attended: 0,
        archived: 0,
        annulled: 0,
        total: 0
      }
      docs.forEach((doc) => {
        total.draft += doc.draft
        total.processing += doc.processing
        total.attended += doc.attended
        total.archived += doc.archived
        total.annulled += doc.annulled
        total.total += doc.total
      })
      docs.push(total)
      send(docs)
    })
  }

  notesByDeadline (req, mongo, send) {
    let today = new Date()
    let pipeline = [{
      $lookup: {
        from: 'unit',
        pipeline: [{
          $project: {
            _id: 1,
            name: 1
          }
        }],
        as: 'tunit'
      }
    },
    {
      $addFields: {
        UnidadDe: {
          $filter: {
            input: {
              $ifNull: ['$actors', []]
            },
            as: 'data',
            cond: {
              $eq: ['$$data.role', 'from']
            }
          }
        },
        UnidadReviser: {
          $filter: {
            input: {
              $ifNull: ['$actors', []]
            },
            as: 'data',
            cond: {
              $eq: ['$$data.role', 'reviser']
            }
          }
        },
      }
    },
    {
      $addFields: {
        UnidadDe: {
          $ifNull: [{
            $arrayElemAt: ['$UnidadDe.unit', 0]
          }, {
            $arrayElemAt: ['$UnidadReviser.unit', 0]
          }]
        },
        deadline: {
          $ifNull: [{
            $arrayElemAt: [{
              $filter: {
                input: '$dates',
                as: 'date',
                cond: {
                  $eq: ['$$date.type', 'deadline']
                }
              }
            }, 0]
          }, today]
        },
      }
    },
    {
      $addFields: {
        UnidadDe: {
          $ifNull: ['$UnidadDe', 0]
        },
      }
    },
    {
      $project: {
        _id: 1,
        dates: 1,
        UnidadDe: {
          $cond: {
            if: {
              $eq: ['$UnidadDe', 0]
            },
            then: '',
            else: {
              $ifNull: [{
                $arrayElemAt: ['$tunit.name', {
                  $indexOfArray: ['$tunit._id', '$UnidadDe']
                }]
              }, '']
            }
          }
        },
        deadline: {
          $cond: {
            if: {
              $and: [{
                $lt: [{
                  $ifNull: ['$deadline', 0]
                }, today]
              }, {
                $eq: ['$status', 'processing']
              }]
            },
            then: 1,
            else: 0
          }
        },
        status: 1
      }
    },
    {
      $match: {
        UnidadDe: {
          $ne: ''
        }
      }
    },
    {
      $group: {
        _id: '$UnidadDe',
        value: {
          $sum: '$deadline'
        },
        total: {
          $sum: 1
        }
      }
    },
    {
      $project: {
        _id: 0,
        name: '$_id',
        value: 1,
        total: 1
      }
    },
    {
      $sort: {
        name: -1
      }
    }
    ]
    mongo.aggregate('note', pipeline, {}, async (err, docs) => {
      if (err) console.log(err)
      var total = {
        name: 'Total',
        value: 0,
        total: 0
      }
      docs.forEach((doc) => {
        total.value += doc.value
        total.total += doc.total
      })
      docs.push(total)
      send(docs)
    })
  }

  notesByDeadlineReceiver (req, mongo, send) {
    let today = new Date()
    let pipeline = [{
      $lookup: {
        from: 'unit',
        pipeline: [{
          $project: {
            _id: 1,
            name: 1
          }
        }],
        as: 'tunit'
      }
    },
    {
      $addFields: {
        UnidadPara: {
          $filter: {
            input: {
              $ifNull: ['$actors', []]
            },
            as: 'data',
            cond: {
              $eq: ['$$data.role', 'to']
            }
          }
        },
      }
    },
    {
      $addFields: {
        UnidadPara: {
          $ifNull: [{
            $arrayElemAt: ['$UnidadPara.unit', 0]
          }, 0]
        },
        deadline: {
          $ifNull: [{
            $arrayElemAt: [{
              $filter: {
                input: '$dates',
                as: 'date',
                cond: {
                  $eq: ['$$date.type', 'deadline']
                }
              }
            }, 0]
          }, today]
        },
      }
    },
    {
      $addFields: {
        UnidadPara: {
          $ifNull: ['$UnidadPara', 0]
        },
      }
    },
    {
      $project: {
        _id: 1,
        dates: 1,
        UnidadPara: {
          $cond: {
            if: {
              $eq: ['$UnidadPara', 0]
            },
            then: '',
            else: {
              $ifNull: [{
                $arrayElemAt: ['$tunit.name', {
                  $indexOfArray: ['$tunit._id', '$UnidadPara']
                }]
              }, '']
            }
          }
        },
        deadline: {
          $cond: {
            if: {
              $and: [{
                $lt: [{
                  $ifNull: ['$deadline', 0]
                }, today]
              }, {
                $eq: ['$status', 'processing']
              }]
            },
            then: 1,
            else: 0
          }
        },
        status: 1
      }
    },
    {
      $match: {
        UnidadPara: {
          $ne: ''
        }
      }
    },
    {
      $group: {
        _id: '$UnidadPara',
        value: {
          $sum: '$deadline'
        },
        total: {
          $sum: 1
        }
      }
    },
    {
      $project: {
        _id: 0,
        name: '$_id',
        value: 1,
        total: 1
      }
    },
    {
      $sort: {
        name: -1
      }
    }
    ]
    mongo.aggregate('note', pipeline, {}, async (err, docs) => {
      if (err) console.log(err)
      var total = {
        name: 'Total',
        value: 0,
        total: 0
      }
      docs.forEach((doc) => {
        total.value += doc.value
        total.total += doc.total
      })
      docs.push(total)
      send(docs)
    })
  }

  async attachedByStatus (req, mongo, send) {
    var pipeline = [{
      $lookup: {
        from: 'unit',
        pipeline: [{
          $project: {
            _id: 1,
            name: 1
          }
        }],
        as: 'tunit'
      }
    },
    {
      $addFields: {
        UnidadDe: {
          $filter: {
            input: {
              $ifNull: ['$actors', []]
            },
            as: 'data',
            cond: {
              $eq: ['$$data.role', 'from']
            }
          }
        },
        UnidadReviser: {
          $filter: {
            input: {
              $ifNull: ['$actors', []]
            },
            as: 'data',
            cond: {
              $eq: ['$$data.role', 'reviser']
            }
          }
        },
      }
    },
    {
      $addFields: {
        UnidadDe: {
          $ifNull: [{
            $arrayElemAt: ['$UnidadDe.unit', 0]
          }, {
            $arrayElemAt: ['$UnidadReviser.unit', 0]
          }]
        },
      }
    },
    {
      $addFields: {
        UnidadDe: {
          $ifNull: ['$UnidadDe', 0]
        },
      }
    },
    {
      $project: {
        _id: 1,
        UnidadDe: {
          $cond: {
            if: {
              $eq: ['$UnidadDe', 0]
            },
            then: '',
            else: {
              $ifNull: [{
                $arrayElemAt: ['$tunit.name', {
                  $indexOfArray: ['$tunit._id', '$UnidadDe']
                }]
              }, '']
            }
          }
        },
        dates: 1,
        status: 1
      }
    },
    {
      $match: {
        UnidadDe: {
          $ne: ''
        }
      }
    },
    {
      $group: {
        _id: '$UnidadDe',
        prepared: {
          $sum: {
            $cond: {
              if: {
                $or: [{
                  $eq: ['$status', 'prepared']
                }, {
                  $eq: ['$status', 'draft']
                }]
              },
              then: 1,
              else: 0
            }
          }
        },
        processing: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'processing']
              },
              then: 1,
              else: 0
            }
          }
        },
        answered: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'answered']
              },
              then: 1,
              else: 0
            }
          }
        },
        completed: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'completed']
              },
              then: 1,
              else: 0
            }
          }
        },
        annulled: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'annulled']
              },
              then: 1,
              else: 0
            }
          }
        },
        total: {
          $sum: 1
        }
      }
    },
    {
      $project: {
        _id: 0,
        name: '$_id',
        prepared: 1,
        processing: 1,
        answered: 1,
        completed: 1,
        annulled: 1,
        total: 1
      }
    },
    {
      $sort: {
        name: -1
      }
    }
    ]
    mongo.aggregate('attached', pipeline, {}, async (err, docs) => {
      if (err) console.log(err)
      var total = {
        name: 'Total',
        prepared: 0,
        processing: 0,
        answered: 0,
        completed: 0,
        annulled: 0,
        total: 0
      }
      docs.forEach((doc) => {
        total.prepared += doc.prepared
        total.processing += doc.processing
        total.answered += doc.answered
        total.completed += doc.completed
        total.annulled += doc.annulled
        total.total += doc.total
      })
      docs.push(total)
      send(docs)
    })
  }

  async attachedByStatusReceiver (req, mongo, send) {
    var pipeline = [{
      $lookup: {
        from: 'unit',
        pipeline: [{
          $project: {
            _id: 1,
            name: 1
          }
        }],
        as: 'tunit'
      }
    },
    {
      $addFields: {
        UnidadPara: {
          $filter: {
            input: {
              $ifNull: ['$actors', []]
            },
            as: 'data',
            cond: {
              $eq: ['$$data.role', 'responsible']
            }
          }
        },
      }
    },
    {
      $addFields: {
        UnidadPara: {
          $ifNull: [{
            $arrayElemAt: ['$UnidadPara.unit', 0]
          }, 0]
        },
      }
    },
    {
      $addFields: {
        UnidadPara: {
          $ifNull: ['$UnidadPara', 0]
        },
      }
    },
    {
      $project: {
        _id: 1,
        UnidadPara: {
          $cond: {
            if: {
              $eq: ['$UnidadPara', 0]
            },
            then: '',
            else: {
              $ifNull: [{
                $arrayElemAt: ['$tunit.name', {
                  $indexOfArray: ['$tunit._id', '$UnidadPara']
                }]
              }, '']
            }
          }
        },
        dates: 1,
        status: 1
      }
    },
    {
      $match: {
        UnidadPara: {
          $ne: ''
        }
      }
    },
    {
      $group: {
        _id: '$UnidadPara',
        prepared: {
          $sum: {
            $cond: {
              if: {
                $or: [{
                  $eq: ['$status', 'prepared']
                }, {
                  $eq: ['$status', 'draft']
                }]
              },
              then: 1,
              else: 0
            }
          }
        },
        processing: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'processing']
              },
              then: 1,
              else: 0
            }
          }
        },
        answered: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'answered']
              },
              then: 1,
              else: 0
            }
          }
        },
        completed: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'completed']
              },
              then: 1,
              else: 0
            }
          }
        },
        annulled: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'annulled']
              },
              then: 1,
              else: 0
            }
          }
        },
        total: {
          $sum: 1
        }
      }
    },
    {
      $project: {
        _id: 0,
        name: '$_id',
        prepared: 1,
        processing: 1,
        answered: 1,
        completed: 1,
        annulled: 1,
        total: 1
      }
    },
    {
      $sort: {
        name: -1
      }
    }
    ]
    mongo.aggregate('attached', pipeline, {}, async (err, docs) => {
      if (err) console.log(err)
      var total = {
        name: 'Total',
        prepared: 0,
        processing: 0,
        answered: 0,
        completed: 0,
        annulled: 0,
        total: 0
      }
      docs.forEach((doc) => {
        total.prepared += doc.prepared
        total.processing += doc.processing
        total.answered += doc.answered
        total.completed += doc.completed
        total.annulled += doc.annulled
        total.total += doc.total
      })
      docs.push(total)
      send(docs)
    })
  }

  attachedsByDeadline (req, mongo, send) {
    let today = new Date()
    let pipeline = [{
      $lookup: {
        from: 'unit',
        pipeline: [{
          $project: {
            _id: 1,
            name: 1
          }
        }],
        as: 'tunit'
      }
    },
    {
      $addFields: {
        UnidadDe: {
          $filter: {
            input: {
              $ifNull: ['$actors', []]
            },
            as: 'data',
            cond: {
              $eq: ['$$data.role', 'from']
            }
          }
        },
        UnidadReviser: {
          $filter: {
            input: {
              $ifNull: ['$actors', []]
            },
            as: 'data',
            cond: {
              $eq: ['$$data.role', 'reviser']
            }
          }
        },
      }
    },
    {
      $addFields: {
        UnidadDe: {
          $ifNull: [{
            $arrayElemAt: ['$UnidadDe.unit', 0]
          }, {
            $arrayElemAt: ['$UnidadReviser.unit', 0]
          }]
        },
        deadline: {
          $ifNull: [{
            $arrayElemAt: [{
              $filter: {
                input: '$dates',
                as: 'date',
                cond: {
                  $eq: ['$$date.type', 'deadline']
                }
              }
            }, 0]
          }, today]
        },
      }
    },
    {
      $addFields: {
        UnidadDe: {
          $ifNull: ['$UnidadDe', 0]
        },
      }
    },
    {
      $project: {
        _id: 1,
        dates: 1,
        UnidadDe: {
          $cond: {
            if: {
              $eq: ['$UnidadDe', 0]
            },
            then: '',
            else: {
              $ifNull: [{
                $arrayElemAt: ['$tunit.name', {
                  $indexOfArray: ['$tunit._id', '$UnidadDe']
                }]
              }, '']
            }
          }
        },
        deadline: {
          $cond: {
            if: {
              $and: [{
                $lt: [{
                  $ifNull: ['$deadline', 0]
                }, today]
              }, {
                $or: [{
                  $eq: ['$status', 'processing']
                }, {
                  $eq: ['$status', 'answered']
                }]
              }]
            },
            then: 1,
            else: 0
          }
        },
        status: 1
      }
    },
    {
      $match: {
        UnidadDe: {
          $ne: ''
        }
      }
    },
    {
      $group: {
        _id: '$UnidadDe',
        value: {
          $sum: '$deadline'
        },
        total: {
          $sum: 1
        }
      }
    },
    {
      $project: {
        _id: 0,
        name: '$_id',
        value: 1,
        total: 1
      }
    },
    {
      $sort: {
        name: -1
      }
    }
    ]
    mongo.aggregate('attached', pipeline, {}, async (err, docs) => {
      if (err) console.log(err)
      var total = {
        name: 'Total',
        value: 0,
        total: 0
      }
      docs.forEach((doc) => {
        total.value += doc.value
        total.total += doc.total
      })
      docs.push(total)
      send(docs)
    })
  }

  attachedsByDeadlineReceiver (req, mongo, send) {
    let today = new Date()
    let pipeline = [{
      $lookup: {
        from: 'unit',
        pipeline: [{
          $project: {
            _id: 1,
            name: 1
          }
        }],
        as: 'tunit'
      }
    },
    {
      $addFields: {
        UnidadPara: {
          $filter: {
            input: {
              $ifNull: ['$actors', []]
            },
            as: 'data',
            cond: {
              $eq: ['$$data.role', 'responsible']
            }
          }
        },
      }
    },
    {
      $addFields: {
        UnidadPara: {
          $ifNull: [{
            $arrayElemAt: ['$UnidadPara.unit', 0]
          }, 0]
        },
        deadline: {
          $ifNull: [{
            $arrayElemAt: [{
              $filter: {
                input: '$dates',
                as: 'date',
                cond: {
                  $eq: ['$$date.type', 'deadline']
                }
              }
            }, 0]
          }, today]
        },
      }
    },
    {
      $addFields: {
        UnidadPara: {
          $ifNull: ['$UnidadPara', 0]
        },
      }
    },
    {
      $project: {
        _id: 1,
        dates: 1,
        UnidadPara: {
          $cond: {
            if: {
              $eq: ['$UnidadPara', 0]
            },
            then: '',
            else: {
              $ifNull: [{
                $arrayElemAt: ['$tunit.name', {
                  $indexOfArray: ['$tunit._id', '$UnidadPara']
                }]
              }, '']
            }
          }
        },
        deadline: {
          $cond: {
            if: {
              $and: [{
                $lt: [{
                  $ifNull: ['$deadline', 0]
                }, today]
              }, {
                $or: [{
                  $eq: ['$status', 'processing']
                }, {
                  $eq: ['$status', 'answered']
                }]
              }]
            },
            then: 1,
            else: 0
          }
        },
        status: 1
      }
    },
    {
      $match: {
        UnidadPara: {
          $ne: ''
        }
      }
    },
    {
      $group: {
        _id: '$UnidadPara',
        value: {
          $sum: '$deadline'
        },
        total: {
          $sum: 1
        }
      }
    },
    {
      $project: {
        _id: 0,
        name: '$_id',
        value: 1,
        total: 1
      }
    },
    {
      $sort: {
        name: -1
      }
    }
    ]
    mongo.aggregate('attached', pipeline, {}, async (err, docs) => {
      if (err) console.log(err)
      var total = {
        name: 'Total',
        value: 0,
        total: 0
      }
      docs.forEach((doc) => {
        total.value += doc.value
        total.total += doc.total
      })
      docs.push(total)
      send(docs)
    })
  }

  async commitmentByStatus (req, mongo, send) {
    var pipeline = [{
      $lookup: {
        from: 'unit',
        pipeline: [{
          $project: {
            _id: 1,
            name: 1
          }
        }],
        as: 'tunit'
      }
    },
    {
      $addFields: {
        UnidadDe: {
          $filter: {
            input: {
              $ifNull: ['$actors', []]
            },
            as: 'data',
            cond: {
              $eq: ['$$data.role', 'responsible']
            }
          }
        },
      }
    },
    {
      $addFields: {
        UnidadDe: {
          $ifNull: [{
            $arrayElemAt: ['$UnidadDe.unit', 0]
          }, 0]
        },
      }
    },
    {
      $project: {
        _id: 1,
        UnidadDe: {
          $cond: {
            if: {
              $eq: ['$UnidadDe', 0]
            },
            then: '',
            else: {
              $ifNull: [{
                $arrayElemAt: ['$tunit.name', {
                  $indexOfArray: ['$tunit._id', '$UnidadDe']
                }]
              }, '']
            }
          }
        },
        dates: 1,
        status: 1
      }
    },
    {
      $match: {
        UnidadDe: {
          $ne: ''
        }
      }
    },
    {
      $group: {
        _id: '$UnidadDe',
        accepted: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'accepted']
              },
              then: 1,
              else: 0
            }
          }
        },
        annulled: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'annulled']
              },
              then: 1,
              else: 0
            }
          }
        },
        canceled: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'canceled']
              },
              then: 1,
              else: 0
            }
          }
        },
        completed: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'completed']
              },
              then: 1,
              else: 0
            }
          }
        },
        done: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'done']
              },
              then: 1,
              else: 0
            }
          }
        },
        draft: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'draft']
              },
              then: 1,
              else: 0
            }
          }
        },
        incomplete: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'incomplete']
              },
              then: 1,
              else: 0
            }
          }
        },
        ready: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'ready']
              },
              then: 1,
              else: 0
            }
          }
        },
        returned: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'returned']
              },
              then: 1,
              else: 0
            }
          }
        },
        total: {
          $sum: 1
        }
      }
    },
    {
      $project: {
        _id: 0,
        name: '$_id',
        draft: 1,
        accepted: 1,
        annulled: 1,
        canceled: 1,
        completed: 1,
        done: 1,
        incomplete: 1,
        ready: 1,
        returned: 1,
        total: 1
      }
    },
    {
      $sort: {
        name: -1
      }
    }
    ]
    mongo.aggregate('commitment', pipeline, {}, async (err, docs) => {
      if (err) console.log(err)
      var total = {
        name: 'Total',
        draft: 0,
        accepted: 0,
        annulled: 0,
        canceled: 0,
        completed: 0,
        done: 0,
        incomplete: 0,
        ready: 0,
        returned: 0,
        total: 0
      }
      docs.forEach((doc) => {
        total.draft += doc.draft
        total.accepted += doc.accepted
        total.annulled += doc.annulled
        total.canceled += doc.canceled
        total.completed += doc.completed
        total.done += doc.done
        total.incomplete += doc.incomplete
        total.ready += doc.ready
        total.returned += doc.returned
        total.total += doc.total
      })
      docs.push(total)
      send(docs)
    })
  }

  async commitmentByStatusReceiver (req, mongo, send) {
    var pipeline = [{
      $lookup: {
        from: 'unit',
        pipeline: [{
          $project: {
            _id: 1,
            name: 1
          }
        }],
        as: 'tunit'
      }
    },
    {
      $addFields: {
        UnidadPara: {
          $filter: {
            input: {
              $ifNull: ['$actors', []]
            },
            as: 'data',
            cond: {
              $eq: ['$$data.role', 'supervisor']
            }
          }
        },
      }
    },
    {
      $addFields: {
        UnidadPara: {
          $ifNull: [{
            $arrayElemAt: ['$UnidadPara.unit', 0]
          }, 0]
        },
      }
    },
    {
      $project: {
        _id: 1,
        UnidadPara: {
          $cond: {
            if: {
              $eq: ['$UnidadPara', 0]
            },
            then: '',
            else: {
              $ifNull: [{
                $arrayElemAt: ['$tunit.name', {
                  $indexOfArray: ['$tunit._id', '$UnidadPara']
                }]
              }, '']
            }
          }
        },
        dates: 1,
        status: 1
      }
    },
    {
      $match: {
        UnidadPara: {
          $ne: ''
        }
      }
    },
    {
      $group: {
        _id: '$UnidadPara',
        accepted: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'accepted']
              },
              then: 1,
              else: 0
            }
          }
        },
        annulled: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'annulled']
              },
              then: 1,
              else: 0
            }
          }
        },
        canceled: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'canceled']
              },
              then: 1,
              else: 0
            }
          }
        },
        completed: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'completed']
              },
              then: 1,
              else: 0
            }
          }
        },
        done: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'done']
              },
              then: 1,
              else: 0
            }
          }
        },
        draft: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'draft']
              },
              then: 1,
              else: 0
            }
          }
        },
        incomplete: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'incomplete']
              },
              then: 1,
              else: 0
            }
          }
        },
        ready: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'ready']
              },
              then: 1,
              else: 0
            }
          }
        },
        returned: {
          $sum: {
            $cond: {
              if: {
                $eq: ['$status', 'returned']
              },
              then: 1,
              else: 0
            }
          }
        },
        total: {
          $sum: 1
        }
      }
    },
    {
      $project: {
        _id: 0,
        name: '$_id',
        draft: 1,
        accepted: 1,
        annulled: 1,
        canceled: 1,
        completed: 1,
        done: 1,
        incomplete: 1,
        ready: 1,
        returned: 1,
        total: 1
      }
    },
    {
      $sort: {
        name: -1
      }
    }
    ]
    mongo.aggregate('commitment', pipeline, {}, async (err, docs) => {
      if (err) console.log(err)
      var total = {
        name: 'Total',
        draft: 0,
        accepted: 0,
        annulled: 0,
        canceled: 0,
        completed: 0,
        done: 0,
        incomplete: 0,
        ready: 0,
        returned: 0,
        total: 0
      }
      docs.forEach((doc) => {
        total.draft += doc.draft
        total.accepted += doc.accepted
        total.annulled += doc.annulled
        total.canceled += doc.canceled
        total.completed += doc.completed
        total.done += doc.done
        total.incomplete += doc.incomplete
        total.ready += doc.ready
        total.returned += doc.returned
        total.total += doc.total
      })
      docs.push(total)
      send(docs)
    })
  }

  commitmentByDeadline (req, mongo, send) {
    let today = new Date()
    let pipeline = [{
      $lookup: {
        from: 'unit',
        pipeline: [{
          $project: {
            _id: 1,
            name: 1
          }
        }],
        as: 'tunit'
      }
    },
    {
      $addFields: {
        UnidadDe: {
          $filter: {
            input: {
              $ifNull: ['$actors', []]
            },
            as: 'data',
            cond: {
              $eq: ['$$data.role', 'responsible']
            }
          }
        },
      }
    },
    {
      $addFields: {
        UnidadDe: {
          $ifNull: [{
            $arrayElemAt: ['$UnidadDe.unit', 0]
          }, 0]
        },
        deadline: {
          $ifNull: [{
            $arrayElemAt: [{
              $filter: {
                input: '$dates',
                as: 'date',
                cond: {
                  $eq: ['$$date.type', 'deadline']
                }
              }
            }, 0]
          }, today]
        },
      }
    },
    {
      $project: {
        _id: 1,
        dates: 1,
        UnidadDe: {
          $cond: {
            if: {
              $eq: ['$UnidadDe', 0]
            },
            then: '',
            else: {
              $ifNull: [{
                $arrayElemAt: ['$tunit.name', {
                  $indexOfArray: ['$tunit._id', '$UnidadDe']
                }]
              }, '']
            }
          }
        },
        deadline: {
          $cond: {
            if: {
              $and: [{
                $lt: [{
                  $ifNull: ['$deadline', 0]
                }, today]
              }, {
                $and: [{
                  $ne: ['$status', 'done']
                }, {
                  $ne: ['$status', 'canceled']
                }]
              }]
            },
            then: 1,
            else: 0
          }
        },
        status: 1
      }
    },
    {
      $match: {
        UnidadDe: {
          $ne: ''
        }
      }
    },
    {
      $group: {
        _id: '$UnidadDe',
        value: {
          $sum: '$deadline'
        },
        total: {
          $sum: 1
        }
      }
    },
    {
      $project: {
        _id: 0,
        name: '$_id',
        value: 1,
        total: 1
      }
    },
    {
      $sort: {
        name: -1
      }
    }
    ]
    mongo.aggregate('commitment', pipeline, {}, async (err, docs) => {
      if (err) console.log(err)
      var total = {
        name: 'Total',
        value: 0,
        total: 0
      }
      docs.forEach((doc) => {
        total.value += doc.value
        total.total += doc.total
      })
      docs.push(total)
      send(docs)
    })
  }

  commitmentByDeadlineReceiver (req, mongo, send) {
    let today = new Date()
    let pipeline = [{
      $lookup: {
        from: 'unit',
        pipeline: [{
          $project: {
            _id: 1,
            name: 1
          }
        }],
        as: 'tunit'
      }
    },
    {
      $addFields: {
        UnidadPara: {
          $filter: {
            input: {
              $ifNull: ['$actors', []]
            },
            as: 'data',
            cond: {
              $eq: ['$$data.role', 'supervisor']
            }
          }
        },
      }
    },
    {
      $addFields: {
        UnidadPara: {
          $ifNull: [{
            $arrayElemAt: ['$UnidadPara.unit', 0]
          }, 0]
        },
        deadline: {
          $ifNull: [{
            $arrayElemAt: [{
              $filter: {
                input: '$dates',
                as: 'date',
                cond: {
                  $eq: ['$$date.type', 'deadline']
                }
              }
            }, 0]
          }, today]
        },
      }
    },
    {
      $project: {
        _id: 1,
        dates: 1,
        UnidadPara: {
          $cond: {
            if: {
              $eq: ['$UnidadPara', 0]
            },
            then: '',
            else: {
              $ifNull: [{
                $arrayElemAt: ['$tunit.name', {
                  $indexOfArray: ['$tunit._id', '$UnidadPara']
                }]
              }, '']
            }
          }
        },
        deadline: {
          $cond: {
            if: {
              $and: [{
                $lt: [{
                  $ifNull: ['$deadline', 0]
                }, today]
              }, {
                $and: [{
                  $ne: ['$status', 'done']
                }, {
                  $ne: ['$status', 'canceled']
                }]
              }]
            },
            then: 1,
            else: 0
          }
        },
        status: 1
      }
    },
    {
      $match: {
        UnidadPara: {
          $ne: ''
        }
      }
    },
    {
      $group: {
        _id: '$UnidadPara',
        value: {
          $sum: '$deadline'
        },
        total: {
          $sum: 1
        }
      }
    },
    {
      $project: {
        _id: 0,
        name: '$_id',
        value: 1,
        total: 1
      }
    },
    {
      $sort: {
        name: -1
      }
    }
    ]
    mongo.aggregate('commitment', pipeline, {}, async (err, docs) => {
      if (err) console.log(err)
      var total = {
        name: 'Total',
        value: 0,
        total: 0
      }
      docs.forEach((doc) => {
        total.value += doc.value
        total.total += doc.total
      })
      docs.push(total)
      send(docs)
    })
  }

  async horasCategoria (req, mongo, send) {
    var keys
    var myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits)
    var myAndDependentUnits = req.session.context.dependentUnits.concat(myUnits)
    keys = {
      unit: {
        $in: myAndDependentUnits
      }
    }
    var pipeline = [{
      $match: keys
    },
    {
      $lookup: {
        from: 'activity',
        localField: 'activity',
        foreignField: '_id',
        as: 'act'
      }
    },
    {
      $lookup: {
        from: 'params',
        localField: 'act.tagActivity',
        foreignField: 'options.id',
        as: 'tag'
      }
    },
    {
      $addFields: {
        options: {
          $arrayElemAt: ['$par.options', 0]
        }
      }
    },
    {
      $addFields: {
        categ: {
          $arrayElemAt: [{
            $filter: {
              input: '$options',
              as: 'i',
              cond: {
                $eq: ['$$i.id', {
                  $arrayElemAt: ['$act.tagActivity', 0]
                }]
              }
            }
          }, 0]
        }
      }
    },
    {
      $group: {
        _id: {
          $ifNull: ['$categ.value', 'Sin categoria']
        },
        cont: {
          $sum: 1
        }
      }
    },
    {
      $project: {
        _id: 0,
        id: '$_id',
        title: '$_id',
        value: '$cont'
      }
    },
    {
      $sort: {
        title: 1
      }
    }
    ]
    mongo.aggregate('time', pipeline, {}, async (err, docs) => {
      if (err) {
        send(err)
      } else {
        docs = [{
          id: 'ventas',
          title: 'Ventas',
          value: 400
        },
        {
          id: 'negocios',
          title: 'Negocios',
          value: 200
        }
        ]
        var total = 0
        docs.forEach((doc) => {
          total += doc.value
        })
        docs.forEach((doc) => {
          doc.total = total
        })
        send(docs)
      }
    })
  }

  async horasCategoriaGerencia (req, mongo, send) {
    send()
  }

  async horasGerencia (req, mongo, send) {
    send()
  }
}
exports.Indicator = Indicator