var app = require('./utils/main')

app.init({
  session: 'mongodb://gpax1/demo',
  user: 'mongodb://gpax1/demo',
  notify: 'mongodb://gpax1/demo',
  log: 'mongodb://gpax1/demo',
  outlook: 'gpax.io',
  logger: 'full',
  host: '127.0.0.1',
  port: process.argv[2] || 8083,
  ebillEnvironment: 'Produccion'
})