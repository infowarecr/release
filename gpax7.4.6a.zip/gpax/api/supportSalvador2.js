var app = require('./utils/main')
var os = require('os')
app.init({
    session: 'mongodb://localhost:28017/sessions',
    user: 'mongodb://localhost:28017/support',
    log: 'mongodb://localhost:28017/logs',
    notify: 'mongodb://localhost:28017/notify',
    background: 'mongodb://localhost:28017/ebill',
    outlook: os.hostname(),
    logger: 'full',
    port: process.argv[2] || 8081
})