var Mongo = require('./utils/mongo').Mongo
var fs = require('fs')
var { EJSON } = require('bson')
var moment = require('moment')
var urlMongo = process.argv[2]
if (!urlMongo || urlMongo.length === 0) {
  console.log('Invalid parameters: urlMongo -> expected')
  process.exit()
}

let databases = fs.readFileSync(__dirname + '/backup/databases.txt', 'utf-8').split(',')
var flag = true
var cambiosGlobal
var dbname
var resumeToken
run()

async function run() {
  try {
    var dir = __dirname + '/backup'
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir)
    }
  } catch (e) {
    console.log("Cannot create folder ", e)
    process.exit(0)
  }
  for (let d in databases) {
    await new Promise(resolve => {
      var db = new Mongo(urlMongo + databases[d])
      let archivo
      if (fs.existsSync(__dirname + '/backup/' + db.dbname + '/control.txt')) {
        archivo = fs.readFileSync(__dirname + '/backup/' + db.dbname + '/control.txt', 'utf-8')
      }
      let opts = {
        maxAwaitTimeMS: 1000,
        //startAtOperationTime : db.timestamp(new Date('/2021/11/24/').getTime(), new Date('/2021/11/24/').getTime() / 1000)
        resumeAfter: {
          "_data": "82619418FA000000022B022C0100296E5A100414ADE96FAFFC4D3D9573C6A25218CDF246645F69640064619418FAC395AE1E649E605C0004"
          //"_data": "82619685BA000000032B022C0100296E5A1004034C395CEEEB4D9E955147C530F3F6EC46645F69640064619685BA03E2DD31BDAAC2E90004"
        }
      }
      if (archivo) {
        opts.resumeAfter = {
          "_data": JSON.parse(archivo).startAfter
        }
      }
      var sTO = setInterval(async function () {
        if (flag) {
          clearInterval(sTO)
          cambiosGlobal.close(async (err, res) => {
            await crearControl(dbname, resumeToken)
            resolve()
          })
        }
      }, 10000)
      db.changes([], opts, procesar)
    })
  }
  process.exit(0)
}


async function procesar(cambios) {
  cambiosGlobal = cambios
  while (true) {
    flag = true
    await new Promise(resolve => {
      cambios.next((err, doc) => {
        flag = false
        if (doc) {
          console.log(resumeToken)
          dbname = doc.ns.db
          let dir = __dirname + '/backup/' + dbname
          if (!fs.existsSync(dir)){
            fs.mkdirSync(dir)
          }
          resumeToken = doc._id._data
          fs.appendFileSync(__dirname + '/backup/' + dbname + '/' + moment().format('YYYYMMDD') + '.txt', EJSON.stringify(doc, { relaxed: false }))
          fs.appendFileSync(__dirname + '/backup/' + dbname + '/' + moment().format('YYYYMMDD') + '.txt', '\r\n')
        }
        resolve()
      })
    })
  }
}

async function crearControl(dbname, resumeToken) {
  try{
    if (fs.existsSync(__dirname + '/backup/' + dbname + '/' + moment().format('YYYYMMDD') + '.txt')) {
      let control = {
        time: new Date(),
        dbname: dbname,
        startAfter: resumeToken,
        lastFile: moment().format('YYYYMMDD') + '.txt'
      }
      fs.writeFileSync(__dirname + '/backup/' + dbname + '/control.txt', JSON.stringify(control))
    }
  }catch (e){
      console.log(e)
      process.exit(0)
  }
}

/* {
  "_id": {
    "_data": "82619418FA000000022B022C0100296E5A100414ADE96FAFFC4D3D9573C6A25218CDF246645F69640064619418FAC395AE1E649E605C0004"
  },
  "operationType": "insert",
    "clusterTime": "Timestamp(1637095674, 2)",
    "fullDocument": {
      "_id": "619418fac395ae1e649e605c",
      "caller": "JetApp.app.tabShow",
      "key": "Papeles de trabajo",
      "lang": "es",
      "translate": "Papeles de trabajo"
  },
  "ns": {
    "db": "gpax",
      "coll": "locale"
  },
  "documentKey": {
    "_id": "619418fac395ae1e649e605c"
  }
} */