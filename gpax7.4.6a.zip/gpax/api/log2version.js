var Mongo = require('mongodb')

if (process.argv.length === 4) {
  var urlBase = process.argv[2]
  var db = process.argv[3]
  Mongo.MongoClient.connect(urlBase, { useUnifiedTopology: true, useNewUrlParser: true }, async (er, client) => {
    var logs = client.db('logs')
    var log = logs.collection('log.bacup').aggregate()
    log.match({
      url: /.save/,
      origin: new RegExp(db),
      'output.message': 'savedChanges'
    })
    log.project({
      $project: {
        ip: 1,
        user: 1,
        type: { $arrayElemAt: [{ $split: [{ $arrayElemAt: [{ $split: ['$url', '/'] }, 1] }, '.'] }, 0] },
        data: '$input'
      }
    })
    log.out({
      $merge: {
        into: { db: db, coll: 'version' },
        on: '_id',
        whenMatched: 'keepExisting',
        whenNotMatched: 'insert'
      }
    })
    log.hasNext((err) => {
      if (err) console.log(err)
      else console.log('Versiones extraídas.')
    })
  })
} else {
  console.log('Debe indicar la url base de mongodb y la base de datos para la que obtendrá los datos')
}