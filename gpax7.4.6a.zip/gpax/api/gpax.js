var app = require('./utils/main')
var os = require('os')
var db
if (os.platform() === 'win32' && process.argv[2]) {
  db=process.argv[2]
}
app.init({
  session: db || 'mongodb://localhost/sessions',
  user: db || 'mongodb://localhost/users',
  notify: db || 'mongodb://localhost/notify',
  log: db || 'mongodb://localhost/logs',
  outlook: os.platform() === 'win32' ? null : os.hostname(),
  logger: 'none',
  host: '127.0.0.1',
  port: os.platform() === 'win32' ? process.argv[3] || 8081 : process.argv[2] || 8081
})
