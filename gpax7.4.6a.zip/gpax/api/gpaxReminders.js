var tags = require('./utils/tags').tags
var nodemailer = require('nodemailer')
var CronJob = require('cron').CronJob
var urlUsers = process.argv[2]
var urlBase = process.argv[3]
if (!urlUsers || urlUsers.length === 0) {
  console.log('Invalid parameters: urlUsers -> expected')
  process.exit()
}
if (!urlBase || urlBase.length === 0) {
  console.log('Invalid parameters: urlBase -> expected')
  process.exit()
}
var Mongo = require('./utils/mongo').Mongo

console.log('Users=' + urlUsers)
console.log('urlBase=' + urlBase)

console.log('Before job instantiation')

let jobNew = new CronJob('0 1 * * *', function () {
  alarmsNew()
})
jobNew.start()


async function alarmsNew () {
  var hoy = new Date()
  hoy.setDate(hoy.getDate() + 1)
  hoy.setHours(6)
  hoy.setMinutes(0)
  var mongoUsers = new Mongo(urlUsers)
  mongoUsers.distinct('user', 'database', { active: true }, async function (err, databases) {
    if (err) { throw err }
    console.log('Scanning ' + databases.length + ' databases...')

    for (let i in databases) {
      var database = databases[i]
      console.log('Scanning ' + database)
      let mongo = new Mongo(database)

      var pipeline = [
        { $match: { _id: 'settings', checkEmail: '1' } },
        { $project: { days: 1, user: 1, password: 1, security: 1, smtp: 1, port: 1 } },
        { $addFields: { desde: { $dateAdd: { startDate: hoy, unit: 'day', amount: '$days', timezone: '-06:00' } } } },
        {
          $lookup: {
            from: 'reminders', let: { desde: '$desde' }, as: 'reminders1',
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ['$status', 'active'] },
                      { $and: [{ $lt: ['$date', '$$desde'] }, { $ne: ['$date', ''] }] },
                    ]
                  }
                }
              },
              { $unwind: '$owner' },
              {
                $lookup: {
                  from: 'user',
                  localField: 'owner.user',
                  foreignField: '_id',
                  as: 'user'
                }
              },
              { $unwind: '$user' },
              { $group: { _id: '$owner.user', count: { $sum: 1 }, email: { $first: '$user.email' }, receivedEmail: { $first: { $ifNull: ['$user.receivedEmailNotification', '1'] } } } },
            ]
          }
        },
        {
          $lookup: {
            from: 'reminders', let: { desde: '$desde' }, as: 'reminders2',
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ['$status', 'active'] },
                      { $and: [{ $lt: ['$date', '$$desde'] }, { $ne: ['$date', ''] }] },
                    ]
                  }
                }
              },
              { $unwind: '$supervisor' },
              {
                $lookup: {
                  from: 'user',
                  localField: 'supervisor.user',
                  foreignField: '_id',
                  as: 'user'
                }
              },
              { $unwind: '$user' },
              { $group: { _id: '$supervisor.user', count: { $sum: 1 }, email: { $first: '$user.email' }, receivedEmail: { $first: { $ifNull: ['$user.receivedEmailNotification', '1'] } } } },
            ]
          }
        },
        { $addFields: { reminders: { $concatArrays: ['$reminders1', '$reminders2'] } } },
        { $unwind: '$reminders' },
        {
          $group: {
            _id: '$reminders._id', count: { $sum: '$reminders.count' }, email: { $first: '$reminders.email' }, receivedEmail: { $first: '$reminders.receivedEmail' }, user: { $first: '$user' },
            password: { $first: '$password' }, security: { $first: '$security' }, smtp: { $first: '$smtp' }, port: { $first: '$port' }
          }
        },
        { $match: { receivedEmail: '1' } },
      ]
      await new Promise(resolve => {
        mongo.aggregate('settings', pipeline, {}, async (err, docs) => {
          console.log((docs ? docs.length : 0) + ' reminders')
          if (!err && docs && docs.length) {
            let reminders = docs
            for (let i in reminders) {
              let reminder = reminders[i]
              let html = '<div> Tiene algunos recordatorios, para ver más detalles haga <span class="h-entry p-name"><a class="u-url" href="' + urlBase + '/#!/home.home">Click aqui</a></span> <br></div>'



              // ************************* Pre produccion
              let email = {
                from: reminder.user, // sender address
                to: reminder.email, //'wil512on@gmail.com',// list of receivers
                subject: 'GPAX Recordatorios', // Subject line
                html: html,
                envia: (reminder.email && (reminder.receivedEmail && reminder.receivedEmail === '1') && reminder.user),
                database: database, _id: mongo.newId()
              }
              await new Promise(resolve => {
                mongoUsers.save('email', email, () => {
                  resolve()
                })
              })
              // **********************************************

              // Cuando se aprobado en pre-producción descomentar la siguiente sección
              /*if (reminder.email && (reminder.receivedEmail && reminder.receivedEmail === '1') && reminder.user) {
                var secure = false
                var password
                var transporter
                try {
                  password = tags.util.Decipher(reminder.password)
                } catch (err) {
                  password = ''
                }
                if (reminder.security === 'ssl') { secure = true }

                transporter = nodemailer.createTransport({
                  host: reminder.smtp,
                  port: reminder.port,
                  secure: secure, // true for 465, false for other ports
                  auth: {
                    user: reminder.user,
                    pass: password
                  },
                  tls: {
                    rejectUnauthorized: false
                  }
                })

                // setup email data with unicode symbols
                let message = {
                  from: reminder.user, // sender address
                  to: reminder.email, //'wil512on@gmail.com',// list of receivers
                  subject: 'GPAX Recordatorios', // Subject line
                  html: html
                }

                // send mail with defined transport object
                await new Promise(resolve => {
                  transporter.sendMail(message, (error, info) => {
                    if (error) {
                      console.log(error)
                    } else { console.log('Message sent: %s', info.messageId) }
                    resolve()
                  })
                })
              }*/
            }
            resolve()
          } else {
            resolve()
          }
        })
      })
    }
  })
}