var app = require('./utils/main')
app.init({
  session: 'mongodb://192.168.225.30,192.168.225.31/sessions?replicaSet=gpaxio',
  user: 'mongodb://192.168.225.30,192.168.225.31/users?replicaSet=gpaxio',
  notify: 'mongodb://192.168.225.30,192.168.225.31/notify?replicaSet=gpaxio',
  log: 'mongodb://192.168.225.30,192.168.225.31/logs?replicaSet=gpaxio',
  logger: 'full',
  port: 8082
})
