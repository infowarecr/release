var tags = require('./utils/tags').tags
var nodemailer = require('nodemailer')
var moment = require('moment')
var CronJob = require('cron').CronJob
var urlUsers = process.argv[2]
var urlBase = process.argv[3]
if (!urlUsers || urlUsers.length === 0) {
  console.log('Invalid parameters: urlUsers -> expected')
  process.exit()
}
if (!urlBase || urlBase.length === 0) {
  console.log('Invalid parameters: urlBase -> expected')
  process.exit()
}
var Mongo = require('./utils/mongo').Mongo
var mongoUsers
// var url = 'mongodb://dev:27017/';
mongoUsers = new Mongo(urlUsers)

/// // Cron Probado y funciona cada 5 segundos////////////////////

console.log('Before job instantiation')
let job = new CronJob('00 00 04 * * *', function () {
  searchAlarms()
})
console.log('After job instantiation')
job.start()

function searchAlarms () {
  mongoUsers.distinct('user', 'database', { active: true }, async function (err, databases) {
    if (err) { throw err }
    // probar con gpa7
    //databases = ['mongodb://dev:27017/gpa7']
    var today = new Date()
    today = new Date(today.getFullYear(), today.getMonth(), today.getDate())
    for (let i in databases) {
      let mongoDb = new Mongo(databases[i])
      var sett = await new Promise(resolve => {
        mongoDb.findOne('settings', { _id: 'settings' }, async (err, sett) => {
          if (!err) {
            resolve(sett)
          } else {
            resolve(false)
          }
        })
      })
      if (sett && sett.checkNotification && sett.days >= 0) {
        var date
        let alarms = []
        if (sett.days > 0) {
          let days = sett.days
          date = moment()
          do {
            date.add(1, 'days')
            if (date.isoWeekday() !== 6 && date.isoWeekday() !== 7) {
              days = days - 1
            }
          } while (days)
        } else {
          date = moment()
        }
        // var from = moment('2019-07-16', 'YYYY-MM-DD')
        let from = moment(date)
        from.set('hour', 0)
        from.set('minute', 0)
        from.set('second', 0)
        from.set('millisecond', 0)
        var to = moment(date)
        to.set('hour', 23)
        to.set('minute', 59)
        to.set('second', 59)
        to.set('millisecond', 999)
        var notes = await new Promise(resolve => {
          mongoDb.find('note', { dates: { $elemMatch: { type: 'deadline', value: { $gte: new Date(from.format('YYYY-MM-DD HH:mm')), $lt: new Date(to.format('YYYY-MM-DD HH:mm')) } } } }, {}, { _id: 1, status: 1, name: 1, actors: 1 }, (err, notes) => {
            if (!err) {
              resolve(notes)
            } else {
              resolve(false)
            }
          })
        })
        // Tipos mensajes alarmas
        // 1 = 'VENCE'
        // 2 = 'SEGUIMIENTO'
        if (notes) {
          for (let x in notes) {
            let unit = []
            let alarm = {
              collection: 'note',
              createdAt: today,
              dateAlarm: to._d,
              document: {
                id: notes[x]._id,
                name: notes[x].name,
                status: notes[x].status
              },
              path: 'note.note',
              type: 1,
              actors: []
            }
            for (let l in notes[x].actors) {
              alarm.actors.push({
                user: notes[x].actors[l].user,
                seen: 0,
                role: notes[x].actors[l].role
              })
              if (notes[x].actors[l].role === 'from') {
                alarm.user = notes[x].actors[l].user
              }
              if ((notes[x].actors[l].path === 'sent' || notes[x].actors[l].supervisor === '1') && notes[x].actors[l].unit) {
                unit.push(notes[x].actors[l].unit)
              }
            }
            await parentsUnits(mongoDb, unit, alarm)
            alarms.push(alarm)
          }
        }
        var attacheds = await new Promise(resolve => {
          mongoDb.find('attached', { dates: { $elemMatch: { type: 'deadline', value: { $gte: new Date(from.format('YYYY-MM-DD HH:mm')), $lt: new Date(to.format('YYYY-MM-DD HH:mm')) } } } }, {}, { _id: 1, status: 1, name: 1, actors: 1 }, (err, attacheds) => {
            if (!err) {
              resolve(attacheds)
            } else {
              resolve(false)
            }
          })
        })
        if (attacheds) {
          for (let x in attacheds) {
            var unit = []
            let alarm = {
              collection: 'attached',
              createdAt: today,
              dateAlarm: to._d,
              document: {
                id: attacheds[x]._id,
                name: attacheds[x].name,
                status: attacheds[x].status
              },
              path: 'note.attached',
              type: 1,
              actors: []
            }
            for (let l in attacheds[x].actors) {
              alarm.actors.push({
                user: attacheds[x].actors[l].user,
                seen: 0,
                role: attacheds[x].actors[l].role
              })
              if (attacheds[x].actors[l].role==='responsible') {
                alarm.user = attacheds[x].actors[l].user
                unit.push(attacheds[x].actors[l].unit)
              }
              if ((attacheds[x].actors[l].path === 'sent' || attacheds[x].actors[l].supervisor === '1') && attacheds[x].actors[l].unit) {
                unit.push(attacheds[x].actors[l].unit)
              }
            }
            await parentsUnits(mongoDb, unit, alarm)
            alarms.push(alarm)
          }
        }
        var commitments = await new Promise(resolve => {
          mongoDb.find('commitment', { dates: { $elemMatch: { type: 'deadline', value: { $gte: new Date(from.format('YYYY-MM-DD HH:mm')), $lt: new Date(to.format('YYYY-MM-DD HH:mm')) } } } }, {}, { _id: 1, status: 1, name: 1, actors: 1 }, (err, commitments) => {
            if (!err) {
              resolve(commitments)
            } else {
              resolve(false)
            }
          })
        })
        if (commitments) {
          for (let x in commitments) {
            let alarm = {
              collection: 'commitment',
              createdAt: today,
              dateAlarm: to._d,
              document: {
                id: commitments[x]._id,
                name: commitments[x].name,
                status: commitments[x].status
              },
              path: 'note.commitment',
              type: 1,
              actors: []
            }
            for (let l in commitments[x].actors) {
              alarm.actors.push({
                user: commitments[x].actors[l].user,
                seen: 0,
                role: commitments[x].actors[l].role
              })
              if (commitments[x].actors[l].role === 'inCharge') {
                alarm.user = commitments[x].actors[l].user
                if (commitments[x].actors[l].unit) {
                  unit.push(commitments[x].actors[l].unit)
                }
              }
              if ((commitments[x].actors[l].role === 'supervisor' || commitments[x].actors[l].supervisor === '1') && commitments[x].actors[l].unit) {
                unit.push(commitments[x].actors[l].unit)
              }
            }
            await parentsUnits(mongoDb, unit, alarm)
            alarms.push(alarm)
          }
        }
        var commitments2 = await new Promise(resolve => {
          mongoDb.find('commitment', { dates: { $elemMatch: { type: 'trackingDate', value: { $gte: new Date(from.format('YYYY-MM-DD HH:mm')), $lt: new Date(to.format('YYYY-MM-DD HH:mm')) } } } }, {}, { _id: 1, status: 1, name: 1, actors: 1 }, (err, commitments2) => {
            if (!err) {
              resolve(commitments2)
            } else {
              resolve(false)
            }
          })
        })
        if (commitments2) {
          for (let x in commitments2) {
            let alarm = {
              collection: 'commitment',
              createdAt: today,
              dateAlarm: to._d,
              document: {
                id: commitments2[x]._id,
                name: commitments2[x].name,
                status: commitments2[x].status
              },
              path: 'note.commitment',
              type: 2,
              actors: []
            }
            for (let l in commitments2[x].actors) {
              if (commitments[x].actors[l].role === 'supervisor') {
                alarm.actors.push({
                  user: commitments2[x].actors[l].user,
                  seen: 0,
                  role: commitments2[x].actors[l].role
                })
                alarm.user = commitments[x].actors[l].user
                if (commitments[x].actors[l].unit) {
                  unit.push(commitments[x].actors[l].unit)
                }
              }
              if (commitments[x].actors[l].supervisor === '1' && commitments[x].actors[l].unit) {
                unit.push(commitments[x].actors[l].unit)
              }
            }
            await parentsUnits(mongoDb, unit, alarm)
            alarms.push(alarm)
          }
        }
        if (alarms.length) {
          await new Promise(resolve => {
            mongoDb.insertMany('alarm', alarms, (err, result) => {
              if (!err) {
                resolve(result)
              } else {
                resolve(false)
              }
            })
          })
          if (sett && sett.user /* && sett.password  */ && sett.checkEmail === '1') {
            var emails = await new Promise(resolve => {
              mongoDb.aggregate('alarm', [
                { $match: { createdAt: today } },
                { $lookup: { localField: 'actors.user', foreignField: '_id', from: 'user', as: 'user' } },
                { $unwind: '$user' },
                { $match: { 'user.licensedUser': false, 'user.active': true } },
                { $group: { _id: '$user.email', count: { $sum: 1 } } }
              ], {}, (err, emails) => {
                if (!err) {
                  resolve(emails)
                } else {
                  resolve(false)
                }
              })
            })
            // TODO emails.push (settings.copies)
            for (let i in emails) {
              var secure = false
              var password
              var transporter
              try {
                password = tags.util.Decipher(sett.password)
              } catch (err) {
                password = ''
              }
              if (sett.security === 'ssl') { secure = true }

              transporter = nodemailer.createTransport({
                host: sett.smtp,
                port: sett.port,
                secure: secure, // true for 465, false for other ports
                auth: {
                  user: sett.user,
                  pass: password
                },
                tls: {
                  rejectUnauthorized: false
                }
              })

              // setup email data with unicode symbols
              var sendMessage = 'Hay ' + emails[i].count + ' documentos que vencen en ' + sett.days + ' días'
              /* if (sett.sendMessage && sett.sendMessage.length > 0) {
                  sendMessage = sett.sendMessage
                } */
              let message = {
                from: sett.user, // sender address
                to: emails[i]._id, // list of receivers
                // cc: unlicensedCopy, // list of receivers
                subject: 'Recordatorio GPAX', // Subject line
                // text: 'Hello world?', // plain text body
                html: sendMessage + '<span class="h-entry p-name"><a class="u-url" href="' + urlBase + '">GPAX</a></span>⁠&nbsp;' // html body
              }

              // send mail with defined transport object
              transporter.sendMail(message, (error, info) => {
                if (error) {
                  console.log(error)
                } else { console.log('Message sent: %s', info.messageId) }
              })
            }
          }
        }
      }
    }
  })
}

var parentsUnits = async (mongoDb, unit, alarm) => {
  while (unit.length) {
    let units = await new Promise(resolve => {
      mongoDb.find('unit', { parent: { $in: unit } }, { _id: 1, actors: 1 }, (err, units) => {
        if (!err) {
          resolve(units)
        } else {
          resolve(false)
        }
      })
    })
    unit = []
    if (units) {
      for (let i in units) {
        unit.push(units[i]._id)
        if (units[i].actors) {
          units[i].actors.forEach(a => {
            if (['manager', 'assistant'].includes(a.type[0])) {
              let actor = alarm.actors.findIndex((x) => {
                return x.user.toString() === a.user.toString()
              })
              if (actor === -1) {
                alarm.actors.push({
                  user: a.user,
                  seen: 0
                })
              }
            }
          })
        }
      }
    }
  }
}
