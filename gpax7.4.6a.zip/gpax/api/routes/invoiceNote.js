var tags = require('../utils/tags').tags
var base64 = require('base-64')
var Notification = require('../utils/notification').Notification
var notification = new Notification()

exports.InvoiceNote = InvoiceNote

function InvoiceNote () {
  this.get = function (req, mongo, send) {
    if (req.query._id) {
      mongo.findId('invoiceCredit', req.query._id, (err, invoice) => {
        if (!err) {
          invoice.currency = invoice.total[0].currency
          invoice.value = invoice.total[0].value
          send([invoice])
        } else {
          send()
        }
      })
    } else {
      mongo.findId('invoice', req.query.invoice, (err, values) => {
        if (err && !values) values = {}
        mongo.findN('invoiceCredit', 0, 1, { company: values.company, typeDoc: req.query.type }, { number: 1, _id: 1 }, { _id: -1 }, (err, invs) => {
          if (err && !invs) invs = [{}]
          mongo.findOne('company', { idNum: values.company }, (err, company) => {
            if (err) {
              req.logger.log(err)
            }
            var data = {}
            data.tipDoc = values.number.slice(8, 10)
            data.keyRef = values.key
            data.client = values.client
            data.company = values.company
            data.product = values.product
            data.codProduct = values.codProduct
            data.medPago = values.medPago
            data.items = values.items
            data.detail = values.detail
            data.data = values.data
            data.discount = values.discount
            data.detailDiscount = values.detailDiscount
            data.amounts = values.amounts
            data.dateRef = values.date
            data.value = values.total[0].value
            data.currency = values.total[0].currency
            data.tax = values.tax
            data.typeDoc = req.query.type
            data.codeActivity = '721001'

            data._id = mongo.newId()

            var num = '0000000001'
            if (invs[0] && invs[0].number.slice(10, 20)) {
              num = invs[0].number.slice(10, 20)
              var n = parseInt(num, 10)
              n = n + 1
              num = n.toString()
              num = pad(num, 10)
            }
            // Information for Electronic invoice
            // local o establecimiento
            var casaMatriz = company.establishment
            // Terminal o punto de venta
            var terminal = company.station
            // tipo de comprobante
            var tipComp = data.typeDoc
            // numero consecutivo
            data.number = casaMatriz + terminal + tipComp + num

            //* ******Clave numerica*******
            // codigo del pais
            var codPais = '506'
            var date = new Date()
            // dia
            var day = date.getDate()
            if (day < 10) {
              day = pad(day, 2)
            }
            day = day.toString()
            // mes
            var month = date.getMonth() + 1
            if (month < 10) {
              month = pad(month, 2)
            }
            month = month.toString()
            // año
            var year = date.getFullYear()
            year = year.toString()
            year = year.slice(2, 4)
            // cedula emisor
            if (company.idType === '01') {
              var ced = '000' + company.idNum
            } else if (company.idType === '02' || company.idType === '04') {
              ced = '00' + company.idNum
            } else if (company.idType === '03') {
              if (company.idNum.length === 12) { ced = company.idNum } else { ced = '0' + company.idNum }
            }
            // situacion del comprobante
            var sitComp = '1'
            // codigo de seguridad
            var codSeg = company.code
            // clave nuemrica
            data.key = codPais + day + month + year + ced + data.number + sitComp + codSeg
            send([data])
          })
        })
      })
    }
  }

  this.count = async function (req, mongo, send) {
    var keys = {}
    if (!req.session.context.createUsers) {
      var compaResult = await new Promise((resolve, reject) => {
        mongo.find('company', { userId: req.session.context.user }, { _id: 0, idNum: 1 }, (err, coms) => {
          if (err) reject(err)
          else {
            var arrayC = []
            for (let i in coms) {
              arrayC.push(coms[i].idNum)
            }
            resolve(arrayC)
          }
        })
      }).catch((err) => console.log(err))
      keys = { $or: [{ company: { $in: compaResult } }, { user: req.session.context.user }] }
    }
    mongo.count('invoiceCredit', keys, (err, count) => {
      if (err) {
        req.statusCode = 404
        send()
      } else {
        send({ count: count })
      }
    })
  }
  this.pending = async function (req, mongo, send) {
    var keys = { statusHacienda: { $nin: ['rechazado', 'inconsistente', 'aceptado'] } }
    if (!req.session.context.createUsers) {
      var compaResult = await new Promise((resolve, reject) => {
        mongo.find('company', { userId: req.session.context.user }, { _id: 0, idNum: 1 }, (err, coms) => {
          if (err) reject(err)
          else {
            var arrayC = []
            for (let i in coms) {
              arrayC.push(coms[i].idNum)
            }
            resolve(arrayC)
          }
        })
      }).catch((err) => console.log(err))
      keys = { $and: [{ company: { $in: compaResult } }, { statusHacienda: { $nin: ['rechazado', 'inconsistente', 'aceptado'] } }] }
    }
    mongo.count('invoiceCredit', keys, (err, count) => {
      if (err) {
        req.statusCode = 404
        send()
      } else {
        send({ count: count })
      }
    })
  }

  this.list2 = async function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    var keys
    let query
    if (req.query.filter) {
      query={}
      for (let name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          if (name === 'number') {
            if (req.query.ebill) {
              query.consecutivo2 = req.query.filter[name]
            } else {
              query.number = new RegExp(req.query.filter[name], 'i')
            }
          } else if (name === 'statusHacienda') {
            if (req.query.filter[name] === 'sin verificar') { query.statusHacienda = { $exists: 0 } } else { query.statusHacienda = req.query.filter[name] }
          } else if (name === 'status') {
            if (req.query.filter[name] === 'no enviada') { query.responseXml = { $exists: 0 } } else { query.responseXml = { $exists: 1 } }
          } else if (name === 'company' || name === 'companyName') {
            query.company = req.query.filter[name]
          } else if (name === 'currency') {
            query.Moneda = req.query.filter[name]
          } else if (name === 'date') {
            query.fechaDocumento = new RegExp(req.query.filter[name], 'i')
          } else {
            query[name] = req.query.filter[name].indexOf(',') !== -1 ? { $in: req.query.filter[name].split(',') } : new RegExp(req.query.filter[name].replace(/ /g, '.*'), 'i')
          }
        }
      }
      keys = { $and: [keys, query] }
    }
    var compaResult = await new Promise((resolve, reject) => {
      mongo.find('company', { userId: req.session.context.user }, { _id: 0, idNum: 1 }, (err, coms) => {
        if (err) reject(err)
        else {
          var arrayC = []
          for (let i in coms) {
            arrayC.push(coms[i].idNum)
          }
          resolve(arrayC)
        }
      })
    }).catch((err) => console.log(err))
    keys = query
      ? { $and: [{ $or: [{ company: { $in: compaResult } }, { user: req.session.context.user }] }, query] }
      :{ $or: [{ company: { $in: compaResult } }, { user: req.session.context.user }] }
    var pipeline = []
    pipeline.push({ $match: keys })
    pipeline.push({ $sort: { _id: -1 } })
    pipeline.push({ $skip: skip })
    pipeline.push({ $limit: limit })
    mongo.aggregate('invoiceCredit', pipeline, { allowDiskUse: true }, (err, invoices) => {
      if (err) {
        send({ error: err })
      } else {
        var clientId = []
        for (let i in invoices) {
          clientId.push(invoices[i].client)
        }
        mongo.toHash('client', { _id: { $in: clientId } }, { _id: 1, name: 1 }, (err, client) => {
          if (err && !client) client = {}
          else {
            mongo.find('company', { }, {}, {}, async (err, companies) => {
              if (err && !companies) companies = {}
              else {
                for (let i in invoices) {
                  if (!invoices[i].company) {
                    var num = parseFloat(invoices[i].total[0].value)
                    var discount = invoices[i].discount ? parseFloat(invoices[i].discount) : 0
                    var total = num - discount
                    if (invoices[i].items) {
                      total = 0
                      for (let t in invoices[i].items) {
                        discount = invoices[i].items[t].discount ? parseFloat(invoices[i].items[t].discount) : 0
                        total = total + parseFloat(invoices[i].items[t].total) - discount
                      }
                    }
                    invoices[i].id = invoices[i]._id.toString()
                    invoices[i].currency = invoices[i].total[0].currency
                    invoices[i].value = arreglar(total)
                    invoices[i].key = invoices[i].clave
                    invoices[i].client = client[invoices[i].client.toString()].name
                    invoices[i].date = tags.util.date2str(invoices[i].date, 'DD-MM-YYYY', tags)
                    var recordDate = tags.util.date2str(invoices[i]._id.getTimestamp(), 'DD-MM-YYYY', tags)
                    invoices[i].recordDate = recordDate
                    invoices[i].processDate = invoices[i].processDate ? tags.util.date2str(invoices[i].processDate, 'DD-MM-YYYY', tags) : recordDate
                    invoices[i].responseXml = !!invoices[i].responseXml
                    if (!invoices[i].sent) { invoices[i].sent = 'no' }
                    if (!invoices[i].statusHacienda && invoices[i].responseXml) { invoices[i].statusHacienda = 'aceptado' } else if (!invoices[i].statusHacienda && !invoices[i].responseXml) { invoices[i].statusHacienda = 'sin verificar' }
                    invoices[i].invoices = invoices[i].keyRef
                    reply.data.push(invoices[i])
                  } else {
                    invoices[i].id = invoices[i]._id.toString()
                    invoices[i].currency = invoices[i].total[0].currency
                    if (invoices[i].enviada || invoices[i].response === 524 || invoices[i].responseXml) { invoices[i].status = 'enviada' } else { invoices[i].status = 'no enviada' }
                    invoices[i].value = invoices[i].total[0].value
                    if (invoices[i].voucherXml) { invoices[i].voucherXml = base64.decode(invoices[i].voucherXml) }
                    invoices[i].client = client[invoices[i].client].name
                    invoices[i].date = tags.util.date2str(invoices[i].fechaDocumento, 'DD-MM-YYYY', tags)
                    recordDate = tags.util.date2str(invoices[i]._id.getTimestamp(), 'DD-MM-YYYY', tags)
                    invoices[i].companyName = await new Promise(resolve => {
                      var name = ''
                      for (var c in companies) {
                        if (companies[c].idNum === invoices[i].company) {
                          name = companies[c].name
                          break
                        }
                      }
                      resolve(name)
                    })
                    invoices[i].recordDate = recordDate
                    invoices[i].processDate = invoices[i].processDate ? tags.util.date2str(invoices[i].processDate, 'DD-MM-YYYY', tags) : recordDate
                    if (invoices[i].responseXml) { invoices[i].responseXml = base64.decode(invoices[i].responseXml) }
                    if (!invoices[i].sent) { invoices[i].sent = 'no' }
                    if (!invoices[i].statusHacienda && invoices[i].responseXml) { invoices[i].statusHacienda = 'aceptado' } else if (!invoices[i].statusHacienda && !invoices[i].responseXml) { invoices[i].statusHacienda = 'sin verificar' }
                    var facturas = ''
                    for (let t in invoices[i].Facturas) {
                      var factura = invoices[i].Facturas[t]
                      facturas += factura.ClaveDocumentoReferencia + '<br>'
                    }
                    invoices[i].invoices = facturas
                    reply.data.push(invoices[i])
                  }
                }
                if (skip) {
                  send(reply)
                } else {
                  mongo.count('invoiceCredit', keys, (err, count) => {
                    if (err) {
                      send(err)
                    } else {
                      reply.total_count = count
                      send(reply)
                    }
                  })
                }
              }
            })
          }
        })
      }
    })
  }
  this.list = async function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    var keys
    if (req.query.ebill) {
      keys = {}
    } else {
      keys = { user: req.session.context.user }
    }
    let query = {}
    if (req.query.filter) {
      for (let name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          if (name === 'number') {
            if (req.query.ebill) {
              query.consecutivo2 = req.query.filter[name]
            } else {
              query.number = new RegExp(req.query.filter[name], 'i')
            }
          } else if (name === 'statusHacienda') {
            if (req.query.filter[name] === 'sin verificar') { query.statusHacienda = { $exists: 0 } } else { query.statusHacienda = req.query.filter[name] }
          } else if (name === 'status') {
            if (req.query.filter[name] === 'no enviada') { query.responseXml = { $exists: 0 } } else { query.responseXml = { $exists: 1 } }
          } else if (name === 'company' || name === 'companyName') {
            query.company = req.query.filter[name]
          } else if (name === 'currency') {
            query.Moneda = req.query.filter[name]
          } else if (name === 'date') {
            query.fechaDocumento = new RegExp(req.query.filter[name], 'i')
          } else {
            query[name] = req.query.filter[name].indexOf(',') !== -1 ? { $in: req.query.filter[name].split(',') } : new RegExp(req.query.filter[name].replace(/ /g, '.*'), 'i')
          }
        }
      }
      keys = { $and: [keys, query] }
    }
    if (!req.session.context.createUsers && req.query.ebill) {
      var compaResult = await new Promise((resolve, reject) => {
        mongo.find('company', { users: { $in: [req.session.context.user] } }, { _id: 0, idNum: 1 }, (err, coms) => {
          if (err) reject(err)
          else {
            var arrayC = []
            for (let i in coms) {
              arrayC.push(coms[i].idNum)
            }
            resolve(arrayC)
          }
        })
      }).catch((err) => console.log(err))
      keys = {
        $and: [
          { $or: [{ company: { $in: compaResult } }, { user: req.session.context.user }] },
          query
        ]
      }
    }
    var pipeline = []
    pipeline.push({ $match: keys })
    pipeline.push({ $sort: { _id: -1 } })
    pipeline.push({ $skip: skip })
    pipeline.push({ $limit: limit })
    mongo.aggregate('invoiceCredit', pipeline, { allowDiskUse: true }, (err, invoices) => {
      if (err) {
        send({ error: err })
      } else {
        var clientId = []
        for (let i in invoices) {
          clientId.push(invoices[i].client)
        }
        mongo.toHash('client', { _id: { $in: clientId } }, { _id: 1, name: 1 }, (err, client) => {
          if (err && !client) client = {}
          else {
            mongo.find('company', { }, {}, {}, async (err, companies) => {
              if (err && !companies) companies = {}
              else {
                for (let i in invoices) {
                  if (!invoices[i].company) {
                    var num = parseFloat(invoices[i].total[0].value)
                    var discount = invoices[i].discount ? parseFloat(invoices[i].discount) : 0
                    var total = num - discount
                    if (invoices[i].items) {
                      total = 0
                      for (let t in invoices[i].items) {
                        discount = invoices[i].items[t].discount ? parseFloat(invoices[i].items[t].discount) : 0
                        total = total + parseFloat(invoices[i].items[t].total) - discount
                      }
                    }
                    invoices[i].id = invoices[i]._id.toString()
                    invoices[i].currency = invoices[i].total[0].currency
                    invoices[i].value = arreglar(total)
                    invoices[i].key = invoices[i].clave
                    invoices[i].client = client[invoices[i].client.toString()].name
                    invoices[i].date = tags.util.date2str(invoices[i].date, 'yyyy-mm-dd', tags)
                    var recordDate = tags.util.date2str(invoices[i]._id.getTimestamp(), 'yyyy-mm-dd HH:MM:ss', tags)
                    invoices[i].recordDate = recordDate
                    invoices[i].processDate = invoices[i].processDate ? tags.util.date2str(invoices[i].processDate, 'yyyy-mm-dd HH:MM:ss', tags) : recordDate
                    invoices[i].responseXml = !!invoices[i].responseXml
                    if (!invoices[i].sent) { invoices[i].sent = 'no' }
                    if (!invoices[i].statusHacienda && invoices[i].responseXml) { invoices[i].statusHacienda = 'aceptado' } else if (!invoices[i].statusHacienda && !invoices[i].responseXml) { invoices[i].statusHacienda = 'sin verificar' }
                    invoices[i].invoices = invoices[i].keyRef
                    reply.data.push(invoices[i])
                  } else {
                    invoices[i].id = invoices[i]._id.toString()
                    invoices[i].currency = invoices[i].Moneda
                    if (invoices[i].enviada || invoices[i].response === 524 || invoices[i].responseXml) { invoices[i].status = 'enviada' } else { invoices[i].status = 'no enviada' }
                    invoices[i].number = invoices[i].consecutivoTemporal
                    invoices[i].value = arreglar(invoices[i].TotalComprobante)
                    invoices[i].key = invoices[i].clave
                    if (invoices[i].voucherXml) { invoices[i].voucherXml = base64.decode(invoices[i].voucherXml) }
                    invoices[i].client = invoices[i].Receptor.Nombre
                    invoices[i].date = tags.util.date2str(invoices[i].fechaDocumento, 'yyyy-mm-dd', tags)
                    recordDate = tags.util.date2str(invoices[i]._id.getTimestamp(), 'yyyy-mm-dd HH:MM:ss', tags)
                    invoices[i].companyName = await new Promise(resolve => {
                      var name = ''
                      for (var c in companies) {
                        if (companies[c].idNum === invoices[i].company) {
                          name = companies[c].name
                          break
                        }
                      }
                      resolve(name)
                    })
                    invoices[i].recordDate = recordDate
                    invoices[i].processDate = invoices[i].processDate ? tags.util.date2str(invoices[i].processDate, 'yyyy-mm-dd HH:MM:ss', tags) : recordDate
                    if (invoices[i].responseXml) { invoices[i].responseXml = base64.decode(invoices[i].responseXml) }
                    if (!invoices[i].sent) { invoices[i].sent = 'no' }
                    if (!invoices[i].statusHacienda && invoices[i].responseXml) { invoices[i].statusHacienda = 'aceptado' } else if (!invoices[i].statusHacienda && !invoices[i].responseXml) { invoices[i].statusHacienda = 'sin verificar' }
                    var facturas = ''
                    for (let t in invoices[i].Facturas) {
                      var factura = invoices[i].Facturas[t]
                      facturas += factura.ClaveDocumentoReferencia + '<br>'
                    }
                    invoices[i].invoices = facturas
                    reply.data.push(invoices[i])
                  }
                }
                if (skip) {
                  send(reply)
                } else {
                  mongo.count('invoiceCredit', keys, (err, count) => {
                    if (err) {
                      send(err)
                    } else {
                      reply.total_count = count
                      send(reply)
                    }
                  })
                }
              }
            })
          }
        })
      }
    })
  }

  this.save = function (req, mongo, send) {
    var doc = req.body

    var dt = new Date()
    var time = dt.toTimeString()
    dt = dt.toISOString()
    dt = dt.split('T', 1)
    dt = dt + 'T' + time
    doc.date = dt.split(' ', 1) + '-06:00'
    doc.user = req.session.context.user

    var dtr = new Date(doc.dateRef)
    doc.dateRef = dtr.toISOString()

    doc.total = []
    doc.total.push({
      value: 0,
      currency: doc.currency,
      type: 'invoiced'
    })

    doc.data = doc.data.replace(new RegExp('&nbsp;', 'g'), ' ')

    delete doc.currency
    delete doc.value

    mongo.save('invoiceCredit', doc, (err, result) => {
      if (err) {
        send({ error: tags.savingProblema })
      } else {
        send({ message: tags.savedChanges })
        notification.send(req, req.session.context.room, 'dt_invoicesNote', { id: doc._id })
      }
    })
  }
}

// Añadir ceros a la izquierda
function pad (n, length) {
  n = n.toString()
  while (n.length < length) { n = '0' + n }
  return n
}

var separadorDecimalesInicial = '.' // Modifique este dato para poder obtener la nomenclatura que utilizamos en mi pais
var separadorDecimales = '.' // Modifique este dato para poder obtener la nomenclatura que utilizamos en mi pais
var separadorMiles = ',' // Modifique este dato para poder obtener la nomenclatura que utilizamos en mi pais
// Añadir separador de miles al total
function arreglar (numero) {
  var num = ''
  numero = '' + numero
  var partes = numero.split(separadorDecimalesInicial)
  var entero = partes[0]
  if (partes.length > 1) {
    var decimal = partes[1]
  }
  var cifras = entero.length
  var cifras2 = cifras
  for (let a = 0; a < cifras; a++) {
    cifras2 -= 1
    num += entero.charAt(a)
    if (cifras2 % 3 === 0 && cifras2 !== 0) {
      num += separadorMiles
    }
  }
  if (partes.length > 1) {
    num += separadorDecimales + decimal
  }
  return num
}
