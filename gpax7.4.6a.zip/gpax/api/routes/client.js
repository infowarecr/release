exports.Client = Client
var Notification = require('../utils/notification').Notification
var notification = new Notification()

function Client () {
  this.get = function (req, mongo, send) {
    var doc = {}

    if (req.query._id) {
      mongo.findId('client', req.query._id, (err, user) => {
        if (!err) {
          doc = user
          send(doc)
        } else {
          send()
        }
      })
    } else {
      doc = { _id: mongo.newId() }
      send(doc)
    }
  }

  this.save = function (req, mongo, send) {
    var doc = req.body

    if (!doc._id) { doc._id = mongo.isNativeId(doc.id) ? mongo.toId(doc.id) : mongo.newId() }

    if (doc.id) {
      delete doc.id
    }

    mongo.save('client', doc, (err, result) => {
      if (err) {
        req.logger.log(err)
      } else {
        send({ id: doc._id })
        notification.send(req, req.session.context.room, 'dt_client', { id: doc._id })
      }
    })
  }

  this.saveContact = function (req, mongo, send) {
    var doc = req.body
    if (mongo.isNativeId(doc.id)) {
      doc._id = mongo.toId(doc.id)
      delete doc.id
    }
    var idClient = req.query.idClient
    if (mongo.isNativeId(idClient)) {
      mongo.findId('client', idClient, (err, client) => {
        if (err) { req.logger.log(err) } else {
          if (Array.isArray(client.contacts)) {
            var exist = false
            for (const i in client.contacts) {
              if (client.contacts[i]._id.toString() === doc._id.toString()) {
                client.contacts[i].name = doc.name
                client.contacts[i].phones = doc.phones
                client.contacts[i].email = doc.email
                client.contacts[i].role = doc.role
                exist = true
                break
              }
            }
            if (!exist) { client.contacts.push(doc) }
          } else {
            client.contacts = []
            client.contacts.push(doc)
          }
          mongo.save('client', { _id: client._id, contacts: client.contacts }, (err, result) => {
            if (err) { req.logger.log(err) } else {
              send()
            }
          })
        }
      })
    }
  }

  this.saveAction = function (req, mongo, send) {
    var doc = req.body
    doc.user = req.session.context.user
    if (mongo.isNativeId(doc.id)) {
      doc._id = mongo.toId(doc.id)
      delete doc.id
    }
    var idClient = req.query.idClient
    if (mongo.isNativeId(idClient)) {
      mongo.findId('client', idClient, (err, client) => {
        if (err) { req.logger.log(err) } else {
          if (Array.isArray(client.actions)) {
            var exist = false
            for (const i in client.actions) {
              if (client.actions[i]._id) {
                if (client.actions[i]._id.toString() === doc._id.toString()) {
                  client.actions[i].contact = doc.contact
                  client.actions[i].user = doc.user
                  client.actions[i].state = doc.state
                  client.actions[i].type = doc.type
                  client.actions[i].dateTime = doc.dateTime
                  client.actions[i].description = doc.description
                  exist = true
                }
              } else {
                client.actions[i]._id=mongo.newId(client.actions[i].dateTime)
              }
            }
            if (!exist) { client.actions.push(doc) }
          } else {
            client.actions = []
            client.actions.push(doc)
          }
          mongo.save('client', { _id: client._id, actions: client.actions }, (err, result) => {
            if (err) { req.logger.log(err) } else {
              send()
            }
          })
        }
      })
    }
  }

  this.deleteC = function (req, mongo, send) {
    var id = req.query._id
    var idClient = req.query.idClient
    mongo.findId('client', idClient, (err, client) => {
      if (err) {
        req.logger.log(err)
      } else {
        if (client.contacts) {
          for (const i in client.contacts) {
            if (client.contacts[i]._id.toString() === id.toString()) {
              client.contacts.splice(i, 1)
              break
            }
          }
          mongo.save('client', { _id: client._id, contacts: client.contacts }, (err, result) => {
            if (err) { req.logger.log(err) } else {
              send()
            }
          })
        } else { send() }
      }
    })
  }

  this.list = function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    var keys = {status: 'client'}
    if (req.query.filter) {
      const query = {}
      for (const name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          if (name === 'name') {
            query[name] = { $regex: req.query.filter.name, $options: 'i' }
          } else {
            query[name] = req.query.filter[name].indexOf(',') !== -1 ? { $in: req.query.filter[name].split(',') } : new RegExp(req.query.filter[name].replace(/ /g, '.*'), 'i')
          }
        }
      }
      keys = query
    }
    mongo.findN('client', skip, limit, keys, { _id: 1, name: 1, description: 1, address: 1, phone: 1, date: 1, dateHiring: 1, type: 1, country: 1, products: 1, contacts: 1, actions: 1, licenses: 1, comments: 1, status: 1, idType: 1, idNum: 1, codPhone: 1, clientEmail: 1, budget: 1, platform: 1, website: 1, amount: 1, quantity: 1 }, { _id: 1 }, (err, clients) => {
      if (!err && clients) {
        clients.forEach((client) => {
          client.products = [client.products]
          const date = client.date
          client.date = date
          // client.id = client._id.toString();
          reply.data.push(client)
        })
        mongo.count('client', keys, (err, count) => {
          if (!err && count) {
            reply.total_count = count
          }
          send(reply)
        })
      }
    })
  }

  this.delete = function (req, mongo, send) {
    var doc = req.query
    mongo.findId('client', mongo.toId(doc._id), (err, client) => {
      if (err) {
        send({ error: err })
      } else {
        mongo.deleteOne('client', { _id: doc._id }, (err, result) => {
          if (err) {
            req.logger.log(err)
          } else {
            req.app.routes.trash.insert(req, mongo, 'client', client, () => {
              send(result)
              notification.send(req, req.session.context.room, 'dt_client', { id: '' })
            })
          }
        })
      }
    })
  }
}
