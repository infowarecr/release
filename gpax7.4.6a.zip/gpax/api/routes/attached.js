var tags = require('../utils/tags').tags
var dateformat = require('dateformat')
var Html = require('../utils/html').Html
var html = new Html()
var moment = require('moment')
var Notification = require('../utils/notification').Notification
var notification = new Notification()
/* exported */

exports.Attached = Attached

function Attached () {
  this.get = async function (req, mongo, send) {
    var doc = {}
    if (!!req.query._id && req.query._id !== 'undefined') {
      var keys = await this.$keys(req, mongo)
      mongo.aggregate('attached', [{
        $match: {
          $and: [{
            _id: mongo.toId(req.query._id)
          }, keys]
        }
      },
      {
        $lookup: {
          from: 'unit',
          let: {
            units: '$actors.unit'
          },
          as: 'offline',
          pipeline: [{
            $match: {
              $expr: {
                $and: [{
                  $in: ['$_id', '$$units']
                }, {
                  $eq: ['$offline', true]
                }]
              }
            }
          }]
        }
      }
      ], {}, async (err, document) => {
        if (err || !document || !document.length) {
          req.statusCode = 404
          send()
        } else {
          document = document[0]
          // responsibleUnit is offline and current user is auditor, he can supervising these commitment
          if (document.offline[0] && req.session.context.licensedUser) {
            document.actors.push({
              user: req.session.context.user,
              path: 'send',
              role: 'co-responsible',
              unit: req.session.context.memberUnits[0]
            })
            delete document.offline
          }
          let deadline, answerDate
          if (document.dates) {
            document.dates.findIndex((x) => {
              if (x.type === 'deadline') deadline = x.value
              if (x.type === 'answered') answerDate = x.value
            })
          }
          if (document.actors) {
            document.readResponsible = []
            document.responsible=[]
            for (let i in document.actors) {
              if (document.actors[i].role === 'responsible') {
                document.responsible.push(document.actors[i].user.toString() + '&unit=' + document.actors[i].unit.toString())
                let user = await new Promise(resolve => {
                  mongo.findId('user', document.actors[i].user, {
                    name: 1
                  }, (err, user) => {
                    if (!err && user) {
                      resolve(user)
                    } else {
                      resolve('')
                    }
                  })
                })
                let unit = await new Promise(resolve => {
                  mongo.findId('unit', document.actors[i].unit, {
                    name: 1
                  }, (err, unit) => {
                    if (!err && unit) {
                      resolve(unit)
                    } else {
                      resolve('')
                    }
                  })
                })
                document.readResponsible.push(user.name + '/' + unit.name)
              }
            }
          }
          if (document.status && document.status !== 'draft' && deadline) {
            var date = dateformat(new Date(deadline), 'yyyy/mm/dd')
            document.deadline = date
          }
          if (answerDate) {
            date = dateformat(new Date(answerDate), 'yyyy/mm/dd')
            document.answerDate = date
          }
          if (document.type === 'spreadsheet' && typeof(document.content) === 'string') {
            document.content = JSON.parse(document.content)
          }
          if (document.task) {
            req.query.project = document.project
            req.query.task = document.task
            send(document)
          } else {
            send(document)
          }
        }
      })
    } else {
      // New document
      doc = {
        _id: mongo.newId(),
        isNew: true,
        status: tags.draft,
        name: 'Recomendación',
        requiredResponse: true,
        actors: [{
          user: req.session.context.user,
          path: tags.sent,
          role: tags.reviser
        }],
        type: 'note'
      }
      if (req.session.context.memberUnits && req.session.context.memberUnits.length > 0) {
        doc.actors[0].unit = req.session.context.memberUnits[0]
      }
      if (req.query.reference) {
        doc.reference = req.query.reference
        var note = await new Promise(resolve => {
          mongo.findOne('note', {
            _id: mongo.toId(doc.reference)
          }, {
            _id: 1,
            actors: 1
          }, (err, note) => {
            if (!err) {
              resolve(note)
            }
          })
        })
        note.actors.findIndex((x) => {
          if (x.user.toString() === doc.actors[0].user.toString()) {
            doc.actors[0].unit = x.unit
          }
        })

        let indexFrom = note.actors.findIndex((x) => {
          return x.role === 'from'
        })
        if (indexFrom !== -1) {
          let indexDoc = doc.actors.findIndex((x) => {
            return note.actors[indexFrom].user.toString() === x.user.toString()
          })
          if (indexDoc === -1) {
            doc.actors.push(note.actors[indexFrom])
          }
        }
      }
      send(doc)
    }
  }

  this.changeResponsible = async function (req, mongo, send) {
    var body = req.body
    var users = await new Promise(resolve => {
      mongo.toHash('user', {}, {
        _id: 1,
        name: 1
      }, (err, users) => {
        if (!err) {
          resolve(users)
        }
      })
    })
    var units = await new Promise(resolve => {
      mongo.toHash('unit', {}, {
        _id: 1,
        name: 1
      }, (err, units) => {
        if (!err) {
          resolve(units)
        }
      })
    })
    mongo.findId('note', body.note, (err, note) => {
      if (err) {
        console.log(err)
        send()
      } else {
        var actor
        for (let i in note.actors) {
          if (note.actors[i].user.toString() === body.responsible) {
            actor = note.actors[i]
            break
          }
        }
        for (let i in body.ids) {
          body.ids[i] = mongo.toId(body.ids[i])
        }
        mongo.find('attached', {
          _id: {
            $in: body.ids
          }
        }, {
          _id: 1,
          responsible: 1,
          actors: 1
        }, async (err, atts) => {
          if (err) {
            console.log(err)
            send()
          } else {
            for (let i in atts) {
              var exists
              exists = atts[i].actors.findIndex((x) => {
                return x.role === 'responsible'
              })
              if (exists !== -1) {
                if (atts[i].actors[exists].user.toString() !== body.responsible) {
                  let comment = ''
                  let oldUser = atts[i].actors[exists].user
                  comment = '<p>Cambió a ' + '<img class="photo" src="api/user.image?size=20&_id=' + atts[i].actors[exists].user.toString() + '"/>' + (users[atts[i].actors[exists].user.toString()] ? users[atts[i].actors[exists].user.toString()].name : ' ') + '/' + (units[atts[i].actors[exists].unit.toString()] ? units[atts[i].actors[exists].unit.toString()].name : ' ') + ' por ' + '<img class="photo" src="api/user.image?size=20&_id=' + actor.user.toString() + '"/>' + (users[actor.user.toString()] ? users[actor.user.toString()].name : ' ') + '/' + (units[actor.unit.toString()] ? units[actor.unit.toString()].name : ' ') + '</p>'
                  atts[i].actors[exists].user = actor.user
                  atts[i].actors[exists].unit = actor.unit
                  await new Promise(resolve => {
                    mongo.save('attached', {
                      _id: atts[i]._id,
                      responsible: atts[i].responsible,
                      actors: atts[i].actors
                    }, async (err, result) => {
                      if (err) {
                        console.log(err)
                        resolve()
                      } else {
                        await new Promise(resolve => {
                          mongo.find('comment', {
                            collection: 'attached',
                            document: atts[i]._id,
                            involved: oldUser
                          }, {}, async (err, comms) => {
                            if (comms && comms.length) {
                              for (let u in comms) {
                                comms[u].involved.push(actor.user)
                                await new Promise(resolve => {
                                  mongo.save('comment', comms[u], () => {
                                    resolve()
                                  })
                                })
                              }
                            }
                            resolve()
                          })
                        })
                        let involvedActors = []
                        if (atts[i].actors && atts[i].actors.length) {
                          for (let v in atts[i].actors) {
                            if (atts[i].actors[v].path !== 'hidden' && atts[i].actors[v].user.toString() !== req.session.context.user.toString()) involvedActors.push(atts[i].actors[v].user)
                          }
                        }
                        const data = {
                          document: atts[i]._id,
                          comment: comment,
                          collection: 'attached',
                          involved: involvedActors
                        }
                        req.app.routes.comment.save(req, mongo, () => {
                          resolve()
                        }, data)
                      }
                    })
                  })
                  var commitments = await new Promise(resolve => {
                    mongo.find('commitment', {
                      reference: atts[i]._id
                    }, {
                      _id: 1,
                      name: 1,
                      actors: 1
                    }, (err, commitments) => {
                      if (!err) {
                        resolve(commitments)
                      } else {
                        resolve(false)
                      }
                    })
                  })
                  if (commitments) {
                    for (const c in commitments) {
                      let comment = ''
                      const commitment = commitments[c]
                      let oldUserComm = ''
                      for (let g in commitment.actors) {
                        if (commitment.actors[g].role === 'responsible') {
                          oldUserComm = commitment.actors[g].user
                          comment = '<p>Cambió a ' + '<img class="photo" src="api/user.image?size=20&_id=' + commitment.actors[g].user.toString() + '"/>' + (users[commitment.actors[g].user.toString()] ? users[commitment.actors[g].user.toString()].name : ' ') + '/' + (units[commitment.actors[g].unit.toString()] ? units[commitment.actors[g].unit.toString()].name : ' ') + ' por ' + '<img class="photo" src="api/user.image?size=20&_id=' + actor.user.toString() + '"/>' + (users[actor.user.toString()] ? users[actor.user.toString()].name : ' ') + '/' + (units[actor.unit.toString()] ? units[actor.unit.toString()].name : ' ') + '</p>'
                          commitment.actors[g].user = actor.user
                          commitment.actors[g].unit = actor.unit
                          break
                        }
                      }
                      await new Promise(resolve => {
                        mongo.save('commitment', {
                          _id: commitment._id,
                          actors: commitment.actors
                        }, async (err, result) => {
                          if (err) {
                            console.log(err)
                            resolve()
                          } else {
                            await new Promise(resolve => {
                              mongo.find('comment', {
                                collection: 'commitment',
                                document: commitment._id,
                                involved: oldUserComm
                              }, {}, async (err, comms) => {
                                if (comms && comms.length) {
                                  for (let u in comms) {
                                    comms[u].involved.push(actor.user)
                                    await new Promise(resolve => {
                                      mongo.save('comment', comms[u], () => {
                                        resolve()
                                      })
                                    })
                                  }
                                }
                                resolve()
                              })
                            })
                            let involvedActors = []
                            if (commitment.actors && commitment.actors.length) {
                              for (let v in commitment.actors) {
                                if (commitment.actors[v].path !== 'hidden' && commitment.actors[v].user.toString() !== req.session.context.user.toString()) involvedActors.push(commitment.actors[v].user)
                              }
                            }
                            const data = {
                              document: commitment._id,
                              comment: comment,
                              collection: 'commitment',
                              involved: involvedActors
                            }
                            req.app.routes.comment.save(req, mongo, () => {
                              resolve()
                            }, data)
                          }
                        })
                      })
                      var evidences = await new Promise(resolve => {
                        mongo.find('evidence', {
                          reference: commitment._id
                        }, {
                          _id: 1,
                          name: 1,
                          actors: 1
                        }, (err, evidences) => {
                          if (!err) {
                            resolve(evidences)
                          } else {
                            resolve(false)
                          }
                        })
                      })
                      if (evidences) {
                        for (const e in evidences) {
                          let comment = ''
                          const evidence = evidences[e]
                          let oldUserEvi = ''
                          for (var x in evidence.actors) {
                            if (evidence.actors[x].role === 'responsible' && (evidence.actors[x].user && oldUser.toString() === evidence.actors[x].user.toString())) {
                              oldUserEvi = evidence.actors[x].user
                              comment = '<p>Cambió a ' + '<img class="photo" src="api/user.image?size=20&_id=' + evidence.actors[x].user.toString() + '"/>' + (users[evidence.actors[x].user.toString()] ? users[evidence.actors[x].user.toString()].name : ' ') + '/' + (units[evidence.actors[x].unit.toString()] ? units[evidence.actors[x].unit.toString()].name : ' ') + ' por ' + '<img class="photo" src="api/user.image?size=20&_id=' + actor.user.toString() + '"/>' + (users[actor.user.toString()] ? users[actor.user.toString()].name : ' ') + '/' + (units[actor.unit.toString()] ? units[actor.unit.toString()].name : ' ') + '</p>'
                              evidence.actors[x].user = actor.user
                              evidence.actors[x].unit = actor.unit
                              break
                            }
                          }
                          await new Promise(resolve => {
                            mongo.save('evidence', {
                              _id: evidence._id,
                              actors: evidence.actors
                            }, async (err, result) => {
                              if (err) {
                                console.log(err)
                                resolve()
                              } else {
                                await new Promise(resolve => {
                                  mongo.find('comment', {
                                    collection: 'evidence',
                                    document: evidence._id,
                                    involved: oldUserEvi
                                  }, {}, async (err, comms) => {
                                    if (comms && comms.length) {
                                      for (let u in comms) {
                                        comms[u].involved.push(actor.user)
                                        await new Promise(resolve => {
                                          mongo.save('comment', comms[u], () => {
                                            resolve()
                                          })
                                        })
                                      }
                                    }
                                    resolve()
                                  })
                                })
                                let involvedActors = []
                                if (evidence.actors && evidence.actors.length) {
                                  for (let v in evidence.actors) {
                                    if (evidence.actors[v].path !== 'hidden' && evidence.actors[v].user.toString() !== req.session.context.user.toString()) involvedActors.push(evidence.actors[v].user)
                                  }
                                }
                                const data = {
                                  document: evidence._id,
                                  comment: comment,
                                  collection: 'evidence',
                                  involved: involvedActors
                                }
                                req.app.routes.comment.save(req, mongo, () => {
                                  resolve()
                                }, data)
                              }
                            })
                          })
                        }
                      }
                    }
                  }
                }
                //break
              } else {
                let comment = ''
                comment = '<p>Agregó a ' + '<img class="photo" src="api/user.image?size=20&_id=' + actor.user.toString() + '"/>' + (users[actor.user.toString()] ? users[actor.user.toString()].name : ' ') + '/' + (units[actor.unit.toString()] ? units[actor.unit.toString()].name : ' ') + '</p>'

                atts[i].actors.push({
                  user: actor.user,
                  unit: actor.unit,
                  path: 'received',
                  role: 'responsible'
                })
                await new Promise(resolve => {
                  mongo.save('attached', {
                    _id: atts[i]._id,
                    responsible: atts[i].responsible,
                    actors: atts[i].actors
                  }, async (err, result) => {
                    if (err) {
                      console.log(err)
                      resolve()
                    } else {
                      let involvedActors = []
                      if (atts[i].actors && atts[i].actors.length) {
                        for (let v in atts[i].actors) {
                          if (atts[i].actors[v].path !== 'hidden' && atts[i].actors[v].user.toString() !== req.session.context.user.toString()) involvedActors.push(atts[i].actors[v].user)
                        }
                      }
                      const data = {
                        document: atts[i]._id,
                        comment: comment,
                        collection: 'attached',
                        involved: involvedActors
                      }
                      req.app.routes.comment.save(req, mongo, () => {
                        resolve()
                      }, data)
                    }
                  })
                })
              }
            }
            send()
          }
        })
      }
    })
  }

  this.changeAnalyzing = function (req, mongo, send) {
    mongo.findId('attached', req.query._id, async (err, doc) => {
      if (err) {
        console.log(err)
        send()
      } else {
        doc.status = req.query.status
        await new Promise(resolve => {
          req.app.routes.eventUtil.save(req, mongo, 'statusChange', doc.status, doc._id, '', 'attached', () => {
            resolve()
          })
        })
        mongo.save('attached', doc, async (err) => {
          if (err) {
            send()
          } else {
            send()

            if (doc.status === 'analyzing') {

              /*await new Promise(resolve => {
                                mongo.find('reminders', {
                                document: mongo.toId(doc._id)
                                }, {}, (err, rem) => {
                                if (rem && rem.length) {
                                    for (let f in rem) {
                                    rem[f].status = 'inactive'
                                    rem[f].cleared = new Date()
                                    mongo.save('reminders', rem[f], () => {
                                        resolve()
                                    })
                                    }
                                } else {
                                    resolve()
                                }
                                })
                            })*/

              await new Promise(resolve => {
                mongo.findOne('commitment', { reference: doc._id }, { content: 0 }, (err, co) => {
                  if (err || !co) {
                    resolve()
                  } else {
                    mongo.find('reminders', {
                      document: mongo.toId(co._id)
                    }, {}, (err, rem) => {
                      if (rem && rem.length) {
                        for (let f in rem) {
                          rem[f].status = 'inactive'
                          rem[f].cleared = new Date()
                          mongo.save('reminders', rem[f], () => {
                            resolve()
                          })
                        }
                      } else {
                        resolve()
                      }
                    })
                  }
                })
              })

            } else if (doc.status === 'answered') {

              /*await new Promise(resolve => {
                                mongo.findN('reminders', 0, 1, { document: doc._id }, {}, { _id:-1 }, async (err, rem) => {
                                    if (err) {
                                        resolve()
                                    } else if (rem && rem.length) {
                                        rem = rem[0]
                                        rem.status = 'active'
                                        rem.cleared = new Date()
                                        mongo.save('reminders', rem, () => {
                                            resolve()
                                        })
                                    } else resolve()
                                })
                            })*/

              await new Promise(resolve => {
                mongo.findOne('commitment', { reference: doc._id }, { content: 0 }, (err, co) => {
                  if (err || !co) {
                    resolve()
                  } else {
                    mongo.findN('reminders', 0, 1, { document: co._id }, {}, { _id: -1 }, async (err, rem) => {
                      if (err) {
                        resolve()
                      } else if (rem && rem.length) {
                        rem = rem[0]
                        rem.status = 'active'
                        rem.cleared = new Date()
                        mongo.save('reminders', rem, () => {
                          resolve()
                        })
                      } else resolve()
                    })
                  }
                })
              })

            }

            let data = {
              id: doc._id,
              status: doc.status
            }
            notification.send(req, req.session.context.room, 'dtattacheds', data, null, null)
          }
        })
      }
    })
  }

  this.getResponsibles = function (req, mongo, send) {
    mongo.findId('note', req.query._id, async (err, doc) => {
      if (err) {
        console.log(err)
        send()
      } else {
        var ids = []
        for (var i in doc.actors) {
          if (doc.actors[i].role !== 'from') {
            ids.push(doc.actors[i].user)
          }
        }
        mongo.find('user', {
          _id: {
            $in: ids
          }
        }, {
          name: 1
        }, (err, users) => {
          if (err) {
            console.log(err)
            send()
          } else {
            var data = []
            for (let i in users) {
              data.push({
                id: users[i]._id,
                name: users[i].name,
              })
            }
            send(data)
          }
        })
      }
    })
  }

  this.ByResponsible = function (req, mongo, send) {
    var body = req.query
    mongo.find('attached', {
      reference: mongo.toId(body.note)
    }, {}, {}, async (err, docs) => {
      if (err) {
        console.log(err)
        send()
      } else {
        var data = []
        var responsible, name
        for (var i in docs) {
          for (let u in docs[i].actors) {
            if (docs[i].actors[u].role === 'responsible') {
              responsible = docs[i].actors[u].user.toString()
              break
            }
          }
          name = await new Promise(resolve => {
            mongo.findId('user', responsible, {
              name: 1
            }, (err, user) => {
              if (err) {
                console.log(err)
                resolve('')
              } else if (!user) {
                resolve('')
              } else {
                resolve(user.name)
              }
            })
          })
          data.push({
            id: docs[i]._id,
            user: responsible,
            status: docs[i].status,
            nameUser: name,
            name: docs[i].name,
            ch1: body.responsible === responsible ? 'on' : 'off'
          })
        }
        send(data)
      }
    })
  }

  this.kanban = async function (req, mongo, send) {
    let period = req.query.period
    var keys = await this.$keys(req, mongo)
    keys.status = {
      $nin: ['completed', 'done']
    }
    if (period && period.start && period.end) {
      keys.dates = {
        $elemMatch: {
          value: {
            $gte: new Date(period.start),
            $lte: new Date(new Date(period.end).setHours(23, 59, 59))
          },
          type: 'deadline'
        }
      }
    } else if (period && period.start) {
      keys.dates = {
        $elemMatch: {
          value: {
            $gte: new Date(period.start)
          },
          type: 'deadline'
        }
      }
    }
    mongo.aggregate('attached', [{
      $match: keys
    },
    {
      $lookup: {
        from: 'note',
        let: {
          find: '$reference'
        },
        pipeline: [{
          $match: {
            $expr: {
              $and: [{
                $eq: ['$_id', '$$find']
              }]
            }
          }
        },
        {
          $project: {
            _id: 1,
            name: 1,
            sequence: 1
          }
        }
        ],
        as: 'note'
      }
    },
    {
      $project: {
        _id: 1,
        actors: 1,
        dates: 1,
        tags: 1,
        responsible: 1,
        sequence: 1,
        status: 1,
        name: 1,
        note: '$note'
      }
    }
    ], {}, (err, attacheds) => {
      if (err) throw err
      mongo.toHash('user', {}, async (err, users) => {
        if (err) throw err
        const data = []
        let ex = 0
        let pen = 0
        let ex7 = 0
        let ans = 0
        let toAns = 0
        let wr = 0
        let info = 0
        for (const i in attacheds) {
          var doc = attacheds[i]
          const note = doc.note[0]
          var actor = {
            user: ''
          }
          for (let i in doc.actors) {
            if (doc.actors[i].role === 'responsible') {
              actor = {
                user: doc.actors[i].user
              }
              break;
            }
          }
          //const actor = { user: doc.responsible ? doc.responsible.split('&')[0] : '' }
          let deadline
          if (doc.dates) {
            doc.dates.findIndex((x) => {
              if (x.type === 'deadline') deadline = x.value
            })
          }
          if (deadline && doc.status === 'processing') {
            var suma7dias = 7 * 24 * 60 * 60 * 1000
            if (deadline.setHours(0, 0, 0, 0, 0) < new Date().setHours(0, 0, 0, 0, 0) &&
                            deadline.setHours(0, 0, 0, 0, 0) !== new Date().setHours(0, 0, 0, 0, 0)) {
              ex++
              data.push({
                id: doc._id.toString(),
                status: 'expired',
                text: note.sequence && note.sequence.text ? doc.name + '</br>' + '<b>[' + note.sequence.text + ']</b>' + ' - ' + note.name : doc.name + ' - ' + note.name,
                userId: actor.user.toString(),
                userName: users[actor.user.toString()] ? users[actor.user.toString()].name.replace(/(<([^>]+)>)/g, '') : '',
                color: 'red'
              })
            } else if (deadline.setHours(0, 0, 0, 0, 0) > new Date().setHours(0, 0, 0, 0, 0) &&
                            deadline.setHours(0, 0, 0, 0, 0) < new Date().setHours(0, 0, 0, 0, 0) + suma7dias) {
              ex7++
              data.push({
                id: doc._id.toString(),
                status: 'pending1week',
                text: note.sequence && note.sequence.text ? doc.name + '</br>' + '<b>[' + note.sequence.text + ']</b>' + ' - ' + note.name : doc.name + ' - ' + note.name,
                userId: actor.user.toString(),
                userName: users[actor.user.toString()] ? users[actor.user.toString()].name.replace(/(<([^>]+)>)/g, '') : '',
                color: 'green'
              })
            } else if (deadline.setHours(0, 0, 0, 0, 0) > new Date().setHours(0, 0, 0, 0, 0)) {
              pen++
              data.push({
                id: doc._id.toString(),
                status: 'pending',
                text: note.sequence && note.sequence.text ? doc.name + '</br>' + '<b>[' + note.sequence.text + ']</b>' + ' - ' + note.name : doc.name + ' - ' + note.name,
                userId: actor.user.toString(),
                userName: users[actor.user.toString()] ? users[actor.user.toString()].name.replace(/(<([^>]+)>)/g, '') : '',
                color: 'green'
              })
            } else {
              info++
              data.push({
                id: doc._id.toString(),
                status: 'informative',
                text: note.sequence && note.sequence.text ? doc.name + '</br>' + '<b>[' + note.sequence.text + ']</b>' + ' - ' + note.name : doc.name + ' - ' + note.name,
                userId: actor.user.toString(),
                userName: users[actor.user.toString()] ? users[actor.user.toString()].name.replace(/(<([^>]+)>)/g, '') : '',
                color: 'green'
              })
            }
          }
          if (doc.status === 'answered') {
            ans++
            data.push({
              id: doc._id.toString(),
              status: 'answered',
              text: note.sequence && note.sequence.text ? doc.name + '</br>' + '<b>[' + note.sequence.text + ']</b>' + ' - ' + note.name : doc.name + ' - ' + note.name,
              userId: actor.user.toString(),
              userName: users[actor.user.toString()] ? users[actor.user.toString()].name.replace(/(<([^>]+)>)/g, '') : '',
              color: '#4ACFCB'
            })
          }
          if (doc.responsible && doc.status === 'processing' && req.session.context.user.toString() === doc.responsible.split('&')[0]) {
            toAns++
            data.push({
              id: doc._id.toString(),
              status: 'toAnswered',
              text: note.sequence && note.sequence.text ? doc.name + '</br>' + '<b>[' + note.sequence.text + ']</b>' + ' - ' + note.name : doc.name + ' - ' + note.name,
              userId: actor.user.toString(),
              userName: users[actor.user.toString()] ? users[actor.user.toString()].name.replace(/(<([^>]+)>)/g, '') : '',
              color: '#4ACFCB'
            })
          }
          if (doc.status === 'draft' || doc.status === 'prepared') {
            wr++
            data.push({
              id: doc._id.toString(),
              status: 'writing',
              text: note.sequence && note.sequence.text ? doc.name + '</br>' + '<b>[' + note.sequence.text + ']</b>' + ' - ' + note.name : doc.name + ' - ' + note.name,
              userId: actor.user.toString(),
              userName: users[actor.user.toString()] ? users[actor.user.toString()].name.replace(/(<([^>]+)>)/g, '') : '',
              color: '#4ACFCB'
            })
          }
        }

        if (data.length) {
          data[0].ex = ex
          data[0].ex7 = ex7
          data[0].pen = pen
          data[0].ans = ans
          data[0].toAns = toAns
          data[0].wr = wr
          data[0].info = info
        }
        send(data)
      })
    })
  }

  this.save = function (req, mongo, send) {
    var body = req.body
    let idFind = body.doc ? body.doc._id : body._id
    mongo.findId('attached', idFind, (err, docs) => {
      if (err) {
        send({
          error: err
        })
      } else {
        const doc = body.doc || body
        var date = dateformat(new Date(), 'yyyy/mm/dd')
        date = new Date(date)
        mongo.find('time', {
          task: mongo.toId(doc.task),
          project: mongo.toId(doc.project),
          date: date
        }, {}, {}, () => {
          mongo.findId('project', mongo.toId(doc.project), async () => {
            if (doc.type === 'spreadsheet') {
              doc.content = JSON.stringify(doc.content)
            }
            if (!docs) {
              docs = req.body
            }
            // Multiples responsables
            if (docs && docs.actors) {
              var actors = []
              for (let n in docs.actors) {
                if (docs.actors[n].role !== 'responsible') {
                  actors.push(docs.actors[n])
                }
              }
              doc.actors = actors
            } else {
              doc.actors = []
            }
            var responsibles = doc.responsible.split(',')
            for (let n in responsibles) {
              var responsible = responsibles[n].split('&unit=')
              doc.actors.push({
                user: responsible[0],
                unit: responsible[1],
                path: 'hidden',
                role: 'responsible'
              })
            }
            let noteStatus = await new Promise(resolve => {
              mongo.findId('note', doc.reference, (err, note) => {
                if (err) {
                  resolve('')
                }
                if (note) resolve(note.status)
                else resolve('')
              })
            })
            if (!doc.status) {
              doc.status = docs.status
            }
            if (doc.status === 'draft') {
              doc.status = 'prepared'
            }
            if (doc.status === 'prepared' && docs && (docs.status !== 'prepared' && docs.status !== 'draft')) {
              send({
                msj: '_docWithChangesReload'
              }) //Este documento tiene cambios importantes, por favor recargue el documento
              return
            } else if (doc.status === 'prepared' && noteStatus !== 'draft') {
              send({
                msj: '_cantCreateDocAlreadySent'
              }) //Este documento no se puede crear, la nota ya fue enviada
              return
            }
            delete doc.responsible
            delete doc.comment
            delete doc.user
            delete doc.timeString
            delete doc.replyTo
            delete doc.isNew
            delete doc.delegates
            delete doc.mentions
            delete doc.answerDate
            var units = req.session.units || []
            for (const i in doc.actors) {
              if (doc.actors[i].user === req.session.context.user.toString() && doc.actors[i].unit) {
                units = [mongo.toId(doc.actors[i].unit)]
                break
              }
            }
            var readers = []
            for (const i in doc.actors) {
              if (doc.actors[i].unit) {
                if (doc.actors[i].role === tags.from || units.findIndex(function (x) {
                  return x.toString() === doc.actors[i].unit
                }) !== -1) {
                  readers.push(doc.actors[i].user)
                }
              }
            }
            // Add or update dates.issue
            if (doc.dates && doc.dates.length > 0) {
              doc.dates[0].value = new Date()
            } else {
              doc.dates = [{
                type: tags.issue,
                value: new Date()
              }]
            }
            if (doc.deadline) {
              doc.dates[1] = {
                type: tags.deadline,
                value: doc.deadline
              }
              delete doc.deadline
            }
            html.getData(doc.type === 'redactor' || doc.type === 'note' ? doc.content : '', (data) => {
              if (data.links && data.links.length > 0) {
                if (!doc.links) {
                  doc.links = (docs && docs.links) ? docs.links : []
                }
                for (const i in data.links) {
                  if (doc.links.findIndex((lk) => {
                    return lk._id === data.links[i]._id
                  }) === -1) {
                    doc.links.push({
                      _id: data.links[i]._id,
                      clase: data.links[i].clase
                    })
                  }
                }
              }
              if (doc.links && doc.links[0] === '{}') {
                delete doc.linnks
              }
              if (doc.tags === '') {
                doc.tags = []
              } else {
                if (typeof doc.tags === 'string') {
                  doc.tags = doc.tags.split(',')
                }
                for (const i in doc.tags) {
                  doc.tags[i] = mongo.toId(doc.tags[i])
                }
              }
              mongo.save('attached', doc, async (err) => {
                if (err) {
                  send()
                } else {
                  await new Promise(resolve => {
                    req.app.routes.eventUtil.save(req, mongo, 'statusChange', doc.status, doc._id, '', 'attached', () => {
                      resolve()
                    })
                  })
                  send({
                    message: tags.savedChanges,
                    doc: doc
                  })
                  let data = {}
                  data.name = doc.name
                  data.status = doc.status
                  data.id = doc._id
                  if (doc.responsible) {
                    data.responsible = doc.responsible
                    let responsible = doc.responsible.split('&unit=')
                    data.responsibleId = responsible[0]
                    data.responsibleName = await new Promise(resolve => {
                      mongo.findId('user', responsible[0], (err, user) => {
                        if (err) {
                          console.log(err)
                          resolve('')
                        }
                        if (user) resolve(user.name)
                        else resolve('')
                      })
                    })
                    data.responsibleUnit = await new Promise(resolve => {
                      mongo.findId('unit', responsible[1], (err, unit) => {
                        if (err) {
                          console.log(err)
                          resolve('')
                        }
                        if (unit) resolve(unit.name)
                        else resolve('')
                      })
                    })
                  }
                  var tagsDoc = []
                  await new Promise(resolve => {
                    mongo.find('params', {
                      name: {
                        $in: ['riskLevel']
                      }
                    }, {
                      _id: 1,
                      name: 1,
                      options: 1
                    }, (err, tgsDs) => {
                      if (err) {
                        console.log(err)
                        resolve()
                      } else {
                        if (tgsDs.length > 0) {
                          for (var i in tgsDs) {
                            tagsDoc = tagsDoc.concat(tgsDs[i].options)
                          }
                        }
                        resolve()
                      }
                    })
                  })
                  var tagFoundId = doc.tags
                  for (var t in tagsDoc) {
                    if (tagFoundId && tagFoundId.toString() === tagsDoc[t].id.toString()) {
                      data.tagsname = tagsDoc[t].value
                      data.tagscolor = tagsDoc[t].color
                    }
                  }
                  notification.send(req, req.session.context.room, 'dtattacheds', data, null, null)
                  notification.send(req, req.session.context.room, 'dtAttached', null, null, null)
                  notification.send(req, req.session.context.room, 'KanbanAttached', null, null, null)
                }
              })
            })
          })
        })
      }
    })
  }

  this.saveTags = function (req, mongo, send) {
    var body = req.body
    let comment = body.comment ? body.comment : ''
    let idFind = body.doc ? body.doc._id : body._id
    mongo.findId('attached', idFind, async (err, attached) => {
      if (err) {
        send({
          error: err
        })
      } else {
        const doc = body.doc || body
        if (doc.tags === '') {
          doc.tags = []
        } else {
          if (typeof doc.tags === 'string') {
            doc.tags = doc.tags.split(',')
          }
          for (const i in doc.tags) {
            doc.tags[i] = mongo.toId(doc.tags[i])
          }
        }
        let data = {}
        data.name = doc.name
        data.status = doc.status
        data.id = doc._id
        var tagsDoc = []
        var tagsDocRisk = []
        await new Promise(resolve => {
          var pipeline = [{
            $limit: 1
          },
          {
            $lookup: {
              from: 'params',
              pipeline: [{
                $match: {
                  name: {
                    $in: ['riskLevel', 'attachedTag']
                  }
                }
              },
              {
                $project: {
                  _id: 1,
                  name: 1,
                  options: 1
                }
              }
              ],
              as: 'results'
            }
          },
          {
            $project: {
              results: 1
            }
          },
          {
            $sort: {
              _id: -1
            }
          }
          ]
          mongo.aggregate('params', pipeline, {}, (err, tgsDs) => {
            if (err) {
              console.log(err)
              resolve()
            } else {
              if (tgsDs[0].results.length > 0) {
                tgsDs = tgsDs[0].results
                for (var i in tgsDs) {
                  if (tgsDs[i].name === 'attachedTag') {
                    tagsDoc = tagsDoc.concat(tgsDs[i].options)
                  } else if (tgsDs[i].name === 'riskLevel')
                    tagsDocRisk = tagsDocRisk.concat(tgsDs[i].options)
                }
                if (tagsDoc.length > 0) {
                  for (var indexA in tagsDoc) {
                    if (tagsDoc[indexA].id.toString() === doc.attachedTag.toString()) {
                      data.tagsnameTagAttached = tagsDoc[indexA].value
                      data.tagscolorTagAttached = tagsDoc[indexA].color
                    }
                    if (attached.attachedTag && tagsDoc[indexA].id.toString() === attached.attachedTag.toString()) {
                      data.tagsnameOldTagAttached = tagsDoc[indexA].value
                      data.tagscolorOldTagAttached = tagsDoc[indexA].color
                    }
                  }
                }
                if (tagsDocRisk.length > 0) {
                  for (var index in tagsDocRisk) {
                    if (doc.tags[0] && tagsDocRisk[index].id.toString() === doc.tags[0].toString()) {
                      data.tagsnameRisk = tagsDocRisk[index].value
                      data.tagscolorRisk = tagsDocRisk[index].color
                    }
                    if (attached.tags[0] && tagsDocRisk[index].id.toString() === attached.tags[0].toString()) {
                      data.tagsnameOldRisk = tagsDocRisk[index].value
                      data.tagscolorOldRisk = tagsDocRisk[index].color
                    }
                  }
                }
              }
              resolve()
            }
          })
        })

        if (data.tagsnameOldTagAttached && (doc.attachedTag.toString() !== attached.attachedTag.toString()) && data.status !== 'prepared') {
          let comment2 = 'Se cambió la etiqueta del documento de <span class="spanTags" style="background-color:' + data.tagscolorOldTagAttached + '">' + data.tagsnameOldTagAttached + '</span>' + ' a <span class="spanTags" style="background-color:' + data.tagscolorTagAttached + '">' + data.tagsnameTagAttached + '</span>: ' + comment
          const comments = {
            document: doc._id,
            comment: comment2,
            collection: 'attached',
            involved: doc.actors,
            user: req.session.context.user
          }
          req.app.routes.comment.save(req, mongo, () => {
            send()
          }, comments)
        }
        if (doc.attachedTag && !attached.attachedTag && data.status !== 'prepared') {
          let comment2 = 'Agregó la etiqueta <span class="spanTags" style="background-color:' + data.tagscolorTagAttached + '">' + data.tagsnameTagAttached + '</span>: ' + comment
          const comments = {
            document: doc._id,
            comment: comment2,
            collection: 'attached',
            involved: doc.actors,
            user: req.session.context.user
          }
          req.app.routes.comment.save(req, mongo, () => {
            send()
          }, comments)
        }
        if (data.tagsnameOldRisk && (doc.tags[0].toString() !== attached.tags[0].toString()) && data.status !== 'prepared') {
          let comment2 = 'Se cambió el nivel de riesgo del documento de <span class="spanTags" style="background-color:' + data.tagscolorOldRisk + '">' + data.tagsnameOldRisk + '</span>' + ' a <span class="spanTags" style="background-color:' + data.tagscolorRisk + '">' + data.tagsnameRisk + '</span>: ' + comment
          const comments = {
            document: doc._id,
            comment: comment2,
            collection: 'attached',
            involved: doc.actors,
            user: req.session.context.user
          }
          req.app.routes.comment.save(req, mongo, () => {
            send()
          }, comments)
        }
        if (doc.tags[0] && !attached.tags[0] && data.status !== 'prepared') {
          let comment2 = 'Agregó el nivel de riesgo <span class="spanTags" style="background-color:' + data.tagscolorRisk + '">' + data.tagsnameRisk + '</span>: ' + comment
          const comments = {
            document: doc._id,
            comment: comment2,
            collection: 'attached',
            involved: doc.actors,
            user: req.session.context.user
          }
          req.app.routes.comment.save(req, mongo, () => {
            send()
          }, comments)
        }
        mongo.save('attached', doc, async (err) => {
          if (err) {
            send()
          } else {
            notification.send(req, req.session.context.room, 'dtattacheds', data, null, null)
            notification.send(req, req.session.context.room, 'dtAttached', null, null, null)
            notification.send(req, req.session.context.room, 'KanbanAttached', null, null, null)
            send({
              message: tags.savedChanges,
              doc: doc
            })
          }
        })
      }
    })
  }

  this.searchCommitment = function (req, mongo, send) {
    if (!req.query._id) {
      send([])
    } else {
      mongo.find('commitment', {
        reference: mongo.toId(req.query._id)
      }, {}, {
        name: -1
      }, (err, commitment) => {
        if (err) {
          req.statusCode = 404
          send([])
        } else {
          send(commitment)
        }
      })
    }
  }

  this.addActor = function (req, mongo, send) {
    var body = req.body
    mongo.findId('note', body.note, async (err, doc) => {
      if (err) {
        console.log(err)
        send()
      } else {
        let index = doc.actors.findIndex((x) => {
          return x.user.toString() === body.user.split('&unit=')[0] && x.unit.toString() === body.user.split('&unit=')[1]
        })
        if (index === -1) {
          var user = await new Promise(resolve => {
            mongo.findId('user', body.user.split('&unit=')[0], (err, u) => {
              if (err) {
                console.log(err)
                resolve(false)
              } else {
                resolve({
                  _id: u._id,
                  name: u.name
                })
              }
            })
          })
          var unit = await new Promise(resolve => {
            mongo.findId('unit', body.user.split('&unit=')[1], (err, u) => {
              if (err) {
                console.log(err)
                resolve(false)
              } else {
                resolve(u.name)
              }
            })
          })
          doc.actors.push({
            user: body.user.split('&unit=')[0],
            unit: body.user.split('&unit=')[1],
            path: 'received',
            role: body.role
          })
          mongo.save('note', {
            _id: doc._id,
            actors: doc.actors
          }, (err, result) => {
            if (err) {
              console.log(err)
              send()
            } else {
              if (user && unit) {
                let comment = '<p>Agregó a ' + '<img class="photo" src="api/user.image?size=20&_id=' + user._id.toString() + '"/>' + user.name + '/' + unit + '</p>'
                const data = {
                  document: doc._id,
                  comment: comment,
                  collection: 'note'
                }
                req.app.routes.comment.save(req, mongo, () => {
                  send()
                }, data)
              } else {
                send({})
              }
            }
          })
        } else send()
      }
    })
  }

  this.addActors = function (req, id, actors, mongo, next) {
    mongo.findId('attached', id, {
      actors: 1,
      issued: 1,
      reference: 1
    }, async (err, doc) => {
      if (err || !doc) {
        next(err)
      } else {
        //let path = ''
        let role = ''
        let index = doc.actors.findIndex((x) => {
          return x.user.toString() === req.session.context.user.toString()
        })
        /* if (index !== -1) {
                  path = doc.actors[index].path
                } */
        for (let i in actors) {
          if (index !== -1) {
            let checkActorLicense = await new Promise(resolve => {
              mongo.findId('user', actors[i].user, (err, user) => {
                if (user && !user.licensedUser) {
                  resolve(true)
                } else {
                  resolve(false)
                }
              })
            })
            if (doc.actors[index].role === 'responsible' && checkActorLicense) {
              let unitsArray = await new Promise(resolve => {
                mongo.find('unit', {
                  actors: {
                    $elemMatch: {
                      user: mongo.toId(actors[i].user)
                    }
                  }
                }, {
                  _id: 1
                }, (err, units) => {
                  if (units && units.length) {
                    resolve(units)
                  } else {
                    resolve([])
                  }
                })
              })
              let concatUnits = req.session.context.dependentUnits.concat(req.session.context.managerUnits)
              let exists = false
              for (let i in concatUnits) {
                for (let u in unitsArray) {
                  if (unitsArray[u]._id.toString() === concatUnits[i].toString()) {
                    exists = true
                    break
                  }
                }
                if (exists) break
              }
              if (exists) role = 'co-responsible'
            }
          }
          let rm = doc.actors.findIndex((actor) => {
            return actor.user.toString() === actors[i].user.toString()
          })
          if (rm === -1) {
            //if (path && actors[i].role !== 'copy') actors[i].path = path
            if (role) actors[i].role = role
            doc.actors.push(actors[i])
          }
        }
        mongo.save('attached', doc, async (err) => {
          let note = await new Promise(resolve => {
            mongo.findId('note', doc.reference, (err, note) => {
              if (note) resolve(note)
              else resolve(false)
            })
          })
          if (note) {
            await new Promise(resolve => {
              for (let i in actors) {
                let rm = note.actors.findIndex((actor) => {
                  return actor.user.toString() === actors[i].user.toString()
                })
                if (rm === -1) {
                  //if (path) actors[i].path = path
                  note.actors.push(actors[i])
                }
              }
              mongo.save('note', note, () => {
                if (role !== 'co-responsible') {
                  mongo.find('attached', {
                    reference: note._id
                  }, {}, async (err, atts) => {
                    if (atts && atts.length) {
                      for (let t in atts) {
                        for (let i in actors) {
                          let rm = atts[t].actors.findIndex((actor) => {
                            return actor.user.toString() === actors[i].user.toString()
                          })
                          if (rm === -1) {
                            //if (path) actors[i].path = path
                            atts[t].actors.push(actors[i])
                          }
                        }
                        await new Promise(resolve => {
                          mongo.save('attached', atts[t], async () => {
                            mongo.findOne('commitment', {
                              reference: atts[t]._id
                            }, {
                              _id: 1,
                              actors: 1,
                              reference: 1
                            }, async (err, comm) => {
                              if (comm) {
                                for (let i in actors) {
                                  let rm = comm.actors.findIndex((actor) => {
                                    return actor.user.toString() === actors[i].user.toString()
                                  })
                                  if (rm === -1) {
                                    //if (path) actors[i].path = path
                                    comm.actors.push(actors[i])
                                  }
                                }
                                await new Promise(resolve => {
                                  mongo.save('commitment', comm, () => {
                                    mongo.findOne('evidence', {
                                      reference: comm._id
                                    }, {
                                      _id: 1,
                                      actors: 1,
                                      reference: 1
                                    }, async (err, evid) => {
                                      if (evid) {
                                        for (let i in actors) {
                                          let rm = evid.actors.findIndex((actor) => {
                                            return actor.user.toString() === actors[i].user.toString()
                                          })
                                          if (rm === -1) {
                                            //if (path) actors[i].path = path
                                            evid.actors.push(actors[i])
                                          }
                                        }
                                        await new Promise(resolve => {
                                          mongo.save('evidence', evid, () => {
                                            resolve()
                                          })
                                        })
                                      }
                                      resolve()
                                    })
                                  })
                                })
                              }
                            })
                          })
                          resolve()
                        })
                      }
                    }
                    resolve()
                  })
                } else {
                  resolve()
                }
              })
            })
          }
          next(err, doc)
        })
      }
    })
  }

  this.getReviewers = function (req, mongo, send) {
    mongo.findId('attached', req.query._id, {}, (err, document) => {
      if (err) throw err
      var users = []
      var units = []

      var data = []
      if (document) {
        for (const a in document.actors) {
          if (document.actors[a]) {
            var actor = document.actors[a]
            users.push(actor.user)
            units.push(actor.unit)
          }
        }
        mongo.toHash('user', {
          _id: {
            $in: users
          }
        }, {
          _id: 1,
          name: 1
        }, (er, users) => {
          mongo.toHash('unit', {
            _id: {
              $in: units
            }
          }, {
            _id: 1,
            name: 1
          }, (_er, units) => {
            for (const a in document.actors) {
              if (document.actors[a]) {
                var dataactor = document.actors[a]
                data.push({
                  id: dataactor.user,
                  name: dataactor.user ? users[dataactor.user.toString()].name : null,
                  path: dataactor.path,
                  role: dataactor.role,
                  unit: dataactor.unit,
                  unitName: dataactor.unit ? units[dataactor.unit.toString()] ? units[dataactor.unit.toString()].name : '' : null,
                  supervisor: dataactor.supervisor
                })
              }
            }
            send(data)
          })
        })
      }
    })
  }
  this.changeActor = function (req, mongo, send) {
    mongo.findId('attached', mongo.toId(req.body._id), {
      _id: 1,
      actors: 1,
      responsible: 1,
      reference: 1
    }, {}, async (err, attached) => {
      if (err) {
        send({
          error: 'error'
        })
      } else {
        var users = await new Promise(resolve => {
          mongo.toHash('user', {}, {
            _id: 1,
            name: 1
          }, (err, users) => {
            if (!err) {
              resolve(users)
            }
          })
        })
        var units = await new Promise(resolve => {
          mongo.toHash('unit', {}, {
            _id: 1,
            name: 1
          }, (err, units) => {
            if (!err) {
              resolve(units)
            }
          })
        })
        var vec = req.body.new
        var user = vec.split('&unit=')[0]
        var unit = vec.split('&unit=')[1]
        var oldUser = req.body.old
        attached.actors.forEach(u => {
          if (u.user.toString() === oldUser.user && u.unit.toString() === oldUser.unit) {
            u.user = user
            u.unit = unit
          }
        })
        /* if (attached.responsible.includes(oldUser.user) && attached.responsible.includes(oldUser.unit)) {
                  attached.responsible = user + '&unit=' + unit
                } */
        var note = await new Promise(resolve => {
          mongo.find('note', {
            _id: attached.reference
          }, {
            _id: 1,
            name: 1,
            actors: 1,
            from: 1,
            to: 1,
            copy: 1
          }, (err, note) => {
            if (!err) {
              resolve(note[0])
            } else {
              resolve(false)
            }
          })
        })
        const regex = new RegExp(oldUser.user + '&unit=' + oldUser.unit, 'i')
        var attachedsExists = await new Promise(resolve => {
          mongo.find('attached', {
            $and: [{
              reference: attached.reference
            }, {
              responsible: regex
            }, {
              _id: {
                $ne: attached._id
              }
            }]
          }, {
            _id: 1,
            name: 1
          }, (err, attacheds) => {
            if (!err && attacheds.length > 0) {
              resolve(true)
            } else {
              resolve(false)
            }
          })
        })

        const exists = note.actors.findIndex((u) => {
          return u.user.toString() === oldUser.user && u.unit.toString() === oldUser.unit
        })

        if (exists !== -1 && !attachedsExists) {
          note.actors[exists].user = user
          note.actors[exists].unit = unit
        } else {
          const exists2 = note.actors.findIndex((u) => {
            return u.user.toString() === user && u.unit.toString() === unit
          })
          if (exists2 === -1) {
            note.actors.push({
              user: user,
              unit: unit,
              role: 'to',
              path: 'received'
            })
          }
        }
        let from = ''
        let to = ''
        let copy = ''
        note.actors.forEach(a => {
          if (a.role === 'from') {
            from = a.user.toString() + '&unit=' + a.unit.toString()
          }
          if (a.role === 'to') {
            to = to + a.user.toString() + '&unit=' + a.unit.toString() + ','
          }
          if (a.role === 'copy') {
            copy = copy + a.user.toString() + '&unit=' + a.unit.toString() + ','
          }
        })
        if (to.length > 0) {
          to = to.slice(0, -1)
        }
        if (copy.length > 0) {
          copy = copy.slice(0, -1)
        }
        note.from = from
        note.to = to
        note.copy = copy
        await new Promise(resolve => {
          mongo.save('note', note, (err, result) => {
            if (!err) {
              mongo.find('comment', {
                collection: 'note',
                document: note._id,
                involved: mongo.toId(oldUser.user)
              }, {}, async (err, comms) => {
                if (comms && comms.length) {
                  for (let u in comms) {
                    comms[u].involved.push(user)
                    await new Promise(resolve => {
                      mongo.save('comment', comms[u], () => {
                        resolve()
                      })
                    })
                  }
                }
                resolve(result)
              })
            } else resolve()
          })
        })

        var commitments = await new Promise(resolve => {
          mongo.find('commitment', {
            reference: attached._id
          }, {
            _id: 1,
            name: 1,
            actors: 1
          }, (err, commitments) => {
            if (!err) {
              resolve(commitments)
            } else {
              resolve(false)
            }
          })
        })
        if (commitments) {
          for (const c in commitments) {
            const commitment = commitments[c]
            commitment.actors.forEach(u => {
              if (u.user.toString() === oldUser.user && u.unit.toString() === oldUser.unit) {
                u.user = user
                u.unit = unit
              }
            })
            var evidences = await new Promise(resolve => {
              mongo.find('evidence', {
                reference: commitment._id
              }, {
                _id: 1,
                name: 1,
                actors: 1
              }, (err, evidences) => {
                if (!err) {
                  resolve(evidences)
                } else {
                  resolve(false)
                }
              })
            })
            if (evidences) {
              for (const e in evidences) {
                const evidence = evidences[e]
                evidence.actors.forEach(u => {
                  if (u.user.toString() === oldUser.user && u.unit.toString() === oldUser.unit) {
                    u.user = user
                    u.unit = unit
                  }
                })
                await new Promise(resolve => {
                  mongo.save('evidence', evidence, (err, result) => {
                    if (!err) {
                      mongo.find('comment', {
                        collection: 'evidence',
                        document: evidence._id,
                        involved: mongo.toId(oldUser.user)
                      }, {}, async (err, comms) => {
                        if (comms && comms.length) {
                          for (let u in comms) {
                            comms[u].involved.push(user)
                            await new Promise(resolve => {
                              mongo.save('comment', comms[u], () => {
                                resolve()
                              })
                            })
                          }
                        }
                        resolve(result)
                      })
                    } else resolve()
                  })
                })
              }
            }
            await new Promise(resolve => {
              mongo.save('commitment', commitment, (err, result) => {
                if (!err) {
                  mongo.find('comment', {
                    collection: 'commitment',
                    document: commitment._id,
                    involved: mongo.toId(oldUser.user)
                  }, {}, async (err, comms) => {
                    if (comms && comms.length) {
                      for (let u in comms) {
                        comms[u].involved.push(user)
                        await new Promise(resolve => {
                          mongo.save('comment', comms[u], () => {
                            resolve()
                          })
                        })
                      }
                    }
                    resolve(result)
                  })
                } else resolve()
              })
            })
          }
        }
        await new Promise(resolve => {
          mongo.save('attached', attached, (err, result) => {
            if (!err) {
              mongo.find('comment', {
                collection: 'attached',
                document: attached._id,
                involved: mongo.toId(oldUser.user)
              }, {}, async (err, comms) => {
                if (comms && comms.length) {
                  for (let u in comms) {
                    comms[u].involved.push(user)
                    await new Promise(resolve => {
                      mongo.save('comment', comms[u], () => {
                        resolve()
                      })
                    })
                  }
                }
                resolve(result)
              })
            } else resolve()
          })
        })
        let comment = '<p>Cambió a ' + '<img class="photo" src="api/user.image?size=20&_id=' + oldUser.user + '"/>' + (users[oldUser.user] ? users[oldUser.user].name : ' ') + '/' + (units[oldUser.unit] ? units[oldUser.unit].name : ' ') + ' por ' + '<img class="photo" src="api/user.image?size=20&_id=' + user + '"/>' + (users[user] ? users[user].name : ' ') + '/' + (units[unit] ? units[unit].name : ' ') + '</p>'
        comment = comment + '<p>' + req.body.comment + '</p>'
        let involvedActors = []
        if (attached.actors && attached.actors.length) {
          for (let v in attached.actors) {
            if (attached.actors[v].path !== 'hidden' && attached.actors[v].user.toString() !== req.session.context.user.toString()) involvedActors.push(attached.actors[v].user)
          }
        }
        const data = {
          document: attached._id,
          comment: comment,
          collection: 'attached',
          involved: involvedActors
        }
        req.app.routes.comment.save(req, mongo, () => {
          send({
            message: tags.savedChanges
          })
        }, data)
      }
    })
  }
  this.changeProgress = function (req, mongo, send) {
    mongo.findId('attached', req.query.idDoc, (err, doc) => {
      if (!err && doc) {
        doc.realProgress = Number(req.query.progress)
        mongo.save('attached', doc, (err) => {
          if (err) {
            req.logger.log(err)
          } else {
            req.query = doc
            send({
              message: tags.savedChanges,
              doc: doc
            })
          }
        })
      } else {
        send()
      }
    })
  }
  this.deleteReviser = function (req, mongo, send) {
    mongo.findId('attached', req.query.idDoc, (err, doc) => {
      if (err) {
        req.logger.log(err)
      } else {
        const index = doc.actors.findIndex((x) => {
          return x.user.toString() === req.query.id
        })
        doc.actors.splice(index, 1)
        mongo.save('attached', doc, (err) => {
          if (err) {
            req.logger.log(err)
          } else {
            send({})
          }
        })
      }
    })
  }
  this.annulled = function (req, mongo, send) {
    var body = req.body
    let comment = body.comment ? body.comment : ''
    mongo.findId('attached', body._id, async (err, atts) => {
      if (err || !atts) {
        if (err) console.log(err)
        send()
      } else {
        let actorOrigen = ''
        let continuar = false
        let actors = atts.actors
        let indexReviser = actors.findIndex((x) => {
          return x.role === 'reviser' && x.path === 'sent'
        })
        let indexFrom = actors.findIndex((x) => {
          return x.role === 'from'
        })
        if (indexFrom !== -1) {
          actorOrigen = atts.actors[indexFrom]
          continuar = true
        } else if (indexReviser !== -1) {
          actorOrigen = atts.actors[indexReviser]
          continuar = true
        }
        if (continuar) {
          for (let a in atts.actors) {
            let actor = atts.actors[a]
            if (actor.user.toString() !== actorOrigen.user.toString()) {
              actor.path = 'hidden'
            }
          }
          await new Promise(resolve => {
            mongo.save('attached', {
              _id: atts._id,
              status: 'annulled',
              actors: atts.actors
            }, async () => {
              await new Promise(resolve => {
                req.app.routes.eventUtil.save(req, mongo, 'statusChange', 'annulled', atts._id, comment, 'attached', () => {
                  resolve()
                })
              })

              await new Promise(resolve => {
                mongo.find('reminders', {
                  document: mongo.toId(atts._id)
                }, {}, (err, rem) => {
                  if (rem && rem.length) {
                    for (let f in rem) {
                      rem[f].status = 'inactive'
                      rem[f].cleared = new Date()
                      mongo.save('reminders', rem[f], () => {
                        resolve()
                      })
                    }
                  } else {
                    resolve()
                  }
                })
              })

              mongo.findOne('commitment', {
                reference: atts._id
              }, {
                content: 0
              }, (err, comm) => {
                if (err || !comm) {
                  resolve()
                } else {
                  for (let a in comm.actors) {
                    let actor = comm.actors[a]
                    if (actor.user.toString() !== actorOrigen.user.toString()) {
                      actor.path = 'hidden'
                    }
                  }
                  mongo.save('commitment', {
                    _id: comm._id,
                    status: 'annulled',
                    actors: comm.actors
                  }, async () => {
                    await new Promise(resolve => {
                      req.app.routes.eventUtil.save(req, mongo, 'statusChange', 'annulled', comm._id, comment, 'commitment', () => {
                        resolve()
                      })
                    })

                    await new Promise(resolve => {
                      mongo.find('reminders', {
                        document: mongo.toId(comm._id)
                      }, {}, (err, rem) => {
                        if (rem && rem.length) {
                          for (let f in rem) {
                            rem[f].status = 'inactive'
                            rem[f].cleared = new Date()
                            mongo.save('reminders', rem[f], () => {
                              resolve()
                            })
                          }
                        } else {
                          resolve()
                        }
                      })
                    })

                    resolve()
                  })
                }
              })
            })
          })
          mongo.find('attached', {
            reference: mongo.toId(atts.reference)
          }, {}, {
            name: -1
          }, async (err, attached) => {
            if (err) {
              send()
            } else {
              let attended = true
              if (attached.length > 0) {
                for (const i in attached) {
                  let comm = await new Promise(resolve => {
                    mongo.findOne('commitment', {
                      reference: mongo.toId(attached[i]._id)
                    }, {
                      status: 1
                    }, (err, result) => {
                      if (err || !result) {
                        resolve('')
                      } else {
                        resolve(result)
                      }
                    })
                  })
                  if ((attached[i].status !== 'completed' && attached[i].status !== 'annulled') && (comm && comm.status !== 'accepted')) {
                    attended = false
                    break
                  }
                }
              } else {
                attended = false
              }
              if (attended) {
                await new Promise(resolve => {
                  mongo.save('note', {
                    _id: mongo.toId(atts.reference),
                    status: 'attended'
                  }, (err, result) => {
                    if (!err) {
                      req.app.routes.eventUtil.save(req, mongo, 'statusChange', 'attended', atts.reference, '', 'note', () => {
                        resolve(result)
                      })
                    } else {
                      resolve()
                    }
                  })
                })
              }
              send()
            }
          })
        } else {
          send()
        }
      }
    })
  }
  this.completed = function (req, mongo, send) {
    var body = req.body
    let comment = body.comment ? body.comment : ''
    mongo.findId('attached', body._id, async (err, atts) => {
      if (err || !atts) {
        if (err) console.log(err)
        send()
      } else if (['completed', 'anulled'].includes(atts.status)) {
        send()
      } else {
        mongo.save('attached', {
          _id: atts._id,
          status: 'completed',
          realProgress: 100
        }, async () => {
          await new Promise(resolve => {
            req.app.routes.eventUtil.save(req, mongo, 'statusChange', 'completed', atts._id, comment, 'attached', () => {
              resolve()
            })
          })

          await new Promise(resolve => {
            mongo.find('reminders', {
              document: mongo.toId(atts._id)
            }, {}, (err, rem) => {
              if (rem && rem.length) {
                for (let f in rem) {
                  rem[f].status = 'inactive'
                  rem[f].cleared = new Date()
                  mongo.save('reminders', rem[f], () => {
                    resolve()
                  })
                }
              } else {
                resolve()
              }
            })
          })

          mongo.findOne('commitment', {
            reference: atts._id
          }, {
            content: 0
          }, (err, comm) => {
            if (err || !comm) {
              mongo.find('attached', {
                reference: mongo.toId(atts.reference)
              }, {}, {
                name: -1
              }, async (err, attached) => {
                if (err) {
                  send()
                } else {
                  let attended = true
                  if (attached.length > 0) {
                    for (const i in attached) {
                      let comm = await new Promise(resolve => {
                        mongo.findOne('commitment', {
                          reference: mongo.toId(attached[i]._id)
                        }, {
                          status: 1
                        }, (err, result) => {
                          if (err || !result) {
                            resolve('')
                          } else {
                            resolve(result)
                          }
                        })
                      })
                      if ((attached[i].status !== 'completed' && attached[i].status !== 'annulled') && (comm && comm.status !== 'accepted')) {
                        attended = false
                        break
                      }
                    }
                  } else {
                    attended = false
                  }
                  if (attended) {
                    await new Promise(resolve => {
                      mongo.save('note', {
                        _id: mongo.toId(atts.reference),
                        status: 'attended'
                      }, (err, result) => {
                        if (!err) {
                          req.app.routes.eventUtil.save(req, mongo, 'statusChange', 'attended', atts.reference, '', 'note', () => {
                            resolve(result)
                          })
                        } else {
                          resolve()
                        }
                      })
                    })
                  }
                  send()
                }
              })
            } else {
              for (let a in comm.actors) {
                let actor = comm.actors[a]
                if (actor.path === 'hidden') {
                  actor.path = 'received'
                }
              }
              mongo.save('commitment', {
                _id: comm._id,
                status: 'canceled',
                actors: comm.actors
              }, async () => {
                await new Promise(resolve => {
                  req.app.routes.eventUtil.save(req, mongo, 'statusChange', 'canceled', comm._id, comment, 'commitment', () => {
                    resolve()
                  })
                })

                await new Promise(resolve => {
                  mongo.find('reminders', {
                    document: mongo.toId(comm._id)
                  }, {}, (err, rem) => {
                    if (rem && rem.length) {
                      for (let f in rem) {
                        rem[f].status = 'inactive'
                        rem[f].cleared = new Date()
                        mongo.save('reminders', rem[f], () => {
                          resolve()
                        })
                      }
                    } else {
                      resolve()
                    }
                  })
                })

                mongo.find('evidence', {
                  reference: comm._id
                }, {
                  content: 0
                }, async (err, evis) => {
                  if (err || !evis.length) {
                    mongo.find('attached', {
                      reference: mongo.toId(atts.reference)
                    }, {}, {
                      name: -1
                    }, async (err, attached) => {
                      if (err) {
                        send()
                      } else {
                        let attended = true
                        if (attached.length > 0) {
                          for (const i in attached) {
                            let comm = await new Promise(resolve => {
                              mongo.findOne('commitment', {
                                reference: mongo.toId(attached[i]._id)
                              }, {
                                status: 1
                              }, (err, result) => {
                                if (err || !result) {
                                  resolve('')
                                } else {
                                  resolve(result)
                                }
                              })
                            })
                            if ((attached[i].status !== 'completed' && attached[i].status !== 'annulled') && (comm && comm.status !== 'accepted')) {
                              attended = false
                              break
                            }
                          }
                        } else {
                          attended = false
                        }
                        if (attended) {
                          await new Promise(resolve => {
                            mongo.save('note', {
                              _id: mongo.toId(atts.reference),
                              status: 'attended'
                            }, (err, result) => {
                              if (!err) {
                                req.app.routes.eventUtil.save(req, mongo, 'statusChange', 'attended', atts.reference, '', 'note', () => {
                                  resolve(result)
                                })
                              } else {
                                resolve()
                              }
                            })
                          })
                        }
                        send()
                      }
                    })
                  } else {
                    for (let e in evis) {
                      for (let a in evis[e].actors) {
                        let actor = evis[e].actors[a]
                        if (actor.path === 'hidden') {
                          actor.path = 'received'
                        }
                      }
                      await new Promise(resolve => {
                        mongo.save('evidence', {
                          _id: evis[e]._id,
                          status: 'incomplete',
                          actors: evis[e].actors
                        }, async () => {
                          await new Promise(resolve2 => {
                            req.app.routes.eventUtil.save(req, mongo, 'statusChange', 'incomplete', evis[e]._id, comment, 'evidence', () => {
                              resolve2()
                            })
                          })
                          resolve()
                        })
                      })
                    }
                    mongo.find('attached', {
                      reference: mongo.toId(atts.reference)
                    }, {}, {
                      name: -1
                    }, async (err, attached) => {
                      if (err) {
                        send()
                      } else {
                        let attended = true
                        if (attached.length > 0) {
                          for (const i in attached) {
                            let comm = await new Promise(resolve => {
                              mongo.findOne('commitment', {
                                reference: mongo.toId(attached[i]._id)
                              }, {
                                status: 1
                              }, (err, result) => {
                                if (err || !result) {
                                  resolve('')
                                } else {
                                  resolve(result)
                                }
                              })
                            })
                            if ((attached[i].status !== 'completed' && attached[i].status !== 'annulled') && (comm && comm.status !== 'accepted')) {
                              attended = false
                              break
                            }
                          }
                        } else {
                          attended = false
                        }
                        if (attended) {
                          await new Promise(resolve => {
                            mongo.save('note', {
                              _id: mongo.toId(atts.reference),
                              status: 'attended'
                            }, (err, result) => {
                              if (!err) {
                                req.app.routes.eventUtil.save(req, mongo, 'statusChange', 'attended', atts.reference, '', 'note', () => {
                                  resolve(result)
                                })
                              } else {
                                resolve()
                              }
                            })
                          })
                        }
                        send()
                      }
                    })
                  }
                })
              })
            }
          })
        })
      }
    })
  }
  this.answered = function (req, mongo, send) {
    var body = req.body
    let comment = body.comment ? body.comment : ''
    mongo.findId('attached', body._id, async (err, atts) => {
      if (err || !atts) {
        if (err) console.log(err)
        send()
      } else {
        let actorOrigen = ''
        let continuar = false
        let actors = atts.actors
        let indexReviser = actors.findIndex((x) => {
          return x.role === 'reviser' && x.path === 'sent'
        })
        let indexFrom = actors.findIndex((x) => {
          return x.role === 'from'
        })
        if (indexFrom !== -1) {
          actorOrigen = atts.actors[indexFrom]
          continuar = true
        } else if (indexReviser !== -1) {
          actorOrigen = atts.actors[indexReviser]
          continuar = true
        }
        if (continuar) {
          let status = 'answered'
          if (!req.query.reactivate) {
            for (let a in atts.actors) {
              let actor = atts.actors[a]
              if (actor.user.toString() !== actorOrigen.user.toString()) {
                actor.path = 'hidden'
              }
            }
          } else {
            status = !atts.answered || atts.answered === '0' ? 'processing' : 'answered'
            for (let a in atts.actors) {
              let actor = atts.actors[a]
              if (actor.user.toString() !== actorOrigen.user.toString()) {
                if (actor.path === 'hidden') actor.path = 'received'
              }
            }
          }
          await new Promise(resolve => {
            mongo.save('attached', {
              _id: atts._id,
              status: status,
              actors: atts.actors
            }, async () => {
              await new Promise(resolve => {
                req.app.routes.eventUtil.save(req, mongo, 'statusChange', status, atts._id, comment, 'attached', () => {
                  let data = {
                    id: atts._id,
                    status: status,
                    update: true
                  }
                  notification.send(req, req.session.context.room, 'dtattacheds', data, null, null)
                  resolve()
                })
              })
              mongo.findOne('commitment', {
                reference: atts._id
              }, {
                content: 0
              }, (err, comm) => {
                if (err || !comm) {
                  resolve()
                } else {
                  if (!req.query.reactivate) {
                    for (let a in comm.actors) {
                      let actor = comm.actors[a]
                      if (actor.user.toString() !== actorOrigen.user.toString()) {
                        actor.path = 'hidden'
                      }
                    }
                  } else {
                    for (let a in comm.actors) {
                      let actor = comm.actors[a]
                      if (actor.user.toString() !== actorOrigen.user.toString()) {
                        if (actor.path === 'hidden') actor.path = 'received'
                      }
                    }
                  }
                  mongo.save('commitment', {
                    _id: comm._id,
                    status: 'ready',
                    actors: comm.actors
                  }, async () => {
                    await new Promise(resolve => {
                      req.app.routes.eventUtil.save(req, mongo, 'statusChange', 'ready', comm._id, comment, 'commitment', () => {
                        resolve()
                      })
                    })
                    resolve()
                  })
                }
              })
            })
          })
          send({ status: status || ''})
        } else {
          send()
        }
      }
    })
  }
  this.extension = function (req, mongo, send) {
    mongo.findId('attached', mongo.toId(req.body._id), {
      _id: 1,
      actors: 1,
      dates: 1
    }, {}, async (err, attached) => {
      if (err) {
        send({
          error: 'error'
        })
      } else {
        let oldDate
        if (req.body.deadlineExtension) {
          attached.dates.forEach(x => {
            if (x.type === 'deadline') {
              oldDate = x.value
              x.value = req.body.deadlineExtension
            }
          })
        }
        if (!attached.extensions) attached.extensions = []
        attached.extensions.push({
          user: req.session.context.user,
          date: req.body.deadlineExtension,
          priorDate: oldDate
        })
        await new Promise(resolve => {
          mongo.save('attached', attached, (err, result) => {
            if (!err) {
              resolve(result)
            }
          })
        })
        let comment = '<p> Cambió fecha de vencimiento del ' + moment(oldDate).format('DD/MM/YYYY') + ' al ' + moment(req.body.deadlineExtension).format('DD/MM/YYYY')
        comment = comment + '<p>' + req.body.commentExtension + '</p>'
        const data = {
          document: attached._id,
          comment: comment,
          collection: 'attached'
        }
        req.app.routes.comment.save(req, mongo, () => {
          send({
            message: tags.savedChanges
          })
        }, data)
      }
    })
  }
  this.row = function (doc, req, actor, users, usedTags) {
    var issue = {}

    var deadline = {}
    for (const x in doc.dates) {
      if (doc.dates[x].type === 'issue') {
        issue = doc.dates[x]
      } else if (doc.dates[x].type === 'deadline') {
        deadline = doc.dates[x]
      }
    }
    var attachments = 'none'
    if (doc.files && doc.files.length > 0) {
      for (const x in doc.files) {
        if (doc.files[x]) {
          attachments = 'attachment'
        }
      }
    }
    const expired = doc.status === tags.processing && deadline.value && deadline.value.getTime() <= new Date().getTime() ? tags.expired : undefined
    var tagscolor = []
    var tagsname = []
    var filterNames = [usedTags[0] ? usedTags[0].value : '']
    for (const i in usedTags) {
      tagscolor.push(usedTags[i].color)
      tagsname.push(usedTags[i].value)
    }
    var row = {
      id: doc._id.toString(),
      attachments: attachments,
      expired: expired,
      css: expired || doc.status || tags.processing,
      status: doc.status ? doc.status : tags.processing,
      statusName: doc.status,
      role: actor.role,
      user: actor.user ? actor.user : doc.user,
      sequence: doc.sequence && doc.sequence.text ? doc.sequence.text : '',
      name: doc.name,
      path: actor.path,
      pathName: actor.path,
      issue: issue.value ? tags.util.date2str(issue.value, 'yyyy/mm/dd', tags) : '',
      category: doc.category || '',
      deadline: deadline.value ? tags.util.date2str(deadline.value, 'yyyy/mm/dd', tags) : '',
      tagscolor: tagscolor,
      tagsname: tagsname,
      filterNames: filterNames,
      archived: doc.status && doc.status === 'archived' ? 'archived' : '',
      issued: doc.issued,
      content: doc.content,
      actors: doc.actors,
      icon: 'none'
    }
    if (doc.type) {
      row.type = doc.type
    }
    if (doc.task) {
      row.task = doc.task
    }
    if (doc.reference) {
      row.reference = doc.reference
      row.icon = 'attached'
    }
    if (doc.commitment) {
      row.commitment = doc.commitment
      row.icon = 'folder-clock-outline'
    }
    if (doc.evidence) {
      row.evidence = doc.evidence
      row.icon = 'evidence'
    }
    if (doc.actors) {
      for (let i in doc.actors) {
        if (doc.actors[i].role === 'responsible') {
          const user = doc.actors[i].user
          row.responsible = {
            id: user,
            name: users[user] ? users[user].name : ''
          }
          break
        }
      }
    }
    return row
  }

  this.pdf = function (req, mongo, send) {
    mongo.findId('attached', req.query._id, async (err, doc) => {
      if (!err && doc) {
        var i = 0
        while (doc.content.indexOf('{{', i) !== -1 && doc.content.substring(doc.content.indexOf('{{', i), doc.content.indexOf('{{', i) + 1) === '{') {
          i = doc.content.indexOf('{{', i)
          const f = doc.content.indexOf('}}', i)
          const word = doc.content.substring(i + 2, f)
          if (!['page', 'pages'].includes(word)) {
            doc.content = doc.content.replace(new RegExp('{{' + word + '}}', 'g'), '')
          }
          i = f + 2
        }
        if (req.query.details) {
          let user
          doc.actors.forEach(x => {
            if (x.path === 'sent' && x.role === 'reviser') {
              user = x.user
            } else if (x.path === 'sent' && x.role === 'from') {
              user = x.user
            }
          })
          if (doc.project) {
            var proj = await new Promise(resolve => {
              mongo.findId('project', doc.project, (err, project) => {
                if (!err) {
                  resolve(project)
                }
              })
            })
          }
          if (user) {
            var us = await new Promise(resolve => {
              mongo.findId('user', user, (err, user) => {
                if (!err) {
                  resolve(user)
                }
              })
            })
          }
          let i, fit, last
          if (doc.content.indexOf('id="pageFooter-last"') !== -1 || doc.content.indexOf('id="pageFooter-last"') !== -1) {
            i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter-last"'))
            if (!i) {
              i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter-last"'))
            }
            fit = doc.content.slice(0, i + 1)
            last = doc.content.slice(i + 1)
            doc.content = fit + ('<span style="position:relative;font-size: xx-small; top:0em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().format('MM-DD-YYYY') + '</span>') + last
          } else if (doc.content.indexOf('id="pageFooter"') !== -1 || doc.content.indexOf('id="pageFooter"') !== -1) {
            i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter"'))
            if (!i) {
              i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter"'))
            }
            fit = doc.content.slice(0, i + 1)
            last = doc.content.slice(i + 1)
            doc.content = fit + ('<span style="position:relative;font-size: xx-small; top:0em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().format('MM-DD-YYYY') + '</span>') + last
          } else {
            doc.content = doc.content + '<div id="pageFooter" ><div style="position:relative;font-size: xx-small; top:0em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().format('MM-DD-YYYY') + '</div></div>'
          }
        }
        html.pdf(mongo, req, doc.content, doc.pageType, (err, stream) => {
          if (err) {
            send({
              error: err
            })
          } else {
            send(stream)
          }
        })
      } else {
        send({
          error: err
        })
      }
    })
  }

  this.delete = function (req, mongo, send) {
    const doc = req.query
    mongo.findId('attached', mongo.toId(doc._id), (err, attached) => {
      if (err) {
        send({
          error: err
        })
      } else {
        mongo.deleteOne('attached', {
          _id: mongo.toId(doc._id)
        }, (err) => {
          if (err) {
            req.logger.log(err)
          } else {
            req.app.routes.trash.insert(req, mongo, 'attached', attached, () => {
              send({})
            })
          }
        })
      }
    })
  }

  this.list = async function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = {
      data: [],
      pos: skip
    }
    var keys = await this.$keys(req, mongo)
    if (!req.query.filter || (req.query.filter && !req.query.filter.status)) {
      keys.status = {
        $nin: ['done', 'completed', 'annulled']
      }
    } else {
      keys.status = {
        $ne: 'annulled'
      }
    }
    if (req.query.onlydefeated === 'true') {
      keys.$and = [
        {
          $and: [
            {
              $and: [
                {
                dates: {
                  $elemMatch: {
                    value: {
                      $lte: new Date()
                    },
                    type: 'deadline'
                  }
                }
              },
              {
                status: {
                  $in: ['answered', 'processing', 'analizing']
                }
                }
              ]
            },
            {
              $and: [
                {
                datesDeadlineComm: {
                  $elemMatch: {
                    value: {
                      $lte: new Date()
                    },
                    type: 'deadline'
                  }
                }
              },
              {
                statusComm: {
                  $in: ['draft', 'ready', 'return']
                }
                }
              ]
            }
          
          ]
        }
      ]
    }
    if (req.query.onlyunexpired === 'true') {
       keys.$and = [
        {
          $and: [
            {
              $and: [
                {
                dates: {
                  $elemMatch: {
                    value: {
                      $gte: new Date()
                    },
                    type: 'deadline'
                  }
                }
              },
              {
                status: {
                  $in: ['answered', 'processing', 'analizing']
                }
                }
              ]
            },
            {
              $and: [
                {
                datesDeadlineComm: {
                  $elemMatch: {
                    value: {
                      $gte: new Date()
                    },
                    type: 'deadline'
                  }
                }
              },
              {
                statusComm: {
                  $in: ['draft', 'ready', 'return']
                }
                }
              ]
            }
          
          ]
        }
      ]
    }
    if (req.query.filter) {
      var query = []
      const filter = req.query.filter
      if (filter.responsibleName || filter.responsibleUnit) {
        if (filter.responsibleName !== '') {
          query.push({
            actors: {
              $elemMatch: {
                role: 'responsible',
                user: mongo.toId(filter.responsibleName)
              }
            }
          })
        }
        if (filter.responsibleUnit !== '') {
          var dependents = await req.app.routes.note.$unitDependents(mongo, mongo.toId(filter.responsibleUnit))
          query.push({
            actors: {
              $elemMatch: {
                role: 'responsible',
                unit: {
                  $in: dependents
                }
              }
            }
          })
        }
      }
      if (filter.reviser) {
        query.push({
          $or: [{
            actors: {
              $elemMatch: {
                user: mongo.toId(filter.reviser),
                path: 'sent'
              }
            }
          }, {
            actors: {
              $elemMatch: {
                user: mongo.toId(filter.reviser),
                supervisor: '1'
              }
            }
          }]
        })
      }
      if (filter.reviserUnit) {
        query.push({
          $or: [{
            actors: {
              $elemMatch: {
                unit: mongo.toId(filter.reviserUnit),
                role: 'reviser'
              }
            }
          }, {
            actors: {
              $elemMatch: {
                unit: mongo.toId(filter.reviserUnit),
                role: 'from'
              }
            }
          }, {
            actors: {
              $elemMatch: {
                unit: mongo.toId(filter.reviserUnit),
                supervisor: '1'
              }
            }
          }]
        })
      }
      if (filter.name) {
        let text = new RegExp(filter.name, 'i')
        query.push({
          $or: [{
            name: text
          }, {
            'sequence.text': text
          }]
        })
      }
      if (filter.tagsname) {
        let arrayTags = filter.tagsname.split(',')
        for (let i in arrayTags) {
          arrayTags[i] = mongo.toId(arrayTags[i])
        }
        query.push({
          tags: {
            $in: arrayTags
          }
        })
      }
      if (filter.attachedTagName) {
        let tags = filter.attachedTagName.split(',')
        for (let i in tags) {
          tags[i] = mongo.toId(tags[i])
        }
        query.push({
          attachedTag: {
            $in: tags
          }
        })
      }
      if (filter.status && filter.status !== 'all') {
        query.push({
          status: filter.status
        })
      }
      if (filter.deadline) {
        if (filter.deadline.start && !filter.deadline.end) {
          query.push({
            $and: [{
              dates: {
                $elemMatch: {
                  value: {
                    $gte: filter.deadline.start
                  },
                  type: 'deadline'
                }
              }
            },
            {
              status: 'answered'
            }
            ]
          })
        } else if (filter.deadline.start && filter.deadline.end) {
          query.push({
            $and: [{
              dates: {
                $elemMatch: {
                  value: {
                    $gte: filter.deadline.start
                  },
                  type: 'deadline'
                }
              }
            },
            {
              dates: {
                $elemMatch: {
                  value: {
                    $lte: filter.deadline.end
                  },
                  type: 'deadline'
                }
              }
            },
            {
              status: 'answered'
            }
            ]
          })
        }
      }
      if (query.length) {
        query.push(keys)
        keys = {
          $and: query
        }
      }
    }
    var sort
    if (req.query.sort) {
      for (const name in req.query.sort) {
        if (req.query.sort[name].length > 0) {
          if (name === 'deadline') {
            sort = req.query.sort[name] === 'asc' ? {
              'dates.1.value': 1
            } : {
              'dates.1.value': -1
            }
          }
        }
      }
    }
    const users = await new Promise(resolve => {
      mongo.toHash('user', {}, (err, users) => {
        if (err) {
          console.log(err)
          resolve()
        } else {
          resolve(users)
        }
      })
    })
    const units = await new Promise(resolve => {
      mongo.toHash('unit', {}, (err, units) => {
        if (err) {
          console.log(err)
          resolve()
        } else {
          resolve(units)
        }
      })
    })
    var tagsDoc = []
    await new Promise(resolve => {
      mongo.find('params', {
        name: {
          $in: ['riskLevel']
        }
      }, {
        _id: 1,
        name: 1,
        options: 1
      }, (err, tgsDs) => {
        if (err) {
          console.log(err)
          resolve()
        } else {
          if (tgsDs.length > 0) {
            for (var i in tgsDs) {
              tagsDoc = tagsDoc.concat(tgsDs[i].options)
            }
          }
          resolve()
        }
      })
    })

    var attachedTagArray = []
    await new Promise(resolve => {
      mongo.find('params', {
        name: {
          $in: ['attachedTag']
        }
      }, {
        _id: 1,
        name: 1,
        options: 1
      }, (err, tgsDs) => {
        if (err) {
          console.log(err)
          resolve()
        } else {
          if (tgsDs.length > 0) {
            for (var i in tgsDs) {
              attachedTagArray = attachedTagArray.concat(tgsDs[i].options)
            }
          }
          resolve()
        }
      })
    })

    var pipeline = [{
      $lookup: {
        from: 'note',
        localField: 'reference',
        foreignField: '_id',
        as: 'note'
      }
    },
    {
      $unwind: {
        path: '$note',
        preserveNullAndEmptyArrays: true
      }
    },
    {
      $addFields: {
        sequence: '$note.sequence',
        confidential: '$note.confidential',
        noteStatus: '$note.status',
        noteActors: '$note.actors'
      }
    },
    {
      $lookup: {
        from: 'commitment',
        localField: '_id',
        foreignField: 'reference',
        as: 'comm'
      }
    },
    {
      $unwind: {
        path: '$comm',
        preserveNullAndEmptyArrays: true
      }
    },
    {
      $addFields: {
        dates: {
          $filter: {
            input: '$dates',
            as: 'item',
            cond: {
              $eq: ['$$item.type', 'deadline']
            }
          }
        },
        datesDeadlineComm: {
          $filter: {
            input: '$comm.dates',
            as: 'item',
            cond: {
              $eq: ['$$item.type', 'deadline']
            }
          }
        },
        datesIssueComm: {
          $filter: {
            input: '$comm.dates',
            as: 'item',
            cond: {
              $eq: ['$$item.type', 'issue']
            }
          }
        },
        statusComm: '$comm.status'
      }
    },
    {
      $match: keys
    },
    {
      $addFields: {
        isShow: {
          $function: {
            body: `function (status, actors, user) {
                if (status === 'draft') {
                  let cont = true
                  for (let a in actors) {
                    let act = actors[a]
                    if ((hex_md5(user.toString()) === hex_md5(act.user.toString())) && (act.role === 'to' || act.role === 'copy') && (act.path === 'hidden')) {
                      cont = false
                      return false
                    }
                  }
                  if (cont) return true
                } else {
                  return true
                }
              }`,
            args: ['$noteStatus', '$noteActors', req.session.context.user],
            lang: 'js'
          }
        }
      },
    },
    {
      $match: {
        isShow: true
      }
    },
    {
      $project: {
        _id: 1,
        actors: 1,
        tags: 1,
        responsible: 1,
        attachedTag: 1,
        sequence: 1,
        status: 1,
        statusComm: 1,
        name: 1,
        realProgress: 1,
        deadline: {
          $arrayElemAt: ['$dates.value', 0]
        },
        deadlineComm: {
          $arrayElemAt: ['$datesDeadlineComm.value', 0]
        },
        issueComm: {
          $arrayElemAt: ['$datesIssueComm.value', 0]
        }
      }
    },
    {
      $skip: skip
    }, {
      $limit: limit
    },
    {
      $sort: sort || {
        _id: 1
      }
    },
    ]

    mongo.aggregate('attached', pipeline, {}, (err, attacheds) => {
      if (err) {
        throw err
      } else if (attacheds.length > 0) {
        for (var i in attacheds) {
          var deadline = attacheds[i].deadline
          var deadlineComm = attacheds[i].deadlineComm
          if (deadlineComm && (attacheds[i].statusComm !== 'draft' && attacheds[i].statusComm !== 'ready' && attacheds[i].statusComm !== 'returned')) {
            attacheds[i].deadline = deadlineComm
            deadline = deadlineComm
            attacheds[i].expired = undefined
          } else {
            attacheds[i].expired = !['completed'].includes(attacheds[i].status) && deadline && deadline.getTime() <= new Date().getTime() ? tags.expired : undefined
          }
          const revisers = []
          const reviserUnit = []
          let responsible = ['', '']
          if (attacheds[i].actors) {
            for (let u in attacheds[i].actors) {
              if (attacheds[i].actors[u].role === 'responsible') {
                responsible = attacheds[i].actors[u].user ? attacheds[i].actors[u].user.toString() : ''
                let responsibleUnit = attacheds[i].actors[u].unit ? attacheds[i].actors[u].unit.toString() : ''
                attacheds[i].responsibleId = responsible
                attacheds[i].responsibleName = users[responsible] ? users[responsible].name : ''
                attacheds[i].responsibleUnit = units[responsibleUnit] ? units[responsibleUnit].name : ''
                break
              }
            }
          }
          for (var a in attacheds[i].actors) {
            attacheds[i].id = attacheds[i]._id
            if (!responsible && attacheds[i].actors[a].role === 'inCharge') {
              responsible = [(attacheds[i].actors[a].user ? attacheds[i].actors[a].user.toString() : ''), (attacheds[i].actors[a].unit ? attacheds[i].actors[a].unit.toString() : '')]
            } else if ((attacheds[i].actors[a].path === 'sent' || attacheds[i].actors[a].supervisor === '1') && revisers.findIndex((x) => {
              return x.user.toString() === attacheds[i].actors[a].user.toString()
            }) === -1) {
              attacheds[i].actors[a].name = users[attacheds[i].actors[a].user] ? users[attacheds[i].actors[a].user].name : ''
              revisers.push(attacheds[i].actors[a])
              reviserUnit.push({
                unit: attacheds[i].actors[a].unit,
                name: units[attacheds[i].actors[a].unit] ? units[attacheds[i].actors[a].unit].name : ''
              })
            }
          }
          attacheds[i].reviser = revisers
          attacheds[i].reviserUnit = reviserUnit
          if (deadline) {
            attacheds[i].deadlineField = dateformat(new Date(deadline), 'dd/mm/yyyy')
          } else {
            attacheds[i].deadlineField = ''
          }
          var tagFoundId = attacheds[i].tags
          for (let t in tagsDoc) {
            if (tagFoundId && tagFoundId.toString() === tagsDoc[t].id.toString()) {
              attacheds[i].tagsname = tagsDoc[t].value
              attacheds[i].tagscolor = tagsDoc[t].color
            }
          }
          var attachedTag = attacheds[i].attachedTag
          for (let t in attachedTagArray) {
            if (attachedTag && attachedTag.toString() === attachedTagArray[t].id.toString()) {
              attacheds[i].attachedTagName = attachedTagArray[t].value
              attacheds[i].attachedTagColor = attachedTagArray[t].color
            }
          }
          if (attacheds[i].sequence && attacheds[i].sequence.text !== '') {
            attacheds[i].name = '<b>[' + attacheds[i].sequence.text + ']</b> ' + attacheds[i].name
          }
          delete attacheds[i].sequence
          delete attacheds[i].content
          delete attacheds[i].reference
          delete attacheds[i].project
          delete attacheds[i].task
          delete attacheds[i].actors
          delete attacheds[i].dates
        }
        reply.data = attacheds
        if (skip) {
          send(reply)
        } else {
          pipeline.splice(10, 2)
          pipeline.push({
            $group: {
              _id: null,
              count: {
                $sum: 1
              }
            }
          })
          pipeline.push({
            $project: {
              _id: 0
            }
          })
          mongo.aggregate('attached', pipeline, {
            allowDiskUse: true
          }, (err, count) => {
            if (!err && count) {
              reply.total_count = count[0] ? count[0].count : 0
            }
            send(reply)
          })
        }
      } else {
        send([])
      }
    })
  }
  this.responsibles = function (req, mongo, send) {
    var pipeline = [{
      $addFields: {
        actors: {
          $filter: {
            input: '$actors',
            as: 'item',
            cond: {
              $eq: ['$$item.role', 'responsible']
            }
          }
        }
      }
    },
    {
      $group: {
        _id: '$actors.user'
      }
    },
    {
      $lookup: {
        from: 'user',
        localField: '_id',
        foreignField: '_id',
        as: 'rev'
      }
    },
    {
      $unwind: '$rev'
    },
    {
      $group: {
        _id: {
          id: '$rev._id',
          value: '$rev.name'
        }
      }
    },
    {
      $project: {
        _id: 0,
        id: '$_id.id',
        value: '$_id.value'
      }
    }
    ]
    mongo.aggregate('attached', pipeline, {}, (err, options) => {
      if (err) console.log(err)
      send(options)
    })
  }
  this.responsibleUnits = function (req, mongo, send) {
    var pipeline = [{
      $addFields: {
        actors: {
          $filter: {
            input: '$actors',
            as: 'item',
            cond: {
              $eq: ['$$item.role', 'responsible']
            }
          }
        }
      }
    },
    {
      $group: {
        _id: '$actors.unit'
      }
    },
    {
      $lookup: {
        from: 'unit',
        localField: '_id',
        foreignField: '_id',
        as: 'rev'
      }
    },
    {
      $unwind: '$rev'
    },
    {
      $group: {
        _id: {
          id: '$rev._id',
          value: '$rev.name'
        }
      }
    },
    {
      $project: {
        _id: 0,
        id: '$_id.id',
        value: '$_id.value'
      }
    }
    ]
    mongo.aggregate('attached', pipeline, {}, (err, options) => {
      if (err) console.log(err)
      send(options)
    })
  }
  this.$keys = async function (req, mongo, ) {
    var keys
    var scalableSequences = await new Promise(resolve => {
      mongo.find('sequence', {
        scalable: true
      }, (err, seqs) => {
        if (err) console.log(err)
        var ids = []
        if (seqs) {
          for (let s in seqs) {
            ids.push(seqs[s]._id)
          }
        }
        resolve(ids)
      })
    })
    if (req.session.context.licensedUser === false) {
      var myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits)
      var myAndDependentUnits = req.session.context.dependentUnits.concat(myUnits)
      keys = {
        $or: [
          // responsible user without hidden
          {
            actors: {
              $elemMatch: {
                user: req.session.context.user,
                role: 'responsible',
                path: {
                  $ne: 'hidden'
                }
              }
            }
          },
          // or actor referred
          {
            actors: {
              $elemMatch: {
                user: req.session.context.user,
                path: 'referred'
              }
            }
          },
          // if confidential or not scalable, all actors user without hidden
          {
            $and: [{
              $or: [{
                confidential: '1'
              },
              {
                $and: [{
                  'sequence.sequence': {
                    $nin: scalableSequences
                  }
                }, {
                  'sequence._id': {
                    $nin: scalableSequences
                  }
                }]
              }
              ]
            },
            {
              $or: [{
                actors: {
                  $elemMatch: {
                    user: req.session.context.user,
                    path: {
                      $ne: 'hidden'
                    }
                  }
                }
              },
              {
                actors: {
                  $elemMatch: {
                    unit: {
                      $in: myUnits
                    },
                    path: {
                      $ne: 'hidden'
                    }
                  }
                }
              }
              ]
            }
            ]
          },
          // if not confidential and scalable, responsible unit are in dependents units without hidden only
          {
            confidential: {
              $ne: '1'
            },
            $or: [{
              'sequence.sequence': {
                $in: scalableSequences
              }
            },
            {
              'sequence._id': {
                $in: scalableSequences
              }
            },
            {
              'sequence.sequence': null,
              'sequence._id': null
            }
            ],
            actors: {
              $elemMatch: {
                role: 'responsible',
                unit: {
                  $in: myAndDependentUnits
                },
                path: {
                  $ne: 'hidden'
                }
              }
            }
          }
        ]
      }
      if (req.session.context.readerUnits && req.session.context.readerUnits.length > 0) {
        keys.$or.push({
          $and: [{
            actors: {
              $elemMatch: {
                unit: {
                  $in: req.session.context.readerUnits
                },
                path: {
                  $ne: 'hidden'
                },
                role: 'from'
              }
            }
          }]
        })
      }
    } else {
      myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits).concat(req.session.context.memberUnits)
      myAndDependentUnits = req.session.context.dependentUnits.concat(myUnits)
      keys = {
        $or: [
          // users in the note & not hidden
          {
            actors: {
              $elemMatch: {
                user: req.session.context.user,
                path: {
                  $ne: 'hidden'
                }
              }
            }
          },
          // assistant in one unit of note & not hidden
          {
            actors: {
              $elemMatch: {
                unit: {
                  $in: myUnits
                },
                path: {
                  $ne: 'hidden'
                }
              }
            }
          },
          // manager or assistant of ascending unit, not hidden, scalable, non-confidential and not in draft
          {
            actors: {
              $elemMatch: {
                unit: {
                  $in: myAndDependentUnits
                },
                path: {
                  $ne: 'hidden'
                }
              }
            },
            confidential: {
              $ne: '1'
            }
          }
        ]
      }
      if (req.session.context.readerUnits && req.session.context.readerUnits.length > 0) {
        keys.$or.push({
          $and: [{
            actors: {
              $elemMatch: {
                unit: {
                  $in: req.session.context.readerUnits
                },
                path: {
                  $ne: 'hidden'
                },
                role: 'from'
              }
            }
          }]
        })
      }
    }
    return keys
  }
}