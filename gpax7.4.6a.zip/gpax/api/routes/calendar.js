/* Nilton Santos 4 de oct 2017 */
/* Show or edit form */
/* exported */

var dateformat = require('dateformat')
var tags = require('../utils/tags').tags
var Notification = require('../utils/notification').Notification
var notification = new Notification()
exports.Calendar = Calendar

function Calendar () {
  this.get = function (req, mongo, send) {
    var doc = {}
    if (req.query._id) {
      mongo.findId('calendar', req.query._id, (err, calendar) => {
        if (!err) {
          doc = calendar
          send(doc)
        } else {
          send()
        }
      })
    } else {
      doc = { _id: mongo.newId() }
      send(doc)
    }
  }

  this.list = function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    /* filering documents with user of session or unit of user of session and not hidden */
    var keys = {}
    mongo.find('params', { name: 'calendarTags' }, { _id: 1, name: 1, options: 1 }, (er, calendarTags) => {
      /* apply filter in parameters */
      if (req.query.filter) {
        const query = {}
        for (const name in req.query.filter) {
          if (req.query.filter[name].length > 0) {
            if (name === 'name') {
              query[name] = {
                $regex: req.query.filter.name, $options: 'i'
              }
            } else {
              query[name] = req.query.filter[name].indexOf(',') ? { $in: req.query.filter[name].split(',') } : new RegExp(req.query.filter[name].replace(/ /g, '.*'), 'i')
            }
          }
        }
        keys = query
      }
      /* read limit rows from skip position */
      mongo.findN('calendar', skip, limit, keys, {}, { _id: -1 }, (err, docs) => {
        if (err || !docs) {
          send({ error: err })
        } else {
          for (const i in docs) {
            var doc = docs[i]
            var item = this.getItem(doc, calendarTags)
            reply.data.push(item)
          }

          /* if continue is true, send data */
          if (skip) {
            send(reply)
          } else {
            /* add total_count to reply */
            mongo.count('calendar', keys, (err, count) => {
              if (!err && count) {
                reply.total_count = count
              }
              send(reply)
            })
          }
        }
      })
    })
  }

  this.getItem = function (doc, calendarTags) {
    var tagsId = []
    for (const j in doc.tag) {
      tagsId.push(doc.tag[j])
    }
    // calendarTags
    var usedTags = []
    if (calendarTags.length) {
      for (let t = 0; t < calendarTags[0].options.length; t++) {
        for (let o = 0; o < tagsId.length; o++) {
          if (calendarTags[0].options[t].id.toString() === tagsId[o].toString()) {
            usedTags.push(calendarTags[0].options[t])
          }
        }
      }
    }
    var tagcolor = []
    var tagname = []
    var tag = [usedTags[0] ? usedTags[0].value : '']
    for (let i in usedTags) {
      tagcolor.push(usedTags[i].color)
      tagname.push(usedTags[i].value)
    }

    var row = {
      id: doc._id.toString(),
      name: doc.name,
      year: doc.year,
      region: doc.region,
      tagcolor: tagcolor,
      tagname: tagname,
    }

    return row
  }

  this.save = function (req, mongo, send) {
    var doc = req.body
    if (doc.tag) {
      doc.tag = doc.tag.length === 0 ? [] : doc.tag.split(',')
    }
    if (doc.id) { doc._id = mongo.isNativeId(doc.id) ? mongo.toId(doc.id) : mongo.newId() }
    mongo.save('calendar', doc, (err, result) => {
      var reply
      if (err) {
        reply = { error: tags.savingProblema }
      } else {
        reply = { message: tags.savedChanges }
      }
      send(reply)
      mongo.find('params', { name: 'calendarTags' }, { _id: 1, name: 1, options: 1 }, (er, calendarTags) => {
        var item = this.getItem(doc, calendarTags)
        notification.send(req, req.session.context.room, 'calendars', item, null, null)
      })
    })
  }

  this.duplicate = function (req, mongo, send) {
    var doc = req.query
    mongo.findId('calendar', mongo.toId(doc._id), (err, calendar) => {
      if (err) {
        return send({ error: err })
      } else {
        calendar._id = mongo.newId()
        calendar.name = calendar.name + ' - copy'
        calendar.duplicated = true
        mongo.save('calendar', calendar, (err, result) => {
          var reply
          if (err) {
            return send({ error: tags.savingProblema })
          } else {
            reply = { message: tags.savedChanges }
          }
          send(reply)
          mongo.find('params', { name: 'calendarTags' }, { _id: 1, name: 1, options: 1 }, (er, calendarTags) => {
            var item = this.getItem(calendar, calendarTags)
            notification.send(req, req.session.context.room, 'calendars', item, null, null)
          })
        })
      }
    })
  }

  this.delete = async function (req, mongo, send) {
    var doc = req.query
    let array = await new Promise(resolve => {
      mongo.find('plan', { calendar: mongo.toId(doc._id) }, { _id: 1 }, (err, plans) => {
        if (!err && (plans && plans.length)) {
          resolve(true)
        } else {
          resolve(false)
        }
      })
    })
    if (!array) {
      mongo.findId('calendar', mongo.toId(doc._id), (err, calendar) => {
        if (err) {
          send({ error: err })
        } else {
          mongo.deleteOne('calendar', { _id: mongo.toId(doc._id) }, (err, result) => {
            if (err) {
              req.logger.log(err)
            } else {
              req.app.routes.trash.insert(req, mongo, 'calendar', calendar, () => {
                send({ message: tags.savedChanges })
                doc.id = doc._id
                notification.send(req, req.session.context.room, 'calendars', doc, null, true)
              })
            }
          })
        }
      })
    } else {
      send({msj: '_cantDeleteCalendarAlreadyInUse'}) //No es posible borrar este calendario, porque se encuentra asociado a planes operativos
    }
  }
}
