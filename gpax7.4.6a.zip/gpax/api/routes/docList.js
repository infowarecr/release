function test(req, mongo, send, rels) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    var keysProject
    if (req.query.project) {
      keysProject = { _id: mongo.toId(req.query.project) }
    } else {
      keysProject = {
        $or: [
          { 'actors.user': req.session.context.user }
        ]
      }
      if (req.session.context.readerUnits && req.session.context.readerUnits.length > 0) {
        keysProject.$or.push({
          $and: [
            { unit: { $in: req.session.context.readerUnits } },
            { status: 'archived' }
          ]
        })
      }
      if (req.session.context.managerUnits.length > 0) {
        keysProject.$or.push({ unit: { $in: req.session.context.managerUnits } })
      }
      if (req.session.context.assistantUnits.length > 0) {
        keysProject.$or.push({ unit: { $in: req.session.context.assistantUnits } })
      }
      if (req.session.context.dependentUnits.length > 0) {
        keysProject.$or.push({ unit: { $in: req.session.context.dependentUnits } })
      }
    }
    /* filering documents with user of session or unit of user of session and not hidden */
    const plans = await new Promise(resolve => {
      mongo.toHash('plan', {}, { _id: 1, name: 1 }, (err, plans) => {
        if (err) {
          console.log(err)
          resolve([])
        } else {
          resolve(plans)
        }
      })
    })
    let projects = await new Promise(resolve => {
      mongo.toHash('project', keysProject, { _id: 1, plan: 1 }, (err, projects) => {
        if (err) {
          console.log(err)
          resolve([])
        } else {
          resolve(projects)
        }
      })
    })
    var idsProjs = []
    for (const i in projects) {
      idsProjs.push(projects[i]._id)
    }
    const tagsDoc = await new Promise(resolve => {
      mongo.find('params', { name: 'tag' }, { _id: 1, name: 1, options: 1 }, (err, tagsDoc) => {
        if (err || (tagsDoc && tagsDoc.length === 0)) {
          console.log(err)
          resolve([])
        } else {
          resolve(tagsDoc[0].options)
        }
      })
    })
    var tagsVersion = await new Promise(resolve => {
      mongo.find('params', { name: 'version' }, { _id: 1, name: 1, options: 1 }, (err, tagsVersion) => {
        if (err || (tagsVersion && tagsVersion.length === 0)) {
          console.log(err)
          resolve([])
        } else {
          resolve(tagsVersion[0].options)
        }
      })
    })
    var keys1 = { $and: [{ project: { $in: idsProjs } }] }
    if (req.query.filter) {
      if (!req.query.filter.path || req.query.filter.path === 'all') {
        if (req.query.filter.status !== '' && req.query.filter.status !== 'archived') {
          if (!keys1.$and) {
            keys1.$and = []
          }
          keys1.$and.push(
            {
              $or: [
                { status: { $ne: 'archived' } }
              ]
            }
          )
        }
        if (req.query.filter.planName && req.query.filter.planName !== '') {
          if (!keys1.$and) {
            keys1.$and = []
          }
          idsProjs = []
          projects = await new Promise(resolve => {
            mongo.toHash('project', { plan: mongo.toId(req.query.filter.planName) }, { _id: 1, plan: 1 }, async (err, projects) => {
              if (err) { resolve([]) } else { resolve(projects) }
            })
          })
          for (const i in projects) {
            idsProjs.push(projects[i]._id)
          }
          keys1.$and.push({ project: { $in: idsProjs } })
          if (!req.query.filter) { keys1.$and.push({ status: { $ne: 'archived' } }) }
          delete req.query.filter.planName
        }
        if (req.query.start === 0) {
          delete req.query.continue
        }
        delete req.query.filter.path
      }
    }

    /* apply filter in parameters */
    if (req.query.filter) {
      const query = {}
      for (const name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          if (name === 'user') {
            query.actors = { $elemMatch: { user: mongo.toId(req.query.filter.user), path: 'sent', role: 'reviser' } }
          } else if (name === 'projectName') {
            query.project = mongo.toId(req.query.filter.projectName)
          } else if (name === 'tagsname') {
            query.tags = mongo.toId(req.query.filter.tagsname)
          } else if (name === 'version') {
            if (req.query.filter.version === 'onlyEmpty') {
              query.$and = [ { version: '' }, { version: { $exists: 1 } }]
            } else {
              query.version = mongo.toId(req.query.filter.version)
            }
          } else if (name === 'sequence' || name === 'sequence.text') {
            rels = {}
            rels['sequence.text'] = new RegExp(req.query.filter[name], 'i')
          } else if (name === 'name') {
            const text = req.query.filter.name
            if (!text.includes('"') && (text.includes(' ') || text.includes('-') || text.includes('/') || text.includes(':'))) {
              query.$text = { $search: '"' + text.replace(/ /g, '" "') + '"' }
            } else {
              query.$text = { $search: text }
            }
          } else if (name === '_id') {
            var ids = req.query.filter[name].split(',')
            for (const i in ids) {
              if (mongo.isNativeId(ids[i])) {
                ids[i] = mongo.toId(ids[i])
              }
            }
            query[name] = { $in: ids }
          } else if (name === 'path') {
            if (req.query.filter.path === 'archived') {
              query.actors = { $elemMatch: { user: req.session.context.user } }
              query.status = 'archived'
            } else {
              query.actors = { $elemMatch: { user: req.session.context.user, path: req.query.filter.path } }
            }
          } else if (name === 'links._id' && req.query.filter[name] !== 'undefined') {
            query.$or = [{ 'links._id': mongo.toId(req.query.filter[name]) }]
          } else if (name === 'links') {
            ids = req.query.filter[name].split(',')
            for (const i in ids) {
              if (mongo.isNativeId(ids[i])) {
                ids[i] = mongo.toId(ids[i])
              }
            }
            query.$or.push({ _id: { $in: ids } })
          } else if (name === 'issued') {
            query[name] = req.query.filter[name]
          } else if (req.query.filter[name] !== 'default') {
            query[name] = req.query.filter[name].indexOf(',') !== -1 ? { $in: req.query.filter[name].split(',') } : new RegExp(req.query.filter[name].replace(/ /g, '.*'), 'i')
          } else if (req.query.filter[name] === 'default') {
            query[name] = { $ne: 'archived' }
          }
        }
      }
      delete query.filterNames
      var keys2 = { $and: [query, keys1] }
    }
    var sort
    if (rels) {
      keys2 = rels
    }
    var pipeline = []
    pipeline.push({ $match: keys2 || keys1 })
    pipeline.push({
      $lookup: {
        from: 'project',
        let: { find: '$project' },
        pipeline: [
          {
            $match: {
              $expr:
                {
                  $and:
                    [
                      { $eq: ['$_id', '$$find'] }
                    ]
                }
            }
          },
          {
            $project: {
              _id: 1,
              name: 1
            }
          }
        ],
        as: 'project'
      }
    })
    pipeline.push({
      $lookup: {
        from: 'task',
        let: { find: '$_id' },
        pipeline: [
          {
            $match: {
              $expr:
                {
                  $and:
                    [
                      { $in: ['$$find', { $cond: [{ $isArray: '$documents' }, '$documents', []] } ] }
                    ]
                }
            }
          },
          {
            $project: {
              _id: 1,
            }
          }
        ],
        as: 'task'
      }
    }),
    pipeline.push({
      $project: {
        _id: 1,
        actors: 1,
        result: 1,
        name: 1,
        project: '$project',
        type: 1,
        user: 1,
        tags: 1,
        version: 1,
        dates: 1,
        files: 1,
        status: 1,
        sequence: 1,
        category: 1,
        issued: 1,
        task: { $ifNull: [{ $arrayElemAt: ['$task._id', 0] }, '']},
      }
    })
    pipeline.push({ $sort: sort || { _id: -1 } })
    pipeline.push({ $skip: skip })
    pipeline.push({ $limit: limit })
    mongo.aggregate('document', pipeline, {}, (err, docs) => {
      if (err) {
        send({ error: err })
      } else {
        var users = []
        for (const i in docs) {
          const doc = docs[i]
          doc.id = doc._id
          var y = doc.actors.findIndex((x) => {
            if (x) { return x.role !== 'reviser' && x.user && x.user.equals && x.user.equals(req.session.context.user) }
          })
          if (y !== -1) {
            var actual = doc.actors[y]
            doc.actor = { user: doc.actors[y].user, path: actual.role === 'copy' ? 'referred' : actual.path }
          }
          if (!doc.actor) {
            doc.actor = doc.actors[0]
          }
          if (doc.actor && doc.actor.user) users.push(doc.actor.user)
        }
        mongo.toHash('user', {}, { _id: 1, name: 1 }, async (er, users) => {
          if (docs) {
            for (let i = 0; i < docs.length; ++i) {
              var tagsId = docs[i].tags
              var usedTags = []
              if (tagsDoc.length > 0 && (tagsId || (tagsId && tagsId.length > 0))) {
                for (let t = 0; t < tagsDoc.length; t++) {
                  if (tagsId.length) {
                    for (let o = 0; o < tagsId.length; o++) {
                      if (tagsDoc[t].id && tagsId[o] && tagsDoc[t].id.toString() === tagsId[o].toString()) {
                        usedTags.push(tagsDoc[t])
                      }
                    }
                  } else if(tagsId) {
                    if (tagsDoc[t] && tagsId && tagsDoc[t].id.toString() === tagsId.toString()) {
                      usedTags.push(tagsDoc[t])
                    }
                  }
                }
              }
              var usedVersions = []
              if (tagsVersion.length > 0 && docs[i].version ) {
                for (let t = 0; t < tagsVersion.length; t++) {
                  if (tagsVersion[t] && docs[i].version && tagsVersion[t].id.toString() === docs[i].version.toString()) {
                    usedVersions.push(tagsVersion[t])
                  }
                }
              }
              var logdb = req.app.getMongo(req.app.params.log)
              var doc = docs[i]
              let lastEdit = await new Promise(resolve => {
                logdb.findN('log', 0, 1, { 'input._id': doc._id }, { _id: 1 }, { _id: -1 }, (err, log) => {
                  if (log && log.length) {
                    let time = log[0]._id.getTimestamp().toISOString().split('T')[0]
                    resolve(time)
                  } else {
                    resolve('')
                  }
                })
              })
              doc.lastEdit = lastEdit
              if (doc.type === 'expense') { doc.status = 'expense' }
              var username
              if (doc.actor) {
                var actor = doc.actor
                username = actor.user && mongo.isNativeId(actor.user) && users[actor.user.toString()] ? users[actor.user.toString()].name : actor.user
              } else {
                if (doc.user) { username = users[doc.user].name } else { username = '' }
              }
              if (doc.project[0]) {
                doc.planName = projects[doc.project[0]._id.toString()] && projects[doc.project[0]._id.toString()].plan ? plans[projects[doc.project[0]._id.toString()].plan].name : ''
                reply.data.push(this.row(doc, req, actor, username, usedTags, usedVersions))
              }
            }
          }
          /* if continue is true, send data */
          if (skip) {
            send(reply)
          } else {
            pipeline = pipeline.splice(0, 5)
            mongo.aggregate('document', pipeline, {}, (err, docs) => {
            //mongo.count('document', keys2 || keys1, (err, count) => {
              if (!err && docs) {
                reply.total_count = docs.length
              }
              send(reply)
            })
          }
        })
      }
    })
  }