/* global Buffer */
var tags = require('../utils/tags').tags
var path = require('path')
const simpleParser = require('mailparser').simpleParser
var Imap = require('imap')
var moment = require('moment')
var mongodb = require('mongodb')
var mimeTypes = require('mime-types')
var fs = require('fs')

var Grid = require('gridfs-stream')

var Notification = require('../utils/notification').Notification;
var notification = new Notification();
/* exported */

class User {
  /* user authentication */
  check (login, password, users, next) {
    users.findOne('user', { login: login, password: password }, (err, user) => {
      if (err || !user || user.active === false) {
        next({ error: 'Credenciales inválidas o usuario inactivo' })
      } else {
        next(null, user)
      }
    })
  }
  // https://gpax.io/api/user.go?url=document.document?_id=8098809
  goURL(req, mongo, send) {
    req.query.users = req.query.users ? req.query.users.split(',') : []
    if (req.query.url) {
      req.query.url = req.query.url.replace(/\$/g, '&')
    }
    if (req.session.authenticated) {
      if (-1 !== req.query.users.findIndex((u) => { return u.toString() === req.session.context.user.toString() })) {
        var goURL = {}
        if (req.query.url)
          goURL.url = req.query.url
        if (req.query.link)
          goURL.link = req.query.link
        req.session.context.goURL = goURL
      }
      send('<script>window.location="/"</script>')
    } else {
      req.session.goURL = { users: req.query.users }
      if (req.query.url)
        req.session.goURL.url = req.query.url
      if (req.query.link)
        req.session.goURL.link = req.query.link
      send('<script>window.location="/login.html"</script>')
    }
  }
  deleteGoURL(req, mongo, send) {
    delete req.session.goURL
    if (req.session.context) {
       delete req.session.context.goURL
    }
    send()
  }
  status (req, mongo, send) {
    if (req.session.authenticated) {
      send(req.session.context)
    } else {
      req.statusCode = 401
      send()
    }
  }

  sendEmailPassword (req, mongo, send) {
    let users = req.app.getMongo(req.app.params.user)
    //let host = req.body.email.split('@')[1]
    users.findOne('user', { email: req.body.email.toLowerCase() }, async (err, client) => {
      if (!err) {
        if (client) {
          client.url = client.database
          let mongodb = req.app.getMongo(client.url)
          var sett = await new Promise(resolve => {
            mongodb.findOne('settings', { _id: 'settings' }, (err, sett) => {
              if (!err) {
                resolve(sett)
              } else {
                resolve(false)
              }
            })
          })
          let user = await new Promise(resolve => {
            mongodb.find('user', { email: req.body.email }, (err, user) => {
              if (user && user.length) {
                resolve(user[0])
              } else {
                resolve(false)
              }
            })
          })
          function randomString (len, an) {
            an = an && an.toLowerCase();
            var str = '', i = 0, min = an == 'a' ? 10 : 0, max = an == 'n' ? 10 : 62;
            for (; i++ < len;) {
              var r = Math.random() * (max - min) + min << 0;
              str += String.fromCharCode(r += r > 9 ? r < 36 ? 55 : 61 : 48);
            }
            return str;
          }
          var code = randomString(10);
          if (user) {
            var doc = {
              _id: mongodb.newId(),
              user: user._id,
              email: req.body.email,
              code: code,
              url: client.url
            }
            await new Promise(resolve => {
              users.save('passwordReset', doc, (err, result) => {
                resolve(result)
              })
            })
            var secure = true
            var password = ''
            var transporter
            try { password = tags.util.Decipher(sett.password) }
            catch (err) { password = '' }
            if (sett.security === '') { secure = false }
            var nodemailer = require('nodemailer')
            transporter = nodemailer.createTransport({
              host: sett.smtp,
              port: sett.port,
              secure: secure,
              debug: true,
              logger: true,
              auth: {
                user: sett.user,
                pass: password
              },
              tls: {
                rejectUnauthorized: false
              }
            })

            // setup email data with unicode symbols
            var sendMessage = 'Hola,⁠&nbsp; su código para realizar el cambio de contraseña es el siguiente <strong>' + code + '</strong>, tiene una vigencia de 10 min, después de transcurrido ese tiempo deberá realizar el proceso nuevamente.'
            /* if (sett.sendMessage && sett.sendMessage.length > 0) {
                    sendMessage = sett.sendMessage
                  } */
            let message = {
              from: sett.user, // sender address
              to: req.body.email, // list of receivers
              // cc: unlicensedCopy, // list of receivers
              subject: 'Solicitud cambio contraseña', // Subject line
              // text: 'Hello world?', // plain text body
              html: sendMessage
            }

            // send mail with defined transport object
            transporter.sendMail(message, (error, info) => {
              if (error) {
                console.log(error)
                notification.saveSystemNotification(req, mongo, null, "Error al enviar correo: " + error.message)
              } else { console.log('Message sent: %s', info.messageId) }
            })
            send({ id: doc._id.toString() }/* '<script>window.location="/pwreset.html?id=' + doc._id.toString() + '"</script>' */)
          } else {
            send({ msg: 'No se encontró usuario con ese correo' })
          }
        } else {
          send({ msg: 'No se encontró cliente con ese host de correo' })
        }
      }
    })
  }

  async pwreset (req, mongo, send) {
    let doc = req.body
    let users = req.app.getMongo(req.app.params.user)
    var docPass = await new Promise(resolve => {
      users.findOne('passwordReset', { _id: mongo.toId(doc.id) }, (err, passwordReset) => {
        if (!err) {
          resolve(passwordReset)
        } else {
          throw err
        }
      })
    })
    if (docPass) {
      if (doc.code === docPass.code) {
        let datePass = moment(docPass._id.getTimestamp())
        datePass.add('10', 'minutes')
        let now = moment()
        if (now < datePass) {
          let mongodb = req.app.getMongo(docPass.url)
          let password = tags.util.crypto(doc.pass)
          let user = await new Promise(resolve => {
            mongodb.findOne('user', { _id: docPass.user }, { password: 1, history: 1 },(err, user) => {
              if (err) {
                resolve({})
              } else {
                resolve(user)
              }
            })
          })
          if (!user.history || !user.history.includes(password)) {
            await new Promise(resolve => {
              users.update('user', { user: docPass.user }, { $set: { password: password } }, (err, result) => {
                if (!err) {
                  resolve(result)
                } else {
                  resolve()
                }
              })
            })
            if(user.history && user.history.push) {
              user.history.push(user.password)
            } else {
              user.history=[user.password]
            }
            if (user.history.length > 10) {
              user.history.shift()
            }
            await new Promise(resolve => {
              mongodb.update('user', { _id: docPass.user }, { $set: { history: user.history } }, (err, result) => {
                resolve(result)
              })
            })
            send({ location: '/login.html' })
          } else {
            send({ location: '/pwreset.html?id=' + doc.id.toString() + '&incorrectPassword=true' })
          }
        } else {
          send({ location: '/pwreset.html?id=' + doc.id.toString() + '&expiredCode=true' })
        }
      } else {
        send({ location: '/pwreset.html?id=' + doc.id.toString() + '&incorrectCode=true' })
      }
    }
  }

  connect (req, mongo, send) {
    var code = req.headers.authorization || req.query.token
    code = code ? code.split(' ') : []
    if (code[0] === 'CRT') {
      this.validate(req, mongo, send)
    } else {
      let users = req.app.getMongo(req.app.params.user)
      var login = req.body.user; var password = req.body.pass
      if (typeof login === 'string' && typeof password === 'string') {
        if (password && password.length > 0) {
          password = tags.util.crypto(password)
        }
        this.check(login, password, users, async (err, user) => {
          if (err) {
            req.status = 401
            send('<script>window.location="/login.html?invalidCredentials=true"</script>')
          } else {
            if (await this.validAuthMethod('gpax', req, user)) {
              this.createSession(req, user, send)
            } else {
              send('<script>window.location="/login.html?notMethod=true"</script>')
              console.log('Authentication failed, not have this method in your profile')
            }
          }
        })
      } else {
        req.statusCode = 401
        send()
      }
    }
  }
  async validAuthMethod (method,req,user) {
    var db = req.app.getMongo(user.database || req.app.params.user)
    return await new Promise(resolve => {
      db.findId('settings', 'settings', (err, sett) => {
        db.findId('user', user.user || user._id, (err, usr) => {
          var allowed=[]
          if (usr) {
            allowed = ''//usr.authMethod || (usr.licensedUser ? sett.authMethodLicensed : sett.authMethodUnLicensed)
            if (!allowed) { // Widthout data in user & settings, all methods are valid
              allowed = ['gpax','certificate','outlook']
            }
            if (!Array.isArray(allowed)) {
              console.log('allowed:' + allowed)
              allowed=[allowed]
            }
          }
          resolve(allowed.includes(method))
        })
      })
    })
  }
  spConnect (req, mongo, send) {
    var code = req.headers.authorization || req.query.token
    code = code ? code.split(' ') : []
    if (code[0] === 'CRT') {
      this.validate(req, mongo, send)
    } else {
      let users = req.app.getMongo(req.app.params.user)
      var login = req.body.user; var password = req.body.pass
      if (typeof login === 'string' && typeof password === 'string') {
        if (password && password.length > 0) {
          password = tags.util.crypto(password)
        }
        this.check(login, password, users, (err, user) => {
          if (err) {
            req.status = 401
            send()
          } else {
            this.createSession(req, user, (res) => {
              if (req.statusCode) {
                send(res)
              } else {
                send(req.session.context)
              }
            })
          }
        })
      } else {
        req.statusCode = 401
        send()
      }
    }
  }

  async createSession (req, user, send) {
    var createPlans = []
    var createProjects = []
    var createStrategies = []
    var managerUnits = []
    var assistantUnits = []
    var memberUnits = []
    var managerProjects = []
    var chiefProjects = []
    if (req.app.params.overridePort) {
      user.database = user.database.replace('27017', req.app.params.overridePort)
    }
    var db = req.app.getMongo(user.database || req.app.params.user)
    var mongo = db
    req.session.database = user.database || req.app.params.user
    var userId = user.user ? user.user : user._id
    db.findId('user', userId, (err, doc) => {
      if (err || !doc) {
        req.statusCode = 404
        send()
      } else {
        db.findOne('settings', { _id: 'settings' }, async (err, setting) => {
          if (err) throw err
          if (!setting) {
            setting = {}
          }
          if (!doc.roles) {
            doc.roles = {}
          }
          if (!doc.autoTimer) {
            doc.autoTimer = false
          }
          if (setting && setting.expirationPassword && setting.expirationPassword !== '0' && doc.expirationPassword && doc.expirationPassword !== '0' && doc.expirationDateMax && new Date().getTime() >= new Date(doc.expirationDateMax).getTime()) {
            doc.expiredPassword = true
          }
          var titleOrg = setting ? setting.title : ''

          if (doc.licensedUser && (!doc.dashboard || !doc.menu || !doc.authMethod)) {
            if (!doc.dashboard) {
              doc.dashboard = setting.dashboardLicensed || 'home.dashboard2'
            }
            if (!doc.menu) {
              doc.menu = user.menu === 'invoices' ? user.menu : setting.menuLicensed || 'projects'
            }
          } else if (!doc.licensedUser && (!doc.dashboard || !doc.menu || !doc.authMethod)) {
            if (!doc.dashboard) {
              doc.dashboard = setting.dashboardUnLicensed || 'note.notes'
            }
            if (!doc.menu) {
              doc.menu = setting.menuUnLicensed || 'auditor'
            }
          }
          req.body.userAlarm = doc._id
          let usersAlarms = await new Promise(resolve => {
            req.app.routes.alarms.userList(req, mongo, (res) => {
              resolve(res)
            })
          })

          let alarms = await new Promise(resolve => {
            mongo.find('reminders', { $or: [{ $or: [{ 'owner.user': doc._id }, { 'owner.user': { $in: usersAlarms[0] }}] }, /*{ 'supervisor.user': doc._id }*/ ], status: 'active', date: {$ne: ''} }, {}, async (err, rems) => {
              if (rems && rems.length) {
                let newD = []
                for (let i in rems) {
                  let reminder = rems[i]
                  if (reminder.date) {
                    let now = new Date()
                    let diff = ''
                    if (setting && setting.days) {
                      diff = moment(reminder.date).diff(now, 'days')
                    }
                    if ((reminder.date.setHours(0, 0, 0) <= now.getTime()) && (reminder.date.setHours(23, 59, 59) >= now.getTime())) {
                      newD.push(reminder)
                    } else if (setting && (diff <= setting.days) && (diff >= 0)) {
                      newD.push(reminder)
                    } else if (now.getTime() > reminder.date.setHours(23, 59, 59)) {
                      newD.push(reminder)
                    }
                  }
                }
                if (newD.length) resolve(true)
                else resolve(false)
              } else {
                resolve(false)
              }
            })
          })

          var context = {
            dashboard: doc.dashboard,
            initUrl: req.session.initUrl,
            user: doc._id,
            name: doc.name,
            email: doc.email,
            gpax: titleOrg || 'GPAX',
            language: doc.lang || 'es-ES',
            menu: doc.menu || user.menu,
            alarmsNotification: alarms,
            alarms: 0,
            expiredPassword: doc.expiredPassword,
            comments: 0,
            unitsMention: doc.unitsMention || [],
            readerUnits: doc.readerUnits || [],
            autoTimer: doc.autoTimer,
            workDay: doc.business ? (doc.business.workDay && doc.business.workDay !== '' ? doc.business.workDay : '480') : '480',
            hourCost: doc.business ? (doc.business.hourCost && doc.business.hourCost !== '' ? doc.business.hourCost : 0) : 0,
            licensedUser: doc.licensedUser,
            createUsers: !!doc.roles.createUsers,
            createUnits: !!doc.roles.createUnits,
            createPlans: createPlans,
            createProjects: createProjects,
            createStrategies: createStrategies,
            createProcess: !!doc.roles.createProcesses,
            createProcedures: !!doc.roles.createProcedures,
            createTags: !!doc.roles.createTags,
            createTemplates: !!doc.roles.createTemplates,
            createSequences: !!doc.roles.createSequences,
            createRepositories: !!doc.roles.createRepositories,
            createClients: !!doc.roles.createClients,
            createReports: !!doc.roles.createReports,
            setSequence: !!doc.roles.setSequence,
            adminTrash: !!doc.roles.adminTrash,
            risk: !!doc.roles.risk,
            assistantUnits: assistantUnits,
            managerUnits: managerUnits,
            memberUnits: memberUnits,
            managerProjects: managerProjects,
            chiefProjects: chiefProjects,
            room: Buffer.from(user.database || req.app.params.user).toString('base64')
          }
          if (req.session.goURL && -1 !== req.session.goURL.users.findIndex((u) => { return u.toString() === context.user.toString() })) {
            context.goURL = req.session.goURL
          }
          if (context.workDay < 24) {
            context.workDay*=60
          }
          // put unitsReader
          db.find('unit', { actors: { $elemMatch: { user: doc._id } } },
            { _id: 1, actors: 1, createPlans: 1, createProjects: 1, createStrategies: 1, offline: 1 }, async (err, units) => {
              if (err) {
                req.logger.log(err)
              }
              for (const i in units) {
                var unit = units[i]
                if (context.licensedUser && unit.offline) {
                  context.assistantUnits.push(unit._id)
                }
                for (const j in unit.actors) {
                  var actor = unit.actors[j]
                  if (actor.user && actor.user.equals && actor.user.equals(doc._id)) {
                    context.memberUnits.push(unit._id)
                    for (const x in actor.type) {
                      var role = actor.type[x]
                      if (role === tags.assistant) {
                        context.assistantUnits.push(unit._id)
                        if (unit.createPlans === '1') {
                          context.createPlans.push(unit._id)
                        }
                        if (unit.createProjects === '1') {
                          context.createProjects.push(unit._id)
                        }
                        if (unit.createStrategies === '1') {
                          context.createStrategies.push(unit._id)
                        }
                      } else if (role === tags.manager) {
                        context.managerUnits.push(unit._id)
                        if (unit.createPlans === '1') {
                          context.createPlans.push(unit._id)
                        }
                        if (unit.createProjects === '1') {
                          context.createProjects.push(unit._id)
                        }
                        if (unit.createStrategies === '1') {
                          context.createStrategies.push(unit._id)
                        }
                      }
                    }
                  }
                }
              }
              // put activePlan
              var hoy=new Date()
              const plans = await new Promise(resolve => {
                mongo.aggregate('user', [{ $match: { _id: userId } },
                  { $graphLookup: { from: 'unit', startWith: '$units', connectFromField: 'parent', connectToField: '_id', as: 'superunits' } },
                  { $project: { name: 1, units: '$superunits._id' } },
                  {
                    $lookup: {
                      from: 'plan', let: { units: '$units' },
                      pipeline: [
                        {
                          $match: {$expr: {
                            $and: [
                              {$eq: ['$status', 'processing']},
                              {$or: [{ $in: ['$unit','$$units'] }, {$in: ['$unit',['',null]]}]},
                              {$lte: [{$dateFromString: {dateString: '$period.start'}},hoy]},
                              {$gte: [{$dateFromString: {dateString: '$period.end'}}, hoy]}
                            ]
                          }}
                        },
                        {$project: {name: 1,unit: 1}}
                      ],
                      as: 'plans'
                    }
                  }], {}, (err, doc) => {
                  resolve(doc && doc[0] && doc[0].plans?doc[0].plans:[])
                })
              })
              if (plans.length === 1) {
                context.activePlan = { id: plans[0]._id, name: plans[0].name }
              } else if (plans.length > 0) {
                for (let i in plans) {
                  let plan = plans[i]
                  if (plan.unit) {
                    context.activePlan = { id: plans[i]._id, name: plans[i].name }
                    break
                  }
                }
                if (!context.activePlan) {
                  context.activePlan = { id: plans[0]._id, name: plans[0].name }
                }
              } else {
                context.activePlan = { id: '', name: ''}
              }
              if (context.createPlans.length === 0) {
                delete context.createPlans
              }
              if (context.createProjects.length === 0) {
                delete context.createProjects
              }
              if (req.session.expired) {
                context.queued = true
              }
              // put dependant units in context
              context.dependentUnits = []
              db.find('project', {}, { actors: 1, unit: 1 }, (err, projects) => {
                if (err) throw err
                if (projects.length >= 1) {
                  for (const i in projects) {
                    if (projects[i].actors && projects[i].actors.length > 0 && projects[i].actors[0].user.toString() === doc._id.toString()) {
                      managerProjects.push(projects[i]._id)
                    }
                    for (const m in managerUnits) {
                      if (managerUnits[m] && projects[i].unit && managerUnits[m].toString() === projects[i].unit.toString()) {
                        chiefProjects.push(projects[i]._id)
                      }
                    }
                    for (const m in assistantUnits) {
                      if (assistantUnits[m] && projects[i].unit && assistantUnits[m].toString() === projects[i].unit.toString()) {
                        chiefProjects.push(projects[i]._id)
                      }
                    }
                  }
                }
                this.dependentUnits(db, managerUnits.concat(assistantUnits), context.dependentUnits, () => {
                  req.session.context = context
                  req.session.ip = req.ip
                  req.session.authenticated = true
                  db.findOne('settings', {}, (err, sett) => {
                    if (err) throw err
                    if (sett && sett.user && sett.password) {
                      this.getEmails(req, send, sett, db, mongo)
                    }
                    send('<script>window.location="/"</script>')
                  })
                })
              })
            })
        })
      }
    })
  }

  getEmails (req, send, doc, db, mongo) {
    db.find('user', {}, { _id: 1, email: 1, units: 1 }, {}, (err, users) => {
      if (err) { send(err) } else {
        var port
        var password
        try {
          password = tags.util.Decipher(doc.password)
        } catch (err) {
          password = ''
        }
        if (doc.securityImap === 'ssl') { port = 993 } else { port = 143 }
        var imap = new Imap({
          user: doc.user,
          password: password,
          host: doc.pop_imap,
          port: port,
          tls: true,
          tlsOptions: {
            rejectUnauthorized: false
          }
        })

        imap.once('ready', function () {
          imap.getBoxes(function (err, boxes) {
            if (err) throw err
            var boxName
            for (const i in boxes) {
              boxName = i
              break
            }
            openInbox(imap, boxName, function (err) {
              if (err) throw err
            })
          })
        })
        imap.on('mail', function () {
          imapConn(imap, users)
        })

        imap.once('error', function (err) {
          console.log(err)
        })

        imap.connect()
      }
    })

    function imapConn (imap, users) {
      imap.search(['NEW'], function (err, results) {
        if (err) throw err
        else if (results.length === 0) {
        } else {
          var f = imap.fetch(results, { bodies: '', markSeen: true })
          var buffer
          f.on('message', function (msg, seqno) {
            msg.on('body', function (stream, info) {
              simpleParser(stream, async (err, mail) => {
                if (err) throw err
                var from = [mail.from.value[0].address]
                var to = []
                if (mail.to) {
                  for (const i in mail.to.value) {
                    to.push(mail.to.value[i].address)
                  }
                }
                var cc = []
                if (mail.cc) {
                  for (const i in mail.cc.value) {
                    cc.push(mail.cc.value[i].address)
                  }
                }
                var subject = mail.subject
                var date = mail.date
                var content = mail.html
                var documents = {
                  name: subject,
                  from: from,
                  to: to,
                  cc: cc,
                  attachments: mail.attachments,
                  content: content,
                  confidential: '0',
                  deadline: '',
                  issued: '1',
                  sequence: {
                    text: ''
                  },
                  dates: [{
                    type: 'issue',
                    value: new Date(date)
                  }],
                  status: 'processing',
                  tags: [],
                  termDays: '0',
                  type: 'redactor',
                  units: []
                }
                from = []; to = []; cc = []
                for (const u in users) {
                  if (users[u].email === documents.from[0]) {
                    from.push(users[u])
                    break
                  }
                }
                if (from.length > 0) {
                  documents._id = mongo.newId()
                  documents.actors = []
                  var unit = ''
                  if (from[0].units.length > 0) { unit = from[0].units[0] }
                  documents.actors.push({
                    user: from[0]._id,
                    path: 'sent',
                    role: 'from',
                    unit: unit
                  })
                  if (documents.to.length > 0) {
                    for (const t in documents.to) {
                      for (const u in users) {
                        if (users[u].email === documents.to[t]) {
                          to.push(users[u])
                        }
                      }
                    }
                    if (to.length > 0) {
                      for (const t in to) {
                        unit = ''
                        if (to[t].units.length > 0) { unit = to[t].units[0] }
                        documents.actors.push({
                          user: to[t]._id,
                          path: 'received',
                          role: 'to',
                          unit: unit
                        })
                      }
                    }
                  }
                  if (documents.cc.length > 0) {
                    for (const t in documents.cc) {
                      for (const u in users) {
                        if (users[u].email === documents.cc[t]) {
                          cc.push(users[u])
                        }
                      }
                    }
                    if (cc.length > 0) {
                      for (const c in cc) {
                        unit = ''
                        if (cc[c].units.length > 0) { unit = cc[c].units[0] }
                        documents.actors.push({
                          user: cc[c]._id,
                          path: 'received',
                          role: 'copy',
                          unit: unit
                        })
                      }
                    }
                  }

                  if (documents.attachments.length > 0) {
                    db.connect(null, (database) => {
                      var gfs = new Grid(database, mongodb)
                      for (const a in documents.attachments) {
                        if (documents.attachments[a].filename && !documents.attachments[a].contentType.includes('image')) {
                          var doc = {
                            filename: documents.attachments[a].filename,
                            mode: 'w',
                            content_type: mimeTypes.contentType(documents.attachments[a].filename),
                            _id: mongo.newId()
                          }
                          var ext = documents.attachments[a].filename.split('.')
                          if (ext.length) {
                            ext = ext[ext.length - 1]
                          }
                          if ((ext && ext !== 'png') || ext !== 'jpg') {
                            buffer = documents.attachments[a].content
                            var writer = gfs.createWriteStream(doc)
                            writer.write(buffer)
                            writer.end()
                            documents.content += ' <a class="fr-file" href="/api/file.get?_id=' + doc._id + '&type=' + ext + '" target="_blank">' + doc.filename + '</a>'
                          }
                        }
                      }
                    })
                    await new Promise(resolve => {
                      delete documents.attachments
                      db.save('document', documents, (err, result) => {
                        if (err) resolve(false)
                        else req.app.routes.document.sendNotification(req, db, send, documents)
                        resolve(result)
                      })
                    }).catch((err) => console.log(err))
                  } else {
                    delete documents.attachments
                    db.save('document', documents, (err, result) => {
                      if (!err) {
                        req.app.routes.document.sendNotification(req, db, send, documents)
                      }
                    })
                  }
                  notification.newEmail(req, mail.subject, mail.from.value[0].address, documents.actors, documents._id)
                }
              })

              stream.on('data', function (chunk) {
                buffer += chunk.toString()
              })
            })
            msg.once('end', function () {
              console.log('Finished')
            })
          })
          f.once('error', function (err) {
            console.log('Fetch error: ' + err)
          })
          f.once('end', function () {
            console.log('Done fetching all messages!')
          })
        }
      })
    }
    function openInbox (imap, b, cb) {
      imap.openBox(b, false, cb)
    }
  }

  dependentUnits (db, parents, dependents, next) {
    db.find('unit', { parent: { $in: parents } }, { _id: 1 }, (err, units) => {
      if (err) throw err
      if (units && units.length > 0) {
        const ids = []
        for (const i in units) {
          ids.push(units[i]._id)
          if (dependents.indexOf(units[i]._id) === -1) {
            dependents.push(units[i]._id)
          }
        }
        this.dependentUnits(db, ids, dependents, next)
      } else {
        next()
      }
    })
  }

  validate (req, mongo, send) {
    var code = req.headers.authorization || req.query.token
    var login, password
    code = code ? code.split(' ') : []
    if (code[0] === 'CRT') {
      var ced = code[1]
      var users = req.app.getMongo(req.app.params.user)
      users.findOne('user', { userId: ced, }, async (err, user) => {
        if (err || !user || user.active === false) {
          req.statusCode = 401
          send({ message: '[CRT401] Credenciales inválidas o usuario inactivo' })
        } else {
          if (await this.validAuthMethod('gpax', req, user)) {
            this.createSession(req, user, send)
          } else {
            send('<script>window.location="/login.html?invalidCredentials=true"</script>')
            console.log('Authentication failed, not have this method in your profile')
          }
        }
      })
    } else {
      if (code.length === 2) {
        code = Buffer.from(code[1], 'base64').toString().split(':')
        if (code.length === 2) {
          login = code[0]
          password = tags.util.crypto(code[1])
        }
      } else {
        code = Buffer.from(code[0], 'base64').toString().split(':')
        login = code[0]
        password = code[1]
      }
      this.check(login, password, req.app.getMongo(req.app.params.user), async (err, user) => {
        if (err) {
          req.statusCode = 401
          send(err)
        } else {
          if (await this.validAuthMethod('gpax', req, user)) {
            this.createSession(req, user, send)
          } else {
            send('<script>window.location="/login.html?invalidCredentials=true"</script>')
            console.log('Authentication failed, not have this method in your profile')
          }
        }
      })
    }
  }

  clientSerial (req, mongo, send) {
    var userId = req.clientSerial
    var users = req.app.getMongo(req.app.params.user)
    users.findOne('user', { userId: userId, active: true }, async (err, user) => {
      if (err || !user || user.active === false) {
        req.statusCode = 401
        send({ message: '[SC401] Credenciales inválidas o usuario inactivo' })
      } else {
        if (await this.validAuthMethod('certificate', req, user)) {
          this.createSession(req, user, send)
        } else {
          send('<script>window.location="/login.html?invalidCredentials=true"</script>')
          console.log('Authentication failed, not have this method in your profile')
        }
      }
    })
  }
  async auth (req, mongo, send) {
    let users = req.app.getMongo(req.app.params.user)
    users.findOne('user', { email: req.user.toLowerCase(), active: true }, async (err, security) => {
      if (err || !security) {
        send('<script>window.location="/relogin.html?"</script>')
        console.log('Authentication failed for ' + req.user)
      } else {
        if (await this.validAuthMethod('outlook', req, security)) {
          this.createSession(req, security, () => {
            send('<script>window.location="/"</script>')
          })
        } else {
          send('<script>window.location="/login.html?notMethod=true"</script>')
          console.log('Authentication failed, not have this method in your profile')
        }
      }
    })
  }
  async connect365 (req, mongo, send) {
    var office365Auth = require('office365-nodejs-authentication')
    var auth = await new Promise(resolve => {
      office365Auth(req.body.user, req.body.pass, 'https://gpax.io', (err, auth) => {
        if (err) {
          resolve({ error: err })
        } else {
          resolve(auth)
        }
      })
    })
    if (auth.error) {
      req.statusCode = 401
      send()
    } else if (auth) {
      let users = req.app.getMongo(req.app.params.user)
      users.findOne('user', { email: req.body.user, active: true }, (err, user) => {
        if (err || !user) {
          req.statusCode = 401
          send()
        } else {
          this.createSession(req, user, send)
        }
      })
    }
  }
  // Destroy user session and redirect to home
  disconnect (req, mongo, send) {
    delete req.session.database
    req.session.authenticated = false
    req.session.destroy(function () {
      send({ authenticated: false })
    })
  }

  profile (req, mongo, send) {
    req.query._id = req.session._id
    this.get(req, mongo, send)
  }

  /* user for edit form */
  get (req, mongo, send) {
    if (req.query._id) {
      mongo.findId('user', req.query._id, async (err, user) => {
        if (!err && user) {
          if (user.password) delete user.password
          if (user.business) {
            const beginHiring = user.business.beginHiring ? user.business.beginHiring.getFullYear() + '-' + (user.business.beginHiring.getMonth() + 1) + '-' + user.business.beginHiring.getDate() : user.business.beginHiring
            const endHiring = user.business.endHiring ? user.business.beginHiring.getFullYear() + '-' + (user.business.beginHiring.getMonth() + 1) + '-' + user.business.beginHiring.getDate() : user.business.endHiring
            user.business.beginHiring = beginHiring
            user.business.endHiring = endHiring
          }
          if (!user.receivedEmailNotification) {
            user.receivedEmailNotification = '1'
          }
          if (user.photo) delete user.photo
          user.name = user.name.replace(/(<([^>]+)>)/g, '')
          if (!user.dashboard || !user.menu || !user.authMethod) {
            await new Promise((resolve) => {
              mongo.findOne('settings', { _id: 'settings' }, (err, setting) => {
                setting = setting || { authMethodLicensed: '', authMethodUnLicensed: '' }
                if (user.licensedUser) {
                  if (!user.dashboard) {
                    user.dashboard = setting.dashboardLicensed || 'home.dashboard2'
                  }
                  if (!user.menu) {
                    user.menu = user.menu === 'invoices' ? user.menu : setting.menuLicensed || 'projects'
                  }
                  if (!user.authMethod) {
                    if (!setting.authMethodLicensed) {
                      setting.authMethodLicensed = []
                    }
                    let index = setting.authMethodLicensed.indexOf('gpax');
                    user.authMethod = setting.authMethodLicensed[index] || 'gpax'
                  }
                } else if (!user.licensedUser) {
                  if (!user.dashboard) {
                    user.dashboard = setting.dashboardUnLicensed || 'note.notes'
                  }
                  if (!user.menu) {
                    user.menu = setting.menuUnLicensed || 'auditor'
                  }
                  if (!user.authMethod) {
                    if (!setting.authMethodUnLicensed) {
                      setting.authMethodUnLicensed = []
                    }
                    let index = setting.authMethodUnLicensed.indexOf('gpax');
                    user.authMethod = setting.authMethodUnLicensed[index] || 'gpax'
                  }
                }
                resolve()
              })
            })
          }
          send(user)
        } else {
          send()
        }
      })
    } else {
      send({ _id: mongo.newId(), active: true, receivedEmailNotification: '1' })
    }
  }

  getToken (req, mongo, send) {
    req.app.getMongo(req.app.params.user).findOne('user', { user: req.session.context.user }, { login: 1, password: 1 }, (err, user) => {
      if (!err && user) {
        var token = Buffer.from(user.login + ':' + user.password).toString('base64')
        send({ message: 'Token: ' + token })
      } else {
        send()
      }
    })
  }

  list (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    var keys = {}
    if (req.query.filter) {
      const query = {}
      for (const name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          if (name === 'filterNames') {
            query.units = { $in: [mongo.toId(req.query.filter[name])] }
          }
          if (name === 'name') {
            query.name = new RegExp(req.query.filter.name, 'i')
          } else if (name === 'licenseText') {
            query.licensedUser = req.query.filter[name] === tags.yes
          } else if (name === 'activeText') {
            query.active = req.query.filter[name] === tags.yes
          } else if (name === '_id') {
            var ids = req.query.filter[name].split(',')
            for (const i in ids) {
              if (mongo.isNativeId(ids[i])) {
                ids[i] = mongo.toId(ids[i])
              }
            }
            query[name] = { $in: ids }
          } else if (name === 'code') {
            query.login = { $regex: req.query.filter[name], $options: 'i' }
          } else {
            query[name] = req.query.filter[name].indexOf(',') !== -1 ? { $in: req.query.filter[name].split(',') } : new RegExp(req.query.filter[name].replace(/ /g, '.*'), 'i')
          }
        }
      }
      delete query.filterNames
      keys = query
    }
    mongo.findN('user', skip, limit, keys, { _id: 1, name: 1, units: 1, roles: 1, licensedUser: 1, active: 1, signature: 1, login: 1, email: 1 }, { name: 1 }, (err, users) => {
      if (!err && users) {
        var unitIds = []
        for (const i in users) {
          var user = users[i]
          if (user.units && user.units.length > 0) {
            for (const j in user.units) {
              unitIds.push(user.units[j])
            }
          }
        }
        mongo.toHash('unit', { _id: { $in: unitIds } }, {}, {}, (err, units) => {
          for (const i in users) {
            var unitName = []
            var user = {}
            user.id = users[i]._id ? users[i]._id.toString() : ''
            user.licenseText = users[i].licensedUser === true ? tags.yes : tags.no
            user.licensedUser = !!users[i].licensedUser
            user.activeText = users[i].active ? tags.yes : tags.no
            user.active = users[i].active ? users[i].active : false
            user.unitName = unitName
            user.name = users[i].name
            user.code = users[i].login
            user.email = users[i].email
            user.signature = users[i].signature
            if (!err && users[i].units) {
              for (const u in users[i].units) {
                var unit = users[i].units[u]
                if (unit && units[unit] && units[unit].name) {
                  user.unitName.push(units[unit].name)
                }
              }
            }
            if (users[i].roles) {
              user.createUsers = !!users[i].roles.createUsers
              user.createUsersText = users[i].roles.createUsers ? tags.yes : tags.no
              user.createUnits = !!users[i].roles.createUnits
              user.createUnitsText = users[i].roles.createUnits ? tags.yes : tags.no
              user.createTemplates = !!users[i].roles.createTemplates
              user.createTemplatesText = users[i].roles.createTemplates ? tags.yes : tags.no
              user.createSequences = !!users[i].roles.createSequences
              user.createSequencesText = users[i].roles.createSequences ? tags.yes : tags.no
              user.createRepositories = !!users[i].roles.createRepositories
              user.createRepositoriesText = users[i].roles.createRepositories ? tags.yes : tags.no
              user.createProcesses = !!users[i].roles.createProcesses
              user.createProcessesText = users[i].roles.createProcesses ? tags.yes : tags.no
              user.createProcedures = !!users[i].roles.createProcedures
              user.createProceduresText = users[i].roles.createProcedures ? tags.yes : tags.no
              user.setSequence = !!users[i].roles.setSequence
              user.setSequenceText = users[i].roles.setSequence ? tags.yes : tags.no
            } else {
              user.createUsers = false
              user.createUnits = false
              user.createTemplates = false
              user.createSequences = false
              user.createRepositories = false
              user.createProcesses = false
              user.createProcedures = false
              user.setSequence = false
              user.createUsersText = 'No'
              user.createUnitsText = 'No'
              user.createTemplatesText = 'No'
              user.createSequencesText = 'No'
              user.createRepositoriesText = 'No'
              user.createProcessesText = 'No'
              user.createProceduresText = 'No'
              user.setSequenceText = 'No'
            }
            var filterNames = [unitName ? unitName[0] : '']
            user.filterNames = filterNames
            reply.data.push(user)
          }
          if (skip) {
            send(reply)
          } else {
            mongo.count('user', keys, (err, count) => {
              if (!err && count) {
                reply.total_count = count
              }
              send(reply)
            })
          }
        })
      } else {
        reply.total_count = 0
        send(reply)
      }
    })
  }

  // funcion guardar autotimer de document en user
  autoTimer (req, mongo, send) {
    if (req.query.autoTimer === 'true') {
      var autoTimer = 0
    } else {
      autoTimer = 1
    }
    req.session.autoTimer = autoTimer * 1 !== 0
    mongo.save('user', { _id: req.session._id, autoTimer: req.session.autoTimer }, (err, result) => {
      if (err) {
        send({ error: tags.savingProblema })
      } else {
        send({ message: tags.savedChanges })
      }
    })
  }

  /* Image for user */
  async image (req, mongo, send) {
    mongo.findId('user', req.query._id, async (err, doc) => {
      if (err || !doc) {
        send({ error: err })
      } else {
        if (doc.photo && mongo.isNativeId(doc.photo)) {
          mongo.getfile(doc.photo, async (err, stream) => {
            if (!err) {
              send(stream)
            } else {
              fs.readFile(path.join(__dirname, '/../img/photo.png'), (err, data) => {
                if (err) throw err
                send(data)
              })
            }
          })
        } else {
          fs.readFile(path.join(__dirname, '/../img/photo.png'), (err, data) => {
            if (err) throw err
            send(data)
          })
        }
      }
    })
  }

  async getProperties (req, mongo, send) {
    mongo.findId('user', req.body._id, req.body.properties, async (err, doc) => {
      if (err || !doc) {
        send({ error: err })
      } else {
        send(doc)
      }
    })
  }

  /* Image for user */
  setImage (req, mongo, send) {
    mongo.findId('user', req.query._id, (err, doc) => {
      if (err || !doc) {
        send({ error: err })
      } else {
        mongo.savefile(req, (err, result) => {
          if (!err) {
            var id = result.link
            id = id.split('_id=')[1].split('&')[0]
            mongo.save('user', { _id: req.query._id, photo: mongo.toId(id) }, (err, rslt) => {
              if (err) throw err
              result.status = 'server'
              notification.send(req, req.session.context.room, 'dt_user', {}, null, null)
              send(result)
            })
          } else {
            send()
          }
        })
      }
    })
  }

  setLang (req, mongo, send) {
    if (req.session && req.session.context && req.session.context.user) {
      mongo.update('user', { _id: req.session.context.user }, { $set: { lang: req.query.lang } }, (err, result) => {
        if (err) throw err
        send()
      })
    } else {
      send({ error: 'Missing session' })
    }
  }

  quick (req, mongo, send) {
    var user = req.body
    user.name += ' ' + user.login
    user.password = tags.util.crypto(user.login)
    user.units = user.units.split(',')
    user.active = true
    user.licensedUser = false
    user.createUsers = false
    user.createUnits = false
    user.createTemplates = false
    user.createSequences = false
    user.createRepositories = false
    user.createProcesses = false
    user.createProcedures = false
    user.setSequence = false
    mongo.find('user', { login: user.login }, (err, exists) => {
      if (err) throw err
      if (exists && exists.length) {
        send({ error: 'alreadyExists' })
      } else {
        mongo.save('user', user, (err, result) => {
          if (err) {
            send({ error: tags.savingProblem })
          } else {
            mongo.update('unit', { _id: user.units[0] }, { $addToSet: { actors: { user: user._id, type: ['member'] } } }, (err, result) => {
              if (err) throw err
              send({ message: tags.savedChanges })
            })
          }
        })
      }
    })
  }

  save (req, mongo, send) {
    mongo.findId('user', req.body._id, (err, user) => {
      if (err) throw err
      mongo.findOne('settings', (err, setting) => {
        if (err) {
          send({ error: err })
        } else {
          mongo.find('unit', {}, {}, {}, async (err, unitResult) => {
            var oldUnits
            if (err) {
              send({ error: tags.savingProblema })
            } else {
              if (!user || !user.units) { oldUnits = [] } else { oldUnits = user.units }
              var doc = req.body
              doc.email = doc.email.toLowerCase()
              let exEmail = await new Promise(resolve => {
                mongo.find('user', { email: doc.email }, async (err, user) => {
                  if (err || (user && user.length)) {
                    resolve(user[0])
                  } else {
                    resolve(false)
                  }
                })
              })
              let exLogin = await new Promise(resolve => {
                mongo.find('user', { login: doc.login }, async (err, user) => {
                  if (err || (user && user.length)) {
                    resolve(user[0])
                  } else {
                    resolve(false)
                  }
                })
              })
              if (exEmail && (!user || (user && (exEmail._id.toString() !== user._id.toString()) &&
                ((user._id.toString() !== req.session.context.user.toString()) ||
                  (user._id.toString() === req.session.context.user.toString() &&
                    exEmail._id.toString() !== req.session.context.user.toString()))))) {
                send({ error: 'Ya existe usuario con este correo' })
              } else if (exLogin && (!user || (user && (exLogin._id.toString() !== user._id.toString()) &&
                ((user._id.toString() !== req.session.context.user.toString()) ||
                  (user._id.toString() === req.session.context.user.toString() &&
                    exLogin._id.toString() !== req.session.context.user.toString()))))) {
                send({ error: 'Ya existe usuario con este código de usuario' })
              } else {
                if (doc.trainnings && doc.trainnings.length && doc.trainnings !== '[]') {
                  for (const trainning in doc.trainnings) {
                    if (doc.trainnings[trainning].hourTrainning) {
                      doc.trainnings[trainning].hourTrainning = parseFloat(doc.trainnings[trainning].hourTrainning)
                    }
                    if (!doc.trainnings[trainning].topic || doc.trainnings[trainning].topic === '') {
                      doc.trainnings[trainning].topic = []
                    } else {
                      if (typeof doc.trainnings[trainning].topic === 'string') doc.trainnings[trainning].topic = doc.trainnings[trainning].topic.split(',')

                      for (const i in doc.trainnings[trainning].topic) {
                        doc.trainnings[trainning].topic[i] = mongo.toId(doc.trainnings[trainning].topic[i])
                      }
                    }
                  }
                }
                if (doc.id) { doc._id = mongo.isNativeId(doc.id) ? mongo.toId(doc.id) : mongo.newId() }
                delete doc.repeatPassword // This field is for validation only
                delete doc.photo // This field is saved with a specific url
                if (doc.password.length > 0) { // Si password is present, can be encrypted
                  doc.password = tags.util.crypto(doc.password)
                  doc.expirationDate = new Date()
                } else {
                  delete doc.password
                }
                if (doc.expirationPassword) {
                  if (!setting || !setting.expirationPassword) { doc.expirationPassword = '' } else if (user.expirationPassword && parseInt(doc.expirationPassword) > parseInt(setting.expirationPassword)) { doc.expirationPassword = setting.expirationPassword }
                  if (doc.expirationPassword) {
                    if (!doc.expirationDate) { var date = new Date() } else { date = doc.expirationDate }
                    doc.expirationDate = date
                    var newDay = date.getDate() + parseInt(doc.expirationPassword)
                    var newDate = new Date(date)
                    var maxDate = newDate.setDate(newDay)
                    doc.expirationDateMax = new Date(maxDate)
                  }
                }
                doc[tags.expiredPassword] = doc[tags.expiredPassword] * 1 !== 0
                doc.active = doc.active * 1 !== 0
                doc.licensedUser = doc.licensedUser * 1 !== 0
                doc.autoTimer = doc.autoTimer * 1 !== 0
                for (let rol in doc.roles) {
                  if (doc.roles[rol]) {
                    doc.roles[rol] = doc.roles[rol] * 1 !== 0
                  }
                }
                if (doc.units) {
                  doc.units = doc.units.length >= 24 ? doc.units.split(',') : []
                  for (let u in doc.units) {
                    doc.units[u] = mongo.toId(doc.units[u])
                    var index = unitResult.findIndex((x) => {
                      return x._id.toString() === doc.units[u].toString()
                    })
                    if (index === -1) {
                      doc.units.splice(u, 1)
                    }
                  }
                } else {
                  doc.units = []
                }
                if (doc.unitsMention) {
                  doc.unitsMention = doc.unitsMention.length >= 24 ? doc.unitsMention.split(',') : []
                }
                else {
                  doc.unitsMention = []
                }
                if (doc.readerUnits) {
                  doc.readerUnits = doc.readerUnits.length >= 24 ? doc.readerUnits.split(',') : []
                  for (let u in doc.readerUnits) {
                    doc.readerUnits[u] = mongo.toId(doc.readerUnits[u])
                    var index = unitResult.findIndex((x) => {
                      return x._id.toString() === doc.readerUnits[u].toString()
                    })
                    if (index === -1) {
                      doc.readerUnits.splice(u, 1)
                    }
                  }
                } else {
                  doc.readerUnits = []
                }
                if (!doc.active) {
                  doc.name = '<span class="inactive">' + doc.name + '</span>'
                } else {
                  doc.name = doc.name.replace(/(<([^>]+)>)/g, '')
                }
                doc._id = mongo.toId(doc._id)
                doc.authMethod = doc.authMethod.split(',')
                let password = doc.password
                delete doc.password
                mongo.save('user', doc, (err, result) => {
                  if (err) {
                    send({ error: tags.savingProblem })
                  } else {
                    if (password) {
                      doc.password = password
                    }
                    this.updateLogin(req, doc, (err) => {
                      if (err) {
                        send({ error: err.toString() })
                      } else {
                        mongo.toHash('unit', { _id: { $in: doc.units } }, { _id: 1, name: 1 }, (err, units) => {
                          if (err && !units) units = []
                          if (doc.units && doc.units.length > oldUnits.length) { addUnits(0) } else if (doc.units && doc.units.length < oldUnits.length) {
                            var removeUnits = []
                            for (const i in oldUnits) {
                              if (doc.units.findIndex((x) => { return x.equals(oldUnits[i]) }) === -1) {
                                removeUnits.push(oldUnits[i])
                              }
                            }
                            dropUnits(0)
                          } else {
                            send({ message: tags.savedChanges })
                          }
                          // Agrega al usuario como miembro en la unidad
                          function addUnits (i) {
                            mongo.findId('unit', doc.units[i], (err, unit) => {
                              if (err) send({ error: err })
                              else if (unit) {
                                if (!unit && !unit.actors) {
                                  unit.actors = []
                                }
                                unit.actors = unit.actors || []
                                const index = unit.actors.findIndex((x) => {
                                  return x.user.equals(doc._id)
                                })
                                if (index === -1) {
                                  unit.actors.push({
                                    user: doc._id,
                                    type: [tags.member]
                                  })
                                }
                                mongo.save('unit', unit, (err, result) => {
                                  if (err) {
                                    send({ error: tags.savingProblema })
                                  } else {
                                    if (i >= doc.units.length - 1) { send({ message: tags.savedChanges }) } else {
                                      i = i + 1
                                      addUnits(i)
                                    }
                                  }
                                })
                              } else if (i >= removeUnits.length - 1) { send({ message: tags.savedChanges }) } else {
                                i = i + 1
                                dropUnits(i)
                              }
                            })
                          }
                          // remueve al usuario de la unidad
                          function dropUnits (i) {
                            mongo.findId('unit', removeUnits[i], (err, unit) => {
                              if (err) send({ error: err })
                              else if (unit) {
                                if (!unit.actors) {
                                  unit.actors = []
                                }
                                const index = unit.actors.findIndex((x) => {
                                  if (x.user.equals(doc._id)) {
                                    return x
                                  }
                                })
                                if (index !== -1) {
                                  unit.actors.splice(index, 1)
                                }
                                mongo.save('unit', unit, (err, result) => {
                                  if (err) {
                                    send({ error: tags.savingProblema })
                                  } else {
                                    if (i >= removeUnits.length - 1) { send({ message: tags.savedChanges }) } else {
                                      i = i + 1
                                      dropUnits(i)
                                    }
                                  }
                                })
                              } else if (i >= removeUnits.length - 1) { send({ message: tags.savedChanges }) } else {
                                i = i + 1
                                dropUnits(i)
                              }
                            })
                          }
                        })
                        var unitIds = []
                        var user = doc
                        if (user.units && user.units.length > 0) {
                          for (const j in user.units) { unitIds.push(user.units[j]) }
                        }
                        mongo.toHash('unit', { _id: { $in: unitIds } }, {}, {}, (err, units) => {
                          var unitName = []
                          var user = {}
                          user.id = doc._id ? doc._id.toString() : ''
                          user.licenseText = doc.licensedUser === true ? tags.yes : tags.no
                          user.licensedUser = !!doc.licensedUser
                          user.activeText = doc.active ? tags.yes : tags.no
                          user.active = doc.active ? doc.active : false
                          user.unitName = unitName
                          user.name = doc.name
                          user.code = doc.login
                          if (!err && doc.units) {
                            for (const u in doc.units) {
                              var unit = doc.units[u]
                              if (unit && units[unit] && units[unit].name) {
                                user.unitName.push(units[unit].name)
                              }
                            }
                          }
                          if (doc.roles) {
                            user.createUsers = !!doc.roles.createUsers
                            user.createUsersText = doc.roles.createUsers ? tags.yes : tags.no
                            user.createUnits = !!doc.roles.createUnits
                            user.createUnitsText = doc.roles.createUnits ? tags.yes : tags.no
                            user.createTemplates = !!doc.roles.createTemplates
                            user.createTemplatesText = doc.roles.createTemplates ? tags.yes : tags.no
                            user.createSequences = !!doc.roles.createSequences
                            user.createSequencesText = doc.roles.createSequences ? tags.yes : tags.no
                            user.createRepositories = !!doc.roles.createRepositories
                            user.createRepositoriesText = doc.roles.createRepositories ? tags.yes : tags.no
                            user.createProcesses = !!doc.roles.createProcesses
                            user.createProcessesText = doc.roles.createProcesses ? tags.yes : tags.no
                            user.createProcedures = !!doc.roles.createProcedures
                            user.createProceduresText = doc.roles.createProcedures ? tags.yes : tags.no
                            user.setSequence = !!doc.roles.setSequence
                            user.setSequenceText = doc.roles.setSequence ? tags.yes : tags.no
                          } else {
                            user.createUsers = false
                            user.createUnits = false
                            user.createTemplates = false
                            user.createSequences = false
                            user.createRepositories = false
                            user.createProcesses = false
                            user.createProcedures = false
                            user.setSequence = false
                            user.createUsersText = 'No'
                            user.createUnitsText = 'No'
                            user.createTemplatesText = 'No'
                            user.createSequencesText = 'No'
                            user.createRepositoriesText = 'No'
                            user.createProcessesText = 'No'
                            user.createProceduresText = 'No'
                            user.setSequence = 'No'
                          }
                          var filterNames = [unitName ? unitName[0] : '']
                          user.filterNames = filterNames
                          notification.send(req, req.session.context.room, 'dt_user', user, null, null)
                        })
                      }
                    })
                  }
                })
              }
            }
          })
        }
      })
    })
  }

  updateLogin (req, doc, next) {
    var u = {
      user: doc._id, active: doc.active, database: req.session.database, menu: doc.menu,
      login: '', userId: '', email: ''
    }
    u.login = doc.login
    if (doc.password) u.password = doc.password
    u.userId = doc.userId
    u.email = doc.email
    var usersDb = req.app.getMongo(req.app.params.user)
    usersDb.findOne('user', { user: u.user }, (err, doc) => {
      if (!err && doc) {
        u._id = doc._id
      } else {
        u._id=usersDb.newId()
      }
      usersDb.save('user', u, next)
    })
  }

  updateExpiredPassword (req, mongo, send) {
    var doc = req.body
    doc.password = tags.util.crypto(doc.password)
    var usersDb = req.app.getMongo(req.app.params.user)
    usersDb.findOne('user', { user: mongo.toId(doc._id) }, {}, (err, userdb) => {
      mongo.findId('user', doc._id, (err, user) => {
        if (err || !user) {
          send()
        } else {
          mongo.findOne('settings', (err, setting) => {
            if (err) {
              send({ error: err })
            } else {
              var before = user
              var now = doc
              if (before.history && typeof before.history === 'string') before.history = ''
              if (!before.history) {
                before.history = [userdb.password]
              } else {
                before.history.push(userdb.password)
                if (before.history.length > 10) {
                  before.history.shift()
                }
              }
              if (before.history.includes(now.password)) {
                send({ msj: '_equal' })
              } else {
                if (user.expirationPassword) {
                  var newExpirationDate = new Date()
                  var maxDate = new Date()
                  if (!setting || !setting.expirationPassword) { user.expirationPassword = '' } else if (user.expirationPassword && parseInt(user.expirationPassword) > parseInt(setting.expirationPassword)) { user.expirationPassword = setting.expirationPassword }
                  if (user.expirationPassword) {
                    newExpirationDate = new Date()
                    var newDay = newExpirationDate.getDate() + parseInt(user.expirationPassword)
                    var newDate = new Date(newExpirationDate)
                    maxDate = newDate.setDate(newDay)
                    maxDate = new Date(maxDate)
                  }
                }
                mongo.save('user', { _id: user._id, history: before.history, expirationDateMax: maxDate, expirationDate: newExpirationDate, expiredPassword: false }, (err, result) => {
                  if (err) {
                    send({ msj: '_notSaved' })
                  } else {
                    usersDb.update('user', { user: user._id }, { $set: { password: now.password } }, (err, result) => {
                      if (err) {
                        send({ error: tags.savingProblem })
                      } else {
                        send({ msj: '_ok' })
                      }
                    })
                  }
                })
              }
            }
          })
        }
      })
    })
  }

  finduser (req, mongo, id, send) {
    mongo.findId('user', id, (err, user) => {
      if (err) {
        send({ error: tags.savingProblema })
      } else {
        const usu = []
        usu.push({
          text: user.name,
          value: user._id.toString()
        })
        send(usu)
      }
    })
  }

  async delete (req, mongo, send) {
    var doc = req.query
    var idUser = mongo.toId(doc._id)
    var pipeline = [
      { $match: { _id: idUser } },
      {
        $lookup: {
          from: 'evidence', let: { idUser: '$_id' }, pipeline: [
            { $match: { $expr: { $in: ['$$idUser', { $cond: { if: { $isArray: ['$actors.user'] }, then: '$actors.user', else: ['$actors.user'] } }] }, actors: { $exists: true } } },
            { $project: { _id: 1, actors: 1 } }
          ], as: 'evidences'
        }
      },
      {
        $lookup: {
          from: 'note', let: { idUser: '$_id' }, pipeline: [
            { $match: { $expr: { $in: ['$$idUser', { $cond: { if: { $isArray: ['$actors.user'] }, then: '$actors.user', else: ['$actors.user'] } }] }, actors: { $exists: true } } },
            { $project: { _id: 1, actors: 1 } }
          ], as: 'notes'
        }
      },
      {
        $lookup: {
          from: 'processAssessment', let: { idUser: '$_id' }, pipeline: [
            { $match: { $expr: { $in: ['$$idUser', { $cond: { if: { $isArray: ['$user'] }, then: '$user', else: ['$user'] } }] }, user: { $exists: true } } },
            { $project: { _id: 1, user: 1 } }
          ], as: 'processAssessments'
        }
      },
      {
        $lookup: {
          from: 'riskEvent', let: { idUser: '$_id' }, pipeline: [
            { $match: { $expr: { $in: ['$$idUser', { $cond: { if: { $isArray: ['$user'] }, then: '$user', else: ['$user'] } }] }, user: { $exists: true } } },
            { $project: { _id: 1, user: 1 } }
          ], as: 'riskEvents'
        }
      },
      {
        $lookup: {
          from: 'settings', let: { idUser: '$_id' }, pipeline: [
            {
              $match: {
                $expr: {
                  $or: [
                    { $in: ['$$idUser', { $cond: { if: { $isArray: ['$copies'] }, then: '$copies', else: ['$copies'] } }] }, { $in: ['$$idUser', { $cond: { if: { $isArray: ['$rpaUsers'] }, then: '$rpaUsers', else: ['$rpaUsers'] } }] },
                    { $eq: ['$rpaUser', '$$idUser'] }
                  ]
                }
              }
            }, { $project: { _id: 1, copies: 1, rpaUser: 1, rpaUsers: 1 } }
          ], as: 'settings'
        }
      },
      {
        $lookup: {
          from: 'time', let: { idUser: '$_id' }, pipeline: [
            { $match: { $expr: { $in: ['$$idUser', { $cond: { if: { $isArray: ['$user'] }, then: '$user', else: ['$user'] } }] }, user: { $exists: true } } },
            { $project: { _id: 1, user: 1 } }
          ], as: 'time'
        }
      },
      {
        $lookup: {
          from: 'trash', let: { idUser: '$_id' }, pipeline: [
            { $match: { $expr: { $in: ['$$idUser', { $cond: { if: { $isArray: ['$user'] }, then: '$user', else: ['$user'] } }] }, user: { $exists: true } } },
            { $project: { _id: 1, user: 1 } }
          ], as: 'trash'
        }
      },
      {
        $lookup: {
          from: 'unit', let: { idUser: '$_id' }, pipeline: [
            { $match: { $expr: { $in: ['$$idUser', { $cond: { if: { $isArray: ['$actors.user'] }, then: '$actors.user', else: ['$actors.user'] } }] }, actors: { $exists: true } } },
            { $project: { _id: 1, actors: 1 } }
          ], as: 'units'
        }
      },
      { $project: { _id: 1, name: 1, projects: 1, attacheds: 1, commitments: 1, controlAssessments: 1, documents: 1, evidences: 1, notes: 1, processAssessments: 1, riskEvents: 1, settings: 1, time: 1, trash: 1, units: 1 } },
      { $sort: { _id: -1 } }
    ]
    var user = await new Promise(resolve => {
      mongo.aggregate('user', pipeline, {}, async (err, user) => {
        if (err) {
          resolve()
        } else {
          resolve(user)
        }
      })
    })
    if (user && user[0] && (
      (user[0].units && user[0].units.length) ||
      (user[0].projects && user[0].projects.length) ||
      (user[0].attacheds && user[0].attacheds.length) ||
      (user[0].commitments && user[0].commitments.length) ||
      (user[0].controlAssessments && user[0].controlAssessments.length) ||
      (user[0].documents && user[0].documents.length) ||
      (user[0].evidences && user[0].evidences.length) ||
      (user[0].notes && user[0].notes.length) ||
      (user[0].processAssessments && user[0].processAssessments.length) ||
      (user[0].riskEvents && user[0].riskEvents.length) ||
      (user[0].settings && user[0].settings.length) ||
      (user[0].time && user[0].time.length) ||
      (user[0].trash && user[0].trash.length))) {
      send({ msj: '_cantDeleteUserAlreadyInUse' }) //El usuario no se puede borrar porque ya ha sido utilizado en el sistema
    } else {
      mongo.deleteOne('user', { _id: mongo.toId(doc._id) }, (err, result) => {
        if (err) {
          req.logger.log(err)
        } else {
          req.app.routes.trash.insert(req, mongo, 'user', user, () => {
            send({ message: tags.savedChanges })
            doc.id = doc._id
            notification.send(req, req.session.context.room, 'dt_user', doc, null, true)
          })
        }
      })
    }
  }

  getTrainning (req, mongo, send) {
    var tagsDoc = []
    var reply = []

    mongo.find('params', { name: { $in: ['topics', 'degrees'] } }, { _id: 1, name: 1, options: 1 }, (er, tgsDs) => {
      if (tgsDs.length > 0) {
        for (const i in tgsDs) {
          tagsDoc = tagsDoc.concat(tgsDs[i].options)
        }
      }
      mongo.findId('user', mongo.toId(req.query.user), (err, user) => {
        if (!err && user) {
          const docs = user.trainnings && user.trainnings !== '[]' ? user.trainnings : []

          for (const i in docs) {
            if (!docs[i].id) {
              docs[i].id = docs[i]._id
            }
            if (docs[i].topic && !docs[i].topic.length) {
              docs[i].topic = [docs[i].topic]
            }
            var tagsId = []
            if (docs[i].topic) {
              for (const top in docs[i].topic) {
                tagsId.push(docs[i].topic[top])
              }
            }
            if (docs[i].degree) {
              tagsId.push(docs[i].degree)
            }
            var usedTags = []
            if (tagsDoc.length > 0 && tagsId && tagsId.length > 0) {
              for (let t = 0; t < tagsDoc.length; t++) {
                if (tagsId.length) {
                  for (let o = 0; o < tagsId.length; o++) {
                    if (tagsDoc[t].id && tagsId[o] && tagsDoc[t].id.toString() === tagsId[o].toString()) {
                      usedTags.push(tagsDoc[t])
                    }
                  }
                } else {
                  if (tagsDoc[t] && tagsId && tagsDoc[t].id.toString() === tagsId.toString()) {
                    usedTags.push(tagsDoc[t])
                  }
                }
              }
            }
            var tagscolor = []
            var tagsname = []
            var tagsid = []
            for (const i in usedTags) {
              tagscolor.push(usedTags[i].color)
              tagsname.push(usedTags[i].value)
              tagsid.push(usedTags[i].id)
            }
            docs[i].tagscolor = tagscolor
            docs[i].tagsname = tagsname
            docs[i].tagsid = tagsid
            if (docs[i].date) {
              docs[i].date = new Date(docs[i].date)
              docs[i].dateTrainning = docs[i].date.getFullYear()
              docs[i].date = docs[i].date.getFullYear() + '-' + (docs[i].date.getMonth() + 1) + '-' + docs[i].date.getDate()
            } else if (docs[i].period && docs[i].period.end) {
              docs[i].date = new Date(docs[i].period.end)
              docs[i].dateTrainning = docs[i].date.getFullYear()
              docs[i].date = docs[i].date.getFullYear() + '-' + (docs[i].date.getMonth() + 1) + '-' + docs[i].date.getDate()
            }
            if (docs[i].period && docs[i].period.start && docs[i].period.end) {
              docs[i].period.start = new Date(docs[i].period.start)
              docs[i].period.end = new Date(docs[i].period.end)
              docs[i].period.start = docs[i].period.start.getFullYear() + '-' + (docs[i].period.start.getMonth() + 1) + '-' + docs[i].period.start.getDate()
              docs[i].period.end = docs[i].period.end.getFullYear() + '-' + (docs[i].period.end.getMonth() + 1) + '-' + docs[i].period.end.getDate()
            }
            reply.push(docs[i])
          }
          send(reply)
        } else {
          send()
        }
      })
    })
  }

  getSkill (req, mongo, send) {
    var tagsDoc = []
    var reply = []
    mongo.find('params', { name: { $in: ['skills', 'skillLevel'] } }, { _id: 1, name: 1, options: 1 }, (er, tgsDs) => {
      if (tgsDs.length > 0) {
        for (const i in tgsDs) {
          tagsDoc = tagsDoc.concat(tgsDs[i].options)
        }
      }
      mongo.findId('user', req.query.user, (err, user) => {
        if (!err && user) {
          const docs = user.skills && user.skills !== '[]' ? user.skills : []
          for (const i in docs) {
            var tagsId = []
            if (docs[i].skill !== '') { tagsId.push(docs[i].skill) }
            if (docs[i].level !== '') { tagsId.push(docs[i].level) }
            var usedTags = []
            if (tagsDoc.length > 0 && tagsId && tagsId.length > 0) {
              for (let t = 0; t < tagsDoc.length; t++) {
                if (tagsId.length) {
                  for (let o = 0; o < tagsId.length; o++) {
                    if (tagsDoc[t].id && tagsId[o] && tagsDoc[t].id.toString() === tagsId[o].toString()) {
                      usedTags.push(tagsDoc[t])
                    }
                  }
                } else {
                  if (tagsDoc[t] && tagsId && tagsDoc[t].id.toString() === tagsId.toString()) {
                    usedTags.push(tagsDoc[t])
                  }
                }
              }
            }
            var tagscolor = []
            var tagsname = []
            var tagsid = []
            for (const i in usedTags) {
              tagscolor.push(usedTags[i].color)
              tagsname.push(usedTags[i].value)
              tagsid.push(usedTags[i].id)
            }
            docs[i].tagscolor = tagscolor
            docs[i].tagsname = tagsname
            docs[i].tagsid = tagsid
            if (docs[i].date && docs[i].date.start) {
              docs[i].date.start = !docs[i].date.start ? new Date(docs[i].date) : new Date(docs[i].date.start)
              docs[i].date.end = !docs[i].date.end ? docs[i].date.start : new Date(docs[i].date.end)

              docs[i].date.start = docs[i].date.start.getFullYear() + '-' + (docs[i].date.start.getMonth() + 1) + '-' + docs[i].date.start.getDate()
              docs[i].date.end = docs[i].date.end.getFullYear() + '-' + (docs[i].date.end.getMonth() + 1) + '-' + docs[i].date.end.getDate()
            } else {
              const date = {}
              date.start = new Date(docs[i].date)
              date.end = new Date(docs[i].date)

              date.start = date.start.getFullYear() + '-' + (date.start.getMonth() + 1) + '-' + date.start.getDate()
              date.end = date.end.getFullYear() + '-' + (date.end.getMonth() + 1) + '-' + date.end.getDate()
              docs[i].date = date
            }
            reply.push(docs[i])
          }
          send(reply)
        } else {
          send()
        }
      })
    })
  }

  getUserSettings (req, mongo, send) {
    mongo.find('userSettings', { user: req.session.context.user},(err, setting) => {
      if (err) {
        send({ error: err })
      } else {
        if (!setting.length) {
          send({})
        } else {
          send(setting[0])
        }
      }
    })

  }

  setUserSettings (req, mongo, send) {
    mongo.find('userSettings', { user: req.session.context.user},(err, setting) => {
      if (err) {
        send({ error: err })
      } else {
        let doc = req.body
        if (!setting.length) {
          doc._id = mongo.newId()
          doc.user = req.session.context.user
          mongo.save('userSettings', doc, (err) => {
            if (err) {
              send({ error: tags.savingProblem })
            } else {
              send({ message: tags.savedChanges })
            }
          })
        } else {
          doc._id = setting[0]._id
          mongo.save('userSettings', doc, (err) => {
            if (err) {
              send({ error: tags.savingProblem })
            } else {
              send({ message: tags.savedChanges })
            }
          })
        }
      }
    })

  }

  async getPerformanceForms (req, mongo, send) {
    var user = req.query.user
    mongo.findOne('settings', { _id: 'settings' }, async (err, doc) => {
      if (err || !doc) {
        send()
      } else {
        var performanceForms = doc.performanceForms
        var documentPerformanceForms = []
        for (const i in performanceForms) {
          var documents = await new Promise(resolve => {
            mongo.find('document', { type: 'form', template: performanceForms[i], person: mongo.toId(user) }, { _id: 1, type: 1, name: 1, template: 1, person: 1, evaluador: 1 }, (err, docs) => {
              if (!err) {
                resolve(docs)
              }
            })
          })

          if (documents) {
            for (const d in documents) {
              var evaluador = await new Promise(resolve => {
                mongo.find('user', { _id: mongo.toId(documents[d].evaluador.toString()) }, { _id: 1, name: 1 }, (err, users) => {
                  if (!err) {
                    resolve(users[0])
                  }
                })
              })
              documents[d].nameEvaluador = evaluador.name
              documentPerformanceForms.push(documents[d])
            }
          }
        }
        send(documentPerformanceForms)
      }
    })
  }
  crtAuth (req, mongo, send) {
    var subject = req.query.cedula
    subject = subject.split('SERIALNUMBER=')[1].split(',')[0]
    var ced = ''
    var arrayId = subject.match(/\d+/g)
    for (var i in arrayId) {
      ced += arrayId[i]
    }
    notification.send(req, 'smartcard', req.query.wsid, ced, [req.query.wsid], false)
    send()
  }
}
exports.User = User