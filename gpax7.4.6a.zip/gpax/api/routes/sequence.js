/* exported */
var tags = require('../utils/tags').tags
var Notification = require('../utils/notification').Notification
var notification = new Notification()
exports.Sequence = Sequence

function Sequence () {
  this.next = async function (seq, mongo, lastValueTO, send) {
    mongo.findId('sequence', seq._id || seq, async (err, sequence) => {
      if (!err && sequence) {
        var year = '' + new Date().getFullYear()
        var month = '' + new Date().getMonth()
        if (month.length > 1) {
          month = '' + (parseInt(month) + 1)
        } else {
          month = '0' + (parseInt(month) + 1)
        }
        var seq2 = { _id: seq._id || seq }
        seq2.text = sequence.format
        if (sequence.global === '1') {
          seq2.type = 'sequence'
          if (seq2.text.indexOf('S') !== -1) {
            seq2.code = sequence.code
            seq2.text = seq2.text.replace('S', sequence.code)
          }
          seq2.text = seq2.text.replace('U-', '')
          if (sequence.annual === '1') {
            if (sequence.year !== year) {
              sequence.lastValue = 0
              sequence.year = year
            }
          }
          if (sequence.lastValue) {
            ++sequence.lastValue
            seq2.lastValue = sequence.lastValue
          } else {
            seq2.lastValue = 1
            console.log('seq=' + JSON.stringify(seq) + ', sequence:' + JSON.stringify('sequence'))
          }
          await new Promise(resolve => {
            mongo.save('sequence', sequence, (err, result) => {
              if (err) console.log(err)
              resolve(result)
            })
          })
        } else {
          seq2.type = 'unit'
          if (seq2.text.indexOf('S') !== -1) {
            seq2.code = sequence.code
            seq2.text = seq2.text.replace('S', sequence.code)
          }
          if (sequence.annual === '1') {
            if (seq.year !== year) {
              seq.lastValue = 0
              seq.year = year
            }
          }
          seq2.text = seq2.text.replace('U', seq.code)
          if (seq.lastValue) {
            seq2.lastValue = seq.lastValue + 1
          } else {
            seq2.lastValue = 1
            console.log('seq=' + JSON.stringify(seq) + ', sequence:' + JSON.stringify('sequence'))
          }
        }
        seq2.text = seq2.text.replace('YYYY', year)
        seq2.text = seq2.text.replace('MM', month)
        seq2.text = seq2.text.replace('YY', year.substring(2))
        var masq = '#'
        if (seq2.text.indexOf('0#') != -1) {
          let i = seq2.text.indexOf('#')
          while (seq2.text[--i] == '0') {
            masq = '0' + masq
          }
        }
        var masqValue = '' + seq2.lastValue
        if (masqValue.length < masq.length) {
          masqValue = masq.substr(0, masq.length - masqValue.length) + masqValue
        }
        seq2.text = seq2.text.replace(masq, masqValue)
        send(seq2)
      } else {
        send()
      }
    })
  }

  this.list = function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    /* filering documents with user of session or unit of user of session and not hidden */
    var keys = {}
    /* apply filter in parameters */
    if (req.query.filter) {
      const query = {}
      for (const name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          if (name === 'name') {
            query.name = { $regex: req.query.filter.name, $options: 'i' }
          } else if (name === 'code') {
            query.code = { $regex: req.query.filter[name], $options: 'i' }
          }
        }
      }
      keys = query
    }
    /* read limit rows from skip position */
    mongo.findN('sequence', skip, limit, keys, { }, { code: 1, active: 1 }, (err, docs) => {
      if (err || !docs) {
        send({ error: err })
      } else {
        /* hash user actors of the documents set */
        docs.forEach((doc) => {
          reply.data.push({
            id: doc._id.toString(),
            name: doc.name,
            code: doc.code,
            annual: Number(doc.annual),
            lifeCycle: doc.lifeCycle,
            format: doc.format,
            global: doc.global,
            description: doc.description ? doc.description : '',
            active: doc.active === undefined ? true : doc.active,
            scalable: doc.scalable
          })
        })

        /* if continue is true, send data */
        if (skip) {
          send(reply)
        } else {
          /* add total_count to reply */
          mongo.count('sequence', keys, (err, count) => {
            if (!err && count) {
              reply.total_count = count
            }
            send(reply)
          })
        }
      }
    })
  }

  this.save = function (req, mongo, send) {
    var doc = req.body
    doc._id = mongo.isNativeId(doc.id) ? mongo.toId(doc.id) : mongo.newId()
    doc.active = parseFloat(doc.active) * 1 !== 0
    doc.scalable = parseFloat(doc.scalable) * 1 !== 0
    doc.year = !doc.year ? '' + new Date().getFullYear() : doc.year
    doc.lastValue = !doc.lastValue ? 0 : doc.lastValue
    if (!doc.active) {
      doc.name = '<span class="inactive">' + doc.name + '</span>'
    } else {
      doc.name = doc.name.replace(/(<([^>]+)>)/g, '')
    }
    mongo.save('sequence', doc, (err) => {
      if (!err) {
        send({ id: doc._id })
        doc.id = doc._id
        notification.send(req, req.session.context.room, 'sequences', doc, null, null)
      } else {
        send()
      }
    })
  }

  this.delete = async function (req, mongo, send) {
    var doc = req.query
    var idSequence = mongo.toId(doc._id)
    var pipeline = [{ $match: { _id: idSequence } },
      {
        $lookup: {
          from: 'attached',
          let: { idSequence: '$_id' },
          pipeline: [
            {
              $match: {
                $expr: {
                  $in: ['$$idSequence', { $cond: { if: { $isArray: ['$sequence.sequence'] }, then: '$sequence.sequence', else: ['$sequence.sequence'] } }]
                },
                'sequence.sequence': { $exists: true }
              }
            },
            { $project: { _id: 1, 'sequence.sequence': 1 } }
          ],
          as: 'attacheds'
        }
      },
      {
        $lookup: {
          from: 'commitment',
          let: { idSequence: '$_id' },
          pipeline: [
            {
              $match: {
                $expr: {
                  $in: ['$$idSequence', { $cond: { if: { $isArray: ['$sequence.sequence'] }, then: '$sequence.sequence', else: ['$sequence.sequence'] } }]
                },
                'sequence.sequence': { $exists: true }
              }
            },
            { $project: { _id: 1, 'sequence.sequence': 1 } }
          ],
          as: 'commitments'
        }
      },
      {
        $lookup: {
          from: 'document',
          let: { idSequence: '$_id' },
          pipeline: [
            {
              $match: {
                $expr: {
                  $in: ['$$idSequence', { $cond: { if: { $isArray: ['$sequence.sequence'] }, then: '$sequence.sequence', else: ['$sequence.sequence'] } }]
                },
                'sequence.sequence': { $exists: true }
              }
            },
            { $project: { _id: 1, 'sequence.sequence': 1 } }
          ],
          as: 'documents'
        }
      },
      {
        $lookup: {
          from: 'evidence',
          let: { idSequence: '$_id' },
          pipeline: [
            {
              $match: {
                $expr: {
                  $in: ['$$idSequence', { $cond: { if: { $isArray: ['$sequence.sequence'] }, then: '$sequence.sequence', else: ['$sequence.sequence'] } }]
                },
                'sequence.sequence': { $exists: true }
              }
            },
            { $project: { _id: 1, 'sequence.sequence': 1 } }
          ],
          as: 'evidences'
        }
      },
      {
        $lookup: {
          from: 'note',
          let: { idSequence: '$_id' },
          pipeline: [
            {
              $match: {
                $expr: {
                  $in: ['$$idSequence', { $cond: { if: { $isArray: ['$sequence.sequence'] }, then: '$sequence.sequence', else: ['$sequence.sequence'] } }]
                },
                'sequence.sequence': { $exists: true }
              }
            },
            { $project: { _id: 1, 'sequence.sequence': 1 } }
          ],
          as: 'notes'
        }
      },
      {
        $lookup: {
          from: 'template',
          let: { idSequence: '$_id' },
          pipeline: [
            {
              $match: {
                $expr: {
                  $in: ['$$idSequence', { $cond: { if: { $isArray: ['$sequence'] }, then: '$sequence', else: ['$sequence'] } }]
                },
                sequence: { $exists: true }
              }
            },
            { $project: { _id: 1, sequence: 1 } }
          ],
          as: 'templates'
        }
      },
      {
        $lookup: {
          from: 'unit',
          let: { idSequence: '$_id' },
          pipeline: [
            {
              $match: {
                $expr: {
                  $in: ['$$idSequence', { $cond: { if: { $isArray: ['$sequences._id'] }, then: '$sequences._id', else: ['$sequences._id'] } }]
                },
                sequences: { $exists: true }
              }
            },
            { $project: { _id: 1, sequences: 1 } }
          ],
          as: 'units'
        }
      },
      { $project: { _id: 1, name: 1, code: 1, attacheds: 1, commitments: 1, documents: 1, evidences: 1, notes: 1, templates: 1, units: 1 } },
      { $sort: { _id: -1 } }
    ]
    var sequence = await new Promise(resolve => {
      mongo.aggregate('sequence', pipeline, {}, async (err, sequence) => {
        if (err) {
          resolve()
        } else {
          resolve(sequence)
        }
      })
    })
    if (sequence[0].attacheds.length ||
      sequence[0].commitments.length ||
      sequence[0].documents.length ||
      sequence[0].evidences.length ||
      sequence[0].notes.length ||
      sequence[0].templates.length ||
      sequence[0].units.length) {
      send({ msj: '_cantDeleteSequenceAreadyInUse' }) //El consecutivo no se puede borrar porque ya ha sido utilizado en el sistema
    } else {
      mongo.findId('sequence', mongo.toId(doc._id), (err, sequence) => {
        if (err) {
          send({ error: err })
        } else {
          mongo.deleteOne('sequence', { _id: mongo.toId(doc._id) }, (err) => {
            if (err) {
              req.logger.log(err)
            } else {
              req.app.routes.trash.insert(req, mongo, 'sequence', sequence, () => {
                send({ message: tags.savedChanges })
                doc.id = doc._id
                notification.send(req, req.session.context.room, 'sequences', doc, null, true)
              })
            }
          })
        }
      })
    }
  }
}
