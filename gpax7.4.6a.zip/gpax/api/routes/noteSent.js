function NoteSent () {
  this.list = async function (req, mongo, send) {
    var keys
    var scalableSequences = await new Promise(resolve => {
      mongo.find('sequence', { scalable: true }, (err, seqs) => {
        if (err) console.log(err)
        var ids = []
        if (seqs) {
          for (let s in seqs) {
            ids.push(seqs[s]._id)
          }
        }
        resolve(ids)
      })
    })
    if (req.session.context.licensedUser === false) {
      var myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits)
      var myAndDependentUnits = req.session.context.dependentUnits.concat(myUnits)
      keys = {
        $or: [
          // to or copy user without hidden
          { actors: { $elemMatch: { user: req.session.context.user, path: 'sent' } } },
          // Confidential, without sequence and in manager/assistant units
          {
            confidential: { $ne: '1' },
            $and: [
              { 'sequence.sequence': { $nin: scalableSequences } },
              { 'sequence._id': { $nin: scalableSequences } }
            ],
            actors: { $elemMatch: { unit: { $in: myUnits }, path: 'sent' } }
          },
          // if not confidential and scalable, responsible unit are in dependents units without hidden only
          {
            confidential: { $ne: '1' },
            $or: [
              { 'sequence.sequence': { $in: scalableSequences } },
              { 'sequence._id': { $in: scalableSequences } },
              { 'sequence.sequence': null, 'sequence._id': null }
            ],
            actors: { $elemMatch: { unit: { $in: myAndDependentUnits }, path: 'sent' } }
          }
        ],
        status: 'processing'
      }
    } else {
      myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits).concat(req.session.context.memberUnits)
      myAndDependentUnits = req.session.context.dependentUnits.concat(myUnits)
      keys = {
        $or: [
          // users in the note & not hidden
          { actors: { $elemMatch: { user: req.session.context.user, path: 'sent' } } },
          // not confitential and assistant in one unit of note & not hidden
          {
            confidential: { $ne: '1' },
            actors: { $elemMatch: { unit: { $in: myUnits }, path: 'sent' } }
          },
          // manager or assistant of ascending unit, not hidden, scalable, non-confidential and not in draft
          {
            confidential: { $ne: '1' },
            actors: { $elemMatch: { unit: { $in: myAndDependentUnits }, path: 'sent' } },
            $or: [
              { 'sequence.sequence': { $in: scalableSequences } },
              { 'sequence._id': { $in: scalableSequences } }
            ]
          }
        ],
        status: 'processing'
      }
    }
    if (req.query.project) {
      keys = { $and: [{ project: mongo.toId(req.query.project) }] }
    }
    if (req.query.search) {
      let text = req.query.search
      if (!text.includes('"') && (text.includes(' ') || text.includes('-') || text.includes('/') || text.includes(':'))) {
        keys.$text = { $search: '"' + text.replace(/ /g, '" "') + '"' }
      } else {
        keys.$text = { $search: text }
      }
    }
    mongo.aggregate('note', [
      { $match: keys },
      {
        $lookup: {
          from: 'attached',
          let: { find: '$_id' },
          pipeline: [
            {
              $match: {
                $expr:
                {
                  $and:
                    [
                      { $eq: ['$reference', '$$find'] }
                    ]
                }
              }
            },
            {
              $count: 'count'
            }
          ],
          as: 'aCount'
        }
      },
      { $skip: req.query.skip ? Number(req.query.skip) : 0 },
      { $limit: 50 },
      { $sort: { _id: -1 } }], {}, async (err, result) => {
      if (err) {
        console.log(err)
        send()
      } else {
        const data = []
        var users = await new Promise(resolve => {
          mongo.toHash('user', {}, { _id: 1, name: 1 }, (err, users) => {
            if (!err) {
              resolve(users)
            }
          })
        })
        for (const i in result) {
          let issue = ''
          for (const x in result[i].dates) {
            if (result[i].dates[x].type === 'issue') {
              issue = result[i].dates[x]
            }
            break
          }
          let from = ''
          for (const x in result[i].actors) {
            if (result[i].actors[x].role === 'from') {
              from = result[i].actors[x].user
            }
          }
          let tag = {}
          if (result[i].personalTag) {
            let index = result[i].personalTag.findIndex(x =>{
              return x.user.toString() === req.session.context.user.toString()
            })
            if (index !== -1) {
              tag = await req.app.routes.note.findPersonalTag(result[i].personalTag[index].tag, mongo) || ''
            }
          }
          const tagColor = tag.color || ''
          const tagName = tag.value || ''
          req.app.routes.note.getTemplateList(data, result[i], users, tagColor, tagName, issue, from, req)
        }
        send(data)
      }
    })
  }
}
exports.NoteSent = NoteSent