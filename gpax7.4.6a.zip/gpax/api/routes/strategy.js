var tags = require('../utils/tags').tags
var dateformat = require('dateformat')
var Notification = require('../utils/notification').Notification
var notification = new Notification()
/* exported */
exports.Strategy = Strategy

function Strategy () {
  this.detailSave = function (req, mongo, next) {
    var doc = req.body
    doc._id = doc.id
    delete doc.id

    try { doc.objectives = JSON.parse(doc.objectives) } catch (s) { }
    try {
      doc.period = JSON.parse(doc.period)
      doc.period.start = dateformat(new Date(doc.period.start), 'yyyy/mm/dd')
      doc.period.end = dateformat(new Date(doc.period.end), 'yyyy/mm/dd')
    } catch (e) { }
    try { doc.workingDays = 1 * doc.workDays } catch (e) { }
    if (doc.status !== tags.processing) {
      doc.status = tags.draft
    }
    doc.period.start = dateformat(new Date(doc.period.start), 'yyyy/mm/dd')
    doc.period.end = dateformat(new Date(doc.period.end), 'yyyy/mm/dd')
    mongo.save('strategy', doc, (err, result) => {
      var reply
      if (err) {
        reply = { error: tags.savingProblema }
      } else {
        reply = { message: tags.savedChanges }
      }
      next(reply)
      doc.id = doc._id
      doc.startDate = doc.period.start ? dateformat(new Date(doc.period.start), 'yyyy/mm/dd') : ''
      doc.endDate = doc.period.end ? dateformat(new Date(doc.period.end), 'yyyy/mm/dd') : ''
      notification.send(req, req.session.context.room, 'dtstrategy', doc, null, null)
    })
  }

  this.objectives = async function (req, mongo, send) {
    mongo.findId('strategy', req.query._id, { objectives: 1, plans: 1 }, async (err, strategy) => {
      if (err) {
        req.statusCode = 404
        send()
      } else if (!strategy || !strategy.objectives || strategy.objectives.length === 0) {
        send([])
      } else {
        // Build the tree from the flat table
        var hash = {}
        if (req.query.filter && req.query.filter.objective) {
          strategy.objectives = strategy.objectives.filter(element => {
            return element.name.toLowerCase().includes(req.query.filter.objective.toLowerCase())
          })
        }
        if (req.query.filter && req.query.filter.status) {
          strategy.objectives = strategy.objectives.filter(element => {
            return element.status.includes(req.query.filter.status)
          })
        }
        for (const i in strategy.objectives) {
          const obj = strategy.objectives[i]
          hash[obj.id] = obj
        }
        for (const i in strategy.objectives) {
          var totalProgress = 0
          var progressObjective = 0

          for (const p in strategy.plans) {
            var resultadoPlan = await new Promise(resolve => {
              mongo.findId('plan', mongo.toId(strategy.plans[p].toString()), { goals: 1 }, async (err, plan) => {
                if (err || !plan) {
                  resolve(false)
                } else {
                  resolve(plan)
                }
              })
            })
            var goalsSum = 0
            for (const g in resultadoPlan.goals) {
              if (strategy.objectives[i].id && (resultadoPlan.goals[g].objective.toString() === strategy.objectives[i].id.toString())) {
                goalsSum++
                if (resultadoPlan.goals[g].progress) {
                  strategy.objectives[i].progress += parseFloat(resultadoPlan.goals[g].progress.toString())
                } else {
                  if (resultadoPlan.goals[g].projects && resultadoPlan.goals[g].projects.length > 0) {
                    for (const p in resultadoPlan.goals[g].projects) {
                      var resultadoProjects = await new Promise(resolve => {
                        mongo.findId('project', mongo.toId(resultadoPlan.goals[g].projects[p]), async (err, project) => {
                          if (err || !project) {
                            resolve(false)
                          } else {
                            resolve(project)
                          }
                        })
                      })
                      if (resultadoProjects.progress) {
                        progressObjective += parseFloat(resultadoProjects.progress.toString())
                      } else {
                        if (resultadoProjects.duration) {
                          let total = 0
                          var tasks = await new Promise(resolve => {
                            mongo.find('task', {project: mongo.toId(resultadoPlan.goals[g].projects[p])}, async (err, tasks) => {
                              if (err) {
                                resolve(false)
                              } else {
                                resolve(tasks)
                              }
                            })
                          })
                          for (const d in tasks) {
                            if (tasks[d].type === 'task' && ['done', 'reviewed', 'completed'].includes(tasks[d].status)) {
                              total += parseFloat(tasks[d].duration)
                            }
                            if (tasks[d].type === 'task' && tasks[d].status === 'suspended') {
                              resultadoProjects.duration = parseFloat(resultadoProjects.duration) - parseFloat(tasks[d].duration)
                            }
                          }
                          resultadoProjects.realDuration = total
                          progressObjective += total / parseFloat(resultadoProjects.duration) * 100
                        }
                      }
                    }
                  }
                  totalProgress = resultadoPlan.goals[g].projects.length > 0 ? progressObjective / resultadoPlan.goals[g].projects.length : 0
                  strategy.objectives[i].progress = totalProgress
                }
              }
            }

            const totalProgressObjective = goalsSum > 0 ? strategy.objectives[i].progress / goalsSum : 0
            strategy.objectives[i].progress = totalProgressObjective
          }

          if (strategy.objectives[i].parent) {
            var parent = hash[strategy.objectives[i].parent]
            if (parent) {
              if (!parent.data) {
                parent.data = [strategy.objectives[i]]
              } else {
                parent.data.push(strategy.objectives[i])
              }
            }
          }
        }

        var tree = []
        for (const i in hash) {
          if (!hash[i].parent) {
            tree.push(hash[i])
          }
        }
        sortBySequence(tree)
        send(tree)
      }
    })
    function sortBySequence (array) {
      array.sort(function (a, b) {
        return (a.sequence > b.sequence) ? 1 : (a.sequence < b.sequence ? -1 : 0)
      })
      for (const i in array) {
        if (array[i].data) {
          sortBySequence(array[i].data)
        }
      }
    }
  }

  this.objectiveSave = function (req, mongo, send) {
    var isNew = false
    var _id = req.body._id
    var objective = req.body.objective
    mongo.findId('strategy', _id, (err, doc) => {
      if (err) {
        send(err)
      } if (!doc) {
        send({ error: 'save the strategy first' })
      } else {
        if (doc.objectives) {
          var b= objective && objective.id? objective.id.toString():'no'
          var index = doc.objectives.findIndex((x) => {
            var a = x && x.id ? x.id.toString() : ''
            return a === b
          })
          if (index === -1) {
            isNew = true
          }
        } else {
          isNew = true
        }
        if (objective.$parent) {
          objective.parent = objective.$parent
        }
        // Delete all $... fields of the objective
        for (const field in objective) {
          if (field.indexOf('$') !== -1) {
            delete objective[field]
          }
        }
        if (isNew) {
          mongo.update('strategy', { _id: _id }, { $push: { objectives: objective } }, (err, result) => {
            if (err || !result) {
              req.statusCode = 404
              send()
            } else {
              send(objective)
              notification.send(req, req.session.context.room, 'objectives.' + req.body._id.toString(), objective, null, null)
            }
          })
        } else {
          mongo.update('strategy', { _id: _id, 'objectives.id': objective.id }, { $set: { 'objectives.$': objective } }, (err, result) => {
            if (err || !result) {
              req.statusCode = 404
              send()
            } else {
              send(objective)
              notification.send(req, req.session.context.room, 'objectives.' + req.body._id.toString(), objective, null, null)
            }
          })
        }
      }
    })
  }

  this.objectiveDelete = function (req, mongo, send) {
    mongo.findId('strategy', req.query._id, { objectives: 1 }, (err, strategy) => {
      if (err || !strategy) {
        req.statusCode = 404
        send()
      } else {
        mongo.find('plan', { strategy: strategy._id }, {}, {}, (err, plan) => {
          if (err) throw err
          var exists = false
          for (const p in plan) {
            for (const g in plan[p].goals) {
              if (plan[p].goals[g].objective.toString() === req.query.objectives.toString()) {
                exists = true
                break
              }
            }
          }
          if (!exists) {
            var objetiveDeleted = ''
            for (const i in strategy.objectives) {
              var objectives = strategy.objectives[i]
              if (!objectives.id || !objectives.status) {
                objetiveDeleted = strategy.objectives[i]
                strategy.objectives.splice(i, 1)
              }
              if (objectives.id && objectives.id.toString() === req.query.objectives) {
                objetiveDeleted = strategy.objectives[i]
                strategy.objectives.splice(i, 1)
                break
              }
            }
            mongo.save('strategy', strategy, (err, result) => {
              if (err || !result) {
                req.statusCode = 404
                send()
              } else {
                objetiveDeleted.strategy = strategy._id
                req.app.routes.trash.insert(req, mongo, 'strategy', objetiveDeleted, () => {
                  send({ saved: true })
                  notification.send(req, req.session.context.room, 'objectives.' + strategy._id.toString(), { id: req.query.objectives }, null, true)
                })
              }
            })
          } else {
            send({ saved: false })
          }
        })
      }
    })
  }

  this.objectiveUsed = function (req, mongo, send) {
    mongo.find('plan', { 'goals.objective': mongo.toId(req.body._id) }, { _id: 1 }, (err, strategy) => {
      if (err) {
        req.statusCode = 404
        send()
      } else {
        if (strategy.length > 0) {
          send({ exists: true })
        } else {
          send({ exists: false })
        }
      }
    })
  }

  this.list = function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    var keys = {}
    if (req.query.filter) {
      const query = {}
      for (const name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          if (name === 'name') {
            query.$text = {
              $search: req.query.filter.name
            }
          } else {
            query[name] = req.query.filter[name].indexOf(',') !== -1 ? { $in: req.query.filter[name].split(',') } : new RegExp(req.query.filter[name].replace(/ /g, '.*'), 'i')
          }
        }
      }
      keys = query
    }
    mongo.findN('strategy', skip, limit, keys, { _id: 1, name: 1, period: 1, status: 1 }, { 'period.start': -1 }, (err, strategies) => {
      if (!err && strategies) {
        for (const i in strategies) {
          const strategy = strategies[i]
          if (strategy.period) {
            strategy.startDate = strategy.period.start ? dateformat(new Date(strategy.period.start), 'yyyy/mm/dd') : ''
            strategy.endDate = strategy.period.end ? dateformat(new Date(strategy.period.end), 'yyyy/mm/dd') : ''
          }
          strategy.id = strategy._id
          // strategy.progress = 45;
          strategy.statusName = strategy.status
          reply.data.push(strategy)
        }
        if (skip) {
          send(reply)
        } else {
          mongo.count('strategy', keys, (err, count) => {
            if (!err && count) {
              reply.total_count = count
            }
            send(reply.data)
          })
        }
      }
    })
  }

  this.get = function (req, mongo, send) {
    mongo.findId('strategy', req.query._id, {}, (err, strategy) => {
      if (err) throw err
      if (!strategy) {
        send({ id: req.query._id })
      } else {
        strategy.id = strategy._id
        if (strategy.period && strategy.period.start && strategy.period.end) {
          strategy.period.start = new Date(strategy.period.start)
          strategy.period.end = new Date(strategy.period.end)
          strategy.period.start = strategy.period.start.getFullYear() + '-' + (strategy.period.start.getMonth() + 1) + '-' + strategy.period.start.getDate()
          strategy.period.end = strategy.period.end.getFullYear() + '-' + (strategy.period.end.getMonth() + 1) + '-' + strategy.period.end.getDate()
        }
        send(strategy)
      }
    })
  }

  this.savePlan = function (req, mongo, send) {
    mongo.findId('strategy', req.body._id, {}, (err, strategy) => {
      if (err) throw err
      mongo.findId('plan', req.body.idPlan, {}, (err, plan) => {
        if (err) throw err
        if (!strategy) {
          var doc = {
            _id: mongo.newId(),
            plans: [req.body.idPlan]
          }

          mongo.save('strategy', doc, (err, result) => {
            var reply
            if (err) {
              reply = { error: tags.savingProblema }
            } else {
              reply = { message: tags.savedChanges }
            }
            send(reply)
          })
        } else {
          if (!strategy.plans) { strategy.plans = [] }
          var index = strategy.plans.findIndex((x) => {
            return x.toString() === req.body.idPlan
          })
          if (index === -1) { strategy.plans.push(req.body.idPlan) }
          mongo.save('strategy', strategy, (err, result) => {
            var reply
            if (err) {
              reply = { error: tags.savingProblema }
            } else {
              reply = { message: tags.savedChanges }
            }
            send(reply)
          })
        }
      })
    })
  }

  this.delete = function (req, mongo, send) {
    if (parseInt(req.query.objs) > 0 || parseInt(req.query.plans) > 0) {
      send({ deleted: false })
    } else {
      mongo.findId('strategy', mongo.toId(req.query._id), (err, strategy) => {
        if (err) {
          send({ error: err })
        } else {
          mongo.deleteOne('strategy', { _id: mongo.toId(req.query._id) }, (err, result) => {
            if (err) {
              req.logger.log(err)
            } else {
              req.app.routes.trash.insert(req, mongo, 'strategy', strategy, () => {
                send({ deleted: true })
                var doc = {}
                doc.id = req.query._id
                notification.send(req, req.session.context.room, 'dtstrategy', doc, null, true)
              })
            }
          })
        }
      })
    }
  }
}
