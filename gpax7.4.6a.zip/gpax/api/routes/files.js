var tags = require('../utils/tags').tags
exports.Files = Files

function Files () {
  this.get = function (req, mongo, send) {
    var doc = {}
    var form = function () {
      var userName = ''
      var idUser
      if (doc.user) { idUser = doc.user } else { idUser = req.session._id }

      mongo.toHash('user', { _id: { $in: [idUser] } }, { _id: 1, name: 1 }, (err, user) => {
        if (err) {
          send({ error: err })
        } else {
          userName = user[idUser.toString()].name
          mongo.docs('product', { _id: 1, name: 1 }, {}, (err, products) => {
            if (err) {
              req.logger.log('Error reading products:' + err)
            }
            var prodOpts = []
            for (let i = 0; i < products.length; ++i) {
              prodOpts.push({ text: products[i].name, value: products[i]._id.toString() })
              if (doc.product && doc.product.equals(products[i]._id)) {
                prodOpts[i].selected = true
              }
            }

            var dialog = {
              id: 'filesGet' + doc._id.toString(),
              width: req.session.screen.lifeW,
              height: req.session.screen.lifeH,
              center: true,
              modal: false,
              caption: 'files',
              park: false,
              resize: false
            }

            dialog.form = {
              action: 'files.save',
              items: []
            }

            dialog.form.items.push({ type: 'settings', labelAlign: 'top', position: 'label-right', offsetTop: 8 })
            dialog.form.items.push({ type: 'hidden', name: '_id', value: doc._id })
            dialog.form.items.push({
              type: 'fieldset',
              list: [
                { type: 'newcolumn', offset: 10 },
                { type: 'input', name: tags.name, value: doc.name, note: { text: 'Asunto' }, width: 250, validate: 'NotEmpty' },
                { type: 'input', name: 'version', value: doc.version, note: { text: 'Version' }, width: 250, validate: 'NotEmpty' },
                { type: 'combo', name: 'product', value: doc.product, note: { text: 'Producto y versión' }, options: prodOpts },
                { type: 'label', label: userName },
                { type: 'hidden', name: tags.user, value: idUser }
              ]
            })
            if (!doc.dateTime) {
              dialog.form.items.push({ type: 'newcolumn', offset: 33 }, { type: 'calendar', name: 'dateTime', dateFormat: '%Y-%m-%d %H:%i:%s', value: tags.util.date2str(new Date(), 'yyyy-mm-dd HH:MM:s', tags), enableTime: true, hidden: true, note: { text: 'Fecha' } })
            } else {
              dialog.form.items.push({ type: 'newcolumn', offset: 33 }, { type: 'label', label: tags.util.date2str(doc.dateTime, 'yyyy-mm-dd', tags) })
            }
            dialog.form.items.push({ type: 'redactor', config: 'full', name: tags.description, value: doc.description, width: req.session.screen.lifeW - 40, height: req.session.screen.lifeH - 80 })

            dialog.form.toolbar = {
              icons_path: 'img/',
              items: [
                { type: 'button', id: 'send', text: tags.save, title: tags.savedChanges, img: 'check.png' }
              ]
            }

            send({ dialog })
          })
        }
      })
    }
    if (req.query._id) {
      mongo.findId('file', req.query._id, (err, user) => {
        if (!err) {
          doc = user
          form()
        } else {
          send()
        }
      })
    } else {
      doc = { _id: mongo.newId() }
      form()
    }
  }

  this.save = function (req, mongo, send) {
    var doc = req.body
    mongo.save('file', doc, (err, result) => {
      if (err) {
        send({ error: tags.savingProblema })
      } else {
        send({ message: tags.savedChanges })
        req.broadcast.formSaved('files', this.getDVItem(doc))
      }
    })
  }

  this.list = function (req, mongo, send) {
    if (!req.query.flow) {
      var dialog = {
        id: 'filesList',
        width: req.session.screen.lifeW,
        height: req.session.screen.lifeH,
        center: true,
        modal: false,
        caption: 'files',
        park: false,
        resize: false
      }

      dialog.toolbar = {
        icons_path: 'img/',
        items: [
          { type: 'text', text: tags.filter, class: 'search' },
          { type: 'buttonInput', id: tags.search, width: 200, userdata: { path: 'files.list?flow=1' } },
          { type: 'text', id: tags.search + 'Count', text: '...' },
          { type: 'button', id: tags.new, text: tags.new, title: 'New File', userdata: { cmd: { url: { ref: 'files.get' } } }, width: 60 }
        ]
      }

      dialog.dataView = {
        autowidth: 1,
        type: {
          template: "<div class='cite'>" +
            '<span >' +
            '#name#<br/>' +
            '#version#' +
            '</span>' +
            '</div>',
          height: 50
        },
        load: 'files.list?flow=1',
        click: 'files.get?_id=#id#',
        drag: true,
        canRemove: false
      }
      send({ dialog })
    } else {
      var keys = {}
      if (req.query.search) {
        var txt = new RegExp(req.query.search.replace(/ /g, '.*'), 'i')
        keys = { $or: [{ name: txt }, { version: txt }] }
      }
      if (req.query.posStart) {
        this.sendData(mongo, {}, keys, Number(req.query.posStart), Number(req.query.count), send)
      } else {
        mongo.count('file', keys, (err, count) => {
          if (err) {
            send({ error: err })
          } else {
            if (count > 50) {
              this.sendData(mongo, { total_count: count }, keys, 0, 50, send)
            } else {
              this.sendData(mongo, {}, keys, 0, count, send)
            }
          }
        })
      }
    }
  }

  this.sendData = function (mongo, body, keys, skip, limit, send) {
    mongo.findN('file', skip, limit, keys, { _id: 1, name: 1, version: 1 }, { name: 1 }, (err, docs) => {
      if (err) {
        send({ error: err })
      } else {
        body.data = []
        for (const i in docs) {
          var doc = docs[i]
          body.data.push(this.getDVItem(doc))
        }
        body.pos = skip
        send(body)
      }
    })
  }

  this.getDVItem = function (doc) {
    return {
      id: doc._id.toString(),
      name: doc.name,
      version: doc.version
    }
  }
}
