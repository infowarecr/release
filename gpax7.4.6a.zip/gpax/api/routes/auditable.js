/* exported */
exports.Auditable = Auditable
var Notification = require('../utils/notification').Notification
var notification = new Notification()
var parseHtml = require('node-html-parser')

function Auditable () {
  /** get Auditable */
  this.get = function (req, mongo, send) {
    if (!req.query._id || (req.query._id && req.query._id.length !== 24)) {
      send({ _id: mongo.newId() })
    } else {
      mongo.aggregate('auditable', [{ $match: { _id: mongo.toId(req.query._id) } },
        { $lookup: { from: 'settings', as: 'controls', pipeline: [{ $match: { $expr: { $eq: ['$_id', 'settings'] } } }] } },
        { $addFields: { controls: { $arrayElemAt: ['$controls.externalControls', 0] } } }], {}, (err, doc) => {
        if (err) {
          send({ error: err })
        } else {
          if (doc && doc[0]) {
            doc[0].duration = ''
            var root = parseHtml.parse('<div>' + doc[0].name + '</div>')
            doc[0].name = root.text
            send(doc[0])
          } else {
            send()
          }
        }
      })
    }
  }
  /** list auditables */
  this.list = function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    var keys = { $or: [{ unit: { $exists: 0 } }, { unit: '' }, { unit: { $in: req.session.context.memberUnits } }, { unit: { $in: req.session.context.dependentUnits } }] }
    if (req.query.byRisk) { keys = { $and: [keys, { type: 'byRisk' }] } }
    if (req.query.filter) {
      const query = {}
      for (const name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          if (name === 'name') {
            query.name = new RegExp(req.query.filter.name, 'i')
          } else if (name === 'type') {
            query.type = req.query.filter.type
          } else if (name === 'tag') {
            let tags = req.query.filter.tag.split(',')
            let or = []
            for (let t in tags) {
              or.push({ tag: new RegExp(tags[t], 'i') })
              tags[t] = mongo.toId(tags[t])
            }
            or.push({ tag: { $in: tags } })
            query.$or = or
          }
          else if (name === 'department') {
            query.unit = mongo.toId(req.query.filter.department)
          }
          else {
            query[name] = req.query.filter[name].indexOf(',') !== -1 ? { $in: req.query.filter[name].split(',') } : new RegExp(req.query.filter[name].replace(/ /g, '.*'), 'i')
          }
        }
      }
      keys = { $and: [keys, query] }
    }
    var sort
    if (req.query.sort) {
      for (const name in req.query.sort) {
        if (req.query.sort[name].length > 0) {
          if (name === 'type') {
            sort = req.query.sort[name] === 'asc' ? { type: 1 } : { type: -1 }
          }
          if (name === 'department') {
            sort = req.query.sort[name] === 'asc' ? { 'tunit.name': 1 } : { 'tunit.name': -1 }
          }
          if (name === 'name') {
            sort = req.query.sort[name] === 'asc' ? { name: 1 } : { name: -1 }
          }
          if (name === 'RR') {
            sort = req.query.sort[name] === 'asc' ? { 'RR': 1 } : { 'RR': -1 }
          }
          if (name === 'RI') {
            sort = req.query.sort[name] === 'asc' ? { 'rRI': 1 } : { 'rRI': -1 }
          }
        }
      }
    }
    var pipeline = [
      { $match: keys },

      {
        $lookup: {
          from: 'unit',
          let: { find: '$unit' },
          pipeline: [
            {
              $match: {
                $expr: { $and: [{ $eq: ['$_id', '$$find'] }] }
              }
            }
          ],
          as: 'tunit'
        }
      },
      { $unwind: { path: '$tunit', preserveNullAndEmptyArrays: true } },
      { $addFields: { rRI: { $ifNull: ['$result', '$RI'] } } },
      { $sort: sort || { _id: -1 } },
      { $skip: skip },
      { $limit: limit }
    ]
    mongo.aggregate('auditable', pipeline, {}, (err, auditables) => {
      if (err) {
        send({ error: err })
      } else {
        mongo.findId('settings', 'riskScale', {}, { _id: -1 }, (err, assessment) => {
          if (err) {
            send({ error: err })
          } else {
            var riskRanges = assessment && assessment.riskRanges ? assessment.riskRanges : []
            mongo.find('params', { name: 'projectTag' }, { _id: 1, name: 1, options: 1 }, async (er, tags) => {
              if (err) {
                send({ error: err })
              } else {
                for (const i in auditables) {
                  var item = this.getTags(auditables[i], tags, mongo)
                  auditables[i].$cellCss = {}
                  auditables[i].id = auditables[i]._id
                  auditables[i].tag = item.tag
                  auditables[i].tagcolor = item.tagcolor
                  auditables[i].tagname = item.tagname
                  auditables[i].RI = auditables[i].result || auditables[i].RI
                  auditables[i].unit = auditables[i].tunit ? auditables[i].tunit.name : ''
                  if (auditables[i].RI && riskRanges) {
                    for (const l in riskRanges) {
                      if (parseFloat(auditables[i].RI) >= riskRanges[l].from && parseFloat(auditables[i].RI) <= riskRanges[l].to) {
                        auditables[i].$cellCss.RI = { 'background-color': riskRanges[l].color, color: riskRanges[l].textColor }
                        break
                      }
                    }
                  }
                  if (auditables[i].RR && riskRanges) {
                    for (const l in riskRanges) {
                      if (parseFloat(auditables[i].RR) >= riskRanges[l].from && parseFloat(auditables[i].RR) <= riskRanges[l].to) {
                        auditables[i].$cellCss.RR = { 'background-color': riskRanges[l].color, color: riskRanges[l].textColor }
                        break
                      }
                    }
                  }
                  /** */
                  if (auditables[i].processes && req.query.byRisk) {
                    var pcss = []
                    if (typeof auditables[i].processes === 'string') {
                      var res = auditables[i].processes.split(',')
                      for (const r in res) {
                        pcss.push(mongo.toId(res[r]))
                      }
                    } else {
                      pcss.push(auditables[i].processes)
                    }
                    var resultado = await new Promise(resolve => {
                      mongo.find('process', { _id: { $in: pcss } }, {}, {}, (err, processes) => {
                        if (err || !processes) { resolve(0) } else if (processes.length > 0) {
                          var resultRisk = 0
                          var resultResidualRisk = 0
                          for (const p in processes) {
                            if (processes[p].RI && typeof processes[p].RI !== 'object') { resultRisk += parseFloat(processes[p].RI) }
                            if (processes[p].RR && typeof processes[p].RR !== 'object') { resultResidualRisk += parseFloat(processes[p].RR) }
                          }
                          resultRisk = resultRisk / processes.length
                          resultResidualRisk = resultResidualRisk / processes.length
                          resolve([resultRisk, resultResidualRisk])
                        } else { resolve(0) }
                      })
                    })
                    if (resultado !== 0) {
                      auditables[i].resultRisk = resultado[0]
                      auditables[i].resultResidualRisk = resultado[1]
                    } else {
                      auditables[i].resultRisk = 0
                      auditables[i].resultResidualRisk = 0
                    }
                  }
                }
                reply.data = auditables
                if (skip) {
                  send(reply)
                } else {
                  mongo.aggregate('auditable', [
                    { $match: keys },
                    {
                      $lookup: {
                        from: 'unit',
                        let: { find: '$unit' },
                        pipeline: [
                          {
                            $match: {
                              $expr: { $and: [{ $eq: ['$_id', '$$find'] }] }
                            }
                          }
                        ],
                        as: 'tunit'
                      }
                    },
                    { $unwind: { path: '$tunit', preserveNullAndEmptyArrays: true } },
                    { $group: { _id: null, Count: { $sum: 1 } } }, { $project: { _id: 0 } },
                  ], {}, (err, count) => {
                    if (!err && count[0]) {
                      reply.total_count = count[0].Count
                    }
                    send(reply)
                  })
                }
              }
            })

          }
        })
      }
    })
  }
  this.toPlan = async function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    var keys
    if (req.query._id) {
      await new Promise(resolve => {
        mongo.findId('plan', req.query._id, (err, plan) => {
          if (err) {
            return err
          } else {
            if (plan && plan.unit && plan.unit !== '') {
              keys = {
                $and: [
                  { duration: { $exists: 1 } },
                  { duration: { $ne: 0 } },
                  { duration: { $ne: '0' } }
                ],
                $or: [
                  { unit: { $exists: 0 } },
                  { unit: '' },
                  { unit: plan.unit }
                ]
              }
            } else {
              keys = {
                $and: [
                  { duration: { $exists: 1 } },
                  { duration: { $ne: 0 } },
                  { duration: { $ne: '0' } }
                ],
                $or: [
                  { unit: { $exists: 0 } },
                  { unit: '' },
                  { unit: { $in: req.session.context.managerUnits } },
                  { unit: { $in: req.session.context.assistantUnits } }
                ]
              }
            }
            resolve()
          }
        })
      })
    } else {
      var units = req.session.context.memberUnits.concat(req.session.context.dependentUnits)
      keys = {
        $and: [
          { duration: { $exists: 1 } },
          { duration: { $ne: 0 } },
          { duration: { $ne: '0' } }
        ],
        $or: [
          { unit: { $exists: 0 } },
          { unit: '' },
          { unit: { $in: units } }
        ]
      }
    }
    if (req.query.byRisk) { keys = { $and: [keys, { type: 'byRisk' }] } }
    if (req.query.filter) {
      const query = {}
      for (const name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          if (name === 'name') {
            query.name = new RegExp(req.query.filter.name, 'i')
          } else if (name === 'type') {
            query.type = req.query.filter.type
          } else if (name === 'tag') {
            if (req.query.filter.tag === 'onlyEmpty') {
              query.$or = [ { tag: { $exists: 0 } }, { tag: '' } ]
            } else {
              query.$or = [{ tag: new RegExp(req.query.filter.tag, 'i') }, { tag: mongo.toId(req.query.filter.tag) } ]
            }
          } else { query[name] = req.query.filter[name].indexOf(',') !== -1 ? { $in: req.query.filter[name].split(',') } : new RegExp(req.query.filter[name].replace(/ /g, '.*'), 'i') }
        }
      }
      keys = { $and: [keys, query] }
    }
    mongo.findN('auditable', skip, limit, keys, {}, {}, (err, auditables) => {
      if (err) {
        send({ error: err })
      } else {
        mongo.findId('settings', 'riskScale', (err, assessment) => {
          if (err) {
            send({ error: err })
          } else {
            var riskRanges = assessment && assessment.riskRanges ? assessment.riskRanges : []
            mongo.find('params', { name: 'projectTag' }, { _id: 1, name: 1, options: 1 }, async (er, tags) => {
              for (const i in auditables) {
                var item = this.getTags(auditables[i], tags, mongo)
                auditables[i].$cellCss = {}
                auditables[i].id = auditables[i]._id
                auditables[i].tag = item.tag
                auditables[i].tagcolor = item.tagcolor
                auditables[i].tagname = item.tagname
                auditables[i].RI = auditables[i].result || auditables[i].RI
                if (auditables[i].name && auditables[i].name.length >= 70) {
                  auditables[i].name2 = auditables[i].name.substring(0, 67) + '...'
                }
                if (auditables[i].RI && riskRanges) {
                  for (const l in riskRanges) {
                    if (parseInt(auditables[i].RI) >= riskRanges[l].from && parseInt(auditables[i].RI) <= riskRanges[l].to) {
                      auditables[i].$cellCss.RI = { 'background-color': riskRanges[l].color, color: riskRanges[l].textColor }
                      auditables[i].color = riskRanges[l].color
                      auditables[i].textColor = riskRanges[l].textColor
                      break
                    }
                  }
                }
                /** */
                if (auditables[i].processes && req.query.filter && req.query.filter.type === 'byRisk') {
                  var pcss = []
                  if (typeof auditables[i].processes === 'string') {
                    var res = auditables[i].processes.split(',')
                    for (const r in res) {
                      pcss.push(mongo.toId(res[r]))
                    }
                  } else {
                    pcss.push(auditables[i].processes)
                  }
                  var resultado = await new Promise(resolve => {
                    mongo.find('process', { _id: { $in: pcss } }, {}, {}, (err, processes) => {
                      if (err || !processes) { resolve(0) } else if (processes.length > 0) {
                        var resultRisk = 0
                        var resultResidualRisk = 0
                        for (const p in processes) {
                          if (processes[p].RI && typeof processes[p].RI !== 'object') { resultRisk += parseFloat(processes[p].RI) }
                          if (processes[p].RR && typeof processes[p].RR !== 'object') { resultResidualRisk += parseFloat(processes[p].RR) }
                        }
                        resultRisk = resultRisk / processes.length
                        resultResidualRisk = resultResidualRisk / processes.length
                        resolve([resultRisk, resultResidualRisk])
                      } else { resolve(0) }
                    })
                  })
                  if (resultado !== 0) {
                    auditables[i].resultRisk = resultado[0]
                    auditables[i].resultResidualRisk = resultado[1]
                  } else {
                    auditables[i].resultRisk = 0
                    auditables[i].resultResidualRisk = 0
                  }
                }
              }
              reply.data = auditables
              if (skip) {
                send(reply)
              } else {
                mongo.count('auditable', keys, (err, count) => {
                  if (!err && count) {
                    reply.total_count = count
                  }
                  send(reply)
                })
              }
            })
          }
        })
      }
    })
  }
  this.getTags = function (doc, tags, mongo) {
    var tagId = []
    if (typeof doc.tag !== 'object') {
      var tagsIds = doc.tag.split(',')
      for (const x in tagsIds) {
        tagsIds[x] = mongo.toId(tagsIds[x])
      }
      doc.tag = tagsIds
      for (const j in doc.tag) {
        tagId.push(doc.tag[j])
      }
    } else {
      tagId.push(doc.tag)
    }
    // Tags
    var usedTags = []
    if (tags.length) {
      for (let t = 0; t < tags[0].options.length; t++) {
        for (let o = 0; o < tagId.length; o++) {
          if (tags[0].options[t].id.toString() === tagId[o].toString()) {
            usedTags.push(tags[0].options[t])
          }
        }
      }
    }
    var tagcolor = []
    var tagname = []
    for (const i in usedTags) {
      tagcolor.push(usedTags[i].color)
      tagname.push(usedTags[i].value)
    }

    var row = {
      tag: doc.tag,
      tagcolor: tagcolor,
      tagname: tagname
    }

    return row
  }
  /** save auditable */
  this.save = async function (req, mongo, send) {
    var doc = req.body
    if(!doc._id) {
      doc._id=mongo.newId()
    }
    var deleteDesc = false
    var deleteCopyFrom = false
    if (doc.copyFrom === '') {
      delete doc.copyFrom
    } else if (doc.copyFrom !== doc._id) {
      deleteDesc = true //para que no guarde la descripción del template seleccionado
    } else if (doc.copyFrom === doc._id) { // cuando ya tenia un copyFrom pero ya no se requiere más
      deleteCopyFrom = true
    }
    var processes = []
    processes = doc.processes.length >= 24 ? doc.processes.split(',') : []
    doc.processes = processes
    if (doc.unit.toString().length < 24) {
      doc.unit = ''
    }
    deleteDesc ? delete doc.description : ''
    deleteCopyFrom ? doc.copyFrom = '' : ''
    mongo.save('auditable', doc, (err) => {
      if (err) {
        send({ error: err })
      } else {
        send()
        mongo.find('params', { name: 'projectTag' }, { _id: 1, name: 1, options: 1 }, async (er, tags) => {
          var item = this.getTags(doc, tags, mongo)
          doc.id = doc._id
          doc.tag = item.tag
          doc.tagcolor = item.tagcolor
          doc.tagname = item.tagname
          doc.unit = await new Promise(resolve => {
            mongo.findId('unit', doc.unit ? doc.unit : '', (err, result) => {
              if (err) throw new Error(err)
              if (result) resolve(result.name)
              else resolve('')
            })
          })
          notification.send(req, req.session.context.room, 'dt_auditables', doc, null, null)
        })
      }
    })
  }
  /** delete auditable */
  this.delete = async function (req, mongo, send) {
    var doc = req.query
    var idAuditable = mongo.toId(doc._id)
    var pipeline = [
      { $match: { _id: idAuditable } },
      {
        $lookup: {

          from: 'project',

          let: { idAuditable: '$_id' },

          pipeline: [{

            $match: {
              $expr:
              {
                $in: ['$$idAuditable', { $cond: { if: { $isArray: ['$auditable'] }, then: '$auditable', else: ['$auditable'] } }]

              },
              auditable: { $exists: true }
            }

          }, { $project: { _id: 1, auditable: 1 } }

          ],

          as: 'projects'
        }
      },
      {
        $lookup: {

          from: 'auditableAssessment',

          let: { idAuditable: '$_id' },

          pipeline: [{

            $match: {
              $expr:
              {
                $in: ['$$idAuditable', { $cond: { if: { $isArray: ['$auditables'] }, then: '$auditables', else: ['$auditables'] } }]

              },
              auditables: { $exists: true }
            }

          }, { $project: { _id: 1, auditables: 1 } }

          ],

          as: 'auditableAssessments'
        }
      },
      { $project: { _id: 1, name: 1, projects: 1, auditableAssessments: 1 } },

      { $sort: { _id: -1 } }
    ]

    var auditable = await new Promise(resolve => {
      mongo.aggregate('auditable', pipeline, {}, async (err, auditable) => {
        if (err) {
          resolve()
        } else {
          resolve(auditable)
        }
      })
    })
    if (auditable && (auditable[0] && auditable[0].projects && auditable[0].projects.length)
      || (auditable[0] && auditable[0].auditableAssessments && auditable[0].auditableAssessments.length)) {
      send({ msj: '_cantDeleteAuditableAlreadyInUse' }) //El elemento auditable no se puede borrar porque ya ha sido utilizado en el sistema
    } else if (auditable && auditable[0]) {
      mongo.findId('auditable', mongo.toId(doc._id), (err, auditable) => {
        if (err) {
          send({ error: err })
        } else {
          mongo.deleteOne('auditable', { _id: mongo.toId(doc._id) }, (err) => {
            if (err) {
              req.logger.log(err)
            } else {
              req.app.routes.trash.insert(req, mongo, 'auditable', auditable, () => {
                send()
                doc.id = doc._id
                notification.send(req, req.session.context.room, 'dt_auditables', doc, null, true)
              })
            }
          })
        }
      })
    } else {
      mongo.deleteOne('auditable', { _id: { $in: [null, ''] } }, (err) => {
        send()
      })
    }
  }
  /* get riskRanges */
  this.riskRanges = function (req, mongo, send) {
    var riskRanges = []
    mongo.findId('auditable', req.query._id, async (err, doc) => {
      if (err || !doc) {
        send(false)
      } else {
        if (doc.processes && typeof doc.processes !== 'object') {
          const process2 = await new Promise((resolve, reject) => {
            mongo.findId('process', doc.processes, async (err, pros) => {
              if (err || !pros) {
                reject(err)
              } else {
                resolve(pros)
              }
            })
          }).catch((err) => console.log(err))
          if (process2 && process2.assessment) {
            const assessment = await new Promise((resolve, reject) => {
              mongo.findId('assessment', process2.assessment, async (err, asse) => {
                if (err || !asse) {
                  reject(err)
                } else {
                  resolve(asse)
                }
              })
            }).catch((err) => console.log(err))
            riskRanges = assessment.riskRanges
          }
        } else if (doc.processes && doc.processes.length > 0) {
          const processes = doc.processes
          for (const z in processes) {
            const process2 = await new Promise((resolve, reject) => {
              mongo.findId('process', processes[z], async (err, pros) => {
                if (err || !pros) {
                  reject(err)
                } else {
                  resolve(pros)
                }
              })
            }).catch((err) => console.log(err))
            if (process2 && process2.assessment) {
              const assessment = await new Promise((resolve, reject) => {
                mongo.findId('assessment', process2.assessment, async (err, asse) => {
                  if (err || !asse) {
                    reject(err)
                  } else {
                    resolve(asse)
                  }
                })
              }).catch((err) => console.log(err))
              if (assessment) {
                riskRanges = assessment.riskRanges
              }
              break
            }
          }
        }
        send({ riskRanges: riskRanges })
      }
    })
  }
  /** duration of template */
  this.duration = function (req, mongo, send) {
    mongo.findId('template', req.query._id, (err, template) => {
      if (err || !template) {
        send({ error: err })
      } else {
        var jornada = 1*(req.session.context.workDay || 480)
        var duration = 0
        if (template.template.data && template.template.data.length) {
          for (const i in template.template.data) {
            var data = template.template.data[i]
            if (!data.type || data.type === 'task') {
              duration = duration + parseInt(data.duration)
            }
          }
        }
        if (duration) duration = duration / jornada
        send({ duration: duration })
      }
    })
  }
}
