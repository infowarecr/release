var request = require('request')

exports.Company = Company
var environments = {
  Pruebas: {
    idpUrl: 'https://idp.comprobanteselectronicos.go.cr/auth/realms/rut-stag/protocol/openid-connect/token',
    url: 'https://api.comprobanteselectronicos.go.cr/recepcion-sandbox/v1/',
    clientId: 'api-stag'
  },
  Produccion: {
    idpUrl: 'https://idp.comprobanteselectronicos.go.cr/auth/realms/rut/protocol/openid-connect/token',
    url: 'https://api.comprobanteselectronicos.go.cr/recepcion/v1/',
    clientId: 'api-prod'
  }
}

function Company () {
  this.get = function (req, mongo, send) {
    var doc = {}
    var keys = {}
    if (req.query._id === 'Produccion' || req.query._id === 'Sandbox') {
      keys = { userId: req.session.context.user, $or: [{ environment: mongo.toId(req.query._id) }, { environment: 'Pruebas' }] }
    } else {
      keys = { userId: req.session.context.user, _id: mongo.toId(req.query._id) }
    }
    mongo.find('company', keys, {}, { _id: -1 }, (err, company) => {
      if (!err) {
        if (company.length > 0) {
          doc = company[0]
          send(doc)
        } else {
          doc = { _id: mongo.newId() }
          send(doc)
        }
      } else { send({ error: err }) }
    })
  }

  this.list = function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    var keys = { userId: req.session.context.user }
    if (req.query.filter) {
      const query = {}
      for (const name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          if (name === 'agent') {
            query.agent = mongo.toId(req.query.filter.agent)
          } else if (name === 'inactive') {
            if (req.query.filter[name] === '0') {
              query.$or = [{ inactive: '0' }, { inactive: { $exists: 0 } }]
            } else {
              query.inactive = req.query.filter[name]
            }
          } else { query[name] = req.query.filter[name].indexOf(',') !== -1 ? { $in: req.query.filter[name].split(',') } : new RegExp(req.query.filter[name].replace(/ /g, '.*'), 'i') }
        }
      }
      keys = { $and: [keys, query] }
    }
    mongo.aggregate('company', [{ $match: keys }, { $skip: skip }, { $limit: limit }, { $project: { _id: 1, idNum: 1, name: 1, agent: 1, production: 1, statusCompany: 1, inactive: 1, deadCert: 1 } }], {}, (err, company) => {
      if (err) {
        send({ error: err })
      } else {
        mongo.find('params', { name: 'agent' }, (err, agents) => {
          if (err) throw err
          var options = agents[0] ? agents[0].options : []
          for (const i in company) {
            company[i].id = company[i]._id
            var expired = company[i].deadCert && company[i].deadCert.getTime() <= new Date().getTime() ? 'expired' : ''
            company[i].expired = expired
            if(company[i].deadCert) company[i].deadCert = company[i].deadCert.toISOString().split('T')[0]
            for (const n in options) {
              if (options[n].id.equals(company[i].agent)) {
                company[i].agent = { name: options[n].value, color: options[n].color, id: company[i].agent }
                break
              }
            }
          }
          reply.data = company
          mongo.count('company', keys, (err, count) => {
            if (!err && count) {
              reply.total_count = count
            }
            send(reply)
          })
        })
      }
    })
  }

  this.save = function (req, mongo, send) {
    var chilkat = require('@chilkat/ck-node14-linux64')
    var fs = require('fs')
    var ambient = environments[req.app.params.ebillEnvironment || 'Pruebas']
    var doc = req.body
    doc.userId = req.session.context.user
    var array = []
    if (doc.users) {
      array = doc.users.split(',')
    }
    doc.users = array
    var msj = ''
    // doc.environment = req.query.param;
    if (doc.production === '1') {
      /** Agregar campos de produccion */
      doc.url = 'https://api.comprobanteselectronicos.go.cr/recepcion/v1/'
      doc.idpUrl = 'https://idp.comprobanteselectronicos.go.cr/auth/realms/rut/protocol/openid-connect/token'
      doc.clientId = 'api-prod'
      doc.environment = 'Produccion'
      /** ------ */
    } else {
      /** Agregar campos de pruebas */
      doc.url = 'https://api.comprobanteselectronicos.go.cr/recepcion-sandbox/v1/'
      doc.idpUrl = 'https://idp.comprobanteselectronicos.go.cr/auth/realms/rut-stag/protocol/openid-connect/token'
      doc.clientId = 'api-stag'
      doc.environment = 'Pruebas'
      /** ----- */
    }
    mongo.findOne('company', { idNum: doc.idNum, production: doc.production }, {}, (err, company) => {
      if (err) {
        send({ error: err })
      } else {
        if (company) { doc._id = company._id }
        request.post({
          url: ambient.idpUrl,
          form: {
            grant_type: 'password',
            client_id: ambient.clientId,
            username: doc.user,
            password: doc.password,
            client_secret: '',
            scope: ''
          }
        },
        function (err, httpResponse, token) {
          if (err) {
            msj = 'Por favor revisar credenciales'
            doc.statusCompany = 'E'
            mongo.save('company', doc, (err, result) => {
              if (err) {
                send({ error: err })
              } else {
                send({ message: msj })
              }
            })
          } else {
            if (httpResponse.statusCode === 200) {
              doc.statusCompany = 'Ok'
            } else if (httpResponse.statusCode === 401) {
              msj = 'Por favor revisar credenciales'
              doc.statusCompany = 'E'
            } else {
              msj = 'Por favor revisar credenciales'
              doc.statusCompany = 'E'
            }
            if (doc.description && doc.description.split('?_id=')[1]) {
              var fileId = doc.description.split('?_id=')[1]
              fileId = fileId.split('&')[0]
              req.app.routes.file.get({ _id: fileId, type: 'p12' }, mongo, (result) => {
                var tmp = '/tmp/' + result.filename
                var file = fs.createWriteStream(tmp)
                file.on('finish', function () {
                  var cert = new chilkat.Cert()
                  var success = cert.LoadPfxFile(tmp, doc.pin)
                  if (success === true) {
                    doc.deadCert = new Date(cert.ValidToStr)
                  }
                  mongo.save('company', doc, (err, result) => {
                    if (err) {
                      send({ error: err })
                    } else {
                      send({ message: msj })
                    }
                  })
                })
                result.pipe(file)
              })
            } else {
              mongo.save('company', doc, (err, result) => {
                if (err) {
                  send({ error: err })
                } else {
                  send({ message: msj })
                }
              })
            }
          }
        })
      }
    })
  }
}
