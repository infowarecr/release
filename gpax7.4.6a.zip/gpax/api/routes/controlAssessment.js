/* exported */
exports.ControlAssessment = ControlAssessment

function ControlAssessment () {
  /** get document ControlAssessment */
  this.get = function (req, mongo, send) {
    if (req.query._id) {
      mongo.findId('controlAssessment', req.query._id, (err, assessment) => {
        if (!err) {
          send(assessment)
        } else {
          send()
        }
      })
    } else {
      send({ _id: mongo.newId(), process: req.query.process, name: req.query.name, parent: req.query.parent, user: req.session.context.user })
    }
  }

  /** load control and calification */
  this.controlCalification = async (req, mongo, send, recycle) => {
    var tagsDoc = []
    var tgsDs = await new Promise(resolve => {
      mongo.find('params', { name: { $in: ['automationLevel', 'periodicity', 'class'] } }, { _id: 1, name: 1, options: 1 }, async (err, tgsDs) => {
        if (err) {
          resolve(false)
        }

        resolve(tgsDs)
      })
    })
    if (tgsDs) {
      if (tgsDs.length > 0) {
        for (var i in tgsDs) {
          tagsDoc = tagsDoc.concat(tgsDs[i].options)
        }
      }
    }
    var result = await new Promise(resolve => {
      mongo.findId('controlAssessment', mongo.toId(req.body.id) || mongo.toId(req.body._id), (err, res) => {
        if (err) {
          resolve(false)
        }

        resolve(res)
      })
    })
    if (result) {
      var riskFactors = []
      for (const i in result.risks) {
        result.risks[i].id = result.risks[i]._id
        for (var t in tagsDoc) {
          if (result.risks[i].automationLevel && result.risks[i].automationLevel.toString() === tagsDoc[t].id.toString()) {
            result.risks[i].automationLevel = { id: result.risks[i].automationLevel, value: tagsDoc[t].value, color: tagsDoc[t].color }
          } else if (result.risks[i].periodicity && result.risks[i].periodicity.toString() === tagsDoc[t].id.toString()) {
            result.risks[i].periodicity = { id: result.risks[i].periodicity, value: tagsDoc[t].value, color: tagsDoc[t].color }
          } else if (result.risks[i].class && result.risks[i].class.toString() === tagsDoc[t].id.toString()) {
            result.risks[i].class = { id: result.risks[i].class, value: tagsDoc[t].value, color: tagsDoc[t].color }
          }
        }
        var risk = result.risks[i]
        if (risk.type === 'riskFactor') {
          riskFactors.push(risk._id)
        }
      }
      var events = await new Promise(resolve => {
        mongo.aggregate('riskEvent', [
          { $match: { riskFactor: { $in: riskFactors } } },
          { $group: { _id: '$riskFactor', count: { $sum: 1 } } }
        ], {}, (err, events) => {
          if (err) {
            resolve(false)
          }

          resolve(events)
        })
      })
      if (events) {
        for (const i in events) {
          result.risks.findIndex((it) => {
            if (it._id.toString() === events[i]._id.toString()) {
              it.events = events[i].count
              return true
            }
          })
        }
      }
    }
    if (recycle) {
      return result.risks
    } else {
      send(result.risks)
    }
  }

  /** save control Assessment */
  this.save = function (req, mongo, send) {
    var doc = req.body
    doc.risks = []
    delete doc.riskId
    var grid = doc.calification
    doc.processEffectivity = parseFloat(doc.processEffectivity) + '%'
    doc.processResidualRisk = parseFloat(doc.processResidualRisk) + '%'

    if (grid === '[]') grid = []
    /** data of risks calification */
    for (const g in grid) {
      var row = grid[g]

      delete row.id
      doc.risks.push(row)
    }
    var calificationResult = doc.calification
    delete doc.id
    delete doc.calification
    mongo.save('controlAssessment', doc, async (err, result) => {
      if (err) {
        send({ error: err.toString() })
      } else {
        send({ id: doc._id, parent: doc.parent, calification: calificationResult })
      }
    })
  }

  this.saveRiskFactorChanges = async function (req, mongo, send) {
    var doc = req.body
    var control = doc.result
    var deletedControl = doc.deleted
    var calificationResult = []
    doc.processEffectivity = parseFloat(doc.processEffectivity) + '%'
    doc.processResidualRisk = parseFloat(doc.processResidualRisk) + '%'

    var controlAssessment = await this.controlCalification(req, mongo, send, true)

    if (control === '[]') control = []
    if (deletedControl === '[]') deletedControl = []

    var resultadoProcess = await new Promise(resolve => {
      mongo.findId('process', mongo.toId(doc.process), async (err, process) => {
        if (err || !process) {
          resolve(false)
        } else {
          resolve(process)
        }
      })
    })

    if (control.length > 0) {
      for (const c in control) {
        var save = false
        var row = control[c]
        delete row.id
        delete row.ch1
        delete row.deleted
        var existRisk = await new Promise(resolve => {
          mongo.find('risk', { type: 'control', _id: mongo.toId(row._id), parent: mongo.toId(row.parent) }, {}, {}, async (err, risk) => {
            if (err) {
              resolve()
              console.log(err)
            } else {
              resolve(risk)
            }
          })
        })
        if (existRisk.length > 0) {
          const posNew = controlAssessment.findIndex((x) => {
            return x._id.toString() === control[c]._id.toString()
          })

          var risksSelected = resultadoProcess.risks.selected
          const pos = risksSelected.findIndex((x) => {
            return x.toString() === control[c]._id.toString()
          })

          if (posNew === -1) {
            doc.risks.push(row)
            save = true
          } else {
            save = false
          }
          if (save) {
            if (pos === -1) {
              resultadoProcess.risks.selected.push(row._id)
            }
            await new Promise(resolve => {
              mongo.save('process', resultadoProcess, async (err, result) => {
                if (err) {
                  resolve()
                } else {
                  resolve()
                }
              })
            })
          }
        }
      }
    }

    if (deletedControl.length > 0) {
      for (const c in deletedControl) {
        save = false
        row = deletedControl[c]
        delete row.id
        delete row.ch1
        delete row.deleted
        var existRisk2 = await new Promise(resolve => {
          mongo.find('risk', { type: 'control', _id: mongo.toId(row._id), parent: mongo.toId(row.parent) }, {}, {}, async (err, risk) => {
            if (err) {
              resolve()
              console.log(err)
            } else {
              resolve(risk)
            }
          })
        })
        if (existRisk2.length > 0) {
          risksSelected = resultadoProcess.risks.selected
          const pos = risksSelected.findIndex((x) => {
            return x.toString() === deletedControl[c]._id.toString()
          })
          const posDeleted = controlAssessment.findIndex((x) => {
            return (x._id.toString() === deletedControl[c]._id.toString())
          })

          if (posDeleted !== -1) {
            const posD = doc.risks.findIndex((x) => {
              return (x._id.toString() === deletedControl[c]._id.toString())
            })
            if (posD !== -1) {
              doc.risks.splice(posD, 1)
              save = true
            }
          } else {
            save = false
          }

          if (save) {
            if (pos !== -1) {
              resultadoProcess.risks.selected.splice(pos, 1)
            }
            await new Promise(resolve => {
              mongo.save('process', resultadoProcess, async (err, result) => {
                if (err) {
                  resolve()
                } else {
                  resolve()
                }
              })
            })
          }
        }
      }
    }

    calificationResult = doc.risks
    delete doc.result
    delete doc.deleted
    delete doc.calification
    mongo.save('controlAssessment', doc, async (err, result) => {
      if (err) {
        send({ error: err.toString() })
      } else {
        send({ calification: calificationResult })
      }
    })
  }
}
