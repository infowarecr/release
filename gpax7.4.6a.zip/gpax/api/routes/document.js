/* eslint-disable no-console */
var tags = require('../utils/tags').tags
var dateformat = require('dateformat')
var Html = require('../utils/html').Html
var html = new Html()
var Extract = require('../utils/extract').Extract
var extract = new Extract()
var Sequence = require('./sequence').Sequence
var sequence = new Sequence()
var nodemailer = require('nodemailer')
var moment = require('moment')
var Notification = require('../utils/notification').Notification
var notification = new Notification()
/* exported */

exports.Document = Document

function Document () {
  this.getExpenses = function (req, mongo, send) {
    var doc = {}
    if (req.query._id) {
      mongo.findId('document', req.query._id, (err, document) => {
        if (err) throw err
        doc = document
        send(doc)
      })
    } else {
      doc = {
        _id: mongo.newId(),
        type: 'expense',
        actors: [{
          user: req.session.context.user,
          path: '',
          role: tags.reviser
        }]
      }
      send(doc)
    }
  }
  this.get = async function (req, mongo, send) {
    var doc = {}
    if (!!req.query._id && req.query._id !== 'undefined') {
      if (req.session.context.licensedUser === false) {
        var myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits)
        var myAndDependentUnits = req.session.context.dependentUnits.concat(myUnits)
      } else {
        myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits).concat(req.session.context.memberUnits)
        myAndDependentUnits = req.session.context.dependentUnits.concat(myUnits)
      }
      mongo.toHash('user', {}, { _id: 1, name: 1 }, (er, users) => {
        mongo.findId('document', mongo.toId(req.query._id), async (err, document) => {
          if (err || !document) {
            req.statusCode = 404
            send()
          } else {
            delete document.data
            // validacion para saber si el usuario puede ver el documento ******
            var keys = {
              _id: document.project,
              $or: [
                { actors: { $elemMatch: { user: req.session.context.user } } },
                { unit: { $in: myUnits } },
                { unit: { $in: myAndDependentUnits } }
              ]
            }
            if (req.session.context.readerUnits && req.session.context.readerUnits.length > 0) {
              keys.$or.push({
                $and: [
                  { unit: { $in: req.session.context.readerUnits } },
                  { status: 'archived' }
                ]
              })
            }
            let show = await new Promise(resolve => {
              mongo.find('project', keys, { name: 1 }, (err, result) => {
                if (!err && (result && result.length)) resolve(true)
                else resolve(false)
              })
            })
            // *****
            if (show) {
              let deadline
              if (document.dates) {
                document.dates.findIndex((x) => {
                  if (x.type === 'deadline') deadline = x.value
                })
              }
              var y = document.actors.findIndex((x) => {
                if (x) { return x.role !== 'reviser' && x.user && x.user.equals && x.user.equals(req.session.context.user) }
              })
              if (y !== -1) {
                var actual = document.actors[y]
                document.actor = { user: document.actors[y].user, path: actual.role === 'copy' ? 'referred' : actual.path }
              }
              if (!document.actor) {
                document.actor = document.actors[0]
              }
              var username
              if (document.actor) {
                var actor = document.actor
                username = actor.user && mongo.isNativeId(actor.user) && users[actor.user.toString()] ? users[actor.user.toString()].name : actor.user
                document.user = actor.user
              } else {
                if (document.user) { username = users[document.user].name } else { username = '' }
              }
              document.userName = username
              if (document.project) {
                document.proj = await new Promise(resolve => {
                  mongo.findId('project', document.project, { _id: 1, name: 1 }, (err, proj) => {
                    if (err || !proj) {
                      if (err) console.log(err)
                      resolve('')
                    } else {
                      resolve(proj)
                    }
                  })
                })
              }
              if (document.status && document.status === 'processing' && deadline) {
                var date = dateformat(new Date(deadline), 'yyyy/mm/dd')
                document.deadline = date
              } else if (document.commitment === '1' && deadline) {
                date = dateformat(new Date(deadline), 'yyyy/mm/dd')
                document.deadline = date
              }
              var logs = req.app.getMongo(req.app.params.log)
              var creator = await req.logger.firstAuthor(mongo, mongo.toId(req.query._id), 'document')
              var last = await req.logger.lastAuthor(mongo, mongo.toId(req.query._id), 'document')
              if (creator._id) {
                document.creator = 'Creado por: ' + creator.name + ' - ' + moment(creator.when).format('DD-MM-YYYY HH:mm')
              } else {
                document.creator = ''
              }
              if (last._id) {
                document.lastModification = '<div style="float: right;">Última modificación: ' + last.name + ' - ' + moment(last.when).format('DD-MM-YYYY HH:mm') + '</div>'
              } else {
                document.lastModification = ''
              }
              var from
              var to = []
              var copy = []
              for (const i in document.actors) {
                if (document.actors[i]) {
                  switch (document.actors[i].role) {
                  case 'from':
                    if (!from && document.actors[i].unit) { from = document.actors[i].user.toString() + '&unit=' + document.actors[i].unit.toString() }
                    break
                  case 'to':
                    if (document.actors[i].unit) { to.push(document.actors[i].user.toString() + '&unit=' + document.actors[i].unit.toString()) }
                    break
                  case 'copy':
                    if (document.actors[i].unit) { copy.push(document.actors[i].user.toString() + '&unit=' + document.actors[i].unit.toString()) }
                    break
                  default:
                    break
                  }
                }
              }
              document.from = from
              document.to = to
              document.copy = copy
              if (document.type === 'spreadsheet' && typeof (document.content) === 'string') { document.content = JSON.parse(document.content) }
              if (document.type === 'form') {
                for (let i in document) {
                  if ((document[i] instanceof Date || (document[i] && document[i].start instanceof Date && document[i].end instanceof Date)) && !mongo.isNativeId(document[i])) {
                    if (document[i] && document[i].start && document[i].end) {
                      document[i].start = new Date(document[i].start)
                      document[i].end = new Date(document[i].end)
                      document[i].start = document[i].start.getFullYear() + '-' + (document[i].start.getMonth() + 1) + '-' + document[i].start.getDate()
                      document[i].end = document[i].end.getFullYear() + '-' + (document[i].end.getMonth() + 1) + '-' + document[i].end.getDate()
                    } else {
                      document[i] = new Date(document[i])
                      document[i] = document[i].getFullYear() + '-' + (document[i].getMonth() + 1) + '-' + document[i].getDate()
                    }
                  }
                }
              }
              if (document.project) {
                req.query.project = document.project
                req.query.task = document.task
                req.app.routes.project.delegates(req, mongo, (delegates) => {
                  document.delegates = delegates
                  mongo.find('comment', { document: document._id }, {}, {}, (err, comments) => {
                    if (err) throw err
                    document.mentions = []
                    for (const c in comments) {
                      for (const m in comments[c].mentions) {
                        const addReviser = document.actors.findIndex((x) => {
                          if (x && x.user.toString() === comments[c].mentions[m].toString()) { return true } else return false
                        })
                        if (addReviser !== -1) { document.mentions.push(comments[c].mentions[m]) }
                      }
                    }
                    if (req.session.context.autoTimer) {
                      var date = new Date()
                      // date = new Date(date);
                      mongo.find('time', { document: document.task, project: document.project, $and: [{ date: { $gte: new Date(new Date(date).setHours(0, 0, 0, 0)) } }, { date: { $lte: new Date(new Date(date).setHours(23, 59, 59)) } }], user: req.session.context.user }, {}, {}, (err, time) => {
                        if (err) throw err
                        mongo.findId('project', document.project, async (err, project) => {
                          if (err) throw err
                          var Obj = {}
                          var own = false
                          var name = ''
                          if (document.task) {
                            await new Promise(resolve => {
                              mongo.findId('task', document.task, (err, task) => {
                                if (task) {
                                  name = task.text
                                  if (task.owner_id && task.owner_id.toString() === req.session.context.user.toString()) {
                                    own = true
                                  }
                                }
                                resolve()
                              })
                            })
                          }
                          if (own) {
                            if (document.type === 'redactor') { document.type = 'document' }
                            if (time.length > 0) {
                              Obj._id = time[0]._id
                              if (!time[0].docs) { time[0].docs = [] }
                              for (const d in time[0].docs) {
                                time[0].docs[d] = time[0].docs[d].toString()
                              }
                              var index = time[0].docs.indexOf(document._id.toString())
                              if (index === -1) {
                                if (time[0].docs && typeof time[0].docs === 'object') { time[0].docs.push(document._id) } else { time[0].docs = [document._id] }
                                Obj.docs = time[0].docs
                              }
                              if (!time[0].open) { Obj.start = new Date() }
                              Obj.comment = time[0].comment + '<br><span class="h-entry p-name" contenteditable="true"><a class="u-uid" href=' + document._id + ' style="display:none;"></a><a class="u-url" href="document.' + document.type + '?_id=' + document._id + '&project=' + document.project + '">' + document.name + ' ' + dateformat(new Date(), 'yyyy/mm/dd') + '</a></span>⁠'
                            } else {
                              Obj._id = mongo.newId()
                              Obj.user = req.session.context.user
                              Obj.date = date
                              Obj.start = new Date()
                              Obj.docs = [document._id]
                              Obj.duration = '0'
                              Obj.status = 'draft'
                              Obj.type = 'task'
                              Obj.document = document.task
                              Obj.task = name
                              Obj.plan = project.plan
                              Obj.project = document.project
                              Obj.comment = '<span class="h-entry p-name"><a class="u-uid" href=' + document._id + ' style="display:none;"></a><a class="u-url" href="document.' + document.type + '?_id=' + document._id + '">' + document.name + ' ' + dateformat(new Date(), 'yyyy/mm/dd') + '</a></span>⁠'
                              Obj.open = true
                            }
                            mongo.save('time', Obj, () => {
                              send(document)
                            })
                          } else {
                            send(document)
                          }
                        })
                      })
                    } else { send(document) }
                  })
                })
              } else {
                send(document)
              }
            } else {
              send()
            }
          }
        })
      })
    } else {
      // New document
      doc = {
        _id: mongo.newId(),
        isNew: true,
        creator: '',
        lastModification: '',
        status: tags.draft,
        actors: [{
          user: req.session.context.user,
          path: tags.sent,
          role: tags.reviser
        }]
      }
      if (req.session.context.memberUnits && req.session.context.memberUnits.length > 0) {
        doc.actors[0].unit = req.session.context.memberUnits[0]
      }
      if (req.query.project) {
        doc.project = req.query.project
        doc.task = req.query.task
      }
      if (req.query.reference) {
        doc.reference = req.query.reference
        if (req.query.evidence) { doc.evidence = '1' } else { doc.commitment = '1' }
        var actors = req.query.actors
        const index = actors.findIndex((x) => {
          return x.user === req.session.context.user.toString()
        })
        let unit
        if (index !== -1) {
          unit = actors[index].unit
        }
        for (const i in actors) {
          switch (actors[i].role) {
          case 'inCharge':
            actors[i].role = 'reviser'
            break
          }
          if (unit) {
            if (actors[i].unit === unit && (actors[i].role !== 'supervisor' && actors[i].role !== 'from')) { actors[i].role = 'inCharge' } else { actors[i].path = 'hidden' }
          }
          doc.actors.push(actors[i])
        }
      }
      if (req.query.template) {
        mongo.findId('template', req.query.template, async (err, template) => {
          if (!err) {
            doc.type = template.type
            doc.name = template.name
            doc.template = req.query.template
            doc.status = 'draft'
            if (template.documental) {
              doc.documental = template.documental
            }
            if (template.pageType) { doc.pageType = template.pageType }
            if (template.tags) { doc.tags = template.tags }
            if (template.units) { doc.units = template.units }
            if (template.sequence && template.sequence[0]) {
              doc.sequence = { sequence: template.sequence[0] }
            } else {
              doc.sequence = { text: '' }
            }
            doc.content = template.template
            if (doc.project && doc.type === 'redactor') {
              doc.content = await extract.fields(mongo, doc.project, doc.content)
            }
            if (req.session.context.autoTimer) {
              var date = new Date()
              // date = new Date(date);
              await new Promise(resolve => {
                mongo.find('time', { document: mongo.toId(doc.task), project: mongo.toId(doc.project), $and: [{ date: { $gte: new Date(new Date(date).setHours(0, 0, 0, 0)) } }, { date: { $lte: new Date(new Date(date).setHours(23, 59, 59)) } }], user: req.session.context.user }, {}, {}, (err, time) => {
                  if (err) throw err
                  mongo.findId('project', doc.project, (err, project) => {
                    if (err) throw err
                    var Obj = {}
                    var name = ''
                    if (doc.task) {
                      for (const i in project.content.data) {
                        if (project.content.data[i].id && project.content.data[i].id.toString() === doc.task.toString()) {
                          name = project.content.data[i].text
                          break
                        }
                      }
                    }
                    if (doc.type === 'redactor') { doc.type = 'document' }
                    if (time.length > 0) {
                      Obj._id = time[0]._id
                      if (!time[0].docs) { time[0].docs = [] }
                      for (const d in time[0].docs) {
                        time[0].docs[d] = time[0].docs[d].toString()
                      }
                      var index = time[0].docs.indexOf(doc._id.toString())
                      if (index === -1) {
                        if (time[0].docs && typeof time[0].docs === 'object') { time[0].docs.push(doc._id) } else { time[0].docs = [doc._id] }
                        Obj.docs = time[0].docs
                      }
                      if (!time[0].open) { Obj.start = new Date() }
                      Obj.comment = time[0].comment + '<br><span class="h-entry p-name" contenteditable="true"><a class="u-uid" href=' + doc._id + ' style="display:none;"></a><a class="u-url" href="document.' + doc.type + '?_id=' + doc._id + '&project=' + doc.project + '">' + doc.name + ' ' + dateformat(new Date(), 'yyyy/mm/dd') + '</a></span>⁠'
                    } else {
                      Obj._id = mongo.newId()
                      Obj.user = req.session.context.user
                      Obj.date = date
                      Obj.start = new Date()
                      Obj.docs = [doc._id]
                      Obj.duration = '0'
                      Obj.status = 'draft'
                      Obj.type = 'task'
                      Obj.document = doc.task
                      Obj.task = name
                      Obj.plan = project.plan
                      Obj.project = doc.project
                      Obj.comment = '<span class="h-entry p-name"><a class="u-uid" href=' + doc._id + ' style="display:none;"></a><a class="u-url" href="document.' + doc.type + '?_id=' + doc._id + '">' + doc.name + ' ' + dateformat(new Date(), 'yyyy/mm/dd') + '</a></span>⁠'
                      Obj.open = true
                    }
                    mongo.save('time', Obj, () => {
                      resolve()
                    })
                  })
                })
              })
            }
            if (req.query.task) {
              req.app.routes.project.delegates(req, mongo, (delegates) => {
                doc.delegates = delegates
                send(doc)
              })
            } else {
              send(doc)
            }
          } else {
            send()
          }
        })
      } else {
        send(doc)
      }
    }
  }

  this.getAndSaveBpd = function (req, mongo, send) {
    // New document
    var doc = {
      _id: mongo.newId(),
      status: tags.draft,
      actors: [{
        user: req.session.context.user,
        path: tags.sent,
        role: tags.reviser
      }]
    }
    if (req.session.context.memberUnits && req.session.context.memberUnits.length > 0) {
      doc.actors[0].unit = req.session.context.memberUnits[0]
    }
    if (req.query.project) {
      doc.project = req.query.project
      doc.task = req.query.task
    }
    mongo.findId('template', req.query.template, (err, template) => {
      if (!err) {
        doc.type = template.type
        doc.name = req.query.name !== '' ? req.query.name : template.name
        doc.template = req.query.template
        doc.status = 'draft'
        if (template.documental) {
          doc.documental = template.documental
        }
        if (template.tags) { doc.tags = template.tags }
        if (template.units) { doc.units = template.units }

        doc.content = template.template
        if (req.query.task) {
          req.app.routes.project.delegates(req, mongo, (delegates) => {
            doc.delegates = delegates
            mongo.save('document', doc, (err) => {
              if (err) {
                send()
              } else {
                send({ _id: doc._id })
              }
            })
          })
        } else {
          mongo.save('document', doc, (err) => {
            if (err) {
              send()
            } else {
              send({ _id: doc._id })
            }
          })
        }
      } else {
        send()
      }
    })
  }

  this.getReviewers = function (req, mongo, send) {
    mongo.findId('document', req.query._id, {}, (err, document) => {
      if (err) throw err
      var users = []

      var data = []
      if (document) {
        for (const a in document.actors) {
          if (document.actors[a]) {
            var actor = document.actors[a]
            users.push(actor.user)
          }
        }
        mongo.toHash('user', { _id: { $in: users } }, { _id: 1, name: 1 }, (er, users) => {
          for (const a in document.actors) {
            if (document.actors[a]) {
              var dataactor = document.actors[a]
              data.push({
                id: dataactor.user,
                name: dataactor.user ? users[dataactor.user.toString()].name : null,
                path: dataactor.path,
                role: dataactor.role
              })
            }
          }
          send(data)
        })
      }
    })
  }

  this.setSequence = function (req, mongo, send) {
    var doc = {}
    mongo.findOne('settings', { _id: 'settings' }, (err, settings) => {
      if (err || !settings) {
        settings = { hours: -6 }
      }
      mongo.findId('document', req.body._id, (err, document) => {
        if (err) {
          send({ error: err })
        } else {
          doc = document
          let deadline
          if (doc.dates) {
            doc.dates.findIndex((x) => {
              if (x.type === 'deadline') deadline = x.value
            })
          }
          if (!deadline) {
            doc.dates = [{ type: tags.issue, value: new Date() }]
          }
          getData(mongo, document, (unitName, tag) => {
            var meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
            var diasSemana = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado']
            var f = new Date()
            if (doc.pageType === 'sticker') {
              f.setHours(f.getHours() + 6 + settings.hours)
              replace(doc, tags.issue, dateformat(f, 'dd-mm-yyyy hh:MM tt'))
              replace(doc, 'tags', tag)
              replace(doc, 'unitTo', unitName)
              replace(doc, 'name', document.name)
            } else {
              replace(doc, tags.issue, diasSemana[f.getDay()] + ' ' + f.getDate() + ' de ' + meses[f.getMonth()] + ' de ' + f.getFullYear())
            }
            if (req.body.termDays && req.body.termDays) {
              const deadline = new Date()
              deadline.setDate(deadline.getDate() + Number(req.body.termDays))
              doc.dates.push({ type: tags.deadline, value: deadline })
            }
            if (req.body.unit && doc.sequence.text === '') {
              mongo.findId('unit', req.body.unit, (err, unit) => {
                if (!err && unit && unit.sequences && unit.sequences.length > 0) {
                  var i = 0
                  if (doc.sequence && doc.sequence.sequence) {
                    i = unit.sequences.findIndex(x => x._id.equals(doc.sequence.sequence))
                  }
                  if (i === -1) i = 0
                  unit.sequences[i].code = unit.code
                  sequence.next(unit.sequences[i], mongo, req.body.type, function (seq) {
                    if (seq && seq.type === 'sequence') {
                      mongo.save('sequence', { _id: seq._id, lastValue: seq.lastValue }, (err) => {
                        if (err) {
                          send()
                        } else {
                          doc.sequence.text = seq.text
                          doc.sequence.value = seq.lastValue
                          doc.sequence.sequence = seq._id
                          replace(doc, 'sequence', seq.text)
                          saveSend(doc)
                        }
                      })
                    } else if (seq && seq.type === 'unit') {
                      const p = unit.sequences.findIndex((x) => { return x._id.toString() === seq._id.toString() })
                      unit.sequences[p].lastValue = seq.lastValue
                      mongo.save('unit', unit, (err) => {
                        if (err) {
                          send()
                        } else {
                          doc.sequence.text = seq.text
                          doc.sequence.value = seq.lastValue
                          doc.sequence.sequence = seq._id
                          replace(doc, 'sequence', seq.text)
                          saveSend(doc)
                        }
                      })
                    } else {
                      saveSend(doc)
                    }
                  })
                } else {
                  saveSend(doc)
                }
              })
            } else {
              saveSend(doc)
            }
          })
        }
        function getData (mongo, doc, next) {
          var unit
          for (const i in doc.actors) {
            if (doc.actors[i].role === 'to') {
              unit = doc.actors[i].unit
              break
            }
          }
          mongo.findId('unit', mongo.toId(unit), (err, unit) => {
            if (err) throw err
            var unitName = ''
            if (unit) {
              unitName = unit.name
            }
            mongo.findOne('params', { name: 'tag' }, (err, param) => {
              if (err) throw err
              var tag
              if (param) {
                for (const i in param.options) {
                  if (param.options[i].id.toString() === doc.tags[0]) {
                    tag = param.options[i].value
                    break
                  }
                }
              }
              next(unitName, tag)
            })
          })
        }
        function replace (doc, tag, value) {
          doc.content = doc.content.replace(new RegExp('{{' + tag + '}}', 'g'), value)
        }
        function saveSend (data) {
          mongo.save('document', data, (err) => {
            if (err) {
              send()
            } else {
              send({ content: data.content, sequence: data.sequence })
            }
          })
        }
      })
    })
  }
  this.send = async function (req, mongo, send) {
    var doc = {}
    mongo.findId('document', req.body._id, async (err, document) => {
      if (err) {
        send({ error: err })
      } else {
        doc = document
        var users = []
        for (const i in doc.actors) {
          users.push(doc.actors[i].user)
        }
        mongo.find('user', { _id: { $in: users } }, {}, {}, async (err, usr) => {
          if (err) throw err
          var unlicensedTo = []
          var unlicensedCopy = []
          var usersToURL = []
          for (const i in usr) {
            for (const j in users) {
              if (usr[i]._id.toString() === users[j].toString()) {
                for (const c in doc.actors) {
                  if (doc.actors[c].user.toString() === users[j].toString()) {
                    if (doc.actors[c].role === 'to') {
                      unlicensedTo.push(usr[i].email)
                      usersToURL.push(usr[i]._id.toString())
                    } else if (doc.actors[c].role === 'copy') {
                      unlicensedCopy.push(usr[i].email)
                      usersToURL.push(usr[i]._id.toString())
                    }
                  }
                }
              }
            }
          }
          mongo.findOne('settings', { _id: 'settings' }, async (err, sett) => {
            if (err) throw err
            if (sett && sett.user && sett.password && (unlicensedTo.length > 0 || unlicensedCopy.length > 0) && sett.checkEmail === '1') {
              var secure = false
              var password
              var copies = []
              var emailCopies = []
              try {
                password = tags.util.Decipher(sett.password)
              } catch (err) {
                password = ''
              }
              if (sett.security === 'ssl') { secure = true }
              if (sett.copies.length > 0) {
                for (const i in sett.copies) {
                  copies.push(sett.copies[i])
                }
              }
              var usersCopies = await new Promise(resolve => {
                mongo.find('user', { _id: { $in: copies } }, {}, {}, (err, usersCopies) => {
                  if (err || !usersCopies) {
                    resolve()
                  } else {
                    resolve(usersCopies)
                  }
                })
              })
              for (const i in usersCopies) {
                emailCopies.push(usersCopies[i].email)
                usersToURL.push(usersCopies[i]._id.toString())
              }

              const transporter = nodemailer.createTransport({
                host: sett.smtp,
                port: sett.port,
                secure: secure, // true for 465, false for other ports
                auth: {
                  user: sett.user,
                  pass: password
                },
                tls: {
                  rejectUnauthorized: false
                }
              })
              if (doc.type === 'redactor') { doc.type = 'document' }

              // setup email data with unicode symbols
              const message = {
                from: sett.user, // sender address
                to: unlicensedTo, // list of receivers
                cc: unlicensedCopy.concat(emailCopies), // list of receivers
                subject: doc.name, // Subject lines
                // text: 'Hello world?', // plain text body
                html: 'Nueva correspondencia en GPAX, haga click aqui para ver ' +
                  '<span class="h-entry p-name"><a class="u-uid" href="' + doc._id + '" style="display:none">' +
                  '</a><a class="u-url" href="' + req.headers.referer + 'api/user.goURL?users='+usersToURL+'&url=note.' + doc.type + '?_id=' + doc._id + '$issued=' + doc.issued + '$status=' + doc.status + '">' + doc.name + '</a></span>⁠&nbsp;' // html body
              }

              // send mail with defined transport object
              transporter.sendMail(message, (error, info) => {
                if (error) {
                  console.log(error)
                  notification.saveSystemNotification(req, mongo, null, 'Error al enviar correo: ' + error.message)
                } else { console.log('Message sent: %s', info.messageId) }
              })
            }
            let deadline
            if (doc.dates) {
              doc.dates.findIndex((x) => {
                if (x.type === 'deadline') deadline = x.value
              })
            }
            if (!deadline) {
              doc.dates = [{ type: tags.issue, value: new Date() }]
            }
            var meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
            var diasSemana = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado']
            var f = new Date()
            var completeDate
            if (doc.pageType !== 'sticker') {
              completeDate = diasSemana[f.getDay()] + ' ' + f.getDate() + ' de ' + meses[f.getMonth()] + ' de ' + f.getFullYear()
              replace(doc, tags.issue, completeDate)
            }
            if (req.body.termDays) {
              const deadline = new Date()
              deadline.setDate(deadline.getDate() + Number(req.body.termDays))
              doc.dates.push({ type: tags.deadline, value: deadline })
            }
            doc.status = tags.processing
            var user = {}
            for (const i in doc.actors) {
              if (doc.actors[i].user === req.session.context.user.toString()) {
                user = doc.actors[i]
                break
              }
            }
            var readers = []
            if (doc.actors) {
              for (const x in doc.actors) {
                if (doc.actors[x].path === tags.hidden) {
                  doc.actors[x].path = tags.received
                }
                if (doc.actors[x].unit) {
                  if (doc.actors[x].unit.equals(user.unit)) {
                    readers.push(doc.actors[x].user)
                  }
                }
              }
            }
            if (req.body.category && req.body.category !== '') {
              doc.category = req.body.category
            }
            if (req.body.unit && doc.sequence.text === '') {
              mongo.findId('unit', req.body.unit, (err, unit) => {
                if (!err && unit && unit.sequences && unit.sequences.length > 0) {
                  var i = 0
                  if (doc.sequence && doc.sequence.sequence) {
                    i = unit.sequences.findIndex(x => x._id.equals(doc.sequence.sequence))
                  }
                  if (i === -1) i = 0
                  unit.sequences[i].code = unit.code
                  sequence.next(unit.sequences[i], mongo, req.body.type, function (seq) {
                    if (seq && seq.type === 'sequence') {
                      mongo.save('sequence', { _id: seq._id, lastValue: seq.lastValue }, (err) => {
                        if (err) {
                          send()
                        } else {
                          doc.sequence = seq
                          replace(doc, 'sequence', seq.text)
                          saveSend(doc)
                        }
                      })
                    } else if (seq && seq.type === 'unit') {
                      const p = unit.sequences.findIndex((x) => { return x._id.toString() === seq._id.toString() })
                      unit.sequences[p].lastValue = seq.lastValue
                      mongo.save('unit', unit, (err) => {
                        if (err) {
                          send()
                        } else {
                          doc.sequence = seq
                          replace(doc, 'sequence', seq.text)
                          saveSend(doc)
                        }
                      })
                    } else {
                      saveSend(doc)
                    }
                  })
                } else {
                  saveSend(doc)
                }
              })
            } else {
              saveSend(doc)
            }
          })
        })
      }
      function replace (doc, tag, value) {
        doc.content = doc.content.replace(new RegExp('{{' + tag + '}}', 'g'), value)
      }
      function saveSend (doc) {
        var idsLink = []
        html.getData(doc.content, (data) => {
          if (data.links && data.links.length > 0) {
            for (const i in data.links) {
              idsLink.push(data.links[i]._id)
            }
            saveDocLink(0, idsLink, doc)
          } else {
            mongo.save('document', doc, (err) => {
              if (err) {
                send()
              } else {
                send({ message: tags.document + ' ' + tags.sent })
                sendNotification(req, mongo, send, doc, null)
              }
            })
          }
        })

        function saveDocLink (y, idsLink, doc) {
          mongo.findId('document', idsLink[y], (err, docLink) => {
            if (err) throw err
            if (docLink) {
              if ((!docLink.issued || docLink.issued !== '1')) {
                docLink.issued = '1'
                docLink.reference = doc._id
                docLink.sequence = doc.sequence
                docLink.status = 'processing'
                /// ///////revisar despues////////////////
                docLink.actors = []
                /// ////////////////////////////////
                let actor
                for (const i in doc.actors) {
                  switch (doc.actors[i].role) {
                  case 'to':
                    actor = {}
                    actor.user = doc.actors[i].user
                    actor.unit = doc.actors[i].unit
                    actor.role = 'inCharge'
                    actor.path = 'received'
                    docLink.actors.push(actor)
                    break
                  case 'copy':
                    actor = {}
                    actor.user = doc.actors[i].user
                    actor.unit = doc.actors[i].unit
                    actor.role = 'inCharge'
                    actor.path = 'referred'
                    docLink.actors.push(actor)
                    break
                  default:
                    actor = doc.actors[i]
                    docLink.actors.push(actor)
                    break
                  }
                }
              }
              mongo.save('document', docLink, (err) => {
                if (err) {
                  send()
                } else {
                  if (idsLink.length - 1 > y) {
                    y++
                    saveDocLink(y, idsLink, doc)
                  } else {
                    mongo.save('document', doc, (err) => {
                      if (err) {
                        send()
                      } else {
                        send({ message: tags.document + ' ' + tags.sent })
                        sendNotification(req, mongo, send, doc, null)
                      }
                    })
                  }
                }
              })
            }
          })
        }
      }
      function sendNotification (req, mongo, send, doc, deleted) {
        doc.id = doc._id
        mongo.find('params', { name: 'tag' }, { _id: 1, name: 1, options: 1 }, (er, tagsDoc) => {
          var user = []
          var y = doc.actors.findIndex((x) => { return x.role !== 'reviser' && x.user.equals && x.user.equals(req.session.context.user) })
          if (y === -1) {
            y = doc.actors.findIndex((x) => { return x.user.equals && x.user.equals(req.session.context.user) })
          }
          if (y !== -1) {
            var actual = doc.actors[y]
            var role = actual.path === 'sent' ? 'to' : 'from'
            y = doc.actors.findIndex((x) => { return x.role === role })
            if (y !== -1) {
              doc.actor = { user: doc.actors[y].user, path: actual.role === 'copy' ? 'referred' : actual.path }
            }
          }
          for (const i in doc.actors) {
            user.push(doc.actors[i].user)
          }
          mongo.toHash('user', { _id: { $in: user } }, { _id: 1, name: 1 }, (er, users) => {
            var data = broadcastItem(req, mongo, send, doc, users, tagsDoc)
            var user = [req.session.context.user]
            notification.send(req, '', 'dtcorrespondence', data, user, deleted)
            var UsersTo = []
            var UsersCopy = []
            for (const i in doc.actors) {
              if (doc.actors[i].role === 'to') {
                UsersTo.push(doc.actors[i].user)
              }
              if (doc.actors[i].role === 'copy') {
                UsersCopy.push(doc.actors[i].user)
              }
              if (doc.actors[i].role === 'from') {
                doc.actor = doc.actors[i]
              }
            }
            var Data = broadcastItem(req, mongo, send, doc, users, tagsDoc)
            Data.path = 'received'
            Data.pathName = 'received'
            if (UsersTo.length > 0) { notification.send(req, '', 'dtcorrespondence', Data, UsersTo, deleted) }
            Data.path = 'referred'
            Data.pathName = 'referred'
            if (UsersCopy.length > 0) { notification.send(req, '', 'dtcorrespondence', Data, UsersCopy, deleted) }
          })
        })
      }
      function broadcastItem (req, mongo, send, doc, users, tagsDoc) {
        var tagsId = []
        tagsId.push(doc.tags)
        var usedTags = []
        if (tagsDoc[0]) {
          for (let t = 0; t < tagsDoc[0].options.length; t++) {
            for (let o = 0; o < tagsId.length; o++) {
              if (tagsId[o] && tagsDoc[0].options[t].id.toString() === tagsId[o].toString()) {
                usedTags.push(tagsDoc[0].options[t])
              }
            }
          }
        }
        var actor = doc.actor ? doc.actor : {}
        var username = actor.user ? (mongo.isNativeId(actor.user) && users[actor.user.toString()] ? users[actor.user.toString()].name : actor.user) : ''
        return row(doc, req, actor, username, usedTags)
      }

      function row (doc, req, actor, username, usedTags) {
        var issue = {}

        var deadline = {}
        for (const x in doc.dates) {
          if (doc.dates[x].type === 'issue') {
            issue = doc.dates[x]
          } else if (doc.dates[x].type === 'deadline') {
            deadline = doc.dates[x]
          }
        }
        var attachments = 'none'
        if (doc.files && doc.files.length > 0) {
          for (const x in doc.files) {
            if (doc.files[x]) {
              attachments = 'attachment'
            }
          }
        }
        const expired = doc.status === tags.processing && deadline.value && deadline.value.getTime() <= new Date().getTime() ? tags.expired : undefined
        var tagscolor = []
        var tagsname = []
        var filterNames = [usedTags[0] ? usedTags[0].value : '']
        for (const i in usedTags) {
          tagscolor.push(usedTags[i].color)
          tagsname.push(usedTags[i].value)
        }
        var row = {
          id: doc._id.toString(),
          attachments: attachments,
          expired: expired,
          css: expired || doc.status || tags.processing,
          status: doc.status ? doc.status : tags.processing,
          statusName: doc.status,
          role: actor.role,
          user: actor.user,
          userName: username,
          sequence: doc.sequence && doc.sequence.text ? doc.sequence.text : '',
          name: doc.name,
          path: actor.path,
          pathName: actor.path,
          issue: issue.value ? tags.util.date2str(issue.value, 'yyyy/mm/dd', tags) : '',
          category: doc.category || '',
          deadline: deadline.value ? tags.util.date2str(deadline.value, 'yyyy/mm/dd', tags) : '',
          tagscolor: tagscolor,
          tagsname: tagsname,
          filterNames: filterNames,
          issued: doc.issued
        }
        if (doc.type) { row.type = doc.type }
        return row
      }
    })
  }

  this.resend = function (req, mongo, send) {
    var doc = {}
    mongo.findId('document', req.body._id, (err, document) => {
      if (err) {
        send({ error: err })
      } else {
        doc = document
        var users = []
        var usersToURL = []
        for (const i in doc.actors) {
          users.push(doc.actors[i].user)
        }
        mongo.find('user', { _id: { $in: users } }, {}, {}, (err, usr) => {
          if (err) throw err
          var unlicensedTo = []; var unlicensedCopy = []
          for (const i in usr) {
            for (const j in users) {
              if (usr[i]._id.toString() === users[j].toString()) {
                for (const c in doc.actors) {
                  if (doc.actors[c].user.toString() === users[j].toString()) {
                    if (doc.actors[c].role === 'to') {
                      unlicensedTo.push(usr[i].email)
                      usersToURL.push(usr[i]._id.toString())
                    } else if (doc.actors[c].role === 'copy') {
                      unlicensedCopy.push(usr[i].email)
                      usersToURL.push(usr[i]._id.toString())
                    }
                  }
                }
              }
            }
          }
          mongo.findOne('settings', { _id: 'settings' }, (err, sett) => {
            if (err) throw err
            if (sett && sett.user && sett.password && (unlicensedTo.length > 0 || unlicensedCopy.length > 0) && sett.checkEmail === '1') {
              var secure = false
              var password
              try {
                password = tags.util.Decipher(sett.password)
              } catch (err) {
                password = ''
              }
              if (sett.security === 'ssl') { secure = true }

              const transporter = nodemailer.createTransport({
                host: sett.smtp,
                port: sett.port,
                secure: secure, // true for 465, false for other ports
                auth: {
                  user: sett.user,
                  pass: password
                },
                tls: {
                  rejectUnauthorized: false
                }
              })
              if (doc.type === 'redactor') { doc.type = 'document' }

              // setup email data with unicode symbols
              const message = {
                from: sett.user, // sender address
                to: unlicensedTo, // list of receivers
                cc: unlicensedCopy, // list of receivers
                subject: doc.name, // Subject line
                // text: 'Hello world?', // plain text body
                html: 'Nueva correspondencia en GPAX, haga click aqui para ver ' +
                  '<span class="h-entry p-name"><a class="u-uid" href="' + doc._id + '" style="display:none">' +
                  '</a><a class="u-url" href="' + req.headers.referer + 'api/user.goURL?users='+usersToURL+'&url=document.' + doc.type + '?_id=' + doc._id + '$issued=' + doc.issued + '$status=' + doc.status +'">' + doc.name + '</a></span>⁠&nbsp;' // html body
              }

              // send mail with defined transport object
              transporter.sendMail(message, (error, info) => {
                if (error) {
                  console.log(error)
                  notification.saveSystemNotification(req, mongo, null, 'Error al enviar correo: ' + error.message)
                } else {
                  console.log('Message sent: %s', info.messageId)
                  send()
                }
              })
            }
          })
        })
      }
    })
  }

  this.saveautoTime = function (req, mongo, send) {
    var data = req.query

    data = {
      _id: data._id,
      user: data.user,
      time: data.time,
      startTime: new Date(1 * data.startTime)
    }

    mongo.findId('document', data._id, (err, docs) => {
      if (err) send({ error: err })
      else {
        var doc = { _id: data._id }
        if (docs && docs.logtime && docs.logtime.length >= 1) {
          doc.logtime = docs.logtime
        } else {
          doc.logtime = []
        }
        doc.logtime.push({
          user: data.user,
          time: data.time,
          dateTime: data.startTime
        })

        mongo.save('document', doc, (err) => {
          if (err) {
            send({ error: tags.savingProblema })
          } else {
            send({ message: tags.savedChanges })
          }
        })
      }
    })
  }
  this.addActors = function (req, id, actors, mongo, next) {
    mongo.findId('document', id, { actors: 1, issued: 1 }, (err, doc) => {
      if (err || !doc) {
        next(err)
      } else {
        for (const i in actors) {
          const rm = doc.actors.findIndex((actor) => { return actor.user === actors[i].user })
          if (rm === -1) {
            doc.actors.push(actors[i])
          }
        }
        mongo.save('document', doc, (err) => {
          next(err, doc)
        })
      }
    })
  }
  this.addActor = function (id, role, actors, mongo) {
    actors = actors.filter(function (el) {
      return el.role !== role
    })
    var vec = ['']
    if (role === 'from' && id.length !== 54) {
      vec = id
    } else if (id.split) {
      vec = id.split(',')
    }
    if (vec[0] !== '') {
      for (const i in vec) {
        const ids = vec[i].split('&unit=')
        if (mongo.isNativeId(ids[0]) && mongo.isNativeId(ids[1])) {
          var user = mongo.toId(ids[0])
          actors = actors.filter(function (el) {
            return el.user !== user.toString()
          })
          actors.push({ user: user, path: role === 'from' ? 'sent' : 'hidden', role: role, unit: mongo.toId(ids[1]) })
        }
      }
    }
    return actors
  }

  this.saveLink = function (req, mongo, send) {
    mongo.findId('document', req.body._id, (err, doc) => {
      if (err) {
        req.statusCode = 400
        send({ error: err })
      } else if (doc) {
        if (doc.links && typeof doc.links === 'object' && typeof req.body.links === 'object') {
          for (const i in req.body.links) {
            const y = doc.links.findIndex((x) => {
              return x._id.toString() === req.body.links[i]._id
            })
            if (y === -1) {
              doc.links.push(req.body.links[i])
            }
          }
        } else {
          doc.links = []
          if (typeof req.body.links === 'object') {
            for (const i in req.body.links) {
              doc.links.push(req.body.links[i])
            }
          }
        }
        mongo.save('document', doc, (err) => {
          if (err) {
            send()
          } else {
            send({ message: tags.savedChanges })
          }
        })
      } else {
        send(req.status = 400)
      }
    })
  }

  this.removeLink = function (req, mongo, send) {
    mongo.findId('document', req.body._id, { links: 1 }, (err, doc) => {
      if (err) {
        req.status = 400
        send({ error: err })
      } else if (doc) {
        const y = doc.links.findIndex((x) => { return x._id.toString() === req.body.link })
        if (y !== -1) {
          doc.links.splice(y, 1)
        }
        mongo.save('document', doc, (err) => {
          if (err) {
            send()
          } else {
            send({ message: tags.savedChanges })
          }
        })
      } else {
        send(req.status = 400)
      }
    })
  }

  this.save = function (req, mongo, send) {
    mongo.findId('document', req.body._id, (err, docs) => {
      if (err) {
        send({ error: err })
      } else {
        const doc = req.body
        var date = new Date()
        mongo.find('time', { document: mongo.toId(doc.task), project: mongo.toId(doc.project), $and: [{ date: { $gte: new Date(new Date(date).setHours(0, 0, 0, 0)) } }, { date: { $lte: new Date(new Date(date).setHours(23, 59, 59)) } }], user: req.session.context.user }, {}, {}, (err, time) => {
          if (err) throw err
          mongo.findId('project', mongo.toId(doc.project), (err, project) => {
            if (err) throw err
            if (docs) {
              doc.actors = docs.actors
              if (!doc.status) { doc.status = docs.status }
            }
            if (doc.status === 'docReady') {
              doc.status = 'ready'
              for (const i in doc.actors) {
                switch (doc.actors[i].role) {
                case 'reviser':
                  doc.actors[i].path = 'sent'
                  break
                case 'from':
                case 'supervisor':
                  doc.actors[i].path = 'sent'
                  doc.actors[i].role = 'supervisor'
                  break
                }
              }
            }
            if (!doc.commitment && !doc.evidence) {
              if (doc.from) {
                doc.actors = this.addActor(doc.from, tags.from, doc.actors, mongo)
              }
              if (doc.to && Array.isArray(doc.to)) {
                doc.actors = this.addActor(doc.to, tags.to, doc.actors, mongo)
              }
              if (doc.copy && Array.isArray(doc.copy)) {
                doc.actors = this.addActor(doc.copy, tags.copy, doc.actors, mongo)
              }
            } else if (doc.commitment || doc.evidence) {
              const ids = []
              doc.actors.findIndex((x) => {
                if (x.role === 'inCharge' || x.role === 'supervisor' || x.role === 'from') {
                  ids.push(x.user)
                }
              })

              ids.forEach(y => {
                doc.actors.forEach(function (element, index) {
                  if (element.user.toString() === y.toString() && (element.role !== 'inCharge' && element.role !== 'supervisor' && element.role !== 'from')) {
                    doc.actors.splice(index, 1)
                  }
                })
              })
            }
            delete doc.comment
            delete doc.user
            delete doc.timeString
            delete doc.isNew
            delete doc.delegates
            delete doc.mentions
            delete doc.creator
            delete doc.lastModification

            var units = req.session.units || []
            for (const i in doc.actors) {
              if (doc.actors[i].user === req.session.context.user.toString() && doc.actors[i].unit) {
                units = [mongo.toId(doc.actors[i].unit)]
                break
              }
            }
            var readers = []
            for (const i in doc.actors) {
              if (doc.actors[i].unit) {
                if (doc.actors[i].role === tags.from || units.findIndex(function (x) { return x.toString() === doc.actors[i].unit }) !== -1) {
                  readers.push(doc.actors[i].user)
                }
              }
            }
            // Add or update dates.issue
            if (doc.dates && doc.dates.length > 0) {
              doc.dates[0].value = new Date()
            } else {
              doc.dates = [{ type: tags.issue, value: new Date() }]
            }
            if (doc.deadline) {
              doc.dates[1] = { type: tags.deadline, value: doc.deadline }
              delete doc.deadline
            }
            html.getData((doc.type === 'redactor' || doc.type === 'document') ? doc.content : '', (data) => {
              if (data.links && data.links.length > 0) {
                if (!doc.links) {
                  doc.links = (docs && docs.links) ? docs.links : []
                }
                for (const i in data.links) {
                  if (doc.links.findIndex((lk) => { return lk._id === data.links[i]._id }) === -1) {
                    doc.links.push({ _id: data.links[i]._id, clase: data.links[i].clase })
                  }
                }
              }
              if (doc.links && doc.links[0] === '{}') {
                delete doc.links
              }
              if (doc.tags === '') {
                doc.tags = []
              } else {
                doc.tags = doc.tags.split(',')
                for (const i in doc.tags) {
                  doc.tags[i] = mongo.toId(doc.tags[i])
                }
              }
              mongo.save('document', doc, (err) => {
                if (err) {
                  send()
                } else {
                  if ((doc.status === 'processing' || doc.status === 'done' || doc.status === 'incomplete' || doc.status === 'completed') && doc.reference) {
                    notification.Okcompromise(req, doc.name, doc.status, doc.actors, doc._id)
                  }
                  if (!docs && doc.project && req.session.context.autoTimer) {
                    var Obj = {}
                    var name = ''
                    for (const i in project.content.data) {
                      if (project.content.data[i].id.toString() === doc.task.toString()) name = project.content.data[i].text
                    }
                    if (doc.type === 'redactor') { doc.type = 'document' }
                    if (time.length > 0) {
                      Obj._id = time[0]._id
                      for (const d in time[0].docs) {
                        time[0].docs[d] = time[0].docs[d].toString()
                      }
                      var index = time[0].docs.indexOf(doc._id.toString())
                      if (index === -1) {
                        if (!time[0].docs) time[0].docs = []
                        time[0].docs.push(doc._id)
                        Obj.docs = time[0].docs
                      }
                      if (!time[0].open) { Obj.start = new Date() }
                      Obj.comment = time[0].comment + '<br><span class="h-entry p-name"><a class="u-uid" href=' + doc._id + ' style="display:none;"></a><a class="u-url" href="document.' + doc.type + '?_id=' + doc._id + '">' + doc.name + ' ' + dateformat(new Date(), 'yyyy/mm/dd') + '</a></span>⁠'
                    } else {
                      Obj._id = mongo.newId()
                      Obj.user = req.session.context.user
                      Obj.date = date
                      Obj.start = new Date()
                      Obj.docs = [doc._id]
                      Obj.duration = '0'
                      Obj.status = 'draft'
                      Obj.type = 'task'
                      Obj.document = doc.task
                      Obj.task = name
                      Obj.plan = project.plan
                      Obj.project = doc.project
                      Obj.comment = '<span class="h-entry p-name"><a class="u-uid" href=' + doc._id + ' style="display:none;"></a><a class="u-url" href="document.' + doc.type + '?_id=' + doc._id + '">' + doc.name + ' ' + dateformat(new Date(), 'yyyy/mm/dd') + '</a></span>⁠'
                      Obj.open = true
                    }
                    mongo.save('time', Obj, () => {
                      send({ message: tags.savedChanges })
                      this.sendNotification(req, mongo, send, doc)
                    })
                  } else {
                    send({ message: tags.savedChanges })
                    this.sendNotification(req, mongo, send, doc)
                  }
                  if (!docs && doc.task) {
                    req.body.data = ['create', doc._id, doc.task]
                    req.app.routes.project.documentEvent(req, mongo, () => { })
                  }
                }
              })
            })
          })
        })
      }
    })
  }
  this.sendNotification = function (req, mongo, send, doc, deleted) {
    if (doc) {
      doc.id = doc._id
    } else {
      doc={}
    }
    mongo.find('params', { name: 'tag' }, { _id: 1, name: 1, options: 1 }, (er, tagsDoc) => {
      var user = []
      var y = doc.actors.findIndex((x) => { return x.role !== 'reviser' && x.user.equals && x.user.equals(req.session.context.user) })
      if (y === -1) {
        y = doc.actors.findIndex((x) => { return x.user.equals && x.user.equals(req.session.context.user) })
      }
      if (y !== -1) {
        var actual = doc.actors[y]
        var role = actual.path === 'sent' ? 'to' : 'from'
        y = doc.actors.findIndex((x) => { return x.role === role })
        if (y !== -1) {
          doc.actor = { user: doc.actors[y].user, path: actual.role === 'copy' ? 'referred' : actual.path }
        }
      }
      if (!doc.actor) {
        doc.actor = doc.actors[0]
      }
      user.push(doc.actor.user)
      mongo.toHash('user', { _id: { $in: user } }, { _id: 1, name: 1 }, (er, users) => {
        if (doc.issued === 1) {
          var data = this.broadcastItem(req, mongo, send, doc, users, tagsDoc)
          var Users = []
          for (const i in doc.actors) {
            if (doc.actors[i].path !== 'hidden') {
              Users.push(doc.actors[i].user)
            }
          }
          notification.send(req, req.session.context.room, 'dtcorrespondence', data, Users, deleted)
        }
        if (doc.project) {
          this.broadcastItem(req, mongo, send, doc, users, tagsDoc)
          notification.send(req, req.session.context.room, 'projectDocuments.' + doc.project.toString(), data, null, deleted)
          if (doc.task) {
            notification.send(req, req.session.context.room, 'taskDocuments.' + doc.task.toString(), { id: doc._id.toString() }, null, deleted)
          }
        }
      })
    })
  }
  this.print = function (req, mongo, send) {
    mongo.findId('document', req.query._id, (err, doc) => {
      if (err) send({ error: err })
      else {
        send(html.print(doc.content))
      }
    })
  }

  this.pdf = function (req, mongo, send) {
    mongo.findId('document', req.query._id, async (err, doc) => {
      if (!err && doc) {
        var i = 0
        while (doc.content.indexOf('{{', i) !== -1 && doc.content.substring(doc.content.indexOf('{{', i), doc.content.indexOf('{{', i) + 1) === '{') {
          i = doc.content.indexOf('{{', i)
          const f = doc.content.indexOf('}}', i)
          const word = doc.content.substring(i + 2, f)
          if (!['page', 'pages'].includes(word)) {
            doc.content = doc.content.replace(new RegExp('{{' + word + '}}', 'g'), '')
          }
          i = f + 2
        }

        let user
        doc.actors.forEach(x => {
          if (x.path === 'sent' && x.role === 'reviser') { user = x.user } else if (x.path === 'sent' && x.role === 'from') { user = x.user }
        })
        if (doc.project) {
          var proj = await new Promise(resolve => {
            mongo.findId('project', doc.project, (err, project) => {
              if (!err) {
                resolve(project)
              }
            })
          })
        }
        if (user) {
          var us = await new Promise(resolve => {
            mongo.findId('user', user, (err, user) => {
              if (!err) {
                resolve(user)
              }
            })
          })
        }
        var last = await req.logger.lastAuthor(mongo, mongo.toId(req.query._id), 'document')
        let creator = await req.logger.firstAuthor(mongo, mongo.toId(req.query._id), 'document')
        //let i,
        var fit
        if (doc.content.indexOf('id="pageFooter-last"') !== -1 || doc.content.indexOf('id=\'pageFooter-last\'') !== -1) {
          i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter-last"'))
          if (!i) { i = doc.content.indexOf('>', doc.content.indexOf('id=\'pageFooter-last\'')) }
          fit = doc.content.slice(0, i + 1)
          last = doc.content.slice(i + 1)
          doc.content = fit +
            (req.query.details ?
              ('<span style="position:relative;font-size: xx-small; top:0em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + creator.name + ', Generado el: ' + moment().format('MM-DD-YYYY') + ', Última modificación: ' + us.name + ' el día ' + moment(last.when).format('MM-DD-YYYY') + '</span>') + last :
              ('<span style="position:relative;font-size: xx-small; top:0em; left:0em;">Creador: ' + creator.name + ', Última modificación: ' + last.name + ' el día ' + moment(last.when).format('MM-DD-YYYY') + '</span>') + last)
          // doc.content.slice(0, i+1) + ('<div style="position:relative;font-size: xx-small; top:7em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().subtract(10, 'days').calendar() + '</div>') + doc.content.slice(i+1);
        } else if (doc.content.indexOf('id="pageFooter"') !== -1 || doc.content.indexOf('id=\'pageFooter\'') !== -1) {
          i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter"'))
          if (!i) { i = doc.content.indexOf('>', doc.content.indexOf('id=\'pageFooter\'')) }
          fit = doc.content.slice(0, i + 1)
          last = doc.content.slice(i + 1)
          doc.content = fit +
            (req.query.details ?
              ('<span style="position:relative;font-size: xx-small; top:0em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().format('MM-DD-YYYY') + ', Última modificación: ' + us.name + ' el día ' + moment(last.when).format('MM-DD-YYYY') + '</span>') + last :
              ('<span style="position:relative;font-size: xx-small; top:0em; left:0em;">Creador: ' + creator.name + ', Última modificación: ' + us.name + ' el día ' + moment(last.when).format('MM-DD-YYYY') + '</span>') + last)
        } else {
          doc.content = doc.content +
            (req.query.details ?
              '<div id="pageFooter" ><div style="position:relative;font-size: xx-small; top:0em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().format('MM-DD-YYYY') + ', Última modificación: ' + us.name + ' el día ' + moment(last.when).format('MM-DD-YYYY') + '</div></div>' :
              '<div id="pageFooter" ><div style="position:relative;font-size: xx-small; top:0em; left:0em;">Creador: ' + creator.name + ', Última modificación: ' + us.name + ' el día ' + moment(last.when).format('MM-DD-YYYY') + '</div></div>')
        }

        html.pdf(mongo, req, doc.content, doc.pageType, (err, stream) => {
          if (err) {
            send({ error: err })
          } else {
            send(stream)
          }
        })
      } else {
        send({ error: err })
      }
    })
  }

  this.deleteReviser = function (req, mongo, send) {
    mongo.findId('document', req.query.idDoc, (err, doc) => {
      if (err) {
        req.logger.log(err)
      } else {
        const index = doc.actors.findIndex((x) => {
          return x.user.toString() === req.query.id
        })
        doc.actors.splice(index, 1)
        mongo.save('document', doc, (err) => {
          if (err) {
            req.logger.log(err)
          } else {
            send({})
          }
        })
      }
    })
  }
  this.allReviewed = function (req, mongo, send) {
    var data = req.body

    for (const i in data.ids) {
      if (mongo.isNativeId(data.ids[i])) {
        data.ids[i] = mongo.toId(data.ids[i])
      }
    }

    var keys = { _id: { $in: data.ids }, status: { $ne: 'reviewed' } }

    mongo.find('document', keys, { _id: 1, name: 1 }, { _id: -1 }, (err, docs) => {
      if (err || !docs) {
        send({ docsWithoutReview: 0 })
      } else {
        send({ docsWithoutReview: docs.length })
      }
    })
  }

  this.autoReview = function (req, mongo, send) {
    var data = req.body

    for (const i in data.ids) {
      if (mongo.isNativeId(data.ids[i])) {
        data.ids[i] = mongo.toId(data.ids[i])
      }
    }

    var keys = { _id: { $in: data.ids }, status: { $ne: 'reviewed' } }

    mongo.find('document', keys, { _id: 1, name: 1, category: 1, status: 1, actors: 1, 'sequence.text': 1, dates: 1, files: 1, history: 1 }, { _id: -1 }, (err, docs) => {
      if (err || !docs) {
        send({ error: err })
      } else {
        mongo.find('note', keys, { _id: 1, name: 1, category: 1, status: 1, actors: 1 }, { _id: -1 }, async (err, notes) => {
          if (err) {
            send({ error: err })
          } else {
            if (docs && docs.length > 0) {
              for (const d in docs) {
                docs[d].status = 'reviewed'
                if (docs[d].history && typeof docs[d].history === 'object') { docs[d].history.push(data.comment) } else { docs[d].history = [data.comment] }
                await new Promise(resolve => {
                  mongo.save('document', docs[d], (err) => {
                    if (err) {
                      resolve()
                    } else {
                      resolve()
                    }
                  })
                })
              }
            }
            send({ message: tags.savedChanges })
          }
        })
      }
    })
  }
  this.rels = function (req, mongo, send) {
    var _id = mongo.toId(req.query._id)
    mongo.findId('document', _id, { links: 1, project: 1 }, (err, doc) => {
      if (err) throw err
      var links = []
      if (doc && doc.links) {
        for (const i in doc.links) {
          links.push(doc.links[i]._id || doc.links[i])
        }
      }
      var keys = {
        $or: [
          { $eq: ['$links._id', _id] },
          { $in: ['$_id', links] }
          //{ 'links._id': _id },
          //{ _id: { $in: links } }
        ]
      }
      if (doc.project) req.query.project = doc.project
      this.ofProject(req, mongo, send, keys)
    })
  }
  this.ofTask = function (req, mongo, send) {
    var task = mongo.toId(req.query.task)
    var pipeline = [
      { $match: { _id: task } },
      {
        $lookup: {
          from: 'document', as: 'docs', let: { documents: '$documents', task: '$_id' },
          pipeline: [
            { $match: { $expr: { $or: [{ $in: ['$_id', { $cond: { if: { $isArray: '$$documents' }, then: '$$documents', else: ['$$documents'] } }] }, { $eq: ['$task', '$$task'] }] } } },
            {
              $addFields: {
                actor: {
                  $arrayElemAt: [{
                    $filter: {
                      input: '$actors',
                      as: 'item',
                      cond: { $eq: ['$$item.path', 'sent'] }
                    }
                  }, 0]
                }
              }
            },
            { $lookup: { from: 'user', localField: 'actor.user', foreignField: '_id', as: 'user' } },
            { $unwind: { path: '$user', preserveNullAndEmptyArrays: true } },
            {
              $lookup: {
                from: 'params', as: 'tags', let: { tags: '$tags' },
                pipeline: [
                  { $unwind: '$options' },
                  { $match: { $expr: { $in: ['$options.id', { $cond: { if: { $isArray: '$$tags' }, then: '$$tags', else: ['$$tags'] } }] } } },
                  { $project: { color: '$options.color', name: '$options.value' } }
                ]
              }
            },
            {
              $project: {
                _id: 0,
                id: '$_id', css: '$status', result: '$result', status: '$status', statusName: '$status', role: 'reviser',
                user: '$user._id', userName: '$user.name', sequence: '$sequence.text', name: '$name',
                path: '$actor.path', pathName: '$actor.path', issue: '$issue',
                tagscolor: '$tags.color', tagsname: '$tags.name', filterNames: '$tags.name',
                type: '$type', task: { $ifNull: ['$task', '$$task'] }
              }
            }
          ]
        }
      },
      {
        $lookup: {
          from: 'note', as: 'notes', let: { documents: '$documents', task: '$_id' },
          pipeline: [
            { $match: { $expr: { $or: [{ $in: ['$_id', { $cond: { if: { $isArray: '$$documents' }, then: '$$documents', else: ['$$documents'] } }] }, { $eq: ['$task', '$$task'] }] } } },
            {
              $addFields: {
                actor: {
                  $arrayElemAt: [{
                    $filter: {
                      input: '$actors',
                      as: 'item',
                      cond: { $eq: ['$$item.path', 'sent'] }
                    }
                  }, 0]
                }
              }
            },
            { $lookup: { from: 'user', localField: 'actor.user', foreignField: '_id', as: 'user' } },
            { $unwind: { path: '$user', preserveNullAndEmptyArrays: true } },
            {
              $lookup: {
                from: 'params', as: 'tags', let: { tags: '$tags' },
                pipeline: [
                  { $unwind: '$options' },
                  { $match: { $expr: { $in: ['$options.id', { $cond: { if: { $isArray: '$$tags' }, then: '$$tags', else: ['$$tags'] } }] } } },
                  { $project: { color: '$options.color', name: '$options.value' } }
                ]
              }
            },
            {
              $project: {
                _id: 0,
                id: '$_id', css: '$status', status: '$status', statusName: '$status', role: 'reviser',
                user: '$user._id', userName: '$user.name', sequence: '$sequence.text', name: '$name',
                path: '$actor.path', pathName: '$actor.path', issue: '$issue',
                tagscolor: '$tags.color', tagsname: '$tags.name', filterNames: '$tags.name',
                type: 'note', task: { $ifNull: ['$task', '$$task'] }
              }
            }
          ]
        }
      },
      { $project: { docs: { $concatArrays: ['$docs', '$notes'] } } },
      { $unwind: '$docs' },
      { $replaceRoot: { newRoot: '$docs' } },
      { $sort: { name: 1 } }
    ]
    mongo.aggregate('task', pipeline, {}, (err, docs) => {
      if (err) {
        send({ error: err })
      } else {
        send(docs)
      }
    })
  }
  this.ofProject = function (req, mongo, send, rels) {
    var project = mongo.toId(req.query.project)
    var pipeline = [
      { $match: project ? { _id: project } : {} },
      {
        $lookup: {
          from: 'document', as: 'docs', let: { project: '$_id' },
          pipeline: [
            { $match: { $expr: rels ? rels : { $eq: ['$project', '$$project'] } } },
            {
              $addFields: {
                actor: {
                  $arrayElemAt: [{
                    $filter: {
                      input: '$actors',
                      as: 'item',
                      cond: { $eq: ['$$item.path', 'sent'] }
                    }
                  }, 0]
                },
                typeTags: { $type: '$tags' }
              }
            },
            { $lookup: { from: 'user', localField: 'actor.user', foreignField: '_id', as: 'user' } },
            { $unwind: { path: '$user', preserveNullAndEmptyArrays: true } },
            {
              $lookup: {
                from: 'params', as: 'tags', let: { tags: '$tags', typeTags: '$typeTags' },
                pipeline: [
                  { $match: { $expr: { $eq: ['$name', 'tag'] } } },
                  { $unwind: '$options' },
                  { $match: { $expr: { $in: ['$options.id', { $cond: [{ $eq: ['$$typeTags', 'array'] }, '$$tags', []] }] } } },
                  { $project: { color: '$options.color', name: '$options.value' } }
                ]
              }
            },
            {
              $lookup: {
                from: 'params', as: 'versionP', let: { tags: '$version' },
                pipeline: [
                  { $match: { $expr: { $eq: ['$name', 'version'] } } },
                  { $unwind: '$options' },
                  { $match: { $expr: { $eq: ['$options.id', '$$tags'] } } },
                  { $project: { color: '$options.color', name: '$options.value' } }
                ]
              }
            },
            {
              $project: {
                _id: 0,
                id: '$_id', css: '$status', result: '$result', status: '$status', statusName: '$status', role: 'reviser',
                user: '$user._id', userName: '$user.name', sequence: '$sequence.text', name: '$name',
                path: '$actor.path', pathName: '$actor.path', issue: '$issue',
                tagscolor: '$tags.color', tagsname: '$tags.name', filterNames: '$tags.name',
                version: { $cond: [{ $gt: ['$version', null] }, { $ifNull: [{ $arrayElemAt: ['$versionP.name', 0] }, 'Sin etiqueta'] }, ''] },
                versionColor: { $cond: [{ $gt: ['$version', null] }, { $ifNull: [{ $arrayElemAt: ['$versionP.color', 0] }, '#e2e2e2'] }, ''] },
                type: '$type', task: '$task'
              }
            }
          ]
        }
      },
      {
        $lookup: {
          from: 'note', as: 'notes', let: { project: '$_id' },
          pipeline: [
            { $match: { $expr: rels ? rels : { $eq: ['$project', '$$project'] } } },
            {
              $addFields: {
                actor: {
                  $arrayElemAt: [{
                    $filter: {
                      input: '$actors',
                      as: 'item',
                      cond: { $eq: ['$$item.path', 'sent'] }
                    }
                  }, 0]
                },
                typeTags: { $type: '$tags' }
              }
            },
            { $lookup: { from: 'user', localField: 'actor.user', foreignField: '_id', as: 'user' } },
            { $unwind: { path: '$user', preserveNullAndEmptyArrays: true } },
            {
              $lookup: {
                from: 'params', as: 'tags', let: { tags: '$tags', typeTags: '$typeTags' },
                pipeline: [
                  { $match: { $expr: { $eq: ['$name', 'tag'] } } },
                  { $unwind: '$options' },
                  { $match: { $expr: { $in: ['$options.id', { $cond: [{ $eq: ['$$typeTags', 'array'] }, '$$tags', []] }] } } },
                  { $project: { color: '$options.color', name: '$options.value' } }
                ]
              }
            },
            {
              $project: {
                _id: 0,
                id: '$_id', css: '$status', status: '$status', statusName: '$status', role: 'reviser',
                user: '$user._id', userName: '$user.name', sequence: '$sequence.text', name: '$name',
                path: '$actor.path', pathName: '$actor.path', issue: '$issue',
                tagscolor: '$tags.color', tagsname: '$tags.name', filterNames: '$tags.name',
                type: 'note', task: '$task'
              }
            }
          ]
        }
      },
      { $project: { docs: { $concatArrays: ['$notes', '$docs'] } } },
      { $unwind: '$docs' },
      { $replaceRoot: { newRoot: '$docs' } },
      { $sort: { name: 1 } }
    ]
    mongo.aggregate('project', pipeline, {}, (err, docs) => {
      if (err) {
        send({ error: err })
      } else {
        send(docs)
      }
    })
  }
  this.list = async function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    var keys = {
      $or: [
        { 'actors.user': req.session.context.user }
      ]
    }
    if (req.session.context.readerUnits && req.session.context.readerUnits.length > 0) {
      keys.$or.push({
        $and: [
          { unit: { $in: req.session.context.readerUnits } },
          { status: 'archived' }
        ]
      })
    }
    var units = []
    units=units.concat(req.session.context.managerUnits)
    units=units.concat(req.session.context.assistantUnits)
    units=units.concat(req.session.context.dependentUnits)
    keys.$or.push({ unit: { $in: units } })
    /* apply filter in parameters */
    if (req.query.filter) {
      var query = {}
      for (const name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          if (name === 'user') {
            query['actors.0.user'] = mongo.toId(req.query.filter.user)
          } else if (name === 'planName') {
            query['project.plan'] = mongo.toId(req.query.filter.planName)
          } else if (name === 'projectName') {
            query['project._id'] = mongo.toId(req.query.filter.projectName)
          } else if (name === 'tagsname') {
            query.tags = mongo.toId(req.query.filter.tagsname)
          } else if (name === 'version') {
            if (req.query.filter.version === 'onlyEmpty') {
              query.$and = [{ version: '' }, { version: { $exists: 1 } }]
            } else {
              query.version = mongo.toId(req.query.filter.version)
            }
          } else if (name === 'name') {
            const text = req.query.filter.name
            query.name = new RegExp(text,'i')
          } else if (name === '_id') {
            var ids = req.query.filter[name].split(',')
            for (const i in ids) {
              if (mongo.isNativeId(ids[i])) {
                ids[i] = mongo.toId(ids[i])
              }
            }
            query[name] = { $in: ids }
          } else if (name === 'links._id' && req.query.filter[name] !== 'undefined') {
            query.$or = [{ 'links._id': mongo.toId(req.query.filter[name]) }]
          } else if (name === 'links') {
            ids = req.query.filter[name].split(',')
            for (const i in ids) {
              if (mongo.isNativeId(ids[i])) {
                ids[i] = mongo.toId(ids[i])
              }
            }
            query.$or.push({ _id: { $in: ids } })
          } else if (req.query.filter[name] !== 'default') {
            query[name] = req.query.filter[name].indexOf(',') !== -1 ? { $in: req.query.filter[name].split(',') } : new RegExp(req.query.filter[name].replace(/ /g, '.*'), 'i')
          } else if (req.query.filter[name] === 'default') {
            query[name] = { $ne: 'archived' }
          }
        }
      }
      delete query.filterNames
      if (Object.keys(query).length) {
        keys = { $and: [keys, query] }
      }
    }
    var pipeline = [
      { $lookup: { from: 'project', localField: 'project', foreignField: '_id', as: 'project' } },
      { $match: keys },
      { $sort: { id: -1 } },
      { $skip: skip },
      { $limit: limit },
      { $lookup: { from: 'plan', localField: 'project.plan', foreignField: '_id', as: 'plan' } },
      { $addFields: {user: {$arrayElemAt: ['$actors.user',0]}} },
      { $lookup: { from: 'user', localField: 'user', foreignField: '_id', as: 'user' } },
      {
        $lookup: {
          from: 'params', let: { ids: {$cond: { if: { $isArray: '$tags' },then: '$tags',else: ['$tags']}} }, as: 'tags', pipeline: [
            { $match: { $expr: { $eq: ['$name', 'tag'] } } },
            { $unwind: '$options' },
            { $replaceRoot: { newRoot: '$options' } },
            { $match: { $expr: { $in: ['$id', '$$ids'] } } }
          ]
        }
      },
      {
        $lookup: {
          from: 'version', as: 'version', let: { id: '$_id' }, pipeline: [
            { $match: { $expr: { $eq: ['$data._id', '$$id'] } } },
            { $sort: { _id: -1 } },
            { $limit: 1 },
            { $project: { lastEdit: { $toDate: '$_id' } } }
          ]
        }
      },
      {
        $project: {id: '$_id',name: 1, status: 1,statusName: '$status',css: '$status', attachments: '',sequence: '', lastEdit: { $arrayElemAt: ['$version.lastEdit', 0] }, type: 1, tagscolor: '$tags.color', tagsname: '$tags.value', user: { $arrayElemAt: ['$user._id', 0] }, project: '$project._id', plan: { $arrayElemAt: ['$plan._id', 0] },
          planName: { $arrayElemAt: ['$plan.name', 0] }, projectName: { $arrayElemAt: ['$project.name', 0] }, userName: { $arrayElemAt: ['$user.name', 0] }
        }
      }
    ]
    mongo.aggregate('document', pipeline, { allowDiskUse: true }, (err, docs) => {
      if (err) {
        send({ error: err })
      } else {
        reply = { data: docs, pos: skip, total_count: 0 }
        pipeline = [
          { $lookup: { from: 'project', localField: 'project', foreignField: '_id', as: 'project' } },
          { $match: keys },
          { $group: { _id: null, count: { $sum: 1 } } }
        ]
        mongo.aggregate('document', pipeline, { allowDiskUse: true }, (err, res) => {
          if (!err && res && res[0]) {
            reply.total_count = res[0].count
          }
          send(reply)
        })
      }
    })
  }
  this.documentsToReady = function (req, mongo, send) {
    var data = req.body

    for (const i in data.ids) {
      if (mongo.isNativeId(data.ids[i])) {
        data.ids[i] = mongo.toId(data.ids[i])
      }
    }

    var keys = { _id: { $in: data.ids } }

    mongo.find('document', keys, { _id: 1, name: 1, category: 1, status: 1, actors: 1 }, { _id: -1 }, (err, docs) => {
      if (err) {
        send({ error: err })
      } else {
        mongo.find('note', keys, { _id: 1, name: 1, category: 1, status: 1, actors: 1 }, { _id: -1 }, async (err, notes) => {
          if (err) {
            send({ error: err })
          } else if (data.status === 'done') {
            if (docs && docs.length > 0) {
              for (const d in docs) {
                if (docs[d].status === 'draft') {
                  docs[d].status = 'ready'
                  await new Promise(resolve => {
                    mongo.save('document', docs[d], (err) => {
                      if (err) {
                        resolve()
                      } else {
                        resolve()
                      }
                    })
                  })
                }
              }
            }
            send({ message: tags.savedChanges })
          } else { send() }
        })
      }
    })
  }
  this.pivot = function (req, mongo, send, rels) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    mongo.find('params', { name: 'tag' }, { options: 1 }, (er, tags) => {
      tags = tags[0].options
      mongo.toHash('user', {}, { name: 1 }, (er, users) => {
        mongo.toHash('unit', {}, { name: 1 }, (err, units) => {
          var keys = {
            $and: [
              {
                $or: [
                  { actors: { $elemMatch: { user: req.session.context.user, path: { $ne: 'hidden' } } } },
                  {
                    $and: [
                      { actors: { $elemMatch: { unit: { $in: req.session.context.memberUnits }, path: { $ne: 'hidden' } } } },
                      { confidential: { $ne: '1' } }
                    ]
                  }
                ]
              },
              { 'sequence.text': { $exists: 1 } }
            ]
          }
          mongo.findN('document', skip, limit, keys, { actors: 1, name: 1, status: 1, dates: 1, sequence: 1 }, (er, docs) => {
            if (er) {
              send({ error: err })
            } else {
              var reply = []
              var doc
              for (const i in docs) {
                doc = docs[i]
                for (const j in doc.actors) {
                  const actor = doc.actors[j]
                  if (actor.role === 'from' && actor.path === 'sent') {
                    doc.de = actor.user && users[actor.user] ? users[actor.user].name : ''
                    doc.unidadDe = actor.unit && units[actor.unit] ? units[actor.unit].name : ''
                  } else if (actor.role === 'to') {
                    doc.para = actor.user && users[actor.user] ? users[actor.user].name : ''
                    doc.unidadPara = actor.unit && units[actor.unit] ? units[actor.unit].name : ''
                  } else if (actor.role === 'copy') {
                    doc.copia = actor.user && users[actor.user] ? users[actor.user].name : ''
                    doc.unidadCopia = actor.unit && units[actor.unit] ? units[actor.unit].name : ''
                  }
                }
                for (const j in doc.dates) {
                  if (doc.dates[j].type === 'issue') {
                    var date = new Date(doc.dates[j].value)
                    doc['año'] = date.getFullYear()
                    doc.mes = date.getMonth()
                    doc.dia = date.getDate()
                  } else if (doc.dates[j].type === 'deadline') {
                    doc['añoVence'] = date.getFullYear()
                    doc.mesVence = date.getMonth()
                    doc.diaVence = date.getDate()
                  }
                }
                doc.asunto = doc.name
                doc.consecutivo = doc.sequence.text
                doc.estado = docs.status
                delete doc.actors
                delete doc.name
                delete doc.status
                delete doc.dates
                delete doc.sequence
                reply.push(doc)
              }
              if (req.query.continue) {
                send(reply)
              } else {
                mongo.count('document', keys, (err, count) => {
                  if (!err && count) {
                    reply.total_count = count
                  }
                  send(reply)
                })
              }
            }
          })
        })
      })
    })
  }

  this.broadcastItem = function (req, mongo, send, doc, users, tagsDoc) {
    var tagsId = []
    for (const t in doc.tags) {
      tagsId.push(doc.tags[t])
    }
    var usedTags = []
    if (tagsDoc[0]) {
      for (let t = 0; t < tagsDoc[0].options.length; t++) {
        for (let o = 0; o < tagsId.length; o++) {
          if (tagsId[o] && tagsDoc[0].options[t].id.toString() === tagsId[o].toString()) {
            usedTags.push(tagsDoc[0].options[t])
          }
        }
      }
    }
    var username
    if (doc.actor) {
      var actor = doc.actor
      username = actor.user && mongo.isNativeId(actor.user) && users[actor.user.toString()] ? users[actor.user.toString()].name : actor.user
    } else {
      username = users[doc.user].name
    }

    return this.row(doc, req, actor, username, usedTags)
  }

  this.getMainActor = function (doc, user, tags) {
    var actor = doc.actors[0] ? doc.actors[0] : {}
    var i = doc.actors.findIndex((u) => { return u.user.equals ? u.user.equals(user) : u.user === user.toString() })
    if (i !== -1) {
      actor = doc.actors[i]
      if (actor.path === 'sent') {
        i = doc.actors.findIndex((u) => { return u.role === 'to' })
      } else {
        i = doc.actors.findIndex((u) => { return u.role === 'from' })
      }
      if (i !== -1) {
        const path = actor.path
        actor = doc.actors[i]
        actor.path = path
      }
    }
    return actor
  }
  this.row = function (doc, req, actor, username, usedTags, usedVersions) {
    var issue = {}

    var deadline = {}
    for (const x in doc.dates) {
      if (doc.dates[x].type === 'issue') {
        issue = doc.dates[x]
      } else if (doc.dates[x].type === 'deadline') {
        deadline = doc.dates[x]
      }
    }
    var attachments = 'none'
    if (doc.files && doc.files.length > 0) {
      for (const x in doc.files) {
        if (doc.files[x]) {
          attachments = 'attachment'
        }
      }
    }
    const expired = doc.status === tags.processing && deadline.value && deadline.value.getTime() <= new Date().getTime() ? tags.expired : undefined
    var tagscolor = []
    var tagsname = []
    var filterNames = [usedTags[0] ? usedTags[0].value : '']
    for (const i in usedTags) {
      tagscolor.push(usedTags[i].color)
      tagsname.push(usedTags[i].value)
    }
    var versioncolor = []
    var versionname = []
    for (const i in usedVersions) {
      versioncolor.push(usedVersions[i].color)
      versionname.push(usedVersions[i].value)
    }
    var row = {
      id: doc._id.toString(),
      attachments: attachments,
      expired: expired,
      css: expired || doc.status || tags.processing,
      status: doc.status ? doc.status : tags.processing,
      statusName: doc.status,
      role: actor.role,
      user: actor.user ? actor.user : doc.user,
      userName: username,
      sequence: doc.sequence && doc.sequence.text ? doc.sequence.text : '',
      name: doc.name,
      path: actor.path,
      pathName: actor.path,
      issue: issue.value ? tags.util.date2str(issue.value, 'yyyy/mm/dd', tags) : '',
      category: doc.category || '',
      deadline: deadline.value ? tags.util.date2str(deadline.value, 'yyyy/mm/dd', tags) : '',
      tagscolor: tagscolor,
      tagsname: tagsname,
      filterNames: filterNames,
      versioncolor: versioncolor,
      versionname: versionname,
      archived: doc.status && doc.status === 'archived' ? 'archived' : '',
      issued: doc.issued,
      result: doc.result,
      actors: doc.actors,
      lastEdit: doc.lastEdit
    }
    if (doc.project && doc.project.length > 0) {
      row.projectName = doc.project[0].name
      row.project = doc.project[0]
    }

    if (doc.type) { row.type = doc.type }
    if (doc.planName) {
      row.planName = doc.planName
      delete doc.planName
    }
    if (doc.task) { row.task = doc.task }
    if (doc.key) { row.key = doc.key }
    if (doc.documental) { row.documental = doc.documental }
    if (doc.bpi) { row.bpi = doc.bpi }
    if (doc.reference) { row.reference = doc.reference }
    return row
  }

  this.delete = function (req, mongo, send) {
    mongo.findId('document', req.query._id, {}, (err, doc) => {
      if (err) {
        send({ error: err })
      } else {
        mongo.deleteOne('document', { _id: mongo.toId(req.query._id) }, (err) => {
          if (err) {
            req.logger.log(err)
          } else {
            req.app.routes.trash.insert(req, mongo, 'document', doc, () => {
              this.sendNotification(req, mongo, send, doc, true)
              send({})
            })
          }
        })
      }
    })
  }
  this.removeTask = function (req, mongo, send) {
    mongo.findId('document', req.body._id, { content: 0 }, (err, doc) => {
      if (err) throw err
      if (doc) {
        if (doc.task && doc.task.toString() === req.body.task.toString()) {
          mongo.update('document', { _id: mongo.toId(doc._id) }, { $unset: { task: '' } }, (err) => {
            if (err) {
              req.logger.log(err)
            } else {
              send()
            }
          })
        } else {
          send()
        }
        this.sendNotification(req, mongo, send, doc, true)
      } else {
        mongo.findId('note', req.body._id, { content: 0 }, (err, note) => {
          if (err) throw err
          if (note && note.task && note.task.toString() === req.body.task.toString()) {
            mongo.update('note', { _id: mongo.toId(note._id) }, { $unset: { task: '' } }, (err) => {
              if (err) {
                req.logger.log(err)
              } else {
                send()
              }
            })
          } else {
            send()
          }
          this.sendNotification(req, mongo, send, note, true)
        })
      }
    })
  }

  this.actions = function (req, mongo, send) {
    mongo.findId('document', req.body._id, (err, doc) => {
      if (err) {
        send({ error: err })
      } else {
        var i = -1
        switch (req.body.action) {
        case 'attended':
          var assistants = req.session.context.assistantUnits
          var indexAssistant = -1
          doc.actors.forEach((x, index) => {
            if (x.user.equals(req.session.context.user) && x.role === 'from') i = index
            else if (x.user.equals(req.session.context.user)) i = index
          })
          for (const a in assistants) {
            indexAssistant = doc.actors.findIndex((x) => {
              if (x.role === 'from') {
                return x.unit.toString() === assistants[a].toString()
              } else { return -1 }
            })
            if (indexAssistant !== -1) {
              doc.status = 'attended'
              break
            }
          }
          if (i !== -1) {
            const actor = doc.actors[i]
            if (actor.role === 'from') { doc.status = 'attended' } else { actor.path = 'attended' }
          }
          break

        case 'processing':
          doc.actors.forEach((x, index) => {
            if (x.user.equals(req.session.context.user) && x.role === 'from') i = index
            else if (x.user.equals(req.session.context.user)) i = index
          })
          if (i !== -1) {
            const actor = doc.actors[i]
            if (actor.role === 'from') { doc.status = 'processing' } else {
              if (actor.role === 'to') { actor.path = 'received' } else { actor.path = 'referred' }
            }
          }
          break

        case 'archived':
          doc.actors.forEach((x, index) => {
            if (x.user.equals(req.session.context.user) && x.role === 'from') i = index
            else if (x.user.equals(req.session.context.user)) i = index
          })
          if (i !== -1) {
            const actor = doc.actors[i]
            if (actor.role === 'from') { doc.status = 'archived' }
          }
          break

        case 'unArchived':
          doc.actors.forEach((x, index) => {
            if (x.user.equals(req.session.context.user) && x.role === 'from') i = index
            else if (x.user.equals(req.session.context.user)) i = index
          })
          if (i !== -1) {
            const actor = doc.actors[i]
            if (actor.role === 'from') { doc.status = 'attended' }
          }
          break
        }

        mongo.save('document', doc, (err) => {
          if (err) {
            send()
          } else {
            send({})
            // sendNotification(req,   mongo, send, doc);
          }
        })
      }
    })
  }

  this.close = function (req, mongo, send) {
    var doc = req.body
    var date = new Date()
    mongo.findId('document', doc._id, (err, document) => {
      if (err) {
        console.log(err)
        send(err)
      } else {
        if (document) {
          mongo.find('time', { $and: [{ document: document.task }, { project: mongo.toId(doc.project) }, { date: { $gte: new Date(new Date(date).setHours(0, 0, 0, 0)) } }, { date: { $lte: new Date(new Date(date).setHours(23, 59, 59)) } }], user: req.session.context.user }, {}, { _id: -1 }, (err, time) => {
            if (err) {
              console.log(err)
              send(err)
            } else {
              if (time && time.length > 0) {
                if (time[0].docs && time[0].docs.length > 0) {
                  for (const d in time[0].docs) {
                    time[0].docs[d] = time[0].docs[d].toString()
                  }
                  var index = time[0].docs.indexOf(doc._id.toString())
                  if (time[0].docs.splice) time[0].docs.splice(index, 1)
                  else time[0].docs = []
                }
                if (!time[0].docs || time[0].docs.length === 0) {
                  if (!time[0].duration) time[0].duration = 0
                  time[0].open = false
                  var start = moment(time[0].start)
                  var stop = new Date()
                  time[0].stop = stop
                  stop = moment(stop)
                  var diff = stop.diff(start, 'm') // Diff in minutes
                  diff = parseInt(diff)
                  time[0].duration = parseFloat(time[0].duration) + parseFloat(diff) /* / 60 */
                  if (time[0].duration !== 0) {
                    time[0].cost = (time[0].duration / 60) * parseFloat(isNaN(Number(req.session.context.hourCost)) ? 0 : Number(req.session.context.hourCost))
                  }
                }
                mongo.save('time', time[0], (err) => {
                  if (err) throw err
                  send(doc)
                })
              } else {
                send()
              }
            }
          })
        } else {
          send()
        }
      }
    })
  }

  this.$keys=async function (req,mongo,) {
    var keys
    var scalableSequences = await new Promise(resolve => {
      mongo.find('sequence', { scalable: true }, (err, seqs) => {
        if (err) console.log(err)
        var ids = []
        if(seqs) {
          for (let s in seqs) {
            ids.push(seqs[s]._id)
          }
        }
        resolve(ids)
      })
    })
    if (req.session.context.licensedUser === false) {
      var myUnits=req.session.context.managerUnits.concat(req.session.context.assistantUnits)
      var myAndDependentUnits = req.session.context.dependentUnits.concat(myUnits)
      keys = {
        $or: [
          // responsible user without hidden
          { actors: { $elemMatch: { user: req.session.context.user, role: 'responsible', path: { $ne: 'hidden' } } } },
          // or actor referred
          { actors: { $elemMatch: { user: req.session.context.user, path: 'referred' } } },
          // if confidential or not scalable, all actors user without hidden
          {
            $and: [
              {
                $or: [
                  { confidential: '1' },
                  { $and: [{ 'sequence.sequence': { $nin: scalableSequences } }, { 'sequence._id': { $nin: scalableSequences } }] }
                ]
              },
              {
                $or: [
                  { actors: { $elemMatch: { user: req.session.context.user, path: { $ne: 'hidden' } } } },
                  { actors: { $elemMatch: { unit: { $in: myUnits }, path: { $ne: 'hidden' } } } }
                ]
              }
            ]
          },
          // if not confidential and scalable, responsible unit are in dependents units without hidden only
          {
            confidential: {$ne: '1'},
            $or: [
              { 'sequence.sequence': { $in: scalableSequences } },
              { 'sequence._id': { $in: scalableSequences } },
              { 'sequence.sequence': null,'sequence._id': null}
            ],
            actors: { $elemMatch: { role: 'responsible', unit: { $in: myAndDependentUnits }, path: { $ne: 'hidden' } } }
          }
        ]
      }
    } else {
      myUnits=req.session.context.managerUnits.concat(req.session.context.assistantUnits).concat(req.session.context.memberUnits)
      myAndDependentUnits = req.session.context.dependentUnits.concat(myUnits)
      keys = {
        $or: [
          // users in the note & not hidden
          { actors: { $elemMatch: { user: req.session.context.user, path: { $ne: 'hidden' } } } },
          // assistant in one unit of note & not hidden
          { actors: { $elemMatch: { unit: { $in: myUnits }, path: { $ne: 'hidden' } } } },
          // manager or assistant of ascending unit, not hidden, scalable, non-confidential and not in draft
          {
            actors: { $elemMatch: { unit: { $in: myAndDependentUnits }, path: { $ne: 'hidden' } } },
            confidential: { $ne: '1' }
          }
        ]
      }
    }
    return keys
  }
}
