
/* exported */
var tags = require('../utils/tags').tags
var Html = require('../utils/html').Html
var dateformat = require('dateformat')
var html = new Html()
var Notification = require('../utils/notification').Notification
var notification = new Notification()

exports.Task = Task

function Task () {
  this.businessDays = function (start, end, holidays) {
    var days = Math.trunc((end - start) / 86400000)
    var res = (days % 7) - 1
    // Subtract weekend of complete weeks between start-end
    days -= (Math.trunc(days / 7) * 2)
    // Subtract weekend of last incomplete week
    if (res) {
      var d = end
      d.setDate(d.getDate() - res)
      let dw = d.getDay()
      for (let i=0; i < res; ++i) {
        if (dw === 0 || dw === 6 || dw === 7) {
          --days
        }
        dw = (++dw) % 7
      }
    }
    // Subtract holidays between start-end if is not weekend
    for (let i in holidays) {
      let date=holidays[i]
      if (date <= end && date >= start && [0,6].indexOf(date.getDay())===-1) {
        --days
      }
    }
    return days
  }

  this.taskIds = function (content, mongo, replaceAll) {
    // Replace each task id with new mongo id
    var ids = {}
    var id
    for (const i in content.data) {
      var task = content.data[i]
      if (replaceAll) task.status = 'draft'
      if (replaceAll || !mongo.isNativeId(task.id)) {
        id = mongo.newId()
        ids['' + task.id] = id
        if (content.calendars) {
          content.calendars.findIndex((c) => {
            if (c.id.includes(task.id)) {
              c.id = 'calendar' + id.toString()
            }
          })
        }
        task.id = id
      }
    }
    // Replace parent ids with respective mongo id
    for (const i in content.data) {
      task = content.data[i]
      if (task.parent && ids['' + task.parent]) {
        task.parent = ids[task.parent]
      }
    }
    // Replace source & target ids in each link with respective mongo id
    for (const i in content.links) {
      const link = content.links[i]
      id = ids['' + link.source]
      if (id) {
        link.source = id
      }
      id = ids['' + link.target]
      if (id) {
        link.target = ids[link.target]
      }
      if (replaceAll) {
        link.id = mongo.newId()
      }
    }
  }

  // Compute working days betheen dates
  this.restaFechas = function (f1, f2) {
    var dias = f2.diff(f1, 'days')
    return dias
  }

  this.remaining = function (projects, id, remaining) {
    for (const p in projects) {
      if (projects[p].budget && projects[p].budget.length) {
        for (const b in projects[p].budget) {
          if (projects[p].budget[b].id === id) {
            remaining = parseFloat(remaining) - parseFloat(projects[p].budget[b].amount)
          }
        }
      }
    }
    return remaining
  }

  this.setWorkDay = function (req, mongo, send) {
    var id = req.body._id
    if (id) {
      id = mongo.toId(id)
      mongo.save('task', { _id: id, workDay: 1 * req.body.workDay, duration: 1 * req.body.duration }, (err, result) => {
        if (err) {
          req.status=500
          send({ message: err.toString() })
        } else {
          send()
        }
      })
    }
  }

  this.get = function (req, mongo, send) {
    var project = req.query.project
    var task = req.query.task
    mongo.findId('task', task, (err, task) => {
      if (err) {
        console.log(err)
        send(err)
      } else {
        if (!task) {
          task = { id: mongo.newId() }
          task._id=task.id
        }
        mongo.findId('project', project, async (err, project) => {
          if (err) {
            console.log(err)
            send(err)
          } else {
            let realDuration = 0
            if(task) {
              var times = await new Promise(resolve => {
                mongo.find('time', {document: task._id, project: project._id }, async (err, times) => {
                  if (err) {
                    resolve(false)
                  } else {
                    resolve(times)
                  }
                })
              })
            }
            if(times) {
              for (let t in times) {
                if (times[t].duration) realDuration = realDuration + times[t].duration
              }
            }
            if(task) task.realDuration = Number(realDuration)
            var userIds = []
            for (const i in project.actors) {
              const actor = project.actors[i]
              userIds.push(actor.user)
              if (actor.type[0] === 'manager') {
                project.manager = actor.user
              } else {
                if (project.members) {
                  project.members.push(actor.user)
                } else {
                  project.members= [actor.user]
                }
              }
            }
            mongo.find('user', { _id: { $in: userIds } }, { name: 1, business: 1 }, (err, users) => {
              if (err) throw err
              if (users && users.length) {
                project.resources = []
                for (const i in users) {
                  const user = { id: users[i]._id, text: users[i].name }
                  project.resources.push(user)
                }
              }
              delete project.actors
              delete project.content
              let data = {
                project: project
              }
              if(task) data.task = task
              send(data)
            })
          }
        })
      }
    })
  }

  this.save = async function (req, mongo, send) {
    var task = req.body.task
    task.calendar = 0
    task._id = task.id
    task.start_date = new Date(task.start_date)
    task.end_date = new Date(task.end_date)
    if (task.documents && task.documents.length) {
      let idsDocs = []
      for (let x in task.documents) {
        idsDocs.push(mongo.toId(task.documents[x]))
      }
      await new Promise(resolve => {
        mongo.find('document', { _id: { $in: idsDocs } }, {}, {}, async (err, docums) => {
          if (err) {
            console.log(err)
            resolve()
          } else {
            if (docums.length) {
              for (let m in docums) {
                let sameUser = true
                if (docums[m].actors && docums[m].actors.length) {
                  for (let g in docums[m].actors) {
                    if (docums[m].actors[g].role === 'reviser' && docums[m].actors[g].path === 'sent') {
                      sameUser = docums[m].actors[g].user.toString() === task.owner_id.toString()
                      if (!sameUser) {
                        let newUser = await new Promise(resolve => {
                          mongo.findId('user', task.owner_id, (err, user) => {
                            if(err || !user) resolve()
                            else resolve(user)
                          })
                        })
                        docums[m].actors[g].user = newUser._id
                        if (newUser.units && newUser.units[0]) {
                          docums[m].actors[g].unit = newUser.units[0]
                        }
                        await new Promise(resolve => {
                          mongo.save('document', docums[m], (err, result) => {
                            if (err) {
                              resolve()
                            } else {
                              resolve(result)
                            }
                          })
                        })
                      }
                      break
                    }
                  }
                }
              }
            }
            resolve()
          }
        })
      })
    }
    let oldTask = await new Promise(resolve => {
      mongo.findId('task', task._id, {}, {}, (err, tk) => {
        if (err || !tk) {
          resolve(false)
        } else {
          resolve(tk)
        }
      })
    })
    mongo.save('task', task, async (err) => {
      if (err) {
        console.log(err)
        send(err)
      } else {
        send({})
        let projectStatus = await new Promise(resolve => {
          mongo.findId('project', task.project, {}, {}, (err, proj) => {
            if (err || !proj) {
              resolve('')
            } else {
              resolve(proj.status)
            }
          })
        })
        if ((projectStatus && projectStatus !== 'draft' && oldTask) && ((oldTask.status !== task.status) || (oldTask.duration !== task.duration) || (oldTask.owner_id !== task.owner_id))) {
          let description = ''
          if (oldTask.status !== task.status) {
            let objStatus = {
              draft: 'Borrador',
              processing: 'Proceso',
              paused: 'Pausado',
              suspended: 'Suspendido',
              done: 'Terminado',
              reviewed: 'Revisado'
            }
            description += '<br>Cambió el estado de la tarea de ' + objStatus[oldTask.status] + ' a ' + objStatus[task.status]
          }
          if (oldTask.duration !== task.duration) {
            async function toDuration (value) {
              let workDay = await new Promise(resolve => {
                mongo.findId('user', task.owner_id, {}, {}, (err, user) => {
                  if (err || !user) {
                    resolve('')
                  } else {
                    let workDay = user.business ? user.business.workDay : req.session.context.workDay
                    resolve(workDay)
                  }
                })
              })
              workDay = workDay ? workDay : req.session.context.workDay
              v = value || 0
              h = (v % workDay)
              var d = v - h < workDay ? 0 : (v - h) / workDay
              m = h % 60
              h = h - m < 60 ? 0 : (h - m) / 60
              return d + ':' + h + ':' + m
            }
            description += '<br>Cambió la duración de la tarea de ' + await toDuration(oldTask.duration) + ' a ' + await toDuration(task.duration)
          }
          if (oldTask.owner_id && task.owner_id && oldTask.owner_id.toString() !== task.owner_id.toString()) {
            let oldUser = await new Promise(resolve => {
              mongo.findId('user', oldTask.owner_id, {}, {}, (err, user) => {
                if (err || !user) {
                  resolve('')
                } else {
                  resolve(user.name)
                }
              })
            })
            let newUser = await new Promise(resolve => {
              mongo.findId('user', task.owner_id, {}, {}, (err, user) => {
                if (err || !user) {
                  resolve('')
                } else {
                  resolve(user.name)
                }
              })
            })
            description += '<br>Cambió el responsable de la tarea de ' + oldUser + ' a ' + newUser
          }
          var evtTask = {
            _id: mongo.newId(),
            user: req.session.context.user,
            date: new Date(),
            event: 'statusChange',
            collection: 'task',
            docId: task._id,
            data: task.status,
            project: task.project,
            description: description
          }
          await new Promise(resolve => {
            mongo.save('eventTask', evtTask, () => { resolve() })
          })
        }
        notification.send(req, req.session.context.room, 'task.' + task._id.toString(), { id: task._id, task: task }, null, null)
      }
    })
  }

  this.deleteTaskModel = async function (req, mongo, send) {
    let task = req.query
    req.app.routes.trash.insert(req, mongo, 'task', task, () => {
      send({})
    })
  }

  this.deleteTask = async function (req, mongo, send) {
    var task = await new Promise(resolve => {
      mongo.findId('task', req.query.task, async (err, task) => {
        if (err) {
          resolve(false)
        } else {
          resolve(task)
        }
      })
    })
    if (task) {
      let times = await new Promise(resolve => {
        mongo.find('time', { document: task._id, project: task.project }, async (err, times) => {
          if (err) {
            resolve(false)
          } else {
            resolve(times)
          }
        })
      })
      if(task.links && task.links.length) {
        send({ msg: 'Existen enlaces sobre esta tarea'})
      }else if(times && times.length) {
        send({ msg: 'Existen reportes de tiempo sobre esta tarea'})
      }else if(task.documents && task.documents.length) {
        send({ msg: 'Existen papeles de trabajo sobre esta tarea'})
      } else {
        if (task.type === 'project') {
          let parents = await new Promise(resolve => {
            mongo.find('task', { parent: task._id, project: task.project }, async (err, tasks) => {
              if (err) {
                resolve(false)
              } else {
                resolve(tasks)
              }
            })
          })
          for (let t in parents) {
            await new Promise(resolve => {
              mongo.deleteOne('task', { _id: parents[t]._id }, (err) => {
                if (err) {
                  resolve()
                } else {
                  req.app.routes.trash.insert(req, mongo, 'task', parents[t], () => {
                    resolve()
                  })
                }
              })
            })
          }
          mongo.deleteOne('task', { _id: task._id }, (err) => {
            if (err) {
              console.log(err)
              send(err)
            } else {
              req.app.routes.trash.insert(req, mongo, 'task', task, () => {
                send({})
              })
            }
          })
        } else {
          mongo.deleteOne('task', { _id: task._id }, (err) => {
            if (err) {
              console.log(err)
              send(err)
            } else {
              req.app.routes.trash.insert(req, mongo, 'task', task, () => {
                send({})
              })
            }
          })
        }
      }
    } else {
      send({})
    }
  }

  this.getData = function (array, next, index) {
    if (!index) {
      index = 0
    }
    if (array.length > index) {
      html.getData(array[index].description, (data) => {
        if (data.links.length > 0) {
          if (!array[index].documents) {
            array[index].documents = []
          }
          for (const i in data.links) {
            if (array[index].documents.indexOf(data.links[i]._id) === -1) {
              array[index].documents.push(data.links[i]._id)
            }
          }
        }
        this.getData(array, next, index + 1)
      })
    } else {
      next()
    }
  }
  this.deleteProject = function (req, mongo, send) {
    mongo.findId('project', req.query._id, (err, project) => {
      if (err) throw err
      var plan = project ? project.plan : ''
      if (project.status === 'draft' && plan) {
        mongo.deleteOne('project', { _id: mongo.toId(req.query._id) }, (err) => {
          if (err) {
            send(err)
          } else {
            project.idGoal = req.query.idGoal
            req.app.routes.trash.insert(req, mongo, 'project', project, async () => {
              send({})
              notification.send(req, req.session.context.room, 'kanban.' + plan.toString(), { id: plan })
              var tasks = await new Promise((resolve) => {
                mongo.find('task', { project: mongo.toId(req.query._id) }, (err, tasks) => {
                  if (err) { resolve([]) } else { resolve(tasks) }
                })
              })
              for (let i in tasks) {
                let task = tasks[i]
                await new Promise((resolve) => {
                  mongo.deleteOne('task', { _id: task._id }, (err) => {
                    if (err) {
                      console.log(err)
                      resolve()
                    } else {
                      req.app.routes.trash.insert(req, mongo, 'task', task, () => {
                        resolve()
                      })
                    }
                  })
                })
              }
            })
          }
        })
      } else {
        send({ msj: '_projectAlreadyStarted'})
      }
    })
  }
  this.deleteProjectIn = function (req, mongo, send) {
    var idGoal = ''
    mongo.findId('project', req.query._id, (err, project) => {
      if (err) throw err
      var plan = project ? project.plan : ''
      if (project.status === 'draft' && plan) {
        mongo.findId('plan', plan, (err, pln) => {
          if (err) throw err
          for (const i in pln.goals) {
            for (const p in pln.goals[i].projects) {
              if (req.query._id.toString() === pln.goals[i].projects[p].toString()) {
                pln.goals[i].projects.splice(p, 1)
                idGoal = pln.goals[i].id
                break
              }
            }
          }
          mongo.save('plan', { _id: pln._id, goals: pln.goals }, () => {
            mongo.deleteOne('project', { _id: mongo.toId(req.query._id) }, (err) => {
              if (err) {
                send(err)
              } else {
                project.idGoal = idGoal
                req.app.routes.trash.insert(req, mongo, 'project', project, async () => {
                  send({})
                  notification.send(req, req.session.context.room, 'planProjects.' + plan.toString(), { id: req.query._id }, null, true)
                  notification.send(req, req.session.context.room, 'dtproject', { id: req.query._id }, null, true)
                  notification.send(req, req.session.context.room, 'kanban.' + plan.toString(), { id: plan })
                  var tasks = await new Promise((resolve) => {
                    mongo.find('task', { project: mongo.toId(req.query._id) }, (err, tasks) => {
                      if (err) { resolve([]) } else { resolve(tasks) }
                    })
                  })
                  for (let i in tasks) {
                    let task = tasks[i]
                    await new Promise((resolve) => {
                      mongo.deleteOne('task', { _id: task._id }, (err) => {
                        if (err) {
                          console.log(err)
                          resolve()
                        } else {
                          task.hidden = true
                          req.app.routes.trash.insert(req, mongo, 'task', task, () => {
                            resolve()
                          })
                        }
                      })
                    })
                  }
                })
              }
            })
          })
        })
      } else {
        send({ msj: '_projectAlreadyStarted'})
      }
    })
  }
  this.addActors = function (req, id, actors, mongo, next) {
    mongo.findId('project', id, { actors: 1 }, (err, doc) => {
      if (err || !doc) {
        next(err)
      } else {
        for (const i in actors) {
          const rm = doc.actors.findIndex((actor) => { return actor.user === actors[i].user })
          if (rm === -1) {
            doc.actors.push({ user: actors[i].user, type: ['guest'] })
          }
        }
        mongo.save('project', doc, (err) => {
          next(err, doc)
        })
      }
    })
  }

  this.delegates = function (req, mongo, send) {
    mongo.findId('project', req.query.project, (err, project) => {
      if (err) {
        send({})
      } else {
        var delegates = []
        var parent = ''; var docId = mongo.toId(req.query._id)
        if (project.content) {
          for (const i in project.content.data) {
            const data = project.content.data[i]
            if ((req.query.task && data.id.toString() === req.query.task.toString()) || (data.documents && data.documents.findIndex((it) => { return mongo.toId(it).equals(docId) }) !== -1)) {
              parent = data.parent
              delegates.push(data.owner_id)
              break
            }
          }
          for (const i in project.content.data) {
            const data = project.content.data[i]
            if (data.id === parent.toString()) {
              if (data.owner_id) { delegates.push(data.owner_id) }
              parent = data.parent
            }
          }
          send(delegates)
        }
      }
    })
  }

  this.templatesTask = function (req, mongo, send) {
    var reply = { data: [] }
    mongo.find('params', { name: 'tag' }, { _id: 1, name: 1, options: 1 }, (er, tags) => {
      mongo.findId('project', req.query._id, (err, project) => {
        if (err) throw err
        var idTemplates = []
        var keys = { $and: [{ type: { $nin: ['project', 'auditable'] } }, { $or: [{ units: project.unit }, { 'units.0': { $exists: 0 } }] }] }
        /* apply filter in parameters */
        if (req.query.filter) {
          let query={}
          for (const name in req.query.filter) {
            if (req.query.filter[name].length > 0) {
              if (name === 'tags') {
                query.tags = mongo.toId(req.query.filter.tags)
              } else if (name === 'name') {
                query.$text = { $search: req.query.filter.name }
              } else {
                query[name] = req.query.filter[name].indexOf(',') !== -1 ? { $in: req.query.filter[name].split(',') } : new RegExp(req.query.filter[name].replace(/ /g, '.*'), 'i')
              }
            }
          }
          keys = Object.keys(query).length > 0 ? { $and: [keys, query] } : keys
        } else {
          if (project.content) {
            var data = project.content.data
            if (data && data.length) {
              var task = req.query.task
              for (const i in data) {
                if (data[i].id.toString() === task.toString()) {
                  if (data[i].templates && data[i].templates.length) {
                    for (const t in data[i].templates) {
                      idTemplates.push(mongo.toId(data[i].templates[t]))
                    }
                  }
                  break
                }
              }
            }
          }
          if (idTemplates.length > 0) {
            keys = { _id: { $in: idTemplates } }
          }
        }
        mongo.find('template', keys, {}, {_id: 1}, (err, temp) => {
          if (err) {
            send()
          } else {
            for (const i in temp) {
              var doc = temp[i]
              var tagsId = []
              for (const j in doc.tags) {
                tagsId.push(doc.tags[j])
              }
              var usedTags = []
              if (tags[0]) {
                for (let t = 0; t < tags[0].options.length; t++) {
                  for (let o = 0; o < tagsId.length; o++) {
                    if (tags[0].options[t].id.toString() === tagsId[o].toString()) {
                      usedTags.push(tags[0].options[t])
                    }
                  }
                }
              }
              var tagscolor = []
              var tagsname = []
              var filterNames = [usedTags[0] ? usedTags[0].value : '']
              for (const i in usedTags) {
                tagscolor.push(usedTags[i].color)
                tagsname.push(usedTags[i].value)
              }
              doc.id = doc._id
              doc.filter = !!doc.filter
              doc.tagscolor = tagscolor
              doc.tagsname = tagsname
              doc.filterNames = filterNames
              reply.data.push(doc)
            }
            send(reply)
          }
        })
      })
    })
  }

  this.saveFile = function (req, mongo, send) {
    mongo.savefile(req, (err, result) => {
      if (!err) {
        send({ id: result.link })
      } else {
        send(err)
      }
    })
  }

  this.deleteFile = function (req, mongo, send) {
    var sources = req.body.source.split(',')
    var project = req.query.project
    function findRow (source, files, value) {
      for (const i in files) {
        const row = files[i]
        if (row.id && row.id.toString() === source) {
          value.data = row
        }
        if (row.data) {
          findRow (source, row.data, value)
        }
      }
    }
    async function toDelete (ids, data, files, send) {
      for (const j in data) {
        var source = data[j].id
        if (source.toString().includes('&')) {
          if (data[j] && data[j].metadata && data[j].metadata) {
            if (data[j].metadata.actors[0].user.toString() !== req.session.context.user.toString()) {
              send(['error'])
              return
            }
            if (data[j].metadata.note) {
              await new Promise(resolve => {
                mongo.findId('note', data[j].metadata.note, (err, note) => {
                  if (err) {
                    resolve(false)
                  } else if (note && note.status !== 'draft') {
                    send(['error'])
                    return
                  } else {
                    resolve(true)
                  }
                })
              })
            }
            if (data[j].metadata.attached) {
              await new Promise(resolve => {
                mongo.findId('attached', data[j].metadata.attached, (err, attached) => {
                  if (err) {
                    resolve(false)
                  } else if (attached && attached.status !== 'prepared') {
                    send(['error'])
                    return
                  } else {
                    resolve(true)
                  }
                })
              })
            }
            if (data[j].metadata.commitment) {
              await new Promise(resolve => {
                mongo.findId('commitment', data[j].metadata.commitment, (err, commitment) => {
                  if (err) {
                    resolve(false)
                  } else if (commitment && !['draft', 'returned'].includes(commitment.status)) {
                    send(['error'])
                    return
                  } else {
                    resolve(true)
                  }
                })
              })
            }
            if (data[j].metadata.evidence) {
              await new Promise(resolve => {
                mongo.findId('evidence', data[j].metadata.evidence, (err, evidence) => {
                  if (err) {
                    resolve(false)
                  } else if (evidence && !['draft'].includes(evidence.status)) {
                    send(['error'])
                    return
                  } else {
                    resolve(true)
                  }
                })
              })
            }
          }
          ids.push(source.toString().split('=')[1].split('&')[0])
        } else {
          let row = {
            data: false
          }
          findRow(source.toString(), files, row)
          if (row.data && row.data.data) {
            toDelete(ids, row.data.data, files, send)
          }
        }

      }
    }
    async function deleteids (ids, i) {
      await new Promise(resolve => {
        mongo.removefile(ids[i], (err) => {
          if (!err) {
            resolve(true)
          } else {
            resolve(false)
          }
        })
      })
      if (i < ids.length - 1) {
        i = i + 1
        deleteids(ids, i)
      }
    }
    mongo.findId('project', project, async (err, project) => {
      if (!err && project) {
        const ids = []
        for (const j in sources) {
          var source = sources[j]
          if (source.toString().includes('&')) {
            let row = {
              data: false
            }
            findRow(source, project.files, row)
            if (row.data && row.data.metadata && row.data.metadata) {
              if (row.data.metadata.actors[0].user.toString() !== req.session.context.user.toString()) {
                send(['error'])
                return
              }
              if (row.data.metadata.note) {
                await new Promise(resolve => {
                  mongo.findId('note', row.data.metadata.note, (err, note) => {
                    if (err) {
                      resolve(false)
                    } else if (note && note.status !== 'draft') {
                      send(['error'])
                      return
                    } else {
                      resolve(true)
                    }
                  })
                })
              }
              if (row.data.metadata.attached) {
                await new Promise(resolve => {
                  mongo.findId('attached', row.data.metadata.attached, (err, attached) => {
                    if (err) {
                      resolve(false)
                    } else if (attached && attached.status !== 'prepared') {
                      send(['error'])
                      return
                    } else {
                      resolve(true)
                    }
                  })
                })
              }
              if (row.data.metadata.commitment) {
                await new Promise(resolve => {
                  mongo.findId('commitment', row.data.metadata.commitment, (err, commitment) => {
                    if (err) {
                      resolve(false)
                    } else if (commitment && !['draft', 'returned'].includes(commitment.status)) {
                      send(['error'])
                      return
                    } else {
                      resolve(true)
                    }
                  })
                })
              }
              if (row.data.metadata.evidence) {
                await new Promise(resolve => {
                  mongo.findId('evidence', row.data.metadata.evidence, (err, evidence) => {
                    if (err) {
                      resolve(false)
                    } else if (evidence && !['draft'].includes(evidence.status)) {
                      send(['error'])
                      return
                    } else {
                      resolve(true)
                    }
                  })
                })
              }
            }
            var id = source.toString().split('=')[1].split('&')[0]
            await new Promise(resolve => {
              mongo.removefile(id, (err) => {
                if (!err) { resolve(true) } else { resolve(false) }
              })
            })
          } else {
            if (project.files) {
              let row = {
                data: false
              }
              findRow(source, project.files, row)
              if (row.data && row.data.data) {
                toDelete(ids, row.data.data, project.files, send)
                if (ids.length) {
                  deleteids (ids, 0)
                }
              }
            }
          }
        }
        send(['ok'])
      }
    })
  }
  this.copyFile = function (req, mongo, send) {
    send({})
  }
  this.renameFile = async function (req, mongo, send) {
    let project = req.query.project
    function findRow (source, files, value) {
      for (const i in files) {
        const row = files[i]
        if (row.id.toString() === source) {
          value.data = row
        }
        if (row.data) {
          findRow (source, row.data, value)
        }
      }
    }
    mongo.findId('project', project, async (err, project) => {
      if (!err && project) {
        if (req.body.source.includes('=')) {
          var idFile = req.body.source.split('=')[1].split('&')[0]
          var id = req.body.source
          var row = {
            data: false
          }
          findRow(id, project.files, row)
          if (row.data && row.data.metadata) {
            await new Promise(resolve => {
              mongo.save('fs.files', {_id: mongo.toId(idFile), filename: req.body.target}, (err, result) => {
                if (!err) {
                  resolve(true)
                } else {
                  resolve(false)
                }
              })
            })
            if (row.data.metadata.actors[0].user.toString() !== req.session.context.user.toString()) {
              send(['error'])
              return
            }
            if (row.data.metadata.note) {
              await new Promise(resolve => {
                mongo.findId('note', row.data.metadata.note, (err, note) => {
                  if (err) {
                    resolve(false)
                  } else if (note && note.status !== 'draft') {
                    send(['error'])
                    return
                  } else {
                    resolve(true)
                  }
                })
              })
            }
            if (row.data.metadata.attached) {
              await new Promise(resolve => {
                mongo.findId('attached', row.data.metadata.attached, (err, attached) => {
                  if (err) {
                    resolve(false)
                  } else if (attached && attached.status !== 'prepared') {
                    send(['error'])
                    return
                  } else {
                    resolve(true)
                  }
                })
              })
            }
            if (row.data.metadata.commitment) {
              await new Promise(resolve => {
                mongo.findId('commitment', row.data.metadata.commitment, (err, commitment) => {
                  if (err) {
                    resolve(false)
                  } else if (commitment && !['draft', 'returned'].includes(commitment.status)) {
                    send(['error'])
                    return
                  } else {
                    resolve(true)
                  }
                })
              })
            }
            if (row.data.metadata.evidence) {
              await new Promise(resolve => {
                mongo.findId('evidence', row.data.metadata.evidence, (err, evidence) => {
                  if (err) {
                    resolve(false)
                  } else if (evidence && !['draft'].includes(evidence.status)) {
                    send(['error'])
                    return
                  } else {
                    resolve(true)
                  }
                })
              })
            }
          } else {
            await new Promise(resolve => {
              mongo.save('fs.files', {_id: mongo.toId(idFile), filename: req.body.target}, (err, result) => {
                if (!err) {
                  resolve(true)
                } else {
                  resolve(false)
                }
              })
            })
            send({})
          }
        } else {
          send({})
        }
      } else {
        send(['error'])
      }
    })
  }
  this.getFileManager = function (req, mongo, send) {
    var project = req.query._id
    mongo.findId('project', project, async (err, project) => {
      if (!err && project) {
        if (project.files) { send(project.files) } else {
          send([
            {
              value: '/', open: true, type: 'folder', date: new Date(), data: []
            }
          ])
        }
      } else {
        send(err)
      }
    })
  }
  this.saveFileManager = function (req, mongo, send) {
    var data = req.body.data
    var id = req.body._id
    var ids = []
    function source1 (data) {
      for (const i in data) {
        const x = data[i]
        if (x.data) { source1(x.data) } else if (typeof x.id !== 'string' && x.reference) {
          ids.push(mongo.toId(x.reference.split('=')[1].split('&')[0]))
        }
      }
    }
    function source2 (data, files, toSave) {
      for (const i in data) {
        const x = data[i]
        if (x.data) { source2(x.data, files, toSave) }
        if (typeof x.id !== 'string' && x.reference) {
          const doc = files[x.reference.split('=')[1].split('&')[0]]
          doc.newId = mongo.newId()
          toSave.push(doc)
          x.temp = x.id
          x.date = new Date()
          x.id = x.reference.split('=')[0] + '=' + doc.newId.toString() + '&' + x.reference.split('&')[1]
          x.reference = x.id
        }
      }
    }
    if (data.length > 0) {
      source1(data)
      mongo.toHash('fs.files', { _id: { $in: ids } }, {}, (err, files) => {
        if (!err) {
          var toSave = []
          source2(data, files, toSave)
          if (toSave.length > 0) {
            save(toSave, 0)
          } else {
            mongo.save('project', { _id: id, files: data }, (err) => {
              if (!err) {
                send({ data: data })
              } else {
                send(err)
              }
            })
          }
        }
      })
    } else {
      send({})
    }
    function save (toSave, i) {
      mongo.copyfile(toSave[i]._id, toSave[i].newId, (err) => {
        if (!err) {
          if (i < toSave.length - 1) {
            i = i + 1
            save(toSave, i)
          } else {
            mongo.save('project', { _id: id, files: data }, (err) => {
              if (!err) {
                send({ data: data })
              } else {
                send(err)
              }
            })
          }
        } else {
          send(err)
        }
      })
    }
  }
  this.proceedings = function (req, mongo, send) {
    mongo.findId('project', req.query._id, async (err, doc) => {
      if (!err && doc) {
        let unit = await new Promise(resolve => {
          mongo.findId('unit', doc.unit, {name: 1}, (err, unit) => {
            if (unit) resolve(unit.name)
            else resolve('')
          })
        })
        let units = ''
        if (doc.units && doc.units.length) {
          await new Promise(resolve => {
            mongo.find('unit', { _id: { $in: doc.units }}, {name: 1}, (err, uns) => {
              if (uns) {
                for (let i in uns) {
                  if (i === '0') units += uns[i].name
                  else units += ', ' + uns[i].name
                }
                resolve()
              }
              else resolve()
            })
          })
        } else if (doc.units) {
          await new Promise(resolve => {
            mongo.findId('unit', doc.units, {name: 1}, (err, unit) => {
              if (unit) {
                units = unit.name
                resolve()
              }
              else resolve()
            })
          })
        }
        let processes = ''
        if (doc.processes && doc.processes.length) {
          await new Promise(resolve => {
            mongo.find('process', { _id: { $in: doc.processes }}, {name: 1}, (err, pros) => {
              if (pros) {
                for (let i in pros) {
                  if (i === '0') processes += pros[i].name
                  else processes += ', ' + pros[i].name
                }
                resolve()
              }
              else resolve()
            })
          })
        }
        let nameTags = ''
        if (doc.tag) {
          if (!mongo.isNativeId(doc.tag) && doc.tag.length >= 24) {
            let tag = doc.tag.split(',')
            for (let t in tag) {
              tag[t] = mongo.toId(tag[t])
            }
          } else if (doc.tag.length === 24) {
            doc.tag = [doc.tag]
          }
          await new Promise(resolve => {
            mongo.findOne('params', { 'options.id': { $in: doc.tag }}, {}, (err, tags) => {
              if (tags) {
                for (let u in doc.tag) {
                  for (let o in tags.options) {
                    if (doc.tag[u].toString() === tags.options[o].id.toString()) {
                      if (u === '0') nameTags += tags.options[o].value
                      else nameTags += ', ' + tags.options[o].value
                    }
                  }
                }
                resolve()
              }
              else resolve()
            })
          })
        }
        let area = ''
        if (doc.area) {
          area = await new Promise(resolve => {
            mongo.findOne('params', { 'options.id': { $in: [ doc.area ] }}, {}, (err, areaT) => {
              if (areaT) {
                let area = ''
                for (let o in areaT.options) {
                  if (doc.area.toString() === areaT.options[o].id.toString()) {
                    area = areaT.options[o].value
                  }
                }
                resolve(area)
              }
              else resolve('')
            })
          })
        }
        let riesgo = ''
        if (doc.risk) {
          riesgo = await new Promise(resolve => {
            mongo.findOne('params', { 'options.id': { $in: [ doc.risk ] }}, {}, (err, riskT) => {
              if (riskT) {
                let riesgo = ''
                for (let o in riskT.options) {
                  if (doc.risk.toString() === riskT.options[o].id.toString()) {
                    riesgo = riskT.options[o].value
                  }
                }
                resolve(riesgo)
              }
              else resolve('')
            })
          })
        }
        let manager = ''
        let members = ''
        if (doc.actors) {
          for (let i in doc.actors) {
            if (i === '0') {
              await new Promise(resolve => {
                mongo.findId('user', doc.actors[i].user, { name: 1 }, (err, user) => {
                  if (user) {
                    manager = user.name
                    resolve()
                  }
                  else resolve()
                })
              })
            } else {
              await new Promise(resolve => {
                mongo.findId('user', doc.actors[i].user, { name: 1 }, (err, user) => {
                  if (user) {
                    if (i === '1') members += user.name
                    else members += ', ' + user.name
                    resolve()
                  }
                  else resolve()
                })
              })
            }
          }
        }
        var tasks = await new Promise((resolve) => {
          mongo.find('task', { project: mongo.toId(doc._id) }, (err, tasks) => {
            if (err) { resolve([]) } else { resolve(tasks) }
          })
        })
        let htmlTasks = ''
        var parents = []
        var level = [0]
        let duration = 0
        let realDuration = 0
        await new Promise(resolve => {
          mongo.find('time', { project: doc._id }, {}, {}, (err, times) => {
            if (times) {
              for (const t in times) {
                if (times[t].user && times[t].duration && times[t].project && times[t].project.toString() === doc._id.toString()) {
                  realDuration += parseFloat(times[t].duration)
                }
              }
              resolve()
            } else resolve()
          })
        })
        var datesStart = []
        var datesEnd = []
        for (let t in tasks) {
          if(tasks[t].type === 'task') {
            duration = duration + parseFloat(tasks[t].duration)
            datesStart.push(new Date(tasks[t].start_date).getTime())
            datesEnd.push(new Date(tasks[t].end_date).getTime())
          }
          let space = '>'
          const p = parents.indexOf(tasks[t].parent.toString())
          if (p === -1) {
            parents = []
            level = [level[0] + 1]
          } else {
            space = ' style="margin-left:' + ((p + 1) * 10) + 'px">'
            parents.splice(p + 1, 100)
            level.splice(p + 1, 100)
            if (level[p + 1]) {
              level[p + 1]++
            } else {
              level.push(1)
            }
          }
          for (const x in level) {
            space += level[x] + '.'
          }
          space += '&nbsp;'
          parents.push(tasks[t].id.toString())
          htmlTasks += '<div' + space + tasks[t].text + '<br><p>'
          htmlTasks += '&nbsp; ' + tasks[t].description + '</div><p>'
          if (tasks[t].documents && tasks[t].documents.length) {
            htmlTasks += '<div style="font-weight:bold;">Documentos</div>'
            for (let d in tasks[t].documents) {
              let document = tasks[t].documents[d]
              let docuTags = ''
              await new Promise(resolve => {
                mongo.findId('document', document, { name: 1, tags: 1 }, (err, docu) => {
                  if (docu) {
                    mongo.findOne('params', { 'options.id': { $in: docu.tags || [] }}, {}, (err, tags) => {
                      if (tags) {
                        for (let u in docu.tags) {
                          for (let o in tags.options) {
                            if (docu.tags[u].toString() === tags.options[o].id.toString()) {
                              if (u === '0') docuTags += tags.options[o].value
                              else docuTags += ', ' + tags.options[o].value
                            }
                          }
                        }
                      }
                      htmlTasks += '<div>* ' + docuTags + ' ' + docu.name + '</div><br>'
                      resolve()
                    })
                  } else {
                    mongo.findId('note', document, { name: 1, tags: 1 }, (err, note) => {
                      if (note) {
                        mongo.findOne('params', { 'options.id': { $in: note.tags || [] }}, {}, (err, tags) => {
                          if (tags) {
                            for (let u in note.tags) {
                              for (let o in tags.options) {
                                if (note.tags[u].toString() === tags.options[o].id.toString()) {
                                  if (u === '0') docuTags += tags.options[o].value
                                  else docuTags += ', ' + tags.options[o].value
                                }
                              }
                            }
                            resolve()
                          }
                          htmlTasks += '<div>* ' + docuTags + ' ' + note.name + '</div><br>'
                          resolve()
                        })
                      } else resolve()
                    })
                  }
                })
              })
            }
          }
        }
        var min = Math.min.apply(null, datesStart)
        var max = Math.max.apply(null, datesEnd)
        let inicio = ''
        let fin = ''
        try {
          if (min && max) {
            inicio = dateformat(new Date(min), 'yyyy/mm/dd')
            fin = dateformat(new Date(max), 'yyyy/mm/dd')
          }
        } catch (err) {
          inicio = dateformat(new Date(), 'yyyy/mm/dd')
          fin = dateformat(new Date(), 'yyyy/mm/dd')
        }
        duration = duration ? (duration / 60).toFixed(2) : duration
        realDuration = realDuration ? (realDuration / 60).toFixed(2) : realDuration
        var notes = await new Promise((resolve) => {
          mongo.find('note', { project: mongo.toId(doc._id) }, (err, notes) => {
            if (err) { resolve([]) } else { resolve(notes) }
          })
        })
        let htmlAtts = ''
        if (notes && notes.length) {
          for (let n in notes) {
            await new Promise(resolve => {
              mongo.find('attached', { reference: notes[n]._id }, { name: 1, content: 1 }, (err, atts) => {
                if (atts) {
                  if (n === '0') htmlAtts += '<div style="font-weight:bold;">Anexos</div>'
                  for (let a in atts) {
                    let num = Number(a) + 1
                    htmlAtts += '<div style="font-weight:bold;">Documento ' + num + ' ' + atts[a].name + '</div><br>'
                    htmlAtts += '<div>' + atts[a].content + '</div><br>'
                  }
                  resolve()
                } else resolve()
              })
            })
          }
        }
        let tipo = doc.type || ''
        var content = '<div>'
        content += '<div style="font-weight:bold;">Nombre del estudio</div>' + doc.name + '<p>'
        content += '<div style="font-weight:bold;">Tipo</div>' + tipo + '<p>'
        content += '<div style="font-weight:bold;">Unidad ejecutora</div>' + unit + '<p>'
        content += '<div style="font-weight:bold;">Unidad analizada</div>' + units + '<p>'
        content += '<div style="font-weight:bold;">Procesos</div>' + processes + '<p>'
        content += '<div style="font-weight:bold;">Categoría</div>' + nameTags + '<p>'
        content += '<div style="font-weight:bold;">Área</div>' + area + '<p>'
        content += '<div style="font-weight:bold;">Nivel de riesgo</div>' + riesgo + '<p>'
        content += '<div style="font-weight:bold;">Personal asignado</div>'
        content += '<div>Gerente</div>' + manager + '<br>'
        content += '<div>Miembros</div>' + members + '<p>'
        content += '<div style="font-weight:bold;">Descripcion</div>' + doc.description + '<p>'
        content += '<div style="font-weight:bold;">Guia de trabajo</div><p>'
        content += htmlTasks
        content += '<div style="font-weight:bold;">Duración estimada</div>' + duration + '<p>'
        content += '<div style="font-weight:bold;">Duración real</div>' + realDuration + '<p>'
        content += '<div style="font-weight:bold;">Fecha inicio</div>' + inicio + '<p>'
        content += '<div style="font-weight:bold;">Fecha fin</div>' + fin + '<p>'
        content += htmlAtts
        content += '</div>'
        // TODO workpapers here
        html.pdf(mongo, req, content, doc.pageType, (err, stream) => {
          if (err) {
            send({ error: err })
          } else {
            send(stream)
          }
        })
      } else {
        send({ error: err })
      }
    })
  }
  //
  this.pdf = function (req, mongo, send) {
    mongo.findId('project', req.query._id, async (err, doc) => {
      if (!err && doc) {
        var content = ''
        // TODO project header
        content += doc.description
        content += '<p style="page-break-after: always;">&nbsp;</p>'
        var users = await new Promise(resolve => {
          const ids = []
          doc.actors.forEach((it) => { ids.push(it.user) })
          mongo.toHash('user', { _id: { $in: ids } }, (err, docs) => {
            if (!err && docs) {
              resolve(docs)
            } else {
              resolve({})
            }
          })
        })
        content += gantt2table(doc.content.data, doc.content.links, users)
        content += '</div>'
        // TODO workpapers here
        html.pdf(mongo, req, content, doc.pageType, (err, stream) => {
          if (err) {
            send({ error: err })
          } else {
            send(stream)
          }
        })
      } else {
        send({ error: err })
      }
    })
    function gantt2table (tasks, links, users) {
      var html = '<style>.cl {width: 100%;background-color:#eee;} .cl td {padding:5px;background-color:#fff;} .cl tr#milestone td{background-color:#eee;}</style>'
      html += '<div style="text-align:center;font-weight:bold;">Plan de trabajo</div>'
      html += '<table class="cl"><tr><th>Tarea</th><th>Encargado</th><th>Duración</th><th>De</th><th>A</th></tr>'
      var parents = []
      var level = [0]
      for (const i in tasks) {
        var task = tasks[i]
        let user = ['task', 'milestone'].includes(task.type) ? task.owner_id : ''
        let space = '>'
        const p = parents.indexOf(task.parent.toString())
        if (p === -1) {
          parents = []
          level = [level[0] + 1]
        } else {
          space = ' style="margin-left:' + ((p + 1) * 10) + 'px">'
          parents.splice(p + 1, 100)
          level.splice(p + 1, 100)
          if (level[p + 1]) {
            level[p + 1]++
          } else {
            level.push(1)
          }
        }
        for (const x in level) {
          space += level[x] + '.'
        }
        space += '&nbsp;'
        parents.push(task.id.toString())
        user = user ? users[user.toString()] ? users[user.toString()].name : '' : ''
        html += '<tr id="' + task.type + '"><td><div' + space + task.text + '</div></td><td>' + user + '</td><td align="right">' +
          task.duration + '</td><td>' + task.start_date + '</td><td>' + task.end_date + '</td></tr>'
      }
      html += '</table>'
      return html
    }
  }

  this.getReports = async function (req, mongo, send) {
    let id = req.query._id
    let type = req.query.type
    let array = []
    if (req.query.type === 'project') {
      await new Promise(resolve => {
        mongo.aggregate('task', [
          { $match: { _id: mongo.toId(id) } },
          { $graphLookup: { from: 'task', startWith: '$_id', connectFromField: '_id', connectToField: 'parent', as: 'supertasks' } },
          { $unwind: { path: '$supertasks', preserveNullAndEmptyArrays: true } },
          { $project: { _id: '$supertasks._id', name: '$supertasks.text' } },
        ], {}, (err, docs) => {
          for (let d in docs) {
            array.push(docs[d]._id)
          }
          resolve()
        })
      })
    } else {
      array = [ mongo.toId(id) ]
    }
    let keys = { document: { $in: array } }

    if (req.query.period) {
      if (req.query.period.start && req.query.period.end) {
        keys.date = { $gte: req.query.period.start, $lte: new Date(new Date(req.query.period.end).setHours(23,59,59)) }
      } else if (req.query.period.start && !req.query.period.end) {
        keys.date = { $gte: req.query.period.start, $lte: new Date(new Date(req.query.period.start).setHours(23,59,59)) }
      }
    }
    mongo.find('time', keys, {}, { _id: -1 }, async (err, docs) => {
      if (err) {
        console.log(err)
        send()
      } else {
        let data = []
        let preStatus = ''
        let total = 0
        for (let i in docs) {
          let doc = docs[i]
          let username = await new Promise(resolve => {
            mongo.findId('user', doc.user, (err, user) => {
              if (user) {
                resolve(user.name)
              } else {
                resolve('')
              }
            })
          })
          let task = await new Promise(resolve => {
            mongo.findId('task', doc.document, (err, task) => {
              if (task) {
                resolve(task)
              } else {
                resolve('')
              }
            })
          })
          let date = ''
          if (doc.date) date = doc.date.toISOString().split('T')[0]
          let duration = 0
          if (doc.duration) {
            doc.duration = Number(doc.duration)
            total += doc.duration
            task.workDay = task.workDay ? Number(task.workDay) : 480
            var v = doc.duration || 0
            var m = v % 60
            var h = (v - m) / 60
            duration = h + 'h : ' + (m < 10 ? '0' + m : m) + 'm'
          }
          let text = task.text ? task.text.length > 70 ? task.text.substring(0, 70) + '...' : task.text : ''
          if (data.length && preStatus === task.status) {
            preStatus = task.status
            task.status = ''
          } else {
            preStatus = task.status
            task.status = task.status|| 'draft'
          }
          let json = {
            id: doc._id,
            order: Number(i) + 1,
            name: text,
            fullname: task.text,
            date: date,
            duration: duration,
            user: doc.user,
            username: username,
            color: task.color || 'gray',
            status: task.status
          }
          data.push(json)
        }
        if (!data.length) {
          data.push({id: 'null'})
        } else {
            let m = total % 60
            let h = (total - m) / 60
            data[0].total = h + 'h : ' + (m < 10 ? '0' + m : m) + 'm'
            //data[0].total = (total / 60).toFixed(2)
        }
        send(data)
      }
    })
  }

  this.saveColumnsDocuments = function (req, mongo, send) {
    var id = req.body._id
    var columns = req.body.columns
    if (id) {
      id = mongo.toId(id)
      mongo.save('task', { _id: id, configColumnsDocuments: columns }, (err, result) => {
        if (err) {
          send({ error: err })
        } else {
          send()
        }
      })
    } else {
      send()
    }
  }

  this.timeline = function (req, mongo, send) {
    let id = req.query._id
    mongo.find('eventTask', { project: mongo.toId(id) }, {}, { _id: -1 },async (err, docs) => {
      if (err) {
        console.log(err)
        send()
      } else {
        let data = []
        for (let i in docs) {
          let doc = docs[i]
          let username = await new Promise(resolve => {
            mongo.findId('user', doc.user, (err, user) => {
              if (user) {
                resolve(user.name)
              } else {
                resolve('')
              }
            })
          })
          let name = await new Promise(resolve => {
            mongo.findId('task', doc.docId, (err, task) => {
              if (task) {
                resolve(task.text)
              } else {
                resolve('')
              }
            })
          })
          function addZero (i) {
            if (i < 10) {
              i = '0' + i;
            }
            return i;
          }
          var d = doc.date
          var h = addZero(d.getHours())
          var m = addZero(d.getMinutes())
          var s = addZero(d.getSeconds())
          data.push({ id: doc._id, value: doc.data, details: username + ' - ' + name, description: doc.description, date: doc.date.toISOString().split('T')[0] + ' a las ' + h + ':' + m + ':' + s })
        }
        send(data)
      }
    })
  }
}