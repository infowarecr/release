var tags = require('../utils/tags').tags
exports.Calc = Calc

function Calc () {
  this.get = function (req, mongo, send) {
    var doc = {}
    mongo.find('calc', {}, {}, {}, (err, calc) => {
      if (err) throw err
      var form = function () {
        var dialog = {
          id: 'CalcGet' + doc._id.toString(),
          width: req.session.screen.lifeW,
          height: req.session.screen.lifeH,
          center: true,
          modal: false,
          caption: 'Calc',
          park: false,
          resize: false
        }

        dialog.form = {
          action: 'calc.save',
          items: [
            { type: 'hidden', name: '_id', value: doc._id },
            { type: 'input', name: 'name', label: 'name:', value: doc.name, inputWidth: 400, rows: 3 },
            {
              type: 'calc',
              name: 'hoja',
              width: req.session.screen.lifeW,
              height: req.session.screen.lifeH,
              value: doc.hoja
            }
          ]
        }

        dialog.form.toolbar = {
          icons_path: 'img/',
          items: [
            { type: 'button', id: 'send', text: tags.save, title: tags.savedChanges, img: 'check.png' }
          ]
        }

        send({ dialog })
      }
      if (calc[0]._id) {
        mongo.findId('calc', calc[0]._id, (err, calc) => {
          if (!err) {
            doc = calc
            form()
          } else {
            send()
          }
        })
      } else {
        doc = { _id: mongo.newId() }
        form()
      }
    })
  }

  this.save = function (req, mongo, send) {
    var doc = req.body
    doc.hoja = JSON.parse(doc.hoja)
    mongo.save('calc', doc, (err, result) => {
      if (err) {
        send({ error: tags.savingProblema })
      } else {
        send({ message: tags.savedChanges })
      }
    })
  }
}
