/* exported */
var tags = require('../utils/tags').tags
exports.Reply = Reply

function Reply () {
  this.grid = function (req, mongo, send) {
    var dialog = {
      id: 'reply',
      width: req.session.screen.lifeW,
      height: req.session.screen.lifeH,
      center: true,
      modal: false,
      caption: 'Prueba',
      park: false,
      resize: false
    }

    dialog.grid = {
      head: [
        { id: 'sales', width: 50, type: 'dyn', align: 'right', sort: 'int', value: 'Sales' },
        { id: 'title', width: 150, type: 'ed', align: 'left', sort: 'str', value: 'Book Title' },
        { id: 'author', width: 100, type: 'ed', align: 'left', sort: 'str', value: 'Author' },
        { id: 'price', width: 80, type: 'price', align: 'right', sort: 'str', value: 'Price' },
        { id: 'instore', width: 80, type: 'ch', align: 'center', sort: 'str', value: 'In Store' },
        { id: 'shipping', width: 80, type: 'co', align: 'left', sort: 'str', value: 'Shipping' }
      ],
      data: [{
        id: 1001,
        sales: '100',
        title: 'A Time to Kill',
        author: 'John Grisham',
        price: '12.99',
        instore: '1',
        shipping: '05/01/1998',
        data: [{
          id: 1002,
          sales: '1000',
          title: 'Blood and Smoke',
          author: 'Stephen King',
          price: '0',
          instore: '1',
          shipping: '01/01/2000',
          data: [

            {
              id: 1003,
              sales: '-200',
              title: 'The Rainmaker',
              author: 'John Grisham',
              price: '7.99',
              instore: '0',
              shipping: '12/01/2001'
            }
          ]
        }]
      }]
    }

    // dialog.grid = {
    //     head: [
    //       { id: 'file', width: '*', type: "tree", align: "left", sort: "str", value: "File" },
    //       { id: 'size', width: '*', type: "ed", align: "left", sort: "int", value: "Size" },
    //     ],
    //     rows: [{
    //         id: 1,
    //         data: [
    //           "C",
    //           "500"
    //         ], rows: [ {
    //         id: 2,
    //         data: [
    //           "Windows",
    //           "200"
    //         ], rows:[{
    //         id: 3,
    //         data: [
    //           "Users",
    //           "300"
    //         ]
    //       }, {id: 4,
    //           data: ["Admin", "150"]
    //       }]
    //       }]
    //       }
    //     ]
    // };

    // dialog.grid.data.rows.push({ id: 1, data: ["C", "500"], rows: [{ id: 2, data: ["Windows", "200"], rows: [{ id: 3, data: ["Users", "300"] }, { id: 4, data: ["Admin", "150"] }] }] });

    send({ dialog })
  }

  this.get = function (req, mongo, send) {
    var doc = {}
    var form = function () {
      var versOpts = [{ text: '6.1', value: '6.1' }, { text: '6.1a', value: '6.1a' }, { text: '6.1b', value: '6.1b' }]

      var dialog = {
        id: 'reply',
        width: req.session.screen.lifeW < 550 ? req.session.screen.lifeW : 550,
        height: req.session.screen.lifeH,
        center: true,
        modal: false,
        caption: 'Prueba',
        park: false,
        resize: false
      }

      dialog.form = {
        action: 'reply.save',
        items: []
      }

      dialog.form.items.push({ type: 'settings', labelAlign: 'top', position: 'label-right', offsetTop: 8 })
      dialog.form.items.push({ type: 'hidden', name: '_id', value: doc._id })
      dialog.form.items.push({
        type: 'fieldset',
        label: 'Encabezado',
        list: [
          { type: 'newcolumn', offset: 10 },
          { type: 'input', name: tags.name, value: doc.name, note: { text: 'Autor' }, width: 250, validate: 'NotEmpty' },
          { type: 'input', name: tags.issue, value: doc.issue, note: { text: 'Asunto' }, width: 250, validate: 'NotEmpty' },
          { type: 'combo', name: tags.versions, value: doc.versions, inputWidth: 250, note: { text: 'Versión' }, options: versOpts }
        ]
      })
      dialog.form.items.push({
        type: 'fieldset',
        label: 'Descripcion',
        list: [
          { type: 'redactor', config: 'full', name: tags.description, value: doc.description, required: true, width: req.session.screen.w * 0.45 }
        ]
      })

      dialog.form.toolbar = {
        icons_path: 'img/',
        items: [
          { type: 'button', id: 'send', text: tags.save, title: tags.savedChanges, img: 'check.png' }
        ]
      }
      send({ dialog })
    }
    if (req.query._id) {
      mongo.findId('reply', req.query._id, (err, user) => {
        if (!err) {
          doc = user
          form()
        } else {
          send()
        }
      })
    } else {
      doc = { _id: mongo.newId() }
      form()
    }
    // send({error:"hola"});
  }

  this.list = function (req, mongo, send) {
    if (!req.query.flow) {
      var dialog = {
        id: 'reply',
        width: req.session.screen.lifeW,
        height: req.session.screen.lifeH,
        center: true,
        modal: false,
        caption: 'Prueba',
        park: false,
        resize: false
      }

      dialog.toolbar = {
        icons_path: 'img/',
        items: [
          { type: 'text', text: tags.filter, class: 'search' },
          { type: 'buttonInput', id: tags.search, width: 200, userdata: { path: 'reply.list?flow=1' } },
          { type: 'text', id: tags.search + 'Count', text: '...' },
          { type: 'button', id: tags.new, text: tags.new, title: 'New User', userdata: { cmd: { url: { ref: 'reply.get' } } }, width: 60 },
          { type: 'button', id: 'grid', text: 'grid', title: 'New Grid', userdata: { cmd: { url: { ref: 'reply.grid' } } }, width: 60 }
        ]
      }

      dialog.dataView = {
        autowidth: 1,
        type: {
          template: "<div class='cite'><span'>'#name#'</span><br/>#issue#</div>",
          height: 50
        },
        load: 'reply.list?flow=1',
        click: 'reply.get?_id=#_id#',
        drag: true,
        canRemove: false

      }
      send({ dialog })
    } else {
      var keys = {}
      if (req.query.search) {
        var txt = new RegExp(req.query.search.replace(/ /g, '.*'), 'i')
        keys = { $or: [{ name: txt }, { issue: txt }] }
      }

      if (req.query.posStart) {
        this.sendData(mongo, {}, keys, Number(req.query.posStart), Number(req.query.count), send)
      } else {
        mongo.count('reply', keys, (err, count) => {
          if (err) {
            send({ error: err })
          } else {
            if (count > 50) {
              this.sendData(mongo, { total_count: count }, keys, 0, 50, send)
            } else {
              this.sendData(mongo, {}, keys, 0, count, send)
            }
          }
        })
      }
    }
  }

  this.sendData = function (mongo, body, keys, skip, limit, send) {
    mongo.findN('reply', skip, limit, keys, { _id: 1, name: 1, issue: 1, versions: 1, description: 1 }, { name: 1 }, (err, docs) => {
      if (err) {
        send({ error: err })
      } else {
        for (let x in docs) {
          docs[x].id = docs[x]._id
        }
        body.pos = skip
        body.data = docs
        send(body)
      }
    })
  }

  this.save = function (req, mongo, send) {
    var doc = req.body

    mongo.save('reply', doc, (err, result) => {
      if (err) {
        send({ error: tags.savingProblema })
      } else {
        send({ message: tags.savedChanges })
        req.broadcast.formSaved('reply', getDVItem(doc))
      }
    })
  }

  function getDVItem (doc) {
    return {
      id: doc._id.toString(),
      name: doc.name,
      issue: doc.issue
    }
  }
}
