/* exported */
exports.Event = Event
var Notification = require('../utils/notification').Notification
var notification = new Notification()

function Event () {
  /** get Event */
  this.get = async function (req, mongo, send) {
    if (req.query._id) {
      mongo.findId('riskEvent', req.query._id, (err, event) => {
        if (err) {
          send({ error: err })
        } else {
          if (event.dateEvent) event.dateEvent = formatDateAndTime(event.dateEvent)
          if (event.dateReport) event.dateReport = formatDateAndTime(event.dateReport)
          if (event) { send(event) } else { send({ _id: mongo.newId(), dateReport: event.dateReport, dateEvent: event.dateEvent }) }
        }
      })
    } else if (req.query.userId) {
      var user = ''
      await new Promise(resolve => {
        mongo.findOne('user', { _id: mongo.toId(req.query.userId) }, (err, users) => {
          if (err) {
            resolve(false)
          } else {
            if (users) {
              user = users._id
            }
            resolve()
          }
        })
      })
      var currentDate = formatDateAndTime(new Date())
      await new Promise(resolve => {
        mongo.findOne('settings', { _id: 'settings' }, (err, sett) => {
          if (err) {
            resolve(false)
          } else {
            if (sett) {
              var timeZone = parseFloat(sett.hours)
              if (timeZone !== -6) {
                currentDate = formatCurrentDate(new Date(), timeZone)
              }
            }
            resolve()
          }
        })
      })
      send({ dateReport: currentDate, user: user })
    }
  }

  function formatDateAndTime (obj) {
    var date = obj.getFullYear() + '/' + (obj.getMonth() + 1) + '/' + obj.getDate()
    var time = obj.getHours() + ':' + obj.getMinutes() + ':' + obj.getSeconds()
    return date + ' ' + time
  }

  function trimTime (obj) {
    var dateWithoutTime = new Date(obj)
    dateWithoutTime.setHours(0, 0, 0)
    dateWithoutTime = new Date(dateWithoutTime)
    return dateWithoutTime
  }

  function formatCurrentDate (obj, timeZone) {
    var date = obj.getFullYear() + '/' + (obj.getMonth() + 1) + '/' + obj.getDate()
    var time = (obj.getHours() + timeZone) + ':' + obj.getMinutes() + ':' + obj.getSeconds()
    return date + ' ' + time
  }

  /** list Events */
  this.list = function (req, mongo, send) {
    var keys = {}
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    var query = {}
    if (req.query.filter) {
      for (const name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          // if ((name === "dateEvent" && req.query.filter["dateEvent"].start !== null && req.query.filter["dateEvent"].end !== null) || (name === "dateReport" && req.query.filter["dateReport"].start !== null && req.query.filter["dateReport"].end !== null)) {
          if (name === 'user') {
            query.user = mongo.toId(req.query.filter.user)
          } else if (name === 'unit') {
            query.unit = mongo.toId(req.query.filter.unit)
          } else if (name === 'riskFactor') {
            query.riskFactor = mongo.toId(req.query.filter.riskFactor)
          } else if (name === 'name') {
            const text = req.query.filter.name
            if (!text.includes('"') && (text.includes(' ') || text.includes('-') || text.includes('/') || text.includes(':'))) {
              query.$text = { $search: '"' + text.replace(/ /g, '" "') + '"' }
            } else {
              query.$text = { $search: text }
            }
          } else if (req.query.filter[name] !== '' && name !== 'dateEvent' && name !== 'dateReport') {
            query[name] = req.query.filter[name].indexOf(',') !== -1 ? { $in: req.query.filter[name].split(',') } : new RegExp(req.query.filter[name].replace(/ /g, '.*'), 'i')
          }
          // }
        }
      }
      keys = { $and: [query, keys] }
    }
    var pipeline = [{ $match: keys }, { $skip: skip }, { $limit: limit }]
    pipeline.push({ $lookup: { from: 'user', localField: 'user', foreignField: '_id', as: 'tuser' } })
    pipeline.push({ $lookup: { from: 'unit', localField: 'unit', foreignField: '_id', as: 'tunid' } })
    pipeline.push({ $lookup: { from: 'risk', localField: 'riskFactor', foreignField: '_id', as: 'trisk' } })
    pipeline.push({
      $addFields: {
        dateEventF: { date: '$dateEvent' },
        dateReportF: { date: '$dateReport' }
      }
    })
    pipeline.push({
      $project: {
        _id: 1,
        user: '$tuser',
        dateEvent: '$dateEventF',
        dateReport: '$dateReportF',
        unit: 1,
        name: 1,
        unitName: '$tunid',
        riskFactor: '$trisk'
      }
    })
    mongo.aggregate('riskEvent', pipeline, {}, (err, events) => {
      if (err || !events) {
        send({ error: err })
      } else {
        reply.data = []
        for (const f in events) {
          events[f].id = events[f]._id
          if (req.query.filter) {
            var dateEventFilter = req.query.filter.dateEvent.start !== null && req.query.filter.dateEvent.end !== null
            var dateReportFilter = req.query.filter.dateReport.start !== null && req.query.filter.dateReport.end !== null
            var fromDate = trimTime(req.query.filter.dateEvent.start)
            var toDate = trimTime(req.query.filter.dateEvent.end)

            var fromDateR = trimTime(req.query.filter.dateReport.start)
            var toDateR = trimTime(req.query.filter.dateReport.end)

            if (dateEventFilter && dateReportFilter) {
              if (((trimTime(events[f].dateEvent.date) >= fromDate) && (trimTime(events[f].dateEvent.date) <= toDate)) && ((trimTime(events[f].dateReport.date) >= fromDateR) && (trimTime(events[f].dateReport.date) <= toDateR))) {
                var pos = reply.data.findIndex((x) => {
                  return x._id.toString() === events[f]._id.toString()
                })
                if (pos === -1) {
                  reply.data.push(events[f])
                }
              } else {
                reply.data.splice(f, 1)
              }
            } else {
              if (dateEventFilter) {
                fromDate = trimTime(req.query.filter.dateEvent.start)
                toDate = trimTime(req.query.filter.dateEvent.end)
                if ((trimTime(events[f].dateEvent.date) >= fromDate) && (trimTime(events[f].dateEvent.date) <= toDate)) {
                  pos = reply.data.findIndex((x) => {
                    return x._id.toString() === events[f]._id.toString()
                  })
                  if (pos === -1) {
                    reply.data.push(events[f])
                  }
                } else {
                  reply.data.splice(f, 1)
                }
              } else
              if (dateReportFilter) {
                if ((trimTime(events[f].dateReport.date) >= fromDateR) && (trimTime(events[f].dateReport.date) <= toDateR)) {
                  pos = reply.data.findIndex((x) => {
                    return x._id.toString() === events[f]._id.toString()
                  })
                  if (pos === -1) {
                    reply.data.push(events[f])
                  }
                } else {
                  reply.data.splice(f, 1)
                }
              } else {
                pos = reply.data.findIndex((x) => {
                  return x._id.toString() === events[f]._id.toString()
                })
                if (pos === -1) {
                  reply.data.push(events[f])
                }
              }
            }
          } else {
            reply.data.push(events[f])
          }
        }
        if (skip) {
          send(reply)
        } else {
          mongo.count('riskEvent', {}, (err, count) => {
            if (!err && count) {
              reply.total_count = count
            }

            for (const f in reply.data) {
              var events = reply.data
              events[f].dateEvent = formatDateAndTime(events[f].dateEvent.date)
              events[f].dateReport = formatDateAndTime(events[f].dateReport.date)
            }
            send(reply.data)
          })
        }
      }
    })
  }
  this.asOptions = function (req, mongo, send) {
    mongo.find('factor', {}, { name: 1 }, (err, facts) => {
      if (err || !facts) {
        send({ error: err })
      } else {
        var events = []
        for (const f in facts) {
          events.push({ id: facts[f]._id, value: facts[f].name })
        }
        send(events)
      }
    })
  }
  /** find specific factor */
  this.findFactor = function (req, mongo, send) {
    mongo.findId('factor', req.query._id, (err, factor) => {
      if (err) {
        send({ error: err })
      } else {
        send({ score: factor.score })
      }
    })
  }

  this.findEventsWithRiskFactor = async function (req, mongo, send) {
    var keys = { riskFactor: mongo.toId(req.query.idRiskFactor) }
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }

    var pipeline = [{ $match: keys }, { $skip: skip }, { $limit: limit }]
    pipeline.push({ $lookup: { from: 'user', localField: 'user', foreignField: '_id', as: 'tuser' } })
    pipeline.push({ $lookup: { from: 'unit', localField: 'unit', foreignField: '_id', as: 'tunid' } })
    pipeline.push({ $lookup: { from: 'risk', localField: 'riskFactor', foreignField: '_id', as: 'trisk' } })
    pipeline.push({
      $addFields: {
        dateEventF: { date: '$dateEvent' },
        dateReportF: { date: '$dateReport' }
      }
    })
    pipeline.push({
      $project: {
        _id: 1,
        user: '$tuser',
        dateEvent: '$dateEventF',
        dateReport: '$dateReportF',
        unit: 1,
        name: 1,
        unitName: '$tunid',
        riskFactor: '$trisk'
      }
    })

    mongo.aggregate('riskEvent', pipeline, {}, (err, events) => {
      if (err || !events) {
        send({ error: err })
      } else {
        for (const f in events) {
          events[f].id = events[f]._id
          events[f].dateEvent = formatDateAndTime(events[f].dateEvent.date)
          events[f].dateReport = formatDateAndTime(events[f].dateReport.date)
        }
        reply.data = events
        if (skip) {
          send(reply)
        } else {
          mongo.count('riskEvent', {}, (err, count) => {
            if (!err && count) {
              reply.total_count = count
            }
            send(reply.data)
          })
        }
      }
    })
  }
  /** save Event */
  this.save = function (req, mongo, send) {
    var doc = req.body
    if (!doc._id) {
      doc._id = mongo.newId()
    }
    doc.user = req.session.context.user
    mongo.save('riskEvent', doc, (err, result) => {
      if (err) {
        send({ error: err })
      } else {
        send()
        doc.id = doc._id
        notification.send(req, req.session.context.room, 'dt_events', doc, null, null)
      }
    })
  }
  /** delete factor */
  this.delete = function (req, mongo, send) {
    var doc = req.query
    mongo.findId('riskEvent', mongo.toId(doc._id), (err, factor) => {
      if (err) {
        send({ error: err })
      } else {
        mongo.deleteOne('riskEvent', { _id: mongo.toId(doc._id) }, (err, result) => {
          if (err) {
            req.logger.log(err)
          } else {
            req.app.routes.trash.insert(req, mongo, 'riskEvent', factor, () => {
              send()
              doc.id = doc._id
              notification.send(req, req.session.context.room, 'dt_events', doc, null, true)
            })
          }
        })
      }
    })
  }
}
