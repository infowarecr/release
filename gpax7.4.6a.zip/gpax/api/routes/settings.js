var tags = require('../utils/tags').tags
var path = require('path')
var mimeTypes = require('mime-types')
var fs = require('fs')

/* exported */
exports.Settings = Settings

function Settings () {
  this.get = function (req, mongo, send) {
    mongo.findOne('settings', { _id: 'settings' }, (err, doc) => {
      if (err) { send() } else {
        settingsExists(doc, (doc) => {
          if (doc.password) {
            try {
              doc.password = tags.util.Decipher(doc.password)
            } catch (err) {
              doc.password = ''
            }
          }
          doc._id = 'settings'
          if (doc.rpaUser && doc.rpaUser.toString) {
            doc.rpaUser = doc.rpaUser + '&unit=' + doc.rpaUnit
          }
          if (doc.rpaUsers && doc.rpaUsers[0]) {
            const users = []
            for (const k in doc.rpaUsers) {
              users.push(doc.rpaUsers[k].user + '&unit=' + doc.rpaUsers[k].unit)
            }
            doc.rpaUsers = users.join(',')
          }
          /* if (docs.copies !== '' && !docs.copies.length) {
              docs.copies = [docs.copies]
            } */
          doc.workDay = req.session.context.workDay
          send(doc)
        })
      }
    })

    function settingsExists (doc, next) {
      if (!doc) {
        mongo.find('settings', {}, (err, docs) => {
          if (!err && docs && docs.length > 0) {
            next(docs[0])
          } else {
            next({})
          }
        })
      } else {
        next(doc)
      }
    }
  }

  this.getEmailAccount = function (req, mongo, send) {
    mongo.findOne('emailAccount', { userId: req.session.context.user }, {}, (err, doc) => {
      if (err) { send() } else if (doc) {
        if (doc.password) {
          try {
            doc.password = tags.util.Decipher(doc.password)
          } catch (err) {
            doc.password = ''
          }
        }
        send(doc)
      } else {
        send()
      }
    })
  }

  this.saveEmailAccount = function (req, mongo, send) {
    var doc = req.body
    if (!doc._id) { doc._id = mongo.newId() }
    if (!doc.userId) { doc.userId = req.session.context.user }
    try {
      doc.password = tags.util.Cipher(doc.password)
    } catch (err) {
      doc.password = ''
    }
    mongo.save('emailAccount', doc, (err) => {
      if (err) {
        send({ error: tags.savingProblem })
      } else {
        send()
      }
    })
  }

  this.image = function (req, mongo, send) {
    mongo.findOne('settings', { _id: 'settings' }, (err, doc) => {
      if (err || !doc) {
        send({ error: err })
      } else {
        if (doc.photo && mongo.isNativeId(doc.photo)) {
          mongo.getfile(doc.photo, (err, stream) => {
            if (!err) {
              send(stream)
            } else {
              fs.readFile(path.join(__dirname, '/../img/photo.png'), (err, data) => {
                if (err) throw err
                send(data)
              })
            }
          })
        } else {
          fs.readFile(path.join(__dirname, '/../img/photo.png'), (err, data) => {
            if (err) throw err
            send(data)
          })
        }
      }
    })
  }

  this.setImage = function (req, mongo, send) {
    mongo.findOne('settings', { _id: 'settings' }, (err, doc) => {
      if (err || !doc) {
        send({ error: err })
      } else {
        mongo.savefile(req, (err, result) => {
          if (!err) {
            var id = result.link
            id = id.split('_id=')[1].split('&')[0]
            mongo.save('settings', { _id: doc._id, photo: mongo.toId(id) }, (err) => {
              if (err) throw err
              result.status = 'server'
              send(result)
            })
          } else {
            send()
          }
        })
      }
    })
  }

  this.save = async function (req, mongo, send) {
    var doc = req.body
    try {
      doc.password = tags.util.Cipher(doc.password)
      doc.auditUnit = doc.auditUnit.length >= 24 ? doc.auditUnit.split(',') : []
      doc.directory = doc.directory.length >= 24 ? doc.directory.split(',') : []
    } catch (err) {
      doc.password = ''
    }
    mongo.findOne('settings', { _id: 'settings' }, async (err, sett) => {
      if (err) throw err
      if (sett) { doc._id = sett._id } else { doc._id = 'settings' }
      if (doc.days) {
        doc.days = parseInt(doc.days)
      } else {
        doc.days = 0
      }
      if (doc.hours) {
        doc.hours = parseInt(doc.hours)
      } else {
        doc.hours = -6
      }
      if (doc.rpaUser && doc.rpaUser.length > 0) {
        const data = doc.rpaUser.split('&unit=')
        doc.rpaUser = mongo.toId(data[0])
        doc.rpaUnit = mongo.toId(data[1])
      }
      if (doc.rpaUsers && doc.rpaUsers.length > 0) {
        const users = doc.rpaUsers.split(',')
        doc.rpaUsers = []
        for (const k in users) {
          const data = users[k].split('&unit=')
          doc.rpaUsers.push({ user: mongo.toId(data[0]), unit: mongo.toId(data[1]) })
        }
      }
      if (doc.copies !== '') {
        if (typeof doc.copies === 'string') {
          doc.copies = doc.copies.split(',')
        }

        for (const i in doc.copies) {
          doc.copies[i] = mongo.toId(doc.copies[i])
        }
      }
      if (doc.performanceForms !== '') {
        if (typeof doc.performanceForms === 'string') {
          doc.performanceForms = doc.performanceForms.split(',')
        }

        for (const i in doc.performanceForms) {
          doc.performanceForms[i] = mongo.toId(doc.performanceForms[i])
        }
      }
      if (doc.commitmentTemplate !== '') {
        if (typeof doc.commitmentTemplate === 'string') {
          doc.commitmentTemplate = doc.commitmentTemplate.split(',')
        }

        for (const i in doc.commitmentTemplate) {
          doc.commitmentTemplate[i] = mongo.toId(doc.commitmentTemplate[i])
        }
      }
      if (doc.auditCommitee !== '') {
        if (typeof doc.auditCommitee === 'string') {
          doc.auditCommitee = doc.auditCommitee.split(',')
        }

        for (const i in doc.auditCommitee) {
          doc.auditCommitee[i] = mongo.toId(doc.auditCommitee[i])
        }
      }

      if (doc.evidenceTemplate !== '') {
        if (typeof doc.evidenceTemplate === 'string') {
          doc.evidenceTemplate = doc.evidenceTemplate.split(',')
        }

        for (const i in doc.evidenceTemplate) {
          doc.evidenceTemplate[i] = mongo.toId(doc.evidenceTemplate[i])
        }
      }

      if (doc.authMethodLicensed.length > 0) {
        const methods = doc.authMethodLicensed.split(',')
        doc.authMethodLicensed = methods
      }

      if (doc.authMethodUnLicensed.length > 0) {
        const methods2 = doc.authMethodUnLicensed.split(',')
        doc.authMethodUnLicensed = methods2
      }

      if (sett && sett.realm && sett.realm !== doc.realm) {
        var pipeline = []
        pipeline.push({ $match: { active: true, login: { $exists: true } } })
        pipeline.push({
          $project: {
            login: 1,
            name: 1,
            active: 1,
            adUser: { $concat: ['$login', '@', doc.realm] },
            multi: true
          }
        })
        await new Promise(resolve => {
          mongo.aggregate('user', pipeline, {}, async (err, result) => {
            if (err) {
              resolve(false)
            } else {
              var usersDb = req.app.getMongo(req.app.params.user)
              for (const u in result) {
                await new Promise(resolve => {
                  usersDb.find('user', { login: result[u].login, _id: result[u]._id }, async (err, user) => {
                    if (err) {
                      resolve()
                    } else {
                      await new Promise(resolve => {
                        usersDb.save('user', result[u], async (err, findUser) => {
                          if (err) {
                            resolve()
                          } else {
                            resolve(findUser)
                          }
                        })
                      })
                      resolve(user)
                    }
                  })
                })
              }
              resolve(result)
            }
          })
        })
      }
      mongo.save('settings', doc, (err) => {
        if (err) {
          send({ error: tags.savingProblem })
        } else {
          send()
        }
      })
    })
  }

  this.saveScale = function (req, mongo, send) {
    var doc = req.body

    mongo.findOne('settings', { _id: 'riskScale' }, (err, sett) => {
      if (err) throw err
      if (sett) {
        doc._id = sett._id
      } else {
        doc._id = 'riskScale'
      }

      mongo.save('settings', doc, (err) => {
        if (err) {
          send({ error: tags.savingProblem })
        } else {
          send()
        }
      })
    })
  }

  this.getScale = function (req, mongo, send) {
    mongo.findOne('settings', { _id: 'riskScale' }, (err, doc) => {
      if (err) { send() } else {
        settingsExists(doc, (doc) => {
          doc._id = 'riskScale'
          send(doc)
        })
      }
    })

    function settingsExists (doc, next) {
      if (!doc) {
        mongo.find('settings', {}, (err, docs) => {
          if (!err && docs && docs.length > 0) {
            next(docs[0])
          }
        })
      } else {
        next(doc)
      }
    }
  }


}
