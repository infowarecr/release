exports.Consecutive = Consecutive

function Consecutive () {
  this.list = function (req, mongo, send) {
    var doc = req.query.company
    mongo.find('consecutive', { company: doc }, {}, {}, (err, consecutives) => {
      if (err) {
        send(err)
      } else {
        for (var i in consecutives) {
          consecutives[i].id = consecutives[i]._id
        }
        send(consecutives)
      }
    })
  }

  this.save = function (req, mongo, send) {
    var doc = req.body
    if (doc.id) delete doc.id
    doc.value = parseInt(doc.value)
    mongo.save('consecutive', doc, (err, result) => {
      if (err) {
        send(err)
      } else {
        send()
      }
    })
  }

  this.delete = function (req, mongo, send) {
    var id = req.body.id
    mongo.deleteOne('consecutive', { _id: mongo.toId(id) }, (err, result) => {
      if (err) {
        send(err)
      } else {
        send()
      }
    })
  }
}
