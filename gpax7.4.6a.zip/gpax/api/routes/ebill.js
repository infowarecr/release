/* eslint-disable no-inner-declarations */
/* eslint-disable no-console */

var base64 = require('base-64')
var utf8 = require('utf8')
var fs = require('fs')

var jsonxml = require('jsontoxml')
// eslint-disable-next-line no-undef
var xml2js = require('xml2js')
var parser = new xml2js.Parser()
/* exported */
exports.EBill = EBill

function EBill () {
  // eslint-disable-next-line no-undef
  this.thread = process.env.pm_id || 0
  this.parseData = function (req) {
    var data = req.body || {}
    if (req.query) {
      for (var field in req.query) {
        data[field] = req.query[field]
      }
    }
    return data
  }

  this.prueba = function (req, mongo, send, data) {
    var observacion = 'observacion'; var adicional1 = 'PM'
    var adicional2 = 'numeroVendedor'; var adicional3 = 'lugarEntrega'; var adicional4 = 'fechaOrdenCompra'
    var adicional5 = 'numeroRecepcion'; var adicional6 = 'header[37]'; var adicional7 = 'ordenCompra'
    var adicional8 = ' header[39]'; var adicional9 = 'header[40]'; var adicional10 = 'header[41]'

    var Otros = []
    var otroTexto = []
    if (adicional1 === 'PM') {
      otroTexto.push({ name: 'OtroTexto', text: observacion })
      if (adicional7 !== '') { otroTexto.push({ name: 'OtroTexto', text: adicional7 }) }
      if (adicional4 !== '') { otroTexto.push({ name: 'OtroTexto', text: adicional4 }) }

      Otros.push(otroTexto)
      Otros.push({
        name: 'OtroContenido',
        children: [
          {
            name: 'retail:Complemento',
            attrs:
            {
              'xsi:schemaLocation': 'https://invoicer.ekomercio.com/esquemas https://invoicer.ekomercio.com/esquemas/ComplementoPricesmartCRV10.xsd',
              'xmlns:xsi': 'http://www.w3.org/2001/XMLSchema-instance',
              'xmlns:retail': 'https://invoicer.ekomercio.com/esquemas'
            },
            children: [
              { name: 'retail:NumeroVendedor', text: adicional2 },
              {
                name: 'retail:LugarDeEntrega',
                children: [
                  { name: 'retail:GLNLugarDeEntrega', text: adicional3 }
                ]
              }
            ]
          }
        ]
      })
    } else if (adicional1 === 'WM') {
      otroTexto.push({ name: 'OtroTexto', text: observacion })
      if (adicional7 !== '') { otroTexto.push({ name: 'OtroTexto', text: adicional7 }) }
    } else if (adicional1 === 'AM') {
      otroTexto.push({ name: 'OtroTexto', text: adicional2, attrs: { codigo: 'AUTOMERCADO_PROVEEDOR' } })
      otroTexto.push({ name: 'OtroTexto', text: adicional7, attrs: { codigo: 'AUTOMERCADO_ORDEN_COMPRA' } })
      otroTexto.push({ name: 'OtroTexto', text: adicional3, attrs: { codigo: 'AUTOMERCADO_GLN_CLIENTE' } })
      otroTexto.push({ name: 'OtroTexto', text: adicional4, attrs: { codigo: 'AUTOMERCADO_FECHA_ORDEN_COMPRA' } })
      otroTexto.push({ name: 'OtroTexto', text: observacion })
      Otros.push(otroTexto)
    } else if (adicional1 === 'GQ') {
      otroTexto.push({ name: 'OtroTexto', text: adicional7, attrs: { codigo: 'OC' } })
      otroTexto.push({ name: 'OtroTexto', text: observacion })
      Otros.push(otroTexto)
    } else {
      otroTexto.push({ name: 'OtroTexto', text: observacion })
      Otros.push(otroTexto)
    }

    var xmlArray = [
      Otros
    ]

    var xml = jsonxml({
      XML: xmlArray
    }, { xmlHeader: true })

    console.log(xml)
  }
  this.nextSequence = async function (mongo, key, field) {
    var seq = await new Promise(resolve => {
      var inc = { $inc: {} }
      inc.$inc['consecutive.$.' + field] = 1
      var res = {}
      res['consecutive.$.' + field] = 1
      mongo.findOneAndUpdate('company', key, inc, res, (err, result) => {
        if (err) {
          resolve(-1)
        } else {
          var consecutivo = pad(result.value.consecutive[0][field].toString(), 10)
          resolve(consecutivo)
        }
      })
    })
    return seq
  }
  /*
   * params: header,details,others
   * reply: {numericKey:"0.....50"} ó {error:"code", message:"message"}
   */
  this.getDeadCert = function (req, mongo, send, data) {
    var chilkat = require('@chilkat/ck-node14-linux64')
    var fs = require('fs')
    if (!data) { data = this.parseData(req) }
    if (data.id) {
      mongo.findOne('company', { idNum: data.id }, {}, (err, comp) => {
        if (comp) {
          if (comp.description && comp.description.split('?_id=')[1]) {
            var fileId = comp.description.split('?_id=')[1]
            fileId = fileId.split('&')[0]
            req.app.routes.file.get({ _id: fileId, type: 'p12' }, mongo, (result) => {
              var tmp = '/tmp/' + result.filename
              var file = fs.createWriteStream(tmp)
              file.on('finish', function () {
                var cert = new chilkat.Cert()
                var success = cert.LoadPfxFile(tmp, comp.pin)
                if (success === true) {
                  send({ message: 'El certificado vence el ' + new Date(cert.ValidToStr).toISOString() })
                  comp.deadCert = new Date(cert.ValidToStr)
                  mongo.save('company', comp, () => {})
                } else {
                  send({ error: 'error', message: 'Ocurrio un error' })
                }
              })
              result.pipe(file)
            })
          } else {
            send({ error: 'error', message: 'Esta compañia no posee un certificado' })
          }
        } else {
          if(err) send({ error: 'error', message: 'Ocurrio un error' })
          else send({ error: 'wrongData', message: 'No se encontro esta compañia' })
        }
      })
    } else{
      send({ error: 'wrongData', message: 'Por favor envia una cedula' })
    }

  }

  this.invoice = function (req, mongo, send, data) {
    var chilkat = require('@chilkat/ck-node14-linux64')
    var envCompany = ''
    if (!data) { data = this.parseData(req) }
    var docFactura = {}
    docFactura._id = mongo.newId()
    docFactura.detalles = []
    docFactura.otrosCargos = []
    if (req.app.params.ebillEnvironment) envCompany = req.app.params.ebillEnvironment
    else envCompany = 'Pruebas'
    var header = data.header.split('|')
    if (header && header.length >= 42) {
      mongo.findOne('company', { idNum: header[0], environment: envCompany }, {}, (err, CP) => {
        if (err || (CP && CP.inactive && CP.inactive === '1')) {
          send({ error: 'notFound', message: 'Cliente ' + header[0] + ' inhabilitado para envio/recepción de documentos electronicos. Por favor contacte con su proveedor de sistema' })
        } else {
          if (header[48] && header[48] !== '') {
            /** Datos Encabezado */
            var entidad = header[0]; var consecutivo2 = header[1]; var tipoDoc = header[2]
            var fechaDoc = header[3]; var condicion = header[4]; var plazo = header[5]
            var subtotal = header[6]; var impuestos = header[7]; var descuentos = header[8]
            var moneda = header[9]; var tipoCambio = header[10]; var enviarFactura = header[11]
            var copiaCortesia = header[12]; var nombreCliente = header[13]; var telefonoCliente = header[14]
            var cedulaCliente = header[15]; var direccionCliente = header[16]; var numeroAreaTelefono = header[17]
            var tipoIdentificacion = header[18]; var extranjero = header[19]; var provinvia = header[20]
            var canton = header[21]; var distrito = header[22]; var barrio = header[23]
            var medioPago1 = header[24]; var medioPago2 = header[25]; var medioPago3 = header[26]
            var medioPago4 = header[27]; var situacion = header[28]; var sucursal = header[29]
            var terminal = header[30]; var observacion = header[31]; var adicional1 = header[32]
            var adicional2 = header[33]; var adicional3 = header[34]; var adicional4 = header[35]
            var adicional5 = header[36]; var adicional6 = header[37]; var adicional7 = header[38]
            var adicional8 = header[39]; var adicional9 = header[40]; var adicional10 = header[41]
            var indicador = header[42]; var numContingencia = header[43]; var tipoDocRef = header[44]
            var CodReferencia = header[45]; var razonContingencia = header[46]; var fechaContingencia = header[47]

            if (fechaContingencia && fechaContingencia !== '') {
              const dateFechaCon = new Date(fechaContingencia)
              fechaContingencia = dateFechaCon.getFullYear() +
                '-' + pad2(dateFechaCon.getMonth() + 1) +
                '-' + pad2(dateFechaCon.getDate()) +
                'T' + pad2(dateFechaCon.getHours()) +
                ':' + pad2(dateFechaCon.getMinutes()) +
                ':' + pad2(dateFechaCon.getSeconds()) +
                '-06:00'
            }
            /** nuevo campos */
            var CodigoActividad = header[48]; var IVADevuelto = header[49]
            /** *Campo Otros PM,WM,GQ,AM */
            var Otros = []
            var otroTexto = []
            if (adicional1 === 'PM') {
              otroTexto.push({ name: 'OtroTexto', text: observacion })
              if (adicional7 !== '') { otroTexto.push({ name: 'OtroTexto', text: adicional7 }) }
              if (adicional4 !== '') { otroTexto.push({ name: 'OtroTexto', text: adicional4 }) }

              Otros.push(otroTexto)
              Otros.push({
                name: 'OtroContenido',
                children: [
                  {
                    name: 'retail:Complemento',
                    attrs:
                    {
                      'xsi:schemaLocation': 'https://invoicer.ekomercio.com/esquemas https://invoicer.ekomercio.com/esquemas/ComplementoPricesmartCR_V1_0.xsd',
                      'xmlns:xsi': 'http://www.w3.org/2001/XMLSchema-instance',
                      'xmlns:retail': 'https://invoicer.ekomercio.com/esquemas'
                    },
                    children: [
                      { name: 'retail:NumeroVendedor', text: adicional2 },
                      {
                        name: 'retail:LugarDeEntrega',
                        children: [
                          { name: 'retail:GLNLugarDeEntrega', text: adicional3 }
                        ]
                      }
                    ]
                  }
                ]
              })
            } else if (adicional1 === 'WM') {
              otroTexto.push({ name: 'OtroTexto', text: observacion })
              if (adicional7 !== '') { otroTexto.push({ name: 'OtroTexto', text: adicional7 }) }
            } else if (adicional1 === 'AM') {
              otroTexto.push({ name: 'OtroTexto', text: adicional2, attrs: { codigo: 'AUTOMERCADO_PROVEEDOR' } })
              otroTexto.push({ name: 'OtroTexto', text: adicional7, attrs: { codigo: 'AUTOMERCADO_ORDEN_COMPRA' } })
              otroTexto.push({ name: 'OtroTexto', text: adicional3, attrs: { codigo: 'AUTOMERCADO_GLN_CLIENTE' } })
              otroTexto.push({ name: 'OtroTexto', text: adicional4, attrs: { codigo: 'AUTOMERCADO_FECHA_ORDEN_COMPRA' } })
              otroTexto.push({ name: 'OtroTexto', text: observacion })
              Otros.push(otroTexto)
            } else if (adicional1 === 'GQ') {
              otroTexto.push({ name: 'OtroTexto', text: adicional7, attrs: { codigo: 'OC' } })
              otroTexto.push({ name: 'OtroTexto', text: observacion })
              Otros.push(otroTexto)
            } else if (adicional1 === 'CB') {
              otroTexto.push({ name: 'OtroTexto', text: adicional5, attrs: { codigo: 'NoDocumento' } })
              otroTexto.push({ name: 'OtroTexto', text: observacion })
              Otros.push(otroTexto)
            } else {
              otroTexto.push({ name: 'OtroTexto', text: observacion })
              Otros.push(otroTexto)
            }
            /** Fin otros */
            indicador = indicador || '0'
            IVADevuelto = IVADevuelto !== '0' ? parseFloat(IVADevuelto) : 0
            /** Datos Detalle_Facturas */
            var TotalServGravados = 0.00000
            var TotalServExentos = 0.00000
            var TotalServExonerado = 0.00000
            var TotalMercanciasGravadas = 0.00000
            var TotalMercanciasExentas = 0.00000
            var TotalMercExonerada = 0.00000
            var TotalOtrosCargos = 0.00000
            var listItems = []
            var listOthers = []
            var descuentoTotal = parseFloat(descuentos)
            var totalFactura = 0
            var totImpuestos = parseFloat(impuestos)
            for (var i in data.details) {
              /** detalle_lineas */
              const detalle = data.details[i].split('|')
              const linea = detalle[0]; const codigoProducto = detalle[1]; const tipoCodigoProducto = detalle[2]
              const cantidad = detalle[3]; const unidad = detalle[4]; const unidadComercial = detalle[5]
              const descripcion = detalle[6]; const precioUnitario = detalle[7]; const descuento = detalle[8]
              const naturalezaDescuento = detalle[9]; const esServicio = detalle[10]; const impuesto = detalle[11]
              const TipoDocExonera = detalle[12]; const NumDocExonera = detalle[13]; const NombreInstituExonera = detalle[14]
              let FechaEmisionExonera = detalle[15]; const MontoImpExonera = detalle[16]; const PorcCompraExonera = detalle[17]
              const adicional1 = detalle[18]; const adicional2 = detalle[19]; const adicional3 = detalle[20]
              const adicional4 = detalle[21]; const adicional5 = detalle[22]
              /** detalle_impuestos */
              const CodigoImpuesto = detalle[24]; const porcentajeImpuestos = detalle[25]; const montoImpuestos = detalle[26]
              /** nuevos campos */
              var CodigoTarifa = detalle[27]; var FactorIVA = detalle[28]; var CodigoProductoServicio = detalle[29]
              var PartidaArancelaria = detalle[30]; var BaseImponible = detalle[31]
              /** nuevos campos CABYS*/
              var Cabys = detalle[32];
              var cod2 = detalle[33]; var tip2 = detalle[34];
              var cod3 = detalle[35]; var tip3 = detalle[36];
              var cod4 = detalle[37]; var tip4 = detalle[38];
              var cod5 = detalle[39]; var tip5 = detalle[40];
              /** */
              var MontoExportacion = ''
              var ImpuestoNeto = 0
              /** */
              var dateExonera = new Date(FechaEmisionExonera)
              FechaEmisionExonera = dateExonera.getFullYear() +
                '-' + pad2(dateExonera.getMonth() + 1) +
                '-' + pad2(dateExonera.getDate()) +
                'T' + pad2(dateExonera.getHours()) +
                ':' + pad2(dateExonera.getMinutes()) +
                ':' + pad2(dateExonera.getSeconds()) +
                '-06:00'
              var impuestolinea
              var montototal = indicador === '0' ? Math.round(parseFloat(cantidad) * parseFloat(precioUnitario) * 100000) / 100000 : Math.round((parseFloat(cantidad) * parseFloat(precioUnitario)) * 100000) / 100000
              totalFactura = totalFactura + montototal
              var montodesc = descuento !== '' ? parseFloat(descuento) : 0.00000
              var subtotalLinea = indicador === '0' ? Math.round((montototal - montodesc) * 100000) / 100000 : Math.round((montototal - montodesc) * 100000) / 100000
              /** sumar gravados + exentos */
              if (esServicio === '1') {
                impuestolinea = montoImpuestos !== '' ? parseFloat(montoImpuestos) : 0.00000
                if (impuestolinea > 0) {
                  if (PorcCompraExonera && PorcCompraExonera !== '' && PorcCompraExonera !== '0') {
                    let PorcAplicarExoneracion
                    if (PorcCompraExonera && porcentajeImpuestos && Number(PorcCompraExonera) >= Number(porcentajeImpuestos)) {
                      PorcAplicarExoneracion = porcentajeImpuestos
                    } else {
                      PorcAplicarExoneracion = PorcCompraExonera
                    }
                    TotalServGravados += montototal - ( montototal * ( parseFloat(PorcAplicarExoneracion) / parseFloat(porcentajeImpuestos) ) ) // (1 - (parseFloat(PorcCompraExonera) / 100)) * montototal
                    TotalServExonerado += montototal * ( parseFloat(PorcAplicarExoneracion) / parseFloat(porcentajeImpuestos) ) //TotalServExonerado + ((parseFloat(PorcCompraExonera) / 100) * montototal)
                    totImpuestos = Math.round((totImpuestos - parseFloat(MontoImpExonera)) * 100000) / 100000
                  } else {
                    TotalServGravados += montototal
                  }
                } else {
                  TotalServExentos += montototal
                }
              } else if (esServicio === '0') {
                impuestolinea = montoImpuestos !== '' ? parseFloat(montoImpuestos) : 0.00000
                if (impuestolinea > 0) {
                  if (PorcCompraExonera && PorcCompraExonera !== '' && PorcCompraExonera !== '0') {
                    let PorcAplicarExoneracion
                    if (PorcCompraExonera && porcentajeImpuestos && Number(PorcCompraExonera) >= Number(porcentajeImpuestos)) {
                      PorcAplicarExoneracion = porcentajeImpuestos
                    } else {
                      PorcAplicarExoneracion = PorcCompraExonera
                    }
                    TotalMercanciasGravadas += montototal - ( montototal * ( parseFloat(PorcAplicarExoneracion) / parseFloat(porcentajeImpuestos) ) ) // (1 - (parseFloat(PorcCompraExonera) / 100)) * montototal
                    TotalMercExonerada += montototal * ( parseFloat(PorcAplicarExoneracion) / parseFloat(porcentajeImpuestos) )
                    totImpuestos = Math.round((totImpuestos - parseFloat(MontoImpExonera)) * 100000) / 100000
                  } else {
                    TotalMercanciasGravadas += montototal
                  }
                } else {
                  TotalMercanciasExentas += montototal
                }
              }
              if (TipoDocExonera !== '') {
                ImpuestoNeto = Math.round((impuestolinea - MontoImpExonera) * 100000) / 100000
                impuestolinea = ImpuestoNeto
              } else {
                ImpuestoNeto = impuestolinea
              }
              var montototalinea = indicador === '0' ? Math.round(subtotalLinea + impuestolinea) : Math.round((subtotalLinea + impuestolinea) * 100000) / 100000

              docFactura.detalles.push({
                codigoCabys: Cabys,
                tipoCodigoProducto: tipoCodigoProducto,
                codigoProducto: codigoProducto,
                codigoProducto2: cod2,
                tipoCodigoProducto2: tip2,
                codigoProducto3: cod3,
                tipoCodigoProducto3: tip3,
                codigoProducto4: cod4,
                tipoCodigoProducto4: tip4,
                codigoProducto5: cod5,
                tipoCodigoProducto5: tip5,
                CodigoProductoServicio: CodigoProductoServicio,
                PartidaArancelaria: PartidaArancelaria,
                BaseImponible: BaseImponible,
                CodigoTarifa: CodigoTarifa,
                FactorIVA: FactorIVA,
                MontoExportacion: MontoExportacion,
                cantidad: cantidad,
                unidad: unidad,
                unidadComercial: unidadComercial,
                descripcion: descripcion,
                precioUnitario: precioUnitario,
                montototal: montototal,
                montodesc: montodesc,
                naturalezaDescuento: naturalezaDescuento,
                subtotalLinea: subtotalLinea,
                CodigoImpuesto: CodigoImpuesto,
                porcentajeImpuestos: porcentajeImpuestos,
                montoImpuestos: montoImpuestos,
                TipoDocExonera: TipoDocExonera,
                NumDocExonera: NumDocExonera,
                NombreInstituExonera: NombreInstituExonera,
                FechaEmisionExonera: FechaEmisionExonera,
                PorcentajeExoneracion: PorcCompraExonera,
                MontoExoneracion: MontoImpExonera,
                ImpuestoNeto: ImpuestoNeto,
                montototalinea: montototalinea
              })
              listItems.push({
                name: 'LineaDetalle',
                children: [
                  { name: 'NumeroLinea', text: linea },
                  PartidaArancelaria !== '' ? { name: 'PartidaArancelaria', text: PartidaArancelaria } : {},
                  CodigoProductoServicio !== '' ? { name: 'Codigo', text: CodigoProductoServicio } : {},
                  codigoProducto && codigoProducto !== '' ? {
                    name: 'CodigoComercial',
                    children: [
                      { name: 'Tipo', text: tipoCodigoProducto },
                      { name: 'Codigo', text: codigoProducto }
                    ]
                  } : {},
                  cod2 && cod2 !== '' ? {
                    name: 'CodigoComercial',
                    children: [
                      { name: 'Tipo', text: tip2 },
                      { name: 'Codigo', text: cod2 }
                    ]
                  } : {},
                  cod3 && cod3 !== '' ? {
                    name: 'CodigoComercial',
                    children: [
                      { name: 'Tipo', text: tip3 },
                      { name: 'Codigo', text: cod3 }
                    ]
                  } : {},
                  cod4 && cod4 !== '' ? {
                    name: 'CodigoComercial',
                    children: [
                      { name: 'Tipo', text: tip4 },
                      { name: 'Codigo', text: cod4 }
                    ]
                  } : {},
                  cod5 && cod5 !== '' ? {
                    name: 'CodigoComercial',
                    children: [
                      { name: 'Tipo', text: tip5 },
                      { name: 'Codigo', text: cod5 }
                    ]
                  } : {},
                  { name: 'Cantidad', text: decimal(cantidad, 3) },
                  { name: 'UnidadMedida', text: unidad },
                  unidadComercial !== '' ? { name: 'UnidadMedidaComercial', text: unidadComercial } : {},
                  { name: 'Detalle', text: omitirAcentos(descripcion) },
                  { name: 'PrecioUnitario', text: decimal(precioUnitario.toString(), 5) },
                  { name: 'MontoTotal', text: decimal(montototal.toString(), 5) },
                  descuento !== '' && naturalezaDescuento !== '' ? {
                    name: 'Descuento',
                    children: [
                      { name: 'MontoDescuento', text: decimal(montodesc.toString(), 5) },
                      { name: 'NaturalezaDescuento', text: omitirAcentos(naturalezaDescuento) }
                    ]
                  } : {},
                  { name: 'SubTotal', text: decimal(subtotalLinea.toString(), 5) },
                  BaseImponible !== '' ? { name: 'BaseImponible', text: decimal(BaseImponible.toString(), 5) } : {},
                  CodigoImpuesto !== '' && (porcentajeImpuestos !== '' && porcentajeImpuestos !== '0') && (montoImpuestos !== '' && montoImpuestos !== '0') ? {
                    name: 'Impuesto',
                    children: [
                      { name: 'Codigo', text: CodigoImpuesto },
                      CodigoTarifa !== '' ? { name: 'CodigoTarifa', text: CodigoTarifa } : {},
                      { name: 'Tarifa', text: decimal(porcentajeImpuestos, 2) },
                      FactorIVA && FactorIVA !== '' && FactorIVA !== '0' ? { name: 'FactorIVA', text: decimal(FactorIVA, 4) } : {},
                      { name: 'Monto', text: decimal(montoImpuestos, 5) },
                      MontoExportacion !== '' ? { name: 'MontoExportacion', text: decimal(MontoExportacion, 5) } : {},
                      TipoDocExonera !== '' && NombreInstituExonera !== '' ? {
                        name: 'Exoneracion',
                        children: [
                          { name: 'TipoDocumento', text: TipoDocExonera },
                          { name: 'NumeroDocumento', text: NumDocExonera },
                          { name: 'NombreInstitucion', text: omitirAcentos(NombreInstituExonera) },
                          { name: 'FechaEmision', text: FechaEmisionExonera },
                          { name: 'PorcentajeExoneracion', text: PorcCompraExonera },
                          { name: 'MontoExoneracion', text: decimal(MontoImpExonera, 5) }
                        ]
                      } : {}
                    ]
                  } : {},
                  { name: 'ImpuestoNeto', text: decimal(ImpuestoNeto.toString(), 5) },
                  { name: 'MontoTotalLinea', text: decimal(montototalinea.toString(), 5) }
                ]
              })
            }

            for (var c in data.others) {
              /** otrosCargos */
              const otros = data.others[c].split('|')
              const lineaOtros = otros[0]; const TipoDocumentoOtros = otros[1]; const NumeroIdentidadTercero = otros[2]
              const NombreTercero = otros[3]; const DetalleOtros = otros[4]; const PorcentajeOtros = otros[5]
              let MontoCargo = otros[6]

              MontoCargo = Math.round(parseFloat(MontoCargo) * 100000) / 100000

              TotalOtrosCargos = TotalOtrosCargos + MontoCargo

              docFactura.otrosCargos.push({
                TipoDocumento: TipoDocumentoOtros,
                NumeroIdentidadTercero: NumeroIdentidadTercero,
                NombreTercero: NombreTercero,
                DetalleOtros: DetalleOtros,
                PorcentajeOtros: PorcentajeOtros,
                MontoCargo: MontoCargo
              })

              listOthers.push([
                { name: 'TipoDocumento', text: TipoDocumentoOtros },
                tipoDoc !== '08' && tipoDoc !== '09' && NumeroIdentidadTercero !== '' ? { name: 'NumeroIdentidadTercero', text: NumeroIdentidadTercero } : {},
                tipoDoc !== '08' && tipoDoc !== '09' && NombreTercero !== '' ? { name: 'NombreTercero', text: NombreTercero } : {},
                { name: 'Detalle', text: DetalleOtros },
                PorcentajeOtros !== '' ? { name: 'Porcentaje', text: decimal(PorcentajeOtros.toString(), 5) } : {},
                { name: 'MontoCargo', text: decimal(MontoCargo.toString(), 5) }
              ])
            }

            mongo.findOne('company', { idNum: entidad, environment: envCompany }, async (err, environment) => {
              if (err || !environment) {
                send({ error: 'notFound', message: 'Cédula ' + entidad + ' no esta registrada en sistema de Facturación Electrónica' })
              } else {
                // resumen fact
                TotalMercanciasGravadas = Math.round(TotalMercanciasGravadas * 100000) / 100000
                TotalServGravados = Math.round(TotalServGravados * 100000) / 100000
                TotalMercanciasExentas = Math.round(TotalMercanciasExentas * 100000) / 100000
                TotalServExentos = Math.round(TotalServExentos * 100000) / 100000
                var TotalGravado = Math.round((TotalServGravados + TotalMercanciasGravadas) * 100000) / 100000
                var TotalExento = Math.round((TotalServExentos + TotalMercanciasExentas) * 100000) / 100000
                var TotalExonerado = Math.round((TotalServExonerado + TotalMercExonerada) * 100000) / 100000
                var TotalVenta = Math.round((TotalGravado + TotalExento + TotalExonerado) * 100000) / 100000
                var TotalDescuentos = descuentoTotal
                var TotalVentaNeta = indicador === '0' ? Math.round((TotalVenta - TotalDescuentos) * 100000) / 100000 : Math.round((TotalVenta - TotalDescuentos) * 100000) / 100000
                var TotalImpuesto = totImpuestos
                var TotalComprobante = indicador === '0' ? Math.round(TotalVentaNeta + TotalImpuesto + TotalOtrosCargos - IVADevuelto) : Math.round((TotalVentaNeta + TotalImpuesto + TotalOtrosCargos - IVADevuelto) * 100000) / 100000
                mongo.findOne('invoice', { consecutivo2: consecutivo2, sucursal: sucursal, terminal: terminal, company: entidad }, {}, async (err, invs) => {
                  var obj
                  var follow = true
                  if (err) {
                    send({ error: 'notFound', message: 'Ocurrio un error al buscar el consecutivo en la base de datos, intentelo de nuevo' })
                  } else if (invs && (invs.statusHacienda !== 'inconsistente' && invs.statusHacienda !== undefined)) {
                    send({ error: 'wrongData', message: 'El consecutivo enviado ya existe en la base de datos con clave numérica ' + invs.clave })
                  } else {
                    // observacion + adicionales
                    var observaciones = observacion + ' ' + adicional1 + ' ' + adicional2 + ' ' + adicional3 + ' ' + adicional4 + ' ' +
                      adicional5 + ' ' + adicional6 + ' ' + adicional7 + ' ' + adicional8 + ' ' + adicional9 + ' ' + adicional10

                    if (invs) {
                      docFactura._id = invs._id
                      docFactura.clave = invs.clave
                      docFactura.numeroConsecutivo = invs.numeroConsecutivo
                      var date = new Date(fechaDoc)
                      fechaDoc = date.getFullYear() +
                        '-' + pad2(date.getMonth() + 1) +
                        '-' + pad2(date.getDate()) +
                        'T' + pad2(date.getHours()) +
                        ':' + pad2(date.getMinutes()) +
                        ':' + pad2(date.getSeconds()) +
                        '-06:00'
                    } else {
                      follow = await new Promise(resolve => {
                        mongo.findOneAndUpdate('consecutive',
                          { company: entidad, sucursal: sucursal, terminal: terminal, typeDocument: tipoDoc },
                          { $inc: { value: 1 } },
                          { value: 1 },
                          async (err, consecutiveSearched) => {
                            if (err) {
                              obj = { error: 'notFound', message: 'Ocurrio un error intentelo de nuevo' }
                              resolve(false)
                            } else if (!consecutiveSearched || (consecutiveSearched && !consecutiveSearched.value)) {
                              obj = { error: 'wrongData', message: 'Error, verifique numero consecutivo en la compañia' }
                              resolve(false)
                            } else {
                              var consecutivo
                              consecutivo = pad(consecutiveSearched.value.value.toString(), 10)
                              //* ******Clave numerica*******
                              // Information for Electronic invoice
                              // consecutivo
                              var consecutivoMod = consecutivo
                              // local o establecimiento
                              var casaMatriz = sucursal
                              // numero consecutivo
                              var numeroConsecutivo = casaMatriz + terminal + tipoDoc + consecutivoMod
                              // codigo del pais
                              var codPais = '506'
                              var date = new Date(fechaDoc)
                              fechaDoc = date.getFullYear() +
                                '-' + pad2(date.getMonth() + 1) +
                                '-' + pad2(date.getDate()) +
                                'T' + pad2(date.getHours()) +
                                ':' + pad2(date.getMinutes()) +
                                ':' + pad2(date.getSeconds()) +
                                '-06:00'
                              // dia
                              var day = date.getDate()
                              if (day < 10) {
                                day = pad(day, 2)
                              }
                              day = day.toString()
                              // mes
                              var month = date.getMonth() + 1
                              if (month < 10) {
                                month = pad(month, 2)
                              }
                              month = month.toString()
                              // año
                              var year = date.getFullYear()
                              year = year.toString()
                              year = year.slice(2, 4)
                              // cedula emisor
                              var ced = pad(entidad, 12)
                              // codigo de seguridad
                              var codSeg = pad(environment.code, 8)
                              // clave numerica
                              var key = codPais + day + month + year + ced + numeroConsecutivo + situacion + codSeg
                              docFactura.clave = key
                              docFactura.numeroConsecutivo = numeroConsecutivo
                              resolve(true)
                            }
                          })
                      })
                    }
                    if (follow) {
                      docFactura.CodigoActividad = CodigoActividad
                      docFactura.company = entidad
                      docFactura.tipoDocumento = tipoDoc
                      docFactura.sucursal = sucursal
                      docFactura.terminal = terminal
                      docFactura.consecutivoTemporal = consecutivo2
                      docFactura.fechaDocumento = fechaDoc
                      if (tipoDoc !== '08') {
                        docFactura.Emisor = {
                          Nombre: environment.name,
                          tipoIdentificacion: environment.idType,
                          numeroIdentificacion: environment.idNum,
                          Provincia: environment.province,
                          Canton: environment.canton,
                          Distrito: environment.district,
                          OtrasSenas: environment.signs,
                          CodigoPais: environment.codPhone,
                          NumeroTelefono: environment.phone,
                          CorreoElectronico: environment.email
                        }
                        docFactura.Receptor = {
                          Nombre: nombreCliente,
                          tipoIdentificacion: tipoIdentificacion,
                          numeroIdentificacion: cedulaCliente,
                          IdentificacionExtranjero: extranjero,
                          Provincia: provinvia,
                          Canton: canton,
                          Distrito: distrito,
                          Barrio: barrio,
                          OtrasSenas: direccionCliente,
                          CodigoPais: numeroAreaTelefono,
                          NumTelefono: telefonoCliente,
                          CorreoElectronico: copiaCortesia
                        }
                      } else {
                        docFactura.Emisor = {
                          Nombre: nombreCliente,
                          tipoIdentificacion: tipoIdentificacion,
                          numeroIdentificacion: cedulaCliente,
                          Provincia: provinvia,
                          Canton: canton,
                          Distrito: distrito,
                          Barrio: barrio,
                          OtrasSenas: direccionCliente,
                          CodigoPais: numeroAreaTelefono,
                          NumTelefono: telefonoCliente,
                          CorreoElectronico: copiaCortesia
                        }
                        docFactura.Receptor = {
                          Nombre: environment.name,
                          tipoIdentificacion: environment.idType,
                          numeroIdentificacion: environment.idNum,
                          Provincia: environment.province,
                          Canton: environment.canton,
                          Distrito: environment.district,
                          OtrasSenas: environment.signs,
                          CodigoPais: environment.codPhone,
                          NumeroTelefono: environment.phone,
                          CorreoElectronico: environment.email
                        }
                      }
                      docFactura.CondicionVenta = condicion
                      docFactura.PlazoCredito = plazo
                      docFactura.MedioPago = medioPago1
                      docFactura.Moneda = moneda
                      docFactura.tipoCambio = tipoCambio
                      docFactura.TotalServGravados = TotalServGravados
                      docFactura.TotalMercanciasGravadas = TotalMercanciasGravadas
                      docFactura.TotalServExentos = TotalServExentos
                      docFactura.TotalServExonerado = TotalServExonerado
                      docFactura.TotalMercanciasExentas = TotalMercanciasExentas
                      docFactura.TotalMercExonerada = TotalMercExonerada
                      docFactura.TotalGravado = TotalGravado
                      docFactura.TotalExento = TotalExento
                      docFactura.TotalExonerado = TotalExonerado
                      docFactura.TotalVenta = TotalVenta
                      docFactura.TotalDescuentos = TotalDescuentos
                      docFactura.TotalVentaNeta = TotalVentaNeta
                      docFactura.TotalImpuesto = TotalImpuesto
                      docFactura.TotalIVADevuelto = IVADevuelto
                      docFactura.TotalOtrosCargos = TotalOtrosCargos
                      docFactura.TotalComprobante = TotalComprobante
                      docFactura.observacion = observaciones
                      docFactura.consecutivo2 = consecutivo2
                      docFactura.numContingencia = numContingencia
                      docFactura.tipoDocRef = tipoDocRef
                      docFactura.CodReferencia = CodReferencia
                      docFactura.razonContingencia = razonContingencia
                      docFactura.fechaContingencia = fechaContingencia
                      await new Promise(resolve => {
                        mongo.save('invoice', docFactura, () => {
                          resolve()
                        })
                      })
                      docFactura.atv = 'P'
                      docFactura.thread = this.thread
                      setXML(docFactura.clave, docFactura.numeroConsecutivo)
                    } else {
                      send(obj)
                    }
                  }
                  // compose xml
                  // eslint-disable-next-line no-inner-declarations
                  function setXML (key, numeroConsecutivo) {
                    var xmlArray = [
                      { name: 'Clave', text: key },
                      { name: 'CodigoActividad', text: CodigoActividad },
                      { name: 'NumeroConsecutivo', text: numeroConsecutivo },
                      { name: 'FechaEmision', text: fechaDoc },
                      //* *** datos emisor ****/
                      tipoDoc !== '08' ? {
                        name: 'Emisor',
                        children: [
                          { name: 'Nombre', text: omitirAcentos(environment.name) },
                          {
                            name: 'Identificacion',
                            children: [
                              { name: 'Tipo', text: environment.idType },
                              { name: 'Numero', text: environment.idNum }
                            ]
                          },
                          {
                            name: 'Ubicacion',
                            children: [
                              { name: 'Provincia', text: environment.province },
                              { name: 'Canton', text: environment.canton },
                              { name: 'Distrito', text: environment.district },
                              { name: 'OtrasSenas', text: omitirAcentos(environment.signs) }
                            ]
                          },
                          {
                            name: 'Telefono',
                            children: [
                              { name: 'CodigoPais', text: environment.codPhone },
                              { name: 'NumTelefono', text: environment.phone }
                            ]
                          },
                          { name: 'CorreoElectronico', text: environment.email }
                        ]
                      } : {
                        name: 'Emisor',
                        children: [
                          { name: 'Nombre', text: omitirAcentos(nombreCliente) },
                          tipoIdentificacion !== '' ? {
                            name: 'Identificacion',
                            children: [
                              { name: 'Tipo', text: tipoIdentificacion },
                              { name: 'Numero', text: cedulaCliente }
                            ]
                          } : {},
                          tipoDoc !== '09' && (provinvia !== '' && canton !== '' && distrito !== '' && direccionCliente !== '') ? {
                            name: 'Ubicacion',
                            children: [
                              { name: 'Provincia', text: provinvia },
                              { name: 'Canton', text: canton },
                              { name: 'Distrito', text: distrito },
                              barrio !== '' ? { name: 'Barrio', text: barrio } : {},
                              { name: 'OtrasSenas', text: direccionCliente }
                            ]
                          } : {},
                          numeroAreaTelefono !== '' && telefonoCliente !== '' ? {
                            name: 'Telefono',
                            children: [
                              { name: 'CodigoPais', text: numeroAreaTelefono },
                              { name: 'NumTelefono', text: telefonoCliente }
                            ]
                          } : {},
                          copiaCortesia !== '' ? { name: 'CorreoElectronico', text: copiaCortesia } : {}
                        ]
                      },
                      //* *** datos receptor si existen? ****/
                      tipoDoc !== '08' ? nombreCliente !== '' ? {
                        name: 'Receptor',
                        children: [
                          { name: 'Nombre', text: omitirAcentos(nombreCliente) },
                          tipoIdentificacion !== '' ? {
                            name: 'Identificacion',
                            children: [
                              { name: 'Tipo', text: tipoIdentificacion },
                              { name: 'Numero', text: cedulaCliente }
                            ]
                          } : {},
                          cedulaCliente !== '' && extranjero === '1' ? { name: 'IdentificacionExtranjero', text: cedulaCliente } : {},
                          tipoDoc !== '09' && (provinvia !== '' && canton !== '' && distrito !== '' && direccionCliente !== '') ? {
                            name: 'Ubicacion',
                            children: [
                              { name: 'Provincia', text: provinvia },
                              { name: 'Canton', text: canton },
                              { name: 'Distrito', text: distrito },
                              barrio !== '' ? { name: 'Barrio', text: barrio } : {},
                              { name: 'OtrasSenas', text: direccionCliente }
                            ]
                          } : {},
                          direccionCliente !== '' && extranjero === '1' ? { name: 'OtrasSenasExtranjero', text: omitirAcentos(direccionCliente) } : {},
                          numeroAreaTelefono !== '' && telefonoCliente !== '' ? {
                            name: 'Telefono',
                            children: [
                              { name: 'CodigoPais', text: numeroAreaTelefono },
                              { name: 'NumTelefono', text: telefonoCliente }
                            ]
                          } : {},
                          copiaCortesia !== '' ? { name: 'CorreoElectronico', text: copiaCortesia } : {}
                        ]
                      } : {} : {
                        name: 'Receptor',
                        children: [
                          { name: 'Nombre', text: omitirAcentos(environment.name) },
                          {
                            name: 'Identificacion',
                            children: [
                              { name: 'Tipo', text: environment.idType },
                              { name: 'Numero', text: environment.idNum }
                            ]
                          },
                          {
                            name: 'Ubicacion',
                            children: [
                              { name: 'Provincia', text: environment.province },
                              { name: 'Canton', text: environment.canton },
                              { name: 'Distrito', text: environment.district },
                              { name: 'OtrasSenas', text: omitirAcentos(environment.signs) }
                            ]
                          },
                          {
                            name: 'Telefono',
                            children: [
                              { name: 'CodigoPais', text: environment.codPhone },
                              { name: 'NumTelefono', text: environment.phone }
                            ]
                          },
                          { name: 'CorreoElectronico', text: environment.email }
                        ]
                      },
                      { name: 'CondicionVenta', text: condicion },
                      { name: 'PlazoCredito', text: plazo },
                      { name: 'MedioPago', text: medioPago1 },
                      {
                        name: 'DetalleServicio',
                        children: listItems
                      },
                      listOthers.length > 0 ? {
                        name: 'OtrosCargos',
                        children: listOthers
                      } : {},
                      {
                        name: 'ResumenFactura',
                        children: [
                          tipoCambio !== '' && moneda !== '' ? {
                            name: 'CodigoTipoMoneda',
                            children: [
                              { name: 'CodigoMoneda', text: moneda },
                              { name: 'TipoCambio', text: decimal(tipoCambio, 5) }
                            ]
                          } : {},
                          { name: 'TotalServGravados', text: decimal(TotalServGravados.toString(), 5) },
                          { name: 'TotalServExentos', text: decimal(TotalServExentos.toString(), 5) },
                          tipoDoc !== '09' ? { name: 'TotalServExonerado', text: decimal(TotalServExonerado.toString(), 5) } : {},
                          { name: 'TotalMercanciasGravadas', text: decimal(TotalMercanciasGravadas.toString(), 5) },
                          { name: 'TotalMercanciasExentas', text: decimal(TotalMercanciasExentas.toString(), 5) },
                          tipoDoc !== '09' ? { name: 'TotalMercExonerada', text: decimal(TotalMercExonerada.toString(), 5) } : {},
                          { name: 'TotalGravado', text: decimal(TotalGravado.toString(), 5) },
                          { name: 'TotalExento', text: decimal(TotalExento.toString(), 5) },
                          tipoDoc !== '09' ? { name: 'TotalExonerado', text: decimal(TotalExonerado.toString(), 5) } : {},
                          { name: 'TotalVenta', text: decimal(TotalVenta.toString(), 5) },
                          { name: 'TotalDescuentos', text: decimal(TotalDescuentos.toString(), 5) },
                          { name: 'TotalVentaNeta', text: decimal(TotalVentaNeta.toString(), 5) },
                          impuestos !== '' ? { name: 'TotalImpuesto', text: decimal(TotalImpuesto.toString(), 5) } : {},
                          tipoDoc !== '08' && tipoDoc !== '09' && IVADevuelto !== '0' ? { name: 'TotalIVADevuelto', text: decimal(IVADevuelto.toString(), 5) } : {},
                          { name: 'TotalOtrosCargos', text: decimal(TotalOtrosCargos.toString(), 5) },
                          { name: 'TotalComprobante', text: decimal(TotalComprobante.toString(), 5) }
                        ]
                      },
                      tipoDocRef && tipoDocRef !== '' ? {
                        name: 'InformacionReferencia',
                        children: [
                          { name: 'TipoDoc', text: tipoDocRef },
                          { name: 'Numero', text: numContingencia },
                          { name: 'FechaEmision', text: fechaContingencia },
                          { name: 'Codigo', text: CodReferencia },
                          { name: 'Razon', text: omitirAcentos(razonContingencia) }
                        ]
                      } : {},
                      /* {
                  name: 'Normativa',
                  children: [
                    { name: 'NumeroResolucion', text: 'DGT-R-48-2016' },
                    { name: 'FechaResolucion', text: '20-02-2017 13:22:22' }
                  ]
                }, */
                      {
                        name: 'Otros',
                        children: [
                          Otros
                        ]
                      }
                    ]

                    var xml, x, i, completeXml
                    if (tipoDoc === '01') {
                      // xml de factura
                      xml = jsonxml({
                        FacturaElectronica: xmlArray
                      }, { xmlHeader: true })

                      // xml con etiqueta tipo y xmlns
                      x = xml.split('FacturaElectronica', 2)
                      i = x[0] + 'FacturaElectronica xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/facturaElectronica"'
                      completeXml = i + x[1]
                      completeXml = completeXml + 'FacturaElectronica>'
                    } else if (tipoDoc === '04') {
                      // xml de factura
                      xml = jsonxml({
                        TiqueteElectronico: xmlArray
                      }, { xmlHeader: true })

                      // xml con etiqueta tipo y xmlns
                      x = xml.split('TiqueteElectronico', 2)
                      i = x[0] + 'TiqueteElectronico xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/tiqueteElectronico"'
                      completeXml = i + x[1]
                      completeXml = completeXml + 'TiqueteElectronico>'
                    } else if (tipoDoc === '08') {
                      // xml de factura
                      xml = jsonxml({
                        FacturaElectronicaCompra: xmlArray
                      }, { xmlHeader: true })

                      // xml con etiqueta tipo y xmlns
                      x = xml.split('FacturaElectronicaCompra', 2)
                      i = x[0] + 'FacturaElectronicaCompra xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/facturaElectronicaCompra"'
                      completeXml = i + x[1]
                      completeXml = completeXml + 'FacturaElectronicaCompra>'
                    } else if (tipoDoc === '09') {
                      // xml de factura
                      xml = jsonxml({
                        FacturaElectronicaExportacion: xmlArray
                      }, { xmlHeader: true })

                      // xml con etiqueta tipo y xmlns
                      x = xml.split('FacturaElectronicaExportacion', 2)
                      i = x[0] + 'FacturaElectronicaExportacion xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/facturaElectronicaExportacion"'
                      completeXml = i + x[1]
                      completeXml = completeXml + 'FacturaElectronicaExportacion>'
                    }

                    fs.writeFile('/tmp/' + key + '.xml', completeXml, (err) => {
                      if (err) {
                        send({ error: 'Error', message: 'intentelo de nuevo: ' + err })
                      } else {
                        chilkatExample()
                        firmar()
                      }
                      // firma Chilkat
                      function firmar () {
                        var fileId = environment.description.split('?_id=')[1]
                        fileId = fileId.split('&')[0]
                        req.app.routes.file.get({ _id: fileId, type: 'p12' }, mongo, (result) => {
                          var tmp = '/tmp/' + result.filename
                          var file = fs.createWriteStream(tmp)
                          file.on('finish', function () {
                            var cert = new chilkat.Cert()
                            var success = cert.LoadPfxFile(tmp, environment.pin)
                            if (success !== true) {
                              send({ error: 'wrongCrypt', message: 'Ocurrio un error al abrir el certificado ' + cert.LastErrorText })
                              console.log(cert.LastErrorText)
                              return
                            }

                            // Load XML to be signed.
                            var sbXml = new chilkat.StringBuilder()
                            success = sbXml.LoadFile('/tmp/' + key + '.xml', 'utf-8')
                            if (success !== true) {
                              send({ error: 'wrongCrypt', message: 'Ocurrio un error al cargar la factura' })
                              console.log('Failed to load file.')
                              return
                            }

                            var gen = new chilkat.XmlDSigGen()

                            // Indicate where the signature is to be placed.
                            gen.SigLocation = tipoDoc === '01' ? 'FacturaElectronica'
                              : tipoDoc === '04' ? 'TiqueteElectronico'
                                : tipoDoc === '08' ? 'FacturaElectronicaCompra'
                                  : tipoDoc === '09' ? 'FacturaElectronicaExportacion' : ''
                            gen.SigId = 'Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0'
                            gen.SigNamespacePrefix = 'ds'
                            gen.SignedInfoCanonAlg = 'C14N'
                            gen.SignedInfoDigestMethod = 'sha256'

                            var xml = new chilkat.Xml()
                            var cdn = tipoDoc === '01' ? 'facturaElectronica'
                              : tipoDoc === '04' ? 'tiqueteElectronico'
                                : tipoDoc === '08' ? 'facturaElectronicaCompra'
                                  : tipoDoc === '09' ? 'facturaElectronicaExportacion' : ''
                            xml.Tag = 'xades:QualifyingProperties'
                            xml.AddAttribute('xmlns:xades', 'http://uri.etsi.org/01903/v1.3.2#')
                            xml.AddAttribute('Id', 'QualifyingProperties-aa262416-8607-4f02-8897-0a6440a1ae03')
                            xml.AddAttribute('Target', '#Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0')
                            xml.UpdateAttrAt('xades:SignedProperties', true, 'Id', 'SignedProperties-Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0')
                            xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningTime', 'TO BE GENERATED BY CHILKAT')
                            xml.UpdateAttrAt('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningCertificate|xades:Cert|xades:CertDigest|ds:DigestMethod', true, 'Algorithm', 'http://www.w3.org/2001/04/xmlenc#sha256')
                            xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningCertificate|xades:Cert|xades:CertDigest|ds:DigestValue', 'TO BE GENERATED BY CHILKAT')
                            xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningCertificate|xades:Cert|xades:IssuerSerial|ds:X509IssuerName', 'TO BE GENERATED BY CHILKAT')
                            xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningCertificate|xades:Cert|xades:IssuerSerial|ds:X509SerialNumber', 'TO BE GENERATED BY CHILKAT')
                            xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SignaturePolicyIdentifier|xades:SignaturePolicyId|xades:SigPolicyId|xades:Identifier', 'https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/' + cdn)
                            xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SignaturePolicyIdentifier|xades:SignaturePolicyId|xades:SigPolicyId|xades:Description', '')
                            xml.UpdateAttrAt('xades:SignedProperties|xades:SignedSignatureProperties|xades:SignaturePolicyIdentifier|xades:SignaturePolicyId|xades:SigPolicyHash|ds:DigestMethod', true, 'Algorithm', 'http://www.w3.org/2001/04/xmlenc#sha256')
                            xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SignaturePolicyIdentifier|xades:SignaturePolicyId|xades:SigPolicyHash|ds:DigestValue', 'NmI5Njk1ZThkNzI0MmIzMGJmZDAyNDc4YjUwNzkzODM2NTBiOWUxNTBkMmI2YjgzYzZjM2I5NTZlNDQ4OWQzMQ==')
                            xml.UpdateAttrAt('xades:SignedProperties|xades:SignedDataObjectProperties|xades:DataObjectFormat', true, 'ObjectReference', '#Reference-ab26afbd-e2dc-4cb0-886a-ce2a4a118c7f')
                            xml.UpdateChildContent('xades:SignedProperties|xades:SignedDataObjectProperties|xades:DataObjectFormat|xades:MimeType', 'text/xml')
                            xml.UpdateChildContent('xades:SignedProperties|xades:SignedDataObjectProperties|xades:DataObjectFormat|xades:Encoding', 'UTF-8')

                            gen.AddObject('XadesObjectId-674a431e-692c-4e0a-9d82-6275c85c5876', xml.GetXml(), '', '')

                            var signedPropsId = 'SignedProperties-Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0'
                            gen.AddObjectRef(signedPropsId, 'sha256', 'EXCL_C14N', '', 'http://uri.etsi.org/01903#SignedProperties')

                            var keyInfoId = 'KeyInfoId-Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0'
                            gen.KeyInfoId = keyInfoId
                            gen.AddSameDocRef(keyInfoId, 'sha256', 'EXCL_C14N', '', '')
                            gen.SetRefIdAttr(keyInfoId, 'ReferenceKeyInfo')

                            gen.AddSameDocRef('', 'sha256', 'EXCL_C14N', '', '')
                            gen.SetRefIdAttr('', 'Reference-ab26afbd-e2dc-4cb0-886a-ce2a4a118c7f')

                            gen.KeyInfoType = 'X509Data+KeyValue'
                            gen.X509Type = 'Certificate'
                            success = gen.SetX509Cert(cert, true)
                            if (!success) {
                              send({ error: 'wrongCrypt', message: 'Ocurrio un error al firmar la factura ' + gen.LastErrorText })
                              console.log(gen.LastErrorText)
                              return
                            }

                            gen.Behaviors = 'IndentedSignature'

                            success = gen.CreateXmlDSigSb(sbXml)
                            if (!success) {
                              send({ error: 'wrongCrypt', message: 'Ocurrio un error al firmar la factura ' + gen.LastErrorText })
                              console.log(gen.LastErrorText)
                              return
                            }
                            try {
                              var xmlDoc = sbXml.GetAsString()
                              var comprobanteXml = base64.encode(utf8.encode(xmlDoc))
                              docFactura.voucherXml = comprobanteXml
                              mongo.save('invoice', docFactura, (err) => {
                                if (err) {
                                  send({ error: 'IOError', message: 'Problema al guardar el XML' })
                                } else {
                                  req.app.routes.background.sendPending2atv(req)
                                  send({ numericKey: key })
                                }
                              })
                            } catch (error) {
                              docFactura.statusHacienda = 'inconsistente'
                              delete docFactura.atv
                              mongo.save('invoice', docFactura, (err) => {
                                if (err) throw err
                                send({ error: 'XMLError', message: 'El XML contiene errores' })
                              })
                            }
                          })
                          result.pipe(file)
                        })
                      }
                    })
                  }
                })
              }
            })
          } else {
            send({ error: 'wrongData', message: 'Se espera el campo Codigo actividad' })
          }
        }
      })
    } else {
      send({ error: 'wrongData', message: 'Se esperan 42 campos y se estan recibiendo ' + header.length })
    }
  }
  /*
   * params: header, details, taxes, invoices
   * reply: {numericKey:"0.....50"} ó {error:"code", message:"message"}
   */
  this.note = function (req, mongo, send, data) {
    var chilkat = require('@chilkat/ck-node14-linux64')
    var envCompany = ''
    if (!data) data = this.parseData(req)
    var docFactura = {}
    docFactura._id = mongo.newId()
    docFactura.detalles = []
    docFactura.otrosCargos = []
    docFactura.Facturas = []
    var header = data.header.split('|')
    if (req.app.params.ebillEnvironment) envCompany = req.app.params.ebillEnvironment
    else envCompany = 'Pruebas'
    if (header.length >= 42) {
      mongo.findOne('company', { idNum: header[0], environment: envCompany }, {}, (err, CP) => {
        if (err || (CP && CP.inactive && CP.inactive === '1')) {
          send({ error: 'notFound', message: 'Cliente ' + header[0] + ' inhabilitado para envio/recepción de documentos electronicos. Por favor contacte con su proveedor de sistema' })
        } else {
          if (header[43] && header[43] !== '') {
            /** Datos Encabezado */
            var entidad = header[0]; var consecutivo2 = header[1]; var tipoDoc = header[2]
            var fechaDoc = header[3]; var condicion = header[4]; var plazo = header[5]
            var subtotal = header[6]; var impuestos = header[7]; var descuentos = header[8]
            var moneda = header[9]; var tipoCambio = header[10]; var enviarFactura = header[11]
            var copiaCortesia = header[12]; var nombreCliente = header[13]; var telefonoCliente = header[14]
            var cedulaCliente = header[15]; var direccionCliente = header[16]; var numeroAreaTelefono = header[17]
            var tipoIdentificacion = header[18]; var extranjero = header[19]; var provinvia = header[20]
            var canton = header[21]; var distrito = header[22]; var barrio = header[23]
            var medioPago1 = header[24]; var medioPago2 = header[25]; var medioPago3 = header[26]
            var medioPago4 = header[27]; var situacion = header[28]; var sucursal = header[29]
            var terminal = header[30]; var observacion = header[31]; var adicional1 = header[32]
            var adicional2 = header[33]; var adicional3 = header[34]; var adicional4 = header[35]
            var adicional5 = header[36]; var adicional6 = header[37]; var adicional7 = header[38]
            var adicional8 = header[39]; var adicional9 = header[40]; var adicional10 = header[41]
            var indicador = header[42]
            /** nuevos campos */
            var CodigoActividad = header[43]; var IVADevuelto = header[44]
            /** *Campo Otros PM,WM,GQ,AM */
            var Otros = []
            var otroTexto = []
            if (adicional1 === 'PM') {
              otroTexto.push({ name: 'OtroTexto', text: observacion })
              if (adicional7 !== '') { otroTexto.push({ name: 'OtroTexto', text: adicional7 }) }
              if (adicional4 !== '') { otroTexto.push({ name: 'OtroTexto', text: adicional4 }) }

              Otros.push(otroTexto)
              Otros.push({
                name: 'OtroContenido',
                children: [
                  {
                    name: 'retail:Complemento',
                    attrs:
                    {
                      'xsi:schemaLocation': 'https://invoicer.ekomercio.com/esquemas https://invoicer.ekomercio.com/esquemas/ComplementoPricesmartCR_V1_0.xsd',
                      'xmlns:xsi': 'http://www.w3.org/2001/XMLSchema-instance',
                      'xmlns:retail': 'https://invoicer.ekomercio.com/esquemas'
                    },
                    children: [
                      { name: 'retail:NumeroVendedor', text: adicional2 },
                      {
                        name: 'retail:LugarDeEntrega',
                        children: [
                          { name: 'retail:GLNLugarDeEntrega', text: adicional3 }
                        ]
                      }
                    ]
                  }
                ]
              })
            } else if (adicional1 === 'WM') {
              otroTexto.push({ name: 'OtroTexto', text: observacion })
              if (adicional7 !== '') { otroTexto.push({ name: 'OtroTexto', text: adicional7 }) }
            } else if (adicional1 === 'AM') {
              otroTexto.push({ name: 'OtroTexto', text: adicional2, attrs: { codigo: 'AUTOMERCADO_PROVEEDOR' } })
              otroTexto.push({ name: 'OtroTexto', text: adicional7, attrs: { codigo: 'AUTOMERCADO_ORDEN_COMPRA' } })
              otroTexto.push({ name: 'OtroTexto', text: adicional3, attrs: { codigo: 'AUTOMERCADO_GLN_CLIENTE' } })
              otroTexto.push({ name: 'OtroTexto', text: adicional4, attrs: { codigo: 'AUTOMERCADO_FECHA_ORDEN_COMPRA' } })
              otroTexto.push({ name: 'OtroTexto', text: observacion })
              Otros.push(otroTexto)
            } else if (adicional1 === 'GQ') {
              otroTexto.push({ name: 'OtroTexto', text: adicional7, attrs: { codigo: 'OC' } })
              otroTexto.push({ name: 'OtroTexto', text: observacion })
              Otros.push(otroTexto)
            } else if (adicional1 === 'CB') {
              otroTexto.push({ name: 'OtroTexto', text: adicional5, attrs: { codigo: 'NoDocumento' } })
              otroTexto.push({ name: 'OtroTexto', text: observacion })
              Otros.push(otroTexto)
            } else {
              otroTexto.push({ name: 'OtroTexto', text: observacion })
              Otros.push(otroTexto)
            }
            /** Fin otros */
            indicador = indicador || '0'
            IVADevuelto = IVADevuelto !== '0' ? parseFloat(IVADevuelto) : 0
            /** Datos Detalle_Facturas */
            var TotalServGravados = 0.00000
            var TotalServExentos = 0.00000
            var TotalServExonerado = 0.00000
            var TotalMercanciasGravadas = 0.00000
            var TotalMercanciasExentas = 0.00000
            var TotalMercExonerada = 0.00000
            var TotalOtrosCargos = 0.00000
            var listItems = []
            var listOthers = []
            var descuentoTotal = parseFloat(descuentos)
            var totalFactura = 0
            var totImpuestos = parseFloat(impuestos)
            for (var i in data.details) {
              /** detalle_lineas */
              const detalle = data.details[i].split('|')
              const linea = detalle[0]; const codigoProducto = detalle[1]; const tipoCodigoProducto = detalle[2]
              const cantidad = detalle[3]; const unidad = detalle[4]; const unidadComercial = detalle[5]
              const descripcion = detalle[6]; const precioUnitario = detalle[7]; const descuento = detalle[8]
              const naturalezaDescuento = detalle[9]; const esServicio = detalle[10]; const impuesto = detalle[11]
              const TipoDocExonera = detalle[12]; const NumDocExonera = detalle[13]; const NombreInstituExonera = detalle[14]
              let FechaEmisionExonera = detalle[15]; const MontoImpExonera = detalle[16]; const PorcCompraExonera = detalle[17]
              const adicional1 = detalle[18]; const adicional2 = detalle[19]; const adicional3 = detalle[20]
              const adicional4 = detalle[21]; const adicional5 = detalle[22]
              /** detalle_impuestos */
              const CodigoImpuesto = detalle[24]; const porcentajeImpuestos = detalle[25]; const montoImpuestos = detalle[26]
              /** nuevos campos */
              var CodigoTarifa = detalle[27]; var FactorIVA = detalle[28]; var CodigoProductoServicio = detalle[29]
              var PartidaArancelaria = detalle[30]; var BaseImponible = detalle[31]
              /** nuevos campos CABYS*/
              var Cabys = detalle[32];
              var cod2 = detalle[33]; var tip2 = detalle[34];
              var cod3 = detalle[35]; var tip3 = detalle[36];
              var cod4 = detalle[37]; var tip4 = detalle[38];
              var cod5 = detalle[39]; var tip5 = detalle[40];
              //** */
              var MontoExportacion = ''
              var ImpuestoNeto = 0
              /** */
              var dateExonera = new Date(FechaEmisionExonera)
              FechaEmisionExonera = dateExonera.getFullYear() +
                '-' + pad2(dateExonera.getMonth() + 1) +
                '-' + pad2(dateExonera.getDate()) +
                'T' + pad2(dateExonera.getHours()) +
                ':' + pad2(dateExonera.getMinutes()) +
                ':' + pad2(dateExonera.getSeconds()) +
                '-06:00'
              var impuestolinea
              var montototal = indicador === '0' ? Math.round(parseFloat(cantidad) * parseFloat(precioUnitario) * 100000) / 100000 : Math.round((parseFloat(cantidad) * parseFloat(precioUnitario)) * 100000) / 100000
              totalFactura = totalFactura + montototal
              var montodesc = descuento !== '' ? parseFloat(descuento) : 0.00000
              var subtotalLinea = indicador === '0' ? Math.round((montototal - montodesc) * 100000) / 100000 : Math.round((montototal - montodesc) * 100000) / 100000
              /** sumar gravados + exentos */
              if (esServicio === '1') {
                impuestolinea = montoImpuestos !== '' ? parseFloat(montoImpuestos) : 0.00000
                if (impuestolinea > 0) {
                  if (PorcCompraExonera && PorcCompraExonera !== '' && PorcCompraExonera !== '0') {
                    let PorcAplicarExoneracion
                    if (PorcCompraExonera && porcentajeImpuestos && Number(PorcCompraExonera) >= Number(porcentajeImpuestos)) {
                      PorcAplicarExoneracion = porcentajeImpuestos
                    } else {
                      PorcAplicarExoneracion = PorcCompraExonera
                    }
                    TotalServGravados += montototal - ( montototal * ( parseFloat(PorcAplicarExoneracion) / parseFloat(porcentajeImpuestos) ) ) // (1 - (parseFloat(PorcCompraExonera) / 100)) * montototal
                    TotalServExonerado += montototal * ( parseFloat(PorcAplicarExoneracion) / parseFloat(porcentajeImpuestos) ) //TotalServExonerado + ((parseFloat(PorcCompraExonera) / 100) * montototal)
                    totImpuestos = Math.round((totImpuestos - parseFloat(MontoImpExonera)) * 100000) / 100000
                  } else {
                    TotalServGravados += montototal
                  }
                } else {
                  TotalServExentos += montototal
                }
              } else if (esServicio === '0') {
                impuestolinea = montoImpuestos !== '' ? parseFloat(montoImpuestos) : 0.00000
                if (impuestolinea > 0) {
                  if (PorcCompraExonera && PorcCompraExonera !== '' && PorcCompraExonera !== '0') {
                    let PorcAplicarExoneracion
                    if (PorcCompraExonera && porcentajeImpuestos && Number(PorcCompraExonera) >= Number(porcentajeImpuestos)) {
                      PorcAplicarExoneracion = porcentajeImpuestos
                    } else {
                      PorcAplicarExoneracion = PorcCompraExonera
                    }
                    TotalMercanciasGravadas += montototal - ( montototal * ( parseFloat(PorcAplicarExoneracion) / parseFloat(porcentajeImpuestos) ) ) // (1 - (parseFloat(PorcCompraExonera) / 100)) * montototal
                    TotalMercExonerada += montototal * ( parseFloat(PorcAplicarExoneracion) / parseFloat(porcentajeImpuestos) )
                    totImpuestos = Math.round((totImpuestos - parseFloat(MontoImpExonera)) * 100000) / 100000
                  } else {
                    TotalMercanciasGravadas += montototal
                  }
                } else {
                  TotalMercanciasExentas += montototal
                }
              }
              if (TipoDocExonera !== '') {
                ImpuestoNeto = Math.round((impuestolinea - MontoImpExonera) * 100000) / 100000
                impuestolinea = ImpuestoNeto
              } else {
                ImpuestoNeto = impuestolinea
              }
              var montototalinea = indicador === '0' ? Math.round(subtotalLinea + impuestolinea) : Math.round((subtotalLinea + impuestolinea) * 100000) / 100000

              docFactura.detalles.push(
                {
                  codigoCabys: Cabys,
                  tipoCodigoProducto: tipoCodigoProducto,
                  codigoProducto: codigoProducto,
                  codigoProducto2: cod2,
                  tipoCodigoProducto2: tip2,
                  codigoProducto3: cod3,
                  tipoCodigoProducto3: tip3,
                  codigoProducto4: cod4,
                  tipoCodigoProducto4: tip4,
                  codigoProducto5: cod5,
                  tipoCodigoProducto5: tip5,
                  CodigoProductoServicio: CodigoProductoServicio,
                  PartidaArancelaria: PartidaArancelaria,
                  BaseImponible: BaseImponible,
                  CodigoTarifa: CodigoTarifa,
                  FactorIVA: FactorIVA,
                  MontoExportacion: MontoExportacion,
                  cantidad: cantidad,
                  unidad: unidad,
                  unidadComercial: unidadComercial,
                  descripcion: descripcion,
                  precioUnitario: precioUnitario,
                  montototal: montototal,
                  montodesc: montodesc,
                  naturalezaDescuento: naturalezaDescuento,
                  subtotalLinea: subtotalLinea,
                  CodigoImpuesto: CodigoImpuesto,
                  porcentajeImpuestos: porcentajeImpuestos,
                  montoImpuestos: montoImpuestos,
                  TipoDocExonera: TipoDocExonera,
                  NumDocExonera: NumDocExonera,
                  NombreInstituExonera: NombreInstituExonera,
                  FechaEmisionExonera: FechaEmisionExonera,
                  PorcentajeExoneracion: PorcCompraExonera,
                  MontoExoneracion: MontoImpExonera,
                  ImpuestoNeto: ImpuestoNeto,
                  montototalinea: montototalinea
                }
              )

              listItems.push({
                name: 'LineaDetalle',
                children: [
                  { name: 'NumeroLinea', text: linea },
                  PartidaArancelaria !== '' ? { name: 'PartidaArancelaria', text: PartidaArancelaria } : {},
                  CodigoProductoServicio !== '' ? { name: 'Codigo', text: CodigoProductoServicio } : {},
                  codigoProducto && codigoProducto !== '' ? {
                    name: 'CodigoComercial',
                    children: [
                      { name: 'Tipo', text: tipoCodigoProducto },
                      { name: 'Codigo', text: codigoProducto }
                    ]
                  } : {},
                  cod2 && cod2 !== '' ? {
                    name: 'CodigoComercial',
                    children: [
                      { name: 'Tipo', text: tip2 },
                      { name: 'Codigo', text: cod2 }
                    ]
                  } : {},
                  cod3 && cod3 !== '' ? {
                    name: 'CodigoComercial',
                    children: [
                      { name: 'Tipo', text: tip3 },
                      { name: 'Codigo', text: cod3 }
                    ]
                  } : {},
                  cod4 && cod4 !== '' ? {
                    name: 'CodigoComercial',
                    children: [
                      { name: 'Tipo', text: tip4 },
                      { name: 'Codigo', text: cod4 }
                    ]
                  } : {},
                  cod5 && cod5 !== '' ? {
                    name: 'CodigoComercial',
                    children: [
                      { name: 'Tipo', text: tip5 },
                      { name: 'Codigo', text: cod5 }
                    ]
                  } : {},
                  { name: 'Cantidad', text: decimal(cantidad, 3) },
                  { name: 'UnidadMedida', text: unidad },
                  unidadComercial !== '' ? { name: 'UnidadMedidaComercial', text: unidadComercial } : {},
                  { name: 'Detalle', text: omitirAcentos(descripcion) },
                  { name: 'PrecioUnitario', text: decimal(precioUnitario.toString(), 5) },
                  { name: 'MontoTotal', text: decimal(montototal.toString(), 5) },
                  descuento !== '' && naturalezaDescuento !== '' ? {
                    name: 'Descuento',
                    children: [
                      { name: 'MontoDescuento', text: decimal(montodesc.toString(), 5) },
                      { name: 'NaturalezaDescuento', text: omitirAcentos(naturalezaDescuento) }
                    ]
                  } : {},
                  { name: 'SubTotal', text: decimal(subtotalLinea.toString(), 5) },
                  BaseImponible !== '' ? { name: 'BaseImponible', text: decimal(BaseImponible.toString(), 5) } : {},
                  CodigoImpuesto !== '' && (porcentajeImpuestos !== '' && porcentajeImpuestos !== '0') && (montoImpuestos !== '' && montoImpuestos !== '0') ? {
                    name: 'Impuesto',
                    children: [
                      { name: 'Codigo', text: CodigoImpuesto },
                      CodigoTarifa !== '' ? { name: 'CodigoTarifa', text: CodigoTarifa } : {},
                      { name: 'Tarifa', text: decimal(porcentajeImpuestos, 2) },
                      FactorIVA !== '' && FactorIVA !== '0' ? { name: 'FactorIVA', text: decimal(FactorIVA, 4) } : {},
                      { name: 'Monto', text: decimal(montoImpuestos, 5) },
                      MontoExportacion !== '' ? { name: 'MontoExportacion', text: decimal(MontoExportacion, 5) } : {},
                      TipoDocExonera !== '' && NombreInstituExonera !== '' ? {
                        name: 'Exoneracion',
                        children: [
                          { name: 'TipoDocumento', text: TipoDocExonera },
                          { name: 'NumeroDocumento', text: NumDocExonera },
                          { name: 'NombreInstitucion', text: omitirAcentos(NombreInstituExonera) },
                          { name: 'FechaEmision', text: FechaEmisionExonera },
                          { name: 'PorcentajeExoneracion', text: PorcCompraExonera },
                          { name: 'MontoExoneracion', text: decimal(MontoImpExonera, 5) }
                        ]
                      } : {}
                    ]
                  } : {},
                  { name: 'ImpuestoNeto', text: decimal(ImpuestoNeto.toString(), 5) },
                  { name: 'MontoTotalLinea', text: decimal(montototalinea.toString(), 5) }
                ]
              })
            }

            for (var c in data.others) {
              /** otrosCargos */
              const otros = data.others[c].split('|')
              const lineaOtros = otros[0]; const TipoDocumentoOtros = otros[1]; const NumeroIdentidadTercero = otros[2]
              const NombreTercero = otros[3]; const DetalleOtros = otros[4]; const PorcentajeOtros = otros[5]
              let MontoCargo = otros[6]

              MontoCargo = Math.round(parseFloat(MontoCargo) * 100000) / 100000

              TotalOtrosCargos = TotalOtrosCargos + MontoCargo

              docFactura.otrosCargos.push({
                TipoDocumento: TipoDocumentoOtros,
                NumeroIdentidadTercero: NumeroIdentidadTercero,
                NombreTercero: NombreTercero,
                DetalleOtros: DetalleOtros,
                PorcentajeOtros: PorcentajeOtros,
                MontoCargo: MontoCargo
              })

              listOthers.push([
                { name: 'TipoDocumento', text: TipoDocumentoOtros },
                NumeroIdentidadTercero !== '' ? { name: 'NumeroIdentidadTercero', text: NumeroIdentidadTercero } : {},
                NombreTercero !== '' ? { name: 'NombreTercero', text: NombreTercero } : {},
                { name: 'Detalle', text: DetalleOtros },
                PorcentajeOtros !== '' ? { name: 'Porcentaje', text: decimal(PorcentajeOtros.toString(), 5) } : {},
                { name: 'MontoCargo', text: decimal(MontoCargo.toString(), 5) }
              ])
            }

            var arrayReferencia = []
            /** Documentos de referencia */
            for (var r in data.invoices) {
              var referencia = data.invoices[r].split('|')
              const NumConsecutivo = referencia[0]; var TipoDocReferencia = referencia[1]
              const CodigoReferencia = referencia[2]; const RazonReferencia = referencia[3]
              var date = new Date(referencia[4])
              const FechaEmisionReferencia = date.getFullYear() +
                '-' + pad2(date.getMonth() + 1) +
                '-' + pad2(date.getDate()) +
                'T' + pad2(date.getHours()) +
                ':' + pad2(date.getMinutes()) +
                ':' + pad2(date.getSeconds()) +
                '-06:00'
              docFactura.Facturas.push(
                {
                  TipoDocumentoReferencia: TipoDocReferencia,
                  ClaveDocumentoReferencia: NumConsecutivo,
                  FechaEmisionReferencia: FechaEmisionReferencia,
                  CodigoReferencia: CodigoReferencia,
                  RazonReferencia: RazonReferencia
                }
              )

              arrayReferencia.push({
                name: 'InformacionReferencia',
                children: [
                  { name: 'TipoDoc', text: TipoDocReferencia },
                  { name: 'Numero', text: NumConsecutivo },
                  { name: 'FechaEmision', text: FechaEmisionReferencia },
                  { name: 'Codigo', text: CodigoReferencia },
                  { name: 'Razon', text: omitirAcentos(RazonReferencia) }
                ]
              })
            }

            mongo.findOne('company', { idNum: entidad, environment: envCompany }, async (err, environment) => {
              if (err || !environment) {
                send({ error: 'wrongData', message: 'Cédula ' + entidad + ' no esta registrada en sistema de Facturación Electrónica' })
              } else {
                // resumen fact
                TotalMercanciasGravadas = Math.round(TotalMercanciasGravadas * 100000) / 100000
                TotalServGravados = Math.round(TotalServGravados * 100000) / 100000
                TotalMercanciasExentas = Math.round(TotalMercanciasExentas * 100000) / 100000
                TotalServExentos = Math.round(TotalServExentos * 100000) / 100000
                var TotalGravado = Math.round((TotalServGravados + TotalMercanciasGravadas) * 100000) / 100000
                var TotalExento = Math.round((TotalServExentos + TotalMercanciasExentas) * 100000) / 100000
                var TotalExonerado = Math.round((TotalServExonerado + TotalMercExonerada) * 100000) / 100000
                var TotalVenta = Math.round((TotalGravado + TotalExento + TotalExonerado) * 100000) / 100000
                var TotalDescuentos = parseFloat(descuentoTotal)
                var TotalVentaNeta = indicador === '0' ? Math.round((TotalVenta - TotalDescuentos) * 100000) / 100000 : Math.round((TotalVenta - TotalDescuentos) * 100000) / 100000
                // var TotalVentaNeta = parseFloat(subtotal) - TotalDescuentos;
                var TotalImpuesto = totImpuestos
                var TotalComprobante = indicador === '0' ? Math.round(TotalVentaNeta + TotalImpuesto + TotalOtrosCargos - IVADevuelto) : Math.round((TotalVentaNeta + TotalImpuesto + TotalOtrosCargos - IVADevuelto) * 100000) / 100000
                mongo.findOne('invoiceCredit', { consecutivo2: consecutivo2, sucursal: sucursal, terminal: terminal, company: entidad }, {}, async (err, invs) => {
                  var obj
                  var follow = true
                  if (err) {
                    send({ error: 'IOError', message: 'Ocurrio un error al buscar el consecutivo en la base de datos, intentelo de nuevo' })
                  } else if (invs && (invs.statusHacienda !== 'inconsistente' && invs.statusHacienda !== undefined)) {
                    send({ error: 'wrongData', message: 'El consecutivo enviado ya existe en la base de datos con clave numérica ' + invs.clave })
                  } else {
                    // observacion + adicionales
                    var observaciones = observacion + ' ' + adicional1 + ' ' + adicional2 + ' ' + adicional3 + ' ' + adicional4 + ' ' +
                      adicional5 + ' ' + adicional6 + ' ' + adicional7 + ' ' + adicional8 + ' ' + adicional9 + ' ' + adicional10

                    // fechaDoc = new Date(fechaDoc).toISOString();
                    if (invs) {
                      docFactura._id = invs._id
                      docFactura.clave = invs.clave
                      docFactura.numeroConsecutivo = invs.numeroConsecutivo
                      var date = new Date(fechaDoc)
                      fechaDoc = date.getFullYear() +
                        '-' + pad2(date.getMonth() + 1) +
                        '-' + pad2(date.getDate()) +
                        'T' + pad2(date.getHours()) +
                        ':' + pad2(date.getMinutes()) +
                        ':' + pad2(date.getSeconds()) +
                        '-06:00'
                    } else {
                      follow = await new Promise(resolve => {
                        mongo.findOneAndUpdate('consecutive',
                          { company: entidad, sucursal: sucursal, terminal: terminal, typeDocument: tipoDoc },
                          { $inc: { value: 1 } },
                          { value: 1 },
                          async (err, consecutiveSearched) => {
                            if (err) {
                              obj = { error: 'notFound', message: 'Ocurrio un error intentelo de nuevo' }
                              resolve(false)
                            } else if (!consecutiveSearched || (consecutiveSearched && !consecutiveSearched.value)) {
                              obj = { error: 'wrongData', message: 'Error, verifique numero consecutivo en la compañia' }
                              resolve(false)
                            } else {
                              var consecutivo
                              consecutivo = pad(consecutiveSearched.value.value.toString(), 10)

                              //* ******Clave numerica*******
                              // Information for Electronic invoice
                              // consecutivo
                              var consecutivoMod = consecutivo
                              // local o establecimiento
                              var casaMatriz = sucursal
                              // numero consecutivo
                              var numeroConsecutivo = casaMatriz + terminal + tipoDoc + consecutivoMod
                              // codigo del pais
                              var codPais = '506'
                              var date = new Date(fechaDoc)
                              fechaDoc = date.getFullYear() +
                                '-' + pad2(date.getMonth() + 1) +
                                '-' + pad2(date.getDate()) +
                                'T' + pad2(date.getHours()) +
                                ':' + pad2(date.getMinutes()) +
                                ':' + pad2(date.getSeconds()) +
                                '-06:00'
                              // dia
                              var day = date.getDate()
                              if (day < 10) {
                                day = pad(day, 2)
                              }
                              day = day.toString()
                              // mes
                              var month = date.getMonth() + 1
                              if (month < 10) {
                                month = pad(month, 2)
                              }
                              month = month.toString()
                              // año
                              var year = date.getFullYear()
                              year = year.toString()
                              year = year.slice(2, 4)
                              // cedula emisor
                              var ced = pad(entidad, 12)
                              // codigo de seguridad
                              var codSeg = pad(environment.code, 8)
                              // clave numerica
                              var key = codPais + day + month + year + ced + numeroConsecutivo + situacion + codSeg
                              docFactura.clave = key
                              docFactura.numeroConsecutivo = numeroConsecutivo
                              resolve(true)
                            }
                          })
                      })
                    }
                    if (follow) {
                      docFactura.CodigoActividad = CodigoActividad
                      docFactura.company = entidad
                      docFactura.tipoDocumento = tipoDoc
                      docFactura.sucursal = sucursal
                      docFactura.terminal = terminal
                      docFactura.consecutivoTemporal = consecutivo2
                      docFactura.fechaDocumento = fechaDoc
                      docFactura.Emisor = {
                        Nombre: environment.name,
                        tipoIdentificacion: environment.idType,
                        numeroIdentificacion: environment.idNum,
                        Provincia: environment.province,
                        Canton: environment.canton,
                        Distrito: environment.district,
                        OtrasSenas: environment.signs,
                        CodigoPais: environment.codPhone,
                        NumeroTelefono: environment.phone,
                        CorreoElectronico: environment.email
                      }
                      docFactura.Receptor = {
                        Nombre: nombreCliente,
                        tipoIdentificacion: tipoIdentificacion,
                        numeroIdentificacion: cedulaCliente,
                        IdentificacionExtranjero: extranjero,
                        Provincia: provinvia,
                        Canton: canton,
                        Distrito: distrito,
                        Barrio: barrio,
                        OtrasSenas: direccionCliente,
                        CodigoPais: numeroAreaTelefono,
                        NumTelefono: telefonoCliente,
                        CorreoElectronico: copiaCortesia
                      }
                      docFactura.CondicionVenta = condicion
                      docFactura.PlazoCredito = plazo
                      docFactura.MedioPago = medioPago1
                      docFactura.Moneda = moneda
                      docFactura.tipoCambio = tipoCambio
                      docFactura.TotalServGravados = TotalServGravados
                      docFactura.TotalMercanciasGravadas = TotalMercanciasGravadas
                      docFactura.TotalServExentos = TotalServExentos
                      docFactura.TotalServExonerado = TotalServExonerado
                      docFactura.TotalMercanciasExentas = TotalMercanciasExentas
                      docFactura.TotalMercExonerada = TotalMercExonerada
                      docFactura.TotalGravado = TotalGravado
                      docFactura.TotalExento = TotalExento
                      docFactura.TotalExonerado = TotalExonerado
                      docFactura.TotalVenta = TotalVenta
                      docFactura.TotalDescuentos = TotalDescuentos
                      docFactura.TotalVentaNeta = TotalVentaNeta
                      docFactura.TotalImpuesto = TotalImpuesto
                      docFactura.TotalIVADevuelto = IVADevuelto
                      docFactura.TotalOtrosCargos = TotalOtrosCargos
                      docFactura.TotalComprobante = TotalComprobante
                      docFactura.observacion = observaciones
                      docFactura.consecutivo2 = consecutivo2
                      await new Promise(resolve => {
                        mongo.save('invoiceCredit', docFactura, () => {
                          resolve()
                        })
                      })
                      docFactura.thread = this.thread
                      docFactura.atv = 'P'
                      setXML(docFactura.clave, docFactura.numeroConsecutivo)
                    } else {
                      send(obj)
                    }
                  }
                  // compose xml
                  function setXML (key, numeroConsecutivo) {
                    var xmlArray = [
                      { name: 'Clave', text: key },
                      { name: 'CodigoActividad', text: CodigoActividad },
                      { name: 'NumeroConsecutivo', text: numeroConsecutivo },
                      { name: 'FechaEmision', text: fechaDoc },
                      //* *** datos emisor ****/
                      TipoDocReferencia !== '08' ? {
                        name: 'Emisor',
                        children: [
                          { name: 'Nombre', text: omitirAcentos(environment.name) },
                          {
                            name: 'Identificacion',
                            children: [
                              { name: 'Tipo', text: environment.idType },
                              { name: 'Numero', text: environment.idNum }
                            ]
                          },
                          {
                            name: 'Ubicacion',
                            children: [
                              { name: 'Provincia', text: environment.province },
                              { name: 'Canton', text: environment.canton },
                              { name: 'Distrito', text: environment.district },
                              { name: 'OtrasSenas', text: omitirAcentos(environment.signs) }
                            ]
                          },
                          {
                            name: 'Telefono',
                            children: [
                              { name: 'CodigoPais', text: environment.codPhone },
                              { name: 'NumTelefono', text: environment.phone }
                            ]
                          },
                          { name: 'CorreoElectronico', text: environment.email }
                        ]
                      } : {
                        name: 'Emisor',
                        children: [
                          { name: 'Nombre', text: omitirAcentos(nombreCliente) },
                          tipoIdentificacion !== '' ? {
                            name: 'Identificacion',
                            children: [
                              { name: 'Tipo', text: tipoIdentificacion },
                              { name: 'Numero', text: cedulaCliente }
                            ]
                          } : {},
                          tipoDoc !== '09' && (provinvia !== '' && canton !== '' && distrito !== '' && direccionCliente !== '') ? {
                            name: 'Ubicacion',
                            children: [
                              { name: 'Provincia', text: provinvia },
                              { name: 'Canton', text: canton },
                              { name: 'Distrito', text: distrito },
                              barrio !== '' ? { name: 'Barrio', text: barrio } : {},
                              { name: 'OtrasSenas', text: direccionCliente }
                            ]
                          } : {},
                          numeroAreaTelefono !== '' && telefonoCliente !== '' ? {
                            name: 'Telefono',
                            children: [
                              { name: 'CodigoPais', text: numeroAreaTelefono },
                              { name: 'NumTelefono', text: telefonoCliente }
                            ]
                          } : {},
                          copiaCortesia !== '' ? { name: 'CorreoElectronico', text: copiaCortesia } : {}
                        ]
                      },
                      //* *** datos receptor si existen? ****/
                      TipoDocReferencia !== '08' ? nombreCliente !== '' ? {
                        name: 'Receptor',
                        children: [
                          { name: 'Nombre', text: omitirAcentos(nombreCliente) },
                          tipoIdentificacion !== '' ? {
                            name: 'Identificacion',
                            children: [
                              { name: 'Tipo', text: tipoIdentificacion },
                              { name: 'Numero', text: cedulaCliente }
                            ]
                          } : {},
                          tipoIdentificacion !== '' && extranjero === '1' ? { name: 'IdentificacionExtranjero', text: cedulaCliente } : {},
                          tipoDoc !== '09' && (provinvia !== '' && canton !== '' && distrito !== '' && direccionCliente !== '') ? {
                            name: 'Ubicacion',
                            children: [
                              { name: 'Provincia', text: provinvia },
                              { name: 'Canton', text: canton },
                              { name: 'Distrito', text: distrito },
                              barrio !== '' ? { name: 'Barrio', text: barrio } : {},
                              { name: 'OtrasSenas', text: direccionCliente }
                            ]
                          } : {},
                          direccionCliente !== '' && extranjero === '1' ? { name: 'OtrasSenasExtranjero', text: omitirAcentos(direccionCliente) } : {},
                          numeroAreaTelefono !== '' && telefonoCliente !== '' ? {
                            name: 'Telefono',
                            children: [
                              { name: 'CodigoPais', text: numeroAreaTelefono },
                              { name: 'NumTelefono', text: telefonoCliente }
                            ]
                          } : {},
                          copiaCortesia !== '' ? { name: 'CorreoElectronico', text: copiaCortesia } : {}
                        ]
                      } : {} : {
                        name: 'Receptor',
                        children: [
                          { name: 'Nombre', text: omitirAcentos(environment.name) },
                          {
                            name: 'Identificacion',
                            children: [
                              { name: 'Tipo', text: environment.idType },
                              { name: 'Numero', text: environment.idNum }
                            ]
                          },
                          {
                            name: 'Ubicacion',
                            children: [
                              { name: 'Provincia', text: environment.province },
                              { name: 'Canton', text: environment.canton },
                              { name: 'Distrito', text: environment.district },
                              { name: 'OtrasSenas', text: omitirAcentos(environment.signs) }
                            ]
                          },
                          {
                            name: 'Telefono',
                            children: [
                              { name: 'CodigoPais', text: environment.codPhone },
                              { name: 'NumTelefono', text: environment.phone }
                            ]
                          },
                          { name: 'CorreoElectronico', text: environment.email }
                        ]
                      },
                      { name: 'CondicionVenta', text: condicion },
                      { name: 'PlazoCredito', text: plazo },
                      { name: 'MedioPago', text: medioPago1 },
                      {
                        name: 'DetalleServicio',
                        children: listItems
                      },
                      listOthers.length > 0 ? {
                        name: 'OtrosCargos',
                        children: listOthers
                      } : {},
                      {
                        name: 'ResumenFactura',
                        children: [
                          tipoCambio !== '' && moneda !== '' ? {
                            name: 'CodigoTipoMoneda',
                            children: [
                              { name: 'CodigoMoneda', text: moneda },
                              { name: 'TipoCambio', text: decimal(tipoCambio, 5) }
                            ]
                          } : {},
                          { name: 'TotalServGravados', text: decimal(TotalServGravados.toString(), 5) },
                          { name: 'TotalServExentos', text: decimal(TotalServExentos.toString(), 5) },
                          tipoDoc !== '09' ? { name: 'TotalServExonerado', text: decimal(TotalServExonerado.toString(), 5) } : {},
                          { name: 'TotalMercanciasGravadas', text: decimal(TotalMercanciasGravadas.toString(), 5) },
                          { name: 'TotalMercanciasExentas', text: decimal(TotalMercanciasExentas.toString(), 5) },
                          tipoDoc !== '09' ? { name: 'TotalMercExonerada', text: decimal(TotalMercExonerada.toString(), 5) } : {},
                          { name: 'TotalGravado', text: decimal(TotalGravado.toString(), 5) },
                          { name: 'TotalExento', text: decimal(TotalExento.toString(), 5) },
                          tipoDoc !== '09' ? { name: 'TotalExonerado', text: decimal(TotalExonerado.toString(), 5) } : {},
                          { name: 'TotalVenta', text: decimal(TotalVenta.toString(), 5) },
                          { name: 'TotalDescuentos', text: decimal(TotalDescuentos.toString(), 5) },
                          { name: 'TotalVentaNeta', text: decimal(TotalVentaNeta.toString(), 5) },
                          impuestos !== '' ? { name: 'TotalImpuesto', text: decimal(TotalImpuesto.toString(), 5) } : {},
                          tipoDoc !== '08' && tipoDoc !== '09' && IVADevuelto !== '0' ? { name: 'TotalIVADevuelto', text: decimal(IVADevuelto.toString(), 5) } : {},
                          { name: 'TotalOtrosCargos', text: decimal(TotalOtrosCargos.toString(), 5) },
                          { name: 'TotalComprobante', text: decimal(TotalComprobante.toString(), 5) }
                        ]
                      },
                      arrayReferencia,
                      /* {
                  name: 'Normativa',
                  children: [
                    { name: 'NumeroResolucion', text: 'DGT-R-48-2016' },
                    { name: 'FechaResolucion', text: '20-02-2017 13:22:22' }
                  ]
                }, */
                      {
                        name: 'Otros',
                        children: [
                          Otros
                        ]
                      }
                    ]
                    if (tipoDoc === '02') {
                      // xml de factura
                      var xml = jsonxml({
                        NotaDebitoElectronica: xmlArray
                      }, { xmlHeader: true })

                      // xml con etiqueta tipo y xmlns
                      var x = xml.split('NotaDebitoElectronica', 2)
                      var i = x[0] + 'NotaDebitoElectronica xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/notaDebitoElectronica"'
                      var completeXml = i + x[1]
                      completeXml = completeXml + 'NotaDebitoElectronica>'
                    } else if (tipoDoc === '03') {
                      // xml de factura
                      xml = jsonxml({
                        NotaCreditoElectronica: xmlArray
                      }, { xmlHeader: true })

                      // xml con etiqueta tipo y xmlns
                      x = xml.split('NotaCreditoElectronica', 2)
                      i = x[0] + 'NotaCreditoElectronica xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/notaCreditoElectronica"'
                      completeXml = i + x[1]
                      completeXml = completeXml + 'NotaCreditoElectronica>'
                    }
                    fs.writeFile('/tmp/' + key + '.xml', completeXml, (err) => {
                      if (err) {
                        send({ error: 'Error', message: 'intentelo de nuevo: ' + err })
                      } else {
                        chilkatExample()
                        firmar()
                      }
                      // firma Chilkat
                      function firmar () {
                        var fileId = environment.description.split('?_id=')[1]
                        fileId = fileId.split('&')[0]
                        req.app.routes.file.get({ _id: fileId, type: 'p12' }, mongo, (result) => {
                          var tmp = '/tmp/' + result.filename
                          var file = fs.createWriteStream(tmp)
                          file.on('finish', function () {
                            var cert = new chilkat.Cert()
                            var success = cert.LoadPfxFile(tmp, environment.pin)
                            if (success !== true) {
                              send({ error: 'wrongCrypt', message: 'Ocurrio un error al abrir el certificado ' + cert.LastErrorText })
                              console.log(cert.LastErrorText)
                              return
                            }

                            // Load XML to be signed.
                            var sbXml = new chilkat.StringBuilder()
                            success = sbXml.LoadFile('/tmp/' + key + '.xml', 'utf-8')
                            if (success !== true) {
                              send({ error: 'wrongCrypt', message: 'Ocurrio un error al cargar la factura' })
                              console.log('Failed to load file.')
                              return
                            }

                            var gen = new chilkat.XmlDSigGen()

                            // Indicate where the signature is to be placed.
                            gen.SigLocation = tipoDoc === '02' ? 'NotaDebitoElectronica'
                              : tipoDoc === '03' ? 'NotaCreditoElectronica' : ''
                            gen.SigId = 'Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0'
                            gen.SigNamespacePrefix = 'ds'
                            gen.SignedInfoCanonAlg = 'C14N'
                            gen.SignedInfoDigestMethod = 'sha256'

                            var xml = new chilkat.Xml()
                            var cdn = tipoDoc === '02' ? 'notaDebitoElectronica'
                              : tipoDoc === '03' ? 'notaCreditoElectronica' : ''
                            xml.Tag = 'xades:QualifyingProperties'
                            xml.AddAttribute('xmlns:xades', 'http://uri.etsi.org/01903/v1.3.2#')
                            xml.AddAttribute('Id', 'QualifyingProperties-aa262416-8607-4f02-8897-0a6440a1ae03')
                            xml.AddAttribute('Target', '#Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0')
                            xml.UpdateAttrAt('xades:SignedProperties', true, 'Id', 'SignedProperties-Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0')
                            xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningTime', 'TO BE GENERATED BY CHILKAT')
                            xml.UpdateAttrAt('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningCertificate|xades:Cert|xades:CertDigest|ds:DigestMethod', true, 'Algorithm', 'http://www.w3.org/2001/04/xmlenc#sha256')
                            xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningCertificate|xades:Cert|xades:CertDigest|ds:DigestValue', 'TO BE GENERATED BY CHILKAT')
                            xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningCertificate|xades:Cert|xades:IssuerSerial|ds:X509IssuerName', 'TO BE GENERATED BY CHILKAT')
                            xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningCertificate|xades:Cert|xades:IssuerSerial|ds:X509SerialNumber', 'TO BE GENERATED BY CHILKAT')
                            xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SignaturePolicyIdentifier|xades:SignaturePolicyId|xades:SigPolicyId|xades:Identifier', 'https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/' + cdn)
                            xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SignaturePolicyIdentifier|xades:SignaturePolicyId|xades:SigPolicyId|xades:Description', '')
                            xml.UpdateAttrAt('xades:SignedProperties|xades:SignedSignatureProperties|xades:SignaturePolicyIdentifier|xades:SignaturePolicyId|xades:SigPolicyHash|ds:DigestMethod', true, 'Algorithm', 'http://www.w3.org/2001/04/xmlenc#sha256')
                            xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SignaturePolicyIdentifier|xades:SignaturePolicyId|xades:SigPolicyHash|ds:DigestValue', 'NmI5Njk1ZThkNzI0MmIzMGJmZDAyNDc4YjUwNzkzODM2NTBiOWUxNTBkMmI2YjgzYzZjM2I5NTZlNDQ4OWQzMQ==')
                            xml.UpdateAttrAt('xades:SignedProperties|xades:SignedDataObjectProperties|xades:DataObjectFormat', true, 'ObjectReference', '#Reference-ab26afbd-e2dc-4cb0-886a-ce2a4a118c7f')
                            xml.UpdateChildContent('xades:SignedProperties|xades:SignedDataObjectProperties|xades:DataObjectFormat|xades:MimeType', 'text/xml')
                            xml.UpdateChildContent('xades:SignedProperties|xades:SignedDataObjectProperties|xades:DataObjectFormat|xades:Encoding', 'UTF-8')

                            gen.AddObject('XadesObjectId-674a431e-692c-4e0a-9d82-6275c85c5876', xml.GetXml(), '', '')

                            var signedPropsId = 'SignedProperties-Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0'
                            gen.AddObjectRef(signedPropsId, 'sha256', 'EXCL_C14N', '', 'http://uri.etsi.org/01903#SignedProperties')

                            var keyInfoId = 'KeyInfoId-Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0'
                            gen.KeyInfoId = keyInfoId
                            gen.AddSameDocRef(keyInfoId, 'sha256', 'EXCL_C14N', '', '')
                            gen.SetRefIdAttr(keyInfoId, 'ReferenceKeyInfo')

                            gen.AddSameDocRef('', 'sha256', 'EXCL_C14N', '', '')
                            gen.SetRefIdAttr('', 'Reference-ab26afbd-e2dc-4cb0-886a-ce2a4a118c7f')

                            gen.KeyInfoType = 'X509Data+KeyValue'
                            gen.X509Type = 'Certificate'
                            success = gen.SetX509Cert(cert, true)
                            if (!success) {
                              send({ error: 'wrongCrypt', message: 'Ocurrio un error al firmar la factura ' + gen.LastErrorText })
                              console.log(gen.LastErrorText)
                              return
                            }

                            gen.Behaviors = 'IndentedSignature'

                            success = gen.CreateXmlDSigSb(sbXml)
                            if (!success) {
                              send({ error: 'wrongCrypt', message: 'Ocurrio un error al firmar la factura ' + gen.LastErrorText })
                              console.log(gen.LastErrorText)
                              return
                            }
                            try {
                              var xmlDoc = sbXml.GetAsString()
                              var comprobanteXml = base64.encode(utf8.encode(xmlDoc))
                              docFactura.voucherXml = comprobanteXml
                              mongo.save('invoiceCredit', docFactura, (err) => {
                                if (err) {
                                  send({ error: 'IOError', message: 'Problema al guardar el XML' })
                                } else {
                                  req.app.routes.backgroundCredit.sendPending2atv(req)
                                  send({ numericKey: key })
                                }
                              })
                            } catch (error) {
                              docFactura.statusHacienda = 'inconsistente'
                              delete docFactura.atv
                              mongo.save('invoiceCredit', docFactura, () => {
                                send({ error: 'XMLError', message: 'El XML contiene errores' })
                              })
                            }
                          })
                          result.pipe(file)
                        })
                      }
                    })
                  }
                })
              }
            })
          } else {
            send({ error: 'wrongData', message: 'Se espera el campo Codigo actividad' })
          }
        }
      })
    } else {
      send({ error: 'wrongData', message: 'Se esperan 42 campos' })
    }
  }
  /*
   * params: numericKey
   * reply: { status: "" } ó {error:"code", message:"message"}
   */
  this.status = function (req, mongo, send) {
    var data = this.parseData(req)
    data._id = mongo.newId()
    data.method = 'status'
    var cedula = data.id
    var TipoDoc = data.type
    var claveNumerica = data.numericKey
    var collection
    var keys = { clave: claveNumerica }
    switch (TipoDoc) {
    case '01':
    case '04':
    case '08':
    case '09':
      collection = 'invoice'
      break
    case '02':
    case '03':
      collection = 'invoiceCredit'
      break
    case '05':
    case '06':
    case '07':
      collection = 'invoice2pay'
      var keyRef = claveNumerica.split('-')[0]
      keys = { $and: [{ $or: [keys, { keyRef: keyRef }] }, { company: cedula }] }
      break
    default:
      send({ error: 'wrongData', message: 'Tipo de documento (' + TipoDoc + ') incorrecto, se espera 01,02,03,04,05,06,07,08 o 09' })
      return
    }
    mongo.findN(collection, 0, 1, keys, {}, { _id: -1 }, (err, factura) => {
      var reply
      if (err) {
        reply = { error: 'IOError', message: err }
      } if (!factura || factura.length === 0) {
        reply = { error: 'notFound', status: 'rechazado', message: 'No existe el documento' }
      } else {
        factura = factura[0]
        var detalle = 'procesando'
        if (factura.responseXml && factura.responseXml !== 'procesando') {
          try{
            var str = base64.decode(factura.responseXml)
            var spl = str.split('<DetalleMensaje>', 2)
            if (spl[1]) { detalle = spl[1].split('</DetalleMensaje>', 1)[0] }
            reply = { status: factura.statusHacienda, message: detalle }
          } catch(e) {
            console.log('ERROR: '+e.toString())
            console.log('xml='+factura.responseXml)
            mongo.update(collection,{_id: factura._id},{$set: {statusHacienda: 'procesando'},$unset: {responseXml: ''}},()=>{})
            reply = {error: 'badXml', status: 'procesando', message: e.toString()}
          }
        } else {
          reply = { status: factura.statusHacienda, message: detalle }
        }
      }
      send(reply)
    })
  }
  /*
   * params: numericKey,id,status,message
   * reply: {numericKey:"0.....50"} ó {error:"code", message:"message"}
   */
  this.setInvoice = function (req, mongo, send) {
    var chilkat = require('@chilkat/ck-node14-linux64')
    var envCompany = '..'
    var data = this.parseData(req)
    data._id = mongo.newId()
    data.method = 'setInvoice'
    if (req.app.params.ebillEnvironment) { envCompany = req.app.params.ebillEnvironment } else { envCompany = 'Pruebas' }
    mongo.findOne('company', { idNum: data.id, environment: envCompany }, {}, (err, CP) => {
      if (err || (CP && CP.inactive && CP.inactive === '1')) {
        send({ error: 'notFound', message: 'Cliente ' + data.id + ' inhabilitado para envio/recepción de documentos electronicos. Por favor contacte con su proveedor de sistema' })
      } else {
        var doc = {}
        doc._id = mongo.newId()
        doc.thread = this.thread
        if (data.xml || data.xml === '') {
          var xmlGet
          try {
            xmlGet = data.xml !== '' ? base64.decode(data.xml) : ''
          } catch (e) {
            send({ error: 'XMLError', message: 'El XML contiene errores' })
            return
          }
          parser.parseString(xmlGet, function (err, result) {
            if (err) {
              send({ error: 'XMLError', message: 'se produjo un error, intentelo de nuevo, ' + err.message })
            } else {
              var existReceptor = true
              var tipo = ''
              var cedula = data.id
              var Estado = data.status
              var MensajeEstado = data.message
              var sucursal = data.sucursal
              var terminal = data.terminal
              var conditionTax = data.conditionTax
              var amountCredit = data.amountCredit || ''
              var amountApplicable = data.amountApplicable || ''
              var codeActivity = data.codeActivity
              var claveNumerica = data.numericKey
              var date = new Date()
              var fechaEmision = date.getFullYear() +
                '-' + pad2(date.getMonth() + 1) +
                '-' + pad2(date.getDate()) +
                'T' + pad2(date.getHours()) +
                ':' + pad2(date.getMinutes()) +
                ':' + pad2(date.getSeconds()) +
                '-06:00'
              var nombreEmisor = data.personName
              var cedulaEmisor = data.personId
              var tipoEmisor = data.personType
              var cedulaReceptor = data.receptorId
              var tipoReceptor = data.receptorType
              var consecutivoTemporal = data.consecutive
              var totalComprobante = data.total
              var totalImpuestos = data.totalTax

              if (((!claveNumerica || claveNumerica === '') || (!cedulaEmisor || cedulaEmisor === '') || (!tipoEmisor || tipoEmisor === '') ||
                (!cedulaReceptor || cedulaReceptor === '') || (!tipoReceptor || tipoReceptor === '') || (!totalComprobante || totalComprobante === '') ||
                (!totalImpuestos || totalImpuestos === '')) && result) {
                if (result.FacturaElectronica) {
                  if (result.FacturaElectronica.Receptor) {
                    claveNumerica = result.FacturaElectronica.Clave[0]
                    cedulaEmisor = result.FacturaElectronica.Emisor[0].Identificacion[0].Numero[0]
                    tipoEmisor = result.FacturaElectronica.Emisor[0].Identificacion[0].Tipo[0]
                    cedulaReceptor = result.FacturaElectronica.Receptor[0].Identificacion[0].Numero[0]
                    tipoReceptor = result.FacturaElectronica.Receptor[0].Identificacion[0].Tipo[0]
                    totalComprobante = result.FacturaElectronica.ResumenFactura[0].TotalComprobante[0]
                    totalImpuestos = result.FacturaElectronica.ResumenFactura[0].TotalImpuesto ? result.FacturaElectronica.ResumenFactura[0].TotalImpuesto[0] : totalImpuestos
                  } else {
                    existReceptor = false
                  }
                } else if (result.TiqueteElectronico) {
                  if (result.TiqueteElectronico.Receptor) {
                    claveNumerica = result.TiqueteElectronico.Clave[0]
                    cedulaEmisor = result.TiqueteElectronico.Emisor[0].Identificacion[0].Numero[0]
                    tipoEmisor = result.TiqueteElectronico.Emisor[0].Identificacion[0].Tipo[0]
                    cedulaReceptor = result.TiqueteElectronico.Receptor[0].Identificacion[0].Numero[0]
                    tipoReceptor = result.TiqueteElectronico.Receptor[0].Identificacion[0].Tipo[0]
                    totalComprobante = result.TiqueteElectronico.ResumenFactura[0].TotalComprobante[0]
                    totalImpuestos = result.TiqueteElectronico.ResumenFactura[0].TotalImpuesto ? result.TiqueteElectronico.ResumenFactura[0].TotalImpuesto[0] : totalImpuestos
                  } else {
                    existReceptor = false
                  }
                } else if (result.NotaCreditoElectronica) {
                  if (result.NotaCreditoElectronica.Receptor) {
                    claveNumerica = result.NotaCreditoElectronica.Clave[0]
                    cedulaEmisor = result.NotaCreditoElectronica.Emisor[0].Identificacion[0].Numero[0]
                    tipoEmisor = result.NotaCreditoElectronica.Emisor[0].Identificacion[0].Tipo[0]
                    cedulaReceptor = result.NotaCreditoElectronica.Receptor[0].Identificacion[0].Numero[0]
                    tipoReceptor = result.NotaCreditoElectronica.Receptor[0].Identificacion[0].Tipo[0]
                    totalComprobante = result.NotaCreditoElectronica.ResumenFactura[0].TotalComprobante[0]
                    totalImpuestos = result.NotaCreditoElectronica.ResumenFactura[0].TotalImpuesto ? result.NotaCreditoElectronica.ResumenFactura[0].TotalImpuesto[0] : totalImpuestos
                  } else {
                    existReceptor = false
                  }
                } else if (result.NotaDebitoElectronica) {
                  if (result.NotaDebitoElectronica.Receptor) {
                    claveNumerica = result.NotaDebitoElectronica.Clave[0]
                    cedulaEmisor = result.NotaDebitoElectronica.Emisor[0].Identificacion[0].Numero[0]
                    tipoEmisor = result.NotaDebitoElectronica.Emisor[0].Identificacion[0].Tipo[0]
                    cedulaReceptor = result.NotaDebitoElectronica.Receptor[0].Identificacion[0].Numero[0]
                    tipoReceptor = result.NotaDebitoElectronica.Receptor[0].Identificacion[0].Tipo[0]
                    totalComprobante = result.NotaDebitoElectronica.ResumenFactura[0].TotalComprobante[0]
                    totalImpuestos = result.NotaDebitoElectronica.ResumenFactura[0].TotalImpuesto ? result.NotaDebitoElectronica.ResumenFactura[0].TotalImpuesto[0] : totalImpuestos
                  } else {
                    existReceptor = false
                  }
                }
              }

              switch (Estado) {
              case 'A':
                Estado = '1'
                tipo = '05'
                break
              case 'AP':
                Estado = '2'
                tipo = '06'
                break
              case 'R':
                Estado = '3'
                tipo = '07'
                break
              default:
                send({ error: 'wrongData', message: 'Codigo de aceptación (' + Estado + ') incorrecto, se espera A, AP o R' })
                return
              }
              if (existReceptor) {
                mongo.findOne('company', { idNum: cedula, environment: envCompany }, async (err, environment) => {
                  if (err || !environment) {
                    send({ error: 'notFound', message: 'Cédula ' + cedula + envCompany + ' no esta registrada en sistema de Facturación Electrónica' })
                  } else {
                    mongo.findOneAndUpdate('consecutive',
                      { company: cedula, sucursal: sucursal, terminal: terminal, typeDocument: tipo },
                      { $inc: { value: 1 } },
                      { value: 1 },
                      async (err, consecutiveSearched) => {
                        if (err) {
                          send({ error: 'notFound', message: 'Ocurrio un error intentelo de nuevo' })
                        } else if (!consecutiveSearched || (consecutiveSearched && !consecutiveSearched.value)) {
                          send({ error: 'wrongData', message: 'Error, verifique numero consecutivo en la compañia' })
                        } else {
                          var consecutivo
                          consecutivo = pad(consecutiveSearched.value.value.toString(), 10)
                          /** numero consecutivo */
                          var numeroConsecutivo = sucursal + terminal + tipo + consecutivo

                          /** clave numerica */
                          // dia
                          var codPais = '506'
                          var day = date.getDate()
                          if (day < 10) {
                            day = pad(day, 2)
                          }
                          day = day.toString()
                          // mes
                          var month = date.getMonth() + 1
                          if (month < 10) {
                            month = pad(month, 2)
                          }
                          month = month.toString()
                          // año
                          var year = date.getFullYear()
                          year = year.toString()
                          year = year.slice(2, 4)
                          // cedula emisor
                          var ced = pad(cedula, 12)
                          // situacion del comprobante
                          var situacion = '1'
                          // codigo de seguridad
                          var codSeg = pad(environment.code, 8)

                          var key = codPais + day + month + year + ced + numeroConsecutivo + situacion + codSeg

                          doc.keyRef = claveNumerica
                          doc.clave = key + '-' + numeroConsecutivo
                          doc.date = fechaEmision
                          doc.nombreEmisor = nombreEmisor
                          doc.emisor = cedulaEmisor
                          doc.tipoEmisor = tipoEmisor
                          doc.receptor = cedulaReceptor
                          doc.tipoReceptor = tipoReceptor
                          doc.typeStatus = Estado
                          doc.consecutive = numeroConsecutivo
                          doc.tipoDocumento = tipo
                          doc.company = cedula
                          doc.message = MensajeEstado
                          doc.sucursal = sucursal
                          doc.terminal = terminal
                          doc.conditionTax = conditionTax
                          doc.amountCredit = amountCredit
                          doc.amountApplicable = amountApplicable
                          doc.codeActivity = codeActivity
                          doc.consecutivoTemporal = consecutivoTemporal
                          doc.total = totalComprobante
                          doc.tax = totalImpuestos
                          await new Promise(resolve => {
                            mongo.save('invoice2pay', doc, () => {
                              resolve()
                            })
                          })
                          doc.atv = 'P'

                          var xml = jsonxml({
                            MensajeReceptor: [
                              { name: 'Clave', text: claveNumerica },
                              { name: 'NumeroCedulaEmisor', text: cedulaEmisor },
                              { name: 'FechaEmisionDoc', text: fechaEmision },
                              { name: 'Mensaje', text: Estado },
                              MensajeEstado !== '' ? { name: 'DetalleMensaje', text: omitirAcentos(MensajeEstado) } : {},
                              totalImpuestos && totalImpuestos !== '' ? { name: 'MontoTotalImpuesto', text: decimal(totalImpuestos.toString(), 5) } : {},
                              codeActivity !== '' ? { name: 'CodigoActividad', text: codeActivity } : {},
                              conditionTax !== '' ? { name: 'CondicionImpuesto', text: conditionTax } : {},
                              amountCredit !== '' ? { name: 'MontoTotalImpuestoAcreditar', text: decimal(amountCredit.toString(), 5) } : {},
                              amountApplicable !== '' ? { name: 'MontoTotalDeGastoAplicable', text: decimal(amountApplicable.toString(), 5) } : {},
                              { name: 'TotalFactura', text: decimal(totalComprobante.toString(), 5) },
                              { name: 'NumeroCedulaReceptor', text: cedulaReceptor },
                              { name: 'NumeroConsecutivoReceptor', text: numeroConsecutivo }
                            ]
                          }, { xmlHeader: true })

                          var x = xml.split('MensajeReceptor', 2)
                          var i = x[0] + 'MensajeReceptor xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/mensajeReceptor"'
                          var completeXml = i + x[1]
                          completeXml = completeXml + 'MensajeReceptor>'

                          fs.writeFile('/tmp/' + claveNumerica + '.xml', completeXml, (err) => {
                            if (err) {
                              send({ error: 'Error', message: 'intentelo de nuevo: ' + err })
                            } else {
                              chilkatExample()
                              firmar()
                            }
                            // firma Chilkat
                            function firmar () {
                              var fileId = environment.description.split('?_id=')[1]
                              fileId = fileId.split('&')[0]
                              req.app.routes.file.get({ _id: fileId, type: 'p12' }, mongo, (result) => {
                                var tmp = '/tmp/' + result.filename
                                var file = fs.createWriteStream(tmp)
                                file.on('finish', function () {
                                  var cert = new chilkat.Cert()
                                  var success = cert.LoadPfxFile(tmp, environment.pin)
                                  if (success !== true) {
                                    send({ error: 'wrongCrypt', message: 'Ocurrio un error al abrir el certificado ' + cert.LastErrorText })
                                    console.log(cert.LastErrorText)
                                    return
                                  }

                                  // Load XML to be signed.
                                  var sbXml = new chilkat.StringBuilder()
                                  success = sbXml.LoadFile('/tmp/' + claveNumerica + '.xml', 'utf-8')
                                  if (success !== true) {
                                    send({ error: 'wrongCrypt', message: 'Ocurrio un error al cargar la factura' })
                                    console.log('Failed to load file.')
                                    return
                                  }

                                  var gen = new chilkat.XmlDSigGen()

                                  // Indicate where the signature is to be placed.
                                  gen.SigLocation = 'MensajeReceptor'
                                  gen.SigId = 'Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0'
                                  gen.SigNamespacePrefix = 'ds'
                                  gen.SignedInfoCanonAlg = 'C14N'
                                  gen.SignedInfoDigestMethod = 'sha256'

                                  var xml = new chilkat.Xml()
                                  xml.Tag = 'xades:QualifyingProperties'
                                  xml.AddAttribute('xmlns:xades', 'http://uri.etsi.org/01903/v1.3.2#')
                                  xml.AddAttribute('Id', 'QualifyingProperties-aa262416-8607-4f02-8897-0a6440a1ae03')
                                  xml.AddAttribute('Target', '#Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0')
                                  xml.UpdateAttrAt('xades:SignedProperties', true, 'Id', 'SignedProperties-Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0')
                                  xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningTime', 'TO BE GENERATED BY CHILKAT')
                                  xml.UpdateAttrAt('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningCertificate|xades:Cert|xades:CertDigest|ds:DigestMethod', true, 'Algorithm', 'http://www.w3.org/2001/04/xmlenc#sha256')
                                  xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningCertificate|xades:Cert|xades:CertDigest|ds:DigestValue', 'TO BE GENERATED BY CHILKAT')
                                  xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningCertificate|xades:Cert|xades:IssuerSerial|ds:X509IssuerName', 'TO BE GENERATED BY CHILKAT')
                                  xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningCertificate|xades:Cert|xades:IssuerSerial|ds:X509SerialNumber', 'TO BE GENERATED BY CHILKAT')
                                  xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SignaturePolicyIdentifier|xades:SignaturePolicyId|xades:SigPolicyId|xades:Identifier', 'https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/mensajeReceptor')
                                  xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SignaturePolicyIdentifier|xades:SignaturePolicyId|xades:SigPolicyId|xades:Description', '')
                                  xml.UpdateAttrAt('xades:SignedProperties|xades:SignedSignatureProperties|xades:SignaturePolicyIdentifier|xades:SignaturePolicyId|xades:SigPolicyHash|ds:DigestMethod', true, 'Algorithm', 'http://www.w3.org/2001/04/xmlenc#sha256')
                                  xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SignaturePolicyIdentifier|xades:SignaturePolicyId|xades:SigPolicyHash|ds:DigestValue', 'NmI5Njk1ZThkNzI0MmIzMGJmZDAyNDc4YjUwNzkzODM2NTBiOWUxNTBkMmI2YjgzYzZjM2I5NTZlNDQ4OWQzMQ==')
                                  xml.UpdateAttrAt('xades:SignedProperties|xades:SignedDataObjectProperties|xades:DataObjectFormat', true, 'ObjectReference', '#Reference-ab26afbd-e2dc-4cb0-886a-ce2a4a118c7f')
                                  xml.UpdateChildContent('xades:SignedProperties|xades:SignedDataObjectProperties|xades:DataObjectFormat|xades:MimeType', 'text/xml')
                                  xml.UpdateChildContent('xades:SignedProperties|xades:SignedDataObjectProperties|xades:DataObjectFormat|xades:Encoding', 'UTF-8')

                                  gen.AddObject('XadesObjectId-674a431e-692c-4e0a-9d82-6275c85c5876', xml.GetXml(), '', '')

                                  var signedPropsId = 'SignedProperties-Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0'
                                  gen.AddObjectRef(signedPropsId, 'sha256', 'EXCL_C14N', '', 'http://uri.etsi.org/01903#SignedProperties')

                                  var keyInfoId = 'KeyInfoId-Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0'
                                  gen.KeyInfoId = keyInfoId
                                  gen.AddSameDocRef(keyInfoId, 'sha256', 'EXCL_C14N', '', '')
                                  gen.SetRefIdAttr(keyInfoId, 'ReferenceKeyInfo')

                                  gen.AddSameDocRef('', 'sha256', 'EXCL_C14N', '', '')
                                  gen.SetRefIdAttr('', 'Reference-ab26afbd-e2dc-4cb0-886a-ce2a4a118c7f')

                                  gen.KeyInfoType = 'X509Data+KeyValue'
                                  gen.X509Type = 'Certificate'
                                  success = gen.SetX509Cert(cert, true)
                                  if (!success) {
                                    send({ error: 'wrongCrypt', message: 'Ocurrio un error al firmar la factura ' + gen.LastErrorText })
                                    console.log(gen.LastErrorText)
                                    return
                                  }

                                  gen.Behaviors = 'IndentedSignature'

                                  success = gen.CreateXmlDSigSb(sbXml)
                                  if (!success) {
                                    send({ error: 'wrongCrypt', message: 'Ocurrio un error al firmar la factura ' + gen.LastErrorText })
                                    console.log(gen.LastErrorText)
                                    return
                                  }
                                  try {
                                    var xmlDoc = sbXml.GetAsString()
                                    var comprobanteXml = base64.encode(utf8.encode(xmlDoc))
                                    doc.voucherXml = comprobanteXml
                                    mongo.save('invoice2pay', doc, (err) => {
                                      if (err) {
                                        send({ error: 'IOError', message: 'Problema al guardar el XML' })
                                      } else {
                                        send({ numericKey: claveNumerica + '-' + numeroConsecutivo })
                                        req.app.routes.backgroundInvoice2pay.sendPending2atv(req)
                                      }
                                    })
                                  } catch (error) {
                                    doc.statusHacienda = 'inconsistente'
                                    delete doc.atv
                                    mongo.save('invoice2pay', doc, () => {
                                      send({ error: 'XMLError', message: 'El XML contiene errores' })
                                    })
                                  }
                                })
                                result.pipe(file)
                              })
                            }
                          })
                        }
                      })
                  }
                })
              } else {
                send({ error: 'wrongData', message: 'El documento no tiene un receptor asociado' })
              }
            }
          })
        } else {
          send({ error: 'wrongData', message: 'XML no enviado en el body' })
        }
      }
    })
  }
  /*
   * params: numericKey,xmlType
   * reply: {xmlText:"<...><..../></...>"} ó {error:"code", message:"message"}
   */
  this.get = function (req, mongo, send) {
    var data = this.parseData(req)
    var collection
    var keys = ''
    if (data.numericKey) {
      keys = { clave: data.numericKey }
    } else if (data.numericConsecutive && data.company) {
      keys = { numeroConsecutivo: data.numericConsecutive, company: data.company }
    }
    switch (data.type) {
    case '01':
    case '04':
    case '08':
    case '09':
      collection = 'invoice'
      break
    case '02':
    case '03':
      collection = 'invoiceCredit'
      break
    case '05':
    case '06':
    case '07':
      collection = 'invoice2pay'
      if (data.numericKey) {
        var keyRef = data.numericKey.split('-')[0]
        keys = { $and: [{ consecutive: data.numericKey.split('-')[1] }, { $or: [keys, { keyRef: keyRef }] }] }
      } else if (data.numericConsecutive && data.company) {
        keys = { consecutive: data.numericConsecutive, company: data.company }
      }
      break
    default:
      send({ xml: '<error><code>wrongData</code><message>Tipo de documento (' + data.type + ') incorrecto, se espera 01,02,03,04,05,06,07,08 o 09</message></error>' })
      return
    }
    if (!keys) {
      send({ error: 'wrongData', message: 'Ocurrio un error, se esperaban más datos' })
    } else {
      mongo.findOne(collection, keys, {}, (err, doc) => {
        var reply
        if (err || !doc) {
          reply = { error: 'wrongData', message: 'Ocurrio un error o el documento no existe, intentelo de nuevo' }
        } else {
          if (data.xmlType === 'D') {
            if (doc.voucherXml) {
              reply = { xml: doc.voucherXml }
            } else {
              reply = { error: 'notSend', message: 'No se ha enviado el documento a hacienda aun' }
            }
          } else if (data.xmlType === 'R') {
            if (doc.responseXml) {
              reply = { xml: doc.responseXml }
            } else {
              reply = { error: 'notQuery', message: 'No se ha consultado el estado aun' }
            }
          } else {
            reply = { error: 'wrongData', message: 'No se especifico el tipo de documento o es incorrecto' }
          }
        }
        if (reply.error) {
          if (reply.error === 'wrongData') {
            send({ xml: '<error><code>wrongData</code><message>' + reply.message + '</message></error>' })
          } else {
            send(reply)
          }
        } else {
          send(reply)
        }
      })
    }
  }

  function pad (n, length) {
    n = n ? n.toString() : ''
    while (n.length < length) { n = '0' + n }
    return n
  }

  function pad2 (number) {
    if (number < 10) {
      return '0' + number
    }
    return number
  }

  function decimal (n, p) {
    var total
    n = n.split('.', 2)
    if (n.length > 1) {
      var dec = pader(n[1], p)
      total = n[0] + '.' + dec
    } else {
      dec = pader('0', p)
      total = n + '.' + dec
    }
    return total
  }

  function pader (n, length) {
    n = n.toString()
    if (n.length < length) {
      while (n.length < length) { n = n + '0' }
    } else if (n.length > length) {
      n = n.substr(0, 5)
    }
    return n
  }

  function omitirAcentos (text) {
    var acentos = 'ÃÀÁÄÂÈÉËÊÌÍÏÎÒÓÖÔÙÚÜÛãàáäâèéëêìíïîòóöôùúüûÑñÇç'
    var original = 'AAAAAEEEEIIIIOOOOUUUUaaaaaeeeeiiiioooouuuunncc'

    for (var i = 0; i < text.length; i++) {
      for (var j = 0; j < acentos.length; j++) {
        text = text.replace(acentos.charAt(j), original.charAt(j))
      }
    }

    return text
  }

  function chilkatExample () {
    var chilkat = require('@chilkat/ck-node14-linux64')
    // After licensing Chilkat, replace the "Anything for 30-day trial" with the purchased unlock code.
    // To verify the purchased unlock code was recognized, examine the contents of the LastErrorText
    var glob = new chilkat.Global()
    var success = glob.UnlockBundle('NFWJAQ.CB1042022_zJkF8zzt3K3e')
    //glob.UnlockBundle('INFOWA.CB1062020_V8xq8zKRD72n')
    if (success !== true) {
      console.log(glob.LastErrorText)
      return
    }
    var status = glob.UnlockStatus
    if (status !== 2) {
      console.log('chilkat: unlocked in trial mode.')
    }
    // The LastErrorText can be examined in the success case to see if it was unlocked in
    // trial more, or with a purchased unlock code.
  }
}
