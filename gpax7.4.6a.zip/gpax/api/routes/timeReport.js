/* exported */
exports.TimeReport = TimeReport
const Entities = require('html-entities').AllHtmlEntities
const entities = new Entities()
var Notification = require('../utils/notification').Notification
var notification = new Notification()
const moment = require('moment')

function TimeReport () {

  this.$unitDependents = async function (mongo, id) {
    if (!id.forEach) {
      id=[id]
    }
    var units = await new Promise(resolve => {
      mongo.find('unit', {}, { parent: 1 }, (err, all) => {
        if (err) console.log(err)
        resolve(all)
      })
    })
    var dependents = []
    id.forEach((i) => {
      dependents.push(i)
      this.$dependents(i, dependents, units)
    })
    return dependents
  }

  this.$dependents = function (parent, dependents,units) {
    units.forEach((u) => {
      if (u.parent && u.parent.equals && u.parent.equals(parent)) {
        dependents.push(u._id)
        this.$dependents(u._id,dependents,units)
      }
    })
  }

  this.get = function (req, mongo, send) {
    var sche = req.query.scheduler
    if (sche) {
      var id = mongo.toId(req.query.id)
      mongo.find('time', req.query.time_id ? { _id: mongo.toId(req.query.time_id) } : { task: id, $and: [{ date: { $gte: new Date(req.query.date) } }, { date: { $lte: new Date(new Date(req.query.date).setHours(23)) } }], user: req.session.context.user },
        {}, {}, async (err, task) => {
          if (err) {
            send()
          } if (task.length <= 0 || (task[0] && task[0].type === 'activity')) {
            mongo.find('time',
              req.query.time_id ? { _id: mongo.toId(req.query.time_id) } : { activity: req.query.activity, $and: [{ date: { $gte: new Date(req.query.date) } }, { date: { $lte: new Date(new Date(req.query.date).setHours(23)) } }], user: req.session.context.user },
              {}, {}, (err, act) => {
                if (err || act.length <= 0) {
                  send()
                } else {
                  act[0].activity = act[0].activity + '_&_' + act[0].plan
                  var date = new Date(act[0].date)
                  var month = date.getMonth()
                  month = parseInt(month) + 1
                  act[0].date = { start: date.getFullYear() + '-' + month + '-' + date.getDate(), end: date.getFullYear() + '-' + month + '-' + date.getDate() }
                  send(act[0])
                }
              })
          } else {
            task[0].task = task[0].task + ',&,' + task[0].project + ',&,' + task[0].plan + ',&,' + task[0].name
            var date = new Date(task[0].date)
            var month = date.getMonth()
            month = parseInt(month) + 1
            task[0].date = date.getFullYear() + '-' + month + '-' + date.getDate()
            mongo.findId('project', task[0].project, (err, pjt) => {
              if (!err && pjt) { task[0].statusProj = pjt.status } else { task[0].statusProj = 'draft' }
              send(task[0])
            })
          }
        })
    } else {
      id = mongo.toId(req.query.id)
      mongo.findOne('time', { _id: id }, {}, async (err, time) => {
        if (err || !time) {
          send()
        } else {
          if (time.type === 'task') {
            if (time.document) {
              time.task_Act_Name = await new Promise(resolve => {
                mongo.findId('task', time.document, (err, task) => {
                  if (task) {
                    resolve(task.text)
                  } else {
                    resolve('')
                  }
                })
              })
            } else time.task_Act_Name = ''
            if (time.project) {
              time.project_plan_Name = await new Promise(resolve => {
                mongo.findId('project', time.project, (err, project) => {
                  if (project) {
                    resolve(project.name)
                  } else {
                    resolve('')
                  }
                })
              })
            } else time.project_plan_Name = ''
          } else {
            if (time.document) {
              time.task_Act_Name = await new Promise(resolve => {
                mongo.findId('activity', time.document, (err, act) => {
                  if (act) {
                    resolve(act.name)
                  } else {
                    resolve('')
                  }
                })
              })
            } else time.task_Act_Name = ''
            if (time.plan) {
              time.project_plan_Name = await new Promise(resolve => {
                mongo.findId('plan', time.plan, (err, plan) => {
                  if (plan) {
                    resolve(plan.name)
                  } else {
                    resolve('')
                  }
                })
              })
            } else time.project_plan_Name = ''
          }
          var date = new Date(time.date)
          var month = date.getMonth()
          month = parseInt(month) + 1
          time.date = date.getFullYear() + '-' + month + '-' + date.getDate()
          if (time.dateEnd) {
            let date = new Date(time.dateEnd)
            let month = date.getMonth()
            month = parseInt(month) + 1
            time.dateEnd = date.getFullYear() + '-' + month + '-' + date.getDate()
          }
          time.web = 1
          let units = await this.$unitDependents(mongo, req.session.context.managerUnits.concat(req.session.context.assistantUnits))
          var users = await new Promise(resolve => {
            mongo.find(
              'unit',
              { _id: { $in: units } },
              { actors: 1 },
              { actors: 1 },
              (err, units) => {
                mongo.find(
                  'project',
                  { actors: { $elemMatch: { user: req.session.context.user, type: 'manager' } }, status: 'processing' },
                  { actors: 1 },
                  { actors: 1 },
                  (err2, projs) => {
                    var users = []
                    if (!err && units.length !== 0) {
                      for (const i in units) {
                        if (units[i].actors) {
                          for (const j in units[i].actors) {
                            users.push(units[i].actors[j].user)
                          }
                        }
                      }
                      for (const i in projs) {
                        if (projs[i].actors) {
                          for (const j in projs[i].actors) {
                            users.push(projs[i].actors[j].user)
                          }
                        }
                      }
                    }
                    resolve(users)
                  }
                )
              }
            )
          })
          let i = users.findIndex((u) => {
            return u.toString() === time.user.toString()
          })
          if (i !== -1) {
            time.reviserUser = true
          }
          send(time)
        }
      })
    }
  }

  this.getForReview = function (req, mongo, send) {
    mongo.findId('time', mongo.toId(req.body._id), (err, doc) => {
      if (err || !doc) {
        send()
      } else {
        if (doc.date) { doc.date = doc.date.toLocaleDateString() }
        send(doc)
      }
    })
  }

  this.delete = function (req, mongo, send) {
    mongo.findId('time', mongo.toId(req.query._id), (err, time) => {
      if (err) {
        send({ error: err })
      } else {
        mongo.deleteOne('time', { _id: mongo.toId(req.query._id) }, (err, result) => {
          if (err) {
            send(err)
          } else {
            req.app.routes.trash.insert(req, mongo, 'time', time, () => {
              send({})
            })
          }
        })
      }
    })
  }

  this.getTemplate = function (req, mongo, send) {
    var id = req.query._id
    mongo.findId('activity', id, async (err, activity) => {
      if (err) throw err
      else {
        if (activity && activity.template) {
          var template = await new Promise(resolve => {
            mongo.findId('template', activity.template, (err, template) => {
              if (err) {
                resolve(false)
              } else {
                resolve(template)
              }
            })
          })
          if (template) {
            send({ fields: template.template, template: template._id })
          } else {
            send(false)
          }
        } else {
          send(false)
        }
      }
    })
  }
  this.show = function (req, mongo, send) {
    var user = req.query.user
    let from = moment(req.query.primer).startOf('day')
    let to = moment(req.query.ultimo).endOf('day')
    var usuario
    if (user || user === '') {
      if (user === '') {
        usuario = user
      } else {
        usuario = mongo.toId(user)
      }
    } else {
      usuario = mongo.toId(req.session.context.user)
    }
    var keys = { $and: [{ date: { $gte: new Date(from._d) } }, { date: { $lte: new Date(to._d) } }], user: usuario }
    if(req.query.date) {
      from = moment(req.query.date).startOf('day')
      to = moment(req.query.date).endOf('day')
      keys = { $and: [{ date: { $gte: new Date(from._d) } }, { date: { $lte: new Date(to._d) } }], user: usuario }
    }
    var pipeline = [
      { $match: keys },
      { $lookup: { from: 'project', localField: 'project', foreignField: '_id', as: 'project' } },
      { $lookup: { from: 'plan', localField: 'plan', foreignField: '_id', as: 'Tplan' } },
      { $lookup: { from: 'activity', localField: 'document', foreignField: '_id', as: 'tAct' } },
      { $lookup: { from: 'task', localField: 'document', foreignField: '_id', as: 'tTask' } },
      {
        $addFields: {
          project: { $arrayElemAt: ['$project.name', 0] },
          planStatus: { $arrayElemAt: ['$Tplan.status', 0] },
          planName: { $arrayElemAt: ['$Tplan.name', 0] },
          taskItem: { $ifNull: [{ $arrayElemAt: ['$tTask', 0] }, ''] },
          activityItem: { $ifNull: [{ $arrayElemAt: ['$tAct', 0] }, ''] }
        }
      },
      {
        $addFields: {
          newName: { $ifNull: ['$taskItem.text', '$activityItem.name'] },
        }
      },
      {
        $project: {
          id: '$_id',
          project: { $ifNull: ['$project', 'Actividad'] },
          plan: '$plan',
          planStatus: { $ifNull: ['$planStatus', '' ] },
          planName: { $ifNull: ['$planName', '' ] },
          task: '$task',
          activity: '$activity',
          name: { $ifNull: ['$newName', { $ifNull: ['$name', '$activity' ] } ] },
          duration: '$duration',
          action: '$action',
          document: { $ifNull: ['$document', ''] },
          day: { $dayOfWeek: { date: '$date', timezone: '-0600' } },
          _id: 0
        }
      },
      {
        $sort: {
          document: 1
        }
      }
    ]
    mongo.aggregate('time', pipeline, {}, (err, times) => {
      if (err) throw err
      var data = times
      var days = ['', 'D', 'L', 'M', 'MC', 'J', 'V', 'S']
      var totals = { totalD: 0, totalL: 0, totalM: 0, totalMC: 0, totalJ: 0, totalV: 0, totalS: 0 }
      times.forEach((t) => {
        var d = days[t.day]
        t[d] = t.duration
        totals['total' + d] += t.duration
      })
      var reply = { totals: totals, times: data }
      send(reply)
    })
  }
  this.getTaskname = function (tasks, id) {
    var r = ''
    for (const i in tasks) {
      var idTask = tasks[i].id.toString ? tasks[i].id.toString() : tasks[i].id
      if (idTask === id) {
        r = tasks[i].text
        break
      }
    }
    return r
  }
  this.save = async function (req, mongo, send) {
    var doc = req.body
    doc.duration = Number(doc.duration)
    doc.cost = (doc.duration / 60) * parseFloat(isNaN(Number(req.session.context.hourCost)) ? 0 : Number(req.session.context.hourCost))
    delete doc.reviserUser
    if (doc.template) {
      doc.template = mongo.toId(doc.template)
    }
    if (!doc.plan) {
      doc.plan=req.session.context.activePlan.id
    }
    doc.date = new Date(doc.date)
    if (req.query.status === 'draft') {
      mongo.save('time', doc, (err, result) => {
        if (err) {
          req.logger.log(err)
        } else {
          send({ id: doc._id })
          notification.send(req, req.session.context.room, 'myScheduler', { id: doc._id }, null, null)
          notification.send(req, req.session.context.room, 'tiemReportView', { id: doc._id }, null, null)
          notification.send(req, req.session.context.room, 'projectDocuments.' + doc.project.toString(), { id: doc._id }, null, null)
        }
      })
    } else {
      if (doc._id) {
        mongo.save('time', doc, (err, result) => {
          if (err) {
            req.logger.log(err)
          } else {
            send({ id: doc._id })
            notification.send(req, req.session.context.room, 'myScheduler', { id: doc._id }, null, null)
            notification.send(req, req.session.context.room, 'tiemReportView', { id: doc._id }, null, null)
            notification.send(req, req.session.context.room, 'projectDocuments.' + doc.project.toString(), { id: doc._id }, null, null)
          }
        })
      } else {
        if (doc.period === '1') {

          var to = moment(new Date(doc.dateEnd))
          var from = moment(new Date(doc.date))
          let days = 0
          let plan
          if (req.session.context.activePlan) {
            plan = await new Promise(resolve => {
              mongo.findId('plan', req.session.context.activePlan.id, (err, plan) => {
                if (!err && plan) {
                  resolve(plan)
                } else {
                  resolve(false)
                }
              })
            })
          } else {
            plan = false
          }
          let holiday = false
          let calendar = ''
          var dateArray = []
          if (plan && plan.calendar) {
            calendar = await new Promise(resolve => {
              mongo.findId('calendar', plan.calendar, (err, calendar) => {
                if (!err && calendar) {
                  resolve(calendar)
                } else {
                  resolve(false)
                }
              })
            })
            if (calendar && calendar.days && calendar.days.length) {
              for (let i in calendar.days) {
                let day = calendar.days[i]
                var currentDate = day.fromAdd
                while (currentDate <= day.toAdd) {
                  dateArray.push(new Date(currentDate))
                  let date = new Date(currentDate)
                  currentDate = new Date(date.setDate(date.getDate() + 1))
                }
              }
            }
          }
          
          do {
            holiday = false
            if (calendar && doc.includeHolidays !== '1') {
              for (let d in dateArray) {
                let x = dateArray[d]
                if (new Date(from._d.setHours(0,0,0)).toString() === x.toString()) {
                  holiday = true
                  break
                }
              }
            } else {
              holiday = false
            }
            if (((calendar && ((from.isoWeekday() === 1 && calendar.monday === '1')
                || (from.isoWeekday() === 2 && calendar.tuesday === '1')
                || (from.isoWeekday() === 3 && calendar.wednesday === '1')
                || (from.isoWeekday() === 4 && calendar.thursday === '1')
                || (from.isoWeekday() === 5 && calendar.friday === '1')
                || (from.isoWeekday() === 6 && calendar.saturday === '1')
                || (from.isoWeekday() === 7 && calendar.sunday === '1')))
                && !holiday) || !calendar) {
              days = days + 1
              doc._id = mongo.newId()
              doc.date = from._d
              doc.dateStart = new Date(doc.date)
              if(calendar) doc.calendar = calendar._id
              doc.status = 'draft'
              doc.user = req.session.context.user
              doc.type = req.query.type
              if (req.query.status) {
                doc.status = req.query.status
              }
              delete doc._idNew
              await new Promise(resolve => {
                mongo.save('time', doc, (err, result) => {
                  resolve()
                })
              })
            }
            from.add(1, 'days')
          } while (to._d.setHours(0, 0, 0) >= from._d.setHours(0, 0, 0))
          send({ id: doc._id })
          if (doc.project) {
            notification.send(req, req.session.context.room, 'myScheduler', { id: doc._id }, null, null)
            notification.send(req, req.session.context.room, 'tiemReportView', { id: doc._id }, null, null)
            notification.send(req, req.session.context.room, 'projectDocuments.' + doc.project.toString(), { id: doc._id }, null, null)
          }
        } else {
          doc._id = req.body._idNew
          doc.status = 'draft'
          doc.user = req.session.context.user
          doc.type = req.query.type
          if (req.query.status) {
            doc.status = req.query.status
          }
          mongo.save('time', doc, (err, result) => {
            if (err) {
              req.logger.log(err)
            } else {
              send({ id: doc._id })
              if (doc.project) {
                notification.send(req, req.session.context.room, 'myScheduler', { id: doc._id }, null, null)
                notification.send(req, req.session.context.room, 'tiemReportView', { id: doc._id }, null, null)
                notification.send(req, req.session.context.room, 'projectDocuments.' + doc.project.toString(), { id: doc._id }, null, null)
              }
            }
          })
        }
      }
    }
  }

  this.pivot = (req, mongo, send) => {
    var pipelinePlan = []
    var pipelineProject = []

    pipelinePlan.push({ $lookup: { from: 'user', localField: 'activities.data.user', foreignField: '_id', as: 'tuser' } })

    // pipelinePlan.push({ $unwind: { path: '$activities.data', preserveNullAndEmptyArrays: true } })

    pipelineProject.push({ $lookup: { from: 'user', localField: 'content.data.owner_id', foreignField: '_id', as: 'tuser' } })

    // pipelineProject.push({ $unwind: { path: '$content.data', preserveNullAndEmptyArrays: true } })

    pipelineProject.push({ $match: { status: { $ne: 'draft' } } })
    mongo.toHash('plan', {}, { name: 1 }, (err, pls) => {
      if (err) throw err
      mongo.aggregate('plan', pipelinePlan, { allowDiskUse: true }, (err, plans) => {
        if (err) throw err
        mongo.aggregate('project', pipelineProject, { allowDiskUse: true }, (err, projects) => {
          if (err) throw err
          mongo.find('time', {}, { }, async (err, times) => {
            if (err) throw err
            var activities = []
            var tasks = []
            for (const i in plans) {
              const plan = plans[i]
              if (plan.activities && plan.activities.data) {
                for (const p in plan.activities.data) {
                  const user = plan.tuser.findIndex((x) => {
                    return x._id.toString() === plan.activities.data[p].user.toString()
                  })
                  if (plan.tuser[user]) {
                    activities.push(
                      {
                        planId: plan._id,
                        plan: plan.name,
                        proyecto: 'Actividades',
                        tarea: plan.activities.activities[plan.activities.data[p].activity],
                        usuario: plan.tuser[user].name,
                        duracionPlaneada: plan.activities.data[p].value,
                        duration: 0
                      }
                    )
                  }
                }
              }
            }

            for (const i in projects) {
              const project = projects[i]
              for (const c in project.content.data) {
                if (project.content && project.content.data && (project.content.data[c].owner_id && project.content.data[c].owner_id !== '')) {
                  const user = project.tuser.findIndex((x) => {
                    return x._id.toString() === project.content.data[c].owner_id.toString()
                  })
                  if (user !== -1) {
                    tasks.push(
                      {
                        id: project.content.data[c].id,
                        plan: pls[project.plan.toString()].name,
                        proyecto: project.name,
                        tarea: project.content.data[c].text,
                        usuario: project.tuser[user].name,
                        duracionPlaneada: project.content.data[c].duration,
                        duration: 0
                      }
                    )
                  }
                }
              }
            }
            for (const i in times) {
              const time = times[i]
              if (time.type === 'task') {
                const i = tasks.findIndex((x) => {
                  return x.id.toString() === time.task.toString()
                })
                if (i !== -1) {
                  tasks[i].duration = Number(tasks[i].duration) + Number(time.duration)
                }
              } else if (time.type === 'activity') {
                const i = activities.findIndex((x) => {
                  return x.actividad === time.activity && x.planId.toString() === time.plan.toString()
                })
                if (i !== -1) {
                  activities[i].duration = Number(activities[i].duration) + Number(time.duration)
                }
              }
            }
            var data = []
            data = data.concat(activities)
            data = data.concat(tasks)
            data.forEach(x => {
              delete x.planId
            })
            send(data)
          })
        })
      })
    })
  }

  this.ActivePlans = function (req, mongo, send) {
    mongo.find('plan', { status: { $ne: 'draft' } }, { _id: 1, name: 1 }, { _id: -1 }, (err, plans) => {
      var plan
      var pls = []
      if (err || !plans.length) {
        send([])
      } else {
        for (const i in plans) {
          plan = plans[i]
          pls.push({ id: plan._id, value: plan.name })
        }
        send(pls)
      }
    })
  }

  this.adminReports = function (req, mongo, send) {
    var doc = req.query
    mongo.find('time', { $and: [{ date: { $gte: new Date(doc.primer) } }, { date: { $lte: new Date(doc.ultimo) } }], user: mongo.toId(doc.user) }, {}, {}, async (err, times) => {
      if (err) {
        send({ error: err })
      } else {
        for (const i in times) {
          let comment = '<p>'+ (doc.action === 'lock' ? ' Aprobó el reporte' : ' Canceló la aprobación del reporte') + '</p>'
          var data = {
            collection: "timeReport",
            comment: comment,
            dateTime: new Date(),
            document: times[i]._id,
            documentType: "timeReport",
            involved: [times[i].user],
            unread: [times[i].user],
            user: req.session.context.user
          }
          await new Promise(resolve => {
            mongo.save('time', { _id: times[i]._id, action: doc.action }, (err, result) => {
              if (err) {
                resolve()
              } else {
                req.app.routes.comment.save(req, mongo, () => {
                  resolve()
                }, data)
              }
            })
          })
        }
        send()
      }
    })
  }

  this.approveTime = async function (req, mongo, send) {
    let comment = '<p>'+ (req.body.action === 'lock' ? ' Aprobó el reporte' : ' Cancelo la aprobación del reporte') + '</p>'
    var data = {
      collection: "timeReport",
      comment: comment,
      dateTime: new Date(),
      document: req.body._id,
      documentType: "timeReport",
      involved: [req.body.user],
      unread: [req.body.user],
      user: req.session.context.user
    }
    await new Promise(resolve => {
      mongo.save('time', { _id: mongo.toId(req.body._id), action: req.body.action }, (err, result) => {
        if (err) {
          resolve()
        } else {
          req.app.routes.comment.save(req, mongo, () => {
            resolve()
          }, data)
        }
      })
    })
    send()
  }

  this.$keys = async function (req, mongo,) {
    var keys
    var myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits)
    var myAndDependentUnits = req.session.context.dependentUnits.concat(myUnits)
    keys = {unit: myAndDependentUnits}
    return keys
  }
}
