/* exported */
var tags = require('../utils/tags').tags
var dateformat = require('dateformat')
exports.Entry = Entry
var Notification = require('../utils/notification').Notification
var notification = new Notification()

function Entry () {
  this.get = function (req, mongo, send) {
    var doc = {}
    var users = []

    function getResponseAuthors (responses, i) {
      if (responses && responses.length > i) {
        users.push(responses[i].user)
        getResponseAuthors(responses, i + 1)
      }
    }
    var form = function () {
      var userName = ''
      if (doc.user) { users.push(doc.user) }
      users.push(req.session.context.user)
      getResponseAuthors(doc.responses, 0)
      mongo.toHash('user', { _id: { $in: users } }, { _id: 1, name: 1 }, {}, (err, user) => {
        if (err) {
          send({ error: err })
        } else {
          userName = user[users[0].toString()].name
          var id = user[users[0].toString()]._id

          mongo.findId('entry', doc._id, function (err, entry) {
            if (err) throw err
            if (!entry) {
              doc.contextName = user[req.session.context.user.toString()].name
              doc.contextId = req.session.context.user.toString()
              doc.userName = userName
              doc.user = id
              send(doc)
            } else {
              doc.userName = user[doc.user.toString()].name
              doc.contextName = user[req.session.context.user.toString()] ? user[req.session.context.user.toString()].name : ''
              doc.contextId = req.session.context.user.toString()
              doc.dateTime = dateformat(new Date(doc.dateTime), 'yyyy/mm/dd HH:MM:ss')
              if (doc.responses) {
                for (const i in doc.responses) {
                  doc.responses[i].userName = user[doc.responses[i].user.toString()].name
                }
              }
              send(doc)
            }
            /* else {
             mongo.toHash("product", { _id: { $in: [doc.product] } }, { _id: 1, name: 1 }, (err, prod) => {
               if (err) {
                 send({ error: err });
               } else {
                 var prodName = doc.product ? prod[doc.product.toString()].name : "";

                 var body = "";
                 body += "<div>";
                 body += " <div class=\"right-label\" >" + doc.status + " - " + doc.priority + " </div>";
                 body += " </br>";
                 body += " <div class=\"title\">";
                 body += "  <div style=\"margin-left:30px;  margin-top:20px; text-align: left;\"><img src=\"api/user.image?size=40&_id=" + id + "\" class = \"photo\" title=\"" + userName + "\"/>" + prodName + " : " + doc.name + "</div>";
                 body += "  <div class=\"label\" >" + tags.util.dateTime2human(doc.dateTime, tags) + " - " + doc.type;
                 if (doc.confidential) {
                   body += " <span class=\"highlight\">Privado</span>";
                 }
                 body += "  </div>";
                 body += " </div>";
                 body += " <br/>";
                 body += " <hr>";
                 body += " <div class=\"description\" >" + doc.description + "</div>";
                 body += " <br/>";
                 body += " <div class=\"description\" >" + loadResponses(doc.responses, user) + "</div>";
                 body += "</div>";

                 send({ body: body });
               }
             });
           } */
          })
        }
      })
    }
    if (req.query._id) {
      mongo.findId('entry', req.query._id, (err, entry) => {
        if (!err) {
          doc = entry
          form()
        } else {
          send()
        }
      })
    } else {
      doc = { _id: mongo.newId() }
      form()
    }
  }

  this.set = function (req, mongo, send) {
    var doc = {}
    for (const i in req.query) {
      if (i.indexOf('dhx') === -1) {
        if (i.indexOf('confidential') !== -1) {
          /* doc[i] = eval(req.query[i])
        } else { */
          doc[i] = req.query[i]
        }
      }
    }
    mongo.save('entry', doc, (err) => {
      if (!err) {
        send({
          message: tags.savedChanges
        })
      } else {
        send({ error: tags.savingProblema })
      }
    })
  }

  this.list = function (req, mongo, send) {
    var reply = []
    var keys = {
      $or: [
        { user: req.session.context.user }
      ]
    }

    mongo.toHash('user', {}, (err, users) => {
      if (err) throw err
      mongo.find('client', { users: { $elemMatch: { $eq: req.session.context.user } } }, {}, {}, (err, clients) => {
        if (err) throw err
        if (req.query.all) {
          if (req.session.context.licensedUser) { keys = {} } else {
            const idscli = []
            for (const i in clients) {
              idscli.push(clients[i]._id)
            }
            keys = { $or: [{ client: { $in: idscli } }, { user: req.session.context.user }, { confidential: false }] }
          }
        }
        mongo.find('entry', keys, { _id: 1, name: 1, status: 1, dateTime: 1, confidential: 1, user: 1, priority: 1 }, { _id: -1 }, (err, entries) => {
          if (!err && entries) {
            entries.forEach((entry) => {
              if (!entry.name) {
                entry.text = ''
              } else {
                entry.text = entry.name
              }
              switch (entry.priority) {
              case 'low':
                entry.color = '#12CB00'
                break
              case 'medium':
                entry.color = '#FE6603'
                break
              case 'high':
                entry.color = '#F20404'
                break
              }
              entry.id = entry._id.toString()
              entry.dateTime = dateformat(new Date(entry.dateTime), 'yyyy/mm/dd HH:MM:ss')
              entry.userName = users[entry.user.toString()] ? users[entry.user.toString()].name : ''
              // client.id = client._id.toString();
              var suma3mes = 90 * 24 * 60 * 60 * 1000
              if ((entry.status !== 'done' && entry.status !== 'discarded') || (
                entry._id.getTimestamp().setHours(0, 0, 0, 0, 0) >= new Date().setHours(0, 0, 0, 0, 0) &&
                entry._id.getTimestamp().setHours(0, 0, 0, 0, 0) < new Date().setHours(0, 0, 0, 0, 0) + suma3mes)) {
                reply.push(entry)
              }
            })
            send(reply)
          }
        })
      })
    })
  }

  this.kanban = function (req, mongo, send) {
    const keys = {
      $or: [
        { actors: { $elemMatch: { user: req.session.context.user, path: { $ne: 'hidden' } } } },
        {
          $and: [
            { actors: { $elemMatch: { unit: { $in: req.session.context.assistantUnits }, path: { $ne: 'hidden' } } } }
          ]
        }
      ]
    }
    mongo.find('attached', keys, (err, attacheds) => {
      if (err) throw err
      mongo.toHash('user', {}, (err, users) => {
        if (err) throw err
        const data = []
        for (const i in attacheds) {
          var doc = attacheds[i]
          const actor = { user: doc.responsible ? doc.responsible.split('&')[0] : '' }
          let deadline
          if (doc.dates) {
            doc.dates.findIndex((x) => {
              if (x.type === 'deadline') deadline = x.value
            })
          }
          if (deadline &&
            doc.status === tags.processing &&
            deadline.setHours(0, 0, 0, 0, 0) < new Date().setHours(0, 0, 0, 0, 0) &&
            deadline.setHours(0, 0, 0, 0, 0) !== new Date().setHours(0, 0, 0, 0, 0)) {
            data.push({
              id: doc._id.toString(),
              status: 'expired',
              text: doc.name,
              userId: actor.user.toString(),
              userName: users[actor.user.toString()] ? users[actor.user.toString()].name : '',
              color: 'red'
            })
          }
          var suma7dias = 7 * 24 * 60 * 60 * 1000
          if (deadline &&
            doc.status === tags.processing &&
            deadline.setHours(0, 0, 0, 0, 0) > new Date().setHours(0, 0, 0, 0, 0) &&
            deadline.setHours(0, 0, 0, 0, 0) < new Date().setHours(0, 0, 0, 0, 0) + suma7dias) {
            data.push({
              id: doc._id.toString(),
              status: 'pending1week',
              text: doc.name,
              userId: actor.user.toString(),
              userName: users[actor.user.toString()] ? users[actor.user.toString()].name : '',
              color: 'green'
            })
          }
          var suma1mes = 30 * 24 * 60 * 60 * 1000
          if (deadline &&
            doc.status === tags.processing &&
            deadline.setHours(0, 0, 0, 0, 0) > new Date().setHours(0, 0, 0, 0, 0) &&
            deadline.setHours(0, 0, 0, 0, 0) < new Date().setHours(0, 0, 0, 0, 0) + suma1mes) {
            data.push({
              id: doc._id.toString(),
              status: 'pending1month',
              text: doc.name,
              userId: actor.user.toString(),
              userName: users[actor.user.toString()] ? users[actor.user.toString()].name : '',
              color: 'green'
            })
          }
          if (doc.status === 'answered') {
            data.push({
              id: doc._id.toString(),
              status: 'answered',
              text: doc.name,
              userId: actor.user.toString(),
              userName: users[actor.user.toString()] ? users[actor.user.toString()].name : '',
              color: '#4ACFCB'
            })
          }
          if (doc.responsible && doc.status === 'processing' && req.session.context.user.toString() === doc.responsible.split('&')[0]) {
            data.push({
              id: doc._id.toString(),
              status: 'toAnswered',
              text: doc.name,
              userId: actor.user.toString(),
              userName: users[actor.user.toString()] ? users[actor.user.toString()].name : '',
              color: '#4ACFCB'
            })
          }
        }

        send(data)
      })
    })
  }

  this.save = function (req, mongo, send) {
    var doc = req.body
    delete doc.userName
    delete doc.contextName
    delete doc.contextId
    doc.confidential = doc.confidential * 1 !== 0

    if (doc._id && doc.user) {
      /* if (!doc.dateTime) {
        doc.dateTime = new Date();
      } */
      if (!doc.status) {
        doc.status = 'recorded'
      }
      if (doc.descriptionResponse) {
        if (!doc.responses) { doc.responses = [] }
        const response = {
          user: req.session.context.user,
          dateTime: new Date(),
          description: doc.descriptionResponse
        }
        doc.responses.push(response)
        delete doc.descriptionResponse
      }
      mongo.find('client', { users: req.session.context.user }, (err, client) => {
        if (!err && client && client.length > 0) {
          doc.client = client[0]._id
        }
        mongo.save('entry', doc, (err) => {
          if (!err) {
            send({ responses: doc.responses, status: doc.status })
            notification.send(req, req.session.context.room, 'dt_entries', { id: doc._id })
          } else {
            send({ error: tags.savingProblema })
          }
        })
      })
    }
  }
}
