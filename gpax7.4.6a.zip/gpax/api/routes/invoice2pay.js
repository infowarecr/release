var tags = require('../utils/tags').tags
var jsonxml = require('jsontoxml')
var fs = require('fs')
var xml2js = require('xml2js')
var parser = new xml2js.Parser()
var request = require('request')
var base64 = require('base-64')
var dirname = __dirname.substring(0, __dirname.lastIndexOf('/'))
dirname = dirname.substring(0, dirname.lastIndexOf('/'))
var Notification = require('../utils/notification').Notification
var notification = new Notification()

exports.Invoice2pay = Invoice2pay

function Invoice2pay () {
  this.get = function (req, mongo, send) {
    var doc = {}

    if (req.query._id) {
      mongo.findId('invoice2pay', req.query._id, (err, doc) => {
        if (err && !doc) doc = {}
        send([doc])
      })
    } else {
      mongo.findN('invoice2pay', 0, 1, { company: req.query.company }, { number: 1, _id: 1 }, { _id: -1 }, (err, msjs) => {
        if (err && !msjs) msjs = [{}]
        mongo.findOne('company', { idNum: req.query.company }, (err, company) => {
          if (err) {
            send({ error: err })
          } else {
            doc = { _id: mongo.newId() }

            if (!doc.number) {
              var num = '0000000001'
              if (msjs[0] && msjs[0].number.slice(10, 20)) {
                num = msjs[0].number.slice(10, 20)
                var n = parseInt(num, 10)
                n = n + 1
                num = n.toString()
                num = pad(num, 10)
              }
              // Information for Electronic invoice
              // local o establecimiento
              var casaMatriz = company.establishment
              // Terminal o punto de venta
              var terminal = company.station
              // tipo de comprobante
              var tipComp = req.query.msj
              // numero consecutivo
              doc.number = casaMatriz + terminal + tipComp + num

              // company
              doc.company = req.query.company

              switch (req.query.msj) {
              case '05':
                doc.message = '1'
                break
              case '06':
                doc.message = '2'
                break
              case '07':
                doc.message = '3'
                break
              }
            }
            doc.idTypeReceiver = company.idType
            doc.idNumReceiver = company.idNum
            send(doc)
          }
        })
      })
    }
  }

  this.save = function (req, mongo, send) {
    var doc = req.body

    var dt = new Date()
    var time = dt.toTimeString()
    dt = dt.toISOString()
    dt = dt.split('T', 1)
    dt = dt + 'T' + time
    doc.date = dt.split(' ', 1) + '-06:00'
    doc.user = req.session.context.user

    mongo.save('invoice2pay', doc, (err, result) => {
      if (err) {
        req.logger.log(err)
      } else {
        send({ id: doc._id })
        notification.send(req, req.session.context.room, 'dt_receiverMessage', { id: doc._id })
      }
    })
  }

  this.count = async function (req, mongo, send) {
    var keys = {}
    if (!req.session.context.createUsers) {
      var compaResult = await new Promise((resolve, reject) => {
        mongo.find('company', { users: { $in: [req.session.context.user] } }, { _id: 0, idNum: 1 }, (err, coms) => {
          if (err) reject(err)
          else {
            var arrayC = []
            for (const i in coms) {
              arrayC.push(coms[i].idNum)
            }
            resolve(arrayC)
          }
        })
      }).catch((err) => console.log(err))
      keys = { $or: [{ company: { $in: compaResult } }, { user: req.session.context.user }] }
    }
    mongo.count('invoice2pay', keys, (err, count) => {
      if (err) {
        req.statusCode = 404
        send()
      } else {
        send({ count: count })
      }
    })
  }
  this.pending = async function (req, mongo, send) {
    var keys = { statusHacienda: { $nin: ['rechazado', 'inconsistente', 'aceptado'] } }
    if (!req.session.context.createUsers) {
      var compaResult = await new Promise((resolve, reject) => {
        mongo.find('company', { users: { $in: [req.session.context.user] } }, { _id: 0, idNum: 1 }, (err, coms) => {
          if (err) reject(err)
          else {
            var arrayC = []
            for (const i in coms) {
              arrayC.push(coms[i].idNum)
            }
            resolve(arrayC)
          }
        })
      }).catch((err) => console.log(err))
      keys = { $and: [{ company: { $in: compaResult } }, { statusHacienda: { $nin: ['rechazado', 'inconsistente', 'aceptado'] } }] }
    }
    mongo.count('invoice2pay', keys, (err, count) => {
      if (err) {
        req.statusCode = 404
        send()
      } else {
        send({ count: count })
      }
    })
  }

  this.list = async function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    var keys={}
    /*if (req.query.ebill) {
      keys = {}
    } else {
      keys = { user: req.session.context.user }
    }*/
    const query = {}
    if (req.query.filter) {
      for (const name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          if (name === 'number') {
            query.consecutive = new RegExp(req.query.filter[name], 'i')
          } else if (name === 'statusHacienda') {
            if (req.query.filter[name] === 'sin verificar') { query.statusHacienda = { $exists: 0 } } else { query.statusHacienda = req.query.filter[name] }
          } else if (name === 'status') {
            if (req.query.filter[name] === 'no enviada') { query.responseXml = { $exists: 0 } } else { query.responseXml = { $exists: 1 } }
          } else if (name === 'company' || name === 'companyName') {
            query.company = req.query.filter[name]
          } else if (name === 'currency') {
            query.Moneda = req.query.filter[name]
          } else if (name === 'date') {
            query.fechaDocumento = new RegExp(req.query.filter[name], 'i')
          } else if (name === 'nombreEmisor') {
            query.nombreEmisor = new RegExp(req.query.filter[name], 'i')
          } else {
            query[name] = req.query.filter[name].indexOf(',') !== -1 ? { $in: req.query.filter[name].split(',') } : new RegExp(req.query.filter[name].replace(/ /g, '.*'), 'i')
          }
        }
      }
      keys = { $and: [keys, query] }
    }
    if (!req.session.context.createUsers) {
      var compaResult = await new Promise((resolve, reject) => {
        mongo.find('company', { users: { $in: [req.session.context.user] } }, { _id: 0, idNum: 1 }, (err, coms) => {
          if (err) reject(err)
          else {
            var arrayC = []
            for (const i in coms) {
              arrayC.push(coms[i].idNum)
            }
            resolve(arrayC)
          }
        })
      }).catch((err) => console.log(err))
      keys = {
        $and: [
          { $or: [{ company: { $in: compaResult } }, { user: req.session.context.user }] },
          query
        ]
      }
    }
    var pipeline = []
    pipeline.push({ $match: keys })
    pipeline.push({ $sort: { _id: -1 } })
    pipeline.push({ $skip: skip })
    pipeline.push({ $limit: limit })
    mongo.aggregate('invoice2pay', pipeline, { allowDiskUse: true }, (err, Message) => {
      if (err) {
        send({ error: err })
      } else {
        mongo.find('company', {}, {}, {}, async (err, companies) => {
          if (err) {
            send({ error: err })
          } else {
            for (const i in Message) {
              Message[i].id = Message[i]._id
              Message[i].date = tags.util.date2str(Message[i].date, 'yyyy-mm-dd', tags)
              Message[i].key = Message[i].clave ? Message[i].clave : Message[i].key ? Message[i].key : ''
              Message[i].emisor = Message[i].emisor ? Message[i].emisor : Message[i].idNumEmisor ? Message[i].idNumEmisor : ''
              Message[i].nombreEmisor = Message[i].nombreEmisor || ''
              Message[i].number = Message[i].consecutive ? Message[i].consecutive : Message[i].number ? Message[i].number : ''
              if (Message[i].total) {
                Message[i].total = arreglar(Message[i].total)
              }
              if (Message[i].value) {
                Message[i].value = parseInt(Message[i].value).toFixed(2)
                Message[i].total = arreglar(Message[i].value)
              }
              if (Message[i].tax) {
                Message[i].tax = parseInt(Message[i].tax).toFixed(2)
                Message[i].tax = arreglar(Message[i].tax)
              }
              if (Message[i].responseXml) { Message[i].responseXml = base64.decode(Message[i].responseXml) }
              if (Message[i].voucherXml) { Message[i].voucherXml = base64.decode(Message[i].voucherXml) }
              if (!Message[i].statusHacienda && Message[i].responseXml) { Message[i].statusHacienda = 'aceptado' } else if (!Message[i].statusHacienda && !Message[i].responseXml) { Message[i].statusHacienda = 'sin verificar' }
              var recordDate = tags.util.date2str(Message[i]._id.getTimestamp(), 'DD-MM-YYYY', tags)
              Message[i].companyName = await new Promise(resolve => {
                var name = ''
                for (var c in companies) {
                  if (companies[c].idNum === Message[i].company) {
                    name = companies[c].name
                    break
                  }
                }
                resolve(name)
              })
              Message[i].recordDate = recordDate
              Message[i].processDate = Message[i].processDate ? tags.util.date2str(Message[i].processDate, 'DD-MM-YYYY', tags) : recordDate

              reply.data.push(Message[i])
            }
            if (skip) {
              send(reply)
            } else {
              mongo.count('invoice2pay', keys, (err, count) => {
                if (err) {
                  send(err)
                } else {
                  reply.total_count = count
                  send(reply)
                }
              })
            }
          }
        })
      }
    })
  }

  this.xml = function (req, mongo, send) {
    var chilkat = require('@chilkat/ck-node14-linux64')
    var body = req.query
    body._id = mongo.toId(body._id)
    mongo.findId('invoice2pay', body._id, (err, invoice) => {
      if (err && !invoice) invoice = {}
      mongo.findOne('company', { idNum: invoice.company }, (err, environment) => {
        if (err && !environment) environment = {}
        function decimal (n) {
          var total
          n = n.split('.', 2)
          if (n.length > 1) {
            var dec = pader(n[1], 5)
            total = n[0] + '.' + dec
          } else {
            total = n + '.00000'
          }
          return total
        }
        // detalle fact
        var xml = jsonxml({
          MensajeReceptor: [
            { name: 'Clave', text: invoice.key },
            { name: 'NumeroCedulaEmisor', text: invoice.idNumEmisor },
            { name: 'FechaEmisionDoc', text: invoice.date },
            { name: 'Mensaje', text: invoice.message },
            invoice.detailMessage ? { name: 'DetalleMensaje', text: omitirAcentos(invoice.detailMessage) } : {},
            invoice.tax && invoice.tax !== '' ? { name: 'MontoTotalImpuesto', text: decimal(invoice.tax) } : {},
            invoice.codeActivity && invoice.codeActivity !== '' ? { name: 'CodigoActividad', text: invoice.codeActivity } : {},
            invoice.conditionTax && invoice.conditionTax !== '' ? { name: 'CondicionImpuesto', text: invoice.conditionTax } : {},
            invoice.amountCredit && invoice.amountCredit !== '' ? { name: 'MontoTotalImpuestoAcreditar', text: decimal(invoice.amountCredit) } : {},
            invoice.amountApplicable && invoice.amountApplicable !== '' ? { name: 'MontoTotalDeGastoAplicable', text: decimal(invoice.amountApplicable) } : {},
            { name: 'TotalFactura', text: decimal(invoice.value) },
            { name: 'NumeroCedulaReceptor', text: invoice.idNumReceiver },
            { name: 'NumeroConsecutivoReceptor', text: invoice.number }
          ]
        }, { xmlHeader: true })

        var x = xml.split('MensajeReceptor', 2)
        var i = x[0] + 'MensajeReceptor xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/mensajeReceptor"'
        var l = i + x[1]
        l = l + 'MensajeReceptor>'

        fs.writeFile('/tmp/' + invoice.key + '.xml', l, (err, result) => {
          if (err) {
            console.log(err)
          }
          chilkatExample()
          firmar()
          // FIRMAR
          function firmar () {
            var fileId = environment.description.split('?_id=')[1]
            fileId = fileId.split('&')[0]
            req.app.routes.file.get({ _id: fileId, type: 'p12' }, mongo, (result) => {
              var tmp = '/tmp/' + result.filename
              var file = fs.createWriteStream(tmp)
              file.on('finish', async function () {
                var cert = new chilkat.Cert()
                var success = cert.LoadPfxFile(tmp, environment.pin)
                if (success !== true) {
                  send({ error: 'wrongCrypt', message: 'Ocurrio un error al abrir el certificado ' + cert.LastErrorText })
                  console.log(cert.LastErrorText)
                  return
                }

                // Load XML to be signed.
                var sbXml = new chilkat.StringBuilder()
                success = sbXml.LoadFile('/tmp/' + invoice.key + '.xml', 'utf-8')
                if (success !== true) {
                  send({ error: 'wrongCrypt', message: 'Ocurrio un error al cargar la factura' })
                  console.log('Failed to load file.')
                  return
                }

                var gen = new chilkat.XmlDSigGen()

                // Indicate where the signature is to be placed.
                gen.SigLocation = 'MensajeReceptor'
                gen.SigId = 'Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0'
                gen.SigNamespacePrefix = 'ds'
                gen.SignedInfoCanonAlg = 'C14N'
                gen.SignedInfoDigestMethod = 'sha256'

                var xml = new chilkat.Xml()
                var cdn = 'mensajeReceptor'
                xml.Tag = 'xades:QualifyingProperties'
                xml.AddAttribute('xmlns:xades', 'http://uri.etsi.org/01903/v1.3.2#')
                xml.AddAttribute('Id', 'QualifyingProperties-aa262416-8607-4f02-8897-0a6440a1ae03')
                xml.AddAttribute('Target', '#Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0')
                xml.UpdateAttrAt('xades:SignedProperties', true, 'Id', 'SignedProperties-Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0')
                xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningTime', 'TO BE GENERATED BY CHILKAT')
                xml.UpdateAttrAt('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningCertificate|xades:Cert|xades:CertDigest|ds:DigestMethod', true, 'Algorithm', 'http://www.w3.org/2001/04/xmlenc#sha256')
                xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningCertificate|xades:Cert|xades:CertDigest|ds:DigestValue', 'TO BE GENERATED BY CHILKAT')
                xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningCertificate|xades:Cert|xades:IssuerSerial|ds:X509IssuerName', 'TO BE GENERATED BY CHILKAT')
                xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningCertificate|xades:Cert|xades:IssuerSerial|ds:X509SerialNumber', 'TO BE GENERATED BY CHILKAT')
                xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SignaturePolicyIdentifier|xades:SignaturePolicyId|xades:SigPolicyId|xades:Identifier', 'https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/' + cdn)
                xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SignaturePolicyIdentifier|xades:SignaturePolicyId|xades:SigPolicyId|xades:Description', '')
                xml.UpdateAttrAt('xades:SignedProperties|xades:SignedSignatureProperties|xades:SignaturePolicyIdentifier|xades:SignaturePolicyId|xades:SigPolicyHash|ds:DigestMethod', true, 'Algorithm', 'http://www.w3.org/2001/04/xmlenc#sha256')
                xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SignaturePolicyIdentifier|xades:SignaturePolicyId|xades:SigPolicyHash|ds:DigestValue', 'NmI5Njk1ZThkNzI0MmIzMGJmZDAyNDc4YjUwNzkzODM2NTBiOWUxNTBkMmI2YjgzYzZjM2I5NTZlNDQ4OWQzMQ==')
                xml.UpdateAttrAt('xades:SignedProperties|xades:SignedDataObjectProperties|xades:DataObjectFormat', true, 'ObjectReference', '#Reference-ab26afbd-e2dc-4cb0-886a-ce2a4a118c7f')
                xml.UpdateChildContent('xades:SignedProperties|xades:SignedDataObjectProperties|xades:DataObjectFormat|xades:MimeType', 'text/xml')
                xml.UpdateChildContent('xades:SignedProperties|xades:SignedDataObjectProperties|xades:DataObjectFormat|xades:Encoding', 'UTF-8')

                gen.AddObject('XadesObjectId-674a431e-692c-4e0a-9d82-6275c85c5876', xml.GetXml(), '', '')

                var signedPropsId = 'SignedProperties-Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0'
                gen.AddObjectRef(signedPropsId, 'sha256', 'EXCL_C14N', '', 'http://uri.etsi.org/01903#SignedProperties')

                var keyInfoId = 'KeyInfoId-Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0'
                gen.KeyInfoId = keyInfoId
                gen.AddSameDocRef(keyInfoId, 'sha256', 'EXCL_C14N', '', '')
                gen.SetRefIdAttr(keyInfoId, 'ReferenceKeyInfo')

                gen.AddSameDocRef('', 'sha256', 'EXCL_C14N', '', '')
                gen.SetRefIdAttr('', 'Reference-ab26afbd-e2dc-4cb0-886a-ce2a4a118c7f')

                gen.KeyInfoType = 'X509Data+KeyValue'
                gen.X509Type = 'Certificate'
                success = gen.SetX509Cert(cert, true)
                if (!success) {
                  send({ error: 'wrongCrypt', message: 'Ocurrio un error al firmar la factura ' + gen.LastErrorText })
                  console.log(gen.LastErrorText)
                  return
                }

                gen.Behaviors = 'IndentedSignature'

                success = gen.CreateXmlDSigSb(sbXml)
                if (!success) {
                  send({ error: 'wrongCrypt', message: 'Ocurrio un error al firmar la factura ' + gen.LastErrorText })
                  console.log(gen.LastErrorText)
                  return
                }
                try {
                  var xmlDoc = sbXml.GetAsString()
                  var comprobante = base64.encode(xmlDoc)
                  await new Promise(resolve => {
                    mongo.save('invoice2pay', { _id: body._id, voucherXml: comprobante }, () => {
                      resolve()
                    })
                  })
                  sender(xmlDoc, comprobante)
                } catch (error) {
                  send({ message: error.message })
                }
              })
              result.pipe(file)
            })
          }

          function sender (xmlStr, comprobanteXml) {
            request.post({
              url: environment.idpUrl,
              form: {
                grant_type: 'password',
                client_id: environment.clientId,
                username: environment.user,
                password: environment.password,
                client_secret: '',
                scope: ''
              }
            },
            function (err, httpResponse, token) {
              if (err) {
                console.log(err)
              } else {
                if (httpResponse.statusCode === 200) {
                  var tokens = JSON.parse(token)
                  parser.parseString(xmlStr, function (err, result) {
                    if (err && !result) result = {}
                    var formData = {}

                    formData = {
                      clave: result.MensajeReceptor.Clave[0],
                      fecha: result.MensajeReceptor.FechaEmisionDoc[0],
                      emisor: {
                        tipoIdentificacion: invoice.idTypeEmisor,
                        numeroIdentificacion: result.MensajeReceptor.NumeroCedulaEmisor[0]
                      },
                      receptor: {
                        tipoIdentificacion: invoice.idTypeReceiver,
                        numeroIdentificacion: result.MensajeReceptor.NumeroCedulaReceptor[0]
                      },
                      consecutivoReceptor: result.MensajeReceptor.NumeroConsecutivoReceptor[0],
                      comprobanteXml: comprobanteXml
                    }

                    var options = {
                      url: environment.url + 'recepcion',
                      json: true,
                      body: formData,
                      headers: {
                        Authorization: 'bearer ' + tokens.access_token,
                        'content-type': 'application/javascript'
                      }
                    }
                    request.post(options, function (err, response, out) {
                      if (response.statusCode === 202) {
                        // console.log(response.headers.location)
                        send({ message: 'Enviado' })
                        mongo.save('invoice2pay', { _id: body._id, voucherXml: comprobanteXml, location: response.headers.location }, (err, result) => {
                          if (err) {
                            // send({ error: tags.savingProblema });
                          }
                        })
                      } else if (err) {
                        console.log(err)
                        send({ message: err })
                      } else {
                        console.log(response.statusCode + ' -> ' + response.statusMessage)
                        send({ message: 'Este comprobante ya se envió anteriormente o contiene errores' })
                      }
                    })
                    // }
                    // });
                  })
                } else {
                  console.log(httpResponse.statusCode + ' -> ' + httpResponse.statusMessage)
                }
              }
            })
          }
        })
      })
    })
  }

  this.getstatus = function (req, mongo, send) {
    var body = req.query
    body._id = mongo.toId(body._id)
    mongo.findId('invoice2pay', body._id, (err, invoice) => {
      if (err && !invoice) invoice = {}
      mongo.findOne('company', { idNum: invoice.company }, (err, environment) => {
        if (err && !environment) environment = {}

        getinvoice()

        function getinvoice () {
          request.post({
            url: environment.idpUrl,
            form: {
              grant_type: 'password',
              client_id: environment.clientId,
              username: environment.user,
              password: environment.password,
              client_secret: '',
              scope: ''
            }
          },
          function (err, httpResponse, token) {
            if (err) {
              console.log(err)
            } else {
              if (httpResponse.statusCode === 200) {
                var tokens = JSON.parse(token)

                // Get status invoice
                var options = {
                  json: true,
                  url: environment.url + 'recepcion/' + invoice.key + '-' + invoice.number, // + invoice.key,
                  headers: {
                    Authorization: 'bearer ' + tokens.access_token
                  }
                }
                request.get(options, function (err, response, doc) {
                  if (err) {
                    send({ message: 'Ocurrio un error al obtener la factura' })
                  }
                  if (doc !== null && response.statusCode === 200) {
                    var obj = doc
                    var result = Object.keys(obj).map(function (key) {
                      return [Number(key), obj[key]]
                    })
                    var estado = result[2]
                    // console.log(bytes);
                    var responseXml = result[3] ? result[3] : result[2]
                    responseXml = responseXml[1]
                    var detalle = ''
                    var str = base64.decode(responseXml)
                    var spl = str.split('<DetalleMensaje>', 2)
                    if (spl[1]) { detalle = spl[1].split('</DetalleMensaje>', 1)[0] }
                    // if (body.environment === 'Produccion') {
                    mongo.save('invoice2pay', { _id: body._id, responseXml: responseXml, statusHacienda: estado[1] }, (err, result) => {
                      if (err) {
                        // send({ error: tags.savingProblema });
                      }
                    })
                    // }
                    send({ message: 'Estado: ' + estado[1], detalle: detalle })
                  }
                  if (response.statusCode === 400) {
                    send({ message: 'El comprobante no ha sido enviado aún' })
                  } else {
                    console.log(response.statusCode + ' -> ' + response.statusMessage)
                  }
                })
              } else {
                console.log(httpResponse.statusCode)
              }
            }
          })
        }
      })
    })
  }
  var separadorDecimalesInicial = '.' // Modifique este dato para poder obtener la nomenclatura que utilizamos en mi pais
  var separadorDecimales = '.' // Modifique este dato para poder obtener la nomenclatura que utilizamos en mi pais
  var separadorMiles = ',' // Modifique este dato para poder obtener la nomenclatura que utilizamos en mi pais
  // Añadir separador de miles al total
  function arreglar (numero) {
    var num = ''
    numero = '' + numero
    var partes = numero.split(separadorDecimalesInicial)
    var entero = partes[0]
    if (partes.length > 1) {
      var decimal = partes[1]
    }
    var cifras = entero.length
    var cifras2 = cifras
    for (let a = 0; a < cifras; a++) {
      cifras2 -= 1
      num += entero.charAt(a)
      if (cifras2 % 3 === 0 && cifras2 !== 0) {
        num += separadorMiles
      }
    }
    if (partes.length > 1) {
      num += separadorDecimales + decimal
    }
    return num
  }

  // Añadir ceros a la izquierda
  function pad (n, length) {
    n = n.toString()
    while (n.length < length) { n = '0' + n }
    return n
  }
  // Añadir ceros a la derecha
  function pader (n, length) {
    n = n.toString()
    while (n.length < length) { n = n + '0' }
    return n
  }

  function omitirAcentos (text) {
    var acentos = 'ÃÀÁÄÂÈÉËÊÌÍÏÎÒÓÖÔÙÚÜÛãàáäâèéëêìíïîòóöôùúüûÑñÇç'
    var original = 'AAAAAEEEEIIIIOOOOUUUUaaaaaeeeeiiiioooouuuunncc'

    for (let i = 0; i < text.length; i++) {
      for (let j = 0; j < acentos.length; j++) {
        text = text.replace(acentos.charAt(j), original.charAt(j))
      }
    }

    return text
  }

  function chilkatExample () {
    var chilkat = require('@chilkat/ck-node14-linux64')
    // After licensing Chilkat, replace the "Anything for 30-day trial" with the purchased unlock code.
    // To verify the purchased unlock code was recognized, examine the contents of the LastErrorText
    var glob = new chilkat.Global()
    var success = glob.UnlockBundle('NFWJAQ.CB1042022_zJkF8zzt3K3e')
    //glob.UnlockBundle('INFOWA.CB1062020_V8xq8zKRD72n')
    if (success !== true) {
      console.log(glob.LastErrorText)
      return
    }
    var status = glob.UnlockStatus
    if (status !== 2) {
      console.log('Unlocked in trial mode.')
    }
    // The LastErrorText can be examined in the success case to see if it was unlocked in
    // trial more, or with a purchased unlock code.
  }
}
