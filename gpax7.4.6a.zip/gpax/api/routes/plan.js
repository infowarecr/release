var vm = require('vm')
var tags = require('../utils/tags').tags
var dateformat = require('dateformat')
var moment = require('moment')
var Notification = require('../utils/notification').Notification
var notification = new Notification()
/* exported */
exports.Plan = Plan

function Plan () {
  this.validatePlan = function (req, mongo, send) {
    var pipeline = []
    pipeline.push({ $match: { plan: mongo.toId(req.query._id) } })
    pipeline.push({ $unwind: '$actors' })
    pipeline.push({ $group: { _id: '$_id', total: { $min: '$assignment' }, assignment: { $sum: '$actors.assignment' } } })
    mongo.aggregate('project', pipeline, {}, (err, projects) => {
      if (err) send({ error: err })
      else {
        if (projects.length !== 0) {
          var count = 0
          var projectsIds = []
          for (const i in projects) {
            if (projects[i].total !== projects[i].assignment) {
              count += 1
              projectsIds.push(projects[i]._id)
            }
          }
          mongo.toHash('project', { _id: { $in: projectsIds } }, { _id: 1, name: 1 }, (er, projectsNames) => {
            if (count > 0) {
              var text = 'incomplete projects'
              for (const i in projectsNames) {
                // <div onclick='url(&quot;project.get?_id="+projectsNames[i]._id+"&idPlan="+projectsNames[i].plan+"&quot;);dhtmlx.modalbox.hide(this)'>"+projectsNames[i].name+"</div>"
                text = text + '<br><br>- ' + projectsNames[i].name
              }
              var confirm = {
                text: text,
                func: 'startPlan',
                id: req.query._id
              }
              send({ confirm: confirm })
            } else {
              send({ javascript: 'startPlan("' + req.query._id + '")' })
            }
          })
        }
      }
    })
  }

  this.startPlan = function (req, mongo, send) {
    mongo.findId('plan', req.query._id, (err, plan) => {
      if (err) send({ error: err })
      else {
        var doc
        if (plan) {
          doc = plan
          doc.planObjectives = doc.goals
          doc.status = tags.processing
          mongo.save('plan', doc, (err) => {
            var reply
            if (err) {
              reply = { error: tags.savingProblema }
            } else {
              reply = { message: tags.savedChanges }
              notification.send(req, req.session.context.room, 'dtplan', doc, null, null)
              mongo.find('project', { plan: mongo.toId(req.query._id) }, (err, projects) => {
                if (err) send({ error: err })
                else {
                  var x = 0
                  for (let i = 0; i < projects.length; i++) {
                    mongo.save('planProject', projects[i], (err) => {
                      if (err) {
                        reply = { error: tags.savingProblema }
                      } else {
                        x += 1
                        reply = { message: tags.savedChanges }
                      }
                      if (!(x < projects.length)) { send(reply) }
                    })
                  }
                }
              })
            }
          })
        } else {
          send({ message: tags.unsaved + ' ' + tags.plan })
        }
      }
    })
  }

  this.listMeansChart = function (req, mongo, send) {
    var pipeline = []
    pipeline.push({ $match: { plan: mongo.toId(req.query._id) } })
    pipeline.push({ $unwind: '$actors' })
    pipeline.push({ $lookup: { from: 'user', localField: 'actors.user', foreignField: '_id', as: 'user' } })
    pipeline.push({ $lookup: { from: 'plan', localField: 'plan', foreignField: '_id', as: 'plan' } })
    pipeline.push({ $group: { id: '$actors.user', name: '$user.name', workDays: '$plan.workingDays', value: { $sum: '$actors.assignment' } } })
    mongo.aggregate('project', pipeline, {}, (err, data) => {
      if (err) send({ error: err })
      else {
        var sumAvailable = 0
        var sumAssignment = 0
        for (const i in data) {
          data[i].name = data[i].name[0] || ''
          data[i].workDays = data[i].workDays[0] || 0
          const available = data[i].workDays - data[i].value
          sumAvailable = sumAvailable + available
          sumAssignment = sumAssignment + data[i].value
          data[i].available = available
        }
        data.forEach(function (item) {
          item.sumAssignment = sumAssignment
          item.sumAvailable = sumAvailable
        })
        send(data)
      }
    })
  }

  this.get = function (req, mongo, send) {
    mongo.findId('plan', req.query._id, { budget: 0, activities: 0, goals: 0, plan: 0 }, (err, plan) => {
      if (err || !plan) {
        send({ id: req.query._id })
      } else {
        mongo.find('project', { plan: plan._id }, {}, {}, async (err, projs) => {
          if (err) throw err
          try {
            plan.id = plan._id
            plan.disabledPeriod = false
            var totalProgress = 0
            var progressPlan = 0
            for (const i in projs) {
              if (projs[i].progress) {
                progressPlan += parseFloat(projs[i].progress.toString())
              }
            }
            totalProgress = progressPlan / projs.length
            plan.progress = totalProgress

            for (const i in projs) {
              if (projs[i].status === 'processing' || projs[i].status === 'completed' || projs[i].status === 'archived') {
                plan.disabledPeriod = true
                break
              }
            }
            if (plan.period && plan.period.start && plan.period.end) {
              plan.period.start = new Date(plan.period.start)
              plan.period.end = new Date(plan.period.end)
              plan.period.start = plan.period.start.getFullYear() + '-' + (plan.period.start.getMonth() + 1) + '-' + plan.period.start.getDate()
              plan.period.end = plan.period.end.getFullYear() + '-' + (plan.period.end.getMonth() + 1) + '-' + plan.period.end.getDate()
            }
            send(plan)
          } catch (error) {
            send({ err: error })
          }
        })
      }
    })
  }

  this.checkPlan = function (req, mongo, send) {
    mongo.findId('plan', req.query._id, { period: 1, status: 1, strategy: 1 }, async (err, plan) => {
      if (err) throw err
      if (plan.period && plan.period.start && plan.period.end) {
        if (plan.status === 'processing' && new Date(plan.period.end).getTime() < new Date().getTime()) {
          await new Promise(resolve => {
            mongo.save('plan', { _id: plan._id, status: 'completed' }, (err, result) => {
              if (err) { resolve(err) } else {
                plan.status = 'completed'
                resolve(result)
              }
            })
          })
          send({ status: plan.status, strategy: plan.strategy })
        } else send({ status: plan.status, strategy: plan.strategy })
      } else {
        send({ status: plan.status, strategy: plan.strategy })
      }
    })
  }

  this.linklessProjects = async function (req, mongo, send) {
    const plan = req.query._id
    const doc = []
    await new Promise(resolve => {
      const keys = {
        plan: mongo.toId(plan),
        $or: [
          { 'actors.user': req.session.context.user }
        ]
      }
      keys.$or.push({ unit: '' })
      if (req.session.context.managerUnits.length > 0) {
        keys.$or.push({ unit: { $in: req.session.context.managerUnits } })
      }
      if (req.session.context.assistantUnits.length > 0) {
        keys.$or.push({ unit: { $in: req.session.context.assistantUnits } })
      }
      if (req.session.context.dependentUnits.length > 0) {
        keys.$or.push({ unit: { $in: req.session.context.dependentUnits } })
      }
      mongo.find('project', keys, { name: 1, status: 1 }, (err, data) => {
        if (err || data.length === 0) {
          console.log(err)
          resolve([])
        } else {
          mongo.findId('plan', plan, { name: 1, goals: 1 }, (err, pl) => {
            if (err || !pl) {
              console.log(err)
              resolve([])
            } else {
              for (const i in data) {
                let exists = false
                for (const p in pl.goals) {
                  const index = pl.goals[p].projects.findIndex((x) => {
                    return x.toString() === data[i]._id.toString()
                  })
                  if (index !== -1) {
                    exists = true
                    break
                  }
                }
                if (!exists) {
                  doc.push({ id: data[i]._id, name: data[i].name, status: data[i].status, type: 'linkless' })
                }
              }
              resolve()
            }
          })
        }
      })
    })
    send(doc)
  }

  this.kanban = function (req, mongo, send) {
    var data = []
    if (mongo.isNativeId(req.query._id)) {
      mongo.find('project', { plan: mongo.toId(req.query._id) }, (err, projects) => {
        if (err || !projects) {
          req.statusCode = 404
          send([])
        } else {
          var userIds = []
          for (const i in projects) {
            for (const x in projects[i].actors) {
              var actor = projects[i].actors[x]
              if (actor.type.indexOf('manager') !== -1) {
                userIds.push(actor.user)
                projects[i].manager = actor.user
                break
              }
            }
          }
          mongo.toHash('user', { _id: { $in: userIds } }, { name: 1 }, (err, users) => {
            if (err) throw err
            for (const i in projects) {
              var doc = projects[i]
              data.push({
                id: doc._id,
                status: doc.status || 'draft',
                text: doc.name,
                userId: doc.manager || '',
                userName: !!doc.manager && users[doc.manager.toString()] ? users[doc.manager.toString()].name : '',
                color: doc.status === 'draft' ? '#606161' : doc.status === 'processing' ? '#1b82f8' : doc.status === 'completed' ? '#67F96B' : '#ff9100',
                startDate: doc.startEnd,
                duration: doc.PeriodDuration ? doc.PeriodDuration + ' dias' : doc.duration + ' dias'
              })
            }
            send(data)
          })
        }
      })
    } else { send([]) }
  }
  //* *******************************************************
  //                        OBJECTIVES
  //* *******************************************************
  this.goals = function (req, mongo, send) {
    mongo.findId('plan', req.query._id, { goals: 1 }, async (err, plan) => {
      if (err) {
        req.statusCode = 404
        send()
      } else if (!plan || !plan.goals || plan.goals.length === 0) {
        send([])
      } else {
        // example
        // Build the tree from the flat table
        var hash = {}
        if (req.query.filter && req.query.filter.goal) {
          plan.goals = plan.goals.filter(element => {
            return element.name.toLowerCase().includes(req.query.filter.goal.toLowerCase())
          })
        }
        if (req.query.filter && req.query.filter.status) {
          plan.goals = plan.goals.filter(element => {
            return element.status.includes(req.query.filter.status)
          })
        }
        send(plan.goals)
      }
    })
  }

  this.updateGoals = function (req, mongo, send) {
    mongo.findId('plan', req.query._id, { goals: 1 }, async (err, plan) => {
      if (err) {
        req.statusCode = 404
        send()
      } else if (!plan || !plan.goals || plan.goals.length === 0) {
        send()
      } else {
        send()
        // Build the tree from the flat table
        for (const i in plan.goals) {
          var totalProgress = 0
          var progressGoal = 0
          if (plan.goals[i].projects && plan.goals[i].projects.length > 0) {
            let goalComplete = true
            let archived = true
            let statusGoal = ''
            for (const p in plan.goals[i].projects) {
              var resultadoProjects = await new Promise(resolve => {
                mongo.findId('project', mongo.toId(plan.goals[i].projects[p]), async (err, project) => {
                  if (err || !project) {
                    resolve(false)
                  } else {
                    if (project && project.status !== 'archived') {
                      archived = false
                      if (project.status !== 'draft') statusGoal = 'processing'
                    } else {
                      statusGoal = 'processing'
                    }
                    resolve(project)
                  }
                })
              })
              if (goalComplete && resultadoProjects.status !== 'archived') {
                goalComplete = false
              }
              if (resultadoProjects.status === 'archived') {
                progressGoal += parseFloat('100')
              }else if (resultadoProjects.progress) {
                progressGoal += parseFloat(resultadoProjects.progress.toString())
              } else {
                if (resultadoProjects.duration) {
                  let total = 0
                  let totalDuration = 0
                  var tasks = await new Promise(resolve => {
                    mongo.find('task', {project: mongo.toId(plan.goals[i].projects[p])}, async (err, tasks) => {
                      if (err) {
                        resolve(false)
                      } else {
                        resolve(tasks)
                      }
                    })
                  })
                  for (let d in tasks) {
                    if (tasks[d].type === 'task') {
                      totalDuration += parseFloat(tasks[d].duration)
                    }
                  }
                  resultadoProjects.duration = totalDuration
                  for (const d in tasks) {
                    if (tasks[d].type === 'task' && ['done', 'reviewed', 'completed'].includes(tasks[d].status)) {
                      total += parseFloat(tasks[d].duration)
                    }
                    if (tasks[d].type === 'task' && tasks[d].status === 'suspended') {
                      resultadoProjects.duration = parseFloat(resultadoProjects.duration) - parseFloat(tasks[d].duration)
                    }
                  }
                  resultadoProjects.realDuration = total
                  progressGoal += (resultadoProjects.duration !== 0 ? (total / parseFloat(resultadoProjects.duration)) : 0) * 100
                  progressGoal = progressGoal > 100 ? 100 : progressGoal
                }
              }
            }
            if (archived) {
              plan.goals[i].status = 'completed'
            } else {
              plan.goals[i].status = statusGoal ? statusGoal : 'draft'
            }
          } else {
            plan.goals[i].status = 'draft'
          } 
           totalProgress = plan.goals[i].projects.length > 0 ? progressGoal / plan.goals[i].projects.length : 0
          if (totalProgress === 100 && plan.goals[i].status !== 'completed') {
            plan.goals[i].status = 'completed'
          }
          plan.goals[i].progress = totalProgress 
        }
        await new Promise(resolve => {
          mongo.save('plan', { _id: plan._id, goals: plan.goals }, () => { resolve() })
        })
        
      }
    })
  } 

  this.indicators = function (req, mongo, send) {
    mongo.find('params', { name: 'tag' }, { _id: 1, name: 1, options: 1 }, (er, tagsDoc) => {
      mongo.findId('plan', req.query._id, { indicators: 1 }, (err, plan) => {
        if (err) {
          req.statusCode = 404
          send()
        } else if (!plan || !plan.indicators || plan.indicators.length === 0) {
          send([])
        } else {
          // Build the tree from the flat table
          var hash = {}
          if (plan.indicators !== '[]') {
            for (const i in plan.indicators) {
              var tagsId = []
              tagsId.push(plan.indicators[i].tags)
              var usedTags = []
              if (tagsDoc[0]) {
                for (let t = 0; t < tagsDoc[0].options.length; t++) {
                  for (let o = 0; o < tagsId.length; o++) {
                    if (tagsId[o] && tagsDoc[0].options[t].id.toString() === tagsId[o].toString()) {
                      usedTags.push(tagsDoc[0].options[t])
                    }
                  }
                }
              }
              var tagscolor = []
              var tagsname = []
              var filterNames = [usedTags[0] ? usedTags[0].value : '']
              for (const j in usedTags) {
                tagscolor.push(usedTags[j].color)
                tagsname.push(usedTags[j].value)
                // filterNames.push(usedTags[i].value);
              }
              plan.indicators[i].filterNames = filterNames
              plan.indicators[i].tagscolor = tagscolor
              plan.indicators[i].tagsname = tagsname
              plan.indicators[i].period.start = plan.indicators[i].period.start ? plan.indicators[i].period.start.toISOString().split('T')[0] : ''
              plan.indicators[i].period.end = plan.indicators[i].period.end ? plan.indicators[i].period.end.toISOString().split('T')[0] : ''
              const obj = plan.indicators[i]
              hash[obj.id] = obj
            }
          }
          for (const i in plan.indicators) {
            if (plan.indicators[i].parent) {
              var parent = hash[plan.indicators[i].parent]
              if (!parent.data) {
                parent.data = [plan.indicators[i]]
              } else {
                parent.data.push(plan.indicators[i])
              }
            }
          }
          var tree = []
          for (const i in hash) {
            if (!hash[i].parent) {
              tree.push(hash[i])
            }
          }
          send(tree)
        }
      })
    })
  }

  this.createProject = function (req, planId, newProjects, index, mongo, next) {
    if (index < newProjects.length) {
      var newProject = newProjects[index]
      mongo.findId('auditable', newProject.template, (err, doc) => {
        if (err) {
          next(err)
        } else if(doc) {
          mongo.findId('template', doc.project, async (err, template) => {
            if (err) {
              next(err)
            } else if (!template) {
              next({ message: _('auditableWithoutProject')})
            } else {
              doc._id = newProject.project
              doc.plan = planId
              let content = template.template ? template.template: doc.content
              req.app.routes.project.taskIds(content, mongo, true)
              if (content && content.data) {
                for (const d in content.data) {
                  let task = content.data[d]
                  task.project = doc._id
                  task._id = task.id
                  let start = new Date()
                  let end = new Date()
                  if (task.start_date) {
                    start = moment(new Date(task.start_date))
                  }
                  if (task.end_date) {
                    end = moment(new Date(task.end_date))
                  } else if (task.start_date) {
                    end = start
                  }
                  let days = end.diff(start, 'days')
                  let newStart = new Date()
                  //let newEnd = new Date().setDate(new Date().getDate() + (days + 1))
                  task.start_date = newStart
                  task.end_date = ''/* newEnd ? new Date(newEnd): newStart */
                  var links = []
                  if (content.links && content.links.length > 0) {
                    content.links.forEach(l => {
                      if (l.source.toString() === task.id.toString()) {
                        links.push(l)
                      }
                    })
                  }
                  task.links = links
                  if (content.calendars && content.calendars.length > 0) {
                    content.calendars.forEach(c => {
                      if (c.id.includes(task.id.toString())) {
                        task.calendar = c
                      }
                    })
                  }
                  await new Promise(resolve => {
                    mongo.save('task', task, () => {
                      resolve()
                    })
                  })
                }
              }
              doc.auditable = newProject.template
              doc.status = 'draft'
              if (doc.sequence) {
                doc.sequence = { sequence: doc.sequence }
              } else {
                doc.sequence = { text: '' }
              }
              var findCopyFrom = await new Promise(resolve => {
                mongo.findId('auditable', doc.copyFrom ? doc.copyFrom : '', (err, result) => {
                  if (err) throw new Error(err)
                  if (result) resolve(result.description)
                  else resolve('')
                })
              })
              findCopyFrom ? doc.description = findCopyFrom : doc.description
              mongo.save('project', doc, (err) => {
                if (err) {
                  next(err)
                } else {
                  this.createProject(req, planId, newProjects, index + 1, mongo, next)
                }
              })
            }
          })
        } else {
          this.createProject(req, planId, newProjects, index + 1, mongo, next)
        }
      })
    } else {
      next()
    }
  }

  this.indicatorSave = function (req, mongo, send) {
    var _id = req.body._id
    var indicator = req.body.indicator
    var tagscolor
    var tagsname
    mongo.findId('plan', _id, (err, doc) => {
      mongo.find('params', { name: 'tag' }, { _id: 1, name: 1, options: 1 }, (er, tags) => {
        if (err) {
          send(err)
        } if (!doc) {
          send({ error: 'save the plan first' })
        } else {
          if (tags.length > 0) {
            for (const t in tags[0].options) {
              if (tags[0].options[t].id.toString() === indicator.tags.toString()) {
                tagscolor = [tags[0].options[t].color]
                tagsname = [tags[0].options[t].value]
              }
            }
          }
          if (doc.indicators === '[]' || !doc.indicators) { doc.indicators = [] }
          if (doc.indicators && doc.indicators.length > 0) {
            var index = doc.indicators.findIndex((x) => {
              return x.id.toString() === indicator.id
            })
            if (index !== -1) {
              doc.indicators[index] = indicator
            } else {
              doc.indicators.push(indicator)
            }
          } else {
            doc.indicators.push(indicator)
          }
          if (indicator.$parent) {
            indicator.parent = indicator.$parent
          }
          delete indicator.tagscolor
          delete indicator.tagsname
          mongo.findId('settings', 'settings', async (err, settings) => {
            if (err) console.log(err)
            var context = {
              pipeline: [],
              plan: doc,
              settings: settings,
              indicator: indicator,
              session: req.session.context
            }
            var message = ''
            try {
              const runnable = new vm.Script(indicator.script)
              var ws = vm.createContext(context)
              runnable.runInContext(ws)
            } catch (err) {
              message = err.toString()
            }
            if (indicator.collection) {
              await new Promise(resolve => {
                mongo.aggregate(indicator.collection, context.pipeline, {}, (err, docs) => {
                  if (err && !message) {
                    message = err.toString()
                    resolve()
                  } else if (docs && docs[0] && docs[0].result) {
                    indicator.result = docs[0].result
                    resolve()
                  } else if (!err) {
                    indicator.result = 0
                    resolve()
                  }
                })
              })
            } else indicator.result = 0
            mongo.save('plan', { _id: doc._id, indicators: doc.indicators }, async (err, result) => {
              if (err || !result) {
                req.statusCode = 404
                send({ message: 'savingProblem' })
              } else {
                if (message) {
                  send({ error: message })
                } else {
                  send(indicator)
                }
                indicator.tagscolor = tagscolor
                indicator.tagsname = tagsname
                notification.send(req, req.session.context.room, 'indicator.' + req.body._id.toString(), indicator, null, null)
              }
            })
          })
        }
      })
    })
  }

  this.runScript = async function (mongo) {
    await new Promise(resolve => {
      mongo.find('plan', { status: 'processing', indicators: { $exists: 1 } }, async (err, plans) => {
        if (err) {
          console.log(err)
          resolve()
        } else if (plans && plans.length > 0) {
          for (const i in plans) {
            const plan = plans[i]
            for (var r in plan.indicators) {
              var indicator = plan.indicators[r]
              if (indicator.collection && indicator.script) {
                let script = JSON.stringify(indicator.script).replace(/#/g, '$')
                /* script = script.replace(/"[&]/g, '')
                script = script.replace(/[&]"/g, '') */
                script = JSON.parse(script)
                /* for (var t in script) {
                  const x = script[t] */
                await this.find(script, mongo)
                // }
                var result = await new Promise(resolve => {
                  mongo.aggregate(indicator.collection, script, {}, (err, data) => {
                    if (err) {
                      console.log(err)
                      resolve('')
                    } else {
                      // salvar resultado en indicador plan...
                      if (data[0] && data[0].result) {
                        resolve(data[0].result)
                      } else resolve('')
                    }
                  })
                })
                indicator.result = result
              }
            }
            // salvar plan con indicadores modificados
            await new Promise(resolve => {
              mongo.save('plan', { _id: plan._id, indicators: plan.indicators }, (err) => {
                if (err) {
                  console.log(err)
                  resolve()
                } else {
                  resolve()
                }
              })
            })
          }
          resolve()
        } else resolve()
      })
    })
  }

  this.importActivities = function (req, mongo, send) {
    mongo.find('plan', { _id: mongo.toId(req.body._id) }, { _id: 1, name: 1, activities: 1 }, {}, (err, plan1) => {
      if (err || !plan1) {
        send({ error: err })
      } else {
        mongo.find('plan', { _id: mongo.toId(req.body.selected[0].planId) }, { _id: 1, name: 1, activities: 1 }, {}, async (err, plan2) => {
          if (err || !plan2) {
            send({ error: err })
          } else {
            plan1 = plan1[0]
            plan2 = plan2[0]
            if (!plan1.activities) {
              plan1.activities = {
                activities: {},
                data: []
              }
            }
            const selected = req.body.selected
            for (const i in selected) {
              let exists = false
              for (const a in plan1.activities.activities) {
                if (plan1.activities.activities[a] === selected[i].acivity) {
                  exists = true
                  break
                }
              }
              if (!exists) {
                for (const d in plan2.activities.data) {
                  if (plan2.activities.data[d].activity === selected[i].id) {
                    let exists2 = false
                    for (const r in plan1.activities.activities) {
                      if (plan1.activities.activities[r] === selected[i].activity) {
                        exists2 = true
                      }
                    }
                    if (plan1.activities.activities[selected[i].id] && !exists2) {
                      let id
                      do {
                        id = Math.round(Math.random() * 9999999999999)
                      } while (plan1.activities.activities[id])
                      plan2.activities.data[d].activity = id
                      plan1.activities.data.push(plan2.activities.data[d])
                      plan1.activities.activities[id] = selected[i].activity
                    } else {
                      plan1.activities.data.push(plan2.activities.data[d])
                      if (!exists2) {
                        plan1.activities.activities[selected[i].id] = selected[i].activity
                      }
                    }
                  }
                }
              }
            }
            await new Promise(resolve => {
              mongo.save('plan', plan1, (err, result) => {
                if (err) { resolve(err) } else {
                  resolve(result)
                }
              })
            })
            send({})
          }
        })
      }
    })
  }

  this.find = async function (script, mongo) {
    await recorrer(script)
    async function recorrer (doc) {
      for (var t in doc) {
        var x = doc[t]
        if (typeof x !== 'string') {
          await recorrer(x)
        } else {
          if (x.search('&') !== -1) {
            if (x.split('Date(') && x.split('Date(').length > 1) {
              let date = x.split('Date(')[1].split(')')[0].split(',')
              date = new Date(Number(date[0]), Number(date[1]), Number(date[2]))
              doc[t] = date
            }
          } else if (x.search('settings') !== -1) {
            await new Promise(resolve => {
              mongo.findId('settings', 'settings', (err, sett) => {
                if (err) {
                  console.log(err)
                  resolve()
                } else {
                  if (x.search('settings.auditCommittee') !== -1 && sett.auditCommittee) {
                    doc[t] = sett.auditCommittee
                  } else if (x.search('settings.auditUnit') !== -1 && sett.auditUnit) {
                    doc[t] = sett.auditUnit
                  }
                  resolve()
                }
              })
            })
          }
        }
      }
    }
  }

  this.goalSave = function (req, mongo, send) {
    var isNew = false
    var _id = req.body._id
    var goal = req.body.goal
    if (goal.id) {
      mongo.findId('plan', _id, (err, doc) => {
        if (err) {
          send(err)
        } if (!doc) {
          send({ error: 'first save the plan' })
        } else {
          if (doc.goals) {
            var index = doc.goals.findIndex((x) => {
              return x.id.toString() === goal.id
            })
            if (index === -1) {
              isNew = true
            } else {
              isNew = false
            }
          } else {
            isNew = true
          }
          if (goal.$parent) {
            goal.parent = goal.$parent
          }
          // Delete all $... fields of the goal
          for (const field in goal) {
            if (field.indexOf('$') !== -1) {
              delete goal[field]
            }
          }
          // Get template's id (<templateId>_<provisional id>) from new projects & replace provisional project id by mongoId
          var newProjects = []
          if (mongo.isNativeId(doc.unit)) var unitId = doc.unit
          else unitId = null
          for (const i in goal.projects) {
            const id = goal.projects[i]
            if (id && id.indexOf('_') !== -1) {
              var newProject = { template: id.substring(0, id.indexOf('_')), project: mongo.newId() }
              if (unitId) newProject.unit = unitId
              newProjects.push(newProject)
              goal.projects[i] = newProject.project
            }
          }
          // Create the new projects
          this.createProject(req, _id, newProjects, 0, mongo, async (err) => {
            if (err) {
              // req.statusCode = 404
              send({ error2: err.message })
            } else {
              // check complete goal
              if (goal.projects && goal.projects.length) {
                let archived = true
                let statusGoal = ''
                for (let p in goal.projects) {
                  await new Promise(resolve => {
                    mongo.findId('project', goal.projects[p], async (err, project) => {
                      if (project && project.status !== 'archived') {
                        archived = false
                        if (project.status !== 'draft') statusGoal = 'processing'
                      } else {
                        statusGoal = 'processing'
                      }
                      resolve()
                    })
                  })
                }
                if (archived) {
                  goal.status = 'completed'
                } else {
                  goal.status = statusGoal ? statusGoal : 'draft'
                }
              } else {
                goal.status = 'draft'
              }
              if (isNew) {
                mongo.update('plan', { _id: _id }, { $push: { goals: goal } }, (err, result) => {
                  if (err || !result) {
                    // req.statusCode = 404
                    send({ error: err })
                  } else {
                    send(goal)
                    notification.send(req, req.session.context.room, 'goal.' + req.body._id.toString(), goal, null, null)
                    notification.send(req, req.session.context.room, 'kanban.' + req.body._id.toString(), { id: doc._id })
                  }
                })
              } else {
                mongo.update('plan', { _id: _id, 'goals.id': goal.id }, { $set: { 'goals.$': goal } }, (err, result) => {
                  if (err || !result) {
                    // req.statusCode = 404
                    send({ error: err })
                  } else {
                    send(goal)
                    notification.send(req, req.session.context.room, 'goal.' + req.body._id.toString(), goal, null, null)
                    notification.send(req, req.session.context.room, 'kanban.' + req.body._id.toString(), { id: doc._id })
                  }
                })
              }
            }
          })
        }
      })
    } else {
      send({ error: 'add new goal' })
    }
  }

  this.goalDelete = function (req, mongo, send) {
    mongo.findId('plan', req.query._id, { goals: 1 }, (err, plan) => {
      if (err || !plan) {
        req.statusCode = 404
        send()
      } else {
        var goalDeleted = ''
        for (const i in plan.goals) {
          var goals = plan.goals[i]
          if (!goals.id || !goals.status) {
            goalDeleted = plan.goals[i]
            plan.goals.splice(i, 1)
          }
          if (goals.id && goals.id.toString() === req.query.goal) {
            goalDeleted = plan.goals[i]
            plan.goals.splice(i, 1)
            break
          }
        }
        mongo.save('plan', plan, (err, result) => {
          if (err || !result) {
            req.statusCode = 404
            send()
          } else {
            goalDeleted.plan = plan._id
            req.app.routes.trash.insert(req, mongo, 'plan', goalDeleted, () => {
              send({ saved: true })
              notification.send(req, req.session.context.room, 'goal.' + plan._id.toString(), { id: req.query.goal }, null, true)
            })
          }
        })
      }
    })
  }

  this.indicatorDelete = function (req, mongo, send) {
    mongo.findId('plan', req.query._id, { indicators: 1 }, (err, plan) => {
      if (err || !plan) {
        req.statusCode = 404
        send()
      } else {
        for (const i in plan.indicators) {
          var indicators = plan.indicators[i]
          if (indicators.id.toString() === req.query.indicator) {
            plan.indicators.splice(i, 1)
            break
          }
        }
        mongo.save('plan', plan, (err, result) => {
          if (err || !result) {
            req.statusCode = 404
            send()
          } else {
            send({ saved: true })
            notification.send(req, req.session.context.room, 'indicator.' + plan._id.toString(), { id: req.query.indicator }, null, true)
          }
        })
      }
    })
  }

  this.changeProjectGoal = function (req, mongo, send) {
    mongo.findId('plan', req.body.plan, { goals: 1 }, (err, plan) => {
      if (err || !plan) {
        send([])
      } else {
        const iO = plan.goals.findIndex((x) => {
          return x.id.toString() === req.body.oldGoal
        })
        const iN = plan.goals.findIndex((x) => {
          return x.id.toString() === req.body.newGoal
        })
        if (iO !== -1 && plan.goals[iO].projects) {
          const i = plan.goals[iO].projects.findIndex((x) => {
            return x.toString() === req.body.project
          })
          if (i !== -1) {
            plan.goals[iO].projects.splice(i, 1)
          }
        }
        if (iO !== -1) {
          if (!plan.goals[iN].projects) { plan.goals[iN].projects = [] }
          plan.goals[iN].projects.push(req.body.project)
        }
        mongo.save('plan', plan, (err) => {
          if (err) throw err
          else {
            send({ message: tags.savedChanges })
          }
        })
      }
    })
  }
  //* *******************************************************
  //                         BUDGET
  //* *******************************************************
  this.budget = function (req, mongo, send) {
    mongo.findId('plan', req.query._id, { budget: 1 }, (err, plan) => {
      if (err || !plan) {
        send([])
      } else {
        for (const b in plan.budget) {
          var budget = plan.budget[b]
          if (budget.id && parseInt(budget.amount) > 0) {
            budget.progress = budget.real / parseInt(budget.amount)
            budget.progress = budget.progress * 100
          }
        }
        send(plan.budget || [])
      }
    })
  }

  this.budgetSave = function (req, mongo, send) {
    var plan = req.body
    mongo.save('plan', plan, (err, result) => {
      if (err || !result) {
        req.statusCode = 404
        send()
      } else {
        send({ saved: true })
        notification.send(req, req.session.context.room, 'budget.' + plan._id, req.query.form, null, null)
      }
    })
  }
  //* *******************************************************
  //                         ACTIVITIES
  //* *******************************************************
  this.activities = function (req, mongo, send) {
    mongo.findId('plan', req.query._id, { activities: 1 }, (err, plan) => {
      if (err || !plan) {
        send({ list: [], data: [] })
      } else {
        var acts = plan.activities
        if (!acts) {
          acts = { hash: {}, data: [] }
        } else if (!acts.data) {
          acts.data = []
        }
        mongo.find('user', { $and: [{ licensedUser: true }, { $or: [{ _id: req.session.context.user }, { units: { $in: req.session.context.managerUnits } }, { units: { $in: req.session.context.assistantUnits } }] }] }, { name: 1, business: 1 }, { name: 1 }, (err, users) => {
          if (err) throw err
          mongo.find('time', { plan: mongo.toId(req.query._id) }, {}, {}, (err, times) => {
            if (err) throw err
            var workDayDefault, workDay
            if (acts.data.length > 0 && times.length > 0) {
              for (const i in acts.data) {
                var data = acts.data[i]
                for (const o in times) {
                  var time = times[o]
                  if (acts.activities[data.activity] === time.activity && time.user && data.user.toString() === time.user.toString()) {
                    users.forEach(x => {
                      if (x._id.equals(data.user) && x.business && x.business.workDay && !isNaN(Number(x.business.workDay))) {
                        workDay = Number(x.business.workDay)
                      } else {
                        workDayDefault = 480
                      }
                    })
                    if (data.real) {
                      data.real = data.real + (parseFloat(time.duration) / (workDay || workDayDefault))
                    } else {
                      data.real = parseFloat(time.duration) / (workDay || workDayDefault)
                    }
                  }
                }
              }
            }
            if (err || !users) {
              acts.users = []
              send(acts)
            } else {
              var hash = {}
              for (const i in users) {
                hash[users[i]._id] = users[i].name
              }
              acts.users = hash
              send(acts)
            }
          })
        })
      }
    })
  }
  this.activitiesSave = function (req, mongo, send) {
    var grid = req.body.activities
    var activities = {}
    var data = []
    mongo.findId('plan', req.body._id, { activities: 1, name: 1 }, (err, plan) => {
      if (err) throw err
      if (!plan.activities) {
        for (const i in grid) {
          var row = grid[i]
          activities[row.id] = row.name
          for (const field in row) {
            if (mongo.isNativeId(field)) {
              var value = row[field]
              value = value === '' ? 0 : value.indexOf && value.indexOf(',') !== -1 ? 1 * value.replace(',', '.') : 1 * value
              data.push({ activity: row.id, user: field, value: value })
            }
          }
        }
        mongo.save('plan', { _id: req.body._id, activities: { activities: activities, data: data } }, (err, result) => {
          if (err || !result) {
            req.statusCode = 404
            send()
          } else {
            send({ saved: true })
            notification.send(req, req.session.context.room, 'activities.' + req.body._id.toString(), req.query.item, null, null)
          }
        })
      } else {
        if (req.body.filter === '' || !req.body.filter) {
          for (const i in grid) {
            // if (!plan.activities.activities[grid[i].id]) {
            plan.activities.activities[grid[i].id] = grid[i].name
            // }
            if (plan.activities.data.length === 0) {
              row = grid[i]
              for (const field in row) {
                if (mongo.isNativeId(field)) {
                  value = row[field]
                  value = value && value !== '' ? 1 * value : 0
                  plan.activities.data.push({ activity: row.id, user: field, value: value })
                }
              }
            }
            row = grid[i]
            for (const field in row) {
              if (mongo.isNativeId(field)) {
                var exist2 = false
                value = row[field]
                value = value && value !== '' ? 1 * value : 0
                for (const f in plan.activities.data) {
                  if (plan.activities.data[f].user.toString() === field && plan.activities.data[f].activity.toString() === row.id.toString()) {
                    exist2 = true
                    break
                  }
                }
                if (!exist2) {
                  plan.activities.data.push({ activity: row.id, user: field, value: value })
                }
              }
            }
            var BreakException = {}
            var row2 = grid[i]
            // activities[row2.id] = row2.name;
            data = []
            for (const field in row2) {
              if (mongo.isNativeId(field)) {
                value = row2[field]
                value = value !== '' ? 1 * value : value
                if (value !== 0) {
                  if (value === '') { value = 0 }
                  data.push({ activity: row2.id, user: field, value: value })
                }
              }
            }
            data.forEach(x => {
              if (grid[i][x.user.toString()] !== undefined) {
                try {
                  plan.activities.data.forEach((element, index) => {
                    if (x.user.toString() === element.user.toString() && element.activity.toString() === grid[i].id.toString()) {
                      var vl = grid[i][element.user.toString()]
                      if (grid[i][element.user.toString()] === '') { vl = 0 }
                      plan.activities.data[index] = { activity: element.activity, user: element.user, value: vl }
                      throw BreakException
                    }
                  })
                } catch (e) {
                  if (e !== BreakException) throw e
                }
              }
            })
          }
        } else {
          for (const i in grid) {
            BreakException = {}
            plan.activities.data.findIndex((x) => {
              if (grid[i][x.user.toString()] !== undefined) {
                try {
                  plan.activities.data.forEach((element) => {
                    if (x.user.toString() === element.user.toString() && element.activity.toString() === grid[i].id.toString()) {
                      element.activity = grid[i].id
                      element.user = x.user
                      element.value = grid[i][x.user.toString()]
                      throw BreakException
                    }
                  })
                } catch (e) {
                  if (e !== BreakException) throw e
                }
              }
            })
          }
        }
        mongo.save('plan', { _id: plan._id, activities: plan.activities }, (err, result) => {
          if (err || !result) {
            req.statusCode = 404
            send()
          } else {
            send({ saved: true })
            notification.send(req, req.session.context.room, 'activities.' + req.body._id.toString(), req.query.item, null, null)
          }
        })
      }
    })
  }

  this.activityDelete = async function (req, mongo, send) {
    var doc = req.query
    mongo.findId('activity', mongo.toId(doc._id), (err, activity) => {
      if (err) {
        send({ error: err })
      } else {
        mongo.find('activityUser', { '_id.activity': activity._id }, {}, (err, acts) => {
          if (err || (acts && acts.length)) {
            send({ msj: '_activityInUse' }) //Esta actividad se esta utilizando
          } else {
            mongo.find('time', { document: activity._id }, {}, (err, tms) => {
              if (err || (tms && tms.length)) {
                send({ msj: '_activityInUse' }) //Esta actividad se esta utilizando
              } else {
                mongo.deleteOne('activity', { _id: mongo.toId(doc._id) }, (err) => {
                  if (err) {
                    req.logger.log(err)
                  } else {
                    req.app.routes.trash.insert(req, mongo, 'activity', activity, () => {
                      send({ message: tags.savedChanges })
                    })
                  }
                })
              }
            })
          }
        })
      }
    })
  }

  this.list = async function (req, mongo, send) {
    var keys = { $or: [{ unit: { $exists: 0 } }, { unit: '' }, { unit: { $in: req.session.context.managerUnits } }, { unit: { $in: req.session.context.assistantUnits } }, { unit: { $in: req.session.context.memberUnits } }] }
    if (req.query.filter) {
      const query = {}
      for (const name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          if (name === 'name') {
            query.$text = {
              $search: req.query.filter.name
            }
          } else if (name === '_id' || name === 'strategy') {
            var ids = req.query.filter[name].split(',')
            for (const i in ids) {
              if (mongo.isNativeId(ids[i])) {
                ids[i] = mongo.toId(ids[i])
              }
            }
            query[name] = { $in: ids }
          } else {
            query[name] = req.query.filter[name].indexOf(',') !== -1 ? { $in: req.query.filter[name].split(',') } : new RegExp(req.query.filter[name].replace(/ /g, '.*'), 'i')
          }
        }
      }
      keys = { $and: [keys, query] }
    }
    var pipeline = [
      { $match: keys },
      { $lookup: { from: 'project', localField: '_id', foreignField: 'plan', as: 'projects' } },
      { $unwind: { path: '$projects', preserveNullAndEmptyArrays: true } },
      { $unwind: { path: '$projects.content.data', preserveNullAndEmptyArrays: true } },
      { $match: { $or: [{ 'projects.content.data.type': 'task' }, { 'projects.content.data': { $exists: 0 } }] } },
      {
        $group: {
          _id: '$_id',
          tasks: { $sum: { $cmp: [{ $ifNull: ['$projects', 0] }, 0] } },
          tasksCompleted: { $sum: { $cond: { if: { $in: ['$projects.content.data.status', ['completed', 'reviewed', 'suspended', 'done']] }, then: 1, else: 0 } } },
          name: { $first: '$name' },
          period: { $first: '$period' },
          status: { $first: '$status' },
          strategy: { $first: '$strategy' }
        }
      },
      {
        $project: {
          _id: 1,
          id: '$_id',
          name: 1,
          status: 1,
          strategy: 1,
          period: 1,
          progress: {
            $cond: {
              if: { $eq: ['$tasks', 0] },
              then: 0,
              else: { $multiply: [{ $divide: ['$tasksCompleted', '$tasks'] }, 100] }
            }
          },
          startDate: { $dateToString: { format: '%Y-%m-%d', date: { $toDate: '$period.start' } } },
          endDate: { $dateToString: { format: '%Y-%m-%d', date: { $toDate: '$period.end' } } }
        }
      },
      { $sort: { name: -1 } }
    ]
    mongo.aggregate('plan', pipeline, {}, (err, plans) => {
      if (err) console.log(err)
      send(plans)
    })
  }

  this.row = function (doc, tags) {
    const data = { id: doc._id, _id: doc._id, name: doc.name, period: doc.period, status: doc.status }
    if (doc.status === 'draft') {
      data.status = tags.withoutStarting
    }
    data.id = data._id
    data.progress = 45 /* TODO duration -> real / planned */
    data.statusName = data.status
    return data
  }

  this.Delete = function (req, mongo, send) {
    if (parseInt(req.query.goals) > 0 || parseInt(req.query.acts) > 0) {
      send({ deleted: false })
    } else {
      mongo.findId('plan', req.query._id, (err, pl) => {
        if (err) {
          send({ error: err })
        } else {
          mongo.deleteOne('plan', { _id: mongo.toId(req.query._id) }, (err) => {
            if (err) {
              req.logger.log(err)
            } else {
              req.app.routes.trash.insert(req, mongo, 'plan', pl, () => {
                send({ deleted: true })
                var doc = {}
                doc.id = req.query._id
                notification.send(req, req.session.context.room, 'dtplan', doc, null, true)
                notification.send(req, req.session.context.room, 'dtplan.' + pl.strategy.toString(), doc, null, true)
              })
            }
          })
        }
      })
    }
  }

  this.detailSave = function (req, mongo, next) {
    var doc = req.body
    doc._id = doc.id
    if (doc.unit.toString().length < 24) {
      doc.unit = ''
    }
    delete doc.id

    try {
      doc.goals = JSON.parse(doc.goals)
    } catch (s) {
      doc.goals
    }
    try {
      doc.workingDays = doc.workingDays ? parseInt('0' + doc.workDays) : 0
    } catch (e) {
      doc.workingDays
    }
    if (doc.status !== tags.processing) {
      doc.status = tags.draft
    }
    var holidays = []
    for (const i in doc.holidays) {
      var date = new Date(doc.holidays[i])
      if (date >= doc.period.start && date <= doc.period.end) {
        holidays.push(dateformat(date, 'yyyy/mm/dd'))
      }
    }
    if (!doc.strategy) {
      delete doc.strategy
    }
    doc.holidays = holidays
    doc.period.start = dateformat(doc.period.start, 'yyyy/mm/dd')
    doc.period.end = dateformat(doc.period.end, 'yyyy/mm/dd')
    mongo.save('plan', doc, (err) => {
      var reply
      if (err) {
        reply = { error: tags.savingProblema }
      } else {
        reply = { message: tags.savedChanges, id: doc._id }
      }
      next(reply)
      doc.id = doc._id
      doc.statusName = doc.status
      doc.startDate = doc.period.start
      doc.endDate = doc.period.end
      if(doc.strategy) notification.send(req, req.session.context.room, 'dtplan.' + doc.strategy.toString(), doc, null, null)
    })
  }

  this.updateTaskProject = function (req, mongo, send) {
    mongo.findId('plan', req.query._id, (err, plan) => {
      if (err) send({ error: err })
      else {
        const task = JSON.parse(req.query.task)
        const p = plan.goals.data.findIndex(function (x) {
          return x.id === task.id
        })
        if (p !== -1) {
          for (const prop in task) {
            plan.goals.data[p][prop] = task[prop]
          }
        }
        mongo.save('plan', plan, (err, result) => {
          if (!err || result) {
            send({})
          }
        })
      }
    })
  }

  this.deleteBudget = function (req, mongo, send) {
    var id = req.body._id

    var budget = req.body.budget

    var reply = {}

    var borrar = true
    mongo.findId('plan', id, (err, result) => {
      if (err) throw err
      mongo.find('project', {}, {}, {}, (err, projects) => {
        if (err) {
          send()
        } else {
          for (const p in projects) {
            if (projects[p].budget) {
              for (const b in projects[p].budget) {
                var bud = projects[p].budget[b]
                if (bud.id.toString() === budget && parseInt(bud.amount) > 0) {
                  borrar = false
                  reply = { msj: '_cantDeleteBudgetAlreadyInUse' } //Hay proyectos utilizando este presupuesto, no se puede borrar
                  break
                }
              }
            }
          }
          if (borrar) {
            for (const bp in result.budget) {
              if (result.budget[bp].id.toString() === budget) {
                result.budget.splice(bp, 1)
                break
              }
            }
            mongo.save('plan', { _id: id, budget: result.budget }, (err) => {
              if (err) {
                send()
              } else {
                send(reply)
                notification.send(req, req.session.context.room, 'budget.' + req.body._id, { id: req.body.budget }, null, true)
              }
            })
          } else {
            send(reply)
          }
        }
      })
    })
  }

  this.deleteActivity = function (req, mongo, send) {
    var id = req.body._id

    var activity = req.body.activity

    var reply = {}

    var borrar = true
    mongo.findId('plan', id, async (err, result) => {
      if (err) {
        send()
      } else {
        var data = result.activities.data
        await new Promise(resolve => {
          mongo.findOne('time', { plan: result._id, activity: req.body.name }, (err, time) => {
            if (err || time) {
              borrar = false
              reply = { msj: '_cantDeleteUserWithRealTime' } //Usuarios con tiempo Real, no se puede borrar
              resolve()
            } else {
              resolve()
            }
          })
        })
        if (borrar) {
          for (const i in data) {
            if (activity === data[i].activity && data[i].value > 0) {
              borrar = false
              reply = { msj: '_cantDeleteUserWithScheduledTime' } //Usuarios con tiempo Planificado, no se puede borrar
              break
            }
          }
        }
        if (borrar) {
          delete result.activities.activities[activity]
          mongo.save('plan', { _id: id, activities: result.activities }, (err) => {
            if (err) {
              send()
            } else {
              send(reply)
              notification.send(req, req.session.context.room, 'activities.' + req.body._id.toString(), { id: req.body.activity }, null, true)
            }
          })
        } else {
          send(reply)
        }
      }
    })
  }

  this.gantt = function (req, mongo, send) {
    var keys = {
      $and: [
        { plan: mongo.toId(req.query._id) },
        {
          $or: [
            { 'actors.user': req.session.context.user }
          ]
        }]

    }
    if (req.session.context.managerUnits.length > 0) {
      keys.$and[1].$or.push({ unit: { $in: req.session.context.managerUnits } })
    }
    if (req.session.context.assistantUnits.length > 0) {
      keys.$and[1].$or.push({ unit: { $in: req.session.context.assistantUnits } })
    }
    if (req.session.context.dependentUnits.length > 0) {
      keys.$and[1].$or.push({ unit: { $in: req.session.context.dependentUnits } })
    }
    var pipeline = [
      { $match: keys },
      { $project: { name: 1, content: 1, actors: 1, status: 1, startEnd: 1 } },
      { $lookup: { from: 'user', localField: 'actors.user', foreignField: '_id', as: 'user' } },
      { $lookup: { from: 'time', localField: '_id', foreignField: 'project', as: 'time' } },
      { $unwind: '$actors' },
      { $match: { 'actors.type': 'manager' } },
      { $sort: { startEnd: 1 } },
      {
        $project: {
          name: 1,
          content: 1,
          status: 1,
          'user._id': 1,
          'user.name': 1,
          'user.business.workDay': 1,
          owner_id: '$actors.user',
          realDuration: { $sum: '$time.duration' },
          duracion: { $sum: '$content.data.duration' }
        }
      }
    ]
    mongo.findId('plan', mongo.toId(req.query._id), {}, (err, plan) => {
      if (err) throw err
      mongo.aggregate('project', pipeline, { allowDiskUse: true }, async (err, projects) => {
        if (err || !projects) {
          req.statusCode = 404
          send()
        } else {
          var gantt = { data: [], links: [] }
          var resources = []
          for (const i in projects) {
            var project = projects[i]
            gantt.data.push({ // Add project as root task of all subtasks
              id: project._id,
              text: project.name,
              type: 'project',
              duration: project.duration,
              durationReal: project.durationReal,
              owner_id: project.owner_id && project.owner_id !== '' ? [project.owner_id] : [],
              status: project.status,
              progress: project.duracion > project.durationReal ? 1 : project.duracion / project.durationReal
            })
            var tasks = await new Promise((resolve) => {
              mongo.find('task', { project: project._id }, {}, { orden: 1, _id: 1 }, (err, tasks) => {
                if (err) { resolve(false) } else { resolve(tasks) }
              })
            })
            if (tasks) {
              for (let t in tasks) {
                let task = tasks[t]
                if (!task.parent || task.parent === '') { // main tasks will be childs of project task
                  task.parent = project._id
                }
                task.owner_id = task.owner_id && task.owner_id !== '' ? [task.owner_id] : []
                task.start_date = moment(task.start_date).format('YYYY-MM-DD HH:mm')
                task.end_date = moment(task.end_date).format('YYYY-MM-DD HH:mm')
                gantt.data.push(task)
                if (task.links) {
                  gantt.links = gantt.links.concat(task.links)
                }
                /* if (task.calendar) {
                  calendars.push(task.calendar)
                } */
              }

              /* for (const k in project.content.data) {
                var task = project.content.data[k]
                if (!task.parent || task.parent === '') { // main tasks will be childs of project task
                  task.parent = project._id
                }
                task.owner_id = task.owner_id && task.owner_id !== '' ? [task.owner_id] : []
                gantt.data.push(task)
              }
              for (const k in project.content.links) {
                gantt.links.push(project.content.links[k])
              } */
              for (const k in project.user) {
                var user = project.user[k]
                resources.push({ id: user._id, text: user.name, workDay: user.business.workDay })
              }
            }
          }
          send({ id: plan._id, content: { period: plan.period, holydays: plan.holydays, gantt: gantt, resources: resources } })
        }
      })
    })
  }

  this.activityList = async function (req, mongo, send) {
    var id = req.query._id
    await new Promise(resolve => {
      mongo.find('params', { name: 'tagActivity' }, { _id: 1, name: 1, options: 1 }, (err, tagsDoc) => {
        if (err || (tagsDoc && tagsDoc.length === 0)) {
          console.log(err)
          resolve([])
        } else {
          resolve(tagsDoc[0].options)
        }
      })
    })
    let keys = { plan: mongo.toId(id) }
    const query = []
    for (const name in req.query.filter) {
      if (req.query.filter[name].length > 0 && req.query.filter[name] !== 'null') {
        if (name === 'template') {
          query.push( { template: mongo.toId(req.query.filter.template) })
        } else if (name === 'name') {
          query.push({ 'name': new RegExp(req.query.filter.name, 'i') })
        } else if (name === 'tagsname') {
          query.push({ tagActivity: mongo.toId(req.query.filter.tagsname) })
        }
      }
    }
    if (query.length) {
      keys.$and = query
    }
    var pipeline = [
      { $lookup: { from: 'template', localField: 'template', foreignField: '_id', as: 'ttemplate' } },
      { $unwind: '$ttemplate' },
      {
        $lookup: {
          from: 'params',
          pipeline: [
            { $match: { $expr: { $and: [{ $eq: ['$name', 'tagActivity'] }] } } },
            { $project: { _id: 0, options: 1 } }
          ],
          as: 'params'
        }
      },
      { $match: keys },
      {
        $addFields: {
          tag: '$tagActivity',
          param: { $arrayElemAt: [{ $cond:
            {
              if: { $isArray: '$params' },
              then: '$params',
              else: []
            }
          }, 0] }
        }
      },
      { $sort: { _id: -1 } },
      {
        $project: {
          id: '$_id',
          name: 1,
          templateName: '$ttemplate.name',
          tagName: { $ifNull: [{ $arrayElemAt: ['$param.options.value', { $indexOfArray: ['$param.options.id', '$tag'] }] }, ''] },
          tagColor: { $ifNull: [{ $arrayElemAt: ['$param.options.color', { $indexOfArray: ['$param.options.id', '$tag'] }] }, ''] },
        }
      }
    ]
    mongo.aggregate('activity', pipeline, { allowDiskUse: true }, (err, activities) => {
      if (err) {
        throw err
      } else {
        send(activities)
      }
    })
  }

  this.activity = function (req, mongo, send) {
    var id = req.query._id
    mongo.findId('activity', id, (err, activity) => {
      if (err) {
        throw err
      } else if (!activity) {
        activity = {
          _id: mongo.newId()
        }
        send(activity)
      } else {
        send(activity)
      }
    })
  }

  this.saveActivity = function (req, mongo, send) {
    var doc = req.body
    mongo.save('activity', doc, (err) => {
      var reply
      if (err) {
        reply = { error: tags.savingProblema }
      } else {
        reply = { message: tags.savedChanges }
      }
      send(reply)
    })

  }

  this.activityUserList = function (req, mongo, send) {
    let keys = {}
    const query = []
    for (const name in req.query.filter) {
      if (req.query.filter[name].length > 0 && req.query.filter[name] !== 'null') {
        if (name === 'user') {
          query.push( { user: mongo.toId(req.query.filter.user) })
        } else if (name === 'plan') {
          query.push( { plan: mongo.toId(req.query.filter.plan) })
        } else if (name === 'activity') {
          query.push({ 'tactivity.name': new RegExp(req.query.filter.activity, 'i') })
        }
      }
    }
    if (query.length) {
      keys.$and = query
    }
    var pipeline = [
      { $lookup: { from: 'activity', localField: 'activity', foreignField: '_id', as: 'tactivity' } },
      { $unwind: '$tactivity' },
      { $lookup: { from: 'plan', localField: 'plan', foreignField: '_id', as: 'tplan' } },
      { $unwind: '$tplan' },
      { $lookup: { from: 'user', localField: 'user', foreignField: '_id', as: 'tuser' } },
      { $unwind: '$tuser' },
      { $lookup: { from: 'time', localField: 'activity', foreignField: 'doc_id', as: 'ttime' } },
      { $unwind: '$ttime' },
      { $match: keys },
      { $sort: { _id: -1 } },
      {
        '$group': {
          '_id': {
            id: '$_id',
            activityName: '$tactivity.name',
            planName: '$tplan.name',
            userName: '$tuser.name',
            planned: '$planned',
          },
          'real': {
            '$sum': '$ttime.duration'
          }
        }
      },
      {
        $project: {
          '_id': 0,
          id: '$_id.id',
          activityName: '$_id.activityName',
          planName: '$_id.planName',
          userName: '$_id.userName',
          planned: '$_id.planned',
          real: 1
        }
      }
    ]
    mongo.aggregate('activityUser', pipeline, { allowDiskUse: true }, (err, activities) => {
      if (err) {
        throw err
      } else {
        send(activities)
      }
    })
  }

  this.activityUser = function (req, mongo, send) {
    var id = req.query._id
    var pipeline = [
      { $match: { _id: mongo.toId(id)} },
      { $lookup: { from: 'time', localField: 'activity', foreignField: 'doc_id', as: 'ttime' } },
      { $unwind: '$ttime' },
      {
        '$group': {
          '_id': {
            _id: '$_id',
            activity: '$activity',
            plan: '$plan',
            user: '$user',
            planned: '$planned',
          },
          'real': {
            '$sum': '$ttime.duration'
          }
        }
      },
      {
        $project: {
          '_id': 0,
          id: '$_id._id',
          activity: '$_id.activity',
          plan: '$_id.plan',
          user: '$_id.user',
          planned: '$_id.planned',
          real: 1
        }
      }
    ]
    mongo.aggregate('activityUser', pipeline, { allowDiskUse: true }, (err, activity) => {
      if (err) {
        throw err
      } else if (!activity.length) {
        activity = {
          _id: mongo.newId()
        }
        send(activity)
      } else {
        send(activity[0])
      }
    })
  }

  this.saveActivityUser = function (req, mongo, send) {
    var doc = req.body
    mongo.save('activityUser', doc, (err) => {
      var reply
      if (err) {
        reply = { error: tags.savingProblema }
      } else {
        reply = { message: tags.savedChanges }
      }
      send(reply)
    })

  }

  this.reportsTimes = function (req, mongo, send) {
    let keys = {}
    const query = []
    for (const name in req.query.filter) {
      if (req.query.filter[name].length > 0 && req.query.filter[name] !== 'null') {
        if (name === 'user') {
          query.push( { userId: mongo.toId(req.query.filter.user) })
        } else if (name === 'project') {
          query.push( { projectId: mongo.toId(req.query.filter.project) })
        } else if (name === 'task') {
          query.push({ 'actividad/tarea': new RegExp(req.query.filter.task, 'i') })
        } else if (name === 'year') {
          query.push({ 'year': Number(req.query.filter.year) })
        } else if (name === 'month') {
          query.push({ 'month': Number(req.query.filter.month) })
        } else if (name === 'dayOfMonth') {
          query.push({ 'dayOfMonth': Number(req.query.filter.dayOfMonth) })
        } else if (name === 'week') {
          query.push({ 'week': Number(req.query.filter.week) })
        }
      }
    }
    if (query.length) {
      keys.$and = query
    }
    var pipeline = [
      { $limit: 1 },
      {
        $lookup: {
          from: 'activityUser',
          pipeline: [
            { $lookup: { from: 'user', localField: 'user', foreignField: '_id', as: 'tuser' } },
            { $lookup: { from: 'plan', localField: 'plan', foreignField: '_id', as: 'tplan' } },
            { $lookup: { from: 'activity', localField: 'activity', foreignField: '_id', as: 'tactivity' } },
            {
              $addFields: {
                units: { $arrayElemAt: ['$tuser.units', 0] },
              }
            },
            {
              $project: {
                _id: '$_id',
                fecha: { $arrayElemAt: ['$tplan.period.start', 0] },
                tipo: 'activity',
                usuario: { $arrayElemAt: ['$tuser.name', 0] },
                userId: { $arrayElemAt: ['$tuser._id', 0] },
                proyecto: 'Actividades',
                plan: { $arrayElemAt: ['$tplan.name', 0] },
                'actividad/tarea': { $arrayElemAt: ['$tactivity.name', 0] },
                duracionPlan: { $toDouble: '$planned' },
                costo: { $toDouble: '0' },
                projectId: 'activities',
                identify: 'actividadPlan'
              }
            },
          ],
          as: 'plan'
        }
      },
      {
        $lookup: {
          from: 'plan',
          pipeline: [
            {
              $lookup: {
                from: 'project',
                let: { id: '$_id' },
                pipeline: [{$match: {$expr: {$and: [{$eq: ['$plan', '$$id']}]}}}
                ],
                as: 'tproject'
              }
            },
            { $unwind: { path: '$tproject', preserveNullAndEmptyArrays: true } },
            { $unwind: { path: '$tproject.content.data', preserveNullAndEmptyArrays: true } },
            { $lookup: { from: 'user', localField: 'tproject.content.data.owner_id', foreignField: '_id', as: 'tuser'}},
            {
              $project: {
                _id: '$tproject.content.data.id',
                fecha: '$tproject.content.data.end_date',
                tipo: 'task',
                usuario: { $arrayElemAt: ['$tuser.name', 0] },
                userId: { $arrayElemAt: ['$tuser._id', 0] },
                proyecto: '$tproject.name',
                plan: '$name',
                'actividad/tarea': '$tproject.content.data.text',
                duracionPlan: { $toDouble: '$tproject.content.data.duration' },
                costo: { $toDouble: '0' },
                projectId: '$tproject._id',
                identify: 'tareaPlan'
              }
            }
          ],
          as: 'tasksPlan'
        }
      },
      {
        $lookup: {
          from: 'plan',
          pipeline: [
            {
              $lookup: {
                from: 'project',
                let: { id: '$_id' },
                pipeline: [{$match: {$expr: {$and: [{$eq: ['$plan', '$$id']}]}}}
                ],
                as: 'tproject'
              }
            },
            { $unwind: { path: '$tproject', preserveNullAndEmptyArrays: true } },
            { $unwind: { path: '$tproject.content.data', preserveNullAndEmptyArrays: true } },
            {
              $group: {
                _id: '$tproject.content.data.owner_id',
                plans: { $push: '$name' },
                projects: { $push: '$tproject.name' },
                tasks: { $push: '$tproject.content.data.text' },
                plansId: { $push: '$_id' },
                projectsId: { $push: '$tproject._id' },
                tasksId: { $push: '$tproject.content.data.id' }
              }
            },
            { $lookup: { from: 'user', localField: '_id', foreignField: '_id', as: 'tuser' } },
            { $unwind: '$tuser' },
            {
              $lookup: {
                from: 'time',
                let: { id: '$_id', plans: '$plansId' },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $and: [
                          { $eq: ['$user', '$$id'] },
                          { $in: ['$plan', '$$plans']}
                        ]
                      }
                    }
                  }
                ],
                as: 'ttime'
              }
            },
            { $unwind: '$ttime' },
            { $addFields: {
              jornada: { $cond: { if: { $eq: ['', '$tuser.business.workDay'] }, then: '480', else: '$tuser.business.workDay' } } } },
            {
              $project: {
                _id: '$ttime._id',
                fecha: '$ttime.date',
                tipo: '$ttime.type',
                usuario: '$tuser.name',
                userId: '$tuser._id',
                proyecto: {
                  $cond: {
                    if: { $eq: ['$ttime.type', 'task'] },
                    then: { $arrayElemAt: ['$projects', { $indexOfArray: ['$projectsId', '$ttime.project'] }] },
                    else: 'Actividades'
                  }
                },
                plan: { $arrayElemAt: ['$plans', { $indexOfArray: ['$plansId', '$ttime.plan'] }] },
                'actividad/tarea': { $ifNull: ['$ttime.activity', { $arrayElemAt: ['$tasks', { $indexOfArray: ['$tasksId', '$ttime.task'] }] }] },
                duracionReal: { $divide: [{ $toDouble: '$ttime.duration' }, { $toDouble: '$jornada' }] },
                costo: { $toDouble: '$ttime.cost' },
                projectId: '$ttime.project',
                identify: 'Reales'
              }
            }
          ],
          as: 'tasksReal'
        }
      },
      {
        $project: {
          union: {
            $concatArrays: [ '$tasksPlan', '$plan', '$tasksReal' ]
          }
        }
      },
      { $unwind: '$union' },
      { $replaceRoot: { newRoot: '$union' } },
      {
        $addFields: {
          year: {$year: { $toDate: '$fecha' }},
          month: {$month: { $toDate: '$fecha' }},
          dayOfMonth: {$dayOfMonth: { $toDate: '$fecha' }},
          week: {$week: { $toDate: '$fecha' }},
        }
      },
      { $match: keys },
      {
        '$project': {
          _id: 0,
          'task': '$actividad/tarea',
          projectId: 1,
          date: { $dateToString: { format: '%Y-%m-%d', date: { $toDate: '$fecha' }}},
          year: 1,
          month: 1,
          dayOfMonth: 1,
          week: 1,
          userName: '$usuario',
          projectName: '$proyecto',
          userId: '$userId',
          plan: '$plan',
          //planned: { $ifNull: ['$duracionPlan',0]} ,
          duration: { $ifNull: ['$duracionReal', 0] },
          //costo: { $ifNull: ['$costo', 0] }
        }
      }
    ]
    mongo.aggregate('plan', pipeline, { allowDiskUse: true }, (err, times) => {
      if (err) {
        throw err
      } else {
        send(times)
      }
    })
  }
}
