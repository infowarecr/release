/* exported */
var tags = require('../utils/tags').tags
var Notification = require('../utils/notification').Notification
var notification = new Notification()
exports.Process = Process

function Process () {
  this.prochart = function (req, mongo, send) {
    mongo.find('process', {}, { _id: 1, name: 1, actors: 1, parent: 1 }, { name: 1 }, (err, docs) => {
      if (err) send({ error: err })
      else {
        var ids = []
        for (let i = 0; i < docs.length; ++i) {
          var doc = docs[i]
          if (doc.actors && doc.actors.length > 0) {
            ids.push(doc.actors[0].user)
          }
        }
        mongo.toHash('user', { _id: { $in: ids } }, { _id: 1, name: 1 }, (err, hash) => {
          if (err) send({ error: err })
          else {
            var units = []
            for (let i = 0; i < docs.length; ++i) {
              var doc = docs[i]
              if (doc.actors && doc.actors.length > 0 && hash[doc.actors[0].user.toString()]) {
                var manager = hash[doc.actors[0].user.toString()]
                units.push({
                  key: doc._id.toString(),
                  name: doc.name,
                  manager: manager.name,
                  photo: 'user.image?itemId=photo&_id=' + manager._id.toString(),
                  parent: doc.parent ? doc.parent.toString() : ''
                })
              } else {
                units.push({
                  key: doc._id.toString(),
                  name: doc.name,
                  parent: doc.parent ? doc.parent.toString() : ''
                })
              }
            }
          }
        })
      }
    })
  }

  this.setParent=function (req,mongo,send) {
    if (req.body.parent && (req.body.parent.toString() === req.body._id.toString())) {
      req.body.parent = ''
    }
    mongo.save('process', req.body, async (err, result) => {
      if (err) send({ error: err })
      else {
        send(req.body)
        let doc = await new Promise(resolve => {
          mongo.findId('process', req.body._id, {}, (err, process) => {
            resolve(process)
          })
        })
        doc.changueParent = true
        notification.send(req, req.session.context.room, 'processes', doc, null, null)
      }
    })
  }
  this.saveProchart = function (req, mongo, send) {
    var processes = JSON.parse(req.query.processes).nodeDataArray
    if (processes && processes.length > 0) {
      this.procesar(req, mongo, processes, 0, send)
    }
  }

  /** copy processes to the innerdatatable Assessment */
  this.copyProcessesAddInProcess = function (req, mongo, send) {
    var id = req.query._id
    var copyProcesses = req.query.processes
    copyProcesses = copyProcesses.split(',')
    var data = []
    for (const i in copyProcesses) {
      if (mongo.isNativeId(copyProcesses[i])) {
        copyProcesses[i] = mongo.toId(copyProcesses[i])
      }
    }
    //agregar nuevo proceso en calificacion ya en proceso
    mongo.findId('assessment', id, async (err, assessment) => {
      if (err || !assessment) {
        send({ error: err })
      } else {
        let sett = await new Promise(resolve => {
          mongo.findOne('settings', { _id: 'riskScale' }, { riskRanges: 1, impact: 1, probability: 1 }, (err, sett) => {
            if (err) {
              resolve(false)
            } else {
              if (sett) resolve(sett)
              else resolve()
            }
          })
        })
        let msj = ''
        let resultado = true
        for (let u in copyProcesses) {
          resultado = await new Promise(resolve => {
            mongo.findId('process', copyProcesses[u], async (err, process) => {
              if (err || !process) {
                resolve(false)
              } else {
                let data = {}
                data._id = mongo.newId()
                data.name = process.name
                data.user = req.session.context.user
                data.process = process._id
                data.assessment = assessment._id
                //* obtenidos de sett
                data.riskRanges = sett.riskRanges ? sett.riskRanges : ''
                data.impactFactors = sett.impact ? sett.impact : ''
                data.probabilityFactors = sett.probability ? sett.probability : ''
                /** */
                data.probability = String
                data.impact = String
                data.residual = {
                  probability: String,
                  impact: String
                }
                data.risks = []
                if (process.risks && process.risks.selected && process.risks.selected.length > 0 && process.risks.selected !== '[]') {
                  for (const r in process.risks.selected) {
                    var resultado2 = await new Promise(resolve => {
                      mongo.findId('risk', process.risks.selected[r], async (err, risk) => {
                        if (err || !risk) {
                          if (err) console.log(err)
                          resolve('')
                        } else {
                          if (risk.type !== 'control') {
                            risk.probability = String
                            risk.impact = String
                            risk.residual = {
                              probability: String,
                              impact: String
                            }
                          }
                          data.risks.push(risk)
                          resolve(true)
                        }
                      })
                    })
                    if (!resultado2) {
                      break
                    }
                  }
                  if (!resultado2) {
                    msj = 'El proceso ' + process.name + ' tiene riesgos asociados que ya no existen'
                    resolve(false)
                  } else {
                    await new Promise(resolve => {
                      mongo.save('processAssessment', data, () => {
                        resolve()
                      })
                    })
                    resolve(true)
                  }
                } else {
                  msj = 'El proceso ' + process.name + ' no tiene riesgos asociados'
                  resolve(false)
                }
              }
            })
          })
          if (!resultado) {
            break
          }
        }
        if (!resultado) {
          send({ resultado: false, msj: msj })
        } else {
          mongo.find('process', { _id: { $in: copyProcesses } }, {}, {}, async (err, processes) => {
            if (err) throw err
            for (const i in processes) {
              data.push({ id: processes[i]._id, _id: processes[i]._id, name: processes[i].name })
            }
            send(data)
          })
        }
      }
    })
  }

  this.copyProcesses = function (req, mongo, send) {
    var copyProcesses = req.query.processes
    copyProcesses = copyProcesses.split(',')
    var data = []
    for (const i in copyProcesses) {
      if (mongo.isNativeId(copyProcesses[i])) {
        copyProcesses[i] = mongo.toId(copyProcesses[i])
      }
    }
    mongo.find('process', { $or: [{ _id: { $in: copyProcesses } }, { parent: { $in: copyProcesses } }] }, {}, {}, async (err, processes) => {
      if (err) throw err
      let existProcesses = false
      for (const i in processes) {
        if (processes[i].parent !== 0 && processes[i].parent !== '') {
          existProcesses = true
          break
        }
      }
      for (const i in processes) {
        if (existProcesses) {
          if (processes[i].parent !== 0 && processes[i].parent !== '') {
            await this.findChildren(processes[i], data, mongo)
          }
        } else {
          if (processes[i].parent === 0 || processes[i].parent === '' || !processes[i].parent) {
            data.push({ id: processes[i]._id, _id: processes[i]._id, name: processes[i].name })
          }
        }
      }

      send(data)
    })
  }

  //borrar processAssessment
  this.deleteProcessAssessment = function (req, mongo, send) {
    let body = req.query
    mongo.find('processAssessment', { process: mongo.toId(body.process), assessment: mongo.toId(body.assessment) }, {}, (err, proc) => {
      if (err || !proc) {
        if(err) console.log(err)
        send({ error: true })
      } else if (proc) {
        for (let i in proc) {
          mongo.deleteOne('processAssessment', { _id: mongo.toId(proc[i]._id) }, (err, result) => {
            if (err) {
              console.log(err)
              send({ error: true })
              return
            } else {
              req.app.routes.trash.insert(req, mongo, 'processAssessment', proc[i], () => {})
            }
          })
        }
        send()
      }
    })
  }

  this.findChildren = async function (doc, data, mongo) {
    const result = await new Promise(resolve => {
      mongo.find('process', { parent: doc._id }, {}, {}, (err, process) => {
        if (err) {
          console.log(err)
          resolve(false)
        } else {
          if (process.length === 0) {
            resolve(false)
            data.push({ id: doc._id, _id: doc._id, name: doc.name })
          } else if (process.length > 0) {
            resolve(process)
          }
        }
      })
    })
    if (result) {
      for (const p in result) {
        await this.findChildren(result[p], data, mongo)
      }
    }
  }

  this.procesar = function (req, mongo, processes, i, send) {
    if (processes.length > i) {
      var doc = processes[i]
      var id = doc.key
      if (doc.deleted === true) {
        mongo.deleteOne('process', { _id: mongo.toId(id) }, (err, result) => {
          if (err) req.logger.log(err)
          this.procesar(req, mongo, processes, i + 1, send)
        })
      } else {
        if (id.length !== 24) {
          id = mongo.newId()
        }
        mongo.save('process', { _id: id, name: doc.name, parent: doc.parent }, (err, result) => {
          if (err) req.logger.log(err)
          this.procesar(req, mongo, processes, i + 1, send)
        })
      }
    } else {
      send({ message: tags.savedChanges })
      // send({ url: { ref: "process.prochart" } });
    }
  }

  this.get = function (req, mongo, send) {
    var doc = {}
    if (req.query._id) {
      mongo.findId('process', req.query._id, (err, process) => {
        if (!err) {
          doc = process
        } else {
          send()
        }
      })
    } else {
      doc = { _id: mongo.newId(), name: req.query.name }
      if (req.query.parent) {
        doc.parent = req.query.parent
      }
    }
  }

  this.save = async function (req, mongo, send) {
    var doc = req.body
    if (doc.$parent !== '0') {
      doc.parent = doc.$parent
    } else {
      doc.parent = ''
    }
    var process = await new Promise(resolve => {
      mongo.findId('process', doc.id, { _id: 1, risks: 1 }, (err, process) => {
        if (!err) {
          resolve(process)
        } else {
          resolve(false)
        }
      })
    })
    var oldRisks
    if (!process || !process.risks) {
      oldRisks = []
    } else {
      if (process.risks.selected) {
        oldRisks = process.risks.selected
      } else {
        oldRisks = process.risks
      }
    }
    doc._id = mongo.isNativeId(doc.id) ? mongo.toId(doc.id) : mongo.newId()
    var units = []
    var unitsString = doc.units
    units = doc.units.length >= 24 ? doc.units.split(',') : []
    doc.units = []
    for (const i in units) {
      if (units[i].indexOf('[object Object]') === -1) { doc.units.push({ _id: units[i] }) }
    }

    if (doc.toDelete && doc.toDelete.length > 0) {
      var ids = [doc.toDelete[0]]
      var selected = []
      var All = await new Promise(resolve => {
        mongo.find('risk', { $and: [{ parent: doc.toDelete[0] ? mongo.toId(doc.toDelete[0]) : '' }] }, {}, {}, async (err, risks) => {
          if (!err) {
            for (const i in risks) {
              ids.push(risks[i]._id.toString())
              var finds = await new Promise(resolve => {
                mongo.find('risk', { $and: [{ parent: risks[i]._id ? mongo.toId(risks[i]._id) : '' }] }, {}, {}, (err, risks2) => {
                  if (!err) {
                    resolve(risks2)
                  }
                })
              }).catch((err) => console.log(err))
              for (const j in finds) {
                ids.push(finds[j]._id.toString())
              }
            }
            resolve(ids)
          }
        })
      })

      if (All.length > 0) {
        for (const j in doc.risks.selected) {
          if (!All.includes(doc.risks.selected[j])) { selected.push(doc.risks.selected[j]) }
        }
      }
      doc.risks.selected = selected
      delete doc.toDelete
    }
    if (doc.risks.selected.length) {
      for (const r in doc.risks.selected) {
        var risk = await new Promise(resolve => {
          mongo.findId('risk', doc.risks.selected[r], { _id: 1, processes: 1 }, (err, risk) => {
            if (!err) {
              resolve(risk)
            } else {
              resolve(false)
            }
          })
        })
        if (risk) {
          if (risk.processes) {
            var index = risk.processes.findIndex((x) => {
              return x.toString() === doc._id.toString()
            })
            if (index === -1) {
              risk.processes.push(doc._id)
            }
          } else {
            risk.processes = [doc._id]
          }
          await new Promise(resolve => {
            mongo.save('risk', risk, (err, result) => {
              if (!err) {
                resolve(result)
              } else {
                resolve(false)
              }
            })
          })
        }
      }
    }
    if (doc.risks.selected) {
      for (const i in oldRisks) {
        if (doc.risks.selected.findIndex((x) => { return x.toString() === oldRisks[i].toString() }) === -1) {
          const risk = await new Promise(resolve => {
            mongo.findId('risk', oldRisks[i], (err, risk) => {
              if (!err) {
                resolve(risk)
              } else {
                resolve(false)
              }
            })
          })
          if (risk && risk.processes) {
            const index = risk.processes.findIndex((x) => {
              return x.toString() === process._id.toString()
            })
            if (index === -1) {
              risk.processes.push(process._id)
              await new Promise(resolve => {
                mongo.save('risk', risk, (err, result) => {
                  if (!err) {
                    resolve(process)
                  } else {
                    resolve(false)
                  }
                })
              })
            }
          }
        }
      }
    }
    delete doc.open
    delete doc.webix_kids
    delete doc.RI
    delete doc.RR
    delete doc.deleted
    doc.active = parseFloat(doc.active) * 1 !== 0
    if (!doc.active) {
      doc.name = '<span class="inactive">' + doc.name + '</span>'
    } else {
      doc.name = doc.name.replace(/(<([^>]+)>)/g, '')
    }
    if (doc.parent && (doc.parent.toString() === doc._id.toString())) {
      doc.parent = ''
    }
    if (doc.risks && doc.risks.selected && doc.risks.selected.length) {
      await borrar(doc.risks.selected, 0)
      async function borrar (array, i) {
        if (i < array.length) {
          let risk = array[i]
          await new Promise(resolve => {
            mongo.findId('risk', mongo.toId(risk), { _id: 1 }, (err, risk) => {
              if (!err && risk) {
                resolve(true)
              } else {
                array.splice(i, 1)
                resolve(false)
              }
            })
          })
          await borrar(array, i+ 1)
        }
      }
    }
    mongo.save('process', doc, async (err, result) => {
      if (err) {
        send()
      } else {
        // send({ id: doc._id, parent: doc.parent });
        doc.units = unitsString
        send({ doc: doc })
        doc.id = doc._id
        doc.units = unitsString.length >= 24 ? unitsString.split(',') : []
        notification.send(req, req.session.context.room, 'processes', doc, null, null)
      }
    })
  }

  this.list = async function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    var keys
    if (req.query.param === 'onlyActive') {
      keys = { $and: [{ parent: req.query.parent ? mongo.toId(req.query.parent) : '' }, { $or: [{ active: true }, {active: {$exists: 0}}] }] }
    } else {
      keys = { $and: [{ parent: req.query.parent ? mongo.toId(req.query.parent) : '' }] }
    }
    if (req.query.filter && !req.query.parent) {
      const query = {}
      let filter = false
      for (const name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          filter = true
          if (name === 'name') {
            query[name] = {
              $regex: req.query.filter.name, $options: 'i'
            }
          } else if (name === '_id') {
            var ids = req.query.filter[name].split(',')
            for (const i in ids) {
              ids[i] = mongo.toId(ids[i])
            }
            query[name] = { $in: ids }
          } else {
            query[name] = req.query.filter[name].indexOf(',') !== -1 ? { $in: req.query.filter[name].split(',') } : new RegExp(req.query.filter[name].replace(/ /g, '.*'), 'i')
          }
        }
      }
      keys = filter ? query : { $and: [keys, query] }
    }
    mongo.findN('process', skip, limit, keys, {}, { _id: 1 }, (err, proc) => {
      if (err) throw err
      mongo.find('process', {}, {}, {}, async (err, allProc) => {
        if (!err && proc) {
          let riskRanges = await new Promise(resolve => {
            mongo.findId('settings', 'riskScale', {}, { _id: -1 }, (err, assessment) => {
              if (err) {
                resolve(false)
              } else {
                let riskRanges = assessment && assessment.riskRanges ? assessment.riskRanges : false
                resolve(riskRanges)
              }
            })
          })
          for (const i in proc) {
            var proces = proc[i]
            if (proces.parent && (proces.parent.toString() === proces._id.toString())) {
              proces.parent = ''
            }
            proces.$cellCss = {}
            delete proces.webix_kids
            proces.risks = proces.risks || { selected: [], added: [] }
            if (!proces.processTag) { proces.processTag = [] }
            proces.id = proces._id.toString()
            if (proces.units) {
              var units = []
              proces.units.forEach((unt, idx) => {
                units.push(proces.units[idx]._id ? proces.units[idx]._id : proces.units[idx])
              })
              proces.units = units
            }
            const parent = allProc.findIndex((x) => {
              return x.parent && x.parent.toString() === proces.id
            })
            if ((proces.parent === '' && parent !== -1) || (req.query.parent && parent !== -1) || parent !== -1) {
              proces.webix_kids = true
            }
            //puede que el campo venga con 1 o true o que no exista y el resultado sería activo
            if (!proces.active && proces.active !== false && proces.active !== '0') {
              proces.active = true
            }
            if (proces.RI && riskRanges) {
              for (const l in riskRanges) {
                if (parseFloat(proces.RI) >= riskRanges[l].from && parseFloat(proces.RI) <= riskRanges[l].to) {
                  proces.$cellCss.RI = { 'background-color': riskRanges[l].color, color: riskRanges[l].textColor }
                  break
                }
              }
            }
            if (proces.RR && riskRanges) {
              for (const l in riskRanges) {
                if (parseFloat(proces.RR) >= riskRanges[l].from && parseFloat(proces.RR) <= riskRanges[l].to) {
                  proces.$cellCss.RR = { 'background-color': riskRanges[l].color, color: riskRanges[l].textColor }
                  break
                }
              }
            }
            reply.data.push(proces)
          }
          if (skip) {
            if (req.query.parent) {
              send({ parent: req.query.parent, data: reply.data })
            } else {
              send(reply)
            }
          } else {
            mongo.count('process', keys, (err, count) => {
              if (!err && count) {
                reply.total_count = count
              }
              if (req.query.parent) {
                send({ parent: req.query.parent, data: reply.data })
              } else {
                send(reply)
              }
            })
          }
        }
      })
    })
  }

  this.delete = async function (req, mongo, send) {
    var doc = req.query
    var idProcess = mongo.toId(doc._id)
    var pipeline = [
      { $match: { _id: idProcess } },
      {
        $lookup: {

          from: 'project',

          let: { idProcess: '$_id' },

          pipeline: [{

            $match: {

              $expr:

              {
                $in: ['$$idProcess', { $cond: { if: { $isArray: ['$processes'] }, then: '$processes', else: ['$processes'] } }]
              },

              processes: { $exists: true }
            }
          }, { $project: { _id: 1, processes: 1 } }
          ],
          as: 'projects'
        }
      },
      {
        $lookup: {

          from: 'assessment',

          let: { idProcess: '$_id' },

          pipeline: [{

            $match: {

              $expr:

              {
                $in: ['$$idProcess', { $cond: { if: { $isArray: ['$process'] }, then: '$process', else: ['$process'] } }]
              },

              process: { $exists: true }
            }
          }, { $project: { _id: 1, process: 1 } }
          ],
          as: 'assessments'
        }
      },
      {
        $lookup: {

          from: 'auditable',

          let: { idProcess: '$_id' },

          pipeline: [{

            $match: {

              $expr:

              {
                $in: ['$$idProcess', { $cond: { if: { $isArray: ['$processes'] }, then: '$processes', else: ['$processes'] } }]
              },

              processes: { $exists: true }
            }
          }, { $project: { _id: 1, processes: 1 } }
          ],
          as: 'auditables'
        }
      },
      {
        $lookup: {

          from: 'controlAssessment',

          let: { idProcess: '$_id' },

          pipeline: [{

            $match: {

              $expr:

              {
                $in: ['$$idProcess', { $cond: { if: { $isArray: ['$process'] }, then: '$process', else: ['$process'] } }]
              },

              process: { $exists: true }
            }
          }, { $project: { _id: 1, process: 1 } }
          ],
          as: 'controlAssessments'
        }
      },
      {
        $lookup: {

          from: 'processAssessment',

          let: { idProcess: '$_id' },

          pipeline: [{

            $match: {

              $expr:

              {
                $in: ['$$idProcess', { $cond: { if: { $isArray: ['$process'] }, then: '$process', else: ['$process'] } }]
              },

              process: { $exists: true }
            }
          }, { $project: { _id: 1, process: 1 } }
          ],
          as: 'processAssessments'
        }
      },
      {
        $lookup: {

          from: 'riskEvent',

          let: { idProcess: '$_id' },

          pipeline: [{

            $match: {

              $expr:

              {
                $in: ['$$idProcess', { $cond: { if: { $isArray: ['$processes'] }, then: '$processes', else: ['$processes'] } }]
              },

              processes: { $exists: true }
            }
          }, { $project: { _id: 1, processes: 1 } }
          ],
          as: 'riskEvents'
        }
      },

      { $project: { _id: 1, name: 1, projects: 1, assessments: 1, auditables: 1, controlAssessments: 1, processAssessments: 1, riskEvents: 1 } },

      { $sort: { _id: -1 } }
    ]

    var process = await new Promise(resolve => {
      mongo.aggregate('process', pipeline, {}, async (err, process) => {
        if (err) {
          resolve()
        } else {
          resolve(process)
        }
      })
    })
    if (process[0].projects.length ||
      process[0].assessments.length ||
      process[0].auditables.length ||
      process[0].controlAssessments.length ||
      process[0].processAssessments.length ||
      process[0].riskEvents.length) {
      send({ msj: '_cantDeleteProcessAlreadyInUse' }) //El proceso no se puede borrar porque ya ha sido utilizado en el sistema
    } else {
      mongo.findId('process', mongo.toId(doc._id), (err, process) => {
        if (err) {
          send({ error: err })
        } else {
          mongo.deleteOne('process', { _id: mongo.toId(doc._id) }, (err, result) => {
            if (err) {
              req.logger.log(err)
            } else {
              req.app.routes.trash.insert(req, mongo, 'process', process, () => {
                send({ message: tags.savedChanges })
                doc.id = doc._id
                notification.send(req, req.session.context.room, 'processes', doc, null, true)
              })
            }
          })
        }
      })
    }
  }
}
