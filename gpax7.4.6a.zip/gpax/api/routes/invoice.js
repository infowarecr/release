/* global Buffer */
var tags = require('../utils/tags').tags
var Html = require('../utils/html').Html
var imgs = require('../utils/imgsFactura')
var jsonxml = require('jsontoxml')
var fs = require('fs')
var xml2js = require('xml2js')
var parser = new xml2js.Parser()
var request = require('request')
var base64 = require('base-64')
var pdf = require('html-pdf');
var qrcodeNpm = require('qrcode-npm')
var nodemailer = require('nodemailer')
var PDFMake = require('pdfmake/src/printer')
// xmlReader = require('read-xml')
// entities html
const Entities = require('html-entities').AllHtmlEntities
const entities = new Entities()

var Notification = require('../utils/notification').Notification
var notification = new Notification()
// striptags
var striptags = require('striptags')
// eslint-disable-next-line no-undef
var dirname = __dirname.substring(0, __dirname.lastIndexOf('/'))
dirname = dirname.substring(0, dirname.lastIndexOf('/'))

exports.Invoice = Invoice

function Invoice () {
  this.get = function (req, mongo, send) {
    var doc = {}

    if (req.query._id) {
      mongo.findId('invoice', req.query._id, (err, doc) => {
        if (!err && doc.responseXml) {
          var data = {}
          // Obtener solo fecha del string Date
          var dateFact = new Date(doc.date)
          dateFact.setUTCHours(16)
          var dia = dateFact.getDate()
          var mes = dateFact.getMonth() + 1
          var anio = dateFact.getFullYear()
          data.dateFact = String(anio + '-' + mes + '-' + dia)

          mongo.findN('client', 0, 1, { _id: doc.client }, { _id: 1, name: 1, phone: 1, address: 1, codPhone: 1 }, {}, (err, clients) => {
            if (err && !clients) clients = [{}]
            if (!clients[0].phone) clients[0].phone = ''

            var num = parseFloat(doc.total[0].value)

            var separadores = [',']
            var phone = clients[0].phone.split(new RegExp(separadores.join('|'), 'g'))
            data.phone = '+' + clients[0].codPhone + phone[0]
            var desc = doc.data.replace(new RegExp('<p>', 'g'), '')
            data.detailDiscount = doc.detailDiscount ? doc.detailDiscount : ''
            data.descript = doc.detail + ' ' + desc + ' ' + doc.detailDiscount + ' '
            var ref = 'PARA PAGO POR TRANSFERENCIA:</br>'
            ref += '<dir>CUENTA EN COLONES: 15201255000384749, INFOWARE S. A. BANCO DE COSTA RICA</br>'
            ref += 'CUENTA EN DÓLARES: 15201255000445557, INFOWARE S. A. BANCO DE COSTA RICA</br>'
            ref += 'INTERNACIONAL A TRAVES DEL BANCO DE COSTA RICA, CÓDIGO SWIFT BCRICRSJ</dir>'
            data.ref = ref

            data.numberFact = doc.number.slice(10, 20)
            var tipdoc = doc.number.slice(8, 10)
            data.discount = doc.discount ? parseFloat(doc.discount) : 0
            var totalFact = num - doc.discount
            data.totalFact = arreglar(totalFact) + ' ' + doc.total[0].currency
            data.discount = doc.discount === 0 ? '' : doc.discount
            data.address = clients[0].address
            data.name = clients[0].name

            switch (tipdoc) {
            case '01':
              tipdoc = 'Factura electrónica'
              break

            default:
              // code
            }
            data.tipdoc = tipdoc
            data.key = doc.key
            data.number = doc.number
            data.amounts = doc.amounts + doc.discount
            data.company = doc.company
            send(data)
          })
        } else if (doc && !doc.responseXml) {
          data = {}
          data._id = doc._id
          data.number = doc.number
          data.key = doc.key
          data.items = doc.items
          data.client = doc.client
          data.product = doc.product
          data.codProduct = doc.codProduct
          data.medPago = doc.medPago
          data.detail = doc.detail
          data.data = doc.data
          data.type = doc.type
          data.discount = doc.discount
          data.detailDiscount = doc.detailDiscount
          data.status = doc.status
          data.amounts = doc.amounts
          data.value = doc.total ? doc.total[0].value : ''
          data.currency = doc.total ? doc.total[0].currency : ''
          data.tax = doc.tax
          data.typeDoc = doc.typeDoc
          data.codeActivity = doc.codeActivity
          data.company = doc.company
          send([data])
        } else {
          send()
        }
      })
    } else {
      doc = { _id: mongo.newId() }
      doc.typeDoc = req.query.type
      doc.codeActivity = '721001'
      send(doc)
    }
  }

  this.print = function (req, mongo, send) {
    mongo.findId(req.query.collection, req.query._id, (err, doc) => {
      if (err) send({ error: err })
      else {
        if (doc) {
          // creacion qr code
          var imgTag = ''
          if (doc.key) {
            var qr = qrcodeNpm.qrcode(4, 'M')
            qr.addData(doc.key)
            qr.make()
            imgTag = qr.createImgTag(3)
          }

          // Obtener solo fecha del string Date
          var hoy = new Date(doc.date)
          hoy.setUTCHours(16)
          var dia = hoy.getDate()
          var mes = hoy.getMonth() + 1
          var anio = hoy.getFullYear()
          hoy = String(anio + '-' + mes + '-' + dia)

          mongo.findN('client', 0, 1, { _id: doc.client }, { _id: 1, name: 1, phone: 1, address: 1, codPhone: 1 }, {}, (err, clients) => {
            if (err || !clients || clients.length === 0) clients = [{ name: '', address: '' }]
            if (!clients[0] && !clients[0].phone) clients[0].phone = ''

            var num = parseFloat(doc.total[0].value)

            var separadores = [',']
            var phone = clients[0].phone ? clients[0].phone.split(new RegExp(separadores.join('|'), 'g')) : ''

            var desc = doc.data.replace(new RegExp('<p>', 'g'), '')
            doc.detailDiscount = doc.detailDiscount ? doc.detailDiscount : ''

            var description = doc.detail + ' ' + desc + '<p>' + doc.detailDiscount + '</p>'

            var ref = 'Cuentas IBAN:</br>'
            ref += 'Colones: <b>CR36015201255000384749</b></br>'
            ref += 'Dólares: <b>CR42015201255000445557</b></br>'

            var number = doc.number.slice(10, 20)
            var tipdoc = doc.number.slice(8, 10)
            doc.discount = doc.discount ? parseFloat(doc.discount) : 0
            var total = num - doc.discount
            doc.discount = doc.discount === 0 ? '' : doc.discount
            var montos = '<p>' + doc.total[0].value + '</p>' + arreglar(doc.discount)

            if (doc.items) {
              doc.detailDiscount = ''
              doc.discount = 0
              doc.amountTax = 0
              doc.detail = ''
              total = 0
              montos = ''
              for (const i in doc.items) {
                if (montos) montos += ' </p>'
                doc.detail = doc.detail + '-' + doc.items[i].detail + '</br>'
                if (i === 0) doc.detail = doc.detail + ' ' + desc + '</br>'
                total = total + parseFloat(doc.items[i].total)
                montos = montos + arreglar(doc.items[i].total) + ' '
                if (doc.items[i].discount && doc.items[i].discount !== '') {
                  doc.detail = doc.detail + '*' + doc.items[i].detailDiscount + '</br>'
                  doc.discount = doc.discount + parseFloat(doc.items[i].discount)
                  montos = montos + '</p>' + '-' + arreglar(doc.items[i].discount)
                }
                if (doc.items[i].amountTax && doc.items[i].amountTax !== '') {
                  doc.detail = doc.detail + '*IVA </br>'
                  if ((doc.items[i].netTax && doc.items[i].netTax !== '') || (doc.items[i].netTax && doc.items[i].netTax === 0)) {
                    doc.amountTax = doc.amountTax + parseFloat(doc.items[i].netTax)
                  } else {
                    doc.amountTax = doc.amountTax + parseFloat(doc.items[i].amountTax)
                  }
                  montos = montos + '</p>' + arreglar(doc.items[i].amountTax)
                }
                if ((doc.items[i].netTax && doc.items[i].netTax !== '') || (doc.items[i].netTax && doc.items[i].netTax === 0)) {
                  let detailExoneration
                  switch (doc.items[i].typeExoneration) {
                  case '01':
                    detailExoneration = 'Compras autorizadas'
                    break
                  case '02':
                    detailExoneration = 'Ventas exentas a diplomáticos'
                    break
                  case '03':
                    detailExoneration = 'Autorizado por Ley especial'
                    break
                  case '04':
                    detailExoneration = 'Exenciones Dirección General de Hacienda'
                    break
                  case '05':
                    detailExoneration = 'Transitorio V'
                    break
                  case '06':
                    detailExoneration = 'Transitorio IX'
                    break
                  case '07':
                    detailExoneration = 'Transitorio XVII'
                    break
                  case '99':
                    detailExoneration = 'Otros'
                    break
                  default:
                    break
                  }
                  doc.detail = doc.detail + '*Exoneración: ' + detailExoneration + ' </br>'
                  montos = montos + '</p>' + '-' + arreglar(doc.items[i].amountExoneration)
                }
              }
              description = doc.detail + '</br>' + desc
              if (doc.discount === 0) delete doc.discount
              else total = total - doc.discount
              if (doc.amountTax !== 0) {
                total = total + doc.amountTax
              } else {
                delete doc.amountTax
              }
            }
            total = Math.round(total * 100000) / 100000
            total = total.toFixed(2)
            switch (tipdoc) {
            case '01':
              tipdoc = 'Factura electrónica'
              break

            case '03':
              tipdoc = 'Nota Crédito electrónica'
              break

            case '04':
              tipdoc = 'Tiquete electrónico'
              break

            case '08':
              tipdoc = 'Factura electrónica C'
              break
            case '09':
              tipdoc = 'Factura electrónica E'
              break

            default:
              // code
            }

            if (doc.tipDoc) {
              var tipDocRef
              switch (doc.tipDoc) {
              case '01':
                tipDocRef = 'Factura electrónica'
                break

              case '03':
                tipDocRef = 'Nota Crédito electrónica'
                break

              case '04':
                tipDocRef = 'Tiquete electrónico'
                break

              case '08':
                tipDocRef = 'Factura electrónica C'
                break
              case '09':
                tipDocRef = 'Factura electrónica E'
                break

              default:
                // code
              }
            }

            if (doc.codRef) {
              var codRef
              switch (doc.codRef) {
              case '01':
                codRef = 'Anula documento'
                break

              case '02':
                codRef = 'Corrige texto'
                break

              case '03':
                codRef = 'Corrige monto'
                break

              default:
                // code
              }
            }
            clients[0].codPhone = clients[0].codPhone ? '+' + clients[0].codPhone : ''
            phone = clients[0].codPhone !== '' ? clients[0].codPhone + phone[0] : ''

            var body = '<div class="div-template">'
            // body += '<div class="factura" style="height:584px; width:984px;">'
            body += '<div class="div-number">' + number + '</div>'
            body += '<div class="div-tipDoc">' + tipdoc + ' - Contado</div>'
            body += tipDocRef ? '<div class="div-tipDocRef">' + tipDocRef + '</div>' : ''
            body += codRef ? '<div class="div-codRef">' + codRef + '</div>' : ''
            body += tipDocRef ? '<div class="div-keyN">' + doc.key.substring(0, 25) + '<br>' + doc.key.substring(25, 50) + '</div>' : '<div class="div-key">' + doc.key.substring(0, 25) + '<br>' + doc.key.substring(25, 50) + '</div>'
            body += tipDocRef ? '<div class="div-numberConsN">' + doc.number + '</div>' : '<div class="div-numberCons">' + doc.number + '</div>'
            body += '<div class="div-name">' + clients[0].name + '</div>'
            body += '<div class="div-fecha">' + hoy + '</div>'
            body += '<div class="div-address">' + clients[0].address + '</div>'
            body += '<div class="div-phone">' + phone + '</div>'
            body += '<div class="div-data">' + description + '</div>'
            body += '<div class="div-qr">' + imgTag + '</div>'
            body += '<div class="div-amounts">' + montos + '</div>'
            body += '<div class="div-value">' + arreglar(total) + ' ' + doc.total[0].currency + '</div>'
            body += '</div>'

            if (!doc.received) doc.received = '0'
            if (!doc.retained) doc.retained = '0'

            var voucherXml = ''

            var responseXml = ''

            try {
              if (doc.voucherXml) voucherXml = base64.decode(doc.voucherXml)
              if (doc.responseXml) responseXml = base64.decode(doc.responseXml)
              send({
                body: body,
                _id: doc._id,
                received: doc.received,
                retained: doc.retained,
                voucherXml: voucherXml,
                responseXml: responseXml
              })
            } catch (error) {
              send({
                body: body,
                _id: doc._id,
                received: doc.received,
                retained: doc.retained,
                voucherXml: voucherXml,
                responseXml: responseXml
              })
            }
          })
        } else {
          send(new Html().print(''))
        }
      }
    })
  }

  this.sendEmail = function (req, mongo, send) {
    var id = req.query._id
    //var bitmap = fs.readFileSync(dirname + '/ui/img/factura2.png')
    //var imagen = Buffer.from(bitmap).toString('base64')
    mongo.findId(req.query.collection, id, (err, inv) => {
      if (err && !inv) inv = {}
      // Obtener solo fecha del string Date
      var hoy = new Date(inv.date)
      hoy.setUTCHours(16)
      var dia = hoy.getDate()
      var mes = hoy.getMonth() + 1
      var anio = hoy.getFullYear()
      hoy = String(anio + '-' + mes + '-' + dia)

      mongo.findN('client', 0, 1, { _id: inv.client }, { _id: 1, name: 1, phone: 1, address: 1, codPhone: 1, clientEmail: 1 }, {}, (err, clients) => {
        if (err && !clients) clients = [{}]
        if (clients && clients[0].clientEmail && clients[0].clientEmail !== '') {
          if (!clients[0].phone) clients[0].phone = ''
          var num = parseFloat(inv.total[0].value)
          var separadores = [',']
          var phone = clients[0].phone.split(new RegExp(separadores.join('|'), 'g'))

          // creacion qr code
          var imgTag = ''
          if (inv.key) {
            var qr = qrcodeNpm.qrcode(4, 'M')
            qr.addData(inv.key)
            qr.make()
            imgTag = qr.createImgTag(3)
          }

          var desc = inv.data.replace(new RegExp('<p>', 'g'), '')
          inv.detailDiscount = inv.detailDiscount ? inv.detailDiscount : ''

          var description = inv.detail + ' ' + desc + '<p>' + inv.detailDiscount + '</p>'
          //description = description.replace(new RegExp('<br>', 'g'), '\n')
          description = entities.decode(description)
          description = striptags(description)

          var number = inv.number.slice(10, 20)
          var tipdoc = inv.number.slice(8, 10)
          inv.discount = inv.discount ? parseFloat(inv.discount) : 0
          var total = num - inv.discount
          inv.discount = inv.discount === 0 ? '' : inv.discount
          var montos = '<p>' + inv.total[0].value + '</p>' + arreglar(inv.discount)

          if (inv.items) {
            inv.detailDiscount = ''
            inv.discount = 0
            inv.amountTax = 0
            inv.detail = ''
            total = 0
            montos = ''
            for (const i in inv.items) {
              if (montos) montos += ' </p>'
              inv.detail = inv.detail + '-' + inv.items[i].detail + '</br>'
              if (i === 0) inv.detail = inv.detail + ' ' + desc + '</br>'
              total = total + parseFloat(inv.items[i].total)
              montos = montos + arreglar(inv.items[i].total) + '</br>'
              if (inv.items[i].discount && inv.items[i].discount !== '') {
                inv.detail = inv.detail + '*' + inv.items[i].detailDiscount + '</br>'
                inv.discount = inv.discount + parseFloat(inv.items[i].discount)
                montos = montos + '</p>' + '-' + arreglar(inv.items[i].discount)
              }
              if (inv.items[i].amountTax && inv.items[i].amountTax !== '') {
                inv.detail = inv.detail + '*IVA </br>'
                if ((inv.items[i].netTax && inv.items[i].netTax !== '') || (inv.items[i].netTax && inv.items[i].netTax === 0)) {
                  inv.amountTax = inv.amountTax + parseFloat(inv.items[i].netTax)
                } else {
                  inv.amountTax = inv.amountTax + parseFloat(inv.items[i].amountTax)
                }
                montos = montos + '</p>' + arreglar(inv.items[i].amountTax)
              }
              if ((inv.items[i].netTax && inv.items[i].netTax !== '') || (inv.items[i].netTax && inv.items[i].netTax === 0)) {
                let detailExoneration
                switch (inv.items[i].typeExoneration) {
                case '01':
                  detailExoneration = 'Compras autorizadas'
                  break
                case '02':
                  detailExoneration = 'Ventas exentas a diplomáticos'
                  break
                case '03':
                  detailExoneration = 'Autorizado por Ley especial'
                  break
                case '04':
                  detailExoneration = 'Exenciones Dirección General de Hacienda'
                  break
                case '05':
                  detailExoneration = 'Transitorio V'
                  break
                case '06':
                  detailExoneration = 'Transitorio IX'
                  break
                case '07':
                  detailExoneration = 'Transitorio XVII'
                  break
                case '99':
                  detailExoneration = 'Otros'
                  break
                default:
                  break
                }
                inv.detail = inv.detail + '*Exoneración: ' + detailExoneration + ' \n'
                montos = montos + '</p>' + '-' + arreglar(inv.items[i].amountExoneration)
              }
            }
            description = inv.detail + '</p>' + desc
            if (inv.discount === 0) delete inv.discount
            else total = total - inv.discount
            if (inv.amountTax !== 0) {
              total = total + inv.amountTax
            } else {
              delete inv.amountTax
            }
          }
          total = Math.round(total * 100000) / 100000
          total = total.toFixed(2)
          switch (tipdoc) {
          case '01':
            tipdoc = 'Factura electrónica'
            break

          case '03':
            tipdoc = 'Nota Crédito electrónica'
            break

          case '04':
            tipdoc = 'Tiquete electrónico'
            break

          case '08':
            tipdoc = 'Factura electrónica C'
            break
          case '09':
            tipdoc = 'Factura electrónica E'
            break

          default:
            // code
          }

          if (inv.tipDoc) {
            var tipDocRef
            switch (inv.tipDoc) {
            case '01':
              tipDocRef = 'Factura electrónica'
              break

            case '03':
              tipDocRef = 'Nota Crédito electrónica'
              break

            case '04':
              tipDocRef = 'Tiquete electrónico'
              break

            case '08':
              tipDocRef = 'Factura electrónica C'
              break
            case '09':
              tipDocRef = 'Factura electrónica E'
              break

            default:
              // code
            }
          }

          if (inv.codRef) {
            var codRef
            switch (inv.codRef) {
            case '01':
              codRef = 'Anula documento'
              break

            case '02':
              codRef = 'Corrige texto'
              break

            case '03':
              codRef = 'Corrige monto'
              break

            default:
              // code
            }
          }

          clients[0].codPhone = clients[0].codPhone ? '+' + clients[0].codPhone : ''
          phone = clients[0].codPhone !== '' ? clients[0].codPhone + phone[0] : ''
          total = arreglar(total) + ' ' + inv.total[0].currency

          mongo.findOne('settings', { _id: 'settings' }, {}, async (err, account) => {
            if (err && !account) account = {}
            var password
            try {
              password = tags.util.Decipher(account.password)
            } catch (err) {
              password = ''
            }
            const transporter = nodemailer.createTransport({
              host: account.smtp,
              port: account.port,
              secure: true, // true for 465, false for other ports
              auth: {
                user: account.user,
                pass: password
              },
              tls: {
                rejectUnauthorized: false
              }
            })

            const content = `
            <!doctype html>
                <html>
                  <head>
                        <meta charset="utf-8">
                        <title>Factura</title>
                        <style>
                          .img {
                              background-image: url(`+ imgs.imgs.factura + `);
                              background-repeat: no-repeat;
                              background-color: #FFF;
                          }
                           
                          .div-template {
                            position: absolute;
                            z-index: 99;
                          }
                          .div-number {
                            position: absolute;
                            transform: rotate(270deg)!important;  
                            -ms-transform:rotate(270deg); /* IE 9 */
                            -moz-transform:rotate(270deg); /* Firefox */
                            -webkit-transform:rotate(270deg); /* Safari and Chrome */
                            -o-transform:rotate(270deg); /* Opera */
                            width: 92px;
                            height: 27px;
                            left: 13px;
                            top: 330px;
                            z-index: 99;
                            color: #AC2722;
                            font-size: 40px;
                            font-weight: bolder;
                            text-align: right;
                          }
                          .div-key {
                              position: absolute;
                              width: 295px;
                              height: 40px;
                              left: 598px;
                              top: 46px;
                              z-index: 99;
                              color: black;
                              font-size: 14px;
                          }

                          .div-numberCons {
                              position: absolute;
                              width: 295px;
                              height: 27px;
                              left: 642px;
                              top: 92px;
                              z-index: 99;
                              color: black;
                              font-size: 14px;
                          }

                          .div-tipDoc {
                              position: absolute;
                              width: 400px;
                              height: 27px;
                              left: 420px;
                              top: 5px;
                              z-index: 99;
                              color: #00ACD0;
                              font-size: 16px;
                              font-weight: bolder;
                              text-align: right;
                          }

                          .div-name {
                              position: absolute;
                              width: 225px;
                              height: 40px;
                              left: 136px;
                              top: 227px;
                              z-index: 99;
                              font-size: 12px;
                          }
                          .div-fecha {
                              position: absolute;
                              width: 150px;
                              height: 40px;
                              left: 600px;
                              top: 227px;
                              z-index: 99;
                              font-size: 12px;
                          }

                          .div-address {
                              position: absolute;
                              width: 226px;
                              height: 40px;
                              left: 368px;
                              top: 227px;
                              z-index: 99;
                              font-size: 12px;
                          }

                          .div-phone {
                              position: absolute;
                              width: 120px;
                              height: 40px;
                              left: 770px;
                              top: 227px;
                              font-size: 12px;
                              z-index: 99;
                              overflow: hidden;
                          }

                          .div-data {
                              position: absolute;
                              width: 590px;
                              height: 200px;
                              left: 136px;
                              top: 320px;
                              z-index: 99;
                              font-size: 13px;
                          }

                          .div-amounts {
                              position: absolute;
                              width: 70px;
                              height: 200px;
                              left: 765px;
                              top: 320px;
                              z-index: 99;
                              text-align: right;
                              white-space: pre-line;
                              line-height: 0.7;
                          }

                          .div-value {
                              position: absolute;
                              width: 120px;
                              height: 14px;
                              left: 735px;
                              top: 544px;
                              z-index: 99;
                              color: white;
                              text-align: center;
                              font-weight: bold;
                              font-size: 11px;
                          }

                          .div-qr {
                              position: absolute;
                              width: 60px;
                              height: 60px;
                              left: 820px;
                              top: 0px;
                              z-index: 99;
                          }

                          .div-cond {
                              position: absolute;
                              width: 100px;
                              height: 100px;
                              left: 573px;
                              top: 95px;
                              color: #00ACD0;
                              z-index: 99;
                              font-size: 12px;
                          }
                          .div-ref {
                              position: absolute;
                              width: 656px;
                              height: 428px;
                              left: 48px;
                              top: 476px;
                              color: #00ACD0;
                              font-size: 10px;
                              z-index: 99;
                          }
                        </style>
                  </head>
                  <body>
                      <div class="div-template">
                        <div class="img" style="height:790px; width:990px;">
                          <div class="div-number">` + number + `</div>
                          <div class="div-tipDoc">` + tipdoc + ` - Contado</div>
                          <div class="div-key">` + inv.key.substring(0, 25) + '<br>' + inv.key.substring(25, 50) + `</div>
                          <div class="div-numberCons">` + inv.number + `</div>
                          <div class="div-name">` + clients[0].name + `</div>
                          <div class="div-fecha">` + hoy + `</div>
                          <div class="div-address">` + clients[0].address + `</div>
                          <div class="div-phone">` + phone + `</div>
                          <div class="div-data">` + description + `</div>
                          <div class="div-qr">` + imgTag + `</div>
                          <div class="div-amounts">` + montos + `</div>
                          <div class="div-value">` + total + `</div>
                        </div>
                      </div>
                  </body>
              </html>
            `;

            const contentN = `
            <!doctype html>
                <html>
                  <head>
                        <meta charset="utf-8">
                        <title>Factura</title>
                        <style>
                          .note {
                              background-image: url(`+ imgs.imgs.note + `);
                              background-repeat: no-repeat;
                              background-color: #FFF;
                          }
                           
                          .div-template {
                            position: absolute;
                            z-index: 99;
                          }
                          .div-number {
                            position: absolute;
                            transform: rotate(270deg)!important;  
                            -ms-transform:rotate(270deg); /* IE 9 */
                            -moz-transform:rotate(270deg); /* Firefox */
                            -webkit-transform:rotate(270deg); /* Safari and Chrome */
                            -o-transform:rotate(270deg); /* Opera */
                            width: 92px;
                            height: 27px;
                            left: 13px;
                            top: 330px;
                            z-index: 99;
                            color: #AC2722;
                            font-size: 40px;
                            font-weight: bolder;
                            text-align: right;
                          }

                          .div-key {
                              position: absolute;
                              width: 295px;
                              height: 40px;
                              left: 598px;
                              top: 52px;
                              z-index: 99;
                              color: black;
                              font-size: 14px;
                          }

                          .div-numberCons {
                              position: absolute;
                              width: 295px;
                              height: 27px;
                              left: 642px;
                              top: 102px;
                              z-index: 99;
                              color: black;
                              font-size: 14px;
                          }

                          .div-tipDoc {
                              position: absolute;
                              width: 400px;
                              height: 27px;
                              left: 420px;
                              top: 5px;
                              z-index: 99;
                              color: #00ACD0;
                              font-size: 16px;
                              font-weight: bolder;
                              text-align: right;
                          }

                          .div-tipDocRef {
                              position: absolute;
                              width: 200px;
                              height: 27px;
                              left: 700px;
                              top: 157px;
                              z-index: 99;
                              font-size: 16px;
                              text-align: right;
                          }

                          .div-codRef {
                              position: absolute;
                              width: 200px;
                              height: 27px;
                              left: 650px;
                              top: 130px;
                              z-index: 99;
                              font-size: 16px;
                              text-align: right;
                          }

                          .div-name {
                              position: absolute;
                              width: 225px;
                              height: 40px;
                              left: 136px;
                              top: 227px;
                              z-index: 99;
                              font-size: 12px;
                          }
                          .div-fecha {
                              position: absolute;
                              width: 150px;
                              height: 40px;
                              left: 600px;
                              top: 227px;
                              z-index: 99;
                              font-size: 12px;
                          }

                          .div-address {
                              position: absolute;
                              width: 226px;
                              height: 40px;
                              left: 368px;
                              top: 227px;
                              z-index: 99;
                              font-size: 12px;
                          }

                          .div-phone {
                              position: absolute;
                              width: 120px;
                              height: 40px;
                              left: 770px;
                              top: 227px;
                              font-size: 12px;
                              z-index: 99;
                              overflow: hidden;
                          }

                          .div-data {
                              position: absolute;
                              width: 590px;
                              height: 200px;
                              left: 136px;
                              top: 320px;
                              z-index: 99;
                              font-size: 13px;
                          }

                          .div-amounts {
                              position: absolute;
                              width: 70px;
                              height: 200px;
                              left: 765px;
                              top: 320px;
                              z-index: 99;
                              text-align: right;
                              white-space: pre-line;
                              line-height: 0.7;
                          }

                          .div-value {
                              position: absolute;
                              width: 120px;
                              height: 14px;
                              left: 735px;
                              top: 544px;
                              z-index: 99;
                              color: white;
                              text-align: center;
                              font-weight: bold;
                              font-size: 11px;
                          }

                          .div-qr {
                              position: absolute;
                              width: 60px;
                              height: 60px;
                              left: 820px;
                              top: 0px;
                              z-index: 99;
                          }

                          .div-cond {
                              position: absolute;
                              width: 100px;
                              height: 100px;
                              left: 573px;
                              top: 95px;
                              color: #00ACD0;
                              z-index: 99;
                              font-size: 12px;
                          }
                          .div-ref {
                              position: absolute;
                              width: 656px;
                              height: 428px;
                              left: 48px;
                              top: 476px;
                              color: #00ACD0;
                              font-size: 10px;
                              z-index: 99;
                          }
                        </style>
                  </head>
                  <body>
                      <div class="div-template">
                        <div class="note" style="height:790px; width:990px;">
                          <div class="div-number">` + number + `</div>
                          <div class="div-tipDoc">` + tipdoc + ` - Contado</div>
                          <div class="div-tipDocRef">` + tipDocRef + `</div>
                          <div class="div-codRef">` + codRef + `</div>
                          <div class="div-key">` + inv.key.substring(0, 25) + '<br>' + inv.key.substring(25, 50) + `</div>
                          <div class="div-numberCons">` + inv.number + `</div>
                          <div class="div-name">` + clients[0].name + `</div>
                          <div class="div-fecha">` + hoy + `</div>
                          <div class="div-address">` + clients[0].address + `</div>
                          <div class="div-phone">` + phone + `</div>
                          <div class="div-data">` + description + `</div>
                          <div class="div-qr">` + imgTag + `</div>
                          <div class="div-amounts">` + montos + `</div>
                          <div class="div-value">` + total + `</div>
                        </div>
                      </div>
                  </body>
              </html>
            `;

            let opts = {
              'height': '820px', // allowed units: mm, cm, in, px
              'width': '1000px',
              'orientation': 'landscape', // portrait or landscape
              'border': {
                'top': '15px', // default is 0, units: mm, cm, in, px
                'right': '5px',
                'bottom': '5px',
                'left': '5px'
              },
            }

            let htmlEmail = tipDocRef ? contentN : content

            let buffer = await new Promise(resolve => {
              pdf.create(htmlEmail, opts).toBuffer(function (err, buffer) {
                resolve(buffer)
              });
            })

            var attachment = []
            attachment.push({
              filename: 'Factura' + number + '.pdf',
              type: 'application/pdf',
              content: buffer
            })
            if (inv.voucherXml) {
              attachment.push({
                // utf-8 string as an attachment
                filename: 'FacturaXML' + number + '.xml',
                content: base64.decode(inv.voucherXml)
              })
            }
            if (inv.responseXml) {
              attachment.push({
                // utf-8 string as an attachment
                filename: 'RespuestaXML' + number + '.xml',
                content: base64.decode(inv.responseXml)
              })
            }

            // setup email data with unicode symbols
            const message = {
              from: account.user, // sender address
              to: clients[0].clientEmail, // list of receivers adriana@infowarecr.com
              subject: 'Infoware S.A Factura Electrónica N' + number + '', // Subject line
              // text: 'Hello world?', // plain text body
              html: '<p>Se adjuntan documentos de factura electrónica FacturaN' + number + '</p></br><p>Atentamente Infoware S.A</p>',
              attachments: attachment
            }

            // send mail with defined transport object
            transporter.sendMail(message, (error, info) => {
              if (error) {
                console.log(error)
                send({ err: error, status: 404 })
                notification.saveSystemNotification(req, mongo, null, "Error al enviar correo: " + error.message)
              } else {
                console.log('Message sent: %s', info.messageId)
                mongo.save(req.query.collection, { _id: mongo.toId(req.query._id), sent: 'yes' }, (err, result) => {
                  if (err) {
                    send({ error: err })
                  } else {
                    send()
                  }
                })
              }
            })
          })
        } else {
          send({ status: 500 })
        }
      }
      )
    })
  }

  this.save = function (req, mongo, send) {
    var doc = req.body

    var dt = new Date()
    var time = dt.toTimeString()
    dt = dt.toISOString()
    dt = dt.split('T', 1)
    dt = dt + 'T' + time
    doc.date = dt.split(' ', 1) + '-06:00'
    doc.user = req.session.context.user

    doc.total = []
    doc.total.push({
      value: 0,
      currency: doc.currency,
      type: 'invoiced'
    })
    if (doc.value1) {
      doc.total.push({
        value: doc.value1,
        currency: doc.currency,
        type: 'paid'
      })
    }
    doc.data = doc.data.replace(new RegExp('&nbsp;', 'g'), ' ')

    delete doc.currency
    delete doc.value
    delete doc.value1
    mongo.findId('invoice', doc._id, (err, invOriginal) => {
      mongo.findN('invoice', 0, 1, { company: doc.company, typeDoc: doc.typeDoc }, { number: 1, _id: 1 }, { _id: -1 }, (err, invs) => {
        if (err) return
        mongo.findOne('company', { idNum: doc.company }, (err, company) => {
          if (err) {
            send(err)
          }
          if (!invs || !company) {
            req.statusCode = 500
            send()
          } else {
            if (invOriginal && invOriginal.number) {
              doc.number = invOriginal.number
            } else if (!doc.number) {
              var num = '0000000001'
              if (invs[0] && invs[0].number.slice(10, 20)) {
                num = invs[0].number.slice(10, 20)
                var n = parseInt(num, 10)
                n = n + 1
                num = n.toString()
                num = pad(num, 10)
              }
              // Information for Electronic invoice
              // local o establecimiento
              var casaMatriz = company.establishment
              // Terminal o punto de venta
              var terminal = company.station
              // tipo de comprobante
              var tipComp = doc.typeDoc
              // numero consecutivo
              doc.number = casaMatriz + terminal + tipComp + num
            }

            // *******Clave numerica*******
            // codigo del pais
            var codPais = '506'
            var date = new Date()
            // dia
            var day = date.getDate()
            if (day < 10) {
              day = pad(day, 2)
            }
            day = day.toString()
            // mes
            var month = date.getMonth() + 1
            if (month < 10) {
              month = pad(month, 2)
            }
            month = month.toString()
            // año
            var year = date.getFullYear()
            year = year.toString()
            year = year.slice(2, 4)
            // cedula emisor
            if (company.idType === '01') {
              var ced = '000' + company.idNum
            } else if (company.idType === '02' || company.idType === '04') {
              ced = '00' + company.idNum
            } else if (company.idType === '03') {
              if (company.idNum.length === 12) ced = company.idNum
              else ced = '0' + company.idNum
            }
            // situacion del comprobante
            var sitComp = '1'
            // codigo de seguridad
            var codSeg = company.code
            // clave numerica
            doc.key = codPais + day + month + year + ced + doc.number + sitComp + codSeg

            mongo.save('invoice', doc, (err, result) => {
              if (err) {
                req.logger.log(err)
              } else {
                send({ id: doc._id })
                notification.send(req, req.session.context.room, 'dt_invoices', { id: doc._id })
              }
            })
          }
        })
      })
    })
  }

  this.savePaid = function (req, mongo, send) {
    var body = req.body

    mongo.save('invoice', body, (err, result) => {
      if (err) {
        req.logger.log(err)
      } else {
        send({ id: body._id })
      }
    })
  }
  this.cancel = function (req, mongo, send) {
    var id = mongo.toId(req.query._id)
    mongo.save('invoice', { _id: id, status: 'canceled' }, (err, result) => {
      if (err) { return err } else { send() }
    })
  }
  this.count = async function (req, mongo, send) {
    var keys = {}
    if (!req.session.context.createUsers) {
      var compaResult = await new Promise((resolve, reject) => {
        mongo.find('company', { users: { $in: [req.session.context.user] } }, { _id: 0, idNum: 1 }, (err, coms) => {
          if (err) reject(err)
          else {
            var arrayC = []
            for (const i in coms) {
              arrayC.push(coms[i].idNum)
            }
            resolve(arrayC)
          }
        })
      }).catch((err) => console.log(err))
      keys = { $or: [{ company: { $in: compaResult } }, { user: req.session.context.user }] }
    }
    mongo.count('invoice', keys, (err, count) => {
      if (err) {
        req.statusCode = 404
        send()
      } else {
        send({ count: count })
      }
    })
  }
  this.pending = async function (req, mongo, send) {
    var keys = { statusHacienda: { $nin: ['rechazado', 'inconsistente', 'aceptado'] } }
    if (!req.session.context.createUsers) {
      var compaResult = await new Promise((resolve, reject) => {
        mongo.find('company', { userId: req.session.context.user }, { _id: 0, idNum: 1 }, (err, coms) => {
          if (err) reject(err)
          else {
            var arrayC = []
            for (const i in coms) {
              arrayC.push(coms[i].idNum)
            }
            resolve(arrayC)
          }
        })
      }).catch((err) => console.log(err))
      keys = { $and: [{ company: { $in: compaResult } }, { statusHacienda: { $nin: ['rechazado', 'inconsistente', 'aceptado'] } }] }
    }
    mongo.count('invoice', keys, (err, count) => {
      if (err) {
        req.statusCode = 404
        send()
      } else {
        send({ count: count })
      }
    })
  }
  this.list2 = async function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    var keys
    let query
    if (req.query.filter) {
      query={}
      for (const name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          if (name === 'number') {
            query.number = new RegExp(req.query.filter[name], 'i')
          } else if (name === 'statusHacienda') {
            if (req.query.filter[name] === 'sin verificar') query.statusHacienda = { $exists: 0 }
            else query.statusHacienda = req.query.filter[name]
          } else if (name === 'status') {
            query.status = req.query.filter[name]
          } else if (name === 'company' || name === 'companyName') {
            query.company = req.query.filter[name]
          } else if (name === 'currency') {
            query['total.0.currency'] = req.query.filter[name]
          } else if (name === 'date') {
            query.fechaDocumento = new RegExp(req.query.filter[name], 'i')
          } else if (name === 'client') {
            query.client = mongo.toId(req.query.filter.client)
          } else {
            query[name] =
              req.query.filter[name].indexOf(',') !== -1
                ? { $in: req.query.filter[name].split(',') }
                : new RegExp(req.query.filter[name].replace(/ /g, '.*'), 'i')
          }
        }
      }
      keys = query
    }
    var compaResult = await new Promise((resolve, reject) => {
      mongo.find('company', { userId: req.session.context.user }, { _id: 0, idNum: 1 }, (err, coms) => {
        if (err) reject(err)
        else {
          var arrayC = []
          for (const i in coms) {
            arrayC.push(coms[i].idNum)
          }
          resolve(arrayC)
        }
      })
    }).catch((err) => console.log(err))
    keys = query
      ? { $and: [{ $or: [{ company: { $in: compaResult } }, { user: req.session.context.user }] }, query] }
      : { $or: [{ company: { $in: compaResult } }, { user: req.session.context.user }] }
    mongo.findN('invoice', skip, limit, keys, {}, { _id: -1 }, (err, invoices) => {
      if (err) {
        send({ error: err })
      } else {
        var clientId = []
        for (const i in invoices) {
          clientId.push(invoices[i].client)
        }
        mongo.toHash('client', { _id: { $in: clientId } }, { _id: 1, name: 1 }, (err, client) => {
          if (err && !client) client = {}
          else {
            mongo.find('company', {}, {}, {}, async (err, companies) => {
              if (err && !companies) companies = {}
              else {
                for (const i in invoices) {
                  if (!invoices[i].company) {
                    var num = parseFloat(invoices[i].total[0].value)
                    var discount = invoices[i].discount ? parseFloat(invoices[i].discount) : 0
                    var total = num - discount
                    if (invoices[i].items) {
                      total = 0
                      for (const t in invoices[i].items) {
                        discount = invoices[i].items[t].discount ? parseFloat(invoices[i].items[t].discount) : 0
                        total = total + parseFloat(invoices[i].items[t].total) - discount
                        if (invoices[i].items[t].netTax && invoices[i].items[t].netTax !== '') {
                          total = total + parseFloat(invoices[i].items[t].netTax)
                        } else if (invoices[i].items[t].amountTax && invoices[i].items[t].amountTax !== '') {
                          total = total + parseFloat(invoices[i].items[t].amountTax)
                        }
                      }
                    }
                    total = total.toFixed(2)
                    invoices[i].id = invoices[i]
                    invoices[i].received = invoices[i].received ? arreglar(invoices[i].received) : ''
                    invoices[i].retained = invoices[i].retained ? arreglar(invoices[i].retained) : ''
                    invoices[i].clientId = invoices[i].client
                    invoices[i].client = client[invoices[i].client.toString()] ? client[invoices[i].client.toString()].name : ''
                    invoices[i].date = tags.util.date2str(invoices[i].date, 'DD-MM-YYYY', tags)
                    var recordDate = tags.util.date2str(invoices[i]._id.getTimestamp(), 'DD-MM-YYYY', tags)
                    invoices[i].recordDate = recordDate
                    invoices[i].processDate = invoices[i].processDate
                      ? tags.util.date2str(invoices[i].processDate, 'DD-MM-YYYY', tags)
                      : recordDate
                    invoices[i].responseXml = !!invoices[i].responseXml
                    if (!invoices[i].sent) invoices[i].sent = 'no'
                    if (!invoices[i].statusHacienda && invoices[i].responseXml) invoices[i].statusHacienda = 'aceptado'
                    else if (!invoices[i].statusHacienda && !invoices[i].responseXml) invoices[i].statusHacienda = 'sin verificar'
                    reply.data.push(invoices[i])
                  } else {
                    invoices[i].id = invoices[i]._id.toString()
                    invoices[i].currency = invoices[i].total[0] ? invoices[i].total[0].currency : ''
                    let total = 0
                    if (invoices[i].items) {
                      for (const t in invoices[i].items) {
                        discount = invoices[i].items[t].discount ? parseFloat(invoices[i].items[t].discount) : 0
                        total = total + parseFloat(invoices[i].items[t].total) - discount
                        if (invoices[i].items[t].netTax && invoices[i].items[t].netTax !== '') {
                          total = total + parseFloat(invoices[i].items[t].netTax)
                        } else if (invoices[i].items[t].amountTax && invoices[i].items[t].amountTax !== '') {
                          total = total + parseFloat(invoices[i].items[t].amountTax)
                        }
                      }
                    }
                    total = Math.round(total * 100000) / 100000
                    total = total.toFixed(2)
                    total = arreglar(total)
                    invoices[i].value = total
                    if (invoices[i].voucherXml) invoices[i].voucherXml = base64.decode(invoices[i].voucherXml)
                    invoices[i].client = client[invoices[i].client].name
                    invoices[i].date = tags.util.date2str(new Date(invoices[i].date), 'DD-MM-YYYY', tags)
                    recordDate = tags.util.date2str(invoices[i]._id.getTimestamp(), 'DD-MM-YYYY', tags)
                    invoices[i].companyName = await new Promise(resolve => {
                      var name = ''
                      for (var c in companies) {
                        if (companies[c].idNum === invoices[i].company) {
                          name = companies[c].name
                          break
                        }
                      }
                      resolve(name)
                    })
                    invoices[i].recordDate = recordDate
                    invoices[i].processDate = invoices[i].processDate
                      ? tags.util.date2str(invoices[i].processDate, 'DD-MM-YYYY', tags)
                      : recordDate
                    if (invoices[i].responseXml) invoices[i].responseXml = base64.decode(invoices[i].responseXml)
                    if (!invoices[i].sent) invoices[i].sent = 'no'
                    if (!invoices[i].statusHacienda && invoices[i].responseXml) invoices[i].statusHacienda = 'aceptado'
                    else if (!invoices[i].statusHacienda && !invoices[i].responseXml) invoices[i].statusHacienda = 'sin verificar'
                    reply.data.push(invoices[i])
                  }
                }
                if (skip) {
                  send(reply)
                } else {
                  mongo.count('invoice', keys, (err, count) => {
                    if (err) {
                      send(err)
                    } else {
                      reply.total_count = count
                      send(reply)
                    }
                  })
                }
              }
            })
          }
        })
      }
    })
  }
  this.list = async function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    var keys
    if (req.query.ebill) {
      keys = {}
    } else {
      keys = { user: req.session.context.user }
    }
    let query = {}
    if (req.query.filter) {
      for (const name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          if (name === 'number') {
            if (req.query.ebill) {
              query.consecutivoTemporal = req.query.filter[name]
            } else {
              query.number = new RegExp(req.query.filter[name], 'i')
            }
          } else if (name === 'statusHacienda') {
            if (req.query.filter[name] === 'sin verificar') query.statusHacienda = { $exists: 0 }
            else query.statusHacienda = req.query.filter[name]
          } else if (name === 'status') {
            if (req.query.ebill) {
              if (req.query.filter[name] === 'no enviada') query.responseXml = { $exists: 0 }
              else query.responseXml = { $exists: 1 }
            } else {
              query.status = req.query.filter[name]
            }
          } else if (name === 'company' || name === 'companyName') {
            query.company = req.query.filter[name]
          } else if (name === 'currency') {
            if (req.query.ebill) {
              query.Moneda = req.query.filter[name]
            } else {
              query['total.0.currency'] = req.query.filter[name]
            }
          } else if (name === 'date') {
            query.fechaDocumento = new RegExp(req.query.filter[name], 'i')
          } else if (name === 'client') {
            keys.client = mongo.toId(req.query.filter.client)
          } else {
            query[name] =
              req.query.filter[name].indexOf(',') !== -1
                ? { $in: req.query.filter[name].split(',') }
                : new RegExp(req.query.filter[name].replace(/ /g, '.*'), 'i')
          }
        }
      }
      keys = req.query.ebill?query:{ $and: [keys, query] }
    }
    if (!req.session.context.createUsers && req.query.ebill) {
      var compaResult = await new Promise((resolve, reject) => {
        mongo.find('company', { users: { $in: [req.session.context.user] } }, { _id: 0, idNum: 1 }, (err, coms) => {
          if (err) reject(err)
          else {
            var arrayC = []
            for (const i in coms) {
              arrayC.push(coms[i].idNum)
            }
            resolve(arrayC)
          }
        })
      }).catch((err) => console.log(err))
      keys = {
        $and: [
          { $or: [{ company: { $in: compaResult } }, { user: req.session.context.user }] },
          query
        ]
      }
    }
    mongo.findN('invoice', skip, limit, keys, {}, { _id: -1 }, (err, invoices) => {
      if (err) {
        send({ error: err })
      } else {
        var clientId = []
        for (const i in invoices) {
          clientId.push(invoices[i].client)
        }
        mongo.toHash('client', { _id: { $in: clientId } }, { _id: 1, name: 1 }, (err, client) => {
          if (err && !client) client = {}
          else {
            mongo.find('company', {}, {}, {}, async (err, companies) => {
              if (err && !companies) companies = {}
              else {
                for (const i in invoices) {
                  if (invoices[i].number) {
                    var num = parseFloat(invoices[i].total[0].value)
                    var discount = invoices[i].discount ? parseFloat(invoices[i].discount) : 0
                    var total = num - discount
                    if (invoices[i].items) {
                      total = 0
                      for (const t in invoices[i].items) {
                        discount = invoices[i].items[t].discount ? parseFloat(invoices[i].items[t].discount) : 0
                        total = total + parseFloat(invoices[i].items[t].total) - discount
                        if (invoices[i].items[t].netTax && invoices[i].items[t].netTax !== '') {
                          total = total + parseFloat(invoices[i].items[t].netTax)
                        } else if (invoices[i].items[t].amountTax && invoices[i].items[t].amountTax !== '') {
                          total = total + parseFloat(invoices[i].items[t].amountTax)
                        }
                      }
                    }
                    total = total.toFixed(2)
                    invoices[i].id = invoices[i]._id.toString()
                    invoices[i].currency = invoices[i].total[0].currency
                    invoices[i].value = arreglar(total)
                    invoices[i].received = invoices[i].received ? arreglar(invoices[i].received) : ''
                    invoices[i].retained = invoices[i].retained ? arreglar(invoices[i].retained) : ''
                    invoices[i].clientId = invoices[i].client
                    invoices[i].client = client[invoices[i].client.toString()] ? client[invoices[i].client.toString()].name : ''
                    invoices[i].date = tags.util.date2str(invoices[i].date, 'yyyy-mm-dd', tags)
                    var recordDate = tags.util.date2str(invoices[i]._id.getTimestamp(), 'yyyy-mm-dd HH:MM:ss', tags)
                    invoices[i].recordDate = recordDate
                    invoices[i].processDate = invoices[i].processDate
                      ? tags.util.date2str(invoices[i].processDate, 'yyyy-mm-dd HH:MM:ss', tags)
                      : recordDate
                    invoices[i].responseXml = !!invoices[i].responseXml
                    if (!invoices[i].sent) invoices[i].sent = 'no'
                    if (!invoices[i].statusHacienda && invoices[i].responseXml) invoices[i].statusHacienda = 'aceptado'
                    else if (!invoices[i].statusHacienda && !invoices[i].responseXml) invoices[i].statusHacienda = 'sin verificar'
                    reply.data.push(invoices[i])
                  } else {
                    invoices[i].id = invoices[i]._id.toString()
                    invoices[i].currency = invoices[i].Moneda
                    if (invoices[i].enviada || invoices[i].response === 524 || invoices[i].responseXml) invoices[i].status = 'enviada'
                    else invoices[i].status = 'no enviada'
                    invoices[i].number = invoices[i].consecutivoTemporal
                    invoices[i].value = arreglar(invoices[i].TotalComprobante)
                    invoices[i].key = invoices[i].clave
                    if (invoices[i].voucherXml) invoices[i].voucherXml = base64.decode(invoices[i].voucherXml)
                    invoices[i].client = invoices[i].Receptor.Nombre
                    invoices[i].date = invoices[i].fechaDocumento instanceof Date ? tags.util.date2str(invoices[i].fechaDocumento, 'yyyy-mm-dd', tags) : ''
                    recordDate = tags.util.date2str(invoices[i]._id.getTimestamp(), 'yyyy-mm-dd HH:MM:ss', tags)
                    invoices[i].companyName = await new Promise(resolve => {
                      var name = ''
                      for (var c in companies) {
                        if (companies[c].idNum === invoices[i].company) {
                          name = companies[c].name
                          break
                        }
                      }
                      resolve(name)
                    })
                    invoices[i].recordDate = recordDate
                    invoices[i].processDate = invoices[i].processDate
                      ? tags.util.date2str(invoices[i].processDate, 'yyyy-mm-dd HH:MM:ss', tags)
                      : recordDate
                    if (invoices[i].responseXml) invoices[i].responseXml = base64.decode(invoices[i].responseXml)
                    if (!invoices[i].sent) invoices[i].sent = 'no'
                    if (!invoices[i].statusHacienda && invoices[i].responseXml) invoices[i].statusHacienda = 'aceptado'
                    else if (!invoices[i].statusHacienda && !invoices[i].responseXml) invoices[i].statusHacienda = 'sin verificar'
                    reply.data.push(invoices[i])
                  }
                }
                if (skip) {
                  send(reply)
                } else {
                  mongo.count('invoice', keys, (err, count) => {
                    if (err) {
                      send(err)
                    } else {
                      reply.total_count = count
                      send(reply)
                    }
                  })
                }
              }
            })
          }
        })
      }
    })
  }

  this.xml = function (req, mongo, send) {
    var chilkat = require('@chilkat/ck-node14-linux64')
    var body = req.query
    var tipoCredit = false
    var cli
    body._id = mongo.toId(body._id)
    mongo.findId(body.collection, body._id, (err, invoice) => {
      if (err || !invoice) invoice = {}
      mongo.findOne('company', { idNum: invoice.company }, (err, environment) => {
        if (err && !environment) environment = {}
        if (invoice.client) cli = invoice.client
        else cli = ''
        mongo.findId('client', cli, (err, client) => {
          if (err && !client) client = {}
          mongo.findId('product', invoice.product, (err, product) => {
            if (err && !product) product = {}
            var data = invoice.data.replace(new RegExp('<p>', 'g'), '')
            data = data.replace(new RegExp('</p>', 'g'), ' ')

            if (invoice.typeDoc === '03') {
              // invoice.discount ? descuento = true : descuento = descuento
              tipoCredit = true
            }

            if (invoice.typeDoc === '01' || invoice.typeDoc === '04' || invoice.typeDoc === '08' || invoice.typeDoc === '09') {
              // invoice.discount || invoice.discount !== '' ? descuento = true : descuento = descuento
            }

            function decimal (n) {
              var total
              n = n.split('.', 2)
              if (n.length > 1) {
                var dec = pader(n[1], 5)
                total = n[0] + '.' + dec
              } else {
                total = n + '.00000'
              }
              return total
            }
            // detalle fact
            var listItems = []
            var descuentoTotal = 0
            var impuestoTotal = 0
            var totalFactura = 0
            var TotalServGravados = 0.0
            var TotalServExentos = 0.0
            var TotalServExonerado = 0.0
            var TotalMercanciasGravadas = 0.0
            var TotalMercanciasExentas = 0.0
            var TotalMercExonerada = 0.0
            for (const i in invoice.items) {
              var cantidad = 1.0
              var preciounitario = parseFloat(invoice.items[i].total)
              var montototal = Math.round((cantidad * preciounitario) * 100000) / 100000
              totalFactura = totalFactura + montototal
              var montodesc = invoice.items[i].discount && invoice.items[i].discount !== '' ? parseFloat(invoice.items[i].discount) : 0.0
              descuentoTotal = Math.round((descuentoTotal + montodesc) * 100000) / 100000
              var subtotal = Math.round((montototal - montodesc) * 100000) / 100000
              var impuesto = invoice.items[i].amountTax && invoice.items[i].amountTax !== '' ? parseFloat(invoice.items[i].amountTax) : 0.0
              if ((impuesto !== 0 && invoice.items[i].netTax && invoice.items[i].netTax !== '') || (invoice.items[i].netTax && invoice.items[i].netTax === 0)) {
                impuesto = parseFloat(invoice.items[i].netTax)
                TotalServExonerado = TotalServExonerado + ((parseFloat(invoice.items[i].percExoneration) / 100) * montototal)
                TotalServGravados += (1 - (parseFloat(invoice.items[i].percExoneration) / 100)) * montototal
                // fecha exoneracion
              } else if (impuesto > 0) {
                TotalServGravados += montototal
              } else {
                TotalServExentos += montototal
              }
              if (!invoice.items[i].dateExoneration) {
                invoice.items[i].dateExoneration = invoice.date
              }
              impuestoTotal = Math.round((impuestoTotal + impuesto) * 100000) / 100000
              var montototalinea = Math.round((subtotal + impuesto) * 100000) / 100000
              listItems.push({
                name: 'LineaDetalle',
                children: [
                  { name: 'NumeroLinea', text: parseInt(i) + 1 },
                  invoice.items[i].tariffItem && invoice.items[i].tariffItem !== '' ? { name: 'PartidaArancelaria', text: invoice.items[i].tariffItem } : {},
                  invoice.items[i].codeP_S && invoice.items[i].codeP_S !== '' ? { name: 'Codigo', text: invoice.items[i].codeP_S } : {},
                  invoice.items[i].codProduct && invoice.items[i].codProduct !== ''
                    ? {
                      name: 'CodigoComercial',
                      children: [
                        // tipo codigo a utilizar --> Código del producto del vendedor 01
                        { name: 'Tipo', text: '01' },
                        { name: 'Codigo', text: invoice.items[i].codProduct }
                      ]
                    }
                    : {},
                  { name: 'Cantidad', text: cantidad.toString() + '.000' },
                  // ********----******//
                  { name: 'UnidadMedida', text: 'Sp' },
                  { name: 'Detalle', text: omitirAcentos(invoice.items[i].detail) },
                  { name: 'PrecioUnitario', text: decimal(preciounitario.toString()) },
                  { name: 'MontoTotal', text: decimal(montototal.toString()) },
                  invoice.items[i].discount && invoice.items[i].discount !== ''
                    ? {
                      name: 'Descuento',
                      children: [
                        { name: 'MontoDescuento', text: decimal(montodesc.toString()) },
                        { name: 'NaturalezaDescuento', text: omitirAcentos(invoice.items[i].detailDiscount) }
                      ]
                    } : {},
                  { name: 'SubTotal', text: decimal(subtotal.toString()) },
                  invoice.items[i].taxableBase && invoice.items[i].taxableBase !== '' ? { name: 'BaseImponible', text: decimal(invoice.items[i].taxableBase.toString()) } : {},
                  invoice.items[i].amountTax && invoice.items[i].amountTax !== ''
                    ? {
                      name: 'Impuesto',
                      children: [
                        invoice.items[i].codTax && invoice.items[i].codTax !== '' ? { name: 'Codigo', text: invoice.items[i].codTax } : {},
                        invoice.items[i].codRate && invoice.items[i].codRate !== '' ? { name: 'CodigoTarifa', text: invoice.items[i].codRate } : {},
                        invoice.items[i].rate && invoice.items[i].rate !== '' ? { name: 'Tarifa', text: invoice.items[i].rate } : {},
                        invoice.items[i].IVA && invoice.items[i].IVA !== '' ? { name: 'FactorIVA', text: invoice.items[i].IVA } : {},
                        invoice.items[i].amountTax && invoice.items[i].amountTax !== '' ? { name: 'Monto', text: decimal(invoice.items[i].amountTax.toString()) } : {},
                        invoice.items[i].amountExportation && invoice.items[i].amountExportation !== '' ? { name: 'MontoExportacion', text: decimal(invoice.items[i].amountExportation.toString()) } : {},
                        invoice.items[i].typeExoneration && invoice.items[i].typeExoneration !== '' ? {
                          name: 'Exoneracion',
                          children: [
                            { name: 'TipoDocumento', text: invoice.items[i].typeExoneration },
                            { name: 'NumeroDocumento', text: invoice.items[i].numExoneration },
                            { name: 'NombreInstitucion', text: omitirAcentos(invoice.items[i].institutionExoneration) },
                            { name: 'FechaEmision', text: invoice.items[i].dateExoneration },
                            { name: 'PorcentajeExoneracion', text: invoice.items[i].percExoneration },
                            { name: 'MontoExoneracion', text: decimal(invoice.items[i].amountExoneration.toString()) }
                          ]
                        } : {}
                      ]
                    } : {},
                  invoice.items[i].netTax && invoice.items[i].netTax !== '' ? { name: 'ImpuestoNeto', text: decimal(invoice.items[i].netTax.toString()) } : {},
                  { name: 'MontoTotalLinea', text: decimal(montototalinea.toString()) }
                ]
              })
            }

            // resumen fact
            var TotalGravado = Math.round((TotalServGravados + TotalMercanciasGravadas) * 100000) / 100000
            var TotalExento = Math.round((TotalServExentos + TotalMercanciasExentas) * 100000) / 100000
            var TotalExonerado = Math.round((TotalServExonerado + TotalMercExonerada) * 100000) / 100000
            var TotalVenta = Math.round((TotalGravado + TotalExento + TotalExonerado) * 100000) / 100000
            var TotalDescuentos = descuentoTotal
            var TotalVentaNeta = Math.round((TotalVenta - TotalDescuentos) * 100000) / 100000
            var TotalImpuestos = impuestoTotal
            var TotalComprobante = Math.round((TotalVentaNeta + TotalImpuestos) * 100000) / 100000
            var decodeData = entities.decode(data)
            var plainData = striptags(decodeData)
            // plainData = plainData.replace(/\s{2,}/g, ' ')

            var arrayXml = [
              { name: 'Clave', text: invoice.key },
              { name: 'CodigoActividad', text: invoice.codeActivity },
              { name: 'NumeroConsecutivo', text: invoice.number },
              { name: 'FechaEmision', text: invoice.date },
              {
                name: 'Emisor',
                children: [
                  { name: 'Nombre', text: omitirAcentos(environment.name) },
                  {
                    name: 'Identificacion',
                    children: [{ name: 'Tipo', text: environment.idType }, { name: 'Numero', text: environment.idNum }]
                  },
                  {
                    name: 'Ubicacion',
                    children: [
                      { name: 'Provincia', text: environment.province },
                      { name: 'Canton', text: environment.canton },
                      { name: 'Distrito', text: environment.district },
                      { name: 'OtrasSenas', text: omitirAcentos(environment.signs) }
                    ]
                  },
                  {
                    name: 'Telefono',
                    children: [{ name: 'CodigoPais', text: environment.codPhone }, { name: 'NumTelefono', text: environment.phone }]
                  },
                  { name: 'CorreoElectronico', text: environment.email }
                ]
              },
              client && client.name && client.name !== ''
                ? {
                  name: 'Receptor',
                  children: [
                    { name: 'Nombre', text: omitirAcentos(client.name) },
                    client.idNum && client.idNum !== ''
                      ? {
                        name: 'Identificacion',
                        children: [{ name: 'Tipo', text: client.idType }, { name: 'Numero', text: client.idNum }]
                      }
                      : {},
                    client.codPhone && client.codPhone !== ''
                      ? {
                        name: 'Telefono',
                        children: [{ name: 'CodigoPais', text: client.codPhone }, { name: 'NumTelefono', text: client.phone }]
                      }
                      : {},
                    client.clientEmail && client.clientEmail !== '' ? { name: 'CorreoElectronico', text: client.clientEmail } : {}
                  ]
                }
                : {},
              // siempre contado 01
              { name: 'CondicionVenta', text: '01' },
              // solo si es a credito { name: 'PlazoCredito', text: '15' },
              { name: 'MedioPago', text: invoice.medPago },
              {
                name: 'DetalleServicio',
                children: listItems
              },
              {
                name: 'ResumenFactura',
                children: [
                  invoice.total[0].currency && invoice.total[0].currency !== 'CRC' ? {
                    name: 'CodigoTipoMoneda',
                    children: [
                      { name: 'CodigoMoneda', text: invoice.total[0].currency },
                      { name: 'TipoCambio', text: decimal(invoice.currencyExchange.toString()) }
                    ]
                  } : {},
                  { name: 'TotalServGravados', text: decimal(TotalServGravados.toString()) },
                  { name: 'TotalServExentos', text: decimal(TotalServExentos.toString()) },
                  invoice.typeDoc !== '09' ? { name: 'TotalServExonerado', text: decimal(TotalServExonerado.toString()) } : {},
                  { name: 'TotalMercanciasGravadas', text: decimal(TotalMercanciasGravadas.toString()) },
                  { name: 'TotalMercanciasExentas', text: decimal(TotalMercanciasExentas.toString()) },
                  invoice.typeDoc !== '09' ? { name: 'TotalMercExonerada', text: decimal(TotalMercExonerada.toString()) } : {},
                  { name: 'TotalGravado', text: decimal(TotalGravado.toString()) },
                  { name: 'TotalExento', text: decimal(TotalExento.toString()) },
                  invoice.typeDoc !== '09' ? { name: 'TotalExonerado', text: decimal(TotalExonerado.toString()) } : {},
                  { name: 'TotalVenta', text: decimal(TotalVenta.toString()) },
                  TotalDescuentos !== 0 ? { name: 'TotalDescuentos', text: decimal(TotalDescuentos.toString()) } : {},
                  { name: 'TotalVentaNeta', text: decimal(TotalVentaNeta.toString()) },
                  TotalImpuestos !== 0 ? { name: 'TotalImpuesto', text: decimal(TotalImpuestos.toString()) } : {},
                  { name: 'TotalComprobante', text: decimal(TotalComprobante.toString()) }
                ]
              },
              tipoCredit
                ? {
                  name: 'InformacionReferencia',
                  children: [
                    { name: 'TipoDoc', text: invoice.tipDoc },
                    { name: 'Numero', text: invoice.keyRef },
                    { name: 'FechaEmision', text: invoice.dateRef },
                    { name: 'Codigo', text: invoice.codRef },
                    { name: 'Razon', text: omitirAcentos(invoice.reasonRef) }
                  ]
                }
                : {},
              {
                name: 'Otros',
                children: [{ name: 'OtroTexto', text: omitirAcentos(plainData) }]
              }
            ]

            var xml, x, i, l
            if (invoice.typeDoc === '01') {
              xml = jsonxml(
                {
                  FacturaElectronica: arrayXml
                },
                { xmlHeader: true }
              )

              x = xml.split('FacturaElectronica', 2)
              i = x[0] + 'FacturaElectronica xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/facturaElectronica"'
              l = i + x[1]
              l = l + 'FacturaElectronica>'
            } else if (invoice.typeDoc === '04') {
              xml = jsonxml(
                {
                  TiqueteElectronico: arrayXml
                },
                { xmlHeader: true }
              )

              x = xml.split('TiqueteElectronico', 2)
              i = x[0] + 'TiqueteElectronico xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/tiqueteElectronico"'
              l = i + x[1]
              l = l + 'TiqueteElectronico>'
            } else if (invoice.typeDoc === '03') {
              xml = jsonxml(
                {
                  NotaCreditoElectronica: arrayXml
                },
                { xmlHeader: true }
              )

              x = xml.split('NotaCreditoElectronica', 2)
              i = x[0] + 'NotaCreditoElectronica xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/notaCreditoElectronica"'
              l = i + x[1]
              l = l + 'NotaCreditoElectronica>'
            } else if (invoice.typeDoc === '08') {
              xml = jsonxml(
                {
                  FacturaElectronicaCompra: arrayXml
                },
                { xmlHeader: true }
              )

              x = xml.split('FacturaElectronicaCompra', 2)
              i = x[0] + 'FacturaElectronicaCompra xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/facturaElectronicaCompra"'
              l = i + x[1]
              l = l + 'FacturaElectronicaCompra>'
            } else if (invoice.typeDoc === '09') {
              xml = jsonxml(
                {
                  FacturaElectronicaExportacion: arrayXml
                },
                { xmlHeader: true }
              )

              x = xml.split('FacturaElectronicaExportacion', 2)
              i = x[0] + 'FacturaElectronicaExportacion xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/facturaElectronicaExportacion"'
              l = i + x[1]
              l = l + 'FacturaElectronicaExportacion>'
            }

            fs.writeFile('/tmp/' + invoice.key + '.xml', l, (err, result) => {
              if (err) {
                console.log(err)
              }
              chilkatExample()
              firmar()
              // FIRMAR
              function firmar () {
                var fileId = environment.description.split('?_id=')[1]
                fileId = fileId.split('&')[0]
                req.app.routes.file.get({ _id: fileId, type: 'p12' }, mongo, (result) => {
                  var tmp = '/tmp/' + result.filename
                  var file = fs.createWriteStream(tmp)
                  file.on('finish', async function () {
                    var cert = new chilkat.Cert()
                    var success = cert.LoadPfxFile(tmp, environment.pin)
                    if (success !== true) {
                      send({ error: 'wrongCrypt', message: 'Ocurrio un error al abrir el certificado ' + cert.LastErrorText })
                      console.log(cert.LastErrorText)
                      return
                    }

                    // Load XML to be signed.
                    var sbXml = new chilkat.StringBuilder()
                    success = sbXml.LoadFile('/tmp/' + invoice.key + '.xml', 'utf-8')
                    if (success !== true) {
                      send({ error: 'wrongCrypt', message: 'Ocurrio un error al cargar la factura' })
                      console.log('Failed to load file.')
                      return
                    }

                    var gen = new chilkat.XmlDSigGen()

                    // Indicate where the signature is to be placed.
                    gen.SigLocation = invoice.typeDoc === '01' ? 'FacturaElectronica'
                      : invoice.typeDoc === '04' ? 'TiqueteElectronico'
                        : invoice.typeDoc === '08' ? 'FacturaElectronicaCompra'
                          : invoice.typeDoc === '09' ? 'FacturaElectronicaExportacion'
                            : invoice.typeDoc === '03' ? 'NotaCreditoElectronica' : ''
                    gen.SigId = 'Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0'
                    gen.SigNamespacePrefix = 'ds'
                    gen.SignedInfoCanonAlg = 'C14N'
                    gen.SignedInfoDigestMethod = 'sha256'

                    var xml = new chilkat.Xml()
                    var cdn = invoice.typeDoc === '01' ? 'facturaElectronica'
                      : invoice.typeDoc === '04' ? 'tiqueteElectronico'
                        : invoice.typeDoc === '08' ? 'facturaElectronicaCompra'
                          : invoice.typeDoc === '09' ? 'facturaElectronicaExportacion'
                            : invoice.typeDoc === '03' ? 'notaCreditoElectronica' : ''
                    xml.Tag = 'xades:QualifyingProperties'
                    xml.AddAttribute('xmlns:xades', 'http://uri.etsi.org/01903/v1.3.2#')
                    xml.AddAttribute('Id', 'QualifyingProperties-aa262416-8607-4f02-8897-0a6440a1ae03')
                    xml.AddAttribute('Target', '#Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0')
                    xml.UpdateAttrAt('xades:SignedProperties', true, 'Id', 'SignedProperties-Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0')
                    xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningTime', 'TO BE GENERATED BY CHILKAT')
                    xml.UpdateAttrAt('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningCertificate|xades:Cert|xades:CertDigest|ds:DigestMethod', true, 'Algorithm', 'http://www.w3.org/2001/04/xmlenc#sha256')
                    xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningCertificate|xades:Cert|xades:CertDigest|ds:DigestValue', 'TO BE GENERATED BY CHILKAT')
                    xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningCertificate|xades:Cert|xades:IssuerSerial|ds:X509IssuerName', 'TO BE GENERATED BY CHILKAT')
                    xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SigningCertificate|xades:Cert|xades:IssuerSerial|ds:X509SerialNumber', 'TO BE GENERATED BY CHILKAT')
                    xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SignaturePolicyIdentifier|xades:SignaturePolicyId|xades:SigPolicyId|xades:Identifier', 'https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/' + cdn)
                    xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SignaturePolicyIdentifier|xades:SignaturePolicyId|xades:SigPolicyId|xades:Description', '')
                    xml.UpdateAttrAt('xades:SignedProperties|xades:SignedSignatureProperties|xades:SignaturePolicyIdentifier|xades:SignaturePolicyId|xades:SigPolicyHash|ds:DigestMethod', true, 'Algorithm', 'http://www.w3.org/2001/04/xmlenc#sha256')
                    xml.UpdateChildContent('xades:SignedProperties|xades:SignedSignatureProperties|xades:SignaturePolicyIdentifier|xades:SignaturePolicyId|xades:SigPolicyHash|ds:DigestValue', 'NmI5Njk1ZThkNzI0MmIzMGJmZDAyNDc4YjUwNzkzODM2NTBiOWUxNTBkMmI2YjgzYzZjM2I5NTZlNDQ4OWQzMQ==')
                    xml.UpdateAttrAt('xades:SignedProperties|xades:SignedDataObjectProperties|xades:DataObjectFormat', true, 'ObjectReference', '#Reference-ab26afbd-e2dc-4cb0-886a-ce2a4a118c7f')
                    xml.UpdateChildContent('xades:SignedProperties|xades:SignedDataObjectProperties|xades:DataObjectFormat|xades:MimeType', 'text/xml')
                    xml.UpdateChildContent('xades:SignedProperties|xades:SignedDataObjectProperties|xades:DataObjectFormat|xades:Encoding', 'UTF-8')

                    gen.AddObject('XadesObjectId-674a431e-692c-4e0a-9d82-6275c85c5876', xml.GetXml(), '', '')

                    var signedPropsId = 'SignedProperties-Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0'
                    gen.AddObjectRef(signedPropsId, 'sha256', 'EXCL_C14N', '', 'http://uri.etsi.org/01903#SignedProperties')

                    var keyInfoId = 'KeyInfoId-Signature-d1cbfe99-fd8e-4e0f-b0b7-fc5bfe2f1dd0'
                    gen.KeyInfoId = keyInfoId
                    gen.AddSameDocRef(keyInfoId, 'sha256', 'EXCL_C14N', '', '')
                    gen.SetRefIdAttr(keyInfoId, 'ReferenceKeyInfo')

                    gen.AddSameDocRef('', 'sha256', 'EXCL_C14N', '', '')
                    gen.SetRefIdAttr('', 'Reference-ab26afbd-e2dc-4cb0-886a-ce2a4a118c7f')

                    gen.KeyInfoType = 'X509Data+KeyValue'
                    gen.X509Type = 'Certificate'
                    success = gen.SetX509Cert(cert, true)
                    if (!success) {
                      send({ error: 'wrongCrypt', message: 'Ocurrio un error al firmar la factura ' + gen.LastErrorText })
                      console.log(gen.LastErrorText)
                      return
                    }

                    gen.Behaviors = 'IndentedSignature'

                    success = gen.CreateXmlDSigSb(sbXml)
                    if (!success) {
                      send({ error: 'wrongCrypt', message: 'Ocurrio un error al firmar la factura ' + gen.LastErrorText })
                      console.log(gen.LastErrorText)
                      return
                    }
                    try {
                      var xmlDoc = sbXml.GetAsString()
                      var comprobante = base64.encode(xmlDoc)
                      await new Promise(resolve => {
                        mongo.save(body.collection, { _id: body._id, voucherXml: comprobante }, () => {
                          resolve()
                        })
                      })
                      sender(xmlDoc, comprobante)
                    } catch (error) {
                      send({ message: error.message })
                    }
                  })
                  result.pipe(file)
                })
              }

              function sender (xmlStr, comprobanteXml) {
                request.post(
                  {
                    url: environment.idpUrl,
                    form: {
                      grant_type: 'password',
                      client_id: environment.clientId,
                      username: environment.user,
                      password: environment.password,
                      client_secret: '',
                      scope: ''
                    }
                  },
                  function (err, httpResponse, token) {
                    if (err) {
                      console.log(err)
                    } else {
                      if (httpResponse.statusCode === 200) {
                        var tokens = JSON.parse(token)

                        parser.parseString(xmlStr, function (err, result) {
                          if (err && !result) result = {}
                          var formData = {}

                          if (invoice.typeDoc === '01') {
                            if (client && client.idNum) {
                              formData = {
                                clave: result.FacturaElectronica.Clave[0],
                                fecha: result.FacturaElectronica.FechaEmision[0],
                                emisor: {
                                  tipoIdentificacion: result.FacturaElectronica.Emisor[0].Identificacion[0].Tipo[0],
                                  numeroIdentificacion: result.FacturaElectronica.Emisor[0].Identificacion[0].Numero[0]
                                },
                                receptor: {
                                  tipoIdentificacion: result.FacturaElectronica.Receptor[0].Identificacion[0].Tipo[0],
                                  numeroIdentificacion: result.FacturaElectronica.Receptor[0].Identificacion[0].Numero[0]
                                },
                                comprobanteXml: comprobanteXml
                              }
                            } else {
                              formData = {
                                clave: result.FacturaElectronica.Clave[0],
                                fecha: result.FacturaElectronica.FechaEmision[0],
                                emisor: {
                                  tipoIdentificacion: result.FacturaElectronica.Emisor[0].Identificacion[0].Tipo[0],
                                  numeroIdentificacion: result.FacturaElectronica.Emisor[0].Identificacion[0].Numero[0]
                                },
                                comprobanteXml: comprobanteXml
                              }
                            }
                          }

                          if (invoice.typeDoc === '04') {
                            if (client && client.idNum) {
                              formData = {
                                clave: result.TiqueteElectronico.Clave[0],
                                fecha: result.TiqueteElectronico.FechaEmision[0],
                                emisor: {
                                  tipoIdentificacion: result.TiqueteElectronico.Emisor[0].Identificacion[0].Tipo[0],
                                  numeroIdentificacion: result.TiqueteElectronico.Emisor[0].Identificacion[0].Numero[0]
                                },
                                receptor: {
                                  tipoIdentificacion: result.TiqueteElectronico.Receptor[0].Identificacion[0].Tipo[0],
                                  numeroIdentificacion: result.TiqueteElectronico.Receptor[0].Identificacion[0].Numero[0]
                                },
                                comprobanteXml: comprobanteXml
                              }
                            } else {
                              formData = {
                                clave: result.TiqueteElectronico.Clave[0],
                                fecha: result.TiqueteElectronico.FechaEmision[0],
                                emisor: {
                                  tipoIdentificacion: result.TiqueteElectronico.Emisor[0].Identificacion[0].Tipo[0],
                                  numeroIdentificacion: result.TiqueteElectronico.Emisor[0].Identificacion[0].Numero[0]
                                },
                                comprobanteXml: comprobanteXml
                              }
                            }
                          }

                          if (invoice.typeDoc === '08') {
                            if (client && client.idNum) {
                              formData = {
                                clave: result.FacturaElectronicaCompra.Clave[0],
                                fecha: result.FacturaElectronicaCompra.FechaEmision[0],
                                emisor: {
                                  tipoIdentificacion: result.FacturaElectronicaCompra.Emisor[0].Identificacion[0].Tipo[0],
                                  numeroIdentificacion: result.FacturaElectronicaCompra.Emisor[0].Identificacion[0].Numero[0]
                                },
                                receptor: {
                                  tipoIdentificacion: result.FacturaElectronicaCompra.Receptor[0].Identificacion[0].Tipo[0],
                                  numeroIdentificacion: result.FacturaElectronicaCompra.Receptor[0].Identificacion[0].Numero[0]
                                },
                                comprobanteXml: comprobanteXml
                              }
                            } else {
                              formData = {
                                clave: result.FacturaElectronicaCompra.Clave[0],
                                fecha: result.FacturaElectronicaCompra.FechaEmision[0],
                                emisor: {
                                  tipoIdentificacion: result.FacturaElectronicaCompra.Emisor[0].Identificacion[0].Tipo[0],
                                  numeroIdentificacion: result.FacturaElectronicaCompra.Emisor[0].Identificacion[0].Numero[0]
                                },
                                comprobanteXml: comprobanteXml
                              }
                            }
                          }

                          if (invoice.typeDoc === '09') {
                            if (client && client.idNum) {
                              formData = {
                                clave: result.FacturaElectronicaExportacion.Clave[0],
                                fecha: result.FacturaElectronicaExportacion.FechaEmision[0],
                                emisor: {
                                  tipoIdentificacion: result.FacturaElectronicaExportacion.Emisor[0].Identificacion[0].Tipo[0],
                                  numeroIdentificacion: result.FacturaElectronicaExportacion.Emisor[0].Identificacion[0].Numero[0]
                                },
                                receptor: {
                                  tipoIdentificacion: result.FacturaElectronicaExportacion.Receptor[0].Identificacion[0].Tipo[0],
                                  numeroIdentificacion: result.FacturaElectronicaExportacion.Receptor[0].Identificacion[0].Numero[0]
                                },
                                comprobanteXml: comprobanteXml
                              }
                            } else {
                              formData = {
                                clave: result.FacturaElectronicaExportacion.Clave[0],
                                fecha: result.FacturaElectronicaExportacion.FechaEmision[0],
                                emisor: {
                                  tipoIdentificacion: result.FacturaElectronicaExportacion.Emisor[0].Identificacion[0].Tipo[0],
                                  numeroIdentificacion: result.FacturaElectronicaExportacion.Emisor[0].Identificacion[0].Numero[0]
                                },
                                comprobanteXml: comprobanteXml
                              }
                            }
                          }

                          if (invoice.typeDoc === '03') {
                            if (client && client.idNum) {
                              formData = {
                                clave: result.NotaCreditoElectronica.Clave[0],
                                fecha: result.NotaCreditoElectronica.FechaEmision[0],
                                emisor: {
                                  tipoIdentificacion: result.NotaCreditoElectronica.Emisor[0].Identificacion[0].Tipo[0],
                                  numeroIdentificacion: result.NotaCreditoElectronica.Emisor[0].Identificacion[0].Numero[0]
                                },
                                receptor: {
                                  tipoIdentificacion: result.NotaCreditoElectronica.Receptor[0].Identificacion[0].Tipo[0],
                                  numeroIdentificacion: result.NotaCreditoElectronica.Receptor[0].Identificacion[0].Numero[0]
                                },
                                comprobanteXml: comprobanteXml
                              }
                            } else {
                              formData = {
                                clave: result.NotaCreditoElectronica.Clave[0],
                                fecha: result.NotaCreditoElectronica.FechaEmision[0],
                                emisor: {
                                  tipoIdentificacion: result.NotaCreditoElectronica.Emisor[0].Identificacion[0].Tipo[0],
                                  numeroIdentificacion: result.NotaCreditoElectronica.Emisor[0].Identificacion[0].Numero[0]
                                },
                                comprobanteXml: comprobanteXml
                              }
                            }
                          }

                          var options = {
                            url: environment.url + 'recepcion',
                            json: true,
                            body: formData,
                            headers: {
                              Authorization: 'bearer ' + tokens.access_token,
                              'content-type': 'application/javascript'
                            }
                          }
                          request.post(options, function (err, response, out) {
                            if (!err && response.statusCode === 202) {
                              // console.log(response.headers.location)
                              send({ message: 'Factura enviada' })
                              mongo.save(
                                body.collection,
                                { _id: body._id, processDate: new Date(), voucherXml: comprobanteXml },
                                (err, result) => {
                                  if (err) {
                                    // send({ error: tags.savingProblema })
                                  }
                                }
                              )
                            } else if (err) {
                              send({ message: err })
                            } else {
                              console.log(response.statusCode + ' -> ' + response.statusMessage)
                              send({ message: 'Este comprobante ya se envió anteriormente o contiene errores' })
                            }
                          })
                          // }
                          // })
                        })
                      } else {
                        console.log(httpResponse.statusCode + ' -> ' + httpResponse.statusMessage)
                      }
                    }
                  }
                )
              }
            })
          })
        })
      })
    })
  }

  this.getstatus = function (req, mongo, send) {
    var body = req.query
    body._id = mongo.toId(body._id)

    mongo.findId(body.collection, body._id, (err, invoice) => {
      if (err && !invoice) invoice = {}
      mongo.findOne('company', { idNum: invoice.company }, (err, environment) => {
        if (err || !environment) {
          send({ message: 'Solo funciona en produccion', detalle: '' })
          return
        }
        getinvoice()

        function getinvoice () {
          request.post(
            {
              url: environment.idpUrl,
              form: {
                grant_type: 'password',
                client_id: environment.clientId,
                username: environment.user,
                password: environment.password,
                client_secret: '',
                scope: ''
              }
            },
            function (err, httpResponse, token) {
              if (err) {
                console.log(err)
              } else {
                if (httpResponse.statusCode === 200) {
                  var tokens = JSON.parse(token)

                  // Get status invoice
                  var options = {
                    json: true,
                    url: environment.url + 'recepcion/' + invoice.key, // + invoice.key,
                    headers: {
                      Authorization: 'bearer ' + tokens.access_token
                    }
                  }
                  request.get(options, function (err, response, doc) {
                    if (err) {
                      send({ message: 'Ocurrio un error al obtener la factura' })
                    }
                    if (doc !== null && response.statusCode === 200) {
                      var obj = doc
                      var result = Object.keys(obj).map(function (key) {
                        return [Number(key), obj[key]]
                      })
                      var estado = result[2]
                      // console.log(bytes)
                      var responseXml = result[3] ? result[3] : result[2]
                      responseXml = responseXml[1]
                      var detalle = ''
                      var str = base64.decode(responseXml)
                      var spl = str.split('<DetalleMensaje>', 2)
                      if (spl[1]) detalle = spl[1].split('</DetalleMensaje>', 1)[0]
                      // if (body.environment === 'Produccion' && ) {
                      mongo.save(
                        body.collection,
                        { _id: body._id, responseXml: responseXml, statusHacienda: estado[1] },
                        (err, result) => {
                          if (err) {
                            // send({ error: tags.savingProblema })
                          }
                        }
                      )
                      // }
                      send({ message: 'Estado: ' + estado[1], detalle: detalle })
                    }
                    if (response.statusCode === 400) {
                      send({ message: 'El comprobante no ha sido enviado aún' })
                    } else {
                      console.log(response.statusCode + ' -> ' + response.statusMessage)
                    }
                  })
                } else {
                  console.log(httpResponse.statusCode)
                }
              }
            }
          )
        }
      })
    })
  }

  this.pivotInfoware = async function (req, mongo, send) {
    var reply = []
    var allInvoices = []
    var from = new Date(req.query.start)
    var to = new Date(req.query.end)
    to.setDate(to.getDate() + 1)
    var keys = {
      $and: [
        { _id: { $gte: mongo.newId(from), $lt: mongo.newId(to) } }
      ]
    }
    var invoices = await new Promise(resolve => {
      mongo.find('invoice', keys, { _id: 1, client: 1, typeDoc: 1, statusHacienda: 1, items: 1, tax: 1, number: 1 }, { _id: -1 }, (err, ins) => {
        if (!err) {
          resolve(ins)
        }
      })
    })
    var invoices2pay = await new Promise(resolve => {
      mongo.find('invoice2pay', keys, { _id: 1, client: 1, typeDoc: 1, statusHacienda: 1, tax: 1, number: 1 }, { _id: -1 }, (err, ins2p) => {
        if (!err) {
          resolve(ins2p)
        }
      })
    })
    var invoicesCredit = await new Promise(resolve => {
      mongo.find('invoiceCredit', keys, { _id: 1, client: 1, typeDoc: 1, statusHacienda: 1, items: 1, tax: 1, number: 1 }, { _id: -1 }, (err, insC) => {
        if (!err) {
          resolve(insC)
        }
      })
    })
    allInvoices = allInvoices.concat(invoices)
    allInvoices = allInvoices.concat(invoices2pay)
    allInvoices = allInvoices.concat(invoicesCredit)
    var ids = []
    for (const i in allInvoices) {
      ids.push(allInvoices[i].client)
    }
    var companys = await new Promise(resolve => {
      mongo.find('client', { _id: { $in: ids } }, { _id: 1, name: 1 }, (err, coms) => {
        if (!err) {
          resolve(coms)
        }
      })
    })
    for (const i in allInvoices) {
      var invoice = {}
      if (allInvoices[i].items) {
        var sumIVA = 0
        for (var t in allInvoices[i].items) {
          if (allInvoices[i].items[t].tax && allInvoices[i].items[t].tax !== '') {
            sumIVA = sumIVA + parseFloat(allInvoices[i].items[t].tax)
          }
        }
        invoice.IVA = sumIVA
      } else {
        if (allInvoices[i].tax && allInvoices[i].tax !== '') {
          invoice.IVA = parseFloat(allInvoices[i].tax)
        } else {
          invoice.IVA = 0
        }
      }
      var tipo = allInvoices[i].number.slice(8, 10)
      switch (tipo) {
      case '01':
        invoice.type = 'FE'
        break
      case '04':
        invoice.type = 'TE'
        break
      case '08':
        invoice.type = 'FEC'
        break
      case '09':
        invoice.type = 'FEE'
        break
      case '05':
        invoice.type = 'ComprasAceptadas'
        break
      case '06':
        invoice.type = 'ComprasAceptadasParcialmente'
        break
      case '07':
        invoice.type = 'ComprasRechazadas'
        break
      case '03':
        invoice.type = 'NC'
        break
      case '02':
        invoice.type = 'ND'
        break
      }
      const c = companys.findIndex((x) => {
        if (x._id && allInvoices[i].client) {
          return x._id.toString() === allInvoices[i].client.toString()
        }
      })
      if (c !== -1) {
        invoice.company = companys[c].name
      } else {
        invoice.company = ''
      }
      invoice.estado = allInvoices[i].statusHacienda || ''
      reply.push(invoice)
    }
    send(reply)
  }

  function chilkatExample () {
    var chilkat = require('@chilkat/ck-node14-linux64')
    // After licensing Chilkat, replace the "Anything for 30-day trial" with the purchased unlock code.
    // To verify the purchased unlock code was recognized, examine the contents of the LastErrorText
    var glob = new chilkat.Global()
    var success = glob.UnlockBundle('NFWJAQ.CB1042022_zJkF8zzt3K3e')
    //glob.UnlockBundle('INFOWA.CB1062020_V8xq8zKRD72n')
    if (success !== true) {
      console.log(glob.LastErrorText)
      return
    }
    var status = glob.UnlockStatus
    if (status !== 2) {
      console.log('Unlocked in trial mode.')
    }
    // The LastErrorText can be examined in the success case to see if it was unlocked in
    // trial more, or with a purchased unlock code.
  }
}

var separadorDecimalesInicial = '.' // Modifique este dato para poder obtener la nomenclatura que utilizamos en mi pais
var separadorDecimales = '.' // Modifique este dato para poder obtener la nomenclatura que utilizamos en mi pais
var separadorMiles = ',' // Modifique este dato para poder obtener la nomenclatura que utilizamos en mi pais

// Añadir separador de miles al total
function arreglar (numero) {
  var num = ''
  numero = '' + numero
  var partes = numero.split(separadorDecimalesInicial)
  var entero = partes[0]
  if (partes.length > 1) {
    var decimal = partes[1]
  }
  var cifras = entero.length
  var cifras2 = cifras
  for (let a = 0; a < cifras; a++) {
    cifras2 -= 1
    num += entero.charAt(a)
    if (cifras2 % 3 === 0 && cifras2 !== 0) {
      num += separadorMiles
    }
  }
  if (partes.length > 1) {
    num += separadorDecimales + decimal
  }
  return num
}
// Añadir ceros a la izquierda
function pad (n, length) {
  n = n.toString()
  while (n.length < length) n = '0' + n
  return n
}
// Añadir ceros a la derecha
function pader (n, length) {
  n = n.toString()
  while (n.length < length) n = n + '0'
  return n
}

function pad2 (number) {
  if (number < 10) {
    return '0' + number
  }
  return number
}

function omitirAcentos (text) {
  var acentos = 'ÃÀÁÄÂÈÉËÊÌÍÏÎÒÓÖÔÙÚÜÛãàáäâèéëêìíïîòóöôùúüûÑñÇç'
  var original = 'AAAAAEEEEIIIIOOOOUUUUaaaaaeeeeiiiioooouuuunncc'

  for (let i = 0; i < text.length; i++) {
    for (let j = 0; j < acentos.length; j++) {
      text = text.replace(acentos.charAt(j), original.charAt(j))
    }
  }

  return text
}
