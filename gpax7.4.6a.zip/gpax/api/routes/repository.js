/* Nilton Santos 4 de oct 2017 */
/* Show or edit form */
/* exported */

var dateformat = require('dateformat')
var tags = require('../utils/tags').tags
var Notification = require('../utils/notification').Notification
var notification = new Notification()
exports.Repository = Repository

function Repository () {
  this.get = function (req, mongo, send) {
    var doc = {}
    if (req.query._id) {
      mongo.findId('repository', req.query._id, (err, repository) => {
        if (!err) {
          if (!repository.active) repository.active = {}
          repository.active.start = repository.active.start ? dateformat(new Date(repository.active.start), 'yyyy/mm/dd') : repository.active.start
          repository.active.end = repository.active.end ? dateformat(new Date(repository.active.end), 'yyyy/mm/dd') : repository.active.end
          doc = repository
          send(doc)
        } else {
          send()
        }
      })
    } else {
      doc = { _id: mongo.newId(), isNew: true }
      send(doc)
    }
  }

  this.list = function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    /* filering documents with user of session or unit of user of session and not hidden */
    var keys = {}
    mongo.find('params', { name: 'repositoryTags' }, { _id: 1, name: 1, options: 1 }, (er, repositoryTags) => {
      mongo.find('params', { name: 'source' }, { _id: 1, name: 1, options: 1 }, (er, sources) => {
        mongo.find('params', { name: 'type' }, { _id: 1, name: 1, options: 1 }, (er, types) => {
          /* apply filter in parameters */
          if (req.query.filter) {
            const query = {}
            for (const name in req.query.filter) {
              if (req.query.filter[name].length > 0) {
                if (name === 'name') {
                  query[name] = {
                    $regex: req.query.filter.name, $options: 'i'
                  }
                } else if (name === 'active') {
                  var date = new Date().getTime()
                  if (req.query.filter.active === 'activo') {
                    query.$or = [{
                      $or: [{ $and: [{ startDate: null }, { endDate: null }] },
                        { $and: [{ startDate: null }, { endDate: { $gte: date } }] },
                        { $and: [{ startDate: { $lte: date } }, { endDate: null }] },
                        { $and: [{ startDate: { $lte: date } }, { endDate: { $gte: date } }] }
                      ]
                    }]
                  }
                  if (req.query.filter.active === 'inactivo') {
                    query.$or = [{ startDate: { $gt: date } },
                      { endDate: { $lt: date } }
                    ]
                  }
                } else {
                  query[name] = req.query.filter[name].indexOf(',') ? { $in: req.query.filter[name].split(',') } : new RegExp(req.query.filter[name].replace(/ /g, '.*'), 'i')
                }
                if (name === 'tag') {
                  var idstags = []
                  for (let t = 0; t < repositoryTags[0].options.length; t++) {
                    if (repositoryTags[0].options[t].id.toString() === req.query.filter.tag) {
                      idstags.push(repositoryTags[0].options[t].id)
                    }
                  }
                  query.category = { $in: idstags }
                  delete query.tag
                }
                if (name === 'source') {
                  var idsSource = []
                  for (let t = 0; t < sources[0].options.length; t++) {
                    if (sources[0].options[t].id.toString() === req.query.filter.source) {
                      idsSource.push(sources[0].options[t].id)
                    }
                  }
                  query.source = { $in: idsSource }
                }
                if (name === 'type') {
                  var idsType = []
                  for (let t = 0; t < types[0].options.length; t++) {
                    if (types[0].options[t].id.toString() === req.query.filter.type) {
                      idsType.push(types[0].options[t].id)
                    }
                  }
                  query.type = { $in: idsType }
                }
              }
            }
            keys = query
          }
          /* read limit rows from skip position */
          mongo.findN('repository', skip, limit, keys, { source: 1, category: 1, type: 1, name: 1, active: 1 }, { name: 1 }, (err, docs) => {
            if (err || !docs) {
              send({ error: err })
            } else {
              for (const i in docs) {
                var doc = docs[i]
                var item = this.getItem(doc, repositoryTags, sources, types)
                reply.data.push(item)
              }

              /* if continue is true, send data */
              if (skip) {
                send(reply)
              } else {
                /* add total_count to reply */
                mongo.count('repository', keys, (err, count) => {
                  if (!err && count) {
                    reply.total_count = count
                  }
                  send(reply)
                })
              }
            }
          })
        })
      })
    })
  }

  this.getItem = function (doc, repositoryTags, sources, types) {
    var tagsId = []
    for (const j in doc.category) {
      tagsId.push(doc.category[j])
    }
    var sourceId = []
    for (const j in doc.source) {
      sourceId.push(doc.source[j])
    }
    var typeId = []
    for (const j in doc.type) {
      typeId.push(doc.type[j])
    }
    // repositoryTags
    var usedTags = []
    if (repositoryTags.length) {
      for (let t = 0; t < repositoryTags[0].options.length; t++) {
        for (let o = 0; o < tagsId.length; o++) {
          if (repositoryTags[0].options[t].id.toString() === tagsId[o].toString()) {
            usedTags.push(repositoryTags[0].options[t])
          }
        }
      }
    }
    var tagscolor = []
    var tagsname = []
    var tag = [usedTags[0] ? usedTags[0].value : '']
    for (let i in usedTags) {
      tagscolor.push(usedTags[i].color)
      tagsname.push(usedTags[i].value)
    }
    // soucesTags
    var usedSources = []
    if (sources.length) {
      for (let t = 0; t < sources[0].options.length; t++) {
        for (let o = 0; o < sourceId.length; o++) {
          if (sources[0].options[t].id.toString() === sourceId[o].toString()) {
            usedSources.push(sources[0].options[t])
          }
        }
      }
    }
    var sourcecolor = []
    var sourcename = []
    var source = [usedSources[0] ? usedSources[0].value : '']
    for (let i in usedSources) {
      sourcecolor = usedSources[i].color
      sourcename = usedSources[i].value
    }
    // typesTags
    var usedTypes = []
    if (types && types.length) {
      for (let t = 0; t < types[0].options.length; t++) {
        for (let o = 0; o < typeId.length; o++) {
          if (types[0].options[t].id.toString() === typeId[o].toString()) {
            usedTypes.push(types[0].options[t])
          }
        }
      }
    }
    var typecolor = []
    var typename = []
    var type = [usedTypes[0] ? usedTypes[0].value : '']
    for (let i in usedTypes) {
      typecolor.push(usedTypes[i].color)
      typename.push(usedTypes[i].value)
    }
    var date = new Date()
    if (!doc.active) {
      doc.active = {}
    }
    var from = doc.active.start ? new Date(doc.active.start) : null
    var to = doc.active.end ? new Date(doc.active.end) : null
    var status
    if (from && to) {
      if (date >= from && date <= to) {
        status = 'activo'
      } else {
        status = 'inactivo'
      }
    } else if (from && !to) {
      if (date >= from) {
        status = 'activo'
      } else {
        status = 'inactivo'
      }
    } else if (!from && to) {
      if (date <= to) {
        status = 'activo'
      } else {
        status = 'inactivo'
      }
    } else if (!from && !to) {
      status = 'activo'
    }

    var row = {
      id: doc._id.toString(),
      source: source,
      type: type,
      name: doc.name,
      active: status,
      tagscolor: tagscolor,
      sourcecolor: sourcecolor,
      typecolor: typecolor,
      tagsname: tagsname,
      sourcename: sourcename,
      typename: typename,
      tag: tag,
      css: status === 'inactive' ? tags.expired : tags.processing
    }

    return row
  }

  this.save = function (req, mongo, next) {
    var doc = req.body
    if (doc.category) {
      doc.category = doc.category.length === 0 ? [] : doc.category.split(',')
    }
    if (doc.source) {
      doc.source = doc.source.length === 0 ? [] : doc.source.split(',')
    }
    if (doc.type) {
      doc.type = doc.type.length === 0 ? [] : doc.type.split(',')
    }
    if (doc.id) { doc._id = mongo.isNativeId(doc.id) ? mongo.toId(doc.id) : mongo.newId() }
    mongo.save('repository', doc, (err, result) => {
      var reply
      if (err) {
        reply = { error: tags.savingProblema }
      } else {
        reply = { message: tags.savedChanges }
      }
      next(reply)
      mongo.find('params', { name: 'repositoryTags' }, { _id: 1, name: 1, options: 1 }, (er, tags) => {
        mongo.find('params', { name: 'source' }, { _id: 1, name: 1, options: 1 }, (er, sources) => {
          mongo.find('params', { name: 'type' }, { _id: 1, name: 1, options: 1 }, (er, types) => {
            var item = this.getItem(doc, tags, sources, types)
            notification.send(req, req.session.context.room, 'repositories', item, null, null)
          })
        })
      })
    })
  }

  this.delete = function (req, mongo, send) {
    var doc = req.query
    mongo.findId('repository', mongo.toId(doc._id), (err, repository) => {
      if (err) {
        send({ error: err })
      } else {
        mongo.deleteOne('repository', { _id: mongo.toId(doc._id) }, (err, result) => {
          if (err) {
            req.logger.log(err)
          } else {
            req.app.routes.trash.insert(req, mongo, 'repository', repository, () => {
              send({ message: tags.savedChanges })
              doc.id = doc._id
              notification.send(req, req.session.context.room, 'repositories', doc, null, true)
            })
          }
        })
      }
    })
  }
}
