/**
 * Created by jorge on 15/05/17.
 */
/* exported */
var tags = require('../utils/tags').tags
exports.Movil = Movil

function Movil () {
  this.connect = function (req, mongo, send) {
    var login = req.body.login

    var password = req.body.password
    var code = req.headers.authorization
    code = code ? code.split(' ') : []
    if (code.length === 2) {
      code = Buffer.from(code[1], 'base64').toString().split(':')
      login = code[0]
      password = code[1]
    }
    if (password && password.length > 0) { password = tags.util.crypto(password) }
    mongo.find('user', { login: login, password: password }, {
      _id: 1,
      name: 1,
      email: 1,
      roles: 1,
      licenseduser: 1,
      active: 1,
      expiredPassword: 1,
      userLanguage: 1
    }, {}, (err, array) => {
      if (err || array.length === 0) {
        send({ error: true, config: tags.invalidCredentials })
      } else {
        var doc = array[0]
        req.session.authenticated = true
        for (let field in doc) {
          req.session[field] = doc[field]
        }
        delete req.session.expired
        send({ error: false, config: { name: req.session.name, photo: 'user.image?_id=' + req.session._id + '&itemId=photo' } })
      }
    })
  }

  this.disconnect = function (req, mongo, send) {
    req.session.destroy(function () {
      send({ message: req.session.name + ' ' + tags.byte })
    })
  }

  this.alarms = function (req, mongo, send) {
    mongo.find('notification', { 'users.user': req.session._id }, {}, {}, (err, array) => {
      if (err) {
        send({ message: err.errorMessage })
      } else {
        send({ notifications: array })
      }
    })
  }
}
