var tags = require('../utils/tags').tags
var dateformat = require('dateformat')
var Html = require('../utils/html').Html
var html = new Html()
var moment = require('moment')
var Notification = require('../utils/notification').Notification
var notification = new Notification()
/* exported */

exports.Evidence = Evidence

function Evidence () {
  this.get = async function (req, mongo, send) {
    var doc = {}
    if (!!req.query._id && req.query._id !== 'undefined') {
      var keys = await this.$keys(req, mongo)
      mongo.findOne('evidence', { $and: [{ _id: mongo.toId(req.query._id) }, keys] }, {}, async (err, document) => {
        if (err || !document) {
          req.statusCode = 404
          send()
        } else {
          let deadline
          if (document.dates) {
            document.dates.findIndex((x) => {
              if (x.type === 'deadline') deadline = x.value
            })
          }
          if (deadline) {
            var date = dateformat(new Date(deadline), 'yyyy/mm/dd')
            document.answerDate = date
          }
          if (document.type === 'spreadsheet' && typeof (document.content) === 'string') { document.content = JSON.parse(document.content) }
          if (document.task) {
            req.query.project = document.project
            req.query.task = document.task
            /* req.app.routes.project.delegates(req, mongo, (delegates) => {
              document.delegates = delegates;
              mongo.find('comment', { document: document._id }, {}, {}, (err, comments) => {
                document.mentions = [];
                for (let c in comments) {
                  for (let m in comments[c].mentions) {
                    document.mentions.push(comments[c].mentions[m])
                  }
                } */
            /* if (req.session.context.autoTimer) {
              var date = new Date()
              //date = new Date(date);
              mongo.find('time', { task: document.task, project: document.project, $and: [{ date: { "$gte": new Date(new Date(date).setHours(0, 0, 0, 0)) } }, { date: { "$lte": new Date(new Date(date).setHours(23, 59, 59)) } }], user: req.session.context.user }, {}, {}, (err, time) => {
                mongo.findId('project', document.project, (err, project) => {
                  var Obj = {};
                  var own = false;
                  for (let i in project.content.data) {
                    if (project.content.data[i].id.toString() === document.task.toString()) {
                      var name = project.content.data[i].text;
                      if (project.content.data[i].owner_id.toString() === req.session.context.user.toString()) {
                        own = true;
                      }
                      break;
                    }
                  }
                  if (own) {
                    if (document.type === 'redactor')
                      document.type = 'document';
                    if (time.length > 0) {
                      Obj._id = time[0]._id;
                      if (!time[0].docs)
                        time[0].docs = [];
                      for (let d in time[0].docs) {
                        time[0].docs[d] = time[0].docs[d].toString();
                      }
                      var index = time[0].docs.indexOf(document._id.toString());
                      if (index === -1) {
                        time[0].docs.push(document._id);
                        Obj.docs = time[0].docs;
                      }
                      if (!time[0].open)
                        Obj.start = new Date();
                      Obj.comment = time[0].comment + '<br><span class="h-entry p-name" contenteditable="true"><a class="u-uid" href=' + document._id + ' style="display:none;"></a><a class="u-url" href="document.' + document.type + '?_id=' + document._id + '&project=' + document.project + '">' + document.name + ' ' + dateformat(new Date(), "yyyy/mm/dd") + '</a></span>⁠';
                    } else {
                      Obj._id = mongo.newId();
                      Obj.user = req.session.context.user;
                      Obj.date = date;
                      Obj.start = new Date();
                      Obj.docs = [document._id];
                      Obj.duration = 0;
                      Obj.status = 'draft';
                      Obj.type = 'task';
                      Obj.name = name;
                      Obj.task = document.task;
                      Obj.plan = project.plan;
                      Obj.project = document.project;
                      Obj.comment = '<span class="h-entry p-name"><a class="u-uid" href=' + document._id + ' style="display:none;"></a><a class="u-url" href="document.' + document.type + '?_id=' + document._id + '">' + document.name + ' ' + dateformat(new Date(), "yyyy/mm/dd") + '</a></span>⁠';
                      Obj.open = true;
                    }
                    mongo.save("time", Obj, (err, result) => {
                      send(document);
                    });
                  } else {
                    send(document);
                  }
                });
              });
            } else */
            send(document)
            // });
            // });
          } else {
            var comm = await new Promise(resolve => {
              mongo.findId('commitment', document.reference, { status: 1 }, (err, comm) => {
                if (err) {
                  console.log(err)
                  resolve()
                } else {
                  resolve(comm)
                }
              })
            })
            if(comm) document.statusComm = comm.status
            send(document)
          }
        }
      })
    } else {
      // New document
      doc = {
        _id: mongo.newId(),
        isNew: true,
        status: tags.draft,
        actors: [{
          user: req.session.context.user,
          path: tags.sent,
          role: tags.reviser
        }],
        content: '',
        type: 'note',
        evidence: '1'
      }
      if (req.session.context.memberUnits && req.session.context.memberUnits.length > 0) {
        doc.actors[0].unit = req.session.context.memberUnits[0]
      }
      if (req.query.project) {
        doc.project = req.query.project
        doc.task = req.query.task
      }
      if (req.query.reference) {
        doc.reference = req.query.reference
        var actors = req.query.actors
        var index = actors.findIndex((x) => {
          return x.user === req.session.context.user.toString()
        })
        let unit
        if (index !== -1) {
          unit = actors[index].unit
        }
        for (const i in actors) {
          /* switch (actors[i].role) {
          case 'responsible':
            actors[i].role = 'reviser'
            break
          } */
          if (unit) {
            if (actors[i].unit === unit && (actors[i].role !== 'supervisor' && actors[i].role !== 'from')) { actors[i].role = 'responsible' } else { actors[i].path = 'hidden' }
          }
          doc.actors.push(actors[i])
        }
      }
      var evidenceCount = await new Promise(resolve => {
        mongo.count('evidence', { reference: mongo.toId(req.query.reference.toString()) }, (err, count) => {
          if (!err) {
            resolve(count)
          } else {
            resolve(0)
          }
        })
      })
      var attached = await new Promise(resolve => {
        mongo.findId('commitment', req.query.reference, { _id: 1, reference: 1 }, (err, commitment) => {
          if (!err && commitment) {
            mongo.findId('attached', commitment.reference, { _id: 1, name: 1 }, (err, attached) => {
              if (!err && attached) {
                resolve(attached)
              } else {
                resolve(false)
              }
            })
          } else {
            resolve(false)
          }
        })
      })
      if (attached) doc.name = 'Evidencia ' + (evidenceCount + 1) + ' - ' + attached.name
      if (req.query.template) {
        mongo.findId('template', req.query.template, (err, template) => {
          if (!err) {
            doc.type = 'note'
            if (!doc.name) {
              doc.name = template.name
            }
            doc.template = req.query.template
            doc.status = 'draft'
            if (template.pageType) { doc.pageType = template.pageType }
            if (template.units) { doc.units = template.units }
            if (template.sequence && template.sequence[0]) {
              doc.sequence = { sequence: template.sequence[0] }
            } else {
              doc.sequence = { text: '' }
            }
            doc.content = template.template
            send(doc)
          } else {
            send()
          }
        })
      } else {
        send(doc)
      }
    }
  }

  this.pdf = function (req, mongo, send) {
    mongo.findId('evidence', req.query._id, async (err, doc) => {
      if (!err && doc) {
        var i = 0
        while (doc.content.indexOf('{{', i) !== -1 && doc.content.substring(doc.content.indexOf('{{', i), doc.content.indexOf('{{', i) + 1) === '{') {
          i = doc.content.indexOf('{{', i)
          const f = doc.content.indexOf('}}', i)
          const word = doc.content.substring(i + 2, f)
          if (!['page', 'pages'].includes(word)) {
            doc.content = doc.content.replace(new RegExp('{{' + word + '}}', 'g'), '')
          }
          i = f + 2
        }
        if (req.query.details) {
          let user
          doc.actors.forEach(x => {
            if (x.path === 'sent' && x.role === 'reviser') { user = x.user } else if (x.path === 'sent' && x.role === 'from') { user = x.user }
          })
          if (doc.project) {
            var proj = await new Promise(resolve => {
              mongo.findId('project', doc.project, (err, project) => {
                if (!err) {
                  resolve(project)
                }
              })
            })
          }
          if (user) {
            var us = await new Promise(resolve => {
              mongo.findId('user', user, (err, user) => {
                if (!err) {
                  resolve(user)
                }
              })
            })
          }
          let i, fit, last
          if (doc.content.indexOf('id="pageFooter-last"') !== -1 || doc.content.indexOf('id=\'pageFooter-last\'') !== -1) {
            i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter-last"'))
            if (!i) { i = doc.content.indexOf('>', doc.content.indexOf('id=\'pageFooter-last\'')) }
            fit = doc.content.slice(0, i + 1)
            last = doc.content.slice(i + 1)
            doc.content = fit + ('<span style="position:relative;font-size: xx-small; top:0em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().format('MM-DD-YYYY') + '</span>') + last
            // doc.content.slice(0, i+1) + ('<div style="position:relative;font-size: xx-small; top:7em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().subtract(10, 'days').calendar() + '</div>') + doc.content.slice(i+1);
          } else if (doc.content.indexOf('id="pageFooter"') !== -1 || doc.content.indexOf('id=\'pageFooter\'') !== -1) {
            i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter"'))
            if (!i) { i = doc.content.indexOf('>', doc.content.indexOf('id=\'pageFooter\'')) }
            fit = doc.content.slice(0, i + 1)
            last = doc.content.slice(i + 1)
            doc.content = fit + ('<span style="position:relative;font-size: xx-small; top:0em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().format('MM-DD-YYYY') + '</span>') + last
          } else {
            doc.content = doc.content + '<div id="pageFooter" ><div style="position:relative;font-size: xx-small; top:0em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().format('MM-DD-YYYY') + '</div></div>'
          }
        }
        html.pdf(mongo, req, doc.content, doc.pageType, (err, stream) => {
          if (err) {
            send({ error: err })
          } else {
            send(stream)
          }
        })
      } else {
        send({ error: err })
      }
    })
  }

  this.save = function (req, mongo, send) {
    mongo.findId('evidence', req.body._id, (err, docs) => {
      if (err) {
        send({ error: err })
      } else {
        const doc = req.body
        var date = dateformat(new Date(), 'yyyy/mm/dd')
        date = new Date(date)
        mongo.find('time', { task: mongo.toId(doc.task), project: mongo.toId(doc.project), date: date }, {}, {}, (err, time) => {
          if (err) throw err
          mongo.findId('project', mongo.toId(doc.project), (err, project) => {
            if (err) throw err
            if (doc.type === 'spreadsheet') {
              doc.content = JSON.stringify(doc.content)
            }
            if (!docs) {
              if (doc.replyTo) {
                doc.links = [JSON.parse(JSON.stringify(doc.replyTo))]
              }
            } else {
              doc.actors = docs.actors
              if (!doc.status) { doc.status = docs.status }
            }
            if (doc.status === 'docReady') {
              doc.status = 'ready'
              for (const i in doc.actors) {
                switch (doc.actors[i].role) {
                case 'reviser':
                  doc.actors[i].path = 'sent'
                  break
                case 'from':
                case 'supervisor':
                  doc.actors[i].path = 'sent'
                  doc.actors[i].role = 'supervisor'
                  break
                default:
                  doc.actors[i].path = 'received'
                  break
                }
              }
            }
            var indexS = doc.actors.findIndex((x) => {
              return x.user.toString() === req.session.context.user.toString() && x.role === 'supervisor'
            })
            var indexR = doc.actors.findIndex((x) => {
              return x.user.toString() === req.session.context.user.toString() && x.role === 'responsible'
            })
            if (!docs && doc.status === 'draft') {
              if (doc.actors) {

                if (indexS !== -1 && indexR !== -1) {
                  for (let i in doc.actors) {
                    if (doc.actors[i].role === 'responsible') doc.actors[i].path = 'hidden'
                    else doc.actors[i].path = 'sent'
                  }
                }
              }
            }
            const ids = []
            doc.actors.findIndex((x) => {
              if (x.role === 'responsible' || x.role === 'supervisor' || x.role === 'from') {
                ids.push(x.user)
              }
            })

            ids.forEach(y => {
              doc.actors.forEach(function (element, index, object) {
                if (element.user.toString() === y.toString() && (element.role !== 'responsible' && element.role !== 'supervisor' && element.role !== 'from')) {
                  doc.actors.splice(index, 1)
                }
              })
            })

            delete doc.comment
            delete doc.user
            delete doc.timeString
            delete doc.replyTo
            delete doc.isNew
            delete doc.delegates
            delete doc.mentions
            delete doc.answerDate
            var units = req.session.units || []
            var noti
            for (const i in doc.actors) {
              if (doc.actors[i].user === req.session.context.user.toString() && doc.actors[i].unit) {
                units = [mongo.toId(doc.actors[i].unit)]
                break
              }
            }
            var readers = []
            for (const i in doc.actors) {
              if (doc.actors[i].unit) {
                if (doc.actors[i].role === tags.from || units.findIndex(function (x) { return x.toString() === doc.actors[i].unit }) !== -1) {
                  readers.push(doc.actors[i].user)
                }
              }
            }
            // Add or update dates.issue
            if (doc.dates && doc.dates.length > 0) {
              doc.dates[0].value = new Date()
            } else {
              doc.dates = [{ type: tags.issue, value: new Date() }]
            }
            if (doc.status === 'ready') { doc.dates.push({ type: 'answered', value: new Date() }) }
            const actorsNoti = []
            indexS = doc.actors.findIndex((x) => {
              return x.user.toString() === req.session.context.user.toString() && x.role === 'supervisor'
            })
            doc.actors.findIndex((x) => {
              if (((x.role === 'supervisor' || x.supervisor === '1') && x.path !== 'hidden') && indexS === -1) {
                actorsNoti.push({
                  user: x.user,
                  seen: 0
                })
              } else if ((!(x.role === 'supervisor' || x.supervisor === '1') && x.path !== 'hidden') && indexS !== -1 && x.user.toString() !== doc.actors[indexS].user.toString()) {
                actorsNoti.push({
                  user: x.user,
                  seen: 0
                })
              }
            })
            if (actorsNoti.length > 0) {
              noti = {
                _id: mongo.newId(),
                actors: actorsNoti,
                document: { id: doc._id, status: doc.status },
                collection: 'evidence',
                path: 'note.evidence',
                type: 2,
                user: req.session.context.user
              }
              noti.createdAt = noti._id.getTimestamp()
            }
            html.getData(doc.type === 'redactor' || doc.type === 'note' ? doc.content : '', (data) => {
              if (data.links && data.links.length > 0) {
                if (!doc.links) {
                  doc.links = (docs && docs.links) ? docs.links : []
                }
                for (const i in data.links) {
                  if (doc.links.findIndex((lk) => { return lk._id === data.links[i]._id }) === -1) {
                    doc.links.push({ _id: data.links[i]._id, clase: data.links[i].clase })
                  }
                }
              }
              if (doc.links && doc.links[0] === '{}') {
                delete doc.links
              }
              if (doc.tags === '') {
                doc.tags = []
              } else {
                if (typeof doc.tags === 'string') { doc.tags = doc.tags.split(',') }
                for (const i in doc.tags) {
                  doc.tags[i] = mongo.toId(doc.tags[i])
                }
              }
              mongo.save('evidence', doc, async (err, result) => {
                if (err) {
                  send()
                } else {
                  await new Promise(resolve => {
                    req.app.routes.eventUtil.save(req, mongo, 'statusChange', doc.status, doc._id, '', 'evidence', () => {
                      resolve()
                    })
                  })
                  if (noti) {
                    await new Promise(resolve => {
                      mongo.save('notification', noti, (err, result) => {
                        if (!err) {
                          resolve(result)
                        }
                      })
                    })
                    // email notification
                    if(doc.status === 'ready') {
                      await new Promise(resolve => {
                        doc.type = 'evidence'
                        req.query.someone = true
                        notification.notify(req, doc, mongo, send)
                        resolve()
                      })
                    }
                    notification.send(req, req.session.context.room, 'badgeNotification', null, [noti.actors[0].user], null)
                    notification.pushNotification(req, doc, noti, [noti.actors[0].user])
                  }
                  send({
                    message: tags.savedChanges,
                    doc: doc
                  })
                  notification.send(req, req.session.context.room, 'dtAttached', null, null, null)
                  // this.sendNotification(req, mongo, send, doc);
                  // }
                }
              })
            })
          })
        })
      }
    })
  }

  this.duplicate = function (req, mongo, send) {
    var doc = req.query
    mongo.findId('evidence', mongo.toId(doc._id), async (err, evidence) => {
      if (err) {
        return send({ error: err })
      } else {
        evidence._id = mongo.newId()
        evidence.name = evidence.name + ' - copy'
        evidence.status = 'draft'
        evidence.duplicated = true
        mongo.save('evidence', evidence, async (err) => {
          var reply
          if (err) {
            reply = { error: tags.savingProblema }
          } else {
            await new Promise(resolve => {
              req.app.routes.eventUtil.save(req, mongo, 'statusChange', evidence.status, evidence._id, '', 'evidence', () => {
                resolve()
              })
            })
            reply = { message: tags.savedChanges }
          }
          send(reply)
        })
      }
    })
  }

  this.forReference = function (req, mongo, send) {
    var data = []
    mongo.find('evidence', {reference: mongo.toId(req.query.reference)}, {}, { name: 1 }, async (err, docs) => {
      if (err) {
        send({ error: err })
      } else {
        var users = []
        let i = docs.length
        let owner
        while (i--) {
          owner = false
          const y = docs[i].actors.findIndex((ele) => {
            if (ele) {
              if (ele.user.equals(req.session.context.user) && ele.role === 'responsible') {
                owner = true
              }
              return ele.user.equals(req.session.context.user) && ele.path === 'hidden'
            }
          })
          if (y !== -1 || (y === -1 && docs[i].status === 'draft' && !owner)) { docs.splice(i, 1) }
        }
        for (const i in docs) {
          const doc = docs[i]
          var y = doc.actors.findIndex((x) => {
            if (x) { return x.role !== 'reviser' && x.user && x.user.equals && x.user.equals(req.session.context.user) }
          })
          if (y !== -1) {
            var actual = doc.actors[y]
            var role = actual.path === 'sent' ? 'to' : 'from'
            y = doc.actors.findIndex((x) => { return x.role === role })
            if (y !== -1) {
              doc.actor = { user: doc.actors[y].user, path: actual.role === 'copy' ? 'referred' : actual.path }
            }
          }
          if (!doc.actor) {
            doc.actor = doc.actors[0]
          }
          if (doc.actor && doc.actor.user) users.push(doc.actor.user)
        }
        mongo.toHash('user', {}, { _id: 1, name: 1 }, (er, users) => {
          if (docs) {
            for (let i = 0; i < docs.length; ++i) {
              var usedTags = []
              var doc = docs[i]
              if (doc.actor) {
                var actor = doc.actor
              }
              data.push(this.row(doc, req, actor, users, usedTags))
            }
          }
          send(data)
        })
      }
    })

  }

  this.listTree = async function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    var tagsDoc = []
    var scalableSequences = await new Promise(resolve => {
      mongo.find('sequence', { scalable: true }, (err, seqs) => {
        if (err) console.log(err)
        var ids = []
        if(seqs) {
          for (let s in seqs) {
            ids.push(seqs[s]._id)
          }
        }
        resolve(ids)
      })
    })
    let seqNote = ''
    let existScalable = false
    if (req.query.filter && req.query.filter.reference) {
      seqNote = await new Promise(resolve => {
        mongo.findId('note', req.query.filter.reference, (err, n) => {
          if (err || !n) {
            if (err) console.log(err)
            resolve('')
          } else {
            if (n.sequence.sequence) {
              resolve(n.sequence.sequence)
            } else resolve('')
          }
        })
      })
    }
    let indexSequence = scalableSequences.findIndex((x) => {
      return x.toString() === seqNote.toString()
    })
    if (indexSequence !== -1) existScalable = true
    var myAndDependentUnits = req.session.context.dependentUnits.concat(req.session.context.managerUnits.concat(req.session.context.assistantUnits))
    /* filering documents with user of session or unit of user of session and not hidden */
    mongo.find('params', { name: { $in: ['riskLevel', 'tag'] } }, { _id: 1, name: 1, options: 1 }, (er, tgsDs) => {
      if (tgsDs.length > 0) {
        for (const i in tgsDs) {
          tagsDoc = tagsDoc.concat(tgsDs[i].options)
        }
      }
      var keys1
      if (existScalable) {
        keys1 = {
          $or: [
            {
              $and: [
                { actors: { $elemMatch: { role: 'responsible', user: req.session.context.user } } }
              ]
            },
            {
              $or: [
                { actors: { $elemMatch: { user: req.session.context.user, role: 'from' , path: { $ne: 'hidden' } } } },
                { actors: { $elemMatch: { user: req.session.context.user, role: 'reviser', path: { $ne: 'hidden' } } } },
                { actors: { $elemMatch: { unit: { $in: myAndDependentUnits }, role: 'from', path: { $ne: 'hidden' } } } },
                { actors: { $elemMatch: { unit: { $in: myAndDependentUnits }, role: 'reviser', path: { $ne: 'hidden' } } } },
                { actors: { $elemMatch: { role: 'responsible', unit: { $in: myAndDependentUnits } } } },
                {'sequence.sequence': { $in: scalableSequences },}
              ],
            }
          ]
        }
      } else {
        keys1 = {
          $or: [
            { actors: { $elemMatch: { user: req.session.context.user, path: { $ne: 'hidden' } } } },
            {
              $and: [
                { actors: { $elemMatch: { path: { $ne: 'hidden' } } } },
                { confidential: { $ne: '1' } }
              ]
            }
          ]
        }
      }
      if (req.query.project) {
        keys1 = { project: mongo.toId(req.query.project) }
        if (!req.query.filter) { keys1.status = { $ne: 'archived' } }
      } else if (req.query.filter) {
        if (!req.query.filter.path || req.query.filter.path === 'all') {
          if (existScalable) {
            keys1 = {
              $or: [
                {
                  $and: [
                    { actors: { $elemMatch: { role: 'responsible', user: req.session.context.user } } }
                  ]
                },
                {
                  $or: [
                    { actors: { $elemMatch: { user: req.session.context.user, role: 'from', path: { $ne: 'hidden' } } } },
                    { actors: { $elemMatch: { user: req.session.context.user, role: 'reviser', path: { $ne: 'hidden' } } } },
                    { actors: { $elemMatch: { unit: { $in: myAndDependentUnits }, role: 'from', path: { $ne: 'hidden' } } } },
                    { actors: { $elemMatch: { unit: { $in: myAndDependentUnits }, role: 'reviser', path: { $ne: 'hidden' } } } },
                    { actors: { $elemMatch: { role: 'responsible', unit: { $in: myAndDependentUnits } } } },
                    {'sequence.sequence': { $in: scalableSequences },}
                  ],
                }
              ]
            }
          } else {
            {
              [
                { actors: { $elemMatch: { user: req.session.context.user, path: { $ne: 'hidden' } } }, status: { $ne: 'archived' } },
                {
                  $and: [
                    { actors: { $elemMatch: { path: { $ne: 'hidden' } } } },
                    { confidential: { $ne: '1' } }
                  ]
                }
              ]
            }
          }
          if (req.query.filter.status !== '' && req.query.filter.status !== 'archived') {
            if (existScalable) keys1.status = { $ne: 'archived' }
            else {
              keys1.$or[1].$and.push({ status: { $ne: 'archived' } })
              keys1.$or[0].status = { $ne: 'archived' }
            }
          }
          if (req.query.start === 0) {
            delete req.query.continue
          }
          delete req.query.filter.path
        }
      }
      /* apply filter in parameters */
      if (req.query.filter) {
        var query = {}
        for (const name in req.query.filter) {
          if (req.query.filter[name].length > 0) {
            if (name === 'reference') {
              var referenceId = req.query.filter[name]
            }
          }
        }
        delete query.filterNames
      }
      mongo.findId('commitment', referenceId, {}, (err, commi) => {
        if (err || !commi) {
          req.statusCode = 404
          send()
        } else {
          mongo.findId('attached', commi.reference, {}, (err, attach) => {
            if (err || !attach) {
              req.statusCode = 404
              send()
            } else {
              query.reference = attach.reference
              var keys2 = { $and: [query, keys1] }
              mongo.findId('note', attach.reference, {}, { name: 1 }, (err, note) => {
                if (err || !note) {
                  req.statusCode = 404
                  send()
                } else {
                  mongo.findN('attached', skip, limit, keys2 || keys1, {}, { name: 1 }, async (err, docs) => {
                    if (err) {
                      send({ error: err })
                    } else {
                      if (docs.length > 0) {
                        const references = []
                        const IDS = []
                        for (const i in docs) {
                          IDS.push(docs[i]._id)
                          if (docs[i].reference) {
                            references.push(docs[i].reference)
                          }
                        }
                        // let keysrefe = { $and: [{ $and: [{ reference: { $in: IDS } }, /* { actors: { $elemMatch: { user: req.session.context.user, path: { $ne: "hidden" } } } } */] }, keys1] };

                        var commitments = await new Promise(resolve => {
                          mongo.find('commitment', { reference: { $in: IDS } }, {}, { name: 1 }, (err, commit) => {
                            if (!err) {
                              resolve(commit)
                            }
                          })
                        })
                        if (commitments.length > 0) {
                          const references = []
                          const IDS = []
                          for (const i in commitments) {
                            IDS.push(commitments[i]._id)
                            if (commitments[i].reference) {
                              references.push(commitments[i].reference)
                            }
                          }

                          var evidences = await new Promise(resolve => {
                            mongo.find('evidence', { reference: { $in: IDS } }, {}, { name: 1 }, (err, evid) => {
                              if (!err) {
                                resolve(evid)
                              }
                            })
                          })
                        }
                      }
                      var allDocs = []
                      allDocs = allDocs.concat(note)
                      if (docs && docs.length > 0) { allDocs = allDocs.concat(docs) }
                      if (commitments && commitments.length > 0) { allDocs = allDocs.concat(commitments) }
                      if (evidences && evidences.length > 0) { allDocs = allDocs.concat(evidences) }
                      docs = allDocs

                      let i = docs.length
                      let owner
                      while (i--) {
                        owner = false
                        const y = docs[i].actors.findIndex((ele) => {
                          if (ele) {
                            if (ele.user.equals(req.session.context.user) && ele.role === 'responsible') {
                              owner = true
                            }
                            return ele.user.equals(req.session.context.user) && ele.path === 'hidden'
                          }
                        })
                        if (y !== -1 || (y === -1 && docs[i].status === 'draft' && !owner)) { docs.splice(i, 1) } else if (req.query.filter.tagsname && req.query.filter.tagsname.length > 0 && docs[i].tags && docs[i].tags.findIndex((x) => { return x.equals(mongo.toId(req.query.filter.tagsname)) }) === -1) {
                          docs.splice(i, 1)
                        } else if (req.query.filter.name && !docs[i].name.toLowerCase().includes(req.query.filter.name.toLowerCase())) {
                          docs.splice(i, 1)
                        } else if (req.query.filter.status && req.query.filter.status !== 'default' && docs[i].status !== req.query.filter.status) {
                          docs.splice(i, 1)
                        }
                      }

                      var users = []
                      for (const i in docs) {
                        const doc = docs[i]
                        var y = doc.actors.findIndex((x) => {
                          if (x) { return x.role !== 'reviser' && x.user && x.user.equals && x.user.equals(req.session.context.user) }
                        })
                        if (y !== -1) {
                          var actual = doc.actors[y]
                          var role = actual.path === 'sent' ? 'to' : 'from'
                          y = doc.actors.findIndex((x) => { return x.role === role })
                          if (y !== -1) {
                            doc.actor = { user: doc.actors[y].user, path: actual.role === 'copy' ? 'referred' : actual.path }
                          }
                        }
                        if (!doc.actor) {
                          doc.actor = doc.actors[0]
                        }
                        if (doc.actor && doc.actor.user) users.push(doc.actor.user)
                      }
                      mongo.toHash('user', {}, { _id: 1, name: 1 }, (er, users) => {
                        if (docs) {
                          for (let i = 0; i < docs.length; ++i) {
                            var tagsId = docs[i].tags
                            var usedTags = []
                            if (tagsDoc.length > 0 && tagsId && tagsId.length > 0) {
                              for (let t = 0; t < tagsDoc.length; t++) {
                                if (tagsId.length) {
                                  for (let o = 0; o < tagsId.length; o++) {
                                    if (tagsDoc[t].id && tagsId[o] && tagsDoc[t].id.toString() === tagsId[o].toString()) {
                                      usedTags.push(tagsDoc[t])
                                    }
                                  }
                                } else {
                                  if (tagsDoc[t] && tagsId && tagsDoc[t].id.toString() === tagsId.toString()) {
                                    usedTags.push(tagsDoc[t])
                                  }
                                }
                              }
                            }
                            var doc = docs[i]
                            if (doc.type === 'expense') { doc.status = 'expense' }
                            if (doc.actor) {
                              var actor = doc.actor
                            }
                            reply.data.push(this.row(doc, req, actor, users, usedTags))
                          }
                        }
                        /* if continue is true, send data */
                        if (req.query.continue) {
                          send(reply)
                        } else {
                          if (docs && docs.length === limit) {
                            reply.total_count = 999 // ...speculative
                          }
                          const toDelete = order(reply.data, reply.data)
                          for (const i in toDelete) {
                            const y = reply.data.findIndex((ele) => {
                              return ele.id === toDelete[i]
                            })
                            if (y !== -1) { reply.data.splice(y, 1) }
                          }

                          send(reply)
                        }
                      })
                    }
                  })
                }
              })
            }
          })
        }
      })
    })

    function order (arrayP, arrayH) {
      var toDelete = []
      for (const i in arrayP) {
        var doC = arrayP[i]
        for (const y in arrayH) {
          if (arrayH[y].reference && arrayH[y].reference.toString() === doC.id.toString()) {
            if (!doC.data) { doC.data = [] }
            if (doC.data.findIndex((x) => { return x.id === arrayH[y].id }) === -1) { doC.data.push(arrayH[y]) }
            if (!toDelete.includes(arrayH[y].id)) { toDelete.push(arrayH[y].id) }
            // reply.data.splice(y,1);
          }
        }
        if (doC.data) { toDelete.push(order(doC.data, reply.data)) }
      }
      return toDelete
    }
  }

  this.row = function (doc, req, actor, users, usedTags) {
    var issue = {}

    var deadline = {}
    for (const x in doc.dates) {
      if (doc.dates[x].type === 'issue') {
        issue = doc.dates[x]
      } else if (doc.dates[x].type === 'deadline') {
        deadline = doc.dates[x]
      }
    }
    var attachments = 'none'
    if (doc.files && doc.files.length > 0) {
      for (const x in doc.files) {
        if (doc.files[x]) {
          attachments = 'attachment'
        }
      }
    }
    const expired = doc.status === tags.processing && deadline.value && deadline.value.getTime() <= new Date().getTime() ? tags.expired : undefined
    var tagscolor = []
    var tagsname = []
    var filterNames = [usedTags[0] ? usedTags[0].value : '']
    for (const i in usedTags) {
      tagscolor.push(usedTags[i].color)
      tagsname.push(usedTags[i].value)
    }
    var row = {
      id: doc._id.toString(),
      attachments: attachments,
      expired: expired,
      css: expired || doc.status || tags.processing,
      status: doc.status ? doc.status : tags.processing,
      statusName: doc.status,
      role: actor.role,
      user: actor.user ? actor.user : doc.user,
      sequence: doc.sequence && doc.sequence.text ? doc.sequence.text : '',
      name: doc.name,
      path: actor.path,
      pathName: actor.path,
      issue: issue.value ? tags.util.date2str(issue.value, 'yyyy/mm/dd', tags) : '',
      category: doc.category || '',
      deadline: deadline.value ? tags.util.date2str(deadline.value, 'yyyy/mm/dd', tags) : '',
      tagscolor: tagscolor,
      tagsname: tagsname,
      filterNames: filterNames,
      archived: doc.status && doc.status === 'archived' ? 'archived' : '',
      issued: doc.issued,
      content: doc.content,
      actors: doc.actors,
      icon: 'none'
    }
    if (doc.type) { row.type = doc.type }
    if (doc.task) { row.task = doc.task }
    if (doc.reference) {
      row.reference = doc.reference
      row.icon = 'attached'
    }
    if (doc.commitment) {
      row.commitment = doc.commitment
      row.icon = 'folder-clock-outline'
    }
    if (doc.evidence) {
      row.evidence = doc.evidence
      row.icon = 'evidence'
    }
    if (doc.actors) {
      for (let i in doc.actors) {
        if (doc.actors[i].role === 'responsible') {
          const user = doc.actors[i].user
          row.responsible = { id: user, name: users[user]?users[user].name: '' }
          break
        }
      }
    }
    return row
  }

  this.delete = function (req, mongo, send) {
    const doc = req.query
    mongo.deleteOne('evidence', { _id: mongo.toId(doc._id) }, (err, result) => {
      if (err) {
        req.logger.log(err)
      } else {
        send({})
      }
    })
  }

  this.addActors = function (req, id, actors, mongo, next) {
    mongo.findId('evidence', id, { actors: 1, issued: 1, reference: 1 }, async (err, doc) => {
      if (err || !doc) {
        next(err)
      } else {
        /*let path = ''
        let index = doc.actors.findIndex((x) => {
          return x.user.toString() === req.session.context.user.toString()
        })
        if (index !== -1) {
          path = doc.actors[index].path
        }*/
        for (const i in actors) {
          const rm = doc.actors.findIndex((actor) => { return actor.user.toString() === actors[i].user.toString() })
          if (rm === -1) {
            //if(path && actors[i].role !== 'copy') actors[i].path = path
            doc.actors.push(actors[i])
          }
        }
        mongo.save('evidence', doc, async (err, result) => {
          let note = await new Promise(resolve => {
            mongo.findId('commitment', doc.reference, (err, comm) => {
              if (comm) {
                mongo.findId('attached', comm.reference, (err, att) => {
                  if (att) {
                    mongo.findId('note', att.reference, (err, note) => {
                      if (note) resolve(note)
                      else resolve(false)
                    })
                  } else resolve(false)
                })
              } else resolve(false)
            })
          })
          if (note) {
            await new Promise(resolve => {
              for (let i in actors) {
                let rm = note.actors.findIndex((actor) => { return actor.user.toString() === actors[i].user.toString() })
                if (rm === -1) {
                  //if (path) actors[i].path = path
                  note.actors.push(actors[i])
                }
              }
              mongo.save('note', note, () => {
                mongo.find('attached', { reference: note._id }, {}, async (err, atts) => {
                  if (atts && atts.length) {
                    for (let t in atts) {
                      for (let i in actors) {
                        let rm = atts[t].actors.findIndex((actor) => { return actor.user.toString() === actors[i].user.toString() })
                        if (rm === -1) {
                          //if (path) actors[i].path = path
                          atts[t].actors.push(actors[i])
                        }
                      }
                      await new Promise(resolve => {
                        mongo.save('attached', atts[t], async () => {
                          mongo.findOne('commitment', { reference: atts[t]._id }, { _id: 1, actors: 1, reference: 1 }, async (err, comm) => {
                            if (comm) {
                              for (let i in actors) {
                                let rm = comm.actors.findIndex((actor) => { return actor.user.toString() === actors[i].user.toString() })
                                if (rm === -1) {
                                  //if (path) actors[i].path = path
                                  comm.actors.push(actors[i])
                                }
                              }
                              await new Promise(resolve => {
                                mongo.save('commitment', comm, () => {
                                  mongo.findOne('evidence', { reference: comm._id }, { _id: 1, actors: 1, reference: 1 }, async (err, evid) => {
                                    if (evid) {
                                      for (let i in actors) {
                                        let rm = evid.actors.findIndex((actor) => { return actor.user.toString() === actors[i].user.toString() })
                                        if (rm === -1) {
                                          //if (path) actors[i].path = path
                                          evid.actors.push(actors[i])
                                        }
                                      }
                                      await new Promise(resolve => {
                                        mongo.save('evidence', evid, () => {
                                          resolve()
                                        })
                                      })
                                    }
                                    resolve()
                                  })
                                })
                              })
                            }
                          })
                        })
                        resolve()
                      })
                    }
                  }
                  resolve()
                })
              })
            })
          }
          next(err, doc)
        })
      }
    })
  }

  this.$keys =async function (req,mongo,) {
    var keys
    var scalableSequences = await new Promise(resolve => {
      mongo.find('sequence', { scalable: true }, (err, seqs) => {
        if (err) console.log(err)
        var ids = []
        if(seqs) {
          for (let s in seqs) {
            ids.push(seqs[s]._id)
          }
        }
        resolve(ids)
      })
    })
    if (req.session.context.licensedUser === false) {
      var myUnits=req.session.context.managerUnits.concat(req.session.context.assistantUnits)
      var myAndDependentUnits = req.session.context.dependentUnits.concat(myUnits)
      keys = {
        $or: [
          // responsible user without hidden
          { actors: { $elemMatch: { user: req.session.context.user, role: 'responsible', path: { $ne: 'hidden' } } } },
          // if confidential or not scalable, all actors user without hidden
          {
            $and: [
              {
                $or: [
                  { confidential: '1' },
                  { $and: [{ 'sequence.sequence': { $nin: scalableSequences } }, { 'sequence._id': { $nin: scalableSequences } }] },
                ]
              },
              {
                $or: [
                  { actors: { $elemMatch: { user: req.session.context.user, path: { $ne: 'hidden' } } } },
                  { actors: { $elemMatch: { unit: { $in: myUnits }, path: { $ne: 'hidden' } } } }
                ]
              }
            ]
          },
          // if not confidential and scalable, responsible unit are in dependents units without hidden only
          {
            confidential: {$ne: '1'},
            $or: [{ 'sequence.sequence': { $in: scalableSequences } },{ 'sequence._id': { $in: scalableSequences } }],
            actors: { $elemMatch: { role: 'responsible', unit: { $in: myAndDependentUnits }, path: { $ne: 'hidden' } } }
          }
        ]
      }
      if (req.session.context.readerUnits && req.session.context.readerUnits.length > 0) {
        keys.$or.push({
          $and: [
            { actors: { $elemMatch: { unit: { $in: req.session.context.readerUnits }, path: { $ne: 'hidden' } } } }
          ]
        })
      }
    } else {
      myUnits=req.session.context.managerUnits.concat(req.session.context.assistantUnits).concat(req.session.context.memberUnits)
      myAndDependentUnits = req.session.context.dependentUnits.concat(myUnits)
      keys = {
        $or: [
          // users in the note & not hidden
          { actors: { $elemMatch: { user: req.session.context.user, path: { $ne: 'hidden' } } } },
          // assistant in one unit of note & not hidden
          { actors: { $elemMatch: { unit: { $in: myUnits }, path: { $ne: 'hidden' } } } },
          // manager or assistant of ascending unit, not hidden, scalable, non-confidential and not in draft
          {
            actors: { $elemMatch: { unit: { $in: myAndDependentUnits }, path: { $ne: 'hidden' } } },
            confidential: { $ne: '1' }
          }
        ]
      }
      if (req.session.context.readerUnits && req.session.context.readerUnits.length > 0) {
        keys.$or.push({
          $and: [
            { actors: { $elemMatch: { unit: { $in: req.session.context.readerUnits }, path: { $ne: 'hidden' } } } }
          ]
        })
      }
    }
    return keys
  }
}
