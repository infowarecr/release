var tags = require('../utils/tags').tags
var dateformat = require('dateformat')
var Html = require('../utils/html').Html
var html = new Html()
var Extract = require('../utils/extract').Extract
var extract = new Extract()
var Sequence = require('./sequence').Sequence
var sequence = new Sequence()
var moment = require('moment')
var Readable = require('stream').Readable
var parseHtml = require('node-html-parser')
var Notification = require('../utils/notification').Notification
var notification = new Notification()
/* exported */

class Note {
  async get (req, mongo, send) {
    var doc = {}
    var myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits)
    var myAndDependentUnits = req.session.context.dependentUnits.concat(myUnits)
    if (!!req.query._id && req.query._id !== 'undefined') {
      var keys = await this.$keys(req, mongo)
      mongo.findOne('note', {
        $and: [{
          _id: mongo.toId(req.query._id.toString()) || req.query._id
        }, keys]
      }, {}, async (err, document) => {
        if (err || !document) {
          req.statusCode = 404
          send()
        } else {
          if (document.fileHtml) {
            let stream = await new Promise(resolve => {
              mongo.getfile(document.fileHtml, (err, res) => {
                if (err) {
                  console.log(err)
                  resolve({
                    error: err
                  })
                } else {
                  resolve(res)
                }
              })
            })

            function streamToString (stream) {
              var chunks = []
              return new Promise((resolve, reject) => {
                stream.on('data', (chunk) => chunks.push(Buffer.from(chunk)))
                stream.on('error', (err) => reject(err))
                stream.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')))
              })
            }

            document.content = await streamToString(stream)
          }


          let deadline
          if (document.dates) {
            document.dates.findIndex((x) => {
              if (x.type === 'deadline') deadline = x.value
            })
          }
          if (deadline) {
            var date = dateformat(new Date(deadline), 'yyyy/mm/dd')
            document.deadline = date
          }
          let reference = document.reference
          var referenceNote
          do {
            referenceNote = await new Promise(resolve => {
              mongo.findId('note', reference, {}, async (err, reference) => {
                if (!err) {
                  resolve(reference)
                } else {
                  resolve(false)
                }
              })
            })
            if (referenceNote)
              reference = referenceNote.reference
          } while (reference)

          if (referenceNote) {
            document.referenceNote = referenceNote
          }
          var from
          var fromUnitOffline
          var to = []
          var toUnitOffline
          var copy = []
          var copyUnitOffline
          var reviser
          var reviserUnitOffline
          if (document.status === 'draft') {
            if (document.actors && document.actors[0] && document.actors[0].unit && document.actors[0].role === 'reviser') {
              reviser = document.actors[0].user.toString() + '&unit=' + document.actors[0].unit.toString()
              unitDoc = await new Promise(resolve => {
                mongo.findId('unit', document.actors[0].unit, {
                  _id: 1,
                  name: 1,
                  active: 1,
                  offline: 1
                }, (err, unit) => {
                  if (!err) {
                    resolve(unit)
                  }
                })
              })
              reviserUnitOffline = (unitDoc.offline && unitDoc.offline === true) ? unitDoc.offline : ''
            }
            for (const i in document.actors) {
              if (document.actors[i]) {
                var unitDoc = await new Promise(resolve => {
                  mongo.findId('unit', document.actors[i].unit, {
                    _id: 1,
                    name: 1,
                    active: 1,
                    offline: 1
                  }, (err, unit) => {
                    if (!err) {
                      resolve(unit)
                    }
                  })
                })
                switch (document.actors[i].role) {
                case 'from':
                  if (!from && document.actors[i].unit) {
                    from = document.actors[i].user.toString() + '&unit=' + document.actors[i].unit.toString()
                    fromUnitOffline = (unitDoc.offline && unitDoc.offline === true) ? unitDoc.offline : ''
                  }
                  break
                case 'to':
                  if (document.actors[i].unit) {
                    to.push(document.actors[i].user.toString() + '&unit=' + document.actors[i].unit.toString())
                    toUnitOffline = (unitDoc.offline && unitDoc.offline === true) ? unitDoc.offline : ''
                  }
                  break
                case 'copy':
                  if (document.actors[i].unit) {
                    copy.push(document.actors[i].user.toString() + '&unit=' + document.actors[i].unit.toString())
                    copyUnitOffline = (unitDoc.offline && unitDoc.offline === true) ? unitDoc.offline : ''
                  }
                  break
                default:
                  break
                }
              }
            }
          } else {
            var users = [];
            var units = []
            for (const i in document.actors) {
              users.push(document.actors[i].user)
              units.push(document.actors[i].unit)
            }
            var hashUsers = await new Promise(resolve => {
              mongo.toHash('user', {
                _id: {
                  $in: users
                }
              }, {
                _id: 1,
                name: 1
              }, (err, result) => {
                if (err) resolve()
                else resolve(result)
              })
            })
            var hashUnits = await new Promise(resolve => {
              mongo.toHash('unit', {
                _id: {
                  $in: units
                }
              }, {
                _id: 1,
                name: 1,
                active: 1,
                offline: 1
              }, (err, result) => {
                if (err) resolve()
                else resolve(result)
              })
            })
            if (document.actors && document.actors[0] && document.actors[0].unit && document.actors[0].role === 'reviser') {
              reviser = {
                id: document.actors[0].user.toString(),
                user: hashUsers[document.actors[0].user.toString()].name + unit
              }
            }
            for (let i in document.actors) {
              if (document.actors[i] && hashUsers[document.actors[i].user.toString()]) {
                var unit = '/[error]'

                if (document.actors[i].unit && hashUnits[document.actors[i].unit.toString()]) {
                  unit = '/' + hashUnits[document.actors[i].unit.toString()].name
                }

                switch (document.actors[i].role) {
                case 'from':
                  if (!from && document.actors[i].unit) {
                    from = {
                      id: document.actors[i].user.toString(),
                      user: hashUsers[document.actors[i].user.toString()].name + unit
                    }
                  }
                  break
                case 'to':
                  if (document.actors[i].unit) {
                    to.push({
                      id: document.actors[i].user.toString(),
                      user: hashUsers[document.actors[i].user.toString()].name + unit
                    })
                  }
                  break
                case 'copy':
                  if (document.actors[i].unit) {
                    copy.push({
                      id: document.actors[i].user.toString(),
                      user: hashUsers[document.actors[i].user.toString()].name + unit
                    })
                  }
                  break
                default:
                  break
                }
              }
            }
          }
          document.from = from
          document.fromUnit = fromUnitOffline
          document.to = to
          document.toUnit = toUnitOffline
          document.copy = copy
          document.copyUnit = copyUnitOffline
          document.reviser = reviser
          document.reviserUnit = reviserUnitOffline

          document.count = await new Promise(resolve => {
            mongo.find('attached', {
              reference: document._id
            }, {}, (err, count) => {
              if (count && count.length) {
                resolve(count.length)
              } else {
                resolve(0)
              }
            })
          })

          document.countReminders = await new Promise(resolve => {
            mongo.find('reminders', {
              document: document._id
            }, { _id: 1 }, {}, (err, count) => {
              if (count && count.length && !err) {
                resolve(true)
              } else {
                resolve(false)
              }
            })
          })

          if (document.actors) {
            var y = document.actors.findIndex((x) => {
              if (x) {
                return x.role !== 'reviser' && x.user && x.user.equals && x.user.equals(req.session.context.user)
              }
            })
            if (y !== -1) {
              var actual = document.actors[y]
              document.actor = {
                user: document.actors[y].user,
                path: actual.role === 'copy' ? 'referred' : actual.path,
                role: actual.role
              }
            }
            if (!document.actor) {
              let e = myAndDependentUnits.findIndex((x) => {
                for (let a in document.actors) {
                  if (document.actors[a].unit && document.actors[a].unit.toString() === x.toString()) {
                    var actual = document.actors[a]
                    document.actor = {
                      user: document.actors[a].user,
                      path: actual.role === 'copy' ? 'referred' : actual.path,
                      role: actual.role
                    }
                  }
                }
              })
              if (!document.actor) {
                document.actor = document.actors[0]
              }
            }
            document.path = document.actor.path
            delete document.actor
          }
          if (document.type === 'spreadsheet' && typeof(document.content) === 'string') {
            document.content = JSON.parse(document.content)
          }
          if (document.task) {
            req.query.project = document.project
            req.query.task = document.task
            req.app.routes.project.delegates(req, mongo, (delegates) => {
              document.delegates = delegates
              mongo.find('comment', {
                document: document._id
              }, {}, {}, (err, comments) => {
                if (err) throw err
                document.mentions = []
                for (const c in comments) {
                  for (const m in comments[c].mentions) {
                    document.mentions.push(comments[c].mentions[m])
                  }
                }
                send(document)
              })
            })
          } else {
            send(document)
          }
        }
      })
    } else {
      // New document
      var reply = {}
      var vec
      if (req.query.link) {
        vec = req.query.link.split('.')
        reply = {
          _id: vec[0],
          type: vec[1]
        }
      }
      doc = {
        _id: mongo.newId(),
        isNew: true,
        type: 'note',
        status: tags.draft,
        actors: [{
          user: req.session.context.user,
          path: tags.sent,
          role: tags.reviser
        }],
        replyTo: reply
      }
      if (req.session.context.memberUnits && req.session.context.memberUnits.length > 0) {
        doc.actors[0].unit = req.session.context.memberUnits[0]
      }
      if (req.query.project) {
        doc.project = req.query.project
        doc.task = req.query.task
      }
      if (req.query.reference) {
        doc.reference = req.query.reference
        if (req.query.evidence) {
          doc.evidence = '1'
        } else {
          doc.commitment = '1'
        }
        var actors = req.query.actors
        const index = actors.findIndex((x) => {
          return x.user === req.session.context.user.toString()
        })
        let unit
        if (index !== -1) {
          unit = actors[index].unit
        }
        for (const i in actors) {
          switch (actors[i].role) {
          case 'inCharge':
            actors[i].role = 'reviser'
            break
          }
          if (unit) {
            if (actors[i].unit === unit && (actors[i].role !== 'supervisor' && actors[i].role !== 'from')) {
              actors[i].role = 'inCharge'
            } else {
              actors[i].path = 'hidden'
            }
          }
          doc.actors.push(actors[i])
        }
      }
      if (req.query.extractContent) {
        doc.extractContent = 1
        switch (req.query.extractContent) {
        case 'projects':
          doc.content = await extract.projects(mongo, req.query.plan, req.query.period)
          break
        case 'notesForPeriod':
          doc.content = await extract.notesForPeriod(mongo, req.query.period)
          break
        case 'attachedsOfUnit':
          doc.content = await extract.attachedsOfUnit(mongo, req.query.period)
          break
        case 'extension':
          doc.content = await extract.extension(mongo)
          break
        case 'forUnit':
          doc.content = await extract.forUnit(mongo)
          break
        case 'auditCommitteeAgreements':
          doc.content = await new Promise(resolve => {
            extract.auditCommitteeAgreements(req, mongo, (res) => {
              resolve(res)
            })
          })
          break
        case 'auditCommitteeAgreements2':
          doc.content = await new Promise(resolve => {
            extract.auditCommitteeAgreements2(req, mongo, req.query.period, (res) => {
              resolve(res)
            })
          })
          break
        }
      }
      if (req.query.template) {
        mongo.findId('template', req.query.template, async (err, template) => {
          if (!err) {
            doc.type = 'note'
            doc.name = template.name
            doc.template = req.query.template
            doc.status = 'draft'
            if (template.pageType) {
              doc.pageType = template.pageType
            }
            if (template.tags) {
              doc.tags = template.tags
            }
            if (template.units) {
              doc.units = template.units
            }
            if (template.sequence && template.sequence[0]) {
              doc.sequence = {
                sequence: template.sequence[0]
              }
            } else {
              doc.sequence = {
                text: ''
              }
            }
            doc.content = template.template
            if (req.query.extractContent) {
              switch (req.query.extractContent) {
              case 'plan':
                doc.content = await extract.plan(mongo, req.query.plan, doc.content)
                break
              }
            }
            if (doc.project) {
              doc.content = await extract.fields(mongo, doc.project, doc.content)
            }
            if (reply._id) {
              this.reply(req, reply._id, doc, mongo, send)
            } else {
              send(doc)
            }
          } else {
            send()
          }
        })
      } else {
        if (reply._id) {
          this.reply(req, reply._id, doc, mongo, send)
        } else {
          send(doc)
        }
      }
    }
  }

  async activateReminders(req, mongo, send) {
    let id = req.body._id
    mongo.findId('note', mongo.toId(id), { status: 1, name: 1, dates: 1, actors: 1 }, async(err, note) => {
      if (err || !note) {
        send({})
      } else {
        let existAlarmDate = ''
        if (note.dates && note.dates.length) {
          for (let d in note.dates) {
            if (note.dates[d].type === 'deadline') {
              existAlarmDate = note.dates[d].value
            }
          }
        }
        
        //************* creacion de alarmas ******/
        let alarm = {}
        alarm._id = mongo.newId()
        alarm.type = 'note'
        alarm.document = note._id
        alarm.date = existAlarmDate
        alarm.cleared = ''

        alarm.owner = []
        alarm.deparmentManager = []
        for (let i in note.actors) {
          if (note.actors[i].role === 'to' || note.actors[i].role === 'copy') {
            alarm.owner.push(note.actors[i])

            if (note.actors[i].unit) {
              await new Promise(resolve => {
                mongo.findId('unit', note.actors[i].unit, (err, unit) => {
                  if (unit) {
                    if (unit.actors) {
                      for (let a in unit.actors) {
                        if (unit.actors[a].type && (unit.actors[a].type[0] === 'manager' || unit.actors[a].type[0] === 'assistant')) {
                          alarm.deparmentManager.push(unit.actors[a].user)
                        }
                      }
                    }
                  }
                  resolve()
                })
              })
            }
          }
        }

        alarm.reviewer = []
        for (let i in note.actors) {
          if (note.actors[i].role === 'reviser') {
            alarm.reviewer.push(note.actors[i])
          }
        }

        alarm.supervisor = []
        for (let i in note.actors) {
          if (note.actors[i].supervisor === '1') {
            alarm.supervisor.push(note.actors[i])
          }
        }

        alarm.snooze = []
        alarm.status = 'active'

        if (note.status === 'attended' || !existAlarmDate) alarm.status = 'inactive'

        await new Promise(resolve => {
          mongo.save('reminders', alarm, () => {
            resolve()
          })
        })
        var attacheds = await new Promise(resolve => {
          mongo.find('attached', { reference: note._id }, { _id: 1, name: 1, status: 1, dates: 1, actors: 1, reference: 1 }, (err, attacheds) => {
            if (!err && attacheds && attacheds.length) {
              resolve(attacheds)
            } else {
              resolve([])
            }
          })
        })
        if (attacheds.length) {
          for (let i in attacheds) {
            let attached = attacheds[i]
            if (attached.status === 'processing') {
              let alarm = await new Promise(resolve => {
                mongo.find('reminders', {
                  document: mongo.toId(attached._id)
                }, {}, (err, rem) => {
                  if (rem && rem.length) {
                    resolve(true)
                  } else {
                    resolve(false)
                  }
                })
              })
              if (!alarm) {
                let existAlarmDate = ''
                if (attached.dates && attached.dates.length) {
                  for (let d in attached.dates) {
                    if (attached.dates[d].type === 'deadline') {
                      existAlarmDate = attached.dates[d].value
                    }
                  }
                }

                if (existAlarmDate) {
                  //************* creacion de alarmas ******/
                  let alarm = {}
                  alarm._id = mongo.newId()
                  alarm.type = 'attached'
                  alarm.document = attached._id
                  alarm.date = existAlarmDate
                  alarm.cleared = ''

                  alarm.owner = []
                  alarm.deparmentManager = []
                  for (let i in attached.actors) {
                    if (attached.actors[i].role === 'responsible') {
                      alarm.owner.push(attached.actors[i])

                      if (attached.actors[i].unit) {
                        await new Promise(resolve => {
                          mongo.findId('unit', attached.actors[i].unit, (err, unit) => {
                            if (unit) {
                              if (unit.actors) {
                                for (let a in unit.actors) {
                                  if (unit.actors[a].type && (unit.actors[a].type[0] === 'manager' || unit.actors[a].type[0] === 'assistant')) {
                                    alarm.deparmentManager.push(unit.actors[a].user)
                                  }
                                }
                              }
                            }
                            resolve()
                          })
                        })
                      }
                    }
                  }

                  alarm.reviewer = []
                  for (let i in attached.actors) {
                    if (attached.actors[i].role === 'reviser') {
                      alarm.reviewer.push(attached.actors[i])
                    }
                  }

                  alarm.supervisor = []
                  for (let i in attached.actors) {
                    if (attached.actors[i].supervisor === '1' || attached.actors[i].role === 'from') {
                      alarm.supervisor.push(attached.actors[i])
                    }
                  }

                  alarm.snooze = []
                  alarm.status = 'active'

                  await new Promise(resolve => {
                    mongo.save('reminders', alarm, () => {
                      resolve()
                    })
                  })
                }
              }
            } else if (attached.status === 'answered' || attached.status === 'analyzing') {
              var comms = await new Promise(resolve => {
                mongo.find('commitment', { reference: attached._id }, { _id: 1, name: 1, status: 1, dates: 1, actors: 1, reference: 1 }, (err, comms) => {
                  if (!err && comms && comms.length) {
                    resolve(comms)
                  } else {
                    resolve([])
                  }
                })
              })
              if (comms.length) {
                for (let i in comms) {
                  let comm = comms[i]
                  let alarm = await new Promise(resolve => {
                    mongo.find('reminders', {
                      document: mongo.toId(comm._id)
                    }, {}, (err, rem) => {
                      if (rem && rem.length) {
                        resolve(true)
                      } else {
                        resolve(false)
                      }
                    })
                  })
                  if (!alarm) {
                    if (comm.status === 'returned') {
                      let existAlarmDate = ''
                      if (comm.dates && comm.dates.length) {
                        for (let d in comm.dates) {
                          if (comm.dates[d].type === 'deadline') {
                            existAlarmDate = comm.dates[d].value
                          }
                        }
                      }

                      if (existAlarmDate) {
                        //************* creacion de alarmas ******/
                        let alarm = {}

                        let deadlineNote = ''
                        if (note.dates && note.dates.length) {
                          for (let d in note.dates) {
                            if (note.dates[d].type === 'deadline') {
                              deadlineNote = note.dates[d].value
                            }
                          }
                        }

                        let dateNow = new Date()

                        if (deadlineNote && (dateNow.getTime() > deadlineNote.getTime())) {
                          deadlineNote = dateNow
                        }

                        alarm._id = mongo.newId()
                        alarm.type = 'commitment'
                        alarm.document = comm._id
                        alarm.date = deadlineNote || existAlarmDate
                        alarm.cleared = ''

                        alarm.owner = []
                        alarm.deparmentManager = []
                        for (let i in attached.actors) {
                          if (attached.actors[i].role === 'responsible') {
                            alarm.owner.push(attached.actors[i])

                            if (attached.actors[i].unit) {
                              await new Promise(resolve => {
                                mongo.findId('unit', attached.actors[i].unit, (err, unit) => {
                                  if (unit) {
                                    if (unit.actors) {
                                      for (let a in unit.actors) {
                                        if (unit.actors[a].type && (unit.actors[a].type[0] === 'manager' || unit.actors[a].type[0] === 'assistant')) {
                                          alarm.deparmentManager.push(unit.actors[a].user)
                                        }
                                      }
                                    }
                                  }
                                  resolve()
                                })
                              })
                            }
                          }
                        }

                        alarm.reviewer = []
                        for (let i in attached.actors) {
                          if (attached.actors[i].role === 'reviser') {
                            alarm.reviewer.push(attached.actors[i])
                          }
                        }

                        alarm.supervisor = []
                        for (let i in attached.actors) {
                          if (attached.actors[i].supervisor === '1' || attached.actors[i].role === 'from') {
                            alarm.supervisor.push(attached.actors[i])
                          }
                        }

                        alarm.snooze = []
                        alarm.status = 'active'

                        if (attached.status === 'analyzing') alarm.status = 'inactive'

                        await new Promise(resolve => {
                          mongo.save('reminders', alarm, () => {
                            resolve()
                          })
                        })
                      }
                    } else if (comm.status === 'accepted') {
                      await new Promise(resolve => {
                        mongo.find('reminders', {
                          document: mongo.toId(comm._id)
                        }, {}, (err, rem) => {
                          if (rem && rem.length) {
                            for (let f in rem) {
                              rem[f].status = 'inactive'
                              rem[f].cleared = new Date()
                              mongo.save('reminders', rem[f], () => {
                                resolve()
                              })
                            }
                          } else {
                            resolve()
                          }
                        })
                      })

                      let existAlarmDate = ''
                      if (comm.dates && comm.dates.length) {
                        for (let d in comm.dates) {
                          if (comm.dates[d].type === 'deadline') {
                            existAlarmDate = comm.dates[d].value
                          }
                        }
                      }

                      if (existAlarmDate) {
                        //************* creacion de alarmas ******/
                        let alarm = {}

                        alarm._id = mongo.newId()
                        alarm.type = 'commitment'
                        alarm.document = comm._id
                        alarm.date = existAlarmDate
                        alarm.cleared = ''

                        alarm.owner = []
                        alarm.deparmentManager = []
                        for (let i in comm.actors) {
                          if (comm.actors[i].role === 'responsible') {
                            alarm.owner.push(comm.actors[i])

                            if (comm.actors[i].unit) {
                              await new Promise(resolve => {
                                mongo.findId('unit', comm.actors[i].unit, (err, unit) => {
                                  if (unit) {
                                    if (unit.actors) {
                                      for (let a in unit.actors) {
                                        if (unit.actors[a].type && (unit.actors[a].type[0] === 'manager' || unit.actors[a].type[0] === 'assistant')) {
                                          alarm.deparmentManager.push(unit.actors[a].user)
                                        }
                                      }
                                    }
                                  }
                                  resolve()
                                })
                              })
                            }
                          }
                        }

                        alarm.reviewer = []
                        for (let i in comm.actors) {
                          if (comm.actors[i].role === 'reviser') {
                            alarm.reviewer.push(comm.actors[i])
                          }
                        }

                        alarm.supervisor = []
                        for (let i in comm.actors) {
                          if (comm.actors[i].role === 'supervisor') {
                            alarm.supervisor.push(comm.actors[i])
                          }
                        }

                        alarm.snooze = []
                        alarm.status = 'active'

                        if (attached.status === 'analyzing') alarm.status = 'inactive'

                        await new Promise(resolve => {
                          mongo.save('reminders', alarm, () => {
                            resolve()
                          })
                        })
                      }
                    } else if (comm.status === 'completed') {
                      let existAlarmDate = ''
                      if (comm.dates && comm.dates.length) {
                        for (let d in comm.dates) {
                          if (comm.dates[d].type === 'trackingDate') {
                            existAlarmDate = comm.dates[d].value
                          }
                        }
                      }

                      if (existAlarmDate) {
                        //************* creacion de alarmas ******/

                        let dateNow = new Date()

                        if (dateNow.getTime() > existAlarmDate.getTime()) {
                          existAlarmDate = dateNow
                        }

                        let alarm = {}

                        alarm._id = mongo.newId()
                        alarm.type = 'commitment'
                        alarm.document = comm._id
                        alarm.date = existAlarmDate
                        alarm.cleared = ''

                        alarm.owner = []
                        alarm.deparmentManager = []
                        for (let i in attached.actors) {
                          if (attached.actors[i].role === 'from') {
                            alarm.owner.push(attached.actors[i])

                            if (attached.actors[i].unit) {
                              await new Promise(resolve => {
                                mongo.findId('unit', attached.actors[i].unit, (err, unit) => {
                                  if (unit) {
                                    if (unit.actors) {
                                      for (let a in unit.actors) {
                                        if (unit.actors[a].type && (unit.actors[a].type[0] === 'manager' || unit.actors[a].type[0] === 'assistant')) {
                                          alarm.deparmentManager.push(unit.actors[a].user)
                                        }
                                      }
                                    }
                                  }
                                  resolve()
                                })
                              })
                            }
                          }
                        }

                        alarm.reviewer = []
                        for (let i in attached.actors) {
                          if (attached.actors[i].role === 'responsible') {
                            alarm.reviewer.push(attached.actors[i])
                          }
                        }

                        alarm.supervisor = []
                        for (let i in attached.actors) {
                          if (attached.actors[i].supervisor === '1' || attached.actors[i].role === 'from') {
                            alarm.supervisor.push(attached.actors[i])
                          }
                        }

                        alarm.snooze = []
                        alarm.status = 'active'

                        if (attached.status === 'analyzing') alarm.status = 'inactive'

                        await new Promise(resolve => {
                          mongo.find('reminders', {
                            document: mongo.toId(comm._id)
                          }, {}, (err, rem) => {
                            if (rem && rem.length) {
                              for (let f in rem) {
                                rem[f].status = 'inactive'
                                rem[f].cleared = new Date()
                                mongo.save('reminders', rem[f], () => {
                                  resolve()
                                })
                              }
                            } else {
                              resolve()
                            }
                          })
                        })

                        await new Promise(resolve => {
                          mongo.save('reminders', alarm, () => {
                            resolve()
                          })
                        })

                      }
                    } else if (comm.status === 'ready') {
                      let existAlarmDate = ''
                      if (comm.dates && comm.dates.length) {
                        for (let d in comm.dates) {
                          if (comm.dates[d].type === 'deadline') {
                            existAlarmDate = comm.dates[d].value
                          }
                        }
                      }

                      if (existAlarmDate) {
                        //************* creacion de alarmas ******/
                        let alarm = {}

                        let attAlarm = await new Promise(resolve => {
                          mongo.findId('attached', mongo.toId(comm.reference), {}, (err, attac) => {
                            if (attac) {
                              resolve(attac)
                            } else {
                              resolve('')
                            }
                          })
                        })

                        alarm._id = mongo.newId()
                        alarm.type = 'commitment'
                        alarm.document = comm._id
                        alarm.date = existAlarmDate
                        alarm.cleared = ''

                        alarm.owner = []
                        alarm.deparmentManager = []
                        for (let i in attached.actors) {
                          if (attached.actors[i].role === 'from') {
                            alarm.owner.push(attached.actors[i])

                            if (attached.actors[i].unit) {
                              await new Promise(resolve => {
                                mongo.findId('unit', attached.actors[i].unit, (err, unit) => {
                                  if (unit) {
                                    if (unit.actors) {
                                      for (let a in unit.actors) {
                                        if (unit.actors[a].type && (unit.actors[a].type[0] === 'manager' || unit.actors[a].type[0] === 'assistant')) {
                                          alarm.deparmentManager.push(unit.actors[a].user)
                                        }
                                      }
                                    }
                                  }
                                  resolve()
                                })
                              })
                            }
                          }
                        }

                        alarm.reviewer = []
                        for (let i in attached.actors) {
                          if (attached.actors[i].role === 'responsible') {
                            alarm.reviewer.push(attached.actors[i])
                          }
                        }

                        alarm.supervisor = []
                        for (let i in attached.actors) {
                          if (attached.actors[i].supervisor === '1' || attached.actors[i].role === 'from') {
                            alarm.supervisor.push(attached.actors[i])
                          }
                        }

                        alarm.snooze = []
                        alarm.status = 'active'

                        if (attached.status === 'analyzing') alarm.status = 'inactive'

                        await new Promise(resolve => {
                          mongo.find('reminders', {
                            document: attached._id
                          }, {}, (err, rem) => {
                            if (rem && rem.length) {
                              for (let f in rem) {
                                rem[f].status = 'inactive'
                                rem[f].cleared = new Date()
                                mongo.save('reminders', rem[f], () => {
                                  resolve()
                                })
                              }
                            } else {
                              resolve()
                            }
                          })
                        })

                        await new Promise(resolve => {
                          mongo.save('reminders', alarm, () => {
                            resolve()
                          })
                        })
                      }
                    } else if (comm.status === 'done' || comm.status === 'incomplete' || comm.status === 'annulled' || comm.status === 'canceled') {
                      await new Promise(resolve => {
                        mongo.find('reminders', {
                          document: mongo.toId(comm._id)
                        }, {}, (err, rem) => {
                          if (rem && rem.length) {
                            for (let f in rem) {
                              rem[f].status = 'inactive'
                              rem[f].cleared = new Date()
                              mongo.save('reminders', rem[f], () => {
                                resolve()
                              })
                            }
                          } else {
                            resolve()
                          }
                        })
                      })

                      await new Promise(resolve => {
                        mongo.find('reminders', {
                          document: mongo.toId(attached._id)
                        }, {}, (err, rem) => {
                          if (rem && rem.length) {
                            for (let f in rem) {
                              rem[f].status = 'inactive'
                              rem[f].cleared = new Date()
                              mongo.save('reminders', rem[f], () => {
                                resolve()
                              })
                            }
                          } else {
                            resolve()
                          }
                        })
                      })
                    }
                  }
                }
              }
            }
          }
        }
        send({})
      }
    })
  }

  getBody (req, mongo, send) {
    mongo.findId('note', req.query._id, {
      content: 1,
      name: 1
    }, (err, result) => {
      if (err) {
        console.log(err)
        send({
          data: '',
          name: ''
        })
      } else {
        send({
          data: result.content,
          name: result.name
        })
      }
    })
  }

  createAttachedsOfPT (req, mongo, send) {
    var data = req.body.ids
    for (const i in data) {
      data[i] = mongo.toId(data[i])
    }
    mongo.find('document', {
      _id: {
        $in: data
      }
    }, {}, {}, async (err, docs) => {
      if (err) {
        send({
          error: 'error'
        })
      } else {
        for (const i in docs) {
          const doc = docs[i]
          const newDoc = {
            _id: mongo.newId(),
            name: doc.name,
            status: tags.draft,
            actors: [{
              user: req.session.context.user,
              path: tags.sent,
              role: tags.reviser
            }],
            // replyTo: reply,
            type: 'note',
            content: doc.content,
            issued: '1'
          }
          if (doc.template) {
            newDoc.template = doc.template
          }
          if (doc.project) {
            newDoc.project = doc.project
          }
          if (doc.task) {
            newDoc.task = doc.task
          }
          if (req.session.context.memberUnits && req.session.context.memberUnits.length > 0) {
            newDoc.actors[0].unit = req.session.context.memberUnits[0]
          }
          newDoc.requiredResponse = '1'
          if (req.body.reference) {
            newDoc.reference = req.body.reference
            var note = await new Promise(resolve => {
              mongo.findOne('note', {
                _id: mongo.toId(req.body.reference)
              }, {
                _id: 1,
                actors: 1
              }, (err, note) => {
                if (!err) {
                  resolve(note)
                } else {
                  resolve(false)
                }
              })
            })
            if (note) {
              let indexFrom = note.actors.findIndex((x) => {
                return x.role === 'from'
              })
              if (indexFrom !== -1) {
                let indexDoc = newDoc.actors.findIndex((x) => {
                  return note.actors[indexFrom].user.toString() === x.user.toString()
                })
                if (indexDoc === -1) {
                  newDoc.actors.push(note.actors[indexFrom])
                }
              }
            }
          }
          await new Promise(resolve => {
            mongo.save('attached', newDoc, (err, result) => {
              if (!err) {
                resolve(result)
              }
            })
          })
        }
        send({
          message: tags.savedChanges
        })
      }
    })
  }

  changeActor (req, mongo, send) {
    mongo.findId('note', mongo.toId(req.body._id), {
      _id: 1,
      actors: 1,
      from: 1,
      copy: 1,
      to: 1
    }, {}, async (err, note) => {
      if (err) {
        send({
          error: 'error'
        })
      } else {
        var users = await new Promise(resolve => {
          mongo.toHash('user', {}, {
            _id: 1,
            name: 1
          }, (err, users) => {
            if (!err) {
              resolve(users)
            }
          })
        })
        var units = await new Promise(resolve => {
          mongo.toHash('unit', {}, {
            _id: 1,
            name: 1
          }, (err, units) => {
            if (!err) {
              resolve(units)
            }
          })
        })
        var vec = req.body.new
        var user = vec.split('&unit=')[0]
        var unit = vec.split('&unit=')[1]
        var oldUser = req.body.old
        note.actors = note.actors.filter(function (u) {
          const unit = u.unit || ''
          return u.user.toString() !== user || unit.toString() !== unit
        })
        note.actors.forEach(u => {
          if (u.user.toString() === oldUser.user && u.unit.toString() === oldUser.unit) {
            u.user = user
            u.unit = unit
          }
        })
        var attacheds = await new Promise(resolve => {
          mongo.find('attached', {
            reference: note._id
          }, {
            _id: 1,
            name: 1,
            actors: 1,
            responsible: 1
          }, (err, attacheds) => {
            if (!err) {
              resolve(attacheds)
            } else {
              resolve(false)
            }
          })
        })
        if (attacheds) {
          for (const a in attacheds) {
            const attached = attacheds[a]
            attached.actors.forEach(u => {
              if (u.user.toString() === oldUser.user && u.unit.toString() === oldUser.unit) {
                u.user = user
                u.unit = unit
              }
            })
            /* if (attached.responsible.includes(oldUser.user) && attached.responsible.includes(oldUser.unit)) {
                          attached.responsible = user + '&unit=' + unit
                        } */
            var commitments = await new Promise(resolve => {
              mongo.find('commitment', {
                reference: attached._id
              }, {
                _id: 1,
                name: 1,
                actors: 1
              }, (err, commitments) => {
                if (!err) {
                  resolve(commitments)
                } else {
                  resolve(false)
                }
              })
            })
            if (commitments) {
              for (const c in commitments) {
                const commitment = commitments[c]
                commitment.actors.forEach(u => {
                  if (u.user.toString() === oldUser.user && u.unit.toString() === oldUser.unit) {
                    u.user = user
                    u.unit = unit
                  }
                })
                var evidences = await new Promise(resolve => {
                  mongo.find('evidence', {
                    reference: commitment._id
                  }, {
                    _id: 1,
                    name: 1,
                    actors: 1
                  }, (err, evidences) => {
                    if (!err) {
                      resolve(evidences)
                    } else {
                      resolve(false)
                    }
                  })
                })
                if (evidences) {
                  for (const e in evidences) {
                    const evidence = evidences[e]
                    evidence.actors.forEach(u => {
                      if (u.user.toString() === oldUser.user && u.unit.toString() === oldUser.unit) {
                        u.user = user
                        u.unit = unit
                      }
                    })
                    await new Promise(resolve => {
                      mongo.save('evidence', evidence, (err, result) => {
                        if (!err) {
                          mongo.find('comment', {
                            collection: 'evidence',
                            document: evidence._id,
                            involved: mongo.toId(oldUser.user)
                          }, {}, async (err, comms) => {
                            if (comms && comms.length) {
                              for (let u in comms) {
                                comms[u].involved.push(user)
                                await new Promise(resolve => {
                                  mongo.save('comment', comms[u], () => {
                                    resolve()
                                  })
                                })
                              }
                            }
                            resolve(result)
                          })
                        } else resolve()
                      })
                    })
                  }
                }
                await new Promise(resolve => {
                  mongo.save('commitment', commitment, (err, result) => {
                    if (!err) {
                      mongo.find('comment', {
                        collection: 'commitment',
                        document: commitment._id,
                        involved: mongo.toId(oldUser.user)
                      }, {}, async (err, comms) => {
                        if (comms && comms.length) {
                          for (let u in comms) {
                            comms[u].involved.push(user)
                            await new Promise(resolve => {
                              mongo.save('comment', comms[u], () => {
                                resolve()
                              })
                            })
                          }
                        }
                        resolve(result)
                      })
                    } else resolve()
                  })
                })
              }
            }
            await new Promise(resolve => {
              mongo.save('attached', attached, (err, result) => {
                if (!err) {
                  mongo.find('comment', {
                    collection: 'attached',
                    document: attached._id,
                    involved: mongo.toId(oldUser.user)
                  }, {}, async (err, comms) => {
                    if (comms && comms.length) {
                      for (let u in comms) {
                        comms[u].involved.push(user)
                        await new Promise(resolve => {
                          mongo.save('comment', comms[u], () => {
                            resolve()
                          })
                        })
                      }
                    }
                    resolve(result)
                  })
                } else resolve()
              })
            })
          }
        }
        let from = ''
        let to = ''
        let copy = ''
        note.actors.forEach(a => {
          if (a.role === 'from') {
            from = a.user.toString() + '&unit=' + a.unit.toString()
          }
          if (a.role === 'to') {
            to = to + a.user.toString() + '&unit=' + a.unit.toString() + ','
          }
          if (a.role === 'copy') {
            copy = copy + a.user.toString() + '&unit=' + a.unit.toString() + ','
          }
        })
        if (to.length > 0) {
          to = to.slice(0, -1)
        }
        if (copy.length > 0) {
          copy = copy.slice(0, -1)
        }
        note.from = from
        note.to = to
        note.copy = copy
        await new Promise(resolve => {
          mongo.save('note', note, (err, result) => {
            if (!err) {
              mongo.find('comment', {
                collection: 'note',
                document: note._id,
                involved: mongo.toId(oldUser.user)
              }, {}, async (err, comms) => {
                if (comms && comms.length) {
                  for (let u in comms) {
                    comms[u].involved.push(user)
                    await new Promise(resolve => {
                      mongo.save('comment', comms[u], () => {
                        resolve()
                      })
                    })
                  }
                }
                resolve(result)
              })
            } else resolve()
          })
        })
        let comment = '<p>Cambió a ' + '<img class="photo" src="api/user.image?size=20&_id=' + oldUser.user + '"/>' + (users[oldUser.user] ? users[oldUser.user].name : ' ') + '/' + (units[oldUser.unit] ? units[oldUser.unit].name : ' ') + ' por ' + '<img class="photo" src="api/user.image?size=20&_id=' + user + '"/>' + (users[user] ? users[user].name : ' ') + '/' + (units[unit] ? units[unit].name : ' ') + '</p>'
        comment = comment + '<p>' + req.body.comment + '</p>'
        let involvedActors = []
        if (note.actors && note.actors.length) {
          for (let v in note.actors) {
            if (note.actors[v].path !== 'hidden' && note.actors[v].user.toString() !== req.session.context.user.toString()) involvedActors.push(note.actors[v].user)
          }
        }
        const data = {
          document: note._id,
          comment: comment,
          collection: 'note',
          involved: involvedActors
        }
        req.app.routes.comment.save(req, mongo, () => {
          send({
            message: tags.savedChanges
          })
        }, data)
      }
    })
  }

  changeSupervisor (req, mongo, send) {
    mongo.findId('note', mongo.toId(req.body._id), {
      _id: 1,
      actors: 1
    }, {}, async (err, note) => {
      if (err) {
        send({
          error: 'error'
        })
      } else {
        var users = await new Promise(resolve => {
          mongo.toHash('user', {}, {
            _id: 1,
            name: 1
          }, (err, users) => {
            if (!err) {
              resolve(users)
            }
          })
        })
        var units = await new Promise(resolve => {
          mongo.toHash('unit', {}, {
            _id: 1,
            name: 1
          }, (err, units) => {
            if (!err) {
              resolve(units)
            }
          })
        })
        var user = req.body.user
        delete user.name
        let checkUserLicense = await new Promise(resolve => {
          mongo.findId('user', user.user, (err, user) => {
            if (user && user.licensedUser) {
              resolve(true)
            } else {
              resolve(false)
            }
          })
        })
        if (checkUserLicense) {
          note.actors.forEach(u => {
            if (u.user.toString() === user.user && (u.unit ? u.unit.toString() : u.unit) === user.unit) {
              u.supervisor = user.supervisor
            }
          })
          var attacheds = await new Promise(resolve => {
            mongo.find('attached', {
              reference: note._id
            }, {
              _id: 1,
              name: 1,
              actors: 1,
              responsible: 1
            }, (err, attacheds) => {
              if (!err) {
                resolve(attacheds)
              } else {
                resolve(false)
              }
            })
          })
          let exists = false
          for (let t in attacheds) {
            for (let r in attacheds[t].actors) {
              if (attacheds[t].actors[r].role === 'responsible' && (attacheds[t].actors[r].user.toString() === user.user.toString())) {
                exists = true
                break
              }
              if (exists) break
            }
          }
          if (!exists) {
            if (attacheds) {
              for (const a in attacheds) {
                const attached = attacheds[a]
                if (user.supervisor === '1') {
                  let ex = attached.actors.findIndex((x) => {
                    return x.user.toString() === user.user.toString()
                  })
                  if (ex === -1) {
                    attached.actors.push(user)
                  } else {
                    attached.actors[ex].supervisor = '1'
                  }

                } else {
                  attached.actors = attached.actors.filter(function (u) {
                    const unit = u.unit || ''
                    return u.user.toString() !== user.user || unit.toString() !== user.unit
                  })
                }
                var commitments = await new Promise(resolve => {
                  mongo.find('commitment', {
                    reference: attached._id
                  }, {
                    _id: 1,
                    name: 1,
                    actors: 1
                  }, (err, commitments) => {
                    if (!err) {
                      resolve(commitments)
                    } else {
                      resolve(false)
                    }
                  })
                })
                if (commitments) {
                  for (const c in commitments) {
                    const commitment = commitments[c]
                    if (user.supervisor === '1') {
                      let ex = commitment.actors.findIndex((x) => {
                        return x.user.toString() === user.user.toString()
                      })
                      if (ex === -1) {
                        commitment.actors.push(user)
                      } else {
                        commitment.actors[ex].supervisor = '1'
                      }
                    } else {
                      commitment.actors = commitment.actors.filter(function (u) {
                        const unit = u.unit || ''
                        return u.user.toString() !== user.user || unit.toString() !== user.unit
                      })
                    }
                    var evidences = await new Promise(resolve => {
                      mongo.find('evidence', {
                        reference: commitment._id
                      }, {
                        _id: 1,
                        name: 1,
                        actors: 1
                      }, (err, evidences) => {
                        if (!err) {
                          resolve(evidences)
                        } else {
                          resolve(false)
                        }
                      })
                    })
                    if (evidences) {
                      for (const e in evidences) {
                        const evidence = evidences[e]
                        if (user.supervisor === '1') {
                          let ex = evidence.actors.findIndex((x) => {
                            return x.user.toString() === user.user.toString()
                          })
                          if (ex === -1) {
                            evidence.actors.push(user)
                          } else {
                            evidence.actors[ex].supervisor = '1'
                          }
                        } else {
                          evidence.actors = evidence.actors.filter(function (u) {
                            const unit = u.unit || ''
                            return u.user.toString() !== user.user || unit.toString() !== user.unit
                          })
                        }
                        await new Promise(resolve => {
                          mongo.save('evidence', evidence, (err, result) => {
                            if (!err) {
                              resolve(result)
                            }
                          })
                        })
                      }
                    }
                    await new Promise(resolve => {
                      mongo.save('commitment', commitment, (err, result) => {
                        if (!err) {
                          resolve(result)
                        }
                      })
                    })
                  }
                }
                await new Promise(resolve => {
                  mongo.save('attached', attached, (err, result) => {
                    if (!err) {
                      resolve(result)
                    }
                  })
                })
              }
            }
            await new Promise(resolve => {
              mongo.save('note', note, (err, result) => {
                if (!err) {
                  resolve(result)
                }
              })
            })
            let comment
            if (user.supervisor === '1') {
              comment = '<p>agregó a ' + '<img class="photo" src="api/user.image?size=20&_id=' + user.user + '"/>' + (users[user.user] ? users[user.user].name : ' ') + '/' + (units[user.unit] ? units[user.unit].name : ' ') + ' como supervisor </p>'
            } else {
              comment = '<p>eliminó a ' + '<img class="photo" src="api/user.image?size=20&_id=' + user.user + '"/>' + (users[user.user] ? users[user.user].name : ' ') + '/' + (units[user.unit] ? units[user.unit].name : ' ') + ' como supervisor </p>'
            }
            const data = {
              document: note._id,
              comment: comment,
              collection: 'note'
            }
            req.app.routes.comment.save(req, mongo, () => {
              send({
                message: tags.savedChanges
              })
            }, data)
          } else {
            send({
              message: 'Error, el usuario es responsable de un anexo'
            })
          }
        } else {
          send({
            message: 'Error, el usuario no tiene licencia'
          })
        }
      }
    })
  }

  duplicate (req, mongo, send) {
    var doc = req.query
    mongo.findId('note', mongo.toId(doc._id), async (err, note) => {
      if (err) {
        return send({
          error: err
        })
      } else {
        var attacheds = await new Promise(resolve => {
          mongo.find('attached', {
            reference: note._id
          }, {}, (err, attacheds) => {
            if (!err) {
              resolve(attacheds)
            } else {
              resolve(false)
            }
          })
        })
        if (note.links) {
          note.links.push({
            _id: note._id,
            type: 'document'
          })
        } else {
          note.links = [{
            _id: note._id,
            type: 'document'
          }]
        }
        const doc = {
          _id: note._id,
          links: note.links
        }
        note._id = mongo.newId()
        note.name = note.name + ' - copy'
        note.duplicated = true
        const issue = note.dates[0].value
        note.dates = [{
          type: 'issue',
          value: new Date()
        }]
        if (note.sequence && note.sequence.text && note.sequence.text !== '') {
          const regEx = new RegExp(note.sequence.text, 'ig')
          if (note.content.compatibilityMode) {
            note.content = JSON.stringify(note.content)
            note.content = note.content.replace(regEx, '{{sequence}}')
            note.content = JSON.parse(note.content)
          } else {
            note.content = note.content.replace(regEx, '{{sequence}}')
          }
          const sequence = {
            sequence: note.sequence.sequence || note.sequence._id,
            text: ''
          }
          note.sequence = sequence
        }
        if (note.pageType === 'sticker') {
          if (note.content.compatibilityMode) {
            note.content = JSON.stringify(note.content)
            note.content = note.content.replace(dateformat(issue, 'dd-mm-yyyy hh:MM tt'), '{{issue}}')
            note.content = JSON.parse(note.content)
          } else {
            note.content = note.content.replace(dateformat(issue, 'dd-mm-yyyy hh:MM tt'), '{{issue}}')
          }
        } else {
          const meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
          const diasSemana = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado']
          if (note.content.compatibilityMode) {
            note.content = JSON.stringify(note.content)
            note.content = note.content.replace(diasSemana[issue.getDay()] + ' ' + issue.getDate() + ' de ' + meses[issue.getMonth()] + ' de ' + issue.getFullYear(), '{{issue}}')
            note.content = JSON.parse(note.content)
          } else {
            note.content = note.content.replace(diasSemana[issue.getDay()] + ' ' + issue.getDate() + ' de ' + meses[issue.getMonth()] + ' de ' + issue.getFullYear(), '{{issue}}')
          }
        }
        let existsUser = false
        for (const a in note.actors) {
          if (['to', 'copy'].includes(note.actors[a].role)) {
            note.actors[a].path = 'hidden'
          }
          if (note.actors[a].user.toString() === req.session.context.user.toString()) {
            note.actors[a].role = 'reviser'
            note.actors[a].path = 'sent'
            existsUser = true
          }
          delete note.actors[a].seen
        }
        if (!existsUser) {
          note.actors.splice(0, 0, {
            role: 'reviser',
            path: 'sent',
            user: req.session.context.user,
            unit: req.session.context.managerUnits.length > 0 ? req.session.context.managerUnits[0] : req.session.context.memberUnits.length > 0 ? req.session.context.memberUnits[0] : req.session.context.assistantUnits.length > 0 ? req.session.context.assistantUnits[0] : ''
          })
        }
        delete note.answered
        delete note.reference
        delete note.links
        note.status = 'draft'
        if (attacheds) {
          for (const at in attacheds) {
            const attached = attacheds[at]
            attached._id = mongo.newId()
            attached.reference = note._id
            attached.duplicated = true
            attached.dates = [{
              type: 'issue',
              value: new Date()
            }]
            attached.status = 'draft'
            delete attached.answered
            let existsUser = false
            for (const a in attached.actors) {
              if (attached.actors[a].user.toString() === req.session.context.user.toString()) {
                attached.actors[a].role = 'reviser'
                attached.actors[a].path = 'sent'
                existsUser = true
              }
            }
            if (!existsUser) {
              attached.actors.push({
                role: 'reviser',
                path: 'sent',
                user: req.session.context.user,
                unit: req.session.context.managerUnits.length > 0 ? req.session.context.managerUnits[0] : req.session.context.memberUnits.length > 0 ? req.session.context.memberUnits[0] : req.session.context.assistantUnits.length > 0 ? req.session.context.assistantUnits[0] : ''
              })
            }
            attached.actors = attached.actors.filter(x => x.path === 'sent')
            await new Promise(resolve => {
              mongo.save('attached', attached, (err, result) => {
                if (!err) {
                  resolve(result)
                }
              })
            })
          }
        }
        await new Promise(resolve => {
          mongo.save('note', doc, (err, result) => {
            if (!err) {
              resolve(result)
            }
          })
        })
        mongo.save('note', note, (err) => {
          var reply
          if (err) {
            send({
              error: tags.savingProblema
            })
          } else {
            reply = {
              message: tags.savedChanges
            }
          }
          send(reply)
          this.sendNotification(req, mongo, send, note)
        })
      }
    })
  }

  extension (req, mongo, send) {
    mongo.findId('note', mongo.toId(req.body._id), {
      _id: 1,
      actors: 1,
      dates: 1,
      copy: 1,
      to: 1,
      log: 1
    }, {}, async (err, note) => {
      if (err) {
        send({
          error: 'error'
        })
      } else {
        let oldDate
        const first = {
          user: req.session.context.user
        }
        const extension = {}
        if (req.body.deadlineExtension) {
          note.dates.forEach(x => {
            if (x.type === 'deadline') {
              first.deadline = x.value
              oldDate = moment(x.value).format('DD/MM/YYYY')
              x.value = req.body.deadlineExtension
            }
          })
          extension.deadline = req.body.deadlineExtension
          var attacheds = await new Promise(resolve => {
            mongo.find('attached', {
              reference: note._id
            }, {
              _id: 1,
              name: 1,
              dates: 1
            }, (err, attacheds) => {
              if (!err) {
                resolve(attacheds)
              } else {
                resolve(false)
              }
            })
          })
          if (attacheds) {
            for (const a in attacheds) {
              attacheds[a].dates.forEach(x => {
                if (x.type === 'deadline') {
                  x.value = req.body.deadlineExtension
                }
              })
              await new Promise(resolve => {
                mongo.save('attached', attacheds[a], (err, result) => {
                  if (!err) {
                    mongo.findOne('commitment', {reference: attacheds[a]._id}, {}, async (err, comm)=>{
                      if (comm) {
                        comm.dates.forEach(x => {
                          if (x.type === 'deadline') {
                            x.value = req.body.deadlineExtension
                          }
                        })
                        await new Promise(resolve => {
                          mongo.save('commitment', comm, (err, result) => {resolve()})
                        })
                        resolve()
                      } else {
                        resolve()
                      }
                    })
                  } else {
                    resolve()
                  }
                })
              })
            }
          }
        }
        if (!note.extension) {
          note.extension = [first]
        }
        extension.user = req.session.context.user
        note.extension.push(extension)
        await new Promise(resolve => {
          mongo.save('note', note, (err, result) => {
            if (!err) {
              resolve(result)
            }
          })
        })
        let comment = '<p> Cambió fecha de vencimiento del ' + oldDate + ' al ' + moment(req.body.deadlineExtension).format('DD/MM/YYYY')
        comment = comment + '<p>' + req.body.commentExtension + '</p>'
        var data = {
          document: note._id,
          comment: comment,
          collection: 'note'
        }
        req.app.routes.comment.save(req, mongo, () => {
          send({
            message: tags.savedChanges
          })
        }, data)
      }
    })
  }

  getStatus (req, mongo, send) {
    mongo.findId('note', req.query._id, {}, (err, document) => {
      if (err) throw err
      if (document) {
        send({
          status: document.status
        })
      } else send()
    })
  }

  getReviewers (req, mongo, send) {
    mongo.findId('note', req.query._id, {}, (err, document) => {
      if (err) throw err
      var users = []
      var units = []

      var data = []
      if (document) {
        for (const a in document.actors) {
          if (document.actors[a]) {
            var actor = document.actors[a]
            users.push(actor.user)
            units.push(actor.unit)
          }
        }
        mongo.toHash('user', {
          _id: {
            $in: users
          }
        }, {
          _id: 1,
          name: 1
        }, (_er, users) => {
          mongo.toHash('unit', {
            _id: {
              $in: units
            }
          }, {
            _id: 1,
            name: 1
          }, (_er, units) => {
            for (const a in document.actors) {
              if (document.actors[a]) {
                var dataactor = document.actors[a]
                data.push({
                  id: dataactor.user,
                  name: dataactor.user ? users[dataactor.user.toString()] ? users[dataactor.user.toString()].name : '' : null,
                  path: dataactor.path,
                  role: dataactor.role,
                  unit: dataactor.unit,
                  unitName: dataactor.unit ? units[dataactor.unit.toString()] ? units[dataactor.unit.toString()].name : '' : null,
                  supervisor: dataactor.supervisor
                })
              }
            }
            send(data)
          })
        })
      }
    })
  }

  reply (req, _id, doc, mongo, send) {
    mongo.findId('note', _id, (err, document) => {
      if (err) throw err
      doc.reference = _id
      doc.to = []
      doc.copy = []
      for (const i in document.actors) {
        if (document.actors[i].unit) {
          var id = document.actors[i].user.toString() + '&unit=' + document.actors[i].unit.toString()
          if (document.actors[i].user.equals && document.actors[i].user.equals(req.session.context.user)) {
            doc.from = id
          } else {
            switch (document.actors[i].role) {
            case 'from':
            case 'to':
              doc.to.push(id)
              break
            case 'copy':
              doc.copy.push(id)
              break
            default:
              break
            }
          }
        }
      }
      send(doc)
    })
  }

  setSequence (req, mongo, send) {
    var doc = {}
    mongo.findOne('settings', {
      _id: 'settings'
    }, (err, settings) => {
      if (err || !settings) {
        settings = {
          hours: 0
        }
      }
      mongo.findId('note', req.body._id, (err, document) => {
        if (err) {
          send({
            error: err
          })
        } else {
          doc = document
          let deadline
          if (doc.dates) {
            doc.dates.findIndex((x) => {
              if (x.type === 'deadline') deadline = x.value
            })
          }
          if (!deadline) {
            doc.dates = [{
              type: tags.issue,
              value: new Date()
            }]
          }
          getData(mongo, document, (unitName, tag) => {
            var meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
            var diasSemana = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado']
            var f = new Date()
            if (doc.pageType === 'sticker') {
              f.setHours(f.getHours() + settings.hours)
              replace(doc, tags.issue, dateformat(f, 'dd-mm-yyyy hh:MM tt'))
              replace(doc, 'tags', tag)
              replace(doc, 'unitTo', unitName)
              replace(doc, 'name', document.name)
            } else {
              replace(doc, tags.issue, diasSemana[f.getDay()] + ' ' + f.getDate() + ' de ' + meses[f.getMonth()] + ' de ' + f.getFullYear())
            }
            if (req.body.unit && doc.sequence.text === '') {
              mongo.findId('unit', req.body.unit, (err, unit) => {
                if (!err && unit && unit.sequences && unit.sequences.length > 0) {
                  var i = 0
                  if (doc.sequence && doc.sequence.sequence) {
                    i = unit.sequences.findIndex(x => x._id && x._id.equals(doc.sequence.sequence))
                  }
                  if (i === -1) i = 0
                  unit.sequences[i].code = unit.code
                  sequence.next(unit.sequences[i], mongo, req.body.type, function (seq) {
                    if (seq && seq.type === 'sequence') {
                      doc.sequence.text = seq.text
                      doc.sequence.value = seq.lastValue
                      doc.sequence.sequence = seq._id
                      replace(doc, 'sequence', seq.text)
                      saveSend(doc)
                    } else if (seq && seq.type === 'unit') {
                      const p = unit.sequences.findIndex((x) => {
                        return x._id.toString() === seq._id.toString()
                      })
                      unit.sequences[p].lastValue = seq.lastValue
                      if (seq.year) unit.sequences[p].year = seq.year
                      mongo.save('unit', unit, (err) => {
                        if (err) {
                          send()
                        } else {
                          doc.sequence.text = seq.text
                          doc.sequence.value = seq.lastValue
                          doc.sequence.sequence = seq._id
                          replace(doc, 'sequence', seq.text)
                          saveSend(doc)
                        }
                      })
                    } else {
                      saveSend(doc)
                    }
                  })
                } else {
                  saveSend(doc)
                }
              })
            } else {
              saveSend(doc)
            }
          })
        }

        function getData (mongo, doc, next) {
          var unit
          for (const i in doc.actors) {
            if (doc.actors[i].role === 'to') {
              unit = doc.actors[i].unit
              break
            }
          }
          mongo.findId('unit', mongo.toId(unit), (err, unit) => {
            if (err) throw err
            var unitName = ''
            if (unit) {
              unitName = unit.name
            }
            mongo.findOne('params', {
              name: 'tag'
            }, (err, param) => {
              if (err) throw err
              var tag = ''
              if (param && doc.tags.length > 0) {
                for (const i in param.options) {
                  if (param.options[i].id.toString() === doc.tags[0].toString()) {
                    tag = param.options[i].value
                    break
                  }
                }
              }
              next(unitName, tag)
            })
          })
        }

        function replace (doc, tag, value) {
          if (doc.content.compatibilityMode) {
            doc.content = JSON.stringify(doc.content)
            doc.content = doc.content.replace(new RegExp('{{' + tag + '}}', 'g'), value)
            doc.content = JSON.parse(doc.content)
          } else {
            doc.content = doc.content.replace(new RegExp('{{' + tag + '}}', 'g'), value)
          }
        }

        function saveSend (doc) {
          mongo.save('note', doc, async (err) => {
            if (err) {
              send()
            } else {
              var comment = {
                _id: mongo.newId(),
                collection: 'note',
                comment: '_assignedConsecutive' + doc.sequence.text, //Asignó el consecutivo
                dateTime: new Date(),
                document: doc._id,
                documentType: 'note',
                involved: [],
                mentions: [],
                unread: [],
                user: req.session.context.user
              }
              for (const i in doc.actors) {
                comment.mentions.push(mongo.toId(doc.actors[i].user))
                if (doc.actors[i].user.toString() !== req.session.context.user.toString() && doc.actors[i].path !== 'hidden') {
                  comment.unread.push(doc.actors[i].user)
                  comment.involved.push(doc.actors[i].user)
                }
              }
              await new Promise(resolve => {
                mongo.save('comment', comment, (err, result) => {
                  if (!err) {
                    resolve(result)
                  } else {
                    resolve()
                  }
                })
              })
              send({
                content: doc.content,
                sequence: doc.sequence
              })
            }
          })
        }
      })
    })
  }

  async verifyTermDays (req, mongo, send) {
    var days = req.query.days
    let date = ''
    if (days && days !== '0') {
      let plan
      if (req.session.context.activePlan) {
        plan = await new Promise(resolve => {
          mongo.findId('plan', req.session.context.activePlan.id, (err, plan) => {
            if (!err && plan) {
              resolve(plan)
            } else {
              resolve(false)
            }
          })
        })
      } else {
        plan = false
      }
      let holiday = false
      var deadline = moment()
      days = Number(days)
      let calendar = ''
      var dateArray = []
      if (plan && plan.calendar) {
        calendar = await new Promise(resolve => {
          mongo.findId('calendar', plan.calendar, (err, calendar) => {
            if (!err && calendar) {
              resolve(calendar)
            } else {
              resolve(false)
            }
          })
        })
        if (calendar && calendar.days && calendar.days.length) {
          for (let i in calendar.days) {
            let day = calendar.days[i]
            var currentDate = day.fromAdd
            while (currentDate <= day.toAdd) {
              dateArray.push(new Date(currentDate))
              let date = new Date(currentDate)
              currentDate = new Date(date.setDate(date.getDate() + 1))
            }
          }
        }
      }
      do {
        holiday = false
        deadline.add(1, 'days')
        if (calendar) {
          for (let d in dateArray) {
            let x = dateArray[d]
            if (new Date(deadline._d.setHours(0, 0, 0)).toString() === x.toString()) {
              holiday = true
              break
            }
          }
        } else {
          holiday = false
        }
        if (((calendar && ((deadline.isoWeekday() === 1 && calendar.monday === '1') ||
                            (deadline.isoWeekday() === 2 && calendar.tuesday === '1') ||
                            (deadline.isoWeekday() === 3 && calendar.wednesday === '1') ||
                            (deadline.isoWeekday() === 4 && calendar.thursday === '1') ||
                            (deadline.isoWeekday() === 5 && calendar.friday === '1') ||
                            (deadline.isoWeekday() === 6 && calendar.saturday === '1') ||
                            (deadline.isoWeekday() === 7 && calendar.sunday === '1'))) &&
                        !holiday) || !calendar) {
          days = days - 1
        }
      } while (days && days > 0)
      date = deadline._d
    }
    send({
      date: date
    })
  }

  async verifyTermDays2 (req, mongo, send) {
    let date = req.query.date
    var to = moment(new Date(date))
    var deadline = moment()
    let days = 0
    if (date && date !== '') {
      let plan
      if (req.session.context.activePlan) {
        plan = await new Promise(resolve => {
          mongo.findId('plan', req.session.context.activePlan.id, (err, plan) => {
            if (!err && plan) {
              resolve(plan)
            } else {
              resolve(false)
            }
          })
        })
      } else {
        plan = false
      }
      let holiday = false
      let calendar = ''
      var dateArray = []
      if (plan && plan.calendar) {
        calendar = await new Promise(resolve => {
          mongo.findId('calendar', plan.calendar, (err, calendar) => {
            if (!err && calendar) {
              resolve(calendar)
            } else {
              resolve(false)
            }
          })
        })
        if (calendar && calendar.days && calendar.days.length) {
          for (let i in calendar.days) {
            let day = calendar.days[i]
            var currentDate = day.fromAdd
            while (currentDate <= day.toAdd) {
              dateArray.push(new Date(currentDate))
              let date = new Date(currentDate)
              currentDate = new Date(date.setDate(date.getDate() + 1))
            }
          }
        }
      }

      do {
        holiday = false
        deadline.add(1, 'days')
        if (calendar) {
          for (let d in dateArray) {
            let x = dateArray[d]
            if (new Date(deadline._d.setHours(0, 0, 0)).toString() === x.toString()) {
              holiday = true
              break
            }
          }
        } else {
          holiday = false
        }
        if (((calendar && ((deadline.isoWeekday() === 1 && calendar.monday === '1') ||
                            (deadline.isoWeekday() === 2 && calendar.tuesday === '1') ||
                            (deadline.isoWeekday() === 3 && calendar.wednesday === '1') ||
                            (deadline.isoWeekday() === 4 && calendar.thursday === '1') ||
                            (deadline.isoWeekday() === 5 && calendar.friday === '1') ||
                            (deadline.isoWeekday() === 6 && calendar.saturday === '1') ||
                            (deadline.isoWeekday() === 7 && calendar.sunday === '1'))) &&
                        !holiday) || !calendar) {
          days = days + 1
        }
      } while (to._d.setHours(0, 0, 0) > deadline._d.setHours(0, 0, 0))
    }
    send({
      days: days
    })
  }

  send (req, mongo, send) {
    var doc = {}
    mongo.findId('note', req.body._id, async (err, document) => {
      if (err) {
        send({
          error: err
        })
      } else {
        doc = document
        var unit
        var users = []
        for (const i in doc.actors) {
          users.push(doc.actors[i].user)
          if (doc.actors[i].role === 'from') {
            unit = doc.actors[i].unit
          }
        }
        
        if (!doc.dates[1]) {
          doc.dates = [{
            type: tags.issue,
            value: new Date()
          }]
        }
        var meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
        var diasSemana = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado']
        var f = new Date()
        var completeDate
        if (doc.pageType !== 'sticker') {
          completeDate = diasSemana[f.getDay()] + ' ' + f.getDate() + ' de ' + meses[f.getMonth()] + ' de ' + f.getFullYear()
          replace(doc, tags.issue, completeDate)
        }

        //************* creacion de alarmas ******/
        var alarm = {}
        alarm._id = mongo.newId()
        alarm.type = 'note'
        alarm.document = doc._id
        alarm.date = ''
        alarm.cleared = ''

        alarm.owner = []
        alarm.deparmentManager = []
        for (let i in doc.actors) {
          if (doc.actors[i].role === 'to' || doc.actors[i].role === 'copy') {
            alarm.owner.push(doc.actors[i])

            if (doc.actors[i].unit) {
              await new Promise(resolve => {
                mongo.findId('unit', doc.actors[i].unit, (err, unit) => {
                  if (unit) {
                    if (unit.actors) {
                      for (let a in unit.actors) {
                        if (unit.actors[a].type && (unit.actors[a].type[0] === 'manager' || unit.actors[a].type[0] === 'assistant')) {
                          alarm.deparmentManager.push(unit.actors[a].user)
                        }
                      }
                    }
                  }
                  resolve()
                })
              })
            }
          }
        }

        alarm.reviewer = []
        for (let i in doc.actors) {
          if (doc.actors[i].role === 'reviser') {
            alarm.reviewer.push(doc.actors[i])
          }
        }

        alarm.supervisor = []
        for (let i in doc.actors) {
          if (doc.actors[i].supervisor === '1') {
            alarm.supervisor.push(doc.actors[i])
          }
        }

        alarm.snooze = []
        alarm.status = 'inactive'

        await new Promise(resolve => {
          mongo.save('reminders', alarm, () => {
            resolve()
          })
        })

        if (doc.termDays && doc.termDays !== '0') {
          let plan
          if (req.session.context.activePlan) {
            plan = await new Promise(resolve => {
              mongo.findId('plan', req.session.context.activePlan.id, (err, plan) => {
                if (!err && plan) {
                  resolve(plan)
                } else {
                  resolve(false)
                }
              })
            })
          } else {
            plan = false
          }
          let holiday = false
          var deadline = moment()
          let days = Number(doc.termDays)
          let calendar = ''
          var dateArray = []
          if (plan && plan.calendar) {
            calendar = await new Promise(resolve => {
              mongo.findId('calendar', plan.calendar, (err, calendar) => {
                if (!err && calendar) {
                  resolve(calendar)
                } else {
                  resolve(false)
                }
              })
            })
            if (calendar && calendar.days && calendar.days.length) {
              for (let i in calendar.days) {
                let day = calendar.days[i]
                var currentDate = day.fromAdd
                while (currentDate <= day.toAdd) {
                  dateArray.push(new Date(currentDate))
                  var date = new Date(currentDate)
                  currentDate = new Date(date.setDate(date.getDate() + 1))
                }
              }
            }
          }
          do {
            holiday = false
            deadline.add(1, 'days')
            if (calendar) {
              for (let d in dateArray) {
                let x = dateArray[d]
                if (new Date(deadline._d.setHours(0, 0, 0)).toString() === x.toString()) {
                  holiday = true
                  break
                }
              }
            } else {
              holiday = false
            }
            if (((calendar && ((deadline.isoWeekday() === 1 && calendar.monday === '1') ||
                                    (deadline.isoWeekday() === 2 && calendar.tuesday === '1') ||
                                    (deadline.isoWeekday() === 3 && calendar.wednesday === '1') ||
                                    (deadline.isoWeekday() === 4 && calendar.thursday === '1') ||
                                    (deadline.isoWeekday() === 5 && calendar.friday === '1') ||
                                    (deadline.isoWeekday() === 6 && calendar.saturday === '1') ||
                                    (deadline.isoWeekday() === 7 && calendar.sunday === '1'))) &&
                                !holiday) || !calendar) {
              days = days - 1
            }
          } while (days)
          doc.dates.push({
            type: tags.deadline,
            value: deadline._d
          })

          alarm.date = deadline._d
          alarm.status = 'active'

        }
        doc.status = tags.processing
        // email notification
        await new Promise(resolve => {
          doc.type = 'note'
          notification.notify(req, doc, mongo, send)
          resolve()
        })
        var user = {}
        for (const i in doc.actors) {
          if (doc.actors[i].user === req.session.context.user.toString()) {
            user = doc.actors[i]
            break
          }
        }
        var readers = []
        if (doc.actors) {
          for (const x in doc.actors) {
            if (doc.actors[x].path === tags.hidden) {
              doc.actors[x].path = tags.received
            }
            if (doc.actors[x].unit) {
              if (doc.actors[x].unit.equals(user.unit)) {
                readers.push(doc.actors[x].user)
              }
            }
          }
        }
        if (req.body.category && req.body.category !== '') {
          doc.category = req.body.category
        }
        if (unit && doc.sequence.text === '' && doc.sequence && doc.sequence.sequence) {
          mongo.findId('unit', unit, (err, unit) => {
            if (!err && unit && unit.sequences && unit.sequences.length > 0) {
              var i = 0
              if (doc.sequence && doc.sequence.sequence) {
                i = unit.sequences.findIndex(x => x._id.equals(doc.sequence.sequence))
              }
              if (i === -1) i = 0
              unit.sequences[i].code = unit.code
              sequence.next(unit.sequences[i], mongo, req.body.type, function (seq) {
                if (seq && seq.type === 'sequence') {
                  mongo.save('sequence', {
                    _id: seq._id,
                    lastValue: seq.lastValue
                  }, (err) => {
                    if (err) {
                      send()
                    } else {
                      doc.sequence = seq
                      replace(doc, 'sequence', seq.text)
                      saveSend(doc)
                    }
                  })
                } else if (seq && seq.type === 'unit') {
                  const p = unit.sequences.findIndex((x) => {
                    return x._id.toString() === seq._id.toString()
                  })
                  unit.sequences[p].lastValue = seq.lastValue
                  mongo.save('unit', unit, (err) => {
                    if (err) {
                      send()
                    } else {
                      doc.sequence = seq
                      replace(doc, 'sequence', seq.text)
                      saveSend(doc)
                    }
                  })
                } else {
                  saveSend(doc)
                }
              })
            } else {
              saveSend(doc)
            }
          })
        } else {
          saveSend(doc)
        }
      }

      function replace(doc, tag, value) {
        if (doc.content.compatibilityMode) {
          doc.content = JSON.stringify(doc.content)
          doc.content = doc.content.replace(new RegExp('{{' + tag + '}}', 'g'), value)
          doc.content = JSON.parse(doc.content)
        } else {
          doc.content = doc.content.replace(new RegExp('{{' + tag + '}}', 'g'), value)
        }
      }

      function saveSend (doc) {
        var idsLink = []
        mongo.find('attached', {
          reference: doc._id
        }, {
          content: 0
        }, {
          _id: -1
        }, (err, atts) => {
          if (err) throw err
          if (atts && atts.length > 0) {
            for (const i in atts) {
              idsLink.push(atts[i]._id)
            }
            var attended = true
            saveDocLink(0, idsLink, doc, attended)
          } else {
            mongo.save('note', doc, async (err) => {
              if (err) {
                send()
              } else {
                await new Promise(resolve => {
                  req.app.routes.eventUtil.save(req, mongo, 'statusChange', doc.status, doc._id, '', 'note', () => {
                    resolve()
                  })
                })
                var toNoti = []
                const noti = {
                  _id: mongo.newId(),
                  actors: [],
                  document: {
                    id: doc._id,
                    status: doc.status
                  },
                  collection: 'note',
                  path: 'note.note',
                  type: 5,
                  user: req.session.context.user
                }
                noti.createdAt = noti._id.getTimestamp()
                for (const i in doc.actors) {
                  if (doc.actors[i].role === 'to' || doc.actors[i].role === 'copy') {
                    noti.actors.push({
                      user: doc.actors[i].user,
                      seen: 0
                    })
                    toNoti.push(doc.actors[i].user)
                  }
                }
                await new Promise(resolve => {
                  mongo.save('notification', noti, (err, result) => {
                    if (!err) {
                      resolve(result)
                    }
                  })
                })
                var comment = {
                  _id: mongo.newId(),
                  collection: 'note',
                  comment: 'Envió la nota', //Envió la nota
                  dateTime: new Date(),
                  document: doc._id,
                  documentType: 'note',
                  involved: [],
                  mentions: [],
                  unread: [],
                  user: req.session.context.user
                }
                for (const i in doc.actors) {
                  comment.mentions.push(mongo.toId(doc.actors[i].user))
                  if (doc.actors[i].user.toString() !== req.session.context.user.toString() && doc.actors[i].path !== 'hidden') {
                    comment.unread.push(doc.actors[i].user)
                    comment.involved.push(doc.actors[i].user)
                  }
                }
                await new Promise(resolve => {
                  mongo.save('comment', comment, (err, result) => {
                    if (!err) {
                      resolve(result)
                    } else {
                      resolve()
                    }
                  })
                })
                notification.send(req, req.session.context.room, 'badgeNotification', null, toNoti, null)
                notification.pushNotification(req, doc, noti, toNoti)
                send({
                  message: tags.document + ' ' + tags.sent
                })
                sendNotification(req, mongo, send, doc, null)
              }
            })
          }
        })

        function saveDocLink (y, idsLink, doc, attended) {
          mongo.findId('attached', idsLink[y], async (err, docLink) => {
            if (err) throw err
            if (docLink) {
              docLink.dates = doc.dates
              docLink.issued = '1'
              docLink.sequence = doc.sequence
              if (docLink.requiredResponse === '1') {
                docLink.status = 'processing'
                attended = false
              } else {
                docLink.status = 'completed'
              }
              /// ///////revisar despues////////////////
              let responsibleActor = ''
              for (let r in docLink.actors) {
                if (docLink.actors[r].role === 'responsible') {
                  responsibleActor = docLink.actors[r]
                }
              }
              docLink.actors = []
              /// ////////////////////////////////
              let actor
              for (let i in doc.actors) {
                if (!responsibleActor || responsibleActor && responsibleActor.user.toString() !== doc.actors[i].user.toString()) {
                  switch (doc.actors[i].role) {
                  case 'to':
                    actor = {}
                    actor.user = doc.actors[i].user
                    actor.unit = doc.actors[i].unit
                    actor.role = 'inCharge'
                    actor.path = 'received'
                    docLink.actors.push(actor)
                    break
                  case 'copy':
                    actor = {}
                    actor.user = doc.actors[i].user
                    actor.unit = doc.actors[i].unit
                    actor.role = 'inCharge'
                    actor.path = 'referred'
                    docLink.actors.push(actor)
                    break
                  default:
                    actor = doc.actors[i]
                    docLink.actors.push(actor)
                    break
                  }
                }
              }
              if (responsibleActor) {
                responsibleActor.path = 'received'
                docLink.actors.push(responsibleActor)
              }

              let existAlarmDate = ''
              if (docLink.dates && docLink.dates.length) {
                for (let d in docLink.dates) {
                  if (docLink.dates[d].type === 'deadline') {
                    existAlarmDate = docLink.dates[d].value
                  }
                }
              }

              if (existAlarmDate) {
                //************* creacion de alarmas ******/
                let alarm = {}
                alarm._id = mongo.newId()
                alarm.type = 'attached'
                alarm.document = docLink._id
                alarm.date = existAlarmDate
                alarm.cleared = ''

                alarm.owner = []
                alarm.deparmentManager = []
                for (let i in docLink.actors) {
                  if (docLink.actors[i].role === 'responsible') {
                    alarm.owner.push(docLink.actors[i])

                    if (docLink.actors[i].unit) {
                      await new Promise(resolve => {
                        mongo.findId('unit', docLink.actors[i].unit, (err, unit) => {
                          if (unit) {
                            if (unit.actors) {
                              for (let a in unit.actors) {
                                if (unit.actors[a].type && (unit.actors[a].type[0] === 'manager' || unit.actors[a].type[0] === 'assistant')) {
                                  alarm.deparmentManager.push(unit.actors[a].user)
                                }
                              }
                            }
                          }
                          resolve()
                        })
                      })
                    }
                  }
                }

                alarm.reviewer = []
                for (let i in docLink.actors) {
                  if (docLink.actors[i].role === 'reviser') {
                    alarm.reviewer.push(docLink.actors[i])
                  }
                }

                alarm.supervisor = []
                for (let i in docLink.actors) {
                  if (docLink.actors[i].supervisor === '1' || docLink.actors[i].role === 'from') {
                    alarm.supervisor.push(docLink.actors[i])
                  }
                }

                alarm.snooze = []
                alarm.status = 'active'

                await new Promise(resolve => {
                  mongo.save('reminders', alarm, () => {
                    resolve()
                  })
                })
              }

              mongo.save('attached', docLink, async (err) => {
                if (err) {
                  send()
                } else {
                  await new Promise(resolve => {
                    req.app.routes.eventUtil.save(req, mongo, 'statusChange', docLink.status, docLink._id, '', 'attached', () => {
                      resolve()
                    })
                  })
                  if (idsLink.length - 1 > y) {
                    y++
                    saveDocLink(y, idsLink, doc, attended)
                  } else {
                    if (attended) {
                      doc.status = 'attended'
                    }
                    mongo.save('note', doc, async (err) => {
                      if (err) {
                        send()
                      } else {
                        await new Promise(resolve => {
                          req.app.routes.eventUtil.save(req, mongo, 'statusChange', doc.status, doc._id, '', 'note', () => {
                            resolve()
                          })
                        })
                        var toNoti = []
                        const noti = {
                          _id: mongo.newId(),
                          actors: [],
                          document: {
                            id: doc._id,
                            status: doc.status
                          },
                          collection: 'note',
                          path: 'note.note',
                          type: 5,
                          user: req.session.context.user
                        }
                        noti.createdAt = noti._id.getTimestamp()
                        for (const i in doc.actors) {
                          if (doc.actors[i].role === 'to' || doc.actors[i].role === 'copy') {
                            noti.actors.push({
                              user: doc.actors[i].user,
                              seen: 0
                            })
                            toNoti.push(doc.actors[i].user)
                          }
                        }
                        await new Promise(resolve => {
                          mongo.save('notification', noti, (err, result) => {
                            if (!err) {
                              resolve(result)
                            }
                          })
                        })
                        var comment = {
                          _id: mongo.newId(),
                          collection: 'note',
                          comment: 'Envió la nota',
                          dateTime: new Date(),
                          document: doc._id,
                          documentType: 'note',
                          involved: [],
                          mentions: [],
                          unread: [],
                          user: req.session.context.user
                        }
                        for (const i in doc.actors) {
                          comment.mentions.push(mongo.toId(doc.actors[i].user))
                          if (doc.actors[i].user.toString() !== req.session.context.user.toString() && doc.actors[i].path !== 'hidden') {
                            comment.unread.push(doc.actors[i].user)
                            comment.involved.push(doc.actors[i].user)
                          }
                        }
                        await new Promise(resolve => {
                          mongo.save('comment', comment, (err, result) => {
                            if (!err) {
                              resolve(result)
                            } else {
                              resolve()
                            }
                          })
                        })
                        notification.send(req, req.session.context.room, 'badgeNotification', null, toNoti, null)
                        notification.pushNotification(req, doc, noti, toNoti)
                        send({
                          message: tags.document + ' ' + tags.sent
                        })
                        sendNotification(req, mongo, send, doc, null)
                      }
                    })
                  }
                }
              })
            }
          })
        }
      }

      function sendNotification (req, mongo, send, doc, deleted) {
        doc.id = doc._id
        mongo.find('params', {
          name: 'tag'
        }, {
          _id: 1,
          name: 1,
          options: 1
        }, (_er, tagsDoc) => {
          var user = []
          var y = doc.actors.findIndex((x) => {
            return x.role !== 'reviser' && x.user.equals && x.user.equals(req.session.context.user)
          })
          if (y === -1) {
            y = doc.actors.findIndex((x) => {
              return x.user.equals && x.user.equals(req.session.context.user)
            })
          }
          if (y !== -1) {
            var actual = doc.actors[y]
            var role = actual.path === 'sent' ? 'to' : 'from'
            y = doc.actors.findIndex((x) => {
              return x.role === role
            })
            if (y !== -1) {
              doc.actor = {
                user: doc.actors[y].user,
                path: actual.role === 'copy' ? 'referred' : actual.path
              }
            }
          }
          for (const i in doc.actors) {
            user.push(doc.actors[i].user)
          }
          mongo.toHash('user', {
            _id: {
              $in: user
            }
          }, {
            _id: 1,
            name: 1
          }, (_er, users) => {
            var data = broadcastItem(req, mongo, send, doc, users, tagsDoc)
            var user = [req.session.context.user]
            notification.send(req, '', 'dtnotes', data, user, deleted)
            var UsersTo = []
            var UsersCopy = []
            for (const i in doc.actors) {
              if (doc.actors[i].role === 'to') {
                UsersTo.push(doc.actors[i].user)
              }
              if (doc.actors[i].role === 'copy') {
                UsersCopy.push(doc.actors[i].user)
              }
              if (doc.actors[i].role === 'from') {
                doc.actor = doc.actors[i]
              }
            }
            var Data = broadcastItem(req, mongo, send, doc, users, tagsDoc)
            Data.path = 'received'
            Data.pathName = 'received'
            if (UsersTo.length > 0) {
              notification.send(req, '', 'dtnotes', Data, UsersTo, deleted)
            }
            Data.path = 'referred'
            Data.pathName = 'referred'
            if (UsersCopy.length > 0) {
              notification.send(req, '', 'dtnotes', Data, UsersCopy, deleted)
            }
          })
        })
      }

      function broadcastItem (req, mongo, _send, doc, users, tagsDoc) {
        var tagsId = []
        tagsId.push(doc.tags)
        var usedTags = []
        if (tagsDoc[0]) {
          for (let t = 0; t < tagsDoc[0].options.length; t++) {
            for (let o = 0; o < tagsId.length; o++) {
              if (tagsId[o] && tagsDoc[0].options[t].id.toString() === tagsId[o].toString()) {
                usedTags.push(tagsDoc[0].options[t])
              }
            }
          }
        }
        var actor = doc.actor ? doc.actor : {}
        var username = actor.user ? (mongo.isNativeId(actor.user) && users[actor.user.toString()] ? users[actor.user.toString()].name : actor.user) : ''
        return row(doc, req, actor, username, usedTags)
      }

      function row (doc, _req, actor, username, usedTags) {
        var issue = {}

        var deadline = {}
        for (const x in doc.dates) {
          if (doc.dates[x].type === 'issue') {
            issue = doc.dates[x]
          } else if (doc.dates[x].type === 'deadline') {
            deadline = doc.dates[x]
          }
        }
        var attachments = 'none'
        if (doc.files && doc.files.length > 0) {
          for (const x in doc.files) {
            if (doc.files[x]) {
              attachments = 'attachment'
            }
          }
        }
        const expired = doc.status === tags.processing && deadline.value && deadline.value.getTime() <= new Date().getTime() ? tags.expired : undefined
        var tagscolor = []
        var tagsname = []
        var filterNames = [usedTags[0] ? usedTags[0].value : '']
        for (const i in usedTags) {
          tagscolor.push(usedTags[i].color)
          tagsname.push(usedTags[i].value)
        }
        var row = {
          id: doc._id.toString(),
          attachments: attachments,
          expired: expired,
          css: expired || doc.status || tags.processing,
          status: doc.status ? doc.status : tags.processing,
          statusName: doc.status,
          role: actor.role,
          user: actor.user,
          userName: username,
          sequence: doc.sequence && doc.sequence.text ? doc.sequence.text : '',
          name: doc.name,
          path: actor.path,
          pathName: actor.path,
          issue: issue.value ? tags.util.date2str(issue.value, 'yyyy/mm/dd', tags) : '',
          category: doc.category || '',
          deadline: deadline.value ? tags.util.date2str(deadline.value, 'yyyy/mm/dd', tags) : '',
          tagscolor: tagscolor,
          tagsname: tagsname,
          filterNames: filterNames,
          issued: doc.issued
        }
        if (doc.type) {
          row.type = doc.type
        }
        return row
      }
    })
  }

  addActors (req, id, actors, mongo, next) {
    mongo.findId('note', id, {
      _id: 1,
      actors: 1,
      issued: 1,
      reference: 1
    }, (err, doc) => {
      if (err || !doc) {
        next(err)
      } else {
        /* let path = ''
                let index = doc.actors.findIndex((x) => {
                  return x.user.toString() === req.session.context.user.toString()
                })
                if (index !== -1) {
                  path = doc.actors[index].path
                } */
        for (const i in actors) {
          const rm = doc.actors.findIndex((actor) => {
            return actor.user.toString() === actors[i].user.toString()
          })
          if (rm === -1) {
            //if(path && actors[i].role !== 'copy') actors[i].path = path
            doc.actors.push(actors[i])
          }
        }
        mongo.save('note', doc, async (err) => {
          let note = doc
          if (note) {
            await new Promise(resolve => {
              mongo.find('attached', {
                reference: note._id
              }, {}, async (err, atts) => {
                if (atts && atts.length) {
                  for (let t in atts) {
                    for (let i in actors) {
                      let rm = atts[t].actors.findIndex((actor) => {
                        return actor.user.toString() === actors[i].user.toString()
                      })
                      if (rm === -1) {
                        //if (path) actors[i].path = path
                        atts[t].actors.push(actors[i])
                      }
                    }
                    await new Promise(resolve => {
                      mongo.save('attached', atts[t], async () => {
                        mongo.findOne('commitment', {
                          reference: atts[t]._id
                        }, {
                          _id: 1,
                          actors: 1,
                          reference: 1
                        }, async (err, comm) => {
                          if (comm) {
                            for (let i in actors) {
                              let rm = comm.actors.findIndex((actor) => {
                                return actor.user.toString() === actors[i].user.toString()
                              })
                              if (rm === -1) {
                                //if (path) actors[i].path = path
                                comm.actors.push(actors[i])
                              }
                            }
                            await new Promise(resolve => {
                              mongo.save('commitment', comm, () => {
                                mongo.findOne('evidence', {
                                  reference: comm._id
                                }, {
                                  _id: 1,
                                  actors: 1,
                                  reference: 1
                                }, async (err, evid) => {
                                  if (evid) {
                                    for (let i in actors) {
                                      let rm = evid.actors.findIndex((actor) => {
                                        return actor.user.toString() === actors[i].user.toString()
                                      })
                                      if (rm === -1) {
                                        //if (path) actors[i].path = path
                                        evid.actors.push(actors[i])
                                      }
                                    }
                                    await new Promise(resolve => {
                                      mongo.save('evidence', evid, () => {
                                        resolve()
                                      })
                                    })
                                  }
                                  resolve()
                                })
                              })
                            })
                          }
                        })
                      })
                      resolve()
                    })
                  }
                }
                resolve()
              })
            })
          }
          next(err, doc)
        })
      }
    })
  }

  addActor (id, role, actors, mongo) {
    actors = actors.filter(function (el) {
      return el.role !== role
    })
    var vec
    if (role === 'from' && id.length !== 54) {
      vec = id
    } else {
      vec = id.split(',')
    }
    if (vec[0] !== '') {
      for (const i in vec) {
        const ids = vec[i].split('&unit=')
        if (mongo.isNativeId(ids[0]) && mongo.isNativeId(ids[1])) {
          var user = mongo.toId(ids[0])
          actors = actors.filter(function (el) {
            return el.user !== user.toString()
          })
          actors.push({
            user: user,
            path: role === 'from' ? 'sent' : 'hidden',
            role: role,
            unit: mongo.toId(ids[1])
          })
        }
      }
    }
    return actors
  }

  saveLink (req, mongo, send) {
    mongo.findId('note', req.body._id, (err, doc) => {
      if (err) {
        req.statusCode = 400
        send({
          error: err
        })
      } else if (doc) {
        if (doc.links && typeof doc.links === 'object' && typeof req.body.links === 'object') {
          for (const i in req.body.links) {
            const y = doc.links.findIndex((x) => {
              return x._id.toString() === req.body.links[i]._id
            })
            if (y === -1) {
              doc.links.push(req.body.links[i])
            }
          }
        } else {
          doc.links = []
          if (typeof req.body.links === 'object') {
            for (const i in req.body.links) {
              doc.links.push(req.body.links[i])
            }
          }
        }
        mongo.save('note', doc, (err) => {
          if (err) {
            send()
          } else {
            send({
              message: tags.savedChanges
            })
          }
        })
      } else {
        send(req.status = 400)
      }
    })
  }

  removeLink (req, mongo, send) {
    mongo.findId('note', req.body._id, {
      links: 1
    }, (err, doc) => {
      if (err) {
        req.status = 400
        send({
          error: err
        })
      } else if (doc) {
        const y = doc.links.findIndex((x) => {
          return x._id.toString() === req.body.link
        })
        if (y !== -1) {
          doc.links.splice(y, 1)
        }
        mongo.save('note', doc, (err) => {
          if (err) {
            send()
          } else {
            send({
              message: tags.savedChanges
            })
          }
        })
      } else {
        send(req.status = 400)
      }
    })
  }

  uploadContent (req, mongo, send) {
    this.save(req, mongo, send)
  }

  save (req, mongo, send) {
    mongo.findId('note', req.body._id, async (err, docs) => {
      if (err) {
        send({
          error: err
        })
      } else {
        const doc = req.body
        doc._id = mongo.toId(req.body._id.toString())
        if (err) throw err
        if (doc.type === 'spreadsheet') {
          doc.content = JSON.stringify(doc.content)
        }
        if (!docs) {
          if (doc.replyTo) {
            doc.links = [JSON.parse(JSON.stringify(doc.replyTo))]
          }
        } else {
          doc.actors = docs.actors
          if (!doc.status) {
            doc.status = docs.status
          }
        }
        if ((docs && docs.status === 'processing') && doc.status === 'draft') {
          send({
            msj: 'noteAlreadySent'
          })
        } else {
          if (doc.status === 'docReady') {
            doc.status = 'ready'
            for (const i in doc.actors) {
              switch (doc.actors[i].role) {
              case 'reviser':
                doc.actors[i].path = 'sent'
                break
              case 'from':
              case 'supervisor':
                doc.actors[i].path = 'sent'
                doc.actors[i].role = 'supervisor'
                break
              }
            }
          }
          if (doc.status === 'draft' || doc.status === 'send') {
            if (doc.from) {
              doc.actors = this.addActor(doc.from, tags.from, doc.actors, mongo)
            } else {
              for (let i in doc.actors) {
                if (doc.actors[i].role === 'from') {
                  doc.actors.splice(i, 1)
                }
              }
            }
            if (doc.to) {
              doc.actors = this.addActor(doc.to, tags.to, doc.actors, mongo)
            } else {
              function remov (actors) {
                for (let i in actors) {
                  if (actors[i].role === 'to') {
                    actors.splice(i, 1)
                    remov(actors)
                  }
                }
              }
              remov(doc.actors)
            }
            if (doc.copy) {
              doc.actors = this.addActor(doc.copy, tags.copy, doc.actors, mongo)
            } else {
              function remov (actors) {
                for (let i in actors) {
                  if (actors[i].role === 'copy') {
                    actors.splice(i, 1)
                    remov(actors)
                  }
                }
              }
              remov(doc.actors)
            }
          }
          var tempContent
          if (doc.extractContent || doc.fileHtml) {
            let stream = new Readable()
            stream.push(doc.content) // the string you want
            stream.push(null) // indicates end-of-file basically - the end of the stream
            tempContent = doc.content
            doc.content = ''
            let link = await new Promise(resolve => {
              mongo.putFile('contenido_Nota.html', stream, {
                document: doc._id
              }, (err, res) => {
                if (err) {
                  console.log(err)
                  resolve({
                    error: err
                  })
                } else {
                  resolve(res)
                }
              }, doc.fileHtml || false)
            })
            if (link.error) {
              send({
                error: link.error
              })
            } else {
              doc.fileHtml = link._id
            }
          }
          delete doc.extractContent
          delete doc.comment
          delete doc.user
          delete doc.timeString
          delete doc.replyTo
          delete doc.isNew
          delete doc.delegates
          delete doc.mentions
          delete doc.to
          delete doc.copy
          delete doc.from
          delete doc.referenceNote
          var units = req.session.units || []
          for (const i in doc.actors) {
            if (doc.actors[i].user === req.session.context.user.toString() && doc.actors[i].unit) {
              units = [mongo.toId(doc.actors[i].unit)]
              break
            }
          }
          var readers = []
          for (const i in doc.actors) {
            if (doc.actors[i].unit) {
              if (doc.actors[i].role === tags.from || units.findIndex(function (x) {
                return x.toString() === doc.actors[i].unit
              }) !== -1) {
                readers.push(doc.actors[i].user)
              }
            }
          }
          // Add or update dates.issue
          if (doc.dates && doc.dates.length > 0) {
            doc.dates[0].value = new Date()
          } else {
            doc.dates = [{
              type: tags.issue,
              value: new Date()
            }]
          }
          if (doc.deadline) {
            doc.dates[1] = {
              type: tags.deadline,
              value: doc.deadline
            }
            delete doc.deadline
          }
          html.getData(doc.type === 'redactor' || doc.type === 'note' ? doc.content : '', async (data) => {
            if (data.links && data.links.length > 0) {
              if (!doc.links) {
                doc.links = (docs && docs.links) ? docs.links : []
              }
              for (const i in data.links) {
                if (doc.links.findIndex((lk) => {
                  return lk._id === data.links[i]._id
                }) === -1) {
                  doc.links.push({
                    _id: data.links[i]._id,
                    clase: data.links[i].clase
                  })
                }
              }
            }
            if (doc.links && doc.links[0] === '{}') {
              delete doc.links
            }
            if (doc.tags === '') {
              doc.tags = []
            } else {
              doc.tags = doc.tags.split(',')
              for (const i in doc.tags) {
                doc.tags[i] = mongo.toId(doc.tags[i])
              }
            }
            if (doc.reference) {
              await new Promise(resolve => {
                mongo.save('note', {
                  _id: mongo.toId(doc.reference),
                  answered: '1'
                }, (err, result) => {
                  if (!err) {
                    resolve(result)
                  }
                })
              })
            }
            if (doc.status === 'send') {
              let attchs = await new Promise(resolve => {
                mongo.find('attached', {
                  reference: mongo.toId(doc._id)
                }, (err, attchs) => {
                  if (!err) {
                    resolve(attchs)
                  }
                })
              })
              let ex = attchs.findIndex((x) => {
                return x.status === 'draft'
              })
              if (ex === -1) {
                this.send(req, mongo, send)
              } else {
                send({
                  error: 'Hay anexos en estado borrador'
                })
              }
            } else {
              if (doc.content.parentNode) {
                delete doc.content.next
                delete doc.content.parent
                delete doc.content.prev
                delete doc.content.root
                delete doc.content.parentNode
              }

              mongo.save('note', doc, async (err) => {
                if (tempContent)
                  doc.content = tempContent
                if (err) {
                  send()
                } else {
                  await new Promise(resolve => {
                    req.app.routes.eventUtil.save(req, mongo, 'statusChange', doc.status, doc._id, '', 'note', () => {
                      resolve()
                    })
                  })
                  send({
                    message: tags.savedChanges,
                    doc: doc
                  })
                  this.sendNotification(req, mongo, send, doc)
                }
              })
            }
          })
        }
      }
    })
  }

  sendNotification (req, mongo, send, doc, deleted) {
    doc.id = doc._id
    mongo.find('params', {
      name: 'tag'
    }, {
      _id: 1,
      name: 1,
      options: 1
    }, (_er, tagsDoc) => {
      var user = []
      var unit = []
      var y = doc.actors.findIndex((x) => {
        return x.role !== 'reviser' && x.user.equals && x.user.equals(req.session.context.user)
      })
      if (y === -1) {
        y = doc.actors.findIndex((x) => {
          return x.user.equals && x.user.equals(req.session.context.user)
        })
      }
      if (y !== -1) {
        var actual = doc.actors[y]
        var role = actual.path === 'sent' ? 'to' : 'from'
        y = doc.actors.findIndex((x) => {
          return x.role === role
        })
        if (y !== -1) {
          doc.actor = {
            user: doc.actors[y].user,
            unit: doc.actors[y].unit,
            path: actual.role === 'copy' ? 'referred' : actual.path
          }
        }
      }
      if (!doc.actor) {
        doc.actor = doc.actors[0]
      }
      for (const i in doc.actors) {
        user.push(doc.actors[i].user)
        unit.push(doc.actors[i].unit)
      }
      mongo.toHash('unit', {
        _id: {
          $in: unit
        }
      }, {
        _id: 1,
        name: 1
      }, (_er, units) => {
        mongo.toHash('user', {
          _id: {
            $in: user
          }
        }, {
          _id: 1,
          name: 1
        }, (_er, users) => {
          var data = this.broadcastItem(req, mongo, send, doc, users, units, tagsDoc)
          var Users = []
          for (const i in doc.actors) {
            if (doc.actors[i].path !== 'hidden') {
              Users.push(doc.actors[i].user)
            }
          }
          notification.send(req, req.session.context.room, 'dtnotes', data, Users, deleted)
          if (doc.project) {
            notification.send(req, req.session.context.room, 'projectDocuments.' + doc.project.toString(), data, null, deleted)
            if (doc.task) notification.send(req, req.session.context.room, 'taskDocuments.' + doc.task.toString(), data, null, deleted)
          }
        })
      })
    })
  }

  print (req, mongo, send) {
    mongo.findId('note', req.query._id, (err, doc) => {
      if (err) send({
        error: err
      })
      else {
        send(html.print(doc.content))
      }
    })
  }

  async listTree (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = {
      data: [],
      pos: skip
    }
    var tagsDoc = []
    await new Promise(resolve => {
      mongo.find('params', {
        name: {
          $in: ['riskLevel', 'tag']
        }
      }, {
        _id: 1,
        name: 1,
        options: 1
      }, (_er, tgsDs) => {
        if (tgsDs.length > 0) {
          for (const i in tgsDs) {
            tagsDoc = tagsDoc.concat(tgsDs[i].options)
          }
        }
        resolve()
      })
    })
    var keys
    if (req.query.project) {
      keys = {
        project: mongo.toId(req.query.project)
      }
    } else {
      keys = await req.app.routes.attached.$keys(req, mongo)
      if (req.query.start === 0) {
        delete req.query.continue
      }
    }
    /* apply filter in parameters */
    var referenceId = mongo.toId(req.query.reference)
    var attachedId = await new Promise(resolve => {
      mongo.findId('commitment', referenceId, {
        reference: 1
      }, (err, comm) => {
        if (err) console.log(err)
        resolve(comm ? comm.reference : null)
      })
    })
    var noteId = await new Promise(resolve => {
      mongo.findId('attached', attachedId || referenceId, {
        reference: 1
      }, (err, att) => {
        if (err) console.log(err)
        resolve(att ? att.reference : null)
      })
    })
    mongo.findId('note', noteId || referenceId, {}, {
      name: 1
    }, (err, note) => {
      if (err || !note) {
        send(reply)
      } else {
        mongo.find('attached', {
          $and: [{
            reference: note._id
          }, keys]
        }, {}, {
          name: 1
        }, async (err, docs) => {
          if (err) {
            send({
              error: err
            })
          } else {
            if (docs.length > 0) {
              const references = []
              const IDS = []
              for (const i in docs) {
                IDS.push(docs[i]._id)
                if (docs[i].reference) {
                  references.push(docs[i].reference)
                }
              }
              keys = await req.app.routes.commitment.$keys(req, mongo)
              var commitments = await new Promise(resolve => {
                mongo.aggregate('commitment', [{
                  $lookup: {
                    from: 'attached',
                    localField: 'reference',
                    foreignField: '_id',
                    as: 'att'
                  }
                },
                {
                  $unwind: '$att'
                },
                {
                  $lookup: {
                    from: 'note',
                    localField: 'att.reference',
                    foreignField: '_id',
                    as: 'note'
                  }
                },
                {
                  $unwind: '$note'
                },
                {
                  $addFields: {
                    actor: {
                      $filter: {
                        input: '$actors',
                        as: 'actor',
                        cond: {
                          $eq: ['$$actor.role', 'responsible']
                        }
                      }
                    }
                  }
                },
                {
                  $lookup: {
                    from: 'unit',
                    localField: 'actor.unit',
                    foreignField: '_id',
                    as: 'unit'
                  }
                },
                {
                  $addFields: {
                    sequence: '$note.sequence',
                    confidential: '$note.confidential',
                    actorsT: '$att.actors',
                    tags: '$att.tags',
                    offline: {
                      $arrayElemAt: [{
                        $ifNull: ['$unit.offline', [false]]
                      }, 0]
                    }
                  }
                },
                {
                  $addFields: {
                    isShow: {
                      $function: {
                        body: `function (offline, status, actors, user, assistantUnits) {
                            if (status === 'draft') {
                              for (let a in actors) {
                                let act = actors[a]
                                if ((hex_md5(user.toString()) === hex_md5(act.user.toString())) && offline && (act.role === 'from' || act.role === 'reviser' || act.role === 'supervisor') && (act.path === 'sent')) {
                                  return true
                                }
                                if ((hex_md5(user.toString()) === hex_md5(act.user.toString())) && act.role === 'responsible') {
                                  return true
                                }
                                if (assistantUnits && assistantUnits.length) {
                                  for (let i in assistantUnits) {
                                    if ((act.unit && hex_md5(assistantUnits[i].toString()) === hex_md5(act.unit.toString())) && act.role === 'responsible') {
                                      return true
                                    }
                                  }
                                }
                              }
                            } else {
                              return true
                            }
                          }`,
                        args: ['$offline', '$status', '$actorsT', req.session.context.user, req.session.context.assistantUnits],
                        lang: 'js'
                      }
                    }
                  }
                },
                {
                  $match: {
                    $and: [keys, {
                      reference: {
                        $in: IDS
                      }
                    }]
                  }
                },
                {
                  $match: {
                    isShow: true
                  }
                },
                {
                  $sort: {
                    name: 1
                  }
                }
                ], {}, (err, commit) => {
                  if (!err) {
                    resolve(commit)
                  } else {
                    resolve([])
                  }
                })
              })
              if (commitments.length > 0) {
                const references = []
                const IDS = []
                for (const i in commitments) {
                  IDS.push(commitments[i]._id)
                  commitments[i].tipo = 'comm'
                  if (commitments[i].reference) {
                    references.push(commitments[i].reference)
                  }
                }
                var evidences = await new Promise(resolve => {
                  mongo.find('evidence', {
                    reference: {
                      $in: IDS
                    }
                  }, {}, {
                    name: 1
                  }, async (err, evid) => {
                    if (!err && evid) {
                      let data = []
                      for (let e in evid) {
                        var offlineUnit = true
                        var responsableUnit = ''
                        var responsableUnitActors = ''
                        for (let r in commitments) {
                          if (commitments[r]._id.toString() === evid[e].reference.toString()) {
                            if (commitments[r].att && commitments[r].att.actors) {
                              for (let d in commitments[r].att.actors) {
                                if (commitments[r].att.actors[d].role === 'responsible') {
                                  if (commitments[r].att.actors[d].unit) {
                                    await new Promise(resolve => {
                                      mongo.findId('unit', commitments[r].att.actors[d].unit, (err, u) => {
                                        if (u) {
                                          offlineUnit = u.offline || false
                                          responsableUnit = u._id
                                          responsableUnitActors = u.actors
                                        }
                                        resolve()
                                      })
                                    })
                                  }
                                }
                              }
                            }
                            break
                          }
                        }
                        evid[e].responsableUnit = responsableUnit
                        evid[e].responsableUnitActors = responsableUnitActors
                        if (evid[e].status === 'draft') {
                          let exist = false
                          let revisorNotView = false
                          let indexC = note.actors.findIndex((x) => {
                            return x.user.toString() === req.session.context.user.toString() && x.role === 'copy'
                          })
                          if (indexC !== -1) {
                            evid[e].copyUser = true
                          }
                          let indexN = note.actors.findIndex((x) => {
                            return x.user.toString() === req.session.context.user.toString() && (x.role === 'reviser' || x.role === 'from' || x.role === 'supervisor')
                          })
                          if (indexN !== -1) {
                            if (!offlineUnit) {
                              revisorNotView = true
                            }
                          }
                          evid[e].revisorNotView = revisorNotView
                          let indexR = evid[e].actors.findIndex((x) => {
                            return x.user.toString() === req.session.context.user.toString() && x.role === 'responsible' && x.path === 'hidden'
                          })
                          if (indexR !== -1) exist = true
                          if (exist) {
                            let index = evid[e].actors.findIndex((x) => {
                              return x.user.toString() === req.session.context.user.toString() && x.role !== 'responsible' && x.path === 'sent'
                            })
                            if (index !== -1) {
                              exist = false
                            } else {
                              let indexR = evid[e].actors.findIndex((x) => {
                                return x.role === 'responsible' && x.path === 'sent'
                              })
                              if (indexR !== -1) {
                                let user = evid[e].actors[indexR].user
                                if (evid[e].responsableUnitActors) {
                                  for (let r in evid[e].responsableUnitActors) {
                                    if (evid[e].responsableUnitActors[r].user.toString() === user.toString() && evid[e].responsableUnitActors[r].type && evid[e].responsableUnitActors[r].type[0] === 'assistant') {
                                      exist = false
                                      break
                                    }
                                  }
                                }
                              }
                            }
                          }
                          if (!exist) data.push(evid[e])
                        } else {
                          data.push(evid[e])
                        }
                      }
                      resolve(data)
                    } else {
                      resolve([])
                    }
                  })
                })
              }
            }
            var allDocs = []
            allDocs = allDocs.concat(note)
            if (docs && docs.length > 0) {
              allDocs = allDocs.concat(docs)
            }
            if (commitments && commitments.length > 0) {
              allDocs = allDocs.concat(commitments)
            }
            if (evidences && evidences.length > 0) {
              for (let i in evidences) {
                evidences[i].tipo = 'evi'
              }
              allDocs = allDocs.concat(evidences)
            }
            docs = allDocs

            let i = docs.length
            while (i--) {
              if (req.query.filter) {
                if (req.query.filter.tagsname && req.query.filter.tagsname.length > 0 && docs[i].tags && docs[i].tags.findIndex((x) => {
                  return x.equals(mongo.toId(req.query.filter.tagsname))
                }) === -1) {
                  docs.splice(i, 1)
                } else if (req.query.filter.name && !docs[i].name.toLowerCase().includes(req.query.filter.name.toLowerCase())) {
                  docs.splice(i, 1)
                } else if (req.query.filter.status && req.query.filter.status !== 'default' && docs[i].status !== req.query.filter.status) {
                  docs.splice(i, 1)
                }
              }
            }

            var users = []
            for (const i in docs) {
              const doc = docs[i]
              var y = doc.actors.findIndex((x) => {
                if (x) {
                  return x.role !== 'reviser' && x.user && x.user.equals && x.user.equals(req.session.context.user)
                }
              })
              if (y !== -1) {
                var actual = doc.actors[y]
                var role = actual.path === 'sent' ? 'to' : 'from'
                y = doc.actors.findIndex((x) => {
                  return x.role === role
                })
                if (y !== -1) {
                  doc.actor = {
                    user: doc.actors[y].user,
                    path: actual.role === 'copy' ? 'referred' : actual.path
                  }
                }
              }
              let event = ''
              if (doc.tipo && (doc.tipo === 'comm' || doc.tipo === 'evi')) {
                event = await new Promise(resolve => {
                  mongo.find('event', {
                    docId: doc._id
                  }, {}, {
                    id: 1
                  }, (err, ev) => {
                    if (err || !ev) {
                      resolve('')
                    } else {
                      resolve(ev[0])
                    }
                  })
                })
              }
              if (event && event.user) {
                doc.event = event
                users.push(event.user)
              } else {
                if (!doc.actor) {
                  doc.actor = doc.actors[0]
                }
                if (doc.actor && doc.actor.user) users.push(doc.actor.user)
              }
            }
            mongo.toHash('user', {}, {
              _id: 1,
              name: 1
            }, async (_er, users) => {
              if (docs) {
                for (let i = 0; i < docs.length; ++i) {
                  var tagsId = docs[i].tags
                  var usedTags = []
                  if (tagsDoc.length > 0 && tagsId && tagsId.length > 0) {
                    for (let t = 0; t < tagsDoc.length; t++) {
                      if (tagsId.length) {
                        for (let o = 0; o < tagsId.length; o++) {
                          if (tagsDoc[t].id && tagsId[o] && tagsDoc[t].id.toString() === tagsId[o].toString()) {
                            usedTags.push(tagsDoc[t])
                          }
                        }
                      } else {
                        if (tagsDoc[t] && tagsId && tagsDoc[t].id.toString() === tagsId.toString()) {
                          usedTags.push(tagsDoc[t])
                        }
                      }
                    }
                  }
                  var doc = docs[i]
                  if (doc.type === 'expense') {
                    doc.status = 'expense'
                  }
                  if (doc.actor) {
                    var actor = doc.actor
                  }
                  
                  doc.type2 = await new Promise(resolve => {
                    mongo.findId('template', doc.template, { type: 1 }, (err, d) => {
                      if (err || !d) resolve('')
                      else resolve(d.type)
                    })
                  })
                  
                  let row = this.row(doc, req, actor, users, null, usedTags)
                  if (row.icon === 'evidence' && (row.responsible && row.responsible.id.toString() !== req.session.context.user.toString() && (
                    !row.revisor && row.revisorNotView && row.status === 'draft' ||
                                            row.revisor && row.assistantResponsable && row.status === 'draft' ||
                                            !row.assistantResponsable && row.copyUser && row.status === 'draft'))) {
                    reply.data
                  } else {
                    reply.data.push(row)
                  }
                }
              }
              /* if continue is true, send data */
              if (req.query.continue) {
                send(reply)
              } else {
                /* if (docs && docs.length === limit) {
                                  reply.total_count = 999 // ...speculative
                                } */
                const toDelete = order(reply.data, reply.data)
                for (const i in toDelete) {
                  const y = reply.data.findIndex((ele) => {
                    return ele.id === toDelete[i]
                  })
                  if (y !== -1) {
                    reply.data.splice(y, 1)
                  }
                }
                send(reply)
              }
            })
          }
        })
      }
    })

    function order (arrayP, arrayH) {
      var toDelete = []
      for (const i in arrayP) {
        var doC = arrayP[i]
        for (const y in arrayH) {
          if (arrayH[y].reference && arrayH[y].reference.toString() === doC.id.toString()) {
            if (!doC.data) {
              doC.data = []
            }
            if (doC.data.findIndex((x) => {
              return x.id === arrayH[y].id
            }) === -1) {
              doC.data.push(arrayH[y])
            }
            if (!toDelete.includes(arrayH[y].id)) {
              toDelete.push(arrayH[y].id)
            }
          }
        }
        if (doC.data) {
          toDelete.push(order(doC.data, reply.data))
        }
      }
      return toDelete
    }
  }

  pdf (req, mongo, send) {
    mongo.findId('note', req.query._id, async (err, doc) => {
      if (!err && doc) {
        if (doc.fileHtml) {
          let stream = await new Promise(resolve => {
            mongo.getfile(doc.fileHtml, (err, res) => {
              if (err) {
                console.log(err)
                resolve({
                  error: err
                })
              } else {
                resolve(res)
              }
            })
          })

          function streamToString (stream) {
            var chunks = []
            return new Promise((resolve, reject) => {
              stream.on('data', (chunk) => chunks.push(Buffer.from(chunk)))
              stream.on('error', (err) => reject(err))
              stream.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')))
            })
          }

          doc.content = await streamToString(stream)
        }
        var i = 0
        while (doc.content.indexOf('{{', i) !== -1 && doc.content.substring(doc.content.indexOf('{{', i), doc.content.indexOf('{{', i) + 1) === '{') {
          i = doc.content.indexOf('{{', i)
          const f = doc.content.indexOf('}}', i)
          const word = doc.content.substring(i + 2, f)
          if (!['page', 'pages'].includes(word)) {
            doc.content = doc.content.replace(new RegExp('{{' + word + '}}', 'g'), '')
          }
          i = f + 2
        }
        if (req.query.details) {
          let user
          doc.actors.forEach(x => {
            if (x.path === 'sent' && x.role === 'reviser') {
              user = x.user
            } else if (x.path === 'sent' && x.role === 'from') {
              user = x.user
            }
          })
          if (doc.project) {
            var proj = await new Promise(resolve => {
              mongo.findId('project', doc.project, (err, project) => {
                if (!err) {
                  resolve(project)
                }
              })
            })
          }
          if (user) {
            var us = await new Promise(resolve => {
              mongo.findId('user', user, (err, user) => {
                if (!err) {
                  resolve(user)
                }
              })
            })
          }
          let i, fit, last
          if (doc.content.indexOf('id="pageFooter-last"') !== -1 || doc.content.indexOf('id="pageFooter-last"') !== -1) {
            i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter-last"'))
            if (!i) {
              i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter-last"'))
            }
            fit = doc.content.slice(0, i + 1)
            last = doc.content.slice(i + 1)
            doc.content = fit + ('<span style="position:relative;font-size: xx-small; top:0em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().format('MM-DD-YYYY') + '</span>') + last
            // doc.content.slice(0, i+1) + ('<div style="position:relative;font-size: xx-small; top:7em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().subtract(10, 'days').calendar() + '</div>') + doc.content.slice(i+1);
          } else if (doc.content.indexOf('id="pageFooter"') !== -1 || doc.content.indexOf('id="pageFooter"') !== -1) {
            i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter"'))
            if (!i) {
              i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter"'))
            }
            fit = doc.content.slice(0, i + 1)
            last = doc.content.slice(i + 1)
            doc.content = fit + ('<span style="position:relative;font-size: xx-small; top:0em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().format('MM-DD-YYYY') + '</span>') + last
          } else {
            doc.content = doc.content + '<div id="pageFooter" ><div style="position:relative;font-size: xx-small; top:0em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().format('MM-DD-YYYY') + '</div></div>'
          }
        }
        html.pdf(mongo, req, doc.content, doc.pageType, (err, stream) => {
          if (err) {
            send({
              error: err
            })
          } else {
            send(stream)
          }
        })
      } else {
        send({
          error: err
        })
      }
    })
  }

  pdfReport (req, mongo, send) {
    mongo.findId('note', req.query._id, async (err, doc) => {
      if (!err && doc) {
        let reviser, from, managerProject
        var attacheds = await new Promise(resolve => {
          mongo.aggregate('attached', [{
            $match: {
              reference: doc._id
            }
          },
          {
            $lookup: {
              from: 'commitment',
              let: {
                id: '$_id'
              },
              pipeline: [{
                $match: {
                  $expr: {
                    $and: [{
                      $eq: ['$reference', '$$id']
                    }]
                  }
                }
              }],
              as: 'commitments'
            }
          },
          {
            $unwind: {
              path: '$commitments',
              preserveNullAndEmptyArrays: true
            }
          },
          {
            $lookup: {
              from: 'evidence',
              let: {
                id: '$commitments._id'
              },
              pipeline: [{
                $match: {
                  $expr: {
                    $and: [{
                      $eq: ['$reference', '$$id']
                    }]
                  },
                  status: {
                    $ne: 'draft'
                  }
                }
              },
              {
                $project: {
                  _id: 0,
                  dates: 1,
                  name: 1,
                  responsible: 1,
                  status: 1
                }
              }
              ],
              as: 'evidences'
            }
          }
          ], {}, async (err, attacheds) => {
            if (!err) {
              resolve(attacheds)
            } else {
              resolve(false)
            }
          })
        })
        var project = await new Promise(resolve => {
          mongo.findId('project', doc.project, {
            actors: 1,
            unit: 1,
            description: 1
          }, (err, project) => {
            if (!err) {
              resolve(project)
            } else {
              resolve(false)
            }
          })
        })
        var content = `<p style="text-align: center;"><strong><span style="font-size: 18px;">${doc.name}</span></strong></p>
        <p style="text-align: center;"><span style="font-size: 18px;"><strong>Informe ${doc.sequence.text}</strong></span></p>
        <p style="text-align: center;"><span style="font-size: 18px;"><strong>Equipo de Trabajo:</strong></span></p>`
        mongo.find('params', {
          name: 'riskLevel'
        }, {
          _id: 1,
          name: 1,
          options: 1
        }, (_er, tagsDoc) => {
          if (tagsDoc.length > 0) {
            tagsDoc = tagsDoc[0].options
          }
          mongo.toHash('unit', {}, {
            _id: 1,
            name: 1,
            actors: 1
          }, (err, units) => {
            if (err) throw err
            mongo.toHash('user', {}, async (err, users) => {
              if (err) throw err
              if (project) {
                project.actors.forEach(a => {
                  content += `<p style="text-align: center;"><span">${users[a.user.toString()].name}/${(a.type[0] === 'member' ? 'Miembro' : 'Gerente')}</span></p>`
                  if (a.type[0] === 'manager') {
                    managerProject = a
                  }
                })
              }
              content += '<p style="text-align: center;"><strong><span style="font-size: 18px;">Destinatarios:</span></strong></p>'
              doc.actors.forEach(a => {
                if (['to', 'copy'].includes(a.role)) {
                  content += `<p style="text-align: center;"><span>${users[a.user.toString()].name}${(a.unit ? '/' + units[a.unit.toString()].name : '')}</span></p>`
                }
                if (a.path === 'sent' && a.role === 'reviser') {
                  reviser = a
                }
                if (a.path === 'sent' && a.role === 'from') {
                  from = a
                }
              })
              content += `<br>
              <table style="width: 79%; margin-left: calc(6%); margin-right: calc(16%);">
                <tbody>
                  <tr>
                    <td style="width: 25.022%; background-color: rgb(204, 204, 204); text-align: center;">Fecha</td>
                    <td style="width: 26.4274%; background-color: rgb(204, 204, 204); text-align: center;">Elaborado por</td>
                    <td style="width: 24.5996%; background-color: rgb(204, 204, 204); text-align: center;">Revisado por</td>
                    <td style="width: 23.7348%; background-color: rgb(204, 204, 204); text-align: center;">Aprobado por</td>
                  </tr>
                  <tr>
                    <td style="width: 25.022%;">${(doc.dates[0] ? moment(doc.dates[0].value).format('YYYY/MM/DD') : '')}</td>
                    <td style="width: 26.4274%;">
                      ${(reviser ? (users[reviser.user.toString()].name + (reviser.unit ? '/' + units[reviser.unit.toString()].name : '')) : (from ? (users[from.user.toString()].name + (from.unit ? '/' + units[from.unit.toString()].name : '')) : ''))}
                    </td>
                    <td style="width: 24.5996%;">
                      ${(managerProject ? users[managerProject.user.toString()].name + (project && project.unit ? '/' + units[project.unit.toString()].name : '') : '')}
                    </td>`
              if (project && project.unit && units[project.unit.toString()]) {
                units[project.unit.toString()].actors.forEach(a => {
                  if (a.type[0] === 'manager') {
                    content += `<td style="width: 23.7348%;">
                    ${users[managerProject.user.toString()].name}/${units[project.unit.toString()].name}
                    </td>`
                  }
                })
              }
              content += `</tr>
                </tbody>
              </table>
              <p>
                <br>
              </p>
              <p>
                <br>
              </p>
              <p><span style="font-size: 18px;"><strong>1 INTRODUCCI&Oacute;N</strong></span></p>
              <p><strong>1. Introducci&oacute;n de los Procesos auditados</strong></p>
              <p>Haga un resumen del proceso auditado, sus antecedentes y aspectos relevantes de manera ejecutiva.</p>`
              if (project.description.indexOf('id="objetivo"') !== -1) {
                const root = parseHtml.parse(project.description)
                content += `<p><strong>1.1 Objetivo de la Auditoria</strong></p>
                <p>${root.querySelectorAll('#objetivo')[0].innerHTML}</p>`
                if (project.description.indexOf('id="alcance"') !== -1) {
                  const root = parseHtml.parse(project.description)
                  content += `<p><strong>1.2 Alcance</strong></p>
                  <p>${root.querySelectorAll('#alcance')[0].innerHTML}</p>`
                }
              } else {
                content += `<p><strong>1.1 Objetivo de la Auditoria y 1.2 Alcance</strong></p>
                <p>${project.description}</p>`
              }
              content += `<p><strong>1.3 Resumen de los procedimientos aplicados</strong></p>
              <p><strong>1.4 Resultados de auditoria</strong></p>
              <p>Hemos culminado la auditor&iacute;a al proceso xxxxx, con el objetivo de analizar la razonabilidad y efectividad de los controles establecidos dentro del dise&ntilde;o y procesos operativos y de gesti&oacute;n relacionados.</p>
              <p>Como resultado de la revisi&oacute;n efectuada, se destacan las siguientes fortalezas:</p>
              <p>Las mejoras determinadas se presentan a continuaci&oacute;n:</p>
              <p>Como resultado de la auditor&iacute;a, se determinaron xx mejoras y xxx recomendaciones:</p>
              <div style="text-align: center;">
                <br>
              </div>
              <table style="width: 64%; margin-left: calc(11%); margin-right: calc(25%);">
                <tbody>`
              if (attacheds && attacheds.length) {
                for (const a in attacheds) {
                  if (attacheds[a].tags && attacheds[a].tags[0]) {
                    tagsDoc.forEach(t => {
                      if (t.id.toString() === attacheds[a].tags[0].toString()) {
                        t.num = t.num ? t.num + 1 : 1
                        attacheds[a].riskName = t.value
                      }
                    })
                  }
                }
                tagsDoc.forEach(t => {
                  content += `<tr>
                    <td style="width: 50.056%; background-color: rgb(204, 204, 204);">
                      ${t.value}
                    </td>
                    <td style="width: 49.944%;">
                      ${t.num || 0}
                    </td>
                  </tr>`
                })
              }
              content += `</tbody>
              </table>
              <p>
                <br>
              </p>
              <br>
              <table style="width: 79%; margin-left: calc(6%); margin-right: calc(16%);">
                <tbody>
                  <tr>
                    <td style="width: 55%; background-color: rgb(204, 204, 204); text-align: center;">Oportunidad de Mejora</td>
                    <td style="width: 15%; background-color: rgb(204, 204, 204); text-align: center;">Nivel de Riesgo</td>
                    <td style="width: 15%; background-color: rgb(204, 204, 204); text-align: center;">Área Responsable</td>
                    <td style="width: 15%; background-color: rgb(204, 204, 204); text-align: center;">Fecha de compromiso</td>
                  </tr>`
              if (attacheds && attacheds.length) {
                for (const a in attacheds) {
                  content += `<tr>
                    <td style="width: 55%; ">${attacheds[a].name}</td>
                    <td style="width: 15%; ">${attacheds[a].riskName || ''}</td>
                    <td style="width: 15%; ">${attacheds[a].responsible && attacheds[a].responsible.length ? users[attacheds[a].responsible.split('&unit=')[0]].name + '/' + units[attacheds[a].responsible.split('&unit=')[1]].name : ''}</td>
                    <td style="width: 15%; ">${(doc.dates[1] ? moment(doc.dates[1].value).format('YYYY/MM/DD') : '')}</td>
                  </tr>`
                }
              }
              content += `</tbody>
              </table>
              <p>
                <br>
              </p>
              <p><strong>1.5 Opini&oacute;n</strong></p>
              <p>{{opinion}}</p>
              <p><strong>1.6 Estado del Seguimiento de Recomendaciones de Auditorias Previas</strong></p>
              <p>El estado de las recomendaciones anteriores es el siguiente:</p>`
              var beforeAttacheds = await new Promise(resolve => {
                mongo.aggregate('project', [{
                  $match: {
                    auditable: project.auditable,
                    $ne: {
                      _id: project._id
                    }
                  }
                },
                {
                  $lookup: {
                    from: 'note',
                    let: {
                      id: '$_id'
                    },
                    pipeline: [{
                      $match: {
                        $expr: {
                          $and: [{
                            $eq: ['$project', '$$id']
                          }]
                        }
                      }
                    },
                    {
                      $project: {
                        _id: 0,
                        _idNote: '$_id'
                      }
                    }
                    ],
                    as: 'notes'
                  }
                },
                {
                  $unwind: {
                    path: '$notes',
                    preserveNullAndEmptyArrays: true
                  }
                },
                {
                  $replaceRoot: {
                    newRoot: {
                      $mergeObjects: ['$notes', '$$ROOT']
                    }
                  }
                },
                {
                  $project: {
                    notes: 0
                  }
                },
                {
                  $lookup: {
                    from: 'attached',
                    let: {
                      id: '$_idNote'
                    },
                    pipeline: [{
                      $match: {
                        $expr: {
                          $and: [{
                            $eq: ['$reference', '$$id']
                          }]
                        },
                        status: {
                          $in: ['processing', 'answered']
                        }
                      }
                    },
                    {
                      $project: {
                        _id: 0,
                        dates: 1,
                        name: 1,
                        responsible: 1,
                        status: 1
                      }
                    }
                    ],
                    as: 'attacheds'
                  }
                },
                {
                  $unwind: '$attacheds'
                },
                {
                  $group: {
                    _id: null,
                    attacheds: {
                      $push: '$attacheds'
                    }
                  }
                }
                ], {}, (err, attacheds) => {
                  if (!err) {
                    resolve(attacheds)
                  } else {
                    resolve(false)
                  }
                })
              })
              content += `<table style="width: 79%; margin-left: calc(6%); margin-right: calc(16%);">
                <tbody>
                  <tr>
                    <td style="width: 15%; background-color: rgb(204, 204, 204); text-align: center;">Fecha de emisión</td>
                    <td style="width: 55%; background-color: rgb(204, 204, 204); text-align: center;">Asunto</td>
                    <td style="width: 15%; background-color: rgb(204, 204, 204); text-align: center;">Estado</td>
                    <td style="width: 15%; background-color: rgb(204, 204, 204); text-align: center;">Area Responsable</td>
                  </tr>`
              if (beforeAttacheds && beforeAttacheds[0] && beforeAttacheds[0].attacheds.length) {
                beforeAttacheds = beforeAttacheds[0]
                for (const a in beforeAttacheds.attacheds) {
                  const attached = beforeAttacheds.attacheds[a]
                  content += `<tr>
                    <td style="width: 15%; ">${attached.dates[0] ? moment(attached.dates[0].value).format('YYYY/MM/DD') : ''}</td>
                    <td style="width: 55%; ">${attached.name || ''}</td>
                    <td style="width: 15%; ">${attached.status === 'processing' ? 'En proceso' : 'Respondido'}</td>
                    <td style="width: 15%; ">${attached.responsible && attached.responsible.length ? users[attached.responsible.split('&unit=')[0]].name + '/' + units[attached.responsible.split('&unit=')[1]].name : ''}</td>
                  </tr>`
                }
              }

              content += `</tbody>
              </table>
              <p>
                <br>
              </p>
              <p><strong>1.7 Oportunidades de Mejora</strong></p></br>`
              if (attacheds && attacheds.length) {
                for (const a in attacheds) {
                  const attached = attacheds[a]
                  content += `<p>
                  <strong>Título: </strong>
                  ${attached.name}
                  </p></br>`
                  if (attached.content.indexOf('id="condicion"') !== -1) {
                    const root = parseHtml.parse(attached.content)
                    content += `<p><strong>Condicion: </strong></p>
                    <p>${root.querySelectorAll('#condicion')[0].innerHTML}</p>`
                    if (attached.content.indexOf('id="criterio"') !== -1) {
                      const root = parseHtml.parse(attached.content)
                      content += `<p><strong>Criterio: </strong></p>
                      <p>${root.querySelectorAll('#criterio')[0].innerHTML}</p>`
                    }
                    if (attached.content.indexOf('id="causa"') !== -1) {
                      const root = parseHtml.parse(attached.content)
                      content += `<p><strong>Causa: </strong></p>
                      <p>${root.querySelectorAll('#causa')[0].innerHTML}</p>`
                    }
                    if (attached.content.indexOf('id="efecto"') !== -1) {
                      const root = parseHtml.parse(attached.content)
                      content += `<p><strong>Efecto: </strong></p>
                      <p>${root.querySelectorAll('#efecto')[0].innerHTML}</p>`
                    }
                    if (attached.content.indexOf('id="recomendaciones"') !== -1) {
                      const root = parseHtml.parse(attached.content)
                      content += `<p><strong>Recomendaciones: </strong></p>
                      <p>${root.querySelectorAll('#recomendaciones')[0].innerHTML}</p>`
                    }
                  } else {
                    content += `<p>
                    ${attached.content}
                    </p>`
                  }
                  content += `<p><strong>Nivel de Riesgo: ${attached.riskName}</strong></p>`
                  switch (attached.status) {
                  case 'prepared':
                    content += '<p><strong>Nivel de Riesgo: Preparado</strong></p>'
                    break
                  case 'processing':
                    content += '<p><strong>Nivel de Riesgo: En proceso</strong></p>'
                    break
                  case 'answered':
                    content += '<p><strong>Nivel de Riesgo: Respondido</strong></p>'
                    break
                  case 'completed':
                    content += '<p><strong>Nivel de Riesgo: Completado</strong></p>'
                    break
                  }
                  if (attached.commitments) {
                    content += `<p><strong>Respuesta del Auditado</strong></p>
                    <p>
                    <strong>Título: </strong>
                    ${attached.commitments.name}</br>
                    ${attached.commitments.content}
                    </p>`
                  }
                  content += '<p><strong>Análisis de Auditoría</strong></p>'
                  if (attached.evidences && attached.evidences.length) {
                    for (const e in attached.evidences) {
                      const evidence = attached.evidences[e]
                      content += `<p><strong>Seguimiento</strong></p>
                      <p>
                      <strong>Título: </strong>
                      ${evidence.name}</br>
                      ${evidence.content || ''}
                      </p>`
                    }
                  }
                }
              }
              html.pdf(mongo, req, content, doc.pageType, (err, stream) => {
                if (err) {
                  send({
                    error: err
                  })
                } else {
                  send(stream)
                }
              })
            })
          })
        })
      } else {
        send({
          error: err
        })
      }
    })
  }

  pdfAllFile (req, mongo, send) {
    mongo.findId('note', req.query._id, (err, doc) => {
      if (!err && doc) {
        var ids = []
        for (const i in doc.actors) {
          ids.push(doc.actors[i].user)
        }
        mongo.find('params', {
          name: 'tag'
        }, {
          _id: 1,
          name: 1,
          options: 1
        }, (_er, tagsDoc) => {
          if (tagsDoc.length > 0) {
            tagsDoc = tagsDoc[0].options
          }
          mongo.toHash('user', {
            _id: {
              $in: ids
            }
          }, (err, users) => {
            if (err) throw err
            mongo.find('attached', {
              reference: mongo.toId(req.query._id)
            }, async (err, attacheds) => {
              if (err) throw err
              let to = '';
              let copy = '';
              let tag = ''
              doc.actors.findIndex((x) => {
                if (x.role === 'to') {
                  to = to + users[x.user].name + ','
                }
                if (x.role === 'copy') {
                  copy = copy + users[x.user].name + ','
                }
              })
              var tagsId = doc.tags
              var usedTags = []
              if (tagsDoc.length > 0 && tagsId.length > 0) {
                for (let t = 0; t < tagsDoc.length; t++) {
                  if (tagsId.length) {
                    for (let o = 0; o < tagsId.length; o++) {
                      if (tagsDoc[t].id && tagsId[o] && tagsDoc[t].id.toString() === tagsId[o].toString()) {
                        usedTags.push(tagsDoc[t])
                      }
                    }
                  } else {
                    if (tagsDoc[t] && tagsId && tagsDoc[t].id.toString() === tagsId.toString()) {
                      usedTags.push(tagsDoc[t])
                    }
                  }
                }
              }
              for (const i in usedTags) {
                tag = tag + '<span style="background-color:' + usedTags[i].color + '">' + usedTags[i].value + '</span>,'
              }
              var i = 0
              /// //////////////////////////////////////////////////
              /// /////  BH NO QUERIA ESTE ENCABEZADO /////////////
              /// /////////////////////////////////////////////////
              /* var header = 'Enviado por: ' + sendBy + '<br/>' +
                              'De: ' + from + '<br/>' +
                              'Para: ' + (to !== '' ? to.slice(0, to.length - 1) : '') + '<br/>' +
                              'Copia: ' + (copy !== '' ? copy.slice(0, copy.length - 1) : '') + '<br/>' +
                              'Vencimiento: ' + deadline + '<br/>' +
                              'Consecutivo: ' + sequence + '<br/>' +
                              'Etiquetas: ' + (tag !== '' ? tag.slice(0, tag.length - 1) : '') + '<br/>'
                            if (attacheds.length > 0) {
                              header = header + 'Anexos:' +
                                '<ul>'
                              for (const i in attacheds) {
                                header = header + '<li>' + attacheds[i].name + '</li>'
                              }
                              header = header + '</ul>'
                            }
                            header = header + '<br/>' +
                              '<br/>'
                            doc.content = header + doc.content */
              if (attacheds.length > 0) {
                for (const i in attacheds) {
                  const attached = '<br/>' +
                                        '<br/>' +
                                        '<strong>' + attacheds[i].name + '</strong>' +
                                        '<br/>' +
                                        attacheds[i].content

                  doc.content = doc.content + attached
                }
              }
              while (doc.content.indexOf('{{', i) !== -1 && doc.content.substring(doc.content.indexOf('{{', i), doc.content.indexOf('{{', i) + 1) === '{') {
                i = doc.content.indexOf('{{', i)
                const f = doc.content.indexOf('}}', i)
                const word = doc.content.substring(i + 2, f)
                if (!['page', 'pages'].includes(word)) {
                  doc.content = doc.content.replace(new RegExp('{{' + word + '}}', 'g'), '')
                }
                i = f + 2
              }
              if (req.query.details) {
                let user
                doc.actors.forEach(x => {
                  if (x.path === 'sent' && x.role === 'reviser') {
                    user = x.user
                  } else if (x.path === 'sent' && x.role === 'from') {
                    user = x.user
                  }
                })
                if (doc.project) {
                  var proj = await new Promise(resolve => {
                    mongo.findId('project', doc.project, (err, project) => {
                      if (!err) {
                        resolve(project)
                      }
                    })
                  })
                }
                if (user) {
                  var us = await new Promise(resolve => {
                    mongo.findId('user', user, (err, user) => {
                      if (!err) {
                        resolve(user)
                      }
                    })
                  })
                }
                let i, fit, last
                if (doc.content.indexOf('id="pageFooter-last"') !== -1 || doc.content.indexOf('id="pageFooter-last"') !== -1) {
                  i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter-last"'))
                  if (!i) {
                    i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter-last"'))
                  }
                  fit = doc.content.slice(0, i + 1)
                  last = doc.content.slice(i + 1)
                  doc.content = fit + ('<span style="position:relative;font-size: xx-small; top:0em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().format('MM-DD-YYYY') + '</span>') + last
                  // doc.content.slice(0, i+1) + ('<div style="position:relative;font-size: xx-small; top:7em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().subtract(10, 'days').calendar() + '</div>') + doc.content.slice(i+1);
                } else if (doc.content.indexOf('id="pageFooter"') !== -1 || doc.content.indexOf('id="pageFooter"') !== -1) {
                  i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter"'))
                  if (!i) {
                    i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter"'))
                  }
                  fit = doc.content.slice(0, i + 1)
                  last = doc.content.slice(i + 1)
                  doc.content = fit + ('<span style="position:relative;font-size: xx-small; top:0em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().format('MM-DD-YYYY') + '</span>') + last
                } else {
                  doc.content = doc.content + '<div id="pageFooter" ><div style="position:relative;font-size: xx-small; top:0em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().format('MM-DD-YYYY') + '</div></div>'
                }
              }
              if (req.query.toPrint) {
                send({
                  content: doc.content
                })
              } else {
                html.pdf(mongo, req, doc.content, doc.pageType, (err, stream) => {
                  if (err) {
                    send({
                      error: err
                    })
                  } else {
                    send(stream)
                  }
                })
              }
            })
          })
        })
      } else {
        send({
          error: err
        })
      }
    })
  }

  wordAllFile (req, mongo, send) {
    mongo.findId('note', req.query._id, (err, doc) => {
      if (!err && doc) {
        var ids = []
        for (const i in doc.actors) {
          ids.push(doc.actors[i].user)
        }
        mongo.find('params', {
          name: 'tag'
        }, {
          _id: 1,
          name: 1,
          options: 1
        }, (_er, tagsDoc) => {
          if (tagsDoc.length > 0) {
            tagsDoc = tagsDoc[0].options
          }
          mongo.toHash('user', {
            _id: {
              $in: ids
            }
          }, (err, users) => {
            if (err) throw err
            mongo.find('attached', {
              reference: mongo.toId(req.query._id)
            }, {}, {
              name: 1
            }, async (err, attacheds) => {
              if (err) throw err
              let reviser;
              let from2;
              let from = '';
              let sendBy = '';
              let to = '';
              let copy = '';
              let deadline = '';
              let sequence = '';
              let tag = ''
              doc.actors.findIndex((x) => {
                if (x.path === 'sent' && x.role === 'reviser') {
                  reviser = x
                }
                if (x.path === 'sent' && x.role === 'from') {
                  from2 = x
                  from = users[x.user].name
                }
                if (x.role === 'to') {
                  to = to + users[x.user].name + ','
                }
                if (x.role === 'copy') {
                  copy = copy + users[x.user].name + ','
                }
              })
              if (reviser) {
                sendBy = users[reviser.user].name
              } else if (from2) {
                sendBy = users[from2.user].name
              }
              let deadlineExist
              if (doc.dates) {
                doc.dates.findIndex((x) => {
                  if (x.type === 'deadline') deadlineExist = x.value
                })
              }
              if (deadlineExist) {
                deadline = moment(deadlineExist).format('MM-DD-YYYY')
              }
              if (doc.sequence && doc.sequence.text) {
                sequence = doc.sequence.text
              }

              var tagsId = doc.tags
              var usedTags = []
              if (tagsDoc.length > 0 && tagsId.length > 0) {
                for (let t = 0; t < tagsDoc.length; t++) {
                  if (tagsId.length) {
                    for (let o = 0; o < tagsId.length; o++) {
                      if (tagsDoc[t].id && tagsId[o] && tagsDoc[t].id.toString() === tagsId[o].toString()) {
                        usedTags.push(tagsDoc[t])
                      }
                    }
                  } else {
                    if (tagsDoc[t] && tagsId && tagsDoc[t].id.toString() === tagsId.toString()) {
                      usedTags.push(tagsDoc[t])
                    }
                  }
                }
              }
              for (const i in usedTags) {
                tag = tag + '<span style="background-color:' + usedTags[i].color + '">' + usedTags[i].value + '</span>,'
              }
              var i = 0
              var header = 'Enviado por: ' + sendBy + '<br/>' +
                                'De: ' + from + '<br/>' +
                                'Para: ' + (to !== '' ? to.slice(0, to.length - 1) : '') + '<br/>' +
                                'Copia: ' + (copy !== '' ? copy.slice(0, copy.length - 1) : '') + '<br/>' +
                                'Vencimiento: ' + deadline + '<br/>' +
                                'Consecutivo: ' + sequence + '<br/>' +
                                'Etiquetas: ' + (tag !== '' ? tag.slice(0, tag.length - 1) : '') + '<br/>'
              if (attacheds.length > 0) {
                header = header + 'Anexos:' +
                                    '<ul>'
                for (const i in attacheds) {
                  header = header + '<li>' + attacheds[i].name + '</li>'
                }
                header = header + '</ul>'
              }
              header = header + '<br/>' +
                                '<br/>'
              doc.content = header + doc.content
              if (attacheds.length > 0) {
                for (const i in attacheds) {
                  const attached = '<br/>' +
                                        '<br/>' +
                                        '<strong>' + attacheds[i].name + '</strong>' +
                                        '<br/>' +
                                        attacheds[i].content

                  doc.content = doc.content + attached
                }
              }
              while (doc.content.indexOf('{{', i) !== -1 && doc.content.substring(doc.content.indexOf('{{', i), doc.content.indexOf('{{', i) + 1) === '{') {
                i = doc.content.indexOf('{{', i)
                const f = doc.content.indexOf('}}', i)
                const word = doc.content.substring(i + 2, f)
                if (!['page', 'pages'].includes(word)) {
                  doc.content = doc.content.replace(new RegExp('{{' + word + '}}', 'g'), '')
                }
                i = f + 2
              }
              if (req.query.details) {
                let user
                doc.actors.forEach(x => {
                  if (x.path === 'sent' && x.role === 'reviser') {
                    user = x.user
                  } else if (x.path === 'sent' && x.role === 'from') {
                    user = x.user
                  }
                })
                if (doc.project) {
                  var proj = await new Promise(resolve => {
                    mongo.findId('project', doc.project, (err, project) => {
                      if (!err) {
                        resolve(project)
                      }
                    })
                  })
                }
                if (user) {
                  var us = await new Promise(resolve => {
                    mongo.findId('user', user, (err, user) => {
                      if (!err) {
                        resolve(user)
                      }
                    })
                  })
                }
                let i, fit, last
                if (doc.content.indexOf('id="pageFooter-last"') !== -1 || doc.content.indexOf('id="pageFooter-last"') !== -1) {
                  i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter-last"'))
                  if (!i) {
                    i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter-last"'))
                  }
                  fit = doc.content.slice(0, i + 1)
                  last = doc.content.slice(i + 1)
                  doc.content = fit + ('<span style="position:relative;font-size: xx-small; top:0em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().format('MM-DD-YYYY') + '</span>') + last
                  // doc.content.slice(0, i+1) + ('<div style="position:relative;font-size: xx-small; top:7em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().subtract(10, 'days').calendar() + '</div>') + doc.content.slice(i+1);
                } else if (doc.content.indexOf('id="pageFooter"') !== -1 || doc.content.indexOf('id="pageFooter"') !== -1) {
                  i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter"'))
                  if (!i) {
                    i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter"'))
                  }
                  fit = doc.content.slice(0, i + 1)
                  last = doc.content.slice(i + 1)
                  doc.content = fit + ('<span style="position:relative;font-size: xx-small; top:0em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().format('MM-DD-YYYY') + '</span>') + last
                } else {
                  doc.content = doc.content + '<div id="pageFooter" ><div style="position:relative;font-size: xx-small; top:0em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().format('MM-DD-YYYY') + '</div></div>'
                }
              }
              send(doc)
            })
          })
        })
      } else {
        send({
          error: err
        })
      }
    })
  }

  async deleteReviser (req, mongo, send) {
    let userId = req.query.id.toString()
    var continuar = await new Promise(resolve => {
      mongo.find('attached', {
        reference: mongo.toId(req.query.idDoc),
        'actors.user': mongo.toId(userId)
      }, {
        _id: 1,
        actors: 1
      }, (err, atts) => {
        if (err) {
          console.log(err)
          resolve(false)
        } else if (atts.length > 0) {
          let countResponsible = 0
          for (let a in atts) {
            let att = atts[a]
            const index = att.actors.findIndex((x) => {
              return x.user.toString() === userId && (x.role === 'responsible' || (x.role === 'reviser' && x.path === 'sent'))
            })
            if (index !== -1) {
              countResponsible++
            }
          }
          if (countResponsible > 0) {
            resolve(false)
          } else {
            resolve(true)
          }
        } else {
          resolve(true)
        }
      })
    })
    if (continuar) {
      mongo.findId('note', req.query.idDoc, async (err, doc) => {
        if (err) {
          req.logger.log(err)
        } else {
          const index = doc.actors.findIndex((x) => {
            return x.user.toString() === req.query.id
          })
          var user = await new Promise(resolve => {
            mongo.findId('user', doc.actors[index].user, (err, u) => {
              if (err) {
                console.log(err)
                resolve(false)
              } else {
                resolve({
                  _id: u._id,
                  name: u.name
                })
              }
            })
          })
          var unit = await new Promise(resolve => {
            mongo.findId('unit', doc.actors[index].unit, (err, u) => {
              if (err) {
                console.log(err)
                resolve(false)
              } else {
                resolve(u.name)
              }
            })
          })
          doc.actors.splice(index, 1)
          var attacheds = await new Promise(resolve => {
            mongo.find('attached', {
              reference: doc._id
            }, {}, (err, a) => {
              if (err) {
                console.log(err)
                resolve(false)
              } else {
                resolve(a)
              }
            })
          })
          if (attacheds.length >= 1) {
            for (let a in attacheds) {
              let attached = attacheds[a]
              let i = attached.actors.findIndex((x) => {
                return x.user.toString() === req.query.id
              })
              if (i !== -1) {
                attached.actors.splice(i, 1)
                await new Promise(resolve => {
                  mongo.save('attached', attached, (err) => {
                    if (err) {
                      console.log(err)
                      resolve(false)
                    } else {
                      resolve(true)
                    }
                  })
                })
                var commitmentResult = await new Promise(resolve => {
                  mongo.find('commitment', {
                    reference: attached._id
                  }, {}, (err, a) => {
                    if (err) {
                      console.log(err)
                      resolve(false)
                    } else {
                      resolve(a)
                    }
                  })
                })
                if (commitmentResult.length >= 1) {
                  let commitment = commitmentResult[0]
                  let i = commitment.actors.findIndex((x) => {
                    return x.user.toString() === req.query.id
                  })
                  if (i !== -1) {
                    commitment.actors.splice(i, 1)
                    await new Promise(resolve => {
                      mongo.save('commitment', commitment, (err) => {
                        if (err) {
                          console.log(err)
                          resolve(false)
                        } else {
                          resolve(true)
                        }
                      })
                    })
                  }

                  var evidences = await new Promise(resolve => {
                    mongo.find('evidence', {
                      reference: commitment._id
                    }, {}, (err, a) => {
                      if (err) {
                        console.log(err)
                        resolve(false)
                      } else {
                        resolve(a)
                      }
                    })
                  })
                  if (evidences.length >= 1) {
                    for (let e in evidences) {
                      let evidence = evidences[e]
                      let i = evidence.actors.findIndex((x) => {
                        return x.user.toString() === req.query.id
                      })
                      if (i !== -1) {
                        evidence.actors.splice(i, 1)
                        await new Promise(resolve => {
                          mongo.save('evidence', evidence, (err) => {
                            if (err) {
                              console.log(err)
                              resolve(false)
                            } else {
                              resolve(true)
                            }
                          })
                        })
                      }
                    }
                  }
                }
              }
            }
          }

          mongo.save('note', doc, (err) => {
            if (err) {
              req.logger.log(err)
            } else {
              if (user && unit) {
                let comment = '<p>' + '_removedSomeone' + '<img class="photo" src="api/user.image?size=20&_id=' + user._id.toString() + '"/>' + user.name + '/' + unit + '</p>' //Eliminó a
                const data = {
                  document: doc._id,
                  comment: comment,
                  collection: 'note'
                }
                req.app.routes.comment.save(req, mongo, () => {
                  send({})
                }, data)
              } else {
                send({})
              }
            }
          })
        }
      })
    } else {
      send({
        msj: '_cantDeleteDocReviser'
      }) //No se puede eliminar usuario (Responsable o creador del documento)
    }
  }

  rels (req, mongo, send) {
    var _id = mongo.toId(req.query._id)
    mongo.findId('note', _id, {
      links: 1
    }, (err, doc) => {
      if (err) throw err
      var links = []
      if (doc && doc.links) {
        for (const i in doc.links) {
          links.push(doc.links[i]._id)
        }
      }
      var keys = {
        $or: [{
          'links._id': _id
        },
        {
          _id: {
            $in: links
          }
        }
        ]
      }
      this.list(req, mongo, send, keys)
    })
  }

  async list (req, mongo, send, rels) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = {
      data: [],
      pos: skip
    }
    var myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits)
    var myAndDependentUnits = req.session.context.dependentUnits.concat(myUnits)
    /* filering documents with user of session or unit of user of session and not hidden */
    var tagsDoc = await new Promise(resolve => {
      mongo.find('params', {
        name: 'tag'
      }, {
        _id: 1,
        name: 1,
        options: 1
      }, (err, tagsDoc) => {
        if (err || (tagsDoc && tagsDoc.length === 0)) {
          console.log(err)
          resolve([])
        } else {
          resolve(tagsDoc[0].options)
        }
      })
    })
    var usersAll = await new Promise(resolve => {
      mongo.toHash('user', {}, {
        _id: 1,
        name: 1
      }, (err, users) => {
        if (err) {
          console.log(err)
          resolve([])
        } else {
          resolve(users)
        }
      })
    })
    var unitsAll = await new Promise(resolve => {
      mongo.toHash('unit', {}, {
        _id: 1,
        name: 1
      }, (err, units) => {
        if (err) {
          console.log(err)
          resolve([])
        } else {
          resolve(units)
        }
      })
    })
    var keys
    if (req.query.noteId) {
      keys = {
        _id: mongo.toId(req.query.noteId)
      }
    } else {
      if (rels) {
        keys = rels
      } else {
        if (req.query.project) {
          keys = {
            project: mongo.toId(req.query.project)
          }
        } else {
          keys = await this.$keys(req, mongo)
        }
        if (!keys.status) {
          if (req.query.filter) {
            if (!req.query.filter.status) {
              keys.status = {
                $ne: 'annulled'
              }
            } else if (req.query.filter.status === 'all') {
              delete req.query.filter.status
            }
          } else {
            keys.status = {
              $ne: 'annulled'
            }
          }
        }
        const query = []
        for (const name in req.query.filter) {
          if (req.query.filter[name].length > 0 && req.query.filter[name] !== 'null') {
            if (name === 'emisor') {
              query.push({
                actors: {
                  $elemMatch: {
                    user: mongo.toId(req.query.filter.emisor),
                    path: 'sent'
                  }
                }
              })
            } else if (name === 'receiver') {
              query.push({
                actors: {
                  $elemMatch: {
                    user: mongo.toId(req.query.filter.receiver),
                    role: 'to',
                    path: {
                      $ne: 'hidden'
                    }
                  }
                }
              })
            } else if (name === 'emisorUnit') {
              query.push({
                actors: {
                  $elemMatch: {
                    unit: mongo.toId(req.query.filter.emisorUnit),
                    role: 'from'
                  }
                }
              })
            } else if (name === 'receiverUnit') {
              var dependents = await this.$unitDependents(mongo, mongo.toId(req.query.filter.receiverUnit))
              query.push({
                actors: {
                  $elemMatch: {
                    unit: {
                      $in: dependents
                    },
                    role: {
                      $in: ['to', 'copy']
                    },
                    path: {
                      $ne: 'hidden'
                    }
                  }
                }
              })
            } else if (name === 'tagsname') {
              query.push({
                tags: mongo.toId(req.query.filter.tagsname)
              })
            } else if (name === 'sequence' || name === 'sequence.text') {
              query.push({
                'sequence.text': new RegExp(req.query.filter[name], 'i')
              })
            } else if (name === 'name') {
              query.push({
                name: new RegExp(req.query.filter.name, 'i')
              })
            } else if (name === '_id') {
              var ids = req.query.filter[name].split(',')
              for (const i in ids) {
                if (mongo.isNativeId(ids[i])) {
                  ids[i] = mongo.toId(ids[i])
                }
              }
              query.push({
                _id: {
                  $in: ids
                }
              })
            } else if (name === 'path') {
              query.push({
                actors: {
                  $elemMatch: {
                    user: req.session.context.user,
                    path: req.query.filter.path
                  }
                }
              })
            } else if (name === 'links._id' && req.query.filter[name] !== 'undefined') {
              query.push({
                'links._id': mongo.toId(req.query.filter[name])
              })
            } else if (name === 'links') {
              ids = req.query.filter[name].split(',')
              for (const i in ids) {
                if (mongo.isNativeId(ids[i])) {
                  ids[i] = mongo.toId(ids[i])
                }
              }
              query.push({
                _id: {
                  $in: ids
                }
              })
            } else if (name === 'issued') {
              query.push({
                issued: req.query.filter[name]
              })
            } else if (req.query.filter[name] !== '' && name !== 'deadline') {
              let cond = {}
              cond[name] = req.query.filter[name].indexOf(',') !== -1 ? {
                $in: req.query.filter[name].split(',')
              } : new RegExp(req.query.filter[name].replace(/ /g, '.*'), 'i')
              query.push(cond)
            }
          }
        }
        if (req.query.onlydefeated === 'true') {
          keys.$and = [{
            dates: {
              $elemMatch: {
                value: {
                  $lte: new Date()
                },
                type: 'deadline'
              }
            }
          },
          {
            status: {
              $in: ['processing']
            }
          }
          ]
        }
        if (req.query.onlyunexpired === 'true') {
          keys.$and = [{
            dates: {
              $elemMatch: {
                value: {
                  $gte: new Date()
                },
                type: 'deadline'
              }
            }
          },
          {
            status: {
              $in: ['processing']
            }
          }
          ]
        }
        if (req.query.filter && req.query.filter.deadline && req.query.filter.deadline !== 'null') {
          if (req.query.filter.deadline.start && !req.query.filter.deadline.end) {
            query.push({
              $and: [{
                dates: {
                  $elemMatch: {
                    value: {
                      $gte: req.query.filter.deadline.start
                    },
                    type: 'deadline'
                  }
                }
              }, ]
            })
          } else if (req.query.filter.deadline.start && req.query.filter.deadline.end) {
            query.push({
              $and: [{
                dates: {
                  $elemMatch: {
                    value: {
                      $gte: req.query.filter.deadline.start
                    },
                    type: 'deadline'
                  }
                }
              },
              {
                dates: {
                  $elemMatch: {
                    value: {
                      $lte: new Date(req.query.filter.deadline.end.setHours(23, 59, 59))
                    },
                    type: 'deadline'
                  }
                }
              },
              ]
            })
          }
        }
        delete query.filterNames
        if (query.length) {
          keys.$and = query
        }
      }
    }
    var sort
    if (req.query.sort) {
      for (const name in req.query.sort) {
        if (req.query.sort[name].length > 0) {
          if (name === 'deadline') {
            sort = req.query.sort[name] === 'asc' ? {
              'dates.1.value': 1
            } : {
              'dates.1.value': -1
            }
          }
          if (name === 'issue') {
            sort = req.query.sort[name] === 'asc' ? {
              'dates.0.value': 1
            } : {
              'dates.0.value': -1
            }
          }
          if (name === 'name') {
            sort = req.query.sort[name] === 'asc' ? {
              name: 1
            } : {
              name: -1
            }
          }
          if (name === 'sequence.text') {
            sort = req.query.sort[name] === 'asc' ? {
              'sequence.text': 1
            } : {
              'sequence.text': -1
            }
          }
          if (name === 'count') {
            sort = req.query.sort[name] === 'asc' ? {
              'aCount': 1
            } : {
              'aCount': -1
            }
          }
        }
      }
    }
    var pipeline = [{
      $match: keys
    },
    {
      $addFields: {
        isShow: {
          $function: {
            body: `function (status, actors, user) {
                if (status === 'draft') {
                  let cont = true
                  for (let a in actors) {
                    let act = actors[a]
                    if ((hex_md5(user.toString()) === hex_md5(act.user.toString())) && (act.role === 'to' || act.role === 'copy') && (act.path === 'hidden')) {
                      cont = false
                      return false
                    }
                  }
                  if (cont) return true
                } else {
                  return true
                }
              }`,
            args: ['$status', '$actors', req.session.context.user],
            lang: 'js'
          }
        }
      },
    },
    {
      $match: {
        isShow: true
      }
    },
    {
      $lookup: {
        from: 'attached',
        let: {
          find: '$_id'
        },
        pipeline: [{
          $match: {
            $expr: {
              $and: [{
                $eq: ['$reference', '$$find']
              }]
            }
          }
        },
        {
          $count: 'count'
        }
        ],
        as: 'aCount'
      }
    },
    {
      $addFields: {
        parent: {
          $ifNull: ['$reference', 0]
        }
      }
    },
    {
      $project: {
        content: 0,
        reference: 0
      }
    },
    {
      $sort: sort || {
        _id: -1
      }
    },
    {
      $skip: skip
    },
    {
      $limit: limit
    }
    ]
    mongo.aggregate('note', pipeline, {
      allowDiskUse: true
    }, async (err, docs) => {
      if (err) {
        send({
          error: err
        })
      } else {
        for (const i in docs) {
          const doc = docs[i]
          var y = doc.actors.findIndex((x) => {
            if (x) {
              return x.role !== 'reviser' && x.user && x.user.equals && x.user.equals(req.session.context.user)
            }
          })
          if (y !== -1) {
            var actual = doc.actors[y]
            doc.actor = {
              user: doc.actors[y].user,
              path: actual.role === 'copy' ? 'referred' : actual.path,
              role: actual.role
            }
          }
          if (!doc.actor) {
            let e = myAndDependentUnits.findIndex((x) => {
              for (let a in doc.actors) {
                if (doc.actors[a].unit && doc.actors[a].unit.toString() === x.toString()) {
                  var actual = doc.actors[a]
                  doc.actor = {
                    user: doc.actors[a].user,
                    path: actual.role === 'copy' ? 'referred' : actual.path,
                    role: actual.role
                  }
                }
              }
            })
            if (!doc.actor) {
              doc.actor = doc.actors[0]
            }
          }
        }
        for (let i = 0; i < docs.length; ++i) {
          var tagsId = docs[i].tags
          var usedTags = []
          if (tagsDoc.length > 0 && tagsId && tagsId.length > 0) {
            for (let t = 0; t < tagsDoc.length; t++) {
              if (tagsId.length) {
                for (let o = 0; o < tagsId.length; o++) {
                  if (tagsDoc[t].id && tagsId[o] && tagsDoc[t].id.toString() === tagsId[o].toString()) {
                    usedTags.push(tagsDoc[t])
                  }
                }
              } else {
                if (tagsDoc[t] && tagsId && tagsDoc[t].id.toString() === tagsId.toString()) {
                  usedTags.push(tagsDoc[t])
                }
              }
            }
          }
          var doc = docs[i]
          doc.count = doc.aCount && doc.aCount[0] ? doc.aCount[0].count : 0
          if (doc.type === 'expense') {
            doc.status = 'expense'
          }
          if (doc.actor) {
            var actor = doc.actor
          }
          doc.type2 = await new Promise(resolve => {
            mongo.findId('template', doc.template, { type: 1 }, (err, d) => {
              if (err || !d) resolve('')
              else resolve(d.type)
            })
          })
          reply.data.push(this.row(doc, req, actor, usersAll, unitsAll, usedTags))
        }
        if (skip) {
          send(reply)
        } else {
          pipeline.splice(6, 3)
          pipeline.push({
            $group: {
              _id: null,
              count: {
                $sum: 1
              }
            }
          })
          pipeline.push({
            $project: {
              _id: 0
            }
          })
          mongo.aggregate('note', pipeline, {
            allowDiskUse: true
          }, (err, count) => {
            if (err) {
              console.log(err)
              send()
            } else {
              reply.total_count = count[0] ? count[0].count : 0
              send(reply)
            }
          })
        }
      }
    })
  }

  searchAttached (req, mongo, send) {
    if (!req.query._id) {
      send([])
    } else {
      mongo.find('attached', {
        reference: mongo.toId(req.query._id)
      }, {}, {
        name: -1
      }, (err, attached) => {
        if (err) {
          req.statusCode = 404
          send([])
        } else {
          let flag = true
          if (attached.length > 0) {
            for (const i in attached) {
              if (attached[i].status !== 'prepared') {
                flag = false
                break
              }
            }
          } else {
            flag = true
          }
          send({
            flag: flag
          })
        }
      })
    }
  }

  markSeen (req, mongo, send) {
    mongo.findId('note', req.query._id, {content: 0}, async (err, doc) => {
      if (err) throw err
      if (!doc) {
        send({})
      } else {
        send({})
        /*
        const i = doc.actors.findIndex((x) => {
          return (x.role === 'to' || x.role === 'copy') && x.user.toString() === req.query.user
        })
        if (i !== -1 && !doc.actors[i].seen) {
          doc.actors[i].seen = '1'
          const toNoti = []
          const noti = {
            _id: mongo.newId(),
            actors: [],
            document: {
              id: doc._id,
              status: doc.status
            },
            collection: 'note',
            path: 'note.note',
            type: 6,
            user: req.session.context.user
          }
          noti.createdAt = noti._id.getTimestamp()
          for (const i in doc.actors) {
            if (doc.actors[i].role === 'reviser' || doc.actors[i].role === 'from') {
              noti.actors.push({
                user: doc.actors[i].user,
                seen: 0
              })
              toNoti.push(doc.actors[i].user)
            }
          }
          console.log('#1')
          mongo.save('notification', noti, (err) => {
            if (err) {
              console.log(err)
            }
          })
          console.log('#2')
          notification.send(req, req.session.context.room, 'badgeNotification', null, toNoti, null)
          console.log('#3')
          notification.pushNotification(req, doc, noti, toNoti)
          console.log('#4')
        }
        mongo.save('note', doc, (err) => {
          if (err) {
            req.logger.log(err)
          } else {
            console.log('#5')
            mongo.findOne('settings', {
              _id: 'settings'
            }, (err, settings) => {
              console.log('#6')
              let notReplyAudited = false
              if (settings) {
                notReplyAudited = settings.notReplyAudited || false
                if (notReplyAudited === '0') notReplyAudited = false
                else if (notReplyAudited === '1') notReplyAudited = true
              }
              send({
                notReplyAudited: notReplyAudited
              })
            })
          }
        })*/
      }
    })
  }

  broadcastItem (req, mongo, _send, doc, users, units, tagsDoc) {
    mongo.count('attached', {
      reference: doc._id
    }, (err, count) => {
      if (err) throw err
      doc.count = count
      var tagsId = []
      for (const t in doc.tags) {
        tagsId.push(doc.tags[t])
      }
      var usedTags = []
      if (tagsDoc[0]) {
        for (let t = 0; t < tagsDoc[0].options.length; t++) {
          for (let o = 0; o < tagsId.length; o++) {
            if (tagsId[o] && tagsDoc[0].options[t].id.toString() === tagsId[o].toString()) {
              usedTags.push(tagsDoc[0].options[t])
            }
          }
        }
      }
      if (doc.actor) {
        var actor = doc.actor
      }

      return this.row(doc, req, actor, users, units, usedTags)
    })
  }

  getMainActor (doc, user) {
    var actor = doc.actors[0] ? doc.actors[0] : {}
    var i = doc.actors.findIndex((u) => {
      return u.user.equals ? u.user.equals(user) : u.user === user.toString()
    })
    if (i !== -1) {
      actor = doc.actors[i]
      if (actor.path === 'sent') {
        i = doc.actors.findIndex((u) => {
          return u.role === 'to'
        })
      } else {
        i = doc.actors.findIndex((u) => {
          return u.role === 'from'
        })
      }
      if (i !== -1) {
        const path = actor.path
        actor = doc.actors[i]
        actor.path = path
      }
    }
    return actor
  }

  row (doc, _req, actor, users, units, usedTags) {
    var issue = {}

    var deadline = {}
    for (const x in doc.dates) {
      if (doc.dates[x].type === 'issue') {
        issue = doc.dates[x]
      } else if (doc.dates[x].type === 'deadline') {
        deadline = doc.dates[x]
      }
    }
    var attachments = 'none'
    if (doc.files && doc.files.length > 0) {
      for (const x in doc.files) {
        if (doc.files[x]) {
          attachments = 'attachments'
        }
      }
    }
    const expired = doc.status === tags.processing && deadline.value && deadline.value.getTime() <= new Date().getTime() ? tags.expired : undefined
    var tagscolor = []
    var tagsname = []
    var filterNames = [usedTags[0] ? usedTags[0].value : '']
    for (const i in usedTags) {
      tagscolor.push(usedTags[i].color)
      tagsname.push(usedTags[i].value)
    }
    let reviser;
    let from;
    const to = []
    let reviserFind = false
    let emisorUnit;
    const receiverUnit = []
    const seenActors = []
    const deliveredActors = []
    let t = 0;
    let c = 0
    if (users && units) {
      doc.actors.findIndex((x) => {
        var user = users[x.user] ? users[x.user].name || '' : ''
        var unit = units[x.unit] ? units[x.unit].name || '' : ''
        if (x.path === 'sent' && x.role === 'reviser' && !reviserFind) {
          x.name = user
          reviser = x
          emisorUnit = {
            unit: x.unit,
            name: unit
          }
          reviserFind = true
        }
        if (x.path === 'sent' && x.role === 'from') {
          x.name = user
          from = x
          emisorUnit = {
            unit: x.unit,
            name: unit
          }
        }
        if (x.role === 'to') {
          x.name = user
          to.push(x)
          if (units[x.unit]) {
            receiverUnit.push({
              unit: x.unit,
              name: unit
            })
            t++
          }

          if (x.seen) {
            c++
            seenActors.push({
              id: x.user,
              name: x.name
            })
          } else {
            deliveredActors.push({
              id: x.user,
              name: x.name
            })
          }
        }
        if (x.role === 'copy') {
          x.name = user
          t++
          if (x.seen) {
            c++
            seenActors.push({
              id: x.user,
              name: x.name
            })
          } else {
            deliveredActors.push({
              id: x.user,
              name: x.name
            })
          }
        }
      })
    }

    var row = {
      id: doc._id.toString(),
      attachments: attachments,
      revisorNotView: doc.revisorNotView,
      expired: expired,
      css: expired || doc.status || tags.processing,
      count: doc.count,
      status: doc.status ? doc.status : tags.processing,
      statusName: doc.status,
      emisor: from || reviser,
      receiver: to,
      emisorUnit: emisorUnit || null,
      receiverUnit: receiverUnit,
      sequence: doc.sequence && doc.sequence.text ? doc.sequence.text : '',
      name: doc.name,
      path: actor.path,
      pathName: actor.path,
      issue: issue.value ? tags.util.date2str(issue.value, 'DD/MM/YYYY', tags) : '',
      category: doc.category || '',
      deadline: deadline.value ? tags.util.date2str(deadline.value, 'DD/MM/YYYY', tags) : '',
      tagscolor: tagscolor,
      tagsname: tagsname,
      filterNames: filterNames,
      archived: doc.status && doc.status === 'archived' ? 'archived' : '',
      issued: doc.issued,
      actors: doc.actors,
      content: doc.content,
      seenActors: seenActors,
      deliveredActors: deliveredActors,
      icon: 'none'
    }
    if (doc.type2) {
      row.type2 = doc.type2
    } else {
      row.type2 = 'note'
    }
    if (doc.type) {
      row.type = doc.type
    }
    if (doc.task) {
      row.task = doc.task
    }
    if (doc.reference) {
      row.reference = doc.reference
      row.icon = 'attached'
    }
    if (doc.commitment) {
      row.commitment = doc.commitment
      row.icon = 'folder-clock-outline'
    }
    if (doc.evidence) {
      row.evidence = doc.evidence
      row.icon = 'evidence'
      row.copyUser = doc.copyUser
    }
    if (doc.actors) {
      if (doc.event) {
        row.responsible = {
          id: doc.event.user,
          name: users[doc.event.user] ? users[doc.event.user].name : ''
        }
        for (let i in doc.actors) {
          if (doc.actors[i].role === 'supervisor' || doc.actors[i].role === 'from' || doc.actors[i].role === 'reviser' || (doc.actors[i].path === 'sent' && doc.actors[i].role === 'responsible')) {
            let user = doc.actors[i].user
            if (user.toString() === doc.event.user.toString()) {
              row.revisor = true
              break
            }
          }
        }
        let indexR = doc.actors.findIndex((x) => {
          return x.user.toString() === doc.event.user.toString() && (x.role === 'responsible' && x.path === 'sent')
        })
        if (indexR !== -1) {
          let user = doc.actors[indexR].user
          if (doc.responsableUnitActors && row.revisor) {
            for (let r in doc.responsableUnitActors) {
              if (doc.responsableUnitActors[r].user.toString() === user.toString() && doc.responsableUnitActors[r].type && doc.responsableUnitActors[r].type[0] === 'assistant') {
                row.revisor = false
                break
              }
            }
          }
        }
      } //else {
      for (let i in doc.actors) {
        if (doc.actors[i].role === 'responsible') {
          const user = doc.actors[i].user
          row.responsible = {
            id: user,
            name: users[user] ? users[user].name : ''
          }
          break
        }
      }
      //}
    }
    if (doc.responsableUnitActors) {
      for (let r in doc.responsableUnitActors) {
        if (doc.responsableUnitActors[r].user.toString() === _req.session.context.user.toString() && doc.responsableUnitActors[r].type && doc.responsableUnitActors[r].type[0] === 'assistant') {
          row.assistantResponsable = true
          break
        }
      }
    }
    let indexS = doc.actors.findIndex((x) => {
      return x.user.toString() === _req.session.context.user.toString() && x.role === 'supervisor'
    })
    let indexR = doc.actors.findIndex((x) => {
      return x.user.toString() === _req.session.context.user.toString() && x.role === 'responsible'
    })
    if (indexS !== -1 && indexR !== -1) {
      row.revisor = true
    }

    if ((actor.role === 'from' || actor.role === 'reviser') && doc.status !== 'draft') {
      if (t === c) {
        row.seen = 'seen'
      } else {
        row.seen = 'notseen'
      }
    } else {
      row.seen = 'none'
    }

    return row
  }

  annulled (req, mongo, send) {
    var body = req.body
    let comment = body.comment ? body.comment : ''
    mongo.findId('note', body._id, {
      content: 0
    }, (err, note) => {
      if (err || !note) {
        if (err) console.log(err)
        send()
      } else {
        let actorOrigen = ''
        let continuar = false
        let actors = note.actors
        let indexReviser = actors.findIndex((x) => {
          return x.role === 'reviser' && x.path === 'sent'
        })
        let indexFrom = actors.findIndex((x) => {
          return x.role === 'from'
        })
        if (indexFrom !== -1) {
          actorOrigen = note.actors[indexFrom]
          continuar = true
          for (let i in note.actors) {
            let actor = note.actors[i]
            if (actor.role !== 'from') {
              actor.path = 'hidden'
            }
          }
        } else if (indexReviser !== -1) {
          actorOrigen = note.actors[indexReviser]
          continuar = true
          for (let i in note.actors) {
            let actor = note.actors[i]
            if (actor.role !== 'reviser') {
              actor.path = 'hidden'
            }
          }
        }
        if (continuar) {
          mongo.save('note', {
            _id: note._id,
            status: 'annulled',
            actors: note.actors
          }, async (err, result) => {
            if (err) {
              send({
                error: err
              })
            } else {
              await new Promise(resolve => {
                req.app.routes.eventUtil.save(req, mongo, 'statusChange', 'annulled', note._id, comment, 'note', () => {
                  resolve()
                })
              })

              await new Promise(resolve => {
                mongo.find('reminders', {
                  document: mongo.toId(note._id)
                }, {}, (err, rem) => {
                  if (rem && rem.length) {
                    for (let f in rem) {
                      rem[f].status = 'inactive'
                      rem[f].cleared = new Date()
                      mongo.save('reminders', rem[f], () => {
                        resolve()
                      })
                    }
                  } else {
                    resolve()
                  }
                })
              })

              mongo.find('attached', {
                reference: note._id
              }, {}, async (err, atts) => {
                if (err || !atts) {
                  if (err) console.log(err)
                  send()
                } else {
                  for (let i in atts) {
                    for (let a in atts[i].actors) {
                      let actor = atts[i].actors[a]
                      if (actor.user.toString() !== actorOrigen.user.toString()) {
                        actor.path = 'hidden'
                      }
                    }
                    await new Promise(resolve => {
                      mongo.save('attached', {
                        _id: atts[i]._id,
                        status: 'annulled',
                        actors: atts[i].actors
                      }, async () => {
                        await new Promise(resolve => {
                          req.app.routes.eventUtil.save(req, mongo, 'statusChange', 'annulled', atts[i]._id, comment, 'attached', () => {
                            resolve()
                          })
                        })

                        await new Promise(resolve => {
                          mongo.find('reminders', {
                            document: mongo.toId(atts[i]._id)
                          }, {}, (err, rem) => {
                            if (rem && rem.length) {
                              for (let f in rem) {
                                rem[f].status = 'inactive'
                                rem[f].cleared = new Date()
                                mongo.save('reminders', rem[f], () => {
                                  resolve()
                                })
                              }
                            } else {
                              resolve()
                            }
                          })
                        })

                        mongo.findOne('commitment', {
                          reference: atts[i]._id
                        }, {
                          content: 0
                        }, (err, comm) => {
                          if (err || !comm) {
                            resolve()
                          } else {
                            for (let a in comm.actors) {
                              let actor = comm.actors[a]
                              if (actor.user.toString() !== actorOrigen.user.toString()) {
                                actor.path = 'hidden'
                              }
                            }
                            mongo.save('commitment', {
                              _id: comm._id,
                              status: 'annulled',
                              actors: comm.actors
                            }, async () => {
                              await new Promise(resolve => {
                                req.app.routes.eventUtil.save(req, mongo, 'statusChange', 'annulled', comm._id, comment, 'commitment', () => {
                                  resolve()
                                })
                              })

                              await new Promise(resolve => {
                                mongo.find('reminders', {
                                  document: mongo.toId(comm._id)
                                }, {}, (err, rem) => {
                                  if (rem && rem.length) {
                                    for (let f in rem) {
                                      rem[f].status = 'inactive'
                                      rem[f].cleared = new Date()
                                      mongo.save('reminders', rem[f], () => {
                                        resolve()
                                      })
                                    }
                                  } else {
                                    resolve()
                                  }
                                })
                              })

                              mongo.find('evidence', {
                                reference: comm._id
                              }, {}, async (err, evids) => {
                                if (err || !evids) {
                                  if (err) console.log(err)
                                  resolve()
                                } else {
                                  for (let i in evids) {
                                    for (let a in evids[i].actors) {
                                      let actor = evids[i].actors[a]
                                      if (actor.user.toString() !== actorOrigen.user.toString()) {
                                        actor.path = 'hidden'
                                      }
                                    }
                                    await new Promise(resolve => {
                                      mongo.save('evidence', {
                                        _id: evids[i]._id,
                                        status: 'annulled',
                                        actors: evids[i].actors
                                      }, (err) => {
                                        if (!err) {
                                          req.app.routes.eventUtil.save(req, mongo, 'statusChange', 'annulled', evids[i]._id, comment, 'evidence', () => {
                                            resolve()
                                          })
                                        } else {
                                          resolve()
                                        }
                                      })
                                    })
                                  }
                                  resolve()
                                }
                              })
                            })
                          }
                        })
                      })
                    })
                  }
                  send()
                }
              })
            }
          })
        } else {
          send()
        }
      }
    })
  }

  delete (req, mongo, send) {
    mongo.findId('note', req.query._id, {
      content: 0
    }, (err, doc) => {
      if (err) {
        send({
          error: err
        })
      } else {
        if (doc && doc.status === 'processing') {
          send({
            msj: 'noteAlreadySent'
          })
        } else {
          mongo.deleteOne('note', {
            _id: mongo.toId(doc._id)
          }, (err) => {
            if (err) {
              req.logger.log(err)
            } else {
              mongo.save('note', {
                _id: mongo.toId(doc.reference),
                answered: '0',
                status: 'processing'
              }, (err) => {
                if (err) {
                  req.logger.log(err)
                } else {
                  mongo.deleteAll('attached', {
                    reference: mongo.toId(doc._id)
                  }, (err) => {
                    if (err) {
                      req.logger.log(err)
                    } else {
                      req.app.routes.trash.insert(req, mongo, 'note', doc, () => {
                        this.sendNotification(req, mongo, send, doc, true)
                        send({})
                      })
                    }
                  })
                }
              })
            }
          })
        }
      }
    })
  }

  actions (req, mongo, send) {
    mongo.findId('note', req.body._id, async (err, doc) => {
      if (err) {
        send({
          error: err
        })
      } else {
        var i = -1
        var assistants = req.session.context.assistantUnits
        var indexAssistant = -1
        switch (req.body.action) {
        case 'attended':
          doc.actors.forEach((x, index) => {
            if (x.user && x.user.equals) {
              if (x.user.equals(req.session.context.user) && x.role === 'from') i = index
              else if (x.user.equals(req.session.context.user)) i = index
            }
          })
          for (const a in assistants) {
            indexAssistant = doc.actors.findIndex((x) => {
              if (x.role === 'from') {
                return x.unit.toString() === assistants[a].toString()
              } else {
                return -1
              }
            })
            if (indexAssistant !== -1) {
              doc.status = 'attended'
              await new Promise(resolve => {
                mongo.find('reminders', {
                  document: mongo.toId(doc._id)
                }, {}, (err, rem) => {
                  if (rem && rem.length) {
                    for (let f in rem) {
                      rem[f].status = 'inactive'
                      rem[f].cleared = new Date()
                      mongo.save('reminders', rem[f], () => {
                        resolve()
                      })
                    }
                  } else {
                    resolve()
                  }
                })
              })
              break
            }
          }
          if (i !== -1 && indexAssistant === -1) {
            const actor = doc.actors[i]
            if (actor.role === 'from') {
              doc.status = 'attended'
              await new Promise(resolve => {
                mongo.find('reminders', {
                  document: mongo.toId(doc._id)
                }, {}, (err, rem) => {
                  if (rem && rem.length) {
                    for (let f in rem) {
                      rem[f].status = 'inactive'
                      rem[f].cleared = new Date()
                      mongo.save('reminders', rem[f], () => {
                        resolve()
                      })
                    }
                  } else {
                    resolve()
                  }
                })
              })
            } else {
              actor.path = 'attended'
            }
          }
          break

        case 'processing':
          doc.actors.forEach((x, index) => {
            if (x.user && x.user.equals) {
              if (x.user.equals(req.session.context.user) && x.role === 'from') i = index
              else if (x.user.equals(req.session.context.user)) i = index
            }
          })
          for (const a in assistants) {
            indexAssistant = doc.actors.findIndex((x) => {
              if (x.role === 'from') {
                return x.unit.toString() === assistants[a].toString()
              } else {
                return -1
              }
            })
            if (indexAssistant !== -1) {
              doc.status = 'processing'
              await new Promise(resolve => {
                mongo.find('reminders', {
                  document: mongo.toId(doc._id)
                }, {}, (err, rem) => {
                  if (rem && rem.length) {
                    for (let f in rem) {
                      rem[f].status = 'active'
                      rem[f].cleared = new Date()
                      mongo.save('reminders', rem[f], () => {
                        resolve()
                      })
                    }
                  } else {
                    resolve()
                  }
                })
              })
              break
            }
          }
          if (i !== -1 && indexAssistant === -1) {
            const actor = doc.actors[i]
            if (actor.role === 'from') {
              doc.status = 'processing'
              await new Promise(resolve => {
                mongo.find('reminders', {
                  document: mongo.toId(doc._id)
                }, {}, (err, rem) => {
                  if (rem && rem.length) {
                    for (let f in rem) {
                      rem[f].status = 'active'
                      rem[f].cleared = new Date()
                      mongo.save('reminders', rem[f], () => {
                        resolve()
                      })
                    }
                  } else {
                    resolve()
                  }
                })
              })
            } else {
              if (actor.role === 'to') {
                actor.path = 'received'
              } else {
                actor.path = 'referred'
              }
            }
          }
          break

        case 'archived':
          doc.actors.forEach((x, index) => {
            if (x.user && x.user.equals) {
              if (x.user.equals(req.session.context.user) && x.role === 'from') i = index
              else if (x.user.equals(req.session.context.user)) i = index
            }
          })
          for (const a in assistants) {
            indexAssistant = doc.actors.findIndex((x) => {
              if (x.role === 'from') {
                return x.unit.toString() === assistants[a].toString()
              } else {
                return -1
              }
            })
            if (indexAssistant !== -1) {
              doc.status = 'archived'
              break
            }
          }
          if (i !== -1) {
            const actor = doc.actors[i]
            if (actor.role === 'from') {
              doc.status = 'archived'
            }
          }
          break

        case 'unArchived':
          doc.actors.forEach((x, index) => {
            if (x.user && x.user.equals) {
              if (x.user.equals(req.session.context.user) && x.role === 'from') i = index
              else if (x.user.equals(req.session.context.user)) i = index
            }
          })
          for (const a in assistants) {
            indexAssistant = doc.actors.findIndex((x) => {
              if (x.role === 'from') {
                return x.unit.toString() === assistants[a].toString()
              } else {
                return -1
              }
            })
            if (indexAssistant !== -1) {
              doc.status = 'attended'
              break
            }
          }
          if (i !== -1) {
            const actor = doc.actors[i]
            if (actor.role === 'from') {
              doc.status = 'attended'
            }
          }
          break
        }

        mongo.save('note', doc, async (err) => {
          if (err) {
            send()
          } else {
            await new Promise(resolve => {
              req.app.routes.eventUtil.save(req, mongo, 'statusChange', doc.status, doc._id, '', 'note', () => {
                resolve()
              })
            })
            send({})
            // sendNotification(req,   mongo, send, doc);
          }
        })
      }
    })
  }

  // hallazgos
  async countDocumentsFinds (req, mongo, send) {
    // encontratar tag con el nombre
    var tag = await new Promise(resolve => {
      mongo.find('params', {
        'options.value': req.query.tag
      }, {
        'options.$': 1
      }, (err, tag) => {
        if (err) throw err
        resolve(tag)
      })
    })
    var count
    if (tag.length === 0) {
      count = 0
    } else {
      count = await new Promise(resolve => {
        mongo.count('note', {
          tags: tag[0].options[0].id
        }, (err, count) => {
          if (err) throw err
          resolve(count)
        })
      })
    }

    send({
      count: count
    })
  }

  async countCommitmentPending (_req, mongo, send) {
    var count = await new Promise(resolve => {
      mongo.count('note', {
        $and: [{
          commitment: {
            $exists: true
          }
        }, {
          status: 'processing'
        }]
      }, (err, count) => {
        if (err) throw err
        resolve(count)
      })
    })
    send({
      count: count
    })
  }

  async setProject (req, mongo, send) {
    var doc = req.body
    var idNote = req.query.filter
    if (doc.task) {
      var split = doc.task.split(',&,')
      doc.task = split[0]
      doc.project = split[1]
      var note = await new Promise(resolve => {
        mongo.findId('note', idNote, async (err, note) => {
          if (!err) {
            resolve(note)
          }
        })
      })
      var proj = await new Promise(resolve => {
        mongo.findId('project', doc.project, async (err, project) => {
          if (!err) {
            resolve(project)
          }
        })
      })
      if (note && proj) {
        note.task = mongo.toId(doc.task)
        note.project = mongo.toId(doc.project)
        var result = await new Promise(resolve => {
          mongo.save('note', note, async (err) => {
            if (err) {
              resolve(false)
            } else {
              resolve(true)
            }
          })
        })
        if (result) {
          var pos = proj.content.data.findIndex((x) => {
            return x.id.toString() === doc.task
          })
          if (pos !== -1) {
            var task = proj.content.data[pos]
            if (task.documents && task.documents.length >= 0) {
              task.documents.push(mongo.toId(idNote))
            } else {
              task.documents = []
              task.documents.push(mongo.toId(idNote))
            }
            mongo.save('project', proj, async (err) => {
              if (err) {
                send(false)
              } else {
                send({
                  msj: '_noteAssignedToProject'
                }) //Nota asignada a proyecto
              }
            })
          }
        } else {
          send({
            msj: '_cantAssignedNoteToProject'
          }) //No se pudo asignar la nota a un proyecto
        }
      }
    } else {
      send({
        msj: '_cantAssignedNoteToProjectRetry'
      }) //No es posible asignar la nota a un proyecto. Favor reintente
    }
  }

  async personalTag (req, mongo, send) {
    const note = req.query.note
    const tag = req.query.tag
    const personalTag = await this.findPersonalTag(tag, mongo)
    mongo.findId('note', note, (err, doc) => {
      if (err || !doc) {
        console.log(err)
        send()
      } else {
        if (!doc.personalTag) doc.personalTag = []
        let index = doc.personalTag.findIndex(x => {
          return x.user.toString() === req.session.context.user.toString()
        })
        if (index === -1) {
          doc.personalTag.push({
            user: req.session.context.user,
            tag: tag
          })
        }
        mongo.save('note', {
          _id: doc._id,
          personalTag: doc.personalTag
        }, (err, result) => {
          if (err) {
            console.log(err)
            send()
          } else {
            send({
              value: personalTag.value || '',
              color: personalTag.color || ''
            })
          }
        })
      }
    })
  }

  favorite (req, mongo, send) {
    let change = req.query.favorite
    mongo.findId('note', req.query._id, (err, doc) => {
      if (err || !doc) {
        console.log(err)
        send()
      } else {
        if (change === 'true') {
          let index = doc.favorite.findIndex(x => {
            return x.toString() === req.session.context.user.toString()
          })
          if (index !== -1) {
            doc.favorite.splice(index, 1)
          }
          change = false
        } else {
          if (!doc.favorite) doc.favorite = []
          let index = doc.favorite.findIndex(x => {
            return x.toString() === req.session.context.user.toString()
          })
          if (index === -1) {
            doc.favorite.push(req.session.context.user)
          }
          change = true
        }
        mongo.save('note', {
          _id: doc._id,
          favorite: doc.favorite
        }, (err, result) => {
          if (err) {
            console.log(err)
            send()
          } else {
            send({
              favorite: change
            })
          }
        })
      }
    })
  }

  untag (req, mongo, send) {
    mongo.findId('note', req.query._id, (err, doc) => {
      if (err || !doc) {
        console.log(err)
        send()
      } else {
        let index = doc.personalTag.findIndex(x => {
          return x.user.toString() === req.session.context.user.toString()
        })
        if (index !== -1) {
          doc.personalTag.splice(index, 1)
        }
        mongo.save('note', {
          _id: doc._id,
          personalTag: doc.personalTag
        }, (err, result) => {
          if (err) {
            console.log(err)
            send()
          } else {
            send()
          }
        })
      }
    })
  }

  async listFavorite (req, mongo, send) {
    var keys = {
      favorite: {
        $in: [req.session.context.user]
      }
    }
    mongo.findN('note', req.query.skip ? Number(req.query.skip) : 0, 50, keys, {}, {}, async (err, result) => {
      if (err) {
        console.log(err)
        send()
      } else {
        const data = []
        var users = await new Promise(resolve => {
          mongo.toHash('user', {}, {
            _id: 1,
            name: 1
          }, (err, users) => {
            if (!err) {
              resolve(users)
            }
          })
        })
        for (const i in result) {
          let issue = ''
          for (const x in result[i].dates) {
            if (result[i].dates[x].type === 'issue') {
              issue = result[i].dates[x]
            }
            break
          }
          let from = ''
          for (const x in result[i].actors) {
            if (result[i].actors[x].role === 'from') {
              from = result[i].actors[x].user
            }
          }
          let tag = {}
          if (result[i].personalTag) {
            let index = result[i].personalTag.findIndex(x => {
              return x.user.toString() === req.session.context.user.toString()
            })
            if (index !== -1) {
              tag = await req.app.routes.note.findPersonalTag(result[i].personalTag[index].tag, mongo)
            }
          }
          const tagColor = tag.color || ''
          const tagName = tag.value || ''
          this.getTemplateList(data, result[i], users, tagColor, tagName, issue, from, req)
        }
        send(data)
      }
    })
  }

  async listByTag (req, mongo, send) {
    if (req.query.personalTag) {
      let personalTag = mongo.toId(req.query.personalTag)
      var keys = {
        personalTag: {
          $elemMatch: {
            user: req.session.context.user,
            tag: personalTag
          }
        }
      }
      mongo.findN('note', 0, 50, keys, {}, {}, async (err, result) => {
        if (err) {
          console.log(err)
          send()
        } else {
          const data = []
          var users = await new Promise(resolve => {
            mongo.toHash('user', {}, {
              _id: 1,
              name: 1
            }, (err, users) => {
              if (!err) {
                resolve(users)
              }
            })
          })
          for (const i in result) {
            let issue = ''
            for (const x in result[i].dates) {
              if (result[i].dates[x].type === 'issue') {
                issue = result[i].dates[x]
              }
              break
            }
            let from = ''
            for (const x in result[i].actors) {
              if (result[i].actors[x].role === 'from') {
                from = result[i].actors[x].user
              }
            }
            let tag = {}
            if (result[i].personalTag) {
              let index = result[i].personalTag.findIndex(x => {
                return x.user.toString() === req.session.context.user.toString()
              })
              if (index !== -1) {
                tag = await req.app.routes.note.findPersonalTag(result[i].personalTag[index].tag, mongo)
              }
            }
            const tagColor = tag.color || ''
            const tagName = tag.value || ''
            this.getTemplateList(data, result[i], users, tagColor, tagName, issue, from, req)
          }
          send(data)
        }
      })
    } else {
      send([])
    }
  }

  getTemplateList (data, doc, users, color, name, date, from, req) {
    if (doc.favorite) {
      let index = doc.favorite.findIndex(x => {
        return x.toString() === req.session.context.user.toString()
      })
      if (index !== -1) {
        doc.favorite = true
      } else {
        doc.favorite = false
      }
    }
    data.push({
      id: doc._id,
      sequence: doc.sequence && doc.sequence.text ? doc.sequence.text : '',
      name: doc.name /*? doc.name.length >= 55 ? doc.name.substr(0, 55) + '...' : doc.name : ''*/ ,
      date: date.value,
      aCount: doc.aCount && doc.aCount[0] ? doc.aCount[0].count : '',
      from: users[from] ? {
        name: users[from].name,
        user: from
      } : {
        name: '',
        user: ''
      },
      tagColor: color,
      tagName: name,
      favorite: doc.favorite || false,
      status: doc.status
    })
    return data
  }

  async findPersonalTag (t, mongo) {
    const tag = await new Promise(resolve => {
      mongo.findOne('params', {
        name: 'personalTags'
      }, (err, doc) => {
        if (err || !doc) {
          console.log(err)
          resolve({})
        } else {
          const index = doc.options.findIndex((x) => {
            return x.id.toString() === t.toString()
          })
          resolve(doc.options[index])
        }
      })
    })
    return tag
  }
  senders (req, mongo, send) {
    var pipeline = [{
      $addFields: {
        actors: {
          $filter: {
            input: '$actors',
            as: 'item',
            cond: {
              $eq: ['$$item.role', 'from']
            }
          }
        }
      }
    },
    {
      $group: {
        _id: '$actors.user'
      }
    },
    {
      $lookup: {
        from: 'user',
        localField: '_id',
        foreignField: '_id',
        as: 'rev'
      }
    },
    {
      $unwind: '$rev'
    },
    {
      $group: {
        _id: {
          id: '$rev._id',
          value: '$rev.name'
        }
      }
    },
    {
      $project: {
        _id: 0,
        id: '$_id.id',
        value: '$_id.value'
      }
    }
    ]
    mongo.aggregate('note', pipeline, {}, (err, options) => {
      if (err) console.log(err)
      if (!options) options = []
      options.forEach(doc => {
        if (doc.value) doc.value = doc.value.replace(/(<([^>]+)>)/g, '')
      })
      send(options)
    })
  }
  senderUnits (req, mongo, send) {
    var pipeline = [{
      $addFields: {
        actors: {
          $filter: {
            input: '$actors',
            as: 'item',
            cond: {
              $eq: ['$$item.role', 'from']
            }
          }
        }
      }
    },
    {
      $group: {
        _id: '$actors.unit'
      }
    },
    {
      $lookup: {
        from: 'unit',
        localField: '_id',
        foreignField: '_id',
        as: 'rev'
      }
    },
    {
      $unwind: '$rev'
    },
    {
      $group: {
        _id: {
          id: '$rev._id',
          value: '$rev.name'
        }
      }
    },
    {
      $project: {
        _id: 0,
        id: '$_id.id',
        value: '$_id.value'
      }
    }
    ]
    mongo.aggregate('note', pipeline, {}, (err, options) => {
      if (err) console.log(err)
      send(options)
    })
  }
  async receivers (req, mongo, send) {
    var pipeline = [{
      $match: {
        units: {
          $in: await this.$unitDependents(mongo, req.session.context.managerUnits.concat(req.session.context.assistantUnits))
        }
      }
    },
    {
      $project: {
        _id: 0,
        id: '$_id',
        value: '$name'
      }
    },
    {
      $sort: {
        value: 1
      }
    }
    ]
    mongo.aggregate('user', pipeline, {}, (err, options) => {
      if (err) console.log(err)
      send(options)
    })
  }
  async receiverUnits (req, mongo, send) {
    var pipeline = [{
      $match: {
        _id: {
          $in: await this.$unitDependents(mongo, req.session.context.managerUnits.concat(req.session.context.assistantUnits))
        }
      }
    },
    {
      $project: {
        _id: 0,
        id: '$_id',
        value: '$name'
      }
    },
    {
      $sort: {
        value: 1
      }
    }
    ]
    mongo.aggregate('unit', pipeline, {}, (err, options) => {
      if (err) console.log(err)
      send(options)
    })
  }
  async $keys (req, mongo) {
    var keys
    var scalableSequences = await new Promise(resolve => {
      mongo.find('sequence', {
        scalable: true
      }, (err, seqs) => {
        if (err) console.log(err)
        var ids = []
        if (seqs) {
          for (let s in seqs) {
            ids.push(seqs[s]._id)
          }
        }
        resolve(ids)
      })
    })
    if (req.session.context.licensedUser === false) {
      var myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits)
      var myAndDependentUnits = req.session.context.dependentUnits.concat(myUnits)
      keys = {
        $or: [
          // to or copy user without hidden
          {
            actors: {
              $elemMatch: {
                user: req.session.context.user,
                path: {
                  $ne: 'hidden'
                }
              }
            }
          },
          // Confidential, without sequence and in manager/assistant units
          {
            confidential: {
              $ne: '1'
            },
            $and: [{
              'sequence.sequence': {
                $nin: scalableSequences
              }
            },
            {
              'sequence._id': {
                $nin: scalableSequences
              }
            }
            ],
            actors: {
              $elemMatch: {
                role: {
                  $in: ['to', 'copy']
                },
                unit: {
                  $in: myUnits
                },
                path: {
                  $ne: 'hidden'
                }
              }
            }
          },
          // if not confidential and scalable, responsible unit are in dependents units without hidden only
          {
            confidential: {
              $ne: '1'
            },
            $or: [{
              'sequence.sequence': {
                $in: scalableSequences
              }
            },
            {
              'sequence._id': {
                $in: scalableSequences
              }
            },
            {
              'sequence.sequence': null,
              'sequence._id': null
            }
            ],
            actors: {
              $elemMatch: {
                role: {
                  $in: ['to', 'copy']
                },
                unit: {
                  $in: myAndDependentUnits
                },
                path: {
                  $ne: 'hidden'
                }
              }
            }
          }
        ]
      }
      if (req.session.context.readerUnits && req.session.context.readerUnits.length > 0) {
        keys.$or.push({
          $and: [{
            actors: {
              $elemMatch: {
                unit: {
                  $in: req.session.context.readerUnits
                },
                path: {
                  $ne: 'hidden'
                },
                role: 'from'
              }
            }
          },

          ]
        })
      }
    } else {
      myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits).concat(req.session.context.memberUnits)
      myAndDependentUnits = req.session.context.dependentUnits.concat(myUnits)
      keys = {
        $or: [
          // users in the note & not hidden
          {
            actors: {
              $elemMatch: {
                user: req.session.context.user,
                path: {
                  $ne: 'hidden'
                }
              }
            }
          },
          // not confitential and assistant in one unit of note & not hidden
          {
            confidential: {
              $ne: '1'
            },
            actors: {
              $elemMatch: {
                unit: {
                  $in: myUnits
                },
                path: {
                  $ne: 'hidden'
                }
              }
            }
          },
          // manager or assistant of ascending unit, not hidden, scalable, non-confidential and not in draft
          {
            confidential: {
              $ne: '1'
            },
            actors: {
              $elemMatch: {
                unit: {
                  $in: myAndDependentUnits
                },
                path: {
                  $ne: 'hidden'
                }
              }
            },
            $or: [{
              'sequence.sequence': {
                $in: scalableSequences
              }
            },
            {
              'sequence._id': {
                $in: scalableSequences
              }
            }
            ]
          }
        ]
      }
      if (req.session.context.readerUnits && req.session.context.readerUnits.length > 0) {
        keys.$or.push({
          $and: [{
            actors: {
              $elemMatch: {
                unit: {
                  $in: req.session.context.readerUnits
                },
                path: {
                  $ne: 'hidden'
                },
                role: 'from'
              }
            }
          },

          ]
        })
      }
    }
    return keys
  }

  $dependents (parent, dependents, units) {
    units.forEach((u) => {
      if (u.parent && u.parent.equals && u.parent.equals(parent)) {
        dependents.push(u._id)
        this.$dependents(u._id, dependents, units)
      }
    })
  }
  async $unitDependents (mongo, id) {
    if (!id.forEach) {
      id = [id]
    }
    var units = await new Promise(resolve => {
      mongo.find('unit', {}, {
        parent: 1
      }, (err, all) => {
        if (err) console.log(err)
        resolve(all)
      })
    })
    var dependents = []
    id.forEach((i) => {
      dependents.push(i)
      this.$dependents(i, dependents, units)
    })
    return dependents
  }
  async $subunits (mongo, ids) {
    var units = await new Promise(resolve => {
      mongo.find('unit', {}, {
        parent: 1
      }, (err, all) => {
        if (err) console.log(err)
        resolve(all)
      })
    })
    var parents = []
    if (ids) {
      ids.forEach((id) => {
        parents.push({
          unit: id,
          dependents: [id]
        })
      })
      units.forEach((u) => {
        if (u.parent && u.parent.equals && ids.findIndex((id) => {
          return u.parent.equals(id)
        }) !== -1) {
          var element = {
            unit: u._id,
            dependents: [u._id]
          }
          this.$dependents(u._id, element.dependents, units)
          parents.push(element)
        }
      })
    }
    return parents
  }
}
exports.Note = Note