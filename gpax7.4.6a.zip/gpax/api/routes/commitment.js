var tags = require('../utils/tags').tags
var dateformat = require('dateformat')
var Html = require('../utils/html').Html
var html = new Html()
var moment = require('moment')
var Notification = require('../utils/notification').Notification
var notification = new Notification()
/* exported */

exports.Commitment = Commitment

function Commitment () {
  this.get = async function (req, mongo, send) {
    var doc = {}
    if (!!req.query._id && req.query._id !== 'undefined') {
      var keys = await this.$keys(req, mongo)
      var pipeline = [
        {$match: {_id: mongo.toId(req.query._id)}},
        {$lookup: {from: 'attached',localField: 'reference',foreignField: '_id',as: 'att'}},
        {$unwind: '$att'},
        {$lookup: {from: 'note',localField: 'att.reference',foreignField: '_id',as: 'note'}},
        {$unwind: '$note'},
        {$addFields: {actor: {$filter: {input: '$actors',as: 'actor',cond: {$eq: ['$$actor.role', 'responsible']}}}}},
        {$lookup: {from: 'unit',localField: 'actor.unit',foreignField: '_id',as: 'unit'}},
        {$addFields: {revs: '$actors',sequence: '$note.sequence',confidential: '$note.confidential',actors: '$att.actors',tags: '$att.tags',offline: {$arrayElemAt: [{$ifNull: ['$unit.offline', [false]]}, 0]}}},
        {$match: keys},
        {$addFields: {actors: '$revs'}}
      ]
      mongo.aggregate('commitment', pipeline, {}, (err, document) => {
        if (err || !document || document.length === 0) {
          req.statusCode = 400
          send()
        } else {
          document = document[0]
          // responsibleUnit is offline and current user is auditor, he can supervising these commitment
          if (document.offline && req.session.context.licensedUser) {
            document.actors.push({
              user: req.session.context.user,
              path: 'sent',
              role: 'co-responsible',
              unit: req.session.context.memberUnits[0]
            })
            document.unit_Offline = document.offline
            delete document.offline
          }
          if (document.actors) {
            for (let i in document.actors) {
              if (document.actors[i].user.toString() === req.session.context.user.toString() && (document.actors[i].role === 'revisor' || document.actors[i].role === 'supervisor')) {
                document.actors.push({
                  user: req.session.context.user,
                  path: 'sent',
                  role: 'co-responsible',
                  unit: req.session.context.memberUnits[0]
                })
                break
              }
            }
          }
          let deadline, answerDate, trackingDate
          if (document.dates) {
            document.dates.findIndex((x) => {
              if (x.type === 'deadline') deadline = x.value
              if (x.type === 'answered') answerDate = x.value
              if (x.type === 'trackingDate') trackingDate = x.value
            })
          }
          if (deadline) {
            var date = dateformat(new Date(deadline), 'yyyy/mm/dd')
            document.deadline = date
          }
          if (answerDate) {
            date = dateformat(new Date(answerDate), 'yyyy/mm/dd')
            document.answerDate = date
          }
          if (trackingDate) {
            date = dateformat(new Date(trackingDate), 'yyyy/mm/dd')
            document.trackingDate = date
          }
          if (document.type === 'spreadsheet' && typeof(document.content) === 'string') {
            document.content = JSON.parse(document.content)
          }
          if (document.task) {
            req.query.project = document.project
            req.query.task = document.task
            send(document)
          } else {
            send(document)
          }
        }
      })
    } else {
      // New document
      doc = {
        _id: mongo.newId(),
        isNew: true,
        status: tags.draft,
        actors: [],
        type: 'note',
        commitment: '1'
      }
      if (req.query.project) {
        doc.project = req.query.project
        doc.task = req.query.task
      }
      if (req.query.reference) {
        doc.reference = req.query.reference
        var actors = req.query.actors
        const index = actors.findIndex((x) => {
          return (x.user.toString() === req.session.context.user.toString() ||
                            req.session.context.assistantUnits.findIndex((u) => {
                              return u.equals(x.unit)
                            }) !== -1) &&
                        (x.role == 'responsible' || x.role == 'co-responsible')
        })
        // cambiado por
        for (const i in actors) {
          switch (actors[i].role) {
          case 'supervisor':
          case 'from':
          case 'reviser':
            if (actors[i].user.toString() !== req.session.context.user.toString()) {
              actors[i].path = 'hidden'
            }
            doc.actors.push(actors[i])
            break
          }
        }
        var attached = await new Promise(resolve => {
          mongo.find('attached', {
            _id: mongo.toId(req.query.reference.toString())
          }, {
            _id: 1,
            name: 1,
            responsible: 1
          }, (err, attached) => {
            if (!err) {
              resolve(attached)
            } else {
              resolve(false)
            }
          })
        })
        if (index === -1) {
          if (attached && attached.length) {
            const i = actors.findIndex((x) => {
              return x.role === 'responsible'
            })
            doc.actors.push(actors[i])
            if (!actors[i].user.equals(req.session.context.user)) {
              doc.actors.push({
                user: req.session.context.user,
                unit: actors[i].unit,
                role: 'co-responsible',
                path: 'received'
              })
            }
          }
        } else {
          // problema BCRSalvador
          if (actors[index].path === 'inCharge') {
            actors[index].role = 'inCharge'
            actors[index].path = 'received'
          }
          doc.actors.push(actors[index])
        }

        /// /////////////////
      }
      if (attached[0]) doc.name = 'Compromiso - ' + attached[0].name
      if (req.query.template) {
        mongo.findId('template', req.query.template, (err, template) => {
          if (!err) {
            doc.type = 'note'
            if (!doc.name) {
              doc.name = template.name
            }
            doc.template = req.query.template
            doc.status = 'draft'
            if (template.pageType) {
              doc.pageType = template.pageType
            }
            if (template.units) {
              doc.units = template.units
            }
            if (template.sequence && template.sequence[0]) {
              doc.sequence = {
                sequence: template.sequence[0]
              }
            } else {
              doc.sequence = {
                text: ''
              }
            }
            doc.content = template.template
            send(doc)
          } else {
            send()
          }
        })
      } else {
        send(doc)
      }
    }
  }

  this.pdf = function (req, mongo, send) {
    mongo.findId('commitment', req.query._id, async (err, doc) => {
      if (!err && doc) {
        var i = 0
        while (doc.content.indexOf('{{', i) !== -1 && doc.content.substring(doc.content.indexOf('{{', i), doc.content.indexOf('{{', i) + 1) === '{') {
          i = doc.content.indexOf('{{', i)
          const f = doc.content.indexOf('}}', i)
          const word = doc.content.substring(i + 2, f)
          if (!['page', 'pages'].includes(word)) {
            doc.content = doc.content.replace(new RegExp('{{' + word + '}}', 'g'), '')
          }
          i = f + 2
        }
        if (req.query.details) {
          let user
          doc.actors.forEach(x => {
            if (x.path === 'sent' && x.role === 'reviser') {
              user = x.user
            } else if (x.path === 'sent' && x.role === 'from') {
              user = x.user
            }
          })
          if (doc.project) {
            var proj = await new Promise(resolve => {
              mongo.findId('project', doc.project, (err, project) => {
                if (!err) {
                  resolve(project)
                }
              })
            })
          }
          if (user) {
            var us = await new Promise(resolve => {
              mongo.findId('user', user, (err, user) => {
                if (!err) {
                  resolve(user)
                }
              })
            })
          }
          let i, fit, last
          if (doc.content.indexOf('id="pageFooter-last"') !== -1 || doc.content.indexOf('id="pageFooter-last"') !== -1) {
            i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter-last"'))
            if (!i) {
              i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter-last"'))
            }
            fit = doc.content.slice(0, i + 1)
            last = doc.content.slice(i + 1)
            doc.content = fit + ('<span style="position:relative;font-size: xx-small; top:0em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().format('MM-DD-YYYY') + '</span>') + last
          } else if (doc.content.indexOf('id="pageFooter"') !== -1 || doc.content.indexOf('id="pageFooter"') !== -1) {
            i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter"'))
            if (!i) {
              i = doc.content.indexOf('>', doc.content.indexOf('id="pageFooter"'))
            }
            fit = doc.content.slice(0, i + 1)
            last = doc.content.slice(i + 1)
            doc.content = fit + ('<span style="position:relative;font-size: xx-small; top:0em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().format('MM-DD-YYYY') + '</span>') + last
          } else {
            doc.content = doc.content + '<div id="pageFooter" ><div style="position:relative;font-size: xx-small; top:0em; left:0em;">Proyecto: ' + proj.name + ', Creador: ' + us.name + ', Generado el: ' + moment().format('MM-DD-YYYY') + '</div></div>'
          }
        }
        html.pdf(mongo, req, doc.content, doc.pageType, (err, stream) => {
          if (err) {
            send({
              error: err
            })
          } else {
            send(stream)
          }
        })
      } else {
        send({
          error: err
        })
      }
    })
  }

  this.kanban = async function (req, mongo, send) {
    let period = req.query.period
    var doc
    var keys = await this.$keys(req, mongo)
    keys.status = {
      $nin: ['done', 'completed']
    }
    if (period && period.start && period.end) {
      keys.dates = {
        $elemMatch: {
          value: {
            $gte: new Date(period.start),
            $lte: new Date(new Date(period.end).setHours(23, 59, 59))
          },
          type: 'deadline'
        }
      }
    } else if (period && period.start) {
      keys.dates = {
        $elemMatch: {
          value: {
            $gte: new Date(period.start)
          },
          type: 'deadline'
        }
      }
    }
    mongo.aggregate('commitment', [{
      $lookup: {
        from: 'attached',
        let: {
          find: '$reference'
        },
        pipeline: [{
          $match: {
            $expr: {
              $and: [{
                $eq: ['$_id', '$$find']
              }]
            }
          }
        },
        {
          $project: {
            _id: 1,
            reference: 1,
            sequence: 1,
            actors: 1
          }
        }
        ],
        as: 'att'
      }
    },
    {
      $addFields: {
        att: {
          $mergeObjects: '$att'
        }
      }
    },
    {
      $addFields: {
        sequenceAtta: '$att.sequence',
        actorsAtta: '$att.actors',
      }
    },
    {
      $lookup: {
        from: 'note',
        let: {
          find: '$att.reference'
        },
        pipeline: [{
          $match: {
            $expr: {
              $and: [{
                $eq: ['$_id', '$$find']
              }]
            }
          }
        },
        {
          $project: {
            _id: 1,
            name: 1,
            sequence: 1
          }
        }
        ],
        as: 'note'
      }
    },
    {
      $addFields: {
        actor: {
          $filter: {
            input: '$actors',
            as: 'actor',
            cond: {
              $eq: ['$$actor.role', 'responsible']
            }
          }
        }
      }
    },
    {
      $lookup: {
        from: 'unit',
        localField: 'actor.unit',
        foreignField: '_id',
        as: 'unit'
      }
    },
    {
      $addFields: {
        offline: {
          $ifNull: [{
            $arrayElemAt: [{
              $ifNull: ['$unit.offline', [false]]
            }, 0]
          }, '']
        }
      }
    },
    {
      $addFields: {
        isShow: {
          $function: {
            body: `function (offline, status, actors, user) {
                if (status === 'draft') {
                  for (let a in actors) {
                    let act = actors[a]
                    if ((hex_md5(user.toString()) === hex_md5(act.user.toString())) && offline && (act.role === 'from' || act.role === 'reviser' || act.role === 'supervisor') && (act.path === 'sent')) {
                      return true
                    }
                    if ((hex_md5(user.toString()) === hex_md5(act.user.toString())) && act.role === 'responsible') {
                      return true
                    }
                  }
                } else {
                  return true
                }
              }`,
            args: ['$offline', '$status', '$actorsAtta', req.session.context.user],
            lang: 'js'
          }
        }
      }
    },
    {
      $match: keys
    },
    {
      $match: {
        isShow: true
      }
    },
    {
      $project: {
        _id: 1,
        actors: 1,
        dates: 1,
        sequence: '$sequenceAtta',
        status: 1,
        name: 1,
        template: 1,
        note: '$note'
      }
    }
    ], {}, (err, commitments) => {
      if (err) throw err
      mongo.toHash('user', {}, async (err, users) => {
        if (err) throw err
        const data = []
        let ex = 0
        let ex30 = 0
        let ex7 = 0
        let re = 0
        let toAc = 0
        let wr = 0
        for (const i in commitments) {
          doc = commitments[i]
          //encontrar tipo de template, note, editor.....
          doc.type2 = await new Promise(resolve => {
            mongo.findId('template', doc.template, { type: 1 }, (err, d) => {
              if (err || !d) resolve('')
              else resolve(d.type)
            })
          })

          const note = doc.note[0]
          const y = doc.actors.findIndex((x) => {
            return x && x.role === 'responsible'
          })
          const actor = doc.actors[y]
          let deadline
          if (doc.dates) {
            doc.dates.findIndex((x) => {
              if (x.type === 'deadline') deadline = x.value
            })
          }

          var suma7dias = 7 * 24 * 60 * 60 * 1000

          const inc = doc.actors.findIndex((x) => {
            return x.role === 'inCharge' && x.user.toString() === req.session.context.user.toString()
          })

          const sup = doc.actors.findIndex((x) => {
            return x.role === 'supervisor' && x.user.toString() === req.session.context.user.toString()
          })
          if (deadline && actor &&
                        doc.status !== 'draft' && doc.status !== 'done' && doc.status !== 'incomplete' && doc.status !== 'canceled' &&
                        deadline.setHours(0, 0, 0, 0, 0) < new Date().setHours(0, 0, 0, 0, 0) &&
                        deadline.setHours(0, 0, 0, 0, 0) !== new Date().setHours(0, 0, 0, 0, 0)) {
            ex++
            data.push({
              id: doc._id.toString(),
              status: 'expired',
              text: note.sequence && note.sequence.text ? doc.name + '</br>' + '<b>[' + note.sequence.text + ']</b>' + ' - ' + note.name : doc.name + ' - ' + note.name,
              userId: actor ? actor.user.toString() : '',
              userName: users[actor.user.toString()] ? users[actor.user.toString()].name.replace(/(<([^>]+)>)/g, '') : '',
              color: 'red',
              type2: doc.type2
            })
          } else if (doc.status === 'draft') {
            wr++
            data.push({
              id: doc._id.toString(),
              status: 'writing',
              text: note.sequence && note.sequence.text ? doc.name + '</br>' + '<b>[' + note.sequence.text + ']</b>' + ' - ' + note.name : doc.name + ' - ' + note.name,
              userId: actor.user.toString(),
              userName: users[actor.user.toString()] ? users[actor.user.toString()].name.replace(/(<([^>]+)>)/g, '') : '',
              color: '#4ACFCB',
              type2: doc.type2
            })
          } else if (deadline && actor &&
                        doc.status !== 'draft' && doc.status !== 'done' && doc.status !== 'incomplete' && doc.status !== 'canceled' &&
                        deadline.setHours(0, 0, 0, 0, 0) > new Date().setHours(0, 0, 0, 0, 0) &&
                        deadline.setHours(0, 0, 0, 0, 0) < new Date().setHours(0, 0, 0, 0, 0) + suma7dias) {
            ex7++
            data.push({
              id: doc._id.toString(),
              status: 'pending1week',
              text: note.sequence && note.sequence.text ? doc.name + '</br>' + '<b>[' + note.sequence.text + ']</b>' + ' - ' + note.name : doc.name + ' - ' + note.name,
              userId: actor.user.toString(),
              userName: users[actor.user.toString()] ? users[actor.user.toString()].name.replace(/(<([^>]+)>)/g, '') : '',
              color: '#50DE67',
              type2: doc.type2
            })
          } else if (deadline && actor &&
                        doc.status !== 'draft' && doc.status !== 'done' && doc.status !== 'incomplete' && doc.status !== 'canceled' &&
                        deadline.setHours(0, 0, 0) > new Date().setHours(0, 0, 0)) {
            ex30++
            data.push({
              id: doc._id.toString(),
              status: 'pending',
              text: note.sequence && note.sequence.text ? doc.name + '</br>' + '<b>[' + note.sequence.text + ']</b>' + ' - ' + note.name : doc.name + ' - ' + note.name,
              userId: actor.user.toString(),
              userName: users[actor.user.toString()] ? users[actor.user.toString()].name.replace(/(<([^>]+)>)/g, '') : '',
              color: '#50DE67',
              type2: doc.type2
            })
          } else if (doc.status === 'ready' && inc !== -1 && actor) {
            re++
            data.push({
              id: doc._id.toString(),
              status: 'ready',
              text: note.sequence && note.sequence.text ? doc.name + '</br>' + '<b>[' + note.sequence.text + ']</b>' + ' - ' + note.name : doc.name + ' - ' + note.name,
              userId: actor.user.toString(),
              userName: users[actor.user.toString()] ? users[actor.user.toString()].name.replace(/(<([^>]+)>)/g, '') : '',
              color: '#07831B',
              type2: doc.type2
            })
          } else if (doc.status === 'ready' && sup !== -1 && actor) {
            toAc++
            data.push({
              id: doc._id.toString(),
              status: 'toAccept',
              text: note.sequence && note.sequence.text ? doc.name + '</br>' + '<b>[' + note.sequence.text + ']</b>' + ' - ' + note.name : doc.name + ' - ' + note.name,
              userId: actor.user.toString(),
              userName: users[actor.user.toString()] ? users[actor.user.toString()].name.replace(/(<([^>]+)>)/g, '') : '',
              color: '#07831B',
              type2: doc.type2
            })
          }
        }
        if (data.length) {
          data[0].ex = ex
          data[0].ex7 = ex7
          data[0].ex30 = ex30
          data[0].re = re
          data[0].toAc = toAc
          data[0].wr = wr
        }
        send(data)
      })
    })
  }

  this.save = async function (req, mongo, send) {
    mongo.findId('commitment', req.body._id, async (err, docs) => {
      if (err) {
        send({
          error: err
        })
      } else {
        var exists
        if (docs) {
          exists = await new Promise(resolve => {
            mongo.find('commitment', {
              reference: docs.reference
            }, (err, exists) => {
              if (!err) {
                resolve(exists)
              }
            })
          })
        } else {
          exists = false
        }
        if ((exists && exists[0]) && !docs) {
          send({
            message: 'Ya existe compromiso'
          })
        } else {
          mongo.find('evidence', {
            reference: mongo.toId(req.body._id)
          }, {}, {}, async (err, evidences) => {
            if (err) {
              send({
                error: err
              })
            } else {
              const doc = req.body
              var continuar = true
              if (doc.status === 'completed' && evidences && evidences.length > 0) {
                // if commintment is completted, dependent evidences can be ready
                for (const t in evidences) {
                  if (continuar) {
                    if (evidences[t].status !== 'incomplete') {
                      evidences[t].status = 'ready'
                      await new Promise(resolve => {
                        mongo.save('evidence', evidences[t], (err) => {
                          if (err) {
                            continuar = false
                            resolve()
                          } else {
                            req.app.routes.eventUtil.save(req, mongo, 'statusChange', evidences[t].status, evidences[t]._id, '', 'evidence', () => {
                              resolve()
                            })
                          }
                        })
                      })
                    }
                  }
                }
              }
              if (continuar) {
                if (err) throw err
                if (!docs) {
                  if (doc.replyTo) {
                    doc.links = [JSON.parse(JSON.stringify(doc.replyTo))]
                  }
                } else {
                  doc.actors = docs.actors
                  if (!doc.status) {
                    doc.status = docs.status
                  }
                }
                if (req.query.status && req.query.status.includes('btnPopupGiveBack') && (doc.status === 'ready' || doc.status === 'returned')) {

                  let existAlarmDate = ''
                  if (doc.dates && doc.dates.length) {
                    for (let d in doc.dates) {
                      if (doc.dates[d].type === 'deadline') {
                        existAlarmDate = doc.dates[d].value
                      }
                    }
                  }

                  if (existAlarmDate) {
                    //************* creacion de alarmas ******/
                    let alarm = {}

                    let attAlarm = await new Promise(resolve => {
                      mongo.findId('attached', mongo.toId(doc.reference), {}, (err, attac) => {
                        if (attac) {
                          resolve(attac)
                        } else {
                          resolve('')
                        }
                      })
                    })

                    let noteAlarm = await new Promise(resolve => {
                      mongo.findId('note', mongo.toId(attAlarm.reference), {}, (err, note) => {
                        if (note) {
                          resolve(note)
                        } else {
                          resolve('')
                        }
                      })
                    })

                    let deadlineNote = ''
                    if (noteAlarm.dates && noteAlarm.dates.length) {
                      for (let d in noteAlarm.dates) {
                        if (noteAlarm.dates[d].type === 'deadline') {
                          deadlineNote = noteAlarm.dates[d].value
                        }
                      }
                    }

                    let dateNow = new Date()

                    if (deadlineNote && (dateNow.getTime() > deadlineNote.getTime())) {
                      deadlineNote = dateNow
                    }

                    alarm._id = mongo.newId()
                    alarm.type = 'commitment'
                    alarm.document = doc._id
                    alarm.date = deadlineNote || existAlarmDate
                    alarm.cleared = ''

                    alarm.owner = []
                    alarm.deparmentManager = []
                    for (let i in attAlarm.actors) {
                      if (attAlarm.actors[i].role === 'responsible') {
                        alarm.owner.push(attAlarm.actors[i])

                        if (attAlarm.actors[i].unit) {
                          await new Promise(resolve => {
                            mongo.findId('unit', attAlarm.actors[i].unit, (err, unit) => {
                              if (unit) {
                                if (unit.actors) {
                                  for (let a in unit.actors) {
                                    if (unit.actors[a].type && (unit.actors[a].type[0] === 'manager' || unit.actors[a].type[0] === 'assistant')) {
                                      alarm.deparmentManager.push(unit.actors[a].user)
                                    }
                                  }
                                }
                              }
                              resolve()
                            })
                          })
                        }
                      }
                    }

                    alarm.reviewer = []
                    for (let i in attAlarm.actors) {
                      if (attAlarm.actors[i].role === 'reviser') {
                        alarm.reviewer.push(attAlarm.actors[i])
                      }
                    }

                    alarm.supervisor = []
                    for (let i in attAlarm.actors) {
                      if (attAlarm.actors[i].supervisor === '1' || attAlarm.actors[i].role === 'from') {
                        alarm.supervisor.push(attAlarm.actors[i])
                      }
                    }

                    alarm.snooze = []
                    alarm.status = 'active'

                    await new Promise(resolve => {
                      mongo.save('reminders', alarm, () => {
                        resolve()
                      })
                    })
                  }

                }

                if (req.query.status && req.query.status.includes('btnPopupGiveBack') && doc.status === 'accepted') {

                  let existAlarmDate = ''
                  if (doc.dates && doc.dates.length) {
                    for (let d in doc.dates) {
                      if (doc.dates[d].type === 'deadline') {
                        existAlarmDate = doc.dates[d].value
                      }
                    }
                  }

                  if (existAlarmDate) {
                    //************* creacion de alarmas ******/
                    let alarm = {}

                    let attAlarm = await new Promise(resolve => {
                      mongo.findId('attached', mongo.toId(doc.reference), {}, (err, attac) => {
                        if (attac) {
                          resolve(attac)
                        } else {
                          resolve('')
                        }
                      })
                    })

                    let deadlineAtt = ''
                    if (attAlarm.dates && attAlarm.dates.length) {
                      for (let d in attAlarm.dates) {
                        if (attAlarm.dates[d].type === 'deadline') {
                          deadlineAtt = attAlarm.dates[d].value
                        }
                      }
                    }

                    let dateNow = new Date()

                    if (deadlineAtt && (dateNow.getTime() > deadlineAtt.getTime())) {
                      deadlineAtt = dateNow
                    }

                    alarm._id = mongo.newId()
                    alarm.type = 'commitment'
                    alarm.document = doc._id
                    alarm.date = deadlineAtt || existAlarmDate
                    alarm.cleared = ''

                    alarm.owner = []
                    alarm.deparmentManager = []
                    for (let i in attAlarm.actors) {
                      if (attAlarm.actors[i].role === 'responsible') {
                        alarm.owner.push(attAlarm.actors[i])

                        if (attAlarm.actors[i].unit) {
                          await new Promise(resolve => {
                            mongo.findId('unit', attAlarm.actors[i].unit, (err, unit) => {
                              if (unit) {
                                if (unit.actors) {
                                  for (let a in unit.actors) {
                                    if (unit.actors[a].type && (unit.actors[a].type[0] === 'manager' || unit.actors[a].type[0] === 'assistant')) {
                                      alarm.deparmentManager.push(unit.actors[a].user)
                                    }
                                  }
                                }
                              }
                              resolve()
                            })
                          })
                        }
                      }
                    }

                    alarm.reviewer = []
                    for (let i in attAlarm.actors) {
                      if (attAlarm.actors[i].role === 'reviser') {
                        alarm.reviewer.push(attAlarm.actors[i])
                      }
                    }

                    alarm.supervisor = []
                    for (let i in attAlarm.actors) {
                      if (attAlarm.actors[i].supervisor === '1' || attAlarm.actors[i].role === 'from') {
                        alarm.supervisor.push(attAlarm.actors[i])
                      }
                    }

                    alarm.snooze = []
                    alarm.status = 'active'

                    await new Promise(resolve => {
                      mongo.save('reminders', alarm, () => {
                        resolve()
                      })
                    })
                  }

                }

                if (doc.status === 'accepted') {

                  await new Promise(resolve => {
                    mongo.find('reminders', {
                      document: mongo.toId(doc._id)
                    }, {}, (err, rem) => {
                      if (rem && rem.length) {
                        for (let f in rem) {
                          rem[f].status = 'inactive'
                          rem[f].cleared = new Date()
                          mongo.save('reminders', rem[f], () => {
                            resolve()
                          })
                        }
                      } else {
                        resolve()
                      }
                    })
                  })

                  let existAlarmDate = ''
                  if (doc.dates && doc.dates.length) {
                    for (let d in doc.dates) {
                      if (doc.dates[d].type === 'deadline') {
                        existAlarmDate = doc.dates[d].value
                      }
                    }
                  }

                  if (existAlarmDate) {
                    //************* creacion de alarmas ******/
                    let alarm = {}

                    alarm._id = mongo.newId()
                    alarm.type = 'commitment'
                    alarm.document = doc._id
                    alarm.date = existAlarmDate
                    alarm.cleared = ''

                    alarm.owner = []
                    alarm.deparmentManager = []
                    for (let i in doc.actors) {
                      if (doc.actors[i].role === 'responsible') {
                        alarm.owner.push(doc.actors[i])

                        if (doc.actors[i].unit) {
                          await new Promise(resolve => {
                            mongo.findId('unit', doc.actors[i].unit, (err, unit) => {
                              if (unit) {
                                if (unit.actors) {
                                  for (let a in unit.actors) {
                                    if (unit.actors[a].type && (unit.actors[a].type[0] === 'manager' || unit.actors[a].type[0] === 'assistant')) {
                                      alarm.deparmentManager.push(unit.actors[a].user)
                                    }
                                  }
                                }
                              }
                              resolve()
                            })
                          })
                        }
                      }
                    }

                    alarm.reviewer = []
                    for (let i in doc.actors) {
                      if (doc.actors[i].role === 'reviser') {
                        alarm.reviewer.push(doc.actors[i])
                      }
                    }

                    alarm.supervisor = []
                    for (let i in doc.actors) {
                      if (doc.actors[i].role === 'supervisor') {
                        alarm.supervisor.push(doc.actors[i])
                      }
                    }

                    alarm.snooze = []
                    alarm.status = 'active'

                    await new Promise(resolve => {
                      mongo.save('reminders', alarm, () => {
                        resolve()
                      })
                    })
                  }
                }

                if (doc.status === 'completed') {

                  let existAlarmDate = ''
                  if (doc.dates && doc.dates.length) {
                    for (let d in doc.dates) {
                      if (doc.dates[d].type === 'trackingDate') {
                        existAlarmDate = doc.dates[d].value
                      }
                    }
                  }

                  if (existAlarmDate) {
                    //************* creacion de alarmas ******/

                    let attAlarm = await new Promise(resolve => {
                      mongo.findId('attached', mongo.toId(doc.reference), {}, (err, attac) => {
                        if (attac) {
                          resolve(attac)
                        } else {
                          resolve('')
                        }
                      })
                    })

                    let dateNow = new Date()

                    if (dateNow.getTime() > existAlarmDate.getTime()) {
                      existAlarmDate = dateNow
                    }

                    let alarm = {}

                    alarm._id = mongo.newId()
                    alarm.type = 'commitment'
                    alarm.document = doc._id
                    alarm.date = existAlarmDate
                    alarm.cleared = ''

                    alarm.owner = []
                    alarm.deparmentManager = []
                    for (let i in attAlarm.actors) {
                      if (attAlarm.actors[i].role === 'from') {
                        alarm.owner.push(attAlarm.actors[i])

                        if (attAlarm.actors[i].unit) {
                          await new Promise(resolve => {
                            mongo.findId('unit', attAlarm.actors[i].unit, (err, unit) => {
                              if (unit) {
                                if (unit.actors) {
                                  for (let a in unit.actors) {
                                    if (unit.actors[a].type && (unit.actors[a].type[0] === 'manager' || unit.actors[a].type[0] === 'assistant')) {
                                      alarm.deparmentManager.push(unit.actors[a].user)
                                    }
                                  }
                                }
                              }
                              resolve()
                            })
                          })
                        }
                      }
                    }

                    alarm.reviewer = []
                    for (let i in attAlarm.actors) {
                      if (attAlarm.actors[i].role === 'responsible') {
                        alarm.reviewer.push(attAlarm.actors[i])
                      }
                    }

                    alarm.supervisor = []
                    for (let i in attAlarm.actors) {
                      if (attAlarm.actors[i].supervisor === '1' || attAlarm.actors[i].role === 'from') {
                        alarm.supervisor.push(attAlarm.actors[i])
                      }
                    }

                    alarm.snooze = []
                    alarm.status = 'active'

                    await new Promise(resolve => {
                      mongo.find('reminders', {
                        document: mongo.toId(doc._id)
                      }, {}, (err, rem) => {
                        if (rem && rem.length) {
                          for (let f in rem) {
                            rem[f].status = 'inactive'
                            rem[f].cleared = new Date()
                            mongo.save('reminders', rem[f], () => {
                              resolve()
                            })
                          }
                        } else {
                          resolve()
                        }
                      })
                    })

                    await new Promise(resolve => {
                      mongo.save('reminders', alarm, () => {
                        resolve()
                      })
                    })

                  }
                }

                if (doc.status === 'done' || doc.status === 'incomplete' || doc.status === 'annulled' || doc.status === 'canceled') {

                  await new Promise(resolve => {
                    mongo.find('reminders', {
                      document: mongo.toId(doc._id)
                    }, {}, (err, rem) => {
                      if (rem && rem.length) {
                        for (let f in rem) {
                          rem[f].status = 'inactive'
                          rem[f].cleared = new Date()
                          mongo.save('reminders', rem[f], () => {
                            resolve()
                          })
                        }
                      } else {
                        resolve()
                      }
                    })
                  })

                  await new Promise(resolve => {
                    mongo.find('reminders', {
                      document: mongo.toId(doc.reference)
                    }, {}, (err, rem) => {
                      if (rem && rem.length) {
                        for (let f in rem) {
                          rem[f].status = 'inactive'
                          rem[f].cleared = new Date()
                          mongo.save('reminders', rem[f], () => {
                            resolve()
                          })
                        }
                      } else {
                        resolve()
                      }
                    })
                  })

                }

                if (doc.status === 'docReady') {
                  doc.status = 'ready'
                  for (const i in doc.actors) {
                    switch (doc.actors[i].role) {
                    case 'reviser':
                      doc.actors[i].path = 'sent'
                      break
                    case 'from':
                    case 'supervisor':
                      doc.actors[i].path = 'sent'
                      doc.actors[i].role = 'supervisor'
                      break
                    }
                  }

                  let existAlarmDate = ''
                  if (doc.dates && doc.dates.length) {
                    for (let d in doc.dates) {
                      if (doc.dates[d].type === 'deadline') {
                        existAlarmDate = doc.dates[d].value
                      }
                    }
                  }

                  if (existAlarmDate) {
                    //************* creacion de alarmas ******/
                    let alarm = {}

                    let attAlarm = await new Promise(resolve => {
                      mongo.findId('attached', mongo.toId(doc.reference), {}, (err, attac) => {
                        if (attac) {
                          resolve(attac)
                        } else {
                          resolve('')
                        }
                      })
                    })

                    alarm._id = mongo.newId()
                    alarm.type = 'commitment'
                    alarm.document = doc._id
                    alarm.date = existAlarmDate
                    alarm.cleared = ''

                    alarm.owner = []
                    alarm.deparmentManager = []
                    for (let i in attAlarm.actors) {
                      if (attAlarm.actors[i].role === 'from') {
                        alarm.owner.push(attAlarm.actors[i])

                        if (attAlarm.actors[i].unit) {
                          await new Promise(resolve => {
                            mongo.findId('unit', attAlarm.actors[i].unit, (err, unit) => {
                              if (unit) {
                                if (unit.actors) {
                                  for (let a in unit.actors) {
                                    if (unit.actors[a].type && (unit.actors[a].type[0] === 'manager' || unit.actors[a].type[0] === 'assistant')) {
                                      alarm.deparmentManager.push(unit.actors[a].user)
                                    }
                                  }
                                }
                              }
                              resolve()
                            })
                          })
                        }
                      }
                    }

                    alarm.reviewer = []
                    for (let i in attAlarm.actors) {
                      if (attAlarm.actors[i].role === 'responsible') {
                        alarm.reviewer.push(attAlarm.actors[i])
                      }
                    }

                    alarm.supervisor = []
                    for (let i in attAlarm.actors) {
                      if (attAlarm.actors[i].supervisor === '1' || attAlarm.actors[i].role === 'from') {
                        alarm.supervisor.push(attAlarm.actors[i])
                      }
                    }

                    alarm.snooze = []
                    alarm.status = 'active'

                    await new Promise(resolve => {
                      mongo.find('reminders', {
                        document: docs.reference
                      }, {}, (err, rem) => {
                        if (rem && rem.length) {
                          for (let f in rem) {
                            rem[f].status = 'inactive'
                            rem[f].cleared = new Date()
                            mongo.save('reminders', rem[f], () => {
                              resolve()
                            })
                          }
                        } else {
                          resolve()
                        }
                      })
                    })

                    await new Promise(resolve => {
                      mongo.save('reminders', alarm, () => {
                        resolve()
                      })
                    })
                  }

                }
                const ids = []
                doc.actors.findIndex((x) => {
                  if (x.role === 'responsible' || x.role === 'supervisor' || x.role === 'from') {
                    ids.push(x.user)
                  }
                })
                delete doc.att
                delete doc.comment
                delete doc.user
                delete doc.timeString
                delete doc.replyTo
                delete doc.isNew
                delete doc.delegates
                delete doc.mentions
                delete doc.answerDate
                delete doc.trackingDate
                var units = req.session.units || []
                var noti
                for (const i in doc.actors) {
                  if (doc.actors[i].user === req.session.context.user.toString() && doc.actors[i].unit) {
                    units = [mongo.toId(doc.actors[i].unit)]
                    break
                  }
                }
                var readers = []
                for (const i in doc.actors) {
                  if (doc.actors[i].unit) {
                    if (doc.actors[i].role === tags.from || units.findIndex(function (x) {
                      return x.toString() === doc.actors[i].unit
                    }) !== -1) {
                      readers.push(doc.actors[i].user)
                    }
                  }
                }
                // Add or update dates.issue
                if (doc.dates && doc.dates.length > 0) {
                  if (doc.status === 'ready') {
                    doc.dates[0].value = new Date()
                  }
                } else {
                  doc.dates = [{
                    type: tags.issue,
                    value: new Date()
                  }]
                }
                if (doc.deadline && ['returned', 'draft'].includes(doc.status)) {
                  doc.dates[1] = {
                    type: tags.deadline,
                    value: doc.deadline
                  }
                  delete doc.deadline
                }

                html.getData(doc.type === 'redactor' || doc.type === 'note' ? doc.content : '', async (data) => {
                  if (data.links && data.links.length > 0) {
                    if (!doc.links) {
                      doc.links = (docs && docs.links) ? docs.links : []
                    }
                    for (const i in data.links) {
                      if (doc.links.findIndex((lk) => {
                        return lk._id === data.links[i]._id
                      }) === -1) {
                        doc.links.push({
                          _id: data.links[i]._id,
                          clase: data.links[i].clase
                        })
                      }
                    }
                  }
                  if (doc.links && doc.links[0] === '{}') {
                    delete doc.links
                  }
                  if (doc.tags === '') {
                    doc.tags = []
                  } else {
                    if (typeof doc.tags === 'string') {
                      doc.tags = doc.tags.split(',')
                    }
                    for (const i in doc.tags) {
                      doc.tags[i] = mongo.toId(doc.tags[i])
                    }
                  }
                  if (doc.status === 'ready') {
                    const j = doc.dates.findIndex((x) => {
                      return x.type === 'answered'
                    })
                    if (j !== -1) {
                      doc.dates[j] = {
                        type: 'answered',
                        value: new Date()
                      }
                    } else {
                      doc.dates.push({
                        type: 'answered',
                        value: new Date()
                      })
                    }
                    const actorsNoti = []
                    doc.actors.findIndex((x) => {
                      if (x.role === 'supervisor' || x.supervisor === '1') {
                        actorsNoti.push({
                          user: x.user,
                          seen: 0
                        })
                      }
                    })
                    noti = {
                      _id: mongo.newId(),
                      actors: actorsNoti,
                      document: {
                        id: doc._id,
                        status: doc.status
                      },
                      collection: 'commitment',
                      path: 'note.commitment',
                      type: 2,
                      user: req.session.context.user
                    }
                    noti.createdAt = noti._id.getTimestamp()
                  }
                  delete doc.completedComm
                  // Si el compromiso no tiene el actor responsable de cumplirlo, lo busca en el adjunto y se lo agrega
                  var res = doc.actors.findIndex((a) => {
                    return a.role === 'responsible'
                  })
                  if (res === -1) {
                    var att = await new Promise(resolve => {
                      mongo.findId('attached', mongo.toId(doc.reference), (er, doc) => {
                        resolve(doc)
                      })
                    })
                    res = att.actors.findIndex((a) => {
                      return a.role === 'responsible'
                    })
                    doc.actors.push(att.actors[res])
                  }
                  if (doc.content.parentNode) {
                    delete doc.content.next
                    delete doc.content.parent
                    delete doc.content.prev
                    delete doc.content.root
                    delete doc.content.parentNode
                  }
                  mongo.save('commitment', doc, async (err) => {
                    if (err) {
                      send()
                    } else {
                      await new Promise(resolve => {
                        req.app.routes.eventUtil.save(req, mongo, 'statusChange', doc.status, doc._id, '', 'commitment', () => {
                          resolve()
                        })
                      })
                      if ((doc.status === 'processing' || doc.status === 'done' || doc.status === 'incomplete' || doc.status === 'accepted')) {
                        const y = doc.actors.findIndex((x) => {
                          return x && x.role === 'responsible'
                        })
                        noti = {
                          _id: mongo.newId(),
                          actors: [{
                            user: doc.actors[y].user,
                            seen: 0
                          }],
                          document: {
                            id: doc._id,
                            status: doc.status
                          },
                          collection: 'commitment',
                          path: 'note.commitment',
                          type: 2,
                          user: req.session.context.user
                        }
                        noti.createdAt = noti._id.getTimestamp()
                      }
                      if (doc.status === 'completed') {
                        const actorsNoti = []
                        doc.actors.findIndex((x) => {
                          if (x.role === 'supervisor' || x.supervisor === '1') {
                            actorsNoti.push({
                              user: x.user,
                              seen: 0
                            })
                          }
                        })
                        noti = {
                          _id: mongo.newId(),
                          actors: actorsNoti,
                          document: {
                            id: doc._id,
                            status: doc.status
                          },
                          collection: 'commitment',
                          path: 'note.commitment',
                          type: 2,
                          user: req.session.context.user
                        }
                        noti.createdAt = noti._id.getTimestamp()
                      }
                      if (doc.status === 'draft' || doc.status === 'returned') {
                        const y = doc.actors.findIndex((x) => {
                          return x.role === 'supervisor' && x.user.toString() === req.session.context.user
                        })
                        if (y === 0 || doc.status === 'returned') {
                          const j = doc.actors.findIndex((x) => {
                            return ['responsible', 'co-responsible'].includes(x.role)
                          })
                          noti = {
                            _id: mongo.newId(),
                            actors: [{
                              user: doc.actors[j].user,
                              seen: 0
                            }],
                            document: {
                              id: doc._id,
                              status: doc.status
                            },
                            collection: 'commitment',
                            path: 'note.commitment',
                            type: 2,
                            user: req.session.context.user
                          }
                          noti.createdAt = noti._id.getTimestamp()
                        }
                      }
                      let data = {}
                      data.name = doc.name
                      data.status = doc.status
                      data.actors = doc.actors
                      data.id = doc._id
                      let users = []
                      let units = []
                      await new Promise(resolve => {
                        mongo.toHash('user', {}, (err, urs) => {
                          if (err) console.log(err)
                          users = urs
                          mongo.toHash('unit', {}, (err, uns) => {
                            if (err) console.log(err)
                            units = uns
                            resolve()
                          })
                        })
                      })
                      let responsible
                      const revisers = []
                      const reviserUnit = []
                      for (var a in data.actors) {
                        if (data.actors[a].role === 'responsible') {
                          responsible = data.actors[a]
                        } else if (revisers.findIndex((x) => {
                          return x.user.toString() === data.actors[a].user.toString()
                        }) === -1) {
                          data.actors[a].name = users[data.actors[a].user] ? users[data.actors[a].user].name : ''
                          revisers.push(data.actors[a])
                          reviserUnit.push({
                            unit: data.actors[a].unit,
                            name: units[data.actors[a].unit] ? units[data.actors[a].unit].name : ''
                          })
                        }
                      }
                      data.reviser = revisers
                      data.reviserUnit = reviserUnit
                      let deadline
                      if (responsible) {
                        data.responsibleId = responsible.user.toString()
                        data.responsibleName = users[responsible.user.toString()] ? users[responsible.user.toString()].name : ''
                        data.responsibleUnit = responsible.unit && units[responsible.unit.toString()] ? units[responsible.unit.toString()].name : ''
                      }
                      for (var x in doc.dates) {
                        if (doc.dates[x].type === 'deadline') {
                          deadline = doc.dates[x]
                        }
                      }
                      data.deadline = deadline ? dateformat(new Date(deadline.value), 'yyyy/mm/dd') : ''
                      data.expired = !['done', 'incomplete', 'canceled'].includes(doc.status) && deadline && deadline.value && deadline.value.getTime() <= new Date().getTime() ? tags.expired : undefined
                      var tagFoundId = doc.tags
                      var tagsDoc = []
                      await new Promise(resolve => {
                        mongo.find('params', {
                          name: {
                            $in: ['riskLevel']
                          }
                        }, {
                          _id: 1,
                          name: 1,
                          options: 1
                        }, (err, tgsDs) => {
                          if (err) console.log(err)
                          if (tgsDs.length > 0) {
                            for (var i in tgsDs) {
                              tagsDoc = tagsDoc.concat(tgsDs[i].options)
                            }
                          }
                          resolve()
                        })
                      })
                      for (var t in tagsDoc) {
                        if (tagFoundId && tagFoundId.length > 0 && tagFoundId[0].toString() === tagsDoc[t].id.toString()) {
                          data.tagsname = tagsDoc[t].value
                          data.tagscolor = tagsDoc[t].color
                          break
                        }
                      }
                      notification.send(req, req.session.context.room, 'dtcommitments', data, null, null)
                      mongo.findId('attached', mongo.toId(doc.reference), {}, (err, attac) => {
                        if (err) throw err

                        if(doc.status === 'accepted'){
                          let deadlineComm = doc.dates.findIndex((x) => {
                            return x.type === 'deadline'
                          })
                          if (deadlineComm === -1) {
                            deadlineComm = new Date()
                          } else {
                            deadlineComm = doc.dates[deadlineComm].value
                          }
                          let k = attac.dates.findIndex((x) => {
                            return x.type === 'deadline'
                          })
                          if (k !== -1) {
                            attac.dates[k] = {
                              type: 'deadline',
                              value: deadlineComm
                            }
                          } else {
                            attac.dates.push({
                              type: 'deadline',
                              value: deadlineComm
                            })
                          }
                        }

                        if (doc.status === 'ready') {
                          const j = attac.dates.findIndex((x) => {
                            return x.type === 'answered'
                          })
                          if (j !== -1) {
                            attac.dates[j] = {
                              type: 'answered',
                              value: new Date()
                            }
                          } else {
                            attac.dates.push({
                              type: 'answered',
                              value: new Date()
                            })
                          }
                          attac.status = 'answered'
                        } else if (doc.status === 'done' || doc.status === 'incomplete' || doc.status === 'canceled') {
                          attac.status = 'completed'
                          if (doc.status === 'done') attac.realProgress = 100
                        } else attac.answered = '1'
                        mongo.save('attached', attac, async (err) => {
                          if (err) {
                            send()
                          } else {
                            await new Promise(resolve => {
                              req.app.routes.eventUtil.save(req, mongo, 'statusChange', attac.status, attac._id, '', 'attached', () => {
                                resolve()
                              })
                            })
                            mongo.find('attached', {
                              reference: mongo.toId(attac.reference)
                            }, {}, {
                              name: -1
                            }, async (err, attached) => {
                              if (err) {
                                req.statusCode = 404
                                send([])
                              } else {
                                let attended = true
                                if (attached.length > 0) {
                                  for (const i in attached) {
                                    let comm = await new Promise(resolve => {
                                      mongo.findOne('commitment', {
                                        reference: mongo.toId(attached[i]._id)
                                      }, {
                                        status: 1
                                      }, (err, result) => {
                                        if (err || !result) {
                                          resolve('')
                                        } else {
                                          resolve(result)
                                        }
                                      })
                                    })
                                    if (((attached[i].status !== 'completed' && attached[i].status !== 'annulled') && (comm && comm.status !== 'accepted')) || (attached[i].requiredResponse === '1' && !comm)) {
                                      attended = false
                                      break
                                    }
                                  }
                                } else {
                                  attended = false
                                }
                                if (attended) {
                                  await new Promise(resolve => {
                                    mongo.save('note', {
                                      _id: mongo.toId(attac.reference),
                                      status: 'attended'
                                    }, async (err, result) => {
                                      if (!err) {

                                        await new Promise(resolve => {
                                          mongo.find('reminders', {
                                            document: mongo.toId(attac.reference)
                                          }, {}, (err, rem) => {
                                            if (rem && rem.length) {
                                              for (let f in rem) {
                                                rem[f].status = 'inactive'
                                                rem[f].cleared = new Date()
                                                mongo.save('reminders', rem[f], () => {
                                                  resolve()
                                                })
                                              }
                                            } else {
                                              resolve()
                                            }
                                          })
                                        })

                                        req.app.routes.eventUtil.save(req, mongo, 'statusChange', 'attended', attac.reference, '', 'note', () => {
                                          resolve(result)
                                        })
                                      } else {
                                        resolve()
                                      }
                                    })
                                  })
                                }
                                if (noti) {
                                  await new Promise(resolve => {
                                    mongo.save('notification', noti, (err, result) => {
                                      resolve(result)
                                    })
                                  })
                                  // email notification
                                  await new Promise(resolve => {
                                    doc.type = 'commitment'
                                    req.query.someone = true
                                    notification.notify(req, doc, mongo, send)
                                    resolve()
                                  })
                                  if (noti.actors && noti.actors[0]) {
                                    notification.send(req, req.session.context.room, 'badgeNotification', null, [noti.actors[0].user], null)
                                    notification.pushNotification(req, doc, noti, [noti.actors[0].user])
                                  }
                                }
                                if (!req.body.completedComm) {
                                  send({
                                    message: tags.savedChanges,
                                    doc: doc
                                  })
                                } else {
                                  return
                                }
                                notification.send(req, req.session.context.room, 'dtAttached', null, null, null)
                                notification.send(req, req.session.context.room, 'KanbanCommitment', null, null, null)
                              }
                            })
                          }
                        })
                      })
                    }
                  })
                })
              } else {
                send({
                  error: 'error al guardar compromiso'
                })
              }
            }
          })
        }
      }
    })
  }

  this.list = async function (req, mongo, send) {
    var skip = req.query.filter && req.query.filter.tagsname !== '' ? 0 : parseInt(req.query.start) || 0
    var limit = req.query.filter && req.query.filter.tagsname !== '' ? 200 : parseInt(req.query.count) || 50
    var reply = {
      data: [],
      pos: skip
    }
    var keys = await this.$keys(req, mongo)
    //for this query
    var myUnits
    if (req.session.context.licensedUser === false) {
      myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits)
    } else {
      myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits).concat(req.session.context.memberUnits)
    }
    let risk = false
    if (!req.query.filter || (req.query.filter && !req.query.filter.status)) {
      keys.status = {
        $nin: ['done', 'completed', 'incomplete', 'annulled']
      }
    } else {
      keys.status = {
        $ne: 'annulled'
      }
    }
    if (req.query.onlydefeated === 'true') {
      keys.$and = [{
        dates: {
          $elemMatch: {
            value: {
              $lte: new Date()
            },
            type: 'deadline'
          }
        }
      },
      {
        status: {
          $in: ['ready', 'accepted']
        }
      }
      ]
    }
    if (req.query.onlyunexpired === 'true') {
      keys.$and = [{
        dates: {
          $elemMatch: {
            value: {
              $gte: new Date()
            },
            type: 'deadline'
          }
        }
      },
      {
        status: {
          $in: ['ready', 'accepted']
        }
      }
      ]
    }
    if (req.query.filter) {
      var query = []
      const filter = req.query.filter
      if (filter.responsibleName) {
        query.push({
          actors: {
            $elemMatch: {
              role: 'responsible',
              user: mongo.toId(filter.responsibleName)
            }
          }
        })
      }
      if (filter.responsibleUnit) {
        var dependents = await req.app.routes.note.$unitDependents(mongo, mongo.toId(filter.responsibleUnit))
        query.push({
          actors: {
            $elemMatch: {
              role: 'responsible',
              unit: {
                $in: dependents
              }
            }
          }
        })
      }
      if (filter.reviserCommitment) {
        query.push({
          actors: {
            $elemMatch: {
              user: mongo.toId(filter.reviserCommitment),
              path: 'sent'
            }
          }
        })
      }
      if (filter.reviserUnit) {
        query.push({
          $or: [{
            actors: {
              $elemMatch: {
                unit: mongo.toId(filter.reviserUnit),
                role: 'from'
              }
            }
          }, {
            actors: {
              $elemMatch: {
                unit: mongo.toId(filter.reviserUnit),
                role: 'reviser'
              }
            }
          }, {
            actors: {
              $elemMatch: {
                unit: mongo.toId(filter.reviserUnit),
                supervisor: '1'
              }
            }
          }]
        })
      }
      if (filter.name) {
        let text = new RegExp(filter.name, 'i')
        query.push({
          $or: [{
            name: text
          }, {
            'sequence.text': text
          }]
        })
      }
      if (filter.tagsname) {
        let arrayTags = filter.tagsname.split(',')
        for (let i in arrayTags) {
          arrayTags[i] = mongo.toId(arrayTags[i])
        }
        query.push({
          tags: {
            $in: arrayTags
          }
        })
      }
      if (filter.status && filter.status !== 'all') {
        query.push({
          status: filter.status
        })
      }
      if (filter.deadline) {
        if (filter.deadline.start && !filter.deadline.end) {
          query.push({
            $and: [{
              dates: {
                $elemMatch: {
                  value: {
                    $gte: filter.deadline.start
                  },
                  type: 'deadline'
                }
              }
            },
            {
              status: {
                $in: ['ready', 'accepted']
              }
            }
            ]
          })
        } else if (filter.deadline.start && filter.deadline.end) {
          query.push({
            $and: [{
              dates: {
                $elemMatch: {
                  value: {
                    $gte: filter.deadline.start
                  },
                  type: 'deadline'
                }
              }
            },
            {
              dates: {
                $elemMatch: {
                  value: {
                    $lte: filter.deadline.end
                  },
                  type: 'deadline'
                }
              }
            },
            {
              status: {
                $in: ['ready', 'accepted']
              }
            }
            ]
          })
        }
      }
      if (query.length) {
        query.push(keys)
        keys = {
          $and: query
        }
      }
    }
    var sort
    if (req.query.sort) {
      for (const name in req.query.sort) {
        if (req.query.sort[name].length > 0) {
          if (name === 'eCount') {
            sort = req.query.sort[name] === 'asc' ? {
              'eCount': 1
            } : {
              'eCount': -1
            }
          }
        }
      }
    }
    mongo.toHash('user', {}, (err, users) => {
      if (err) console.log(err)
      mongo.toHash('unit', {}, (err, units) => {
        if (err) console.log(err)

        var tagsDoc = []
        mongo.find('params', {
          name: {
            $in: ['riskLevel']
          }
        }, {
          _id: 1,
          name: 1,
          options: 1
        }, (err, tgsDs) => {
          if (err) console.log(err)
          if (tgsDs.length > 0) {
            for (var i in tgsDs) {
              tagsDoc = tagsDoc.concat(tgsDs[i].options)
            }
          }

          mongo.aggregate('commitment', [{
            $lookup: {
              from: 'attached',
              localField: 'reference',
              foreignField: '_id',
              as: 'att'
            }
          },
          {
            $unwind: '$att'
          },
          {
            $lookup: {
              from: 'note',
              localField: 'att.reference',
              foreignField: '_id',
              as: 'note'
            }
          },
          {
            $unwind: '$note'
          },
          {
            $addFields: {
              actor: {
                $filter: {
                  input: '$actors',
                  as: 'actor',
                  cond: {
                    $eq: ['$$actor.role', 'responsible']
                  }
                }
              }
            }
          },
          {
            $lookup: {
              from: 'unit',
              localField: 'actor.unit',
              foreignField: '_id',
              as: 'unit'
            }
          },
          {
            $addFields: {
              sequence: '$note.sequence',
              confidential: '$note.confidential',
              noteStatus: '$note.status',
              actors: '$att.actors',
              tags: '$att.tags',
              offline: {
                $arrayElemAt: [{
                  $ifNull: ['$unit.offline', [false]]
                }, 0]
              }
            }
          },
          {
            $addFields: {
              isShow: {
                $function: {
                  body: `function (offline, status, actors, user) {
                      if (status === 'draft') {
                        for (let a in actors) {
                          let act = actors[a]
                          if ((hex_md5(user.toString()) === hex_md5(act.user.toString())) && offline && (act.role === 'from' || act.role === 'reviser' || act.role === 'supervisor') && (act.path === 'sent')) {
                            return true
                          }
                          if ((hex_md5(user.toString()) === hex_md5(act.user.toString())) && act.role === 'responsible') {
                            return true
                          }
                        }
                      } else {
                        return true
                      }
                    }`,
                  args: ['$offline', '$status', '$actors', req.session.context.user],
                  lang: 'js'
                }
              }
            }
          },
          {
            $match: keys
          },
          {
            $match: {
              $or: [{
                isShow: true
              }, {
                actors: {
                  $elemMatch: {
                    unit: {
                      $in: myUnits
                    },
                    path: {
                      $ne: 'hidden'
                    }
                  }
                }
              }]
            }
          },
          {
            $lookup: {
              from: 'evidence',
              let: {
                find: '$_id'
              },
              pipeline: [{
                $match: {
                  $expr: {
                    $and: [{
                      $eq: ['$reference', '$$find']
                    }]
                  }
                }
              },
              {
                $count: 'count'
              }
              ],
              as: 'eCount'
            }
          },
          {
            $unwind: {
              path: '$eCount',
              preserveNullAndEmptyArrays: true
            }
          },
          {
            $project: {
              _id: 1,
              actors: 1,
              dates: 1,
              sequence: '$sequence',
              template: 1,
              status: 1,
              name: 1,
              tags: '$att.tags',
              eCount: {
                $ifNull: ['$eCount.count', 0]
              }
            }
          },
          {
            $sort: sort || {
              _id: -1
            }
          }, {
            $skip: skip
          }, {
            $limit: limit
          }
          ], {}, async (err, commitments) => {
            if (err) console.log(err)
            if (err) {
              throw err
            } else if (commitments.length > 0) {
              for (var i in commitments) {
                let responsible
                const revisers = []
                const reviserUnit = []
                for (var a in commitments[i].actors) {
                  commitments[i].id = commitments[i]._id
                  if (commitments[i].actors[a].role === 'responsible') {
                    responsible = commitments[i].actors[a]
                  } else if ((commitments[i].actors[a].path === 'sent' || commitments[i].actors[a].supervisor === '1') && revisers.findIndex((x) => {
                    return x.user.toString() === commitments[i].actors[a].user.toString()
                  }) === -1) {
                    commitments[i].actors[a].name = users[commitments[i].actors[a].user] ? users[commitments[i].actors[a].user].name : ''
                    revisers.push(commitments[i].actors[a])
                    reviserUnit.push({
                      unit: commitments[i].actors[a].unit,
                      name: units[commitments[i].actors[a].unit] ? units[commitments[i].actors[a].unit].name : ''
                    })
                  }
                }
                commitments[i].reviser = revisers
                commitments[i].reviserUnit = reviserUnit
                let deadline
                if (responsible) {
                  commitments[i].responsibleId = responsible.user.toString()
                  commitments[i].responsibleName = users[responsible.user.toString()] ? users[responsible.user.toString()].name : ''
                  commitments[i].responsibleUnit = responsible.unit && units[responsible.unit.toString()] ? units[responsible.unit.toString()].name : ''
                }
                for (var x in commitments[i].dates) {
                  if (commitments[i].dates[x].type === 'deadline') {
                    deadline = commitments[i].dates[x]
                  }
                }
                commitments[i].deadline = deadline ? dateformat(new Date(deadline.value), 'yyyy/mm/dd') : ''
                commitments[i].expired = !['done', 'incomplete', 'canceled'].includes(commitments[i].status) && deadline && deadline.value && deadline.value.getTime() <= new Date().getTime() ? tags.expired : undefined
                var tagFoundId = commitments[i].tags
                for (var t in tagsDoc) {
                  if (tagFoundId && tagFoundId.length > 0 && tagFoundId[0].toString() === tagsDoc[t].id.toString()) {
                    commitments[i].tagsname = tagsDoc[t].value
                    commitments[i].tagscolor = tagsDoc[t].color
                    break
                  }
                }
                if (commitments[i].sequence && commitments[i].sequence.text !== '') {
                  commitments[i].name = '<b>[' + commitments[i].sequence.text + ']</b> ' + commitments[i].name
                }

                commitments[i].type2 = await new Promise(resolve => {
                  mongo.findId('template', commitments[i].template, { type: 1 }, (err, d) => {
                    if (err || !d) resolve('')
                    else resolve(d.type)
                  })
                })

                delete commitments[i].actors
                delete commitments[i].dates
                delete commitments[i].tags
              }
              if (risk) {
                let name = ''
                const array = []
                for (const t in tagsDoc) {
                  if (risk === tagsDoc[t].id.toString()) {
                    name = tagsDoc[t].value
                    break
                  }
                }
                for (const i in commitments) {
                  if (commitments[i].tagsname === name) {
                    array.push(commitments[i])
                  }
                }
                commitments = array
              }
              reply.data = commitments
              if (skip) {
                send(reply)
              } else {
                mongo.aggregate('commitment', [{
                  $lookup: {
                    from: 'attached',
                    localField: 'reference',
                    foreignField: '_id',
                    as: 'att'
                  }
                },
                {
                  $unwind: '$att'
                },
                {
                  $lookup: {
                    from: 'note',
                    localField: 'att.reference',
                    foreignField: '_id',
                    as: 'note'
                  }
                },
                {
                  $unwind: '$note'
                },
                {
                  $addFields: {
                    actor: {
                      $filter: {
                        input: '$actors',
                        as: 'actor',
                        cond: {
                          $eq: ['$$actor.role', 'responsible']
                        }
                      }
                    }
                  }
                },
                {
                  $lookup: {
                    from: 'unit',
                    localField: 'actor.unit',
                    foreignField: '_id',
                    as: 'unit'
                  }
                },
                {
                  $addFields: {
                    sequence: '$note.sequence',
                    confidential: '$note.confidential',
                    noteStatus: '$note.status',
                    actors: '$att.actors',
                    tags: '$att.tags',
                    offline: {
                      $arrayElemAt: [{
                        $ifNull: ['$unit.offline', [false]]
                      }, 0]
                    }
                  }
                },
                {
                  $addFields: {
                    isShow: {
                      $function: {
                        body: `function (offline, status, actors, user) {
                            if (status === 'draft') {
                              for (let a in actors) {
                                let act = actors[a]
                                if ((hex_md5(user.toString()) === hex_md5(act.user.toString())) && offline && (act.role === 'from' || act.role === 'reviser' || act.role === 'supervisor') && (act.path === 'sent')) {
                                  return true
                                }
                                if ((hex_md5(user.toString()) === hex_md5(act.user.toString())) && act.role === 'responsible') {
                                  return true
                                }
                              }
                            } else {
                              return true
                            }
                          }`,
                        args: ['$offline', '$status', '$actors', req.session.context.user],
                        lang: 'js'
                      }
                    }
                  }
                },
                {
                  $match: keys
                },
                {
                  $match: {
                    $or: [{
                      isShow: true
                    }, {
                      actors: {
                        $elemMatch: {
                          unit: {
                            $in: myUnits
                          },
                          path: {
                            $ne: 'hidden'
                          }
                        }
                      }
                    }]
                  }
                },
                {
                  $group: {
                    _id: '',
                    count: {
                      $sum: 1
                    }
                  }
                }
                ], {}, (err, result) => {
                  if (err) {
                    send(err)
                  } else {
                    reply.total_count = result.length ? result[0].count : 0
                    send(reply)
                  }
                })
              }
            } else {
              send([])
            }
          })
        })
      })
    })
  }

  this.getReviewers = function (req, mongo, send) {
    mongo.findId('commitment', req.query._id, {}, (err, document) => {
      if (err) throw err
      var users = []
      var units = []

      var data = []
      if (document) {
        for (const a in document.actors) {
          if (document.actors[a]) {
            var actor = document.actors[a]
            users.push(actor.user)
            units.push(actor.unit)
          }
        }
        mongo.toHash('user', {
          _id: {
            $in: users
          }
        }, {
          _id: 1,
          name: 1
        }, (er, users) => {
          mongo.toHash('unit', {
            _id: {
              $in: units
            }
          }, {
            _id: 1,
            name: 1
          }, (_er, units) => {
            for (const a in document.actors) {
              if (document.actors[a]) {
                var dataactor = document.actors[a]
                data.push({
                  id: dataactor.user,
                  name: dataactor.user ? users[dataactor.user.toString()].name : null,
                  path: dataactor.path,
                  role: dataactor.role,
                  unit: dataactor.unit,
                  unitName: dataactor.unit ? units[dataactor.unit.toString()] ? units[dataactor.unit.toString()].name : '' : null,
                  supervisor: dataactor.supervisor
                })
              }
            }
            send(data)
          })
        })
      }
    })
  }

  this.slopes = async function (req, mongo, send) {
    var data = []
    var scalableSequences = await new Promise(resolve => {
      mongo.find('sequence', {
        scalable: true
      }, (err, seqs) => {
        if (err) console.log(err)
        var ids = []
        if (seqs) {
          for (let s in seqs) {
            ids.push(seqs[s]._id)
          }
        }
        resolve(ids)
      })
    })
    var myAndDependentUnits = req.session.context.dependentUnits.concat(req.session.context.managerUnits.concat(req.session.context.assistantUnits))
    var keys = {}
    if (req.session.context.licensedUser === false) {
      keys = {
        $or: [{
          $and: [{
            actors: {
              $elemMatch: {
                user: req.session.context.user,
                role: 'inCharge'
              }
            }
          }]
        },
        {
          actors: {
            $elemMatch: {
              unit: {
                $in: myAndDependentUnits
              },
              path: {
                $ne: 'hidden'
              }
            }
          },
          'sequence.sequence': {
            $in: scalableSequences
          },
        }
        ]
      }
    } else {
      /* keys = {
                    $or: [
                      { actors: { $elemMatch: { user: req.session.context.user, path: { $ne: 'hidden' } } } },
                      { actors: { $elemMatch: { unit: { $in: units }, path: { $ne: 'hidden' } } } }
                    ]
                  } */
      keys = {
        $and: [{
          $or: [
            // users in the note & unrestricted
            {
              actors: {
                $elemMatch: {
                  user: req.session.context.user,
                  path: {
                    $ne: 'hidden'
                  }
                }
              }
            },
            // assistant in one unit of note & unrestricted
            {
              actors: {
                $elemMatch: {
                  unit: {
                    $in: req.session.context.assistantUnits
                  },
                  path: {
                    $ne: 'hidden'
                  }
                }
              }
            },
            // manager or assistant of ascending unit, un restricted, scalable, non-confidential and not in draft
            {
              actors: {
                $elemMatch: {
                  unit: {
                    $in: myAndDependentUnits
                  },
                  path: {
                    $ne: 'hidden'
                  }
                }
              },
              'sequence.sequence': {
                $in: scalableSequences
              }
            }
          ]
        }]
      }
    }
    var query = {
      status: {
        $nin: ['draft', 'done', 'incomplete', 'canceled']
      }
    }
    let risk = false
    mongo.toHash('user', {}, (err, users) => {
      if (err) console.log(err)
      mongo.toHash('unit', {}, (err, units) => {
        if (err) console.log(err)

        var tagsDoc = []
        mongo.find('params', {
          name: {
            $in: ['riskLevel']
          }
        }, {
          _id: 1,
          name: 1,
          options: 1
        }, (err, tgsDs) => {
          if (err) console.log(err)
          if (tgsDs.length > 0) {
            for (var i in tgsDs) {
              tagsDoc = tagsDoc.concat(tgsDs[i].options)
            }
          }

          mongo.aggregate('commitment', [{
            $match: {
              $and: [keys, query]
            }
          },
          {
            $lookup: {
              from: 'attached',
              localField: 'reference',
              foreignField: '_id',
              as: 'att'
            }
          },
          {
            $unwind: '$att'
          },
          {
            $addFields: {
              sequenceAtta: '$att.sequence',
            }
          },
          {
            $project: {
              _id: 1,
              actors: 1,
              dates: 1,
              sequence: '$sequenceAtta',
              status: 1,
              name: 1,
              tags: '$att.tags',
              att: 1
            }
          }
          ], {}, async (err, commitments) => {
            if (err) console.log(err)
            if (err) {
              throw err
            } else if (commitments.length > 0) {
              for (var i in commitments) {
                let responsible
                for (var a in commitments[i].actors) {
                  commitments[i].id = commitments[i]._id
                  if (commitments[i].actors[a].role === 'inCharge') {
                    responsible = commitments[i].actors[a]
                  }
                }
                let deadline
                if (responsible) {
                  commitments[i].responsible = responsible.user.toString()
                  commitments[i].responsibleName = users[responsible.user.toString()] ? users[responsible.user.toString()].name : ''
                  commitments[i].responsibleUnitName = units[responsible.unit.toString()] ? units[responsible.unit.toString()].name : ''
                  commitments[i].responsibleUnit = responsible.unit.toString()
                }
                for (var x in commitments[i].dates) {
                  if (commitments[i].dates[x].type === 'deadline') {
                    deadline = commitments[i].dates[x]
                  }
                }
                commitments[i].deadline = deadline ? dateformat(new Date(deadline.value), 'yyyy/mm/dd') : ''
                commitments[i].expired = !['done', 'incomplete', 'canceled'].includes(commitments[i].status) && deadline && deadline.value && deadline.value.getTime() <= new Date().getTime() ? tags.expired : undefined
                var tagFoundId = commitments[i].tags
                for (var t in tagsDoc) {
                  if (tagFoundId && tagFoundId.length > 0 && tagFoundId[0].toString() === tagsDoc[t].id.toString()) {
                    commitments[i].tagsname = tagsDoc[t].value
                    commitments[i].tagscolor = tagsDoc[t].color
                    break
                  }
                }
                if (commitments[i].sequence && commitments[i].sequence.text !== '') {
                  commitments[i].name = '<b>[' + commitments[i].sequence.text + ']</b> ' + commitments[i].name
                }

                delete commitments[i].actors
                delete commitments[i].dates
                delete commitments[i].tags
              }

              if (risk) {
                let name = ''
                const array = []
                for (const t in tagsDoc) {
                  if (risk === tagsDoc[t].id.toString()) {
                    name = tagsDoc[t].value
                    break
                  }
                }
                for (const i in commitments) {
                  if (commitments[i].tagsname === name) {
                    array.push(commitments[i])
                  }
                }
                commitments = array
              }
              if (req.session.context.licensedUser === false) {
                keys = {
                  $and: [{
                    status: 'processing',
                    requiredResponse: '1'
                  },
                  {
                    $or: [{
                      $and: [{
                        actors: {
                          $elemMatch: {
                            user: req.session.context.user,
                            path: {
                              $ne: 'hidden'
                            }
                          }
                        }
                      },
                      {
                        $and: [{
                          responsible: {
                            $ne: ''
                          }
                        }, {
                          responsible: {
                            $exists: true
                          }
                        }]
                      },
                      {
                        responsible: new RegExp(req.session.context.user.toString(), 'i')
                      }
                      ]
                    },
                    {
                      actors: {
                        $elemMatch: {
                          unit: {
                            $in: myAndDependentUnits
                          },
                          path: {
                            $ne: 'hidden'
                          }
                        }
                      },
                      'sequence.sequence': {
                        $in: scalableSequences
                      },
                    }
                    ]
                  }
                  ]
                }
              } else {
                keys = {
                  $and: [{
                    status: 'processing',
                    requiredResponse: '1'
                  },
                  {
                    $or: [
                      // users in the note & unrestricted
                      {
                        actors: {
                          $elemMatch: {
                            user: req.session.context.user,
                            path: {
                              $ne: 'hidden'
                            }
                          }
                        }
                      },
                      // assistant in one unit of note & unrestricted
                      {
                        actors: {
                          $elemMatch: {
                            unit: {
                              $in: req.session.context.assistantUnits
                            },
                            path: {
                              $ne: 'hidden'
                            }
                          }
                        }
                      },
                      {
                        actors: {
                          $elemMatch: {
                            unit: {
                              $in: myAndDependentUnits
                            },
                            path: {
                              $ne: 'hidden'
                            }
                          }
                        },
                        'sequence.sequence': {
                          $in: scalableSequences
                        }
                      }
                    ]
                  }
                  ]
                }
              }
              var attacheds = await new Promise(resolve => {
                mongo.aggregate('attached', [{
                  $match: {
                    $and: [keys, query]
                  }
                },
                {
                  $project: {
                    _id: 1,
                    status: 1,
                    name: 1,
                    requiredResponse: 1,
                    responsible: 1
                  }
                }
                ], {}, async (err, attacheds) => {
                  if (err) resolve(false)
                  resolve(attacheds)
                })
              })
              for (let c in commitments) {
                let commitment = commitments[c]
                let unitResposible = commitment.responsibleUnit
                if (!data[unitResposible.toString()]) {
                  data[unitResposible.toString()] = {
                    id: unitResposible.toString(),
                    name: units[unitResposible.toString()] ? units[unitResposible.toString()].name : '',
                    commitments: 1,
                    attacheds: 0
                  }
                } else {
                  data[unitResposible.toString()].commitments = data[unitResposible.toString()].commitments + 1
                }
              }
              for (let a in attacheds) {
                let attached = attacheds[a]
                let unitResposible = attached.responsible ? attached.responsible.split('&unit=')[1] : false
                if (unitResposible && !data[unitResposible.toString()]) {
                  data[unitResposible.toString()] = {
                    id: unitResposible.toString(),
                    name: units[unitResposible.toString()] ? units[unitResposible.toString()].name : '',
                    commitments: 0,
                    attacheds: 1
                  }
                } else if (unitResposible) {
                  data[unitResposible.toString()].attacheds = data[unitResposible.toString()].attacheds + 1
                }
              }
              var res = []
              for (const d in data) {
                res.push(data[d])
              }
              send(res)
            } else {
              send([])
            }
          })
        })
      })
    })
  }

  this.slopeUnit = async function (req, mongo, send) {
    var data = []
    var scalableSequences = await new Promise(resolve => {
      mongo.find('sequence', {
        scalable: true
      }, (err, seqs) => {
        if (err) console.log(err)
        var ids = []
        if (seqs) {
          for (let s in seqs) {
            ids.push(seqs[s]._id)
          }
        }
        resolve(ids)
      })
    })
    var unit = mongo.toId(req.query._id)
    var myAndDependentUnits = req.session.context.dependentUnits.concat(req.session.context.managerUnits.concat(req.session.context.assistantUnits))
    var keys = {}
    if (req.session.context.licensedUser === false) {
      keys = {
        $or: [{
          $and: [{
            actors: {
              $elemMatch: {
                user: req.session.context.user,
                role: 'inCharge'
              }
            }
          }]
        },
        {
          actors: {
            $elemMatch: {
              unit: {
                $in: myAndDependentUnits
              },
              path: {
                $ne: 'hidden'
              }
            }
          },
          'sequence.sequence': {
            $in: scalableSequences
          },
        }
        ]
      }
    } else {
      keys = {
        $and: [{
          $or: [
            // users in the note & unrestricted
            {
              actors: {
                $elemMatch: {
                  user: req.session.context.user,
                  path: {
                    $ne: 'hidden'
                  }
                }
              }
            },
            // assistant in one unit of note & unrestricted
            {
              actors: {
                $elemMatch: {
                  unit: {
                    $in: req.session.context.assistantUnits
                  },
                  path: {
                    $ne: 'hidden'
                  }
                }
              }
            },
            // manager or assistant of ascending unit, un restricted, scalable, non-confidential and not in draft
            {
              actors: {
                $elemMatch: {
                  unit: {
                    $in: myAndDependentUnits
                  },
                  path: {
                    $ne: 'hidden'
                  }
                }
              },
              'sequence.sequence': {
                $in: scalableSequences
              }
            }
          ]
        }]
      }
    }
    var query = {
      status: {
        $nin: ['draft', 'done', 'incomplete', 'canceled']
      }
    }
    let risk = false
    mongo.toHash('user', {}, (err, users) => {
      if (err) console.log(err)
      mongo.toHash('unit', {}, (err, units) => {
        if (err) console.log(err)

        var tagsDoc = []
        mongo.find('params', {
          name: {
            $in: ['riskLevel']
          }
        }, {
          _id: 1,
          name: 1,
          options: 1
        }, (err, tgsDs) => {
          if (err) console.log(err)
          if (tgsDs.length > 0) {
            for (var i in tgsDs) {
              tagsDoc = tagsDoc.concat(tgsDs[i].options)
            }
          }

          mongo.aggregate('commitment', [{
            $match: {
              $and: [keys, query]
            }
          },
          {
            $lookup: {
              from: 'attached',
              localField: 'reference',
              foreignField: '_id',
              as: 'att'
            }
          },
          {
            $unwind: '$att'
          },
          {
            $addFields: {
              sequenceAtta: '$att.sequence',
            }
          },
          {
            $match: {
              actors: {
                $elemMatch: {
                  unit: unit,
                  role: 'inCharge'
                }
              }
            }
          },
          {
            $project: {
              _id: 1,
              actors: 1,
              dates: 1,
              sequence: '$sequenceAtta',
              status: 1,
              name: 1,
              tags: '$att.tags',
              att: 1
            }
          }
          ], {}, async (err, commitments) => {
            if (err) console.log(err)
            if (err) {
              throw err
            }
            for (var i in commitments) {
              let responsible
              commitments[i].commitment = true

              for (var a in commitments[i].actors) {
                commitments[i].id = commitments[i]._id
                if (commitments[i].actors[a].role === 'inCharge') {
                  responsible = commitments[i].actors[a]
                }
              }
              let deadline
              if (responsible) {
                commitments[i].responsible = responsible.user.toString()
                commitments[i].responsibleName = users[responsible.user.toString()] ? users[responsible.user.toString()].name : ''
                commitments[i].responsibleUnitName = units[responsible.unit.toString()] ? units[responsible.unit.toString()].name : ''
                commitments[i].responsibleUnit = responsible.unit.toString()
              }
              for (var x in commitments[i].dates) {
                if (commitments[i].dates[x].type === 'deadline') {
                  deadline = commitments[i].dates[x]
                }
              }
              commitments[i].deadline = deadline ? dateformat(new Date(deadline.value), 'yyyy/mm/dd') : ''
              commitments[i].expired = !['done', 'incomplete', 'canceled'].includes(commitments[i].status) && deadline && deadline.value && deadline.value.getTime() <= new Date().getTime() ? tags.expired : undefined
              var tagFoundId = commitments[i].tags
              for (var t in tagsDoc) {
                if (tagFoundId && tagFoundId.length > 0 && tagFoundId[0].toString() === tagsDoc[t].id.toString()) {
                  commitments[i].tagsname = tagsDoc[t].value
                  commitments[i].tagscolor = tagsDoc[t].color
                  break
                }
              }
              if (commitments[i].sequence && commitments[i].sequence.text !== '') {
                commitments[i].name = '<b>[' + commitments[i].sequence.text + ']</b> ' + commitments[i].name
              }

              delete commitments[i].actors
              delete commitments[i].dates
              delete commitments[i].tags
            }

            if (risk) {
              let name = ''
              const array = []
              for (const t in tagsDoc) {
                if (risk === tagsDoc[t].id.toString()) {
                  name = tagsDoc[t].value
                  break
                }
              }
              for (const i in commitments) {
                if (commitments[i].tagsname === name) {
                  array.push(commitments[i])
                }
              }
              commitments = array
            }
            if (req.session.context.licensedUser === false) {
              keys = {
                $and: [{
                  status: 'processing',
                  requiredResponse: '1'
                },
                {
                  $or: [{
                    $and: [{
                      actors: {
                        $elemMatch: {
                          user: req.session.context.user,
                          path: {
                            $ne: 'hidden'
                          }
                        }
                      }
                    },
                    {
                      $and: [{
                        responsible: {
                          $ne: ''
                        }
                      }, {
                        responsible: {
                          $exists: true
                        }
                      }]
                    },
                    {
                      responsible: new RegExp(req.session.context.user.toString(), 'i')
                    }
                    ]
                  },
                  {
                    actors: {
                      $elemMatch: {
                        unit: {
                          $in: myAndDependentUnits
                        },
                        path: {
                          $ne: 'hidden'
                        }
                      }
                    },
                    'sequence.sequence': {
                      $in: scalableSequences
                    },
                  }
                  ]
                }
                ]
              }
            } else {
              keys = {
                $and: [{
                  status: 'processing',
                  requiredResponse: '1'
                },
                {
                  $or: [
                    // users in the note & unrestricted
                    {
                      actors: {
                        $elemMatch: {
                          user: req.session.context.user,
                          path: {
                            $ne: 'hidden'
                          }
                        }
                      }
                    },
                    // assistant in one unit of note & unrestricted
                    {
                      actors: {
                        $elemMatch: {
                          unit: {
                            $in: req.session.context.assistantUnits
                          },
                          path: {
                            $ne: 'hidden'
                          }
                        }
                      }
                    },
                    {
                      actors: {
                        $elemMatch: {
                          unit: {
                            $in: myAndDependentUnits
                          },
                          path: {
                            $ne: 'hidden'
                          }
                        }
                      },
                      'sequence.sequence': {
                        $in: scalableSequences
                      }
                    }
                  ]
                }
                ]
              }
            }
            var attacheds = await new Promise(resolve => {
              mongo.aggregate('attached', [{
                $match: {
                  $and: [keys, query]
                }
              },
              {
                $match: {
                  responsible: new RegExp(unit.toString(), 'i')
                }
              },
              {
                $project: {
                  _id: 1,
                  actors: 1,
                  dates: 1,
                  tags: 1,
                  responsible: 1,
                  sequence: 1,
                  status: 1,
                  name: 1
                }
              }
              ], {}, async (err, attacheds) => {
                if (err) resolve(false)
                resolve(attacheds)
              })
            })
            for (let i in attacheds) {
              attacheds[i].attached = true
              var deadline = {}
              for (const x in attacheds[i].dates) {
                if (attacheds[i].dates[x].type === 'deadline') {
                  deadline = attacheds[i].dates[x]
                }
              }
              attacheds[i].expired = !['completed'].includes(attacheds[i].status) && deadline.value && deadline.value.getTime() <= new Date().getTime() ? tags.expired : undefined
              const revisers = []
              const reviserUnit = []
              let responsible = ['', '']
              if (attacheds[i].responsible) {
                responsible = attacheds[i].responsible.split('&unit=')
                attacheds[i].responsibleId = responsible[0]
                attacheds[i].responsibleName = users[responsible[0]] ? users[responsible[0]].name : ''
                attacheds[i].responsibleUnit = units[responsible[1]] ? units[responsible[1]].name : ''
              }
              for (let a in attacheds[i].actors) {
                attacheds[i].id = attacheds[i]._id
                if (!responsible && attacheds[i].actors[a].role === 'inCharge') {
                  responsible = [attacheds[i].actors[a].user.toString(), attacheds[i].actors[a].unit.toString()]
                } else if ((attacheds[i].actors[a].path === 'sent' || attacheds[i].actors[a].supervisor === '1') && revisers.findIndex((x) => {
                  return x.user.toString() === attacheds[i].actors[a].user.toString()
                }) === -1) {
                  attacheds[i].actors[a].name = users[attacheds[i].actors[a].user] ? users[attacheds[i].actors[a].user].name : ''
                  revisers.push(attacheds[i].actors[a])
                  reviserUnit.push({
                    unit: attacheds[i].actors[a].unit,
                    name: units[attacheds[i].actors[a].unit] ? units[attacheds[i].actors[a].unit].name : ''
                  })
                }
              }
              attacheds[i].reviser = revisers
              attacheds[i].reviserUnit = reviserUnit
              let d = -1
              if (attacheds[i].dates) {
                d = attacheds[i].dates.findIndex((x) => {
                  return x.type === 'deadline'
                })
              }
              if (d !== -1) {
                attacheds[i].deadline = dateformat(new Date(attacheds[i].dates[d].value), 'yyyy/mm/dd')
              } else {
                attacheds[i].deadline = ''
              }
              tagFoundId = attacheds[i].tags
              for (let t in tagsDoc) {
                if (tagFoundId && tagFoundId.toString() === tagsDoc[t].id.toString()) {
                  attacheds[i].tagsname = tagsDoc[t].value
                  attacheds[i].tagscolor = tagsDoc[t].color
                }
              }
              if (attacheds[i].sequence && attacheds[i].sequence.text !== '') {
                attacheds[i].name = '<b>[' + attacheds[i].sequence.text + ']</b> ' + attacheds[i].name
              }
              delete attacheds[i].sequence
              delete attacheds[i].content
              delete attacheds[i].reference
              delete attacheds[i].project
              delete attacheds[i].task
              delete attacheds[i].actors
              delete attacheds[i].dates
            }
            data = data.concat(commitments.concat(attacheds))
            send(data)
          })
        })
      })
    })
  }

  this.row = function (doc, req, actor, users, usedTags) {
    var issue = {}

    var deadline = {}
    for (const x in doc.dates) {
      if (doc.dates[x].type === 'issue') {
        issue = doc.dates[x]
      } else if (doc.dates[x].type === 'deadline') {
        deadline = doc.dates[x]
      }
    }
    var attachments = 'none'
    if (doc.files && doc.files.length > 0) {
      for (const x in doc.files) {
        if (doc.files[x]) {
          attachments = 'attachment'
        }
      }
    }
    const expired = doc.status === tags.processing && deadline.value && deadline.value.getTime() <= new Date().getTime() ? tags.expired : undefined
    var tagscolor = []
    var tagsname = []
    var filterNames = [usedTags[0] ? usedTags[0].value : '']
    for (const i in usedTags) {
      tagscolor.push(usedTags[i].color)
      tagsname.push(usedTags[i].value)
    }
    var row = {
      id: doc._id.toString(),
      attachments: attachments,
      expired: expired,
      css: expired || doc.status || tags.processing,
      status: doc.status ? doc.status : tags.processing,
      statusName: doc.status,
      role: actor.role,
      user: actor.user ? actor.user : doc.user,
      sequence: doc.sequence && doc.sequence.text ? doc.sequence.text : '',
      name: doc.name,
      path: actor.path,
      pathName: actor.path,
      issue: issue.value ? tags.util.date2str(issue.value, 'yyyy/mm/dd', tags) : '',
      category: doc.category || '',
      deadline: deadline.value ? tags.util.date2str(deadline.value, 'yyyy/mm/dd', tags) : '',
      tagscolor: tagscolor,
      tagsname: tagsname,
      filterNames: filterNames,
      archived: doc.status && doc.status === 'archived' ? 'archived' : '',
      issued: doc.issued,
      content: doc.content,
      actors: doc.actors,
      icon: 'none'
    }
    if (doc.type) {
      row.type = doc.type
    }
    if (doc.task) {
      row.task = doc.task
    }
    if (doc.reference) {
      row.reference = doc.reference
      row.icon = 'attached'
    }
    if (doc.commitment) {
      row.commitment = doc.commitment
      row.icon = 'folder-clock-outline'
    }
    if (doc.evidence) {
      row.evidence = doc.evidence
      row.icon = 'evidence'
    }
    if (doc.actors) {
      for (let i in doc.actors) {
        if (doc.actors[i].role === 'responsible') {
          const user = doc.actors[i].user
          row.responsible = {
            id: user,
            name: users[user] ? users[user].name : ''
          }
          break
        }
      }
    }
    return row
  }

  this.delete = function (req, mongo, send) {
    const doc = req.query
    mongo.findId('commitment', mongo.toId(doc._id), (err, commitment) => {
      if (err) {
        send({
          error: err
        })
      } else {
        mongo.deleteOne('commitment', {
          _id: mongo.toId(doc._id)
        }, (err) => {
          if (err) {
            req.logger.log(err)
          } else {
            mongo.save('attached', {
              _id: mongo.toId(commitment.reference),
              answered: '0',
              status: 'processing'
            }, (err) => {
              if (err) {
                req.logger.log(err)
              } else {
                req.app.routes.trash.insert(req, mongo, 'commitment', commitment, () => {
                  send({})
                })
              }
            })
          }
        })
      }
    })
  }
  this.extension = function (req, mongo, send) {
    req.body = req.body._id ? req.body : req.query
    mongo.findId('commitment', mongo.toId(req.body._id), {
      _id: 1,
      actors: 1,
      dates: 1,
      extension: 1
    }, {}, async (err, commitment) => {
      if (err) {
        send({
          error: 'error'
        })
      } else {
        let oldDate, oldTrackingDate
        const first = {
          user: req.session.context.user
        }

        const extension = {}
        if (req.body.deadlineExtension) {
          commitment.dates.forEach(x => {
            if (x.type === 'deadline') {
              first.deadline = x.value
              oldDate = moment(x.value).format('DD/MM/YYYY')
              x.value = req.body.deadlineExtension
            }
          })
          extension.deadline = req.body.deadlineExtension
        }
        if (req.body.trackingExtension) {
          commitment.dates.forEach(x => {
            if (x.type === 'trackingDate') {
              first.trackingDate = x.value
              oldTrackingDate = moment(x.value).format('DD/MM/YYYY')
              x.value = req.body.trackingExtension
            }
          })
          extension.trackingDate = req.body.trackingExtension
        }
        if (!commitment.extension) {
          commitment.extension = [first]
        }
        extension.user = req.session.context.user
        commitment.extension.push(extension)
        await new Promise(resolve => {
          mongo.save('commitment', commitment, (err, result) => {
            if (!err) {
              resolve(result)
            }
          })
        })
        let comment = '<p> Cambió fecha de vencimiento del ' + oldDate + ' al ' + moment(req.body.deadlineExtension).format('DD/MM/YYYY') + '</p>'
        if (req.body.trackingExtension) {
          comment = comment + '<p> y fecha de seguimiento del ' + oldTrackingDate + ' al ' + moment(req.body.trackingExtension).format('DD/MM/YYYY') + '</p>'
        }
        comment = comment + '<p>' + req.body.commentExtension + '</p>'
        const data = {
          document: commitment._id,
          comment: comment,
          collection: 'commitment'
        }
        req.app.routes.comment.save(req, mongo, () => {
          send({
            message: tags.savedChanges
          })
        }, data)
      }
    })
  }
  this.addActors = function (req, id, actors, mongo, next) {
    mongo.findId('commitment', id, {
      actors: 1,
      issued: 1,
      reference: 1
    }, (err, doc) => {
      if (err || !doc) {
        next(err)
      } else {
        /* let path = ''
                        let index = doc.actors.findIndex((x) => {
                          return x.user.toString() === req.session.context.user.toString()
                        })
                        if (index !== -1) {
                          path = doc.actors[index].path
                        } */
        for (const i in actors) {
          const rm = doc.actors.findIndex((actor) => {
            return actor.user.toString() === actors[i].user.toString()
          })
          if (rm === -1) {
            //if(path && actors[i].role !== 'copy') actors[i].path = path
            doc.actors.push(actors[i])
          }
        }
        mongo.save('commitment', doc, async (err) => {
          let note = await new Promise(resolve => {
            mongo.findId('attached', doc.reference, (err, att) => {
              if (att) {
                mongo.findId('note', att.reference, (err, note) => {
                  if (note) resolve(note)
                  else resolve(false)
                })
              } else resolve(false)
            })
          })
          if (note) {
            await new Promise(resolve => {
              for (let i in actors) {
                let rm = note.actors.findIndex((actor) => {
                  return actor.user.toString() === actors[i].user.toString()
                })
                if (rm === -1) {
                  //if (path) actors[i].path = path
                  note.actors.push(actors[i])
                }
              }
              mongo.save('note', note, () => {
                mongo.find('attached', {
                  reference: note._id
                }, {}, async (err, atts) => {
                  if (atts && atts.length) {
                    for (let t in atts) {
                      for (let i in actors) {
                        let rm = atts[t].actors.findIndex((actor) => {
                          return actor.user.toString() === actors[i].user.toString()
                        })
                        if (rm === -1) {
                          //if (path) actors[i].path = path
                          atts[t].actors.push(actors[i])
                        }
                      }
                      await new Promise(resolve => {
                        mongo.save('attached', atts[t], async () => {
                          mongo.findOne('commitment', {
                            reference: atts[t]._id
                          }, {
                            _id: 1,
                            actors: 1,
                            reference: 1
                          }, async (err, comm) => {
                            if (comm) {
                              for (let i in actors) {
                                let rm = comm.actors.findIndex((actor) => {
                                  return actor.user.toString() === actors[i].user.toString()
                                })
                                if (rm === -1) {
                                  //if (path) actors[i].path = path
                                  comm.actors.push(actors[i])
                                }
                              }
                              await new Promise(resolve => {
                                mongo.save('commitment', comm, () => {
                                  mongo.findOne('evidence', {
                                    reference: comm._id
                                  }, {
                                    _id: 1,
                                    actors: 1,
                                    reference: 1
                                  }, async (err, evid) => {
                                    if (evid) {
                                      for (let i in actors) {
                                        let rm = evid.actors.findIndex((actor) => {
                                          return actor.user.toString() === actors[i].user.toString()
                                        })
                                        if (rm === -1) {
                                          //if (path) actors[i].path = path
                                          evid.actors.push(actors[i])
                                        }
                                      }
                                      await new Promise(resolve => {
                                        mongo.save('evidence', evid, () => {
                                          resolve()
                                        })
                                      })
                                    }
                                    resolve()
                                  })
                                })
                              })
                            }
                          })
                        })
                        resolve()
                      })
                    }
                  }
                  resolve()
                })
              })
            })
          }
          next(err, doc)
        })
      }
    })
  }
  this.$keys = async function (req, mongo, ) {
    var keys
    var scalableSequences = await new Promise(resolve => {
      mongo.find('sequence', {
        scalable: true
      }, (err, seqs) => {
        if (err) console.log(err)
        var ids = []
        if (seqs) {
          for (let s in seqs) {
            ids.push(seqs[s]._id)
          }
        }
        resolve(ids)
      })
    })
    if (req.session.context.licensedUser === false) {
      var myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits)
      var myAndDependentUnits = req.session.context.dependentUnits.concat(myUnits)
      keys = {
        $or: [
          // responsible user without hidden
          {
            actors: {
              $elemMatch: {
                user: req.session.context.user,
                role: 'responsible',
                path: {
                  $ne: 'hidden'
                }
              }
            }
          },
          // if confidential or not scalable, all actors user without hidden
          {
            $and: [{
              $or: [{
                confidential: '1'
              },
              {
                $and: [{
                  'sequence.sequence': {
                    $nin: scalableSequences
                  }
                }, {
                  'sequence._id': {
                    $nin: scalableSequences
                  }
                }]
              },
              ]
            },
            {
              $or: [{
                actors: {
                  $elemMatch: {
                    user: req.session.context.user,
                    path: {
                      $ne: 'hidden'
                    }
                  }
                }
              },
              {
                actors: {
                  $elemMatch: {
                    unit: {
                      $in: myUnits
                    },
                    path: {
                      $ne: 'hidden'
                    }
                  }
                }
              }
              ]
            }
            ]
          },
          // if not confidential and scalable, responsible unit are in dependents units without hidden only
          {
            confidential: {
              $ne: '1'
            },
            $or: [{
              'sequence.sequence': {
                $in: scalableSequences
              }
            }, {
              'sequence._id': {
                $in: scalableSequences
              }
            }],
            actors: {
              $elemMatch: {
                role: 'responsible',
                unit: {
                  $in: myAndDependentUnits
                },
                path: {
                  $ne: 'hidden'
                }
              }
            }
          }
        ]
      }
      if (req.session.context.readerUnits && req.session.context.readerUnits.length > 0) {
        keys.$or.push({
          $and: [{
            actors: {
              $elemMatch: {
                unit: {
                  $in: req.session.context.readerUnits
                },
                path: {
                  $ne: 'hidden'
                },
                role: 'from'
              }
            }
          }]
        })
      }
    } else {
      myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits).concat(req.session.context.memberUnits)
      myAndDependentUnits = req.session.context.dependentUnits.concat(myUnits)
      keys = {
        $or: [
          // users in the note & not hidden
          {
            actors: {
              $elemMatch: {
                user: req.session.context.user,
                path: {
                  $ne: 'hidden'
                }
              }
            }
          },
          // assistant in one unit of note & not hidden
          {
            actors: {
              $elemMatch: {
                unit: {
                  $in: myUnits
                },
                path: {
                  $ne: 'hidden'
                }
              }
            }
          },
          // manager or assistant of ascending unit, not hidden, scalable, non-confidential and not in draft
          {
            actors: {
              $elemMatch: {
                unit: {
                  $in: myAndDependentUnits
                },
                path: {
                  $ne: 'hidden'
                }
              }
            },
            confidential: {
              $ne: '1'
            }
          }
        ]
      }
      if (req.session.context.readerUnits && req.session.context.readerUnits.length > 0) {
        keys.$or.push({
          $and: [{
            actors: {
              $elemMatch: {
                unit: {
                  $in: req.session.context.readerUnits
                },
                path: {
                  $ne: 'hidden'
                },
                role: 'from'
              }
            }
          }]
        })
      }
    }
    return keys
  }
}