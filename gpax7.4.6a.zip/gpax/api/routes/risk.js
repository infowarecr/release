/* exported */
var Notification = require('../utils/notification').Notification
var notification = new Notification()

exports.Risk = Risk

function Risk () {
  /** save Risk */
  this.save = async function (req, mongo, send) {
    var doc = req.body
    var risk = await new Promise(resolve => {
      mongo.findId('risk', doc.id, { _id: 1, processes: 1, parent: 1 }, (err, risk) => {
        if (!err) {
          resolve(risk)
        } else {
          resolve(false)
        }
      })
    })
    var processes = await new Promise(resolve => {
      mongo.find('process', {}, { _id: 1 }, (err, processes) => {
        if (!err) {
          resolve(processes)
        } else {
          resolve(false)
        }
      })
    })
    var oldProcesses
    if (doc.$parent && doc.$parent !== '0') {
      doc.parent = doc.$parent
    } else {
      doc.parent = doc.parent ? doc.parent : ''
    }
    if (!risk || !risk.processes) {
      risk = {}
      risk._id = doc.id
      oldProcesses = []
    } else { oldProcesses = risk.processes }
    if (doc.processes && processes) {
      doc.processes = doc.processes.length >= 24 ? doc.processes.split(',') : []
      for (const p in doc.processes) {
        var index = processes.findIndex((x) => {
          return x._id.toString() === doc.processes[p]
        })
        if (index === -1) {
          doc.processes.splice(p, 1)
        }
      }
    } else {
      doc.processes = []
    }
    if (doc.processes) {
      for (const dp in doc.processes) {
        var process = await new Promise(resolve => {
          mongo.findId('process', doc.processes[dp], (err, process) => {
            if (!err) {
              resolve(process)
            } else {
              resolve(false)
            }
          })
        })
        addProcessChild(process, risk, mongo)
        addProcessParent(process, risk, mongo)
      }
      for (const i in oldProcesses) {
        if (doc.processes.findIndex((x) => { return x.toString() === oldProcesses[i].toString() }) === -1) {
          const process = await new Promise(resolve => {
            mongo.findId('process', oldProcesses[i], (err, process) => {
              if (!err) {
                resolve(process)
              } else {
                resolve(false)
              }
            })
          })
          removeProcessChild(process, risk, mongo)
        }
      }
    }

    // actualizar parent
    if (!doc.updateParent) {
      if (risk && doc.parent && risk.parent && doc.parent !== risk.parent.toString()) { doc.parent = risk.parent.toString() }
    }

    /* mongo.findId('risk', doc._id, { parent: 1 }, (err, current) => {
      if (err) throw err
      if (current && doc.parent && current.parent && doc.parent !== current.parent.toString()) { doc.parent = current.parent.toString() } */
    doc._id = mongo.isNativeId(doc.id) ? mongo.toId(doc.id) : mongo.newId()
    delete doc.id
    delete doc.open
    delete doc.ch1
    delete doc.webix_kids
    delete doc.parent_id
    delete doc.updateParent
    mongo.save('risk', doc, (err, result) => {
      if (err) {
        send({ error: err.toString() })
      } else {
        send({ id: doc._id, parent: doc.parent })
        doc.id = doc._id
        notification.send(req, req.session.context.room, 'dt_risk', doc, null, null)
      }
    })
    // })
  }
  async function addProcessChild (process, risk, mongo) {
    if (process) {
      if (!process.risks) process.risks = []
      if (process.risks && process.risks.selected) {
        const index = process.risks.selected.findIndex((x) => {
          return x.equals(risk._id)
        })
        if (index === -1) {
          process.risks.selected.push(risk._id)
        }
      } else {
        process.risks.selected = [risk._id]
      }
      await new Promise(resolve => {
        mongo.save('process', process, (err, result) => {
          if (!err) {
            resolve(process)
          } else {
            resolve(false)
          }
        })
      })
      if (risk.processes) {
        const index = risk.processes.findIndex((x) => {
          return x.equals(process._id)
        })
        if (index === -1) {
          risk.processes.push(process._id)
          await new Promise(resolve => {
            mongo.save('risk', risk, (err, result) => {
              if (!err) {
                resolve(process)
              } else {
                resolve(false)
              }
            })
          })
        }
      }
      const childRisk = await new Promise(resolve => {
        mongo.find('risk', { parent: risk._id }, { _id: 1, processes: 1 }, (err, risks) => {
          if (!err) {
            resolve(risks)
          } else {
            resolve(false)
          }
        })
      })
      if (childRisk) {
        for (const c in childRisk) {
          addProcessChild(process, childRisk[c], mongo)
        }
      }
    }
  }
  async function addProcessParent (process, risk, mongo) {
    if (process) {
      if (!process.risks) process.risks = []
      if (process.risks && process.risks.selected) {
        const index = process.risks.selected.findIndex((x) => {
          return x.equals(risk._id)
        })
        if (index === -1) {
          process.risks.selected.push(risk._id)
        }
      } else {
        process.risks.selected = [risk._id]
      }
      await new Promise(resolve => {
        mongo.save('process', process, (err, result) => {
          if (!err) {
            resolve(process)
          } else {
            resolve(false)
          }
        })
      })
      if (risk.processes) {
        const index = risk.processes.findIndex((x) => {
          return x.equals(process._id)
        })
        if (index === -1) {
          risk.processes.push(process._id)
          await new Promise(resolve => {
            mongo.save('risk', risk, (err, result) => {
              if (!err) {
                resolve(process)
              } else {
                resolve(false)
              }
            })
          })
        }
      }
      const parentRisk = await new Promise(resolve => {
        mongo.find('risk', { _id: risk.parent }, { _id: 1, processes: 1 }, (err, risks) => {
          if (!err) {
            resolve(risks)
          } else {
            resolve(false)
          }
        })
      })
      if (parentRisk) {
        for (const p in parentRisk) {
          addProcessParent(process, parentRisk[p], mongo)
        }
      }
    }
  }
  async function removeProcessChild (process, risk, mongo) {
    if (process) {
      if (!process.risks) process.risks = []
      if (process.risks && process.risks.selected) {
        var r = process.risks.selected.findIndex((x) => {
          return x.toString() === risk._id.toString()
        })
        if (r !== -1) {
          process.risks.selected.splice(r, 1)
          await new Promise(resolve => {
            mongo.save('process', process, (err, result) => {
              if (!err) {
                resolve(process)
              } else {
                resolve(false)
              }
            })
          })
        }
        if (risk.processes) {
          const index = risk.processes.findIndex((x) => {
            return x.toString() === process._id.toString()
          })
          if (index !== -1) {
            risk.processes.splice(index, 1)
            await new Promise(resolve => {
              mongo.save('risk', risk, (err, result) => {
                if (!err) {
                  resolve(process)
                } else {
                  resolve(false)
                }
              })
            })
          }
        }
        const childRisk = await new Promise(resolve => {
          mongo.find('risk', { parent: risk._id }, { _id: 1, processes: 1 }, (err, risks) => {
            if (!err) {
              resolve(risks)
            } else {
              resolve(false)
            }
          })
        })
        if (childRisk) {
          for (const c in childRisk) {
            removeProcessChild(process, childRisk[c], mongo)
          }
        }
      }
    }
  }
  /** delete Risk */
  this.delete = function (req, mongo, send) {
    var doc = req.query
    mongo.findId('risk', mongo.toId(doc._id), (err, risk) => {
      if (err) {
        send({ error: err })
      } else {
        mongo.deleteOne('risk', { _id: mongo.toId(doc._id) }, (err, result) => {
          if (err) {
            req.logger.log(err)
          } else {
            req.app.routes.trash.insert(req, mongo, 'risk', risk, () => {
              send()
              doc.id = doc._id
              notification.send(req, req.session.context.room, 'dt_risk', doc, null, true)
            })
          }
        })
      }
    })
  }
  /** list Risks */
  this.list = function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    if (req.query.parent && mongo.isNativeId(req.query.parent)) {
      var keys = { parent: mongo.toId(req.query.parent) }
    } else {
      keys = { $or: [{ parent: '' }, { parent: { $exists: 0 } }] }
    }
    if (req.query.filter && !req.query.parent) {
      const query = {}
      let filter = false
      for (const name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          filter = true
          if (name === 'name') {
            query[name] = {
              $regex: req.query.filter.name, $options: 'i'
            }
          } else if (name === '_id') {
            var ids = req.query.filter[name].split(',')
            for (const i in ids) {
              ids[i] = mongo.toId(ids[i])
            }
            query[name] = { $in: ids }
          } else {
            query[name] = req.query.filter[name].indexOf(',') !== -1 ? { $in: req.query.filter[name].split(',') } : new RegExp(req.query.filter[name].replace(/ /g, '.*'), 'i')
          }
        }
      }
      keys = filter ? query : { $and: [keys, query] }
    }
    mongo.find('risk', keys, {}, { name: 1 }, (err, risks) => {
      if (err) throw err
      mongo.find('risk', {}, {}, {}, async (err, allRisks) => {
        if (!err && risks) {
          for (const i in risks) {
            var risk = risks[i]
            if (!risk.processes) {
              var processes = await new Promise(resolve => {
                mongo.find('process', { 'risks.selected': risk._id }, { _id: 1 }, (err, processes) => {
                  if (!err) {
                    resolve(processes)
                  } else {
                    resolve(false)
                  }
                })
              })
              if (processes) {
                risk.processes = []
                for (const p in processes) {
                  risk.processes.push(processes[p]._id)
                }
              }
            }
            this.getItem(req, risk, allRisks)
            risk.id = risk._id
            reply.data.push(risk)
          }
          if (skip) {
            if (req.query.parent) { send({ parent: req.query.parent, data: reply.data }) } else { send(reply) }
          } else {
            mongo.count('risk', keys, (err, count) => {
              if (!err && count) {
                reply.total_count = count
              }
              if (req.query.parent) {
                send({ parent: req.query.parent, data: reply.data })
              } else {
                send(reply)
              }
            })
          }
        }
      })
    })
  }
  this.listAllForExcel = async function (req, mongo, send) {
    var reply = []
    let keys = {}

    var tagsDoc = await new Promise(resolve => {
      mongo.find('params', { name: 'riskCategory' }, { _id: 1, name: 1, options: 1 }, (err, tagsDoc) => {
        if (err || (tagsDoc && tagsDoc.length === 0)) {
          console.log(err)
          resolve([])
        } else {
          resolve(tagsDoc[0].options)
        }
      })
    })
    mongo.find('risk', keys, {}, { name: 1 }, (err, risks) => {
      if (!err && risks) {

        for (const i in risks) {
          var risk = risks[i]
          risk.id = risk._id
          risk.weight = risk.weight || ''
          if (tagsDoc.length > 0 && risk.category) {
            for (let t = 0; t < tagsDoc.length; t++) {
              if (tagsDoc[t] && risk.category && tagsDoc[t].id.toString() === risk.category.toString()) {
                risk.category = tagsDoc[t].value || ''
              }
            }
          }else{
            risk.category = ''
          }
          reply.push(risk)
        }
        function arr2hash (data) {
          var hash = {}
          for (var i = 0; i < data.length; i++) {
            var pid = data[i].parent.toString()
            if (!hash[pid]) hash[pid] = []
            hash[pid].push(data[i])
          }
          return hash
        }
        function hash2tree (hash, level) {
          var top = hash[level]
          if (top) {
            for (var i = 0; i < top.length; i++) {
              var branch = top[i]._id.toString()
              if (hash[branch]) { top[i].data = hash2tree(hash, branch) }
            }
          }
          return top
        }
        function getRecords (risks) {
          var hash = arr2hash(risks)
          return hash2tree(hash, '')
        }
        let data = getRecords(reply)
        send(data)
      }
    })
  }
  this.getItem = function (req, risk, allRisks) {
    risk.id = risk._id.toString()
    function find (x) {
      var p = x.parent ? x.parent.toString() : ''
      return p === risk.id
    }
    const parent = allRisks.findIndex(find)
    if ((risk.parent === '' && parent !== -1) || (req.query.parent && parent !== -1) || parent !== -1) {
      risk.webix_kids = true
    }

    return risk
  }

  this.findRisk = async function (req, mongo, send) {
    mongo.find('risk', { type: 'risk', $or: [ { parent: '' }, { parent: 0 }, { parent: { $exists: 0} } ] }, {}, {}, async (err, risks) => {
      if (err) {
        send()
        console.log(err)
      } else {
        var resultadoProcessAssessment = await new Promise(resolve => {
          mongo.findId('processAssessment', mongo.toId(req.query.processAssessment), async (err, doc) => {
            if (err || !doc) {
              resolve(false)
            } else {
              resolve(doc)
            }
          })
        })
        for (const c in risks) {
          const pos = resultadoProcessAssessment.risks.findIndex((x) => {
            return x._id.toString() === risks[c]._id.toString()
          })
          if (pos !== -1) {
            risks[c].ch1 = 'on'
          } else {
            risks[c].ch1 = 'off'
          }
        }
        send(risks)
      }
    })
  }

  this.findRiskFactor = async function (req, mongo, send) {
    mongo.find('risk', { type: 'riskFactor', parent: mongo.toId(req.query._id) }, {}, {}, async (err, riskFactors) => {
      if (err) {
        send()
        console.log(err)
      } else {
        var resultadoProcessAssessment = await new Promise(resolve => {
          mongo.findId('processAssessment', mongo.toId(req.query.processAssessment), async (err, doc) => {
            if (err || !doc) {
              resolve(false)
            } else {
              resolve(doc)
            }
          })
        })
        for (const c in riskFactors) {
          const pos = resultadoProcessAssessment.risks.findIndex((x) => {
            return x._id.toString() === riskFactors[c]._id.toString()
          })
          if (pos !== -1) {
            riskFactors[c].ch1 = 'on'
          } else {
            riskFactors[c].ch1 = 'off'
          }
        }
        send(riskFactors)
      }
    })
  }

  this.findControls = async function (req, mongo, send) {
    mongo.find('risk', { type: 'control', parent: mongo.toId(req.query._id) }, {}, {}, async (err, controls) => {
      if (err) {
        send()
        console.log(err)
      } else {
        var resultadoControlAssessment = await new Promise(resolve => {
          mongo.findId('controlAssessment', mongo.toId(req.query.controlAssessment), async (err, controlA) => {
            if (err || !controlA) {
              resolve(false)
            } else {
              resolve(controlA)
            }
          })
        })
        for (const c in controls) {
          const pos = resultadoControlAssessment.risks.findIndex((x) => {
            return x._id.toString() === controls[c]._id.toString()
          })
          if (pos !== -1) {
            controls[c].ch1 = 'on'
          } else {
            controls[c].ch1 = 'off'
          }
        }
        send(controls)
      }
    })
  }
  this.listBindProcess = async function (req, mongo, send) {
    var keys = { }
    if ((req.query.filter && !req.body.filter) && !req.query.parent) {
      let query = {}
      let filter = false
      for (const name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          filter = true
          if (name === '_id') {
            var ids = req.query.filter[name].split(',')
            for (let i in ids) {
              ids[i] = mongo.toId(ids[i])
            }
            query[name] = { $in: ids }
          }
        }
      }
      keys = filter ? query : { $and: [keys, query] }
    } else if (req.body.filter && !req.query.parent) {
      let query = {}
      for (let i in req.body.filter) {
        req.body.filter[i] = mongo.toId(req.body.filter[i])
      }
      query['_id'] = { $in: req.body.filter }
      keys = query
    }
    mongo.find('risk', keys, {}, async (err, risks) => {
      if (err) {
        send()
      } else {
        const arr2hash = (data) => {
          var hash = {}
          for (var i = 0; i < data.length; i++) {
            data[i].id = data[i]._id
            if (data[i].name && data[i].name.length > 100) {
              data[i].shortName = data[i].name.substring(0, 100) + '...'
            } else {
              data[i].shortName = data[i].name
            }
            var pid = data[i].parent === '' ? 0 : data[i].parent || 0
            if (!hash[pid]) hash[pid] = []
            hash[pid].push(data[i])
          }
          return hash
        }
        const hash2tree = (hash, level) => {
          var top = hash[level]
          if (top) {
            for (var i = 0; i < top.length; i++) {
              var branch = top[i]._id
              if (hash[branch]) { top[i].data = hash2tree(hash, branch) }
            }
          }
          return top
        }
        var hash = arr2hash(risks)
        const data = hash2tree(hash, 0)
        send(data)
      }
    })
  }

  this.findRiskFactors = async function (req, mongo, send) {
    var data = []
    mongo.find('risk', {}, {}, {}, async (err, risks) => {
      if (err) {
        send()
      } else {
        for (const rf in risks) {
          await new Promise(resolve => {
            mongo.find('risk', { type: 'riskFactor', parent: risks[rf]._id }, {}, {}, async (err, risksFactors) => {
              if (err) {
                resolve()
                console.log(err)
              } else {
                for (const m in risksFactors) {
                  data.push({ id: risksFactors[m]._id, risk: risks[rf].name, riskFactor: risksFactors[m].name })
                }
                resolve()
              }
            })
          })
        }
        send(data)
      }
    })
  }

  this.findRiskFactorsInEvents = async function (req, mongo, send) {
    var data = []
    mongo.find('risk', { type: 'riskFactor' }, {}, {}, async (err, riskFactors) => {
      if (err) {
        send()
        console.log(err)
      } else {
        var resultEvents = await new Promise(resolve => {
          mongo.find('riskEvent', {}, {}, {}, async (err, events) => {
            if (err || !events) {
              resolve(false)
            } else {
              resolve(events)
            }
          })
        })
        for (const c in riskFactors) {
          const pos = resultEvents.findIndex((x) => {
            return x.riskFactor.toString() === riskFactors[c]._id.toString()
          })
          if (pos !== -1) {
            data.push({ id: riskFactors[c]._id, value: riskFactors[c].name })
          }
        }
        send(data)
      }
    })
  }
}
