/* template */
var tags = require('../utils/tags').tags
var Notification = require('../utils/notification').Notification
var notification = new Notification()
/* exported */
exports.Template = Template

function Template () {
  this.get = function (req, mongo, send) {
    if (req.query._id) {
      mongo.findId('template', req.query._id, (err, template) => {
        if (err) {
          req.statusCode = 404
          send()
        } else {
          if (template.workDay && template.template) {
            template.template.workDay=template.workDay
          }
          send(template)
        }
      })
    } else {
      send({ _id: mongo.newId(), type: req.query.type })
    }
  }
  this.list = function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    var keys = {}
    var user = req.session.context
    mongo.find('params', { name: 'tag' }, { _id: 1, name: 1, options: 1 }, (er, tgs) => {
      mongo.find('unit', {}, { _id: 1, name: 1 }, (err, units) => {
        if (err) throw err
        mongo.find('sequence', {}, { _id: 1, name: 1 }, (err, sequences) => {
          if (err) throw err
          mongo.findId('user', user.user, (err, users) => {
            if (err) throw err
            if (req.query.filter) {
              let query = {}
              for (const name in req.query.filter) {
                if (req.query.filter[name].length > 0) {
                  if (req.query.restrictedTo === 'true') {
                    var userUnits = users.units
                    if (user.licensedUser) {
                      userUnits.push('')
                      query.$or = [
                        { units: { $in: userUnits } },
                        { 'units.0': { $exists: 0 } }
                      ]
                    } else {
                      query.$or = [
                        { units: { $in: userUnits } },
                        { public: '1' }
                      ]
                    }
                  }
                  if (name === 'tagsname') {
                    query.tags = mongo.toId(req.query.filter.tagsname)
                  }
                  if (name === 'units') {
                    query.units = mongo.toId(req.query.filter.units)
                  }
                  if (name === 'filterSequences') {
                    query.sequence = mongo.toId(req.query.filter.filterSequences)
                  }
                  if (name === 'name' && !req.query.restrictedTo) {
                    query[name] = new RegExp(req.query.filter[name], 'i')
                    /*query.$text = {
                      $search: req.query.filter.name
                    }*/
                  } else if (name === 'name' && req.query.restrictedTo) {
                    query[name] = new RegExp(req.query.filter[name], 'i')
                  } else if (name === '_id') {
                    var ids = req.query.filter[name].split(',')
                    for (const i in ids) {
                      if (mongo.isNativeId(ids[i])) {
                        ids[i] = mongo.toId(ids[i])
                      }
                    }
                    query[name] = { $in: ids }
                  } if (name === 'type') {
                    var type = req.query.filter[name]
                    if (Array.isArray(type)) {
                      if (type[1] !== '') {
                        type = type[1]
                      } else {
                        type = type[0]
                      }
                    }
                    query[name] = type.indexOf(',') !== -1 ? { $in: type.split(',') } : new RegExp(type.replace(/ /g, '.*'), 'i')
                  }
                }
              }
              if (req.query.start === 0) {
                delete req.query.continue
              }
              delete query.tagsname
              delete query.filterUnits
              delete query.filterSequences
              delete query.restrictedTo
              keys = query
            }
            mongo.findN('template', skip, limit, keys, { template: 0 }, { name: 1 }, (err, templates) => {
              if (err) { send({ error: err }) } else {
                for (const i in templates) {
                  var doc = templates[i]
                  var item = this.getItem(doc, tgs, units, sequences)
                  reply.data.push(item)
                }
                if (skip) {
                  send(reply)
                } else {
                  mongo.count('template', keys, (err, count) => {
                    if (!err && count) {
                      reply.total_count = count
                    }
                    send(reply)
                  })
                }
              }
            })
          })
        })
      })
    })
  }

  this.getItem = function (doc, tgs, units, sequences) {
    var tagsId = []
    for (const j in doc.tags) {
      tagsId.push(doc.tags[j])
    }
    var usedTags = []
    if (tgs[0]) {
      for (let t = 0; t < tgs[0].options.length; t++) {
        for (let o = 0; o < tagsId.length; o++) {
          if (tgs[0].options[t].id.toString() === tagsId[o].toString()) {
            usedTags.push(tgs[0].options[t])
          }
        }
      }
    }
    var tagscolor = []
    var tagsname = []
    // var tagsname = [usedTags[0] ? usedTags[0].value : ''];
    for (const i in usedTags) {
      tagscolor.push(usedTags[i].color)
      tagsname.push(usedTags[i].value)
      // filterNames.push(usedTags[i].value);
    }

    var unitsname = []
    for (let t = 0; t < units.length; t++) {
      for (const i in doc.units) {
        if (units[t]._id.toString() === doc.units[i].toString()) {
          unitsname.push(units[t].name)
        }
      }
    }

    var sequencesname = []
    for (let t = 0; t < sequences.length; t++) {
      for (const i in doc.sequence) {
        if (sequences[t]._id.toString() === doc.sequence[i].toString()) {
          sequencesname.push(sequences[t].name)
        }
      }
    }

    var row = {
      unitsname: unitsname,
      filterUnits: unitsname[0],
      sequencesname: sequencesname,
      filterSequences: sequencesname[0],
      id: doc._id,
      name: doc.name,
      template: doc.template,
      type: doc.type,
      filter: !!doc.filter,
      tagscolor: tagscolor,
      tagsname: tagsname
    }

    return row
  }

  this.saveBpmn = function (req, mongo, send) {
    var doc = req.query
    mongo.save('template', doc, (err, result) => {
      var reply
      if (err) {
        reply = { error: tags.savingProblema }
      } else {
        reply = { message: tags.savedChanges }
      }
      send(reply)
    })
  }
  this.setWorkDay = function (req, mongo, send) {
    var id = req.body._id
    var workDay=1 * req.body.workDay
    if (id && workDay) {
      id = mongo.toId(id)
      mongo.findId('template', id, (err, doc) => {
        if (doc.workDay !== workDay) {
          for (let i in doc.template.data) {
            var task = doc.template.data[i]
            if (task.workDay && task.workDay === doc.workDay) {
              delete task.workDay
            }
          }
          mongo.save('template', { _id: id, workDay: workDay,template: doc.template }, (err, result) => {
            if (err) {
              send({ error: err })
            } else {
              send()
            }
          })
        }
      })
    }
  }
  this.save = function (req, mongo, send) {
    var doc = req.body
    var exist = false
    if (doc.units) {
      doc.units = doc.units.split ? doc.units.split(',') : []
    }
    if (doc.tags) {
      doc.tags = doc.tags.length === 0 ? [] : doc.tags.split(',')
    }
    if (doc.sequence) {
      var sequence = []
      sequence = doc.sequence.length >= 24 ? doc.sequence.split(',') : []
      doc.sequence = sequence
    }
    if (doc.type === tags.project) {
      var duration = 0
      var data = doc.template.data

      var links = doc.template.links
      for (const i in doc.template.data) {
        if (doc.template.data[i].parent === 0) { duration = duration + parseInt(doc.template.data[i].duration) }
      }
      for (const d in data) {
        if (data[d].type === 'project') {
          for (const l in links) {
            if (data[d].id.toString() === links[l].source.toString() || data[d].id.toString() === links[l].target.toString()) {
              exist = true
              break
            }
          }
        }
        if (exist) { break }
      }
      doc.duration = duration.toString()
    }
    if (doc.filter) {
      doc.filter = 1 * doc.filter === 1
    }
    if (!exist) {
      mongo.save('template', doc, (err, result) => {
        var reply
        if (err) {
          reply = { error: tags.savingProblema }
        } else {
          reply = { message: tags.savedChanges }
        }
        send(reply)
        mongo.find('params', { name: 'tag' }, { _id: 1, name: 1, options: 1 }, (er, tgs) => {
          mongo.find('unit', {}, { _id: 1, name: 1 }, (er, units) => {
            mongo.find('sequence', {}, { _id: 1, name: 1 }, (er, sequences) => {
              var item = this.getItem(doc, tgs, units, sequences)
              notification.send(req, req.session.context.room, 'templates', item, null, null)
            })
          })
        })
      })
    } else send({ message: 'err' })
  }
  this.delete = async function (req, mongo, send) {
    var doc = req.query
    var idTemplate = mongo.toId(doc._id)
    var pipeline = [
      { $match: { _id: idTemplate } },
      {
        $lookup: {
          from: 'document',
          let: { idTemplate: '$_id' },
          pipeline: [{
            $match: { $expr: { $eq: ['$template', '$$idTemplate'] } }
          }, {
            $project: { _id: 1, template: 1 }
          }], as: 'documents'
        }
      },
      {
        $lookup: {
          from: 'note',
          let: { idTemplate: '$_id' },
          pipeline: [{
            $match: { $expr: { $eq: ['$template', '$$idTemplate'] } }
          }, {
            $project: { _id: 1, template: 1 }
          }], as: 'notes'
        }
      },
      {
        $lookup: {
          from: 'attached',
          let: { idTemplate: '$_id' },
          pipeline: [{
            $match: { $expr: { $eq: ['$template', '$$idTemplate'] } }
          }, {
            $project: { _id: 1, template: 1 }
          }], as: 'attacheds'
        }
      },
      {
        $lookup: {
          from: 'commitment',
          let: { idTemplate: '$_id' },
          pipeline: [{
            $match: { $expr: { $eq: ['$template', '$$idTemplate'] } }
          }, {
            $project: { _id: 1, template: 1 }
          }], as: 'commitments'
        }
      },
      {
        $lookup: {
          from: 'evidence',
          let: { idTemplate: '$_id' },
          pipeline: [{
            $match: { $expr: { $eq: ['$template', '$$idTemplate'] } }
          }, {
            $project: { _id: 1, template: 1 }
          }], as: 'evidences'
        }
      },
      {
        $lookup: {
          from: 'project',
          let: { idTemplate: '$_id' },
          pipeline: [{
            $match: { $expr: { $eq: ['$template', '$$idTemplate'] } }
          }, {
            $project: { _id: 1, template: 1 }
          }], as: 'projects'
        }
      },
      {
        $lookup: {
          from: 'auditable',
          let: { idTemplate: '$_id' },
          pipeline: [{
            $match: { $expr: { $eq: ['$project', '$$idTemplate'] } }
          }, {
            $project: { _id: 1, template: 1 }
          }], as: 'auditables'
        }
      },
      { $project: { _id: 1, name: 1, documents: 1, notes: 1, attacheds: 1, commitments: 1, evidences: 1, projects: 1 } },
      { $sort: { _id: -1 } }
    ]
    var template = await new Promise(resolve => {
      mongo.aggregate('template', pipeline, {}, async (err, templates) => {
        if (err) {
          resolve()
        } else {
          resolve(templates)
        }
      })
    })
    if (template && template[0] && (
      (template[0].documents && template[0].documents.length) ||
      (template[0].notes && template[0].notes.length) ||
      (template[0].attacheds && template[0].attacheds.length) ||
      (template[0].commitments && template[0].commitments.length) ||
      (template[0].evidences && template[0].evidences.length) ||
      (template[0].projects && template[0].projects.length) ||
      (template[0].auditables && template[0].auditables.length)
    )) {
      send({ msj: '_cantDeleteTemplateAlreadyInUse' }) //El modelo no se puede borrar porque ya ha sido utilizado en el sistema
    } else {
      mongo.findId('template', mongo.toId(doc._id), (err, template) => {
        if (err) {
          send({ error: err })
        } else {
          mongo.deleteOne('template', { _id: mongo.toId(doc._id) }, (err, result) => {
            if (err) {
              req.logger.log(err)
            } else {
              req.app.routes.trash.insert(req, mongo, 'template', template, () => {
                doc.id = doc._id
                send({ id: doc._id })
                notification.send(req, req.session.context.room, 'templates', doc, null, true)
                notification.send(req, req.session.context.room, 'templatesProject', doc, null, true)
              })
            }
          })
        }
      })
    }
  }

  this.duplicate = function (req, mongo, send) {
    var doc = req.query
    mongo.findId('template', mongo.toId(doc._id), (err, template) => {
      if (err) {
        return send({ error: err })
      } else {
        template._id = mongo.newId()
        template.name = template.name + ' - copy'
        template.duplicated = true
        mongo.save('template', template, (err, result) => {
          var reply
          if (err) {
            return send({ error: tags.savingProblema })
          } else {
            reply = { message: tags.savedChanges }
          }
          send(reply)
          mongo.find('params', { name: 'tag' }, { _id: 1, name: 1, options: 1 }, (er, tgs) => {
            mongo.find('unit', {}, { _id: 1, name: 1 }, (er, units) => {
              mongo.find('sequence', {}, { _id: 1, name: 1 }, (er, sequences) => {
                var item = this.getItem(template, tgs, units, sequences)
                notification.send(req, req.session.context.room, 'templates', item, null, null)
                // notification.send(req, req.session.context.room, 'templatesProject', item, null, null)
              })
            })
          })
        })
      }
    })
  }

  this.deleteMany = function (req, mongo, send) {
    var doc = req.body.ids
    doc = doc.split(',')
    var allIds = []
    for (const i in doc) {
      allIds.push(doc[i])
      doc[i] = mongo.toId(doc[i])
    }
    mongo.find('template', { _id: { $in: doc } }, {}, {}, (err, templates) => {
      if (err) {
        send({ error: err })
      } else {
        mongo.deleteAll('template', { _id: { $in: doc } }, async (err, res) => {
          if (err) {
            send()
          } else {
            for (const t in templates) {
              await new Promise(resolve => {
                req.app.routes.trash.insert(req, mongo, 'template', templates[t], () => {
                  resolve()
                })
              })
            }
            send({ message: tags.savedChanges })
            doc.id = allIds
            notification.send(req, req.session.context.room, 'templates', { id: allIds }, null, true)
          }
        })
      }
    })
  }
}
