/* exported */
var tags = require('../utils/tags').tags
var dateformat = require('dateformat')

var html2json = require('html2json').html2json
var json2html = require('html2json').json2html

var Notification = require('../utils/notification').Notification
var notification = new Notification()
class Assessment {
  /** get document Assessment */
  get (req, mongo, send) {
    if (req.query._id) {
      mongo.findId('assessment', req.query._id, (err, assessment) => {
        if (!err) {
          send(assessment)
        } else {
          send()
        }
      })
    } else {
      send({ _id: mongo.newId() })
    }
  }

  /** Start SpecificRisk assessment */
  startSpecificRiskAssessment (req, mongo, send) {
    var id = req.query._id
    mongo.findId('assessment', id, async (err, assessment) => {
      if (err || !assessment) {
        send({ error: err })
      } else {
        var dataArray = []
        var save = true
        var msj = String
        if (assessment.type === 'specificRisk') {
          let sett = await new Promise(resolve => {
            mongo.findOne('settings', { _id: 'riskScale' }, { riskRanges: 1, impact: 1, probability: 1 }, (err, sett) => {
              if (err) {
                resolve(false)
              } else {
                if (sett) resolve(sett)
                else resolve()
              }
            })
          })
          if (sett.riskRanges) assessment.riskRanges = sett.riskRanges
          else assessment.riskRanges = []
          for (const i in assessment.process) {
            if (save) {
              var data = {}
              var resultado = await new Promise(resolve => {
                mongo.findId('process', assessment.process[i], async (err, process) => {
                  if (err || !process) {
                    save = false
                    resolve(false)
                  } else {
                    data._id = mongo.newId()
                    data.name = process.name
                    data.user = req.session.context.user
                    data.process = process._id
                    data.assessment = assessment._id
                    //* obtenidos de sett
                    data.riskRanges = sett.riskRanges ? sett.riskRanges : ''
                    data.impactFactors = sett.impact ? sett.impact :''
                    data.probabilityFactors = sett.probability ? sett.probability : ''
                    /** */
                    data.probability = String
                    data.impact = String
                    data.residual = {
                      probability: String,
                      impact: String
                    }
                    data.risks = []
                    if (process.risks && process.risks.selected && process.risks.selected.length > 0 && process.risks.selected !== '[]') {
                      for (const r in process.risks.selected) {
                        if (save) {
                          var resultado2 = await new Promise(resolve => {
                            mongo.findId('risk', process.risks.selected[r], async (err, risk) => {
                              if (err || !risk) {
                                if (err) console.log(err)
                                save = false
                                resolve('')
                              } else {
                                if (risk.type !== 'control') {
                                  risk.probability = String
                                  risk.impact = String
                                  risk.residual = {
                                    probability: String,
                                    impact: String
                                  }
                                }
                                data.risks.push(risk)
                                resolve(true)
                              }
                            })
                          })
                          if (!resultado2) {
                            save = false
                            break
                          }
                        }
                      }
                      if (!resultado2) {
                        msj = process.name+ '_risksNotFound' + ' ' + '_saveProcess'
                        save = false
                        resolve(false)
                      } else {
                        resolve(true)
                      }
                    } else {
                      msj = process.name + '_missingRisks'
                      save = false
                      resolve(false)
                    }
                  }
                })
              })
              if (resultado) {
                dataArray.push(data)
              } else {
                save = false
              }
            } else break
          }
          if (resultado && save) {
            mongo.insertMany('processAssessment', dataArray, (err) => {
              if (err) {
                send({ error: err })
              } else {
                mongo.save('assessment', { _id: assessment._id, status: 'processing', riskRanges: assessment.riskRanges }, () => {
                  send({ resultado: resultado, msj: msj })
                })
              }
            })
          } else {
            send({ resultado: save, msj: msj })
          }
        } else {
          send({ resultado: false, msj: '_untypedAssessment' }) //Calificación sin tipo
        }
      }
    })
  }

  /** Start Factors assessment */
  startFactorsAssessment (req, mongo, send) {
    var id = req.query._id
    mongo.findId('assessment', id, async (err, assessment) => {
      if (err || !assessment) {
        send({ error: err })
      } else {
        var msj = String
        if (assessment.type === 'byFactors') {
          let sett = await new Promise(resolve => {
            mongo.findOne('settings', { _id: 'riskScale' }, { riskRanges: 1 }, (err, sett) => {
              if (err) {
                resolve(false)
              } else {
                if (sett) resolve(sett)
                else resolve()
              }
            })
          })
          if (sett.riskRanges) assessment.riskRanges = sett.riskRanges
          else assessment.riskRanges = []
          mongo.find('auditable', { type: 'byRisk' }, {}, {}, (err, auditables) => {
            if (err) {
              send({ error: err })
            } else {
              var auds = []
              for (const a in auditables) {
                auds.push(auditables[a]._id)
              }
              /** doc del audiAss */
              mongo.save('auditableAssessment', { _id: mongo.newId(), name: 'Mapa de calor', auditables: auds, assessment: assessment._id }, (err) => {
                if (err) {
                  send({ error: err })
                } else {
                  mongo.save('assessment', { _id: assessment._id, status: 'processing', riskRanges: assessment.riskRanges }, () => {
                    send({ resultado: true, msj: msj })
                  })
                }
              })
            }
          })
        } else {
          send({ resultado: false, msj: '_untypedAssessment' })
        }
      }
    })
  }

  /** Start Control assessment */
  async startControlAssessment (req, mongo, send) {
    var id = req.query._id
    mongo.find('assessment', {}, {}, { _id: -1 }, async (err, assessments) => {
      if (err) {
        send()
        console.log(err)
      } else {
        mongo.findId('assessment', id, async (err, assessment) => {
          if (err || !assessment) {
            send({ error: err })
          } else {
            if (assessment.type === 'byControls') {
              var msj = 'La calificación no se ha podido iniciar'
              var processAssessments
              var save = true
              var dataArray = []
              let sett = await new Promise(resolve => {
                mongo.findOne('settings', { _id: 'riskScale' }, { riskRanges: 1, effectivityFactors: 1 }, (err, sett) => {
                  if (err) {
                    resolve(false)
                  } else {
                    if (sett) resolve(sett)
                    else resolve()
                  }
                })
              })
              assessment.riskRanges = sett.riskRanges ? sett.riskRanges : []
              assessment.effectivityFactors = sett.effectivityFactors ? sett.effectivityFactors : []
              for (const i in assessment.process) {
                var existRiskCalification = false
                var sameTree = false
                var arrayProcess = ''

                for (const a in assessments) {
                  for (const p in assessments[a].process) {
                    if ((assessment.process[i].toString() === assessments[a].process[p].toString()) && (assessments[a].type === 'specificRisk') && (assessments[a].status === 'done')) {
                      var proc = await new Promise(resolve => {
                        mongo.findId('process', assessment.process[i], async (err, process) => {
                          if (err || !process) {
                            save = false
                            resolve(false)
                          } else {
                            resolve(process)
                          }
                        })
                      })
                      const processAssessment = proc
                      if (processAssessment) {
                        var resultadoAssessments = await new Promise(resolve => {
                          mongo.find('processAssessment', { assessment: assessments[a]._id, process: processAssessment._id }, {}, { _id: -1 }, async (err, process) => {
                            if (err || !process[0]) {
                              resolve(false)
                            } else {
                              resolve(process[0])
                            }
                          })
                        })
                        processAssessments = resultadoAssessments
                        if (processAssessments) {
                          for (const p in processAssessment.risks.selected) {
                            var risk = await new Promise(resolve => {
                              mongo.findId('risk', processAssessment.risks.selected[p], async (err, risk) => {
                                if (err || !risk) {
                                  if(err) console.log(err)
                                  save = false
                                  resolve(false)
                                } else {
                                  resolve(risk)
                                }
                              })
                            })

                            if (risk && (risk.type === 'risk' || risk.type === 'riskFactor')) {
                              const pos = processAssessments.risks.findIndex((x) => {
                                return x._id.toString() === processAssessment.risks.selected[p].toString()
                              })
                              if (pos !== -1) {
                                sameTree = true
                                save = true
                                existRiskCalification = true
                              } else {
                                sameTree = false
                                save = false
                                existRiskCalification = false
                                arrayProcess = '' + proc.name
                                break
                              }
                            }
                            arrayProcess = '' + proc.name
                          }
                          arrayProcess = '' + proc.name
                        } else {
                          sameTree = false
                          save = false
                          existRiskCalification = false
                          arrayProcess = '' + proc.name
                          break
                        }
                      }
                    } else {
                      save = false
                    }
                    if (sameTree) {
                      break
                    }
                  }
                  if (sameTree || existRiskCalification) {
                    if (existRiskCalification) {
                      save = true
                    }
                    break
                  }
                }

                if (sameTree === false) {
                  if(arrayProcess) msj = 'El ' + arrayProcess + ' , no cuenta con una calificación de Riesgo específico en estado Terminado, con la misma estructura de riesgos y medios'
                  else msj = 'Los procesos no cuentan con una calificacion de riesgo especifico'
                  break
                } else {
                  if (save) {
                    var data = {}
                    var resultado = await new Promise(resolve => {
                      mongo.findId('process', assessment.process[i], async (err, process) => {
                        if (err || !process) {
                          save = false
                          resolve(false)
                        } else {
                          resolve(process)
                        }
                      })
                    })
                    const process = resultado
                    if (sameTree === false) {
                      msj = 'El proceso ' + process.name + ' no se puede calificar'
                      save = false
                    } else {
                      data._id = mongo.newId()
                      data.name = process.name
                      data.user = req.session.context.user
                      data.process = process._id
                      data.assessment = assessment._id
                      data.effectivityFactors = assessment.effectivityFactors
                      data.effectivity = String
                      data.risks = []
                      const existControlInRisks = []
                      var riskName = ''
                      await new Promise(resolve => {
                        mongo.findOne('settings', { _id: 'riskScale' }, (err, sett) => {
                          if (err) {
                            resolve(false)
                          } else {
                            if (sett) {
                              data.riskRanges = sett.riskRanges
                              data.effectivityFactors = sett.effectivityFactors
                            }

                            resolve()
                          }
                        })
                      })
                      data.RI = processAssessments.resultRisks

                      if (process.risks && process.risks.selected.length > 0 && process.risks.selected !== '[]') {
                        for (const r in process.risks.selected) {
                          risk = await new Promise((resolve, reject) => {
                            mongo.findId('risk', process.risks.selected[r], async (err, risk) => {
                              if (err || !risk) {
                                save = false
                                resolve(false)
                              } else {
                                resolve(risk)
                              }
                            })
                          }).catch((err) => console.log(err))
                          if (risk) {
                            if (risk.type === 'risk') {
                              var existControl = 0
                              var riskChildrenMedium = await new Promise((resolve, reject) => {
                                mongo.find('risk', { parent: risk._id }, {}, {}, async (err, risk) => {
                                  if (err || !risk) {
                                    resolve(false)
                                  } else {
                                    resolve(risk)
                                  }
                                })
                              }).catch((err) => console.log(err))

                              for (const children in riskChildrenMedium) {
                                var riskChildrenControl = await new Promise((resolve, reject) => {
                                  mongo.find('risk', { parent: riskChildrenMedium[children]._id }, {}, {}, async (err, risk) => {
                                    if (err || !risk) {
                                      resolve(false)
                                    } else {
                                      resolve(risk)
                                    }
                                  })
                                }).catch((err) => console.log(err))
                                if (riskChildrenControl) {
                                  const pos = riskChildrenControl.findIndex((x) => {
                                    return x.type === 'control'
                                  })
                                  if (pos !== -1) {
                                    existControl++
                                    break
                                  }
                                }
                              }
                              if (existControl > 0) {
                                existControlInRisks.push(true)
                              } else {
                                existControlInRisks.push(false)
                                riskName = risk.name
                              }
                            }
                            data.risks.push(risk)
                          }
                        }
                      } else {
                        msj = 'El proceso ' + process.name + ' no tiene riesgos asociados'
                        save = false
                      }
                      if (data.risks.length > 0) {
                        for (const r in data.risks) {
                          for (const r1 in processAssessments.risks) {
                            if ((data.risks[r]._id.toString() === processAssessments.risks[r1]._id.toString())) {
                              if (processAssessments.risks[r1].result) {
                                data.risks[r].RI = processAssessments.risks[r1].result
                                break
                              }
                            }
                          }
                        }
                        if (existControlInRisks.length > 0) {
                          const pos = existControlInRisks.findIndex((x) => {
                            return x === false
                          })
                          if (pos !== -1) {
                            msj = 'El proceso ' + process.name + ' tiene un riesgo ' + riskName + ' que no tiene controles. No se puede calificar'
                            save = false
                            break
                          } else {
                            save = true
                          }
                        }
                      }

                      if (resultado) {
                        dataArray.push(data)
                      } else {
                        save = false
                      }
                    }
                  } else {
                    msj = 'El proceso no se puede calificar'
                    save = false
                  }
                }
              }
              if (save) {
                mongo.insertMany('controlAssessment', dataArray, (err) => {
                  if (err) {
                    send({ error: err })
                  } else {
                    mongo.save('assessment', { _id: assessment._id, status: 'processing', riskRanges: assessment.riskRanges, effectivityFactors: assessment.effectivityFactors }, () => {
                      send({ resultado: resultado, msj: msj })
                    })
                  }
                })
              } else {
                send({ resultado: save, msj: msj })
              }
            } else {
              send({ resultado: false, msj: '_untypedAssessment' })
            }
          }
        })
      }
    })
  }

  /** Stop SpecificRisk assessment */
  stopSpecificRiskAssessment (req, mongo, send) {
    mongo.find('processAssessment', { assessment: mongo.toId(req.query._id) }, {}, async (err, processAssessments) => {
      if (err || !processAssessments) {
        send({ error: err })
      } else {
        var process
        for (const i in processAssessments) {
          process = await new Promise((resolve, reject) => {
            mongo.findId('process', processAssessments[i].process, async (err, pros) => {
              if (err || !pros) {
                reject(err)
              } else {
                resolve(pros)
              }
            })
          }).catch((err) => console.log(err))

          if (process) {
            process.RI = processAssessments[i].resultRisks
            process.RR = processAssessments[i].resultResidualRisks
            process.assessment = req.query._id
            var result = await new Promise((resolve, reject) => {
              mongo.save('process', process, (err, result) => {
                if (err || !result) {
                  reject(err)
                } else {
                  resolve(true)
                }
              })
            }).catch((err) => console.log(err))

            if (!result) {
              send({ msj: '_error' })
              return
            }
          } else {
            send({ msj: '_error' })
            return
          }
        }
        await this.setAuditablesRisk(mongo)
        await this.setProcessesRisk(mongo)
        mongo.save('assessment', { _id: req.query._id, status: 'done' }, (err, result) => {
          if (err || !result) {
            send({ msj: '_error' })
          } else {
            send({ resultado: true })
          }
        })
      }
    })
  }

  /** Stop factors assessment */
  stopFactorsAssessment (req, mongo, send) {
    mongo.findOne('auditableAssessment', { assessment: mongo.toId(req.query._id) }, async (err, auditableAssesment) => {
      if (err || !auditableAssesment) {
        send({ error: err })
      } else {
        for (const i in auditableAssesment.factors) {
          var auditable = auditableAssesment.factors[i]
          if (auditable.result) {
            await new Promise((resolve, reject) => {
              mongo.findId('assessment', auditableAssesment.assessment, (err, assessment) => {
                if (err) reject(err)
                else {
                  mongo.find('factor', { _id: { $in: assessment.factors } }, { gravity: 1, score: 1, type: 1 }, {}, (err, factors) => {
                    if (err) reject(err)
                    else {
                      auditableAssesment.dataFactors = factors
                      resolve()
                    }
                  })
                }
              })
            }).catch((err) => console.log(err))
            await new Promise((resolve, reject) => {
              mongo.save('auditable', { _id: mongo.toId(auditable.row), result: auditable.result }, (err, res) => {
                if (err) reject(err)
                else resolve()
              })
            }).catch((err) => console.log(err))
          }
        }
        auditableAssesment.dataAuditables = []
        await new Promise((resolve, reject) => {
          mongo.find('auditable', { _id: { $in: auditableAssesment.auditables } }, { RI: 1 }, {}, (err, auditables) => {
            if (err) reject(err)
            else {
              for (var i in auditables) {
                auditableAssesment.dataAuditables.push(auditables[i])
              }
              resolve()
            }
          })
        }).catch((err) => console.log(err))
        auditableAssesment.status = 'done'
        await new Promise((resolve, reject) => {
          mongo.save('auditableAssessment', auditableAssesment, (err, result) => {
            if (err) reject(err)
            else resolve()
          })
        }).catch((err) => console.log(err))
        mongo.save('assessment', { _id: mongo.toId(req.query._id), status: 'done' }, (err, result) => {
          if (err || !result) {
            send({ msj: '_error' })
          } else {
            send({ resultado: true })
          }
        })
      }
    })
  }

  /** Stop Control assessment */
  async stopControlAssessment (req, mongo, send) {
    var effectivity = 0
    var assessment = await new Promise((resolve) => {
      mongo.findId('assessment', req.query._id, async (err, assessment) => {
        if (err) {
          resolve('')
        } else { resolve(assessment) }
      })
    })
    mongo.find('controlAssessment', { assessment: mongo.toId(req.query._id) }, {}, async (err, controlAssessments) => {
      var process
      if (err) {
        console.log(err)
      } else {
        let existEffectivity = false
        let nameRisk = ''
        for (const control in controlAssessments) {
          for (const risk in controlAssessments[control].risks) {
            const arrayRisk = controlAssessments[control].risks[risk]
            if (arrayRisk.type === 'control' && arrayRisk.effectivity) {
              existEffectivity = true
            } if (arrayRisk.type === 'control' && !arrayRisk.effectivity) {
              existEffectivity = false
              nameRisk = arrayRisk.name
              break
            }
          }
          if (!existEffectivity) {
            break
          } else {
            effectivity += parseFloat(controlAssessments[control].processEffectivity)
          }
          process = await new Promise((resolve, reject) => {
            mongo.findId('process', controlAssessments[control].process, async (err, pros) => {
              if (err || !pros) {
                reject(err)
              } else {
                resolve(pros)
              }
            })
          }).catch((err) => console.log(err))

          if (process) {
            if (process.parent !== 0 && process.parent !== '') {
              process.RR = parseFloat(controlAssessments[control].processResidualRisk) + '%'
              process.RI = parseFloat(controlAssessments[control].RI) + '%'
              process.effectivity = parseFloat(controlAssessments[control].processEffectivity) + '%'
              await new Promise(resolve => {
                mongo.save('process', process, (err, result) => {
                  if (err || !result) {
                    resolve()
                  } else {
                    resolve()
                  }
                })
              })
            } else {
              process.RR = parseFloat(controlAssessments[control].processResidualRisk) + '%'
              process.RI = parseFloat(controlAssessments[control].RI) + '%'
              await new Promise(resolve => {
                mongo.save('process', process, (err, result) => {
                  if (err || !result) {
                    resolve()
                  } else {
                    resolve()
                  }
                })
              })
            }
          }
        }
        if (existEffectivity) {
          effectivity = effectivity / controlAssessments.length
          assessment.effectivity = effectivity + '%'
          assessment.status = 'done'
          await this.setProcessesRisk(mongo)
          await this.setAuditablesRisk(mongo)
          mongo.save('assessment', assessment, (err, result) => {
            if (err || !result) {
              send()
            } else {
              send({ resultado: true })
            }
          })
        } else {
          send({ msj: '_unratedControls' + nameRisk }) //'Hay controles sin calificar: '
        }
      }
    })
  }

  async setAuditablesRisk (mongo) {
    var schemes = await new Promise(resolve => {
      mongo.find('auditable', { }, async (err, sches) => {
        if (err || !sches) {
          resolve(false)
        } else {
          resolve(sches)
        }
      })
    })
    if (schemes && schemes.length > 0) {
      for (const j in schemes) {
        var doc = schemes[j]
        if (doc.processes && doc.processes.length === 24) {
          const process1 = await new Promise((resolve, reject) => {
            mongo.find('process', { _id: { $in: doc.processes } }, {}, async (err, pros) => {
              if (err || !pros) {
                reject(err)
              } else {
                resolve(pros)
              }
            })
          }).catch((err) => console.log(err))
          if (process1) {
            if (process1.RI) { doc.RI = process1.RI }
            if (process1.RR) { doc.RR = process1.RR }
            await new Promise((resolve, reject) => {
              mongo.save('auditable', doc, (err, result) => {
                if (err || !result) {
                  reject(err)
                } else {
                  resolve(true)
                }
              })
            }).catch((err) => console.log(err))
          }
        } else if (doc.processes && doc.processes.length > 0) {
          var divRI = 0
          var divRR = 0
          var sumRI = 0
          var sumRR = 0

          const processes = doc.processes
          for (const z in processes) {
            const process2 = await new Promise((resolve, reject) => {
              mongo.findId('process', processes[z], async (err, pros) => {
                if (err || !pros) {
                  reject(err)
                } else {
                  resolve(pros)
                }
              })
            }).catch((err) => console.log(err))
            if (process2) {
              if (process2.RI) {
                sumRI = sumRI + ( process2.RI.split? Number(process2.RI.split('%')[0]) : process2.RI )
                divRI++
              }
              if (process2.RR) {
                sumRR = sumRR + ( process2.RR.split? Number(process2.RR.split('%')[0]) : process2.RR )
                divRR++
              }
            }
          }
          if (sumRI) { doc.RI = (sumRI / divRI) + '%' }
          if (sumRR) { doc.RR = (sumRR / divRR) + '%' }
          doc.result = doc.RI
          await new Promise((resolve, reject) => {
            mongo.save('auditable', doc, (err, result) => {
              if (err || !result) {
                reject(err)
              } else {
                resolve(true)
              }
            })
          }).catch((err) => console.log(err))
        }
      }
      return
    }
  }

  async setProcessesRisk (mongo) {
    let procs = await new Promise(resolve => {
      mongo.find('process', { $or: [{ parent: 0 }, { parent: null }, { parent: '' }] }, async (err, procs) => {
        if (err) console.log(err)
        resolve(procs)
      })
    })
    for (const i in procs) {
      await this.setProcessRisk(mongo, procs[i])
    }
  }

  async setProcessRisk (mongo, process) {
    var risk = await this.getChildrenRisk(mongo, process)
    if (risk.countRR || risk.countRI) {
      delete risk.countRR
      delete risk.countRI
      await new Promise(resolve => {
        mongo.update('process', { _id: process._id }, { $set: risk }, (err, result) => {
          if (err) console.log(err)
          resolve(risk)
        })
      })
    }
    return risk
  }

  async getChildrenRisk (mongo, parent) {
    var risk = { RR: 0, RI: 0, countRI: 0, countRR: 0 }
    await new Promise(resolve => {
      mongo.find('process', { parent: parent._id }, async (err, processes) => {
        if (!err && processes.length) {
          for (const i in processes) {
            var process = processes[i]
            var prisk = await this.setProcessRisk(mongo, process)
            if (prisk.RR) {
              risk.RR += prisk.RR
              ++risk.countRR
            }
            if (prisk.RI) {
              risk.RI += prisk.RI
              ++risk.countRI
            }
          }
          if (risk.countRR) risk.RR /= risk.countRR
          if(risk.countRI) risk.RI /= risk.countRI
        } else {
          risk.RR = parent.RR ? Number(parent.RR.split('%')[0]) : 0
          risk.RI = parent.RI ? Number(parent.RI.split('%')[0]) : 0
        }
        resolve(risk)
      })
    })
    return risk
  }

  /** list Assessments with ProcessAssessments parents */
  list (req, mongo, send) {
    var data = []
    mongo.find('assessment', {}, {}, {}, (err, assessments) => {
      if (err) throw err
      mongo.find('processAssessment', {}, {}, {}, (err, processAssessments) => {
        if (err) throw err
        mongo.find('auditableAssessment', {}, {}, (err, auditableAssessments) => {
          if (err) throw err
          mongo.find('controlAssessment', {}, {}, (err, controlAssessments) => {
            if (err) throw err
            if (!err && assessments.length > 0) {
              for (const i in assessments) {
                var assessment = assessments[i]
                assessment.parent = assessment.parent === '' ? 0 : assessment.parent.toString()
                if (assessment.evaluationMatrix) {
                  assessment.evaluationMatrix = this.clearTable(assessment.evaluationMatrix)
                }
                data.push({
                  id: assessment._id.toString(),
                  name: assessment.name,
                  base: assessment.base,
                  type: assessment.type,
                  period: assessment.period.start + ' ' + tags.to + ' ' + assessment.period.end,
                  status: assessment.status,
                  evaluationMatrix: assessment.evaluationMatrix,
                  evaluationMatrixTable: assessment.evaluationMatrixTable,
                  weight: assessment.weight,
                  description: assessment.description,
                  parent: assessment.parent
                })
              }
              for (const p in processAssessments) {
                var processAssessment = processAssessments[p]
                if (processAssessment.assessment) {
                  data.push({
                    id: processAssessment._id.toString(),
                    name: processAssessment.name,
                    process: processAssessment.process,
                    assessment: processAssessment.assessment ? processAssessment.assessment.toString() : 0,
                    residual: processAssessment.residual,
                    risks: processAssessment.risks,
                    parent: processAssessment.assessment ? processAssessment.assessment.toString() : 0,
                    type: 'process'
                  })
                }
              }
              for (const a in auditableAssessments) {
                var auditableAssessment = auditableAssessments[a]
                data.push({
                  id: auditableAssessment._id.toString(),
                  name: auditableAssessment.name,
                  parent: auditableAssessment.assessment ? auditableAssessment.assessment.toString() : 0,
                  type: 'auditable'
                })
              }
              for (const c in controlAssessments) {
                var controlAssessment = controlAssessments[c]
                if (controlAssessment.assessment) {
                  data.push({
                    id: controlAssessment._id.toString(),
                    name: controlAssessment.name,
                    process: controlAssessment.process,
                    assessment: controlAssessment.assessment ? controlAssessment.assessment.toString() : 0,
                    residual: controlAssessment.residual,
                    risks: controlAssessment.risks,
                    parent: controlAssessment.assessment ? controlAssessment.assessment.toString() : 0,
                    type: 'control'
                  })
                }
              }
              send(data)
            } else {
              send()
            }
          })
        })
      })
    })
  }

  /** clear table values */
  clearTable (table) {
    var Table = html2json(table)
    var rows = Table.child[0].child[0].child
    for (const i in rows) {
      if (i > 0) {
        for (const j in rows[i].child) {
          if (j > 0) {
            var child = rows[i].child[j]
            child.child[0].text = ''
          }
        }
      }
    }
    var result = json2html(Table)
    return result
  }

  /** save Assessment */
  save (req, mongo, send) {
    var doc = req.body
    if (doc.$parent && doc.$parent !== '0') {
      doc.parent = doc.$parent
    } else {
      doc.parent = ''
    }
    if (!doc._id) { doc._id = mongo.isNativeId(doc.id) ? mongo.toId(doc.id) : mongo.newId() }
    if (!doc.status) { doc.status = 'draft' }
    doc.period.start = dateformat(new Date(doc.period.start), 'yyyy/mm/dd')
    doc.period.end = dateformat(new Date(doc.period.end), 'yyyy/mm/dd')
    /** for byFactors */
    if (doc.type === 'byFactors') {
      var factors = []
      factors = doc.factors.length >= 24 ? doc.factors.split(',') : []
      doc.factors = factors
    }

    delete doc.id
    delete doc.open
    delete doc.webix_kids
    delete doc.parent_id
    mongo.save('assessment', doc, (err) => {
      if (err) {
        send({ error: err.toString() })
      } else {
        send({ id: doc._id, parent: doc.parent })
        doc.id = doc._id
        doc.period = doc.period.start + ' ' + tags.to + ' ' + doc.period.end
        notification.send(req, req.session.context.room, 'dt_assessment', doc, null, null)
      }
    })
  }
  //duplicar calificacion de riesgo especifico
  duplicate (req, mongo, send) {
    var id = req.query._id
    mongo.findOne('assessment', { _id: mongo.toId(id) }, {}, (err, doc) => {
      if (err || !doc) {
        if(err) console.log(err)
        send()
      } else {
        mongo.find('processAssessment', { assessment: doc._id }, {}, async (err, procs) => {
          if (err) {
            console.log(err)
            send()
          } else {
            doc._id = mongo.newId()
            doc.status = 'processing'
            let continuar = true
            await new Promise(resolve => {
              mongo.save('assessment', doc, (err) => {
                if (err) {
                  console.log(err)
                  continuar = false
                  resolve()
                } else {
                  resolve()
                }
              })
            })
            if (continuar) {
              for (let i in procs) {
                procs[i]._id = mongo.newId()
                procs[i].assessment = doc._id
                await new Promise(resolve => {
                  mongo.save('processAssessment', procs[i], () => {
                    resolve()
                  })
                })
              }
            }
            send()
          }
        })
      }
    })
  }

  /** delete Assessment and Process Assessment kids */
  delete (req, mongo, send) {
    var doc = req.query
    mongo.findId('assessment', mongo.toId(doc._id), (err, assessment) => {
      if (err) throw err
      mongo.find('unitAssessment', { parent: mongo.toId(doc._id) }, {}, {}, (err, unitKids) => {
        if (err) throw err
        var idUnits = []
        for (const i in unitKids) {
          idUnits.push(unitKids[i]._id)
        }
        mongo.find('processAssessment', { parent: mongo.toId(doc._id) }, {}, {}, (err, processKids) => {
          if (err) throw err
          var idProcess = []
          for (const i in processKids) {
            idProcess.push(processKids[i]._id)
          }
          mongo.deleteOne('unitAssessment', { _id: { $in: idUnits } }, () => {
            mongo.deleteOne('processAssessment', { _id: { $in: idProcess } }, () => {
              mongo.deleteOne('assessment', { _id: mongo.toId(doc._id) }, async (err) => {
                if (err) {
                  req.logger.log(err)
                } else {
                  if (unitKids.length > 0) {
                    for (const u in unitKids) {
                      await new Promise(resolve => {
                        req.app.routes.trash.insert(req, mongo, 'unitAssessment', unitKids[u], () => {
                          resolve()
                        })
                      })
                    }
                  }
                  if (processKids.length > 0) {
                    for (const p in processKids) {
                      await new Promise(resolve => {
                        req.app.routes.trash.insert(req, mongo, 'processAssessment', processKids[p], () => {
                          resolve()
                        })
                      })
                    }
                  }
                  req.app.routes.trash.insert(req, mongo, 'assessment', assessment, () => {
                    send({ message: tags.savedChanges })
                    doc.id = doc._id
                    notification.send(req, req.session.context.room, 'dt_assessment', doc, null, true)
                  })
                }
              })
            })
          })
        })
      })
    })
  }
}

exports.Assessment = Assessment
