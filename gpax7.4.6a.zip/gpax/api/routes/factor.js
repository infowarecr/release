/* exported */
exports.Factor = Factor
var Notification = require('../utils/notification').Notification
var notification = new Notification()

function Factor () {
  /** get Factor */
  this.get = function (req, mongo, send) {
    mongo.findId('factor', req.query._id, (err, factor) => {
      if (err) {
        send({ error: err })
      } else {
        factor ? send(factor) : send({ _id: mongo.newId() })
      }
    })
  }
  /** list Factors */
  this.list = function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    mongo.findN('factor', skip, limit, {}, {}, {}, (err, factors) => {
      if (err || !factors) {
        send({ error: err })
      } else {
        for (const f in factors) {
          factors[f].id = factors[f]._id
        }
        reply.data = factors
        if (skip) {
          send(reply)
        } else {
          mongo.count('factor', {}, (err, count) => {
            if (!err && count) {
              reply.total_count = count
            }
            send(reply.data)
          })
        }
      }
    })
  }
  this.asOptions = function (req, mongo, send) {
    mongo.find('factor', {}, { name: 1 }, (err, facts) => {
      if (err || !facts) {
        send({ error: err })
      } else {
        var factors = []
        for (const f in facts) {
          factors.push({ id: facts[f]._id, value: facts[f].name })
        }
        send(factors)
      }
    })
  }
  /** find specific factor */
  this.findFactor = function (req, mongo, send) {
    mongo.findId('factor', req.query._id, (err, factor) => {
      if (err) {
        send({ error: err })
      } else {
        send({ score: factor.score })
      }
    })
  }

  /** save Factor */
  this.save = function (req, mongo, send) {
    var doc = req.body
    if (!doc._id) {
      doc._id = mongo.newId()
    }
    mongo.save('factor', doc, (err, result) => {
      if (err) {
        send({ error: err })
      } else {
        send()
        doc.id = doc._id
        notification.send(req, req.session.context.room, 'dt_factors', doc, null, null)
      }
    })
  }
  /** delete factor */
  this.delete = function (req, mongo, send) {
    var doc = req.query
    mongo.findId('factor', mongo.toId(doc._id), (err, factor) => {
      if (err) {
        send({ error: err })
      } else {
        mongo.deleteOne('factor', { _id: mongo.toId(doc._id) }, (err, result) => {
          if (err) {
            req.logger.log(err)
          } else {
            req.app.routes.trash.insert(req, mongo, 'factor', factor, () => {
              send()
              doc.id = doc._id
              notification.send(req, req.session.context.room, 'dt_factors', doc, null, true)
            })
          }
        })
      }
    })
  }
}
