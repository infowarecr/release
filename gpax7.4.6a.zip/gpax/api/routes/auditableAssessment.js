/* exported */
exports.AuditableAssessment = AuditableAssessment

function AuditableAssessment () {
  this.get = function (req, mongo, send) {
    var reply = { data: [], factors: [] }
    mongo.findId('auditableAssessment', req.query._id, (err, doc) => {
      if (err) {
        send({ error: err })
      } else {
        reply.support = doc.support
        mongo.findId('assessment', doc.assessment, (err, assessment) => {
          if (err) {
            send({ error: err })
          } else {
            if (doc && doc.auditables.length > 0 && assessment && assessment.factors.length > 0) {
              mongo.find('factor', { _id: { $in: assessment.factors } }, {}, {}, (err, factors) => {
                if (err) {
                  send({ error: err })
                } else {
                  mongo.find('auditable', { _id: { $in: doc.auditables } }, {}, {}, async (err, auditables) => {
                    if (err) {
                      send({ error: err })
                    } else {
                      var maxGravity = 0
                      if (!doc.status || doc.status !== 'done') {
                        for (const i in auditables) {
                          var auditable = auditables[i]
                          reply.data.push({
                            id: auditable._id,
                            name: auditable.name,
                            RI: auditable.RI,
                            RR: auditable.RR,
                            result: 0
                          })
                        }
                        for (const f in factors) {
                          if (factors[f].type !== 'risk') { maxGravity += parseFloat(factors[f].gravity) }
                          var maxValue = 0
                          for (const t in factors[f].score) {
                            var value = parseFloat(factors[f].score[t].value)
                            maxValue = maxValue < value ? value : maxValue
                          }
                          factors[f].rows = []
                          factors[f].maxValue = maxValue
                          if (doc.factors) {
                            for (const l in doc.factors) {
                              if (doc.factors[l].factor.toString() === factors[f]._id.toString()) {
                                var result = 0
                                for (const p in factors[f].score) {
                                  if (factors[f].score[p].id.toString() === doc.factors[l].value.toString()) {
                                    result = parseFloat(factors[f].score[p].value) / maxValue
                                    result = parseFloat(result) * 100
                                    result = result * factors[f].gravity
                                    // result = parseFloat(result.toFixed(2));
                                    break
                                  }
                                }
                                factors[f].rows.push({
                                  value: doc.factors[l].value.toString(),
                                  row: doc.factors[l].row.toString(),
                                  result: result
                                })
                              }
                            }
                          }
                          reply.factors.push(factors[f])
                        }
                        for (const x in reply.data) {
                          const data = reply.data[x]
                          for (const c in reply.factors) {
                            for (const t in reply.factors[c].rows) {
                              const row = reply.factors[c].rows[t]
                              if (data.id.toString() === row.row) {
                                data.result = parseFloat(data.result) + parseFloat(row.result) / maxGravity
                                data.result = parseFloat(data.result.toFixed(2)) + '%'
                              }
                            }
                          }
                        }
                        for (const c in reply.factors) {
                          if (reply.factors[c].type === 'residualRisk') {
                            for (var k in reply.data) {
                              var doc2 = reply.data[k]
                              if (doc2.RI) {
                                var result2 = parseFloat(doc2.RI) * parseFloat(reply.factors[c].gravity)
                                result2 = result2 / maxGravity
                                doc2.result = parseFloat(doc2.result) + result2
                                doc2.result = parseFloat(parseFloat(doc2.result).toFixed(2)) + '%'
                              }
                            }
                          }
                        }
                        for (const h in reply.data) {
                          const data = reply.data[h]
                          for (const d in doc.factors) {
                            if (data.id.toString() === doc.factors[d].row.toString()) {
                              doc.factors[d].result = data.result
                              await new Promise(resolve => {
                                mongo.save('auditableAssessment', doc, (err, result) => {
                                  if (err) throw err
                                  resolve()
                                })
                              })
                              break
                            }
                          }
                          for (const k in assessment.riskRanges) {
                            var ranges = assessment.riskRanges[k]
                            if (data.result && ranges.to && ranges.from) {
                              if (parseFloat(data.result) >= parseFloat(ranges.from) && parseFloat(data.result) <= parseFloat(ranges.to)) {
                                data.$cellCss = {}
                                data.$cellCss.result = { 'background-color': ranges.color, color: ranges.textColor }
                              }
                            }
                            if (data.RI && data.RI !== '' && ranges.to && ranges.from) {
                              if (parseFloat(data.RI) >= parseFloat(ranges.from) && parseFloat(data.RI) <= parseFloat(ranges.to)) {
                                data.$cellCss = data.$cellCss || {}
                                data.$cellCss.RI = { 'background-color': ranges.color, color: ranges.textColor }
                              }
                            }
                            if (data.RR && data.RR !== '' && ranges.to && ranges.from) {
                              if (parseFloat(data.RR) >= parseFloat(ranges.from) && parseFloat(data.RR) <= parseFloat(ranges.to)) {
                                data.$cellCss = data.$cellCss || {}
                                data.$cellCss.RR = { 'background-color': ranges.color, color: ranges.textColor }
                              }
                            }
                          }
                        }
                        reply.maxGravity = maxGravity
                        send(reply)
                      } else {
                        for (const i in doc.dataAuditables) {
                          const auditable = doc.dataAuditables[i]
                          const name = await new Promise((resolve, reject) => {
                            mongo.findOne('auditable', { _id: auditable._id }, { name: 1 }, (err, aud) => {
                              if (err) reject(err)
                              else resolve(aud.name)
                            })
                          }).catch((err) => console.log(err))
                          reply.data.push({
                            id: auditable._id,
                            name: name,
                            RI: auditable.RI,
                            result: 0
                          })
                        }
                        for (const f in doc.dataFactors) {
                          const factors = doc.dataFactors
                          factors[f].name = await new Promise((resolve, reject) => {
                            mongo.findOne('factor', { _id: factors[f]._id }, { name: 1 }, (err, fac) => {
                              if (err) reject(err)
                              else resolve(fac.name)
                            })
                          })
                          if (factors[f].type !== 'risk') { maxGravity += parseFloat(factors[f].gravity) }
                          let maxValue = 0
                          for (const t in factors[f].score) {
                            const value = parseFloat(factors[f].score[t].value)
                            maxValue = maxValue < value ? value : maxValue
                          }
                          factors[f].rows = []
                          factors[f].maxValue = maxValue
                          if (doc.factors) {
                            for (const l in doc.factors) {
                              if (doc.factors[l].factor.toString() === factors[f]._id.toString()) {
                                let result = 0
                                for (const p in factors[f].score) {
                                  if (factors[f].score[p].id.toString() === doc.factors[l].value.toString()) {
                                    result = parseFloat(factors[f].score[p].value) / maxValue
                                    result = parseFloat(result) * 100
                                    result = result * factors[f].gravity
                                    // result = parseFloat(result.toFixed(2));
                                    break
                                  }
                                }
                                factors[f].rows.push({
                                  value: doc.factors[l].value.toString(),
                                  row: doc.factors[l].row.toString(),
                                  result: result
                                })
                              }
                            }
                          }
                          reply.factors.push(factors[f])
                        }
                        for (const x in reply.data) {
                          const data = reply.data[x]
                          for (const c in reply.factors) {
                            for (const t in reply.factors[c].rows) {
                              const row = reply.factors[c].rows[t]
                              if (data.id.toString() === row.row) {
                                data.result = parseFloat(data.result) + parseFloat(row.result) / maxGravity
                                data.result = parseFloat(data.result.toFixed(2)) + '%'
                              }
                            }
                          }
                        }
                        for (const c in reply.factors) {
                          if (reply.factors[c].type === 'residualRisk') {
                            for (const k in reply.data) {
                              const doc2 = reply.data[k]
                              if (doc2.RI) {
                                let result2 = parseFloat(doc2.RI) * parseFloat(reply.factors[c].gravity)
                                result2 = result2 / maxGravity
                                doc2.result = parseFloat(doc2.result) + result2
                                doc2.result = parseFloat(parseFloat(doc2.result).toFixed(2)) + '%'
                              }
                            }
                          }
                        }
                        for (const h in reply.data) {
                          const data = reply.data[h]
                          for (const k in assessment.riskRanges) {
                            const ranges = assessment.riskRanges[k]
                            if (data.result && ranges.to && ranges.from) {
                              if (parseFloat(data.result) >= parseFloat(ranges.from) && parseFloat(data.result) <= parseFloat(ranges.to)) {
                                data.$cellCss = {}
                                data.$cellCss.result = { 'background-color': ranges.color, color: ranges.textColor }
                              }
                            }
                            if (data.RI && data.RI !== '' && ranges.to && ranges.from) {
                              if (parseFloat(data.RI) >= parseFloat(ranges.from) && parseFloat(data.RI) <= parseFloat(ranges.to)) {
                                data.$cellCss = data.$cellCss || {}
                                data.$cellCss.RI = { 'background-color': ranges.color, color: ranges.textColor }
                              }
                            }
                            if (data.RR && data.RR !== '' && ranges.to && ranges.from) {
                              if (parseFloat(data.RR) >= parseFloat(ranges.from) && parseFloat(data.RR) <= parseFloat(ranges.to)) {
                                data.$cellCss = data.$cellCss || {}
                                data.$cellCss.RR = { 'background-color': ranges.color, color: ranges.textColor }
                              }
                            }
                          }
                        }
                        reply.maxGravity = maxGravity
                        send(reply)
                      }
                    }
                  })
                }
              })
            } else {
              send()
            }
          }
        })
      }
    })
  }
  this.save = function (req, mongo, send) {
    var doc = req.body
    mongo.findId('auditableAssessment', doc._id, { factors: 1 }, (err, auditableAssessment) => {
      if (err) {
        send({ error: err })
      } else {
        if (doc.support || doc.support === '') {
          auditableAssessment.support = doc.support
        } else {
          if (auditableAssessment.factors) {
            var exist = false
            for (const i in auditableAssessment.factors) {
              var f = auditableAssessment.factors[i]
              if (doc.factor.toString() === f.factor.toString() && doc.row.toString() === f.row.toString()) {
                f.value = doc.value
                exist = true
                break
              }
            }
            if (!exist) {
              auditableAssessment.factors.push({ row: doc.row, value: doc.value, factor: doc.factor })
            }
          } else {
            auditableAssessment.factors = [{ row: doc.row, value: doc.value, factor: doc.factor }]
          }
        }

        mongo.save('auditableAssessment', auditableAssessment, (err, result) => {
          if (err) {
            send({ error: err })
          } else {
            send()
          }
        })
      }
    })
  }
  this.refresh = async (req, mongo, send) => {
    var auditables = req.body.auditables
    for (var i in auditables) {
      await new Promise(resolve => {
        mongo.findId('auditable', mongo.toId(auditables[i]), async (err, auditable) => {
          if (err) {
            resolve()
          } else {
            var doc = auditable
            if (doc.processes && doc.processes.length > 0) {
              var divRI = 0
              var divRR = 0
              var sumRI = 0
              var sumRR = 0

              const processes = doc.processes
              for (const z in processes) {
                const process2 = await new Promise((resolve, reject) => {
                  mongo.findId('process', processes[z], async (err, pros) => {
                    if (err || !pros) {
                      reject(err)
                    } else {
                      resolve(pros)
                    }
                  })
                }).catch((err) => console.log(err))
                if (process2) {
                  if (process2.RI) {
                    sumRI = sumRI + process2.RI.split ? Number(process2.RI.split('%')[0]) : Number(process2.RI)
                    divRI++
                  }
                  if (process2.RR) {
                    sumRR = sumRR + process2.RR.split ? Number(process2.RR.split('%')[0]) : Number(process2.RR)
                    divRR++
                  }
                }
              }
              if (sumRI) { doc.RI = (sumRI / divRI).toFixed(2) + '%' } else { doc.RI = '' }
              if (sumRR) { doc.RR = (sumRR / divRR).toFixed(2) + '%' } else { doc.RR = '' }
              await new Promise((resolve, reject) => {
                mongo.save('auditable', doc, (err, result) => {
                  if (err || !result) {
                    reject(err)
                  } else {
                    resolve(true)
                  }
                })
              }).catch((err) => console.log(err))
            } else if (doc.processes && doc.processes.length === 0) {
              doc.RI = ''
              doc.RR = ''
              await new Promise((resolve, reject) => {
                mongo.save('auditable', doc, (err, result) => {
                  if (err || !result) {
                    reject(err)
                  } else {
                    resolve(true)
                  }
                })
              }).catch((err) => console.log(err))
            }
            resolve()
          }
        })
      })
    }
    send()
  }
}
