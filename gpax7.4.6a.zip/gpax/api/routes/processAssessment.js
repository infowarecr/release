/* exported */
var tags = require('../utils/tags').tags
exports.ProcessAssessment = ProcessAssessment

var html2json = require('html2json').html2json
var json2html = require('html2json').json2html
const Entities = require('html-entities').AllHtmlEntities
var Notification = require('../utils/notification').Notification
var notification = new Notification()

const entities = new Entities()
function ProcessAssessment () {
  /** get document ProcessAssessment */
  this.get = function (req, mongo, send) {
    if (req.query._id) {
      mongo.findId('processAssessment', req.query._id, (err, assessment) => {
        if (err)console.log(err)
        if (!err) {
          send(assessment)
        } else {
          send()
        }
      })
    } else {
      send({ _id: mongo.newId(), process: req.query.process, name: req.query.name, parent: req.query.parent, user: req.session.context.user })
    }
  }
  /** save process Assessment */
  this.save = function (req, mongo, send) {
    var doc = req.body
    doc.risks = []
    delete doc.riskId
    delete doc.evaluationMatrix
    var grid = doc.calification
    if (grid === '[]') grid = []
    /** data of risks calification */
    for (const g in grid) {
      var row = grid[g]
      delete row.$cellCss
      delete row.data
      delete row.id
      doc.risks.push(row)
    }

    delete doc.id
    delete doc.open
    delete doc.webix_kids
    delete doc.calification
    mongo.save('processAssessment', doc, async (err, result) => {
      if (err) {
        send({ error: err.toString() })
      } else {
        var assessment = await new Promise(resolve => {
          mongo.findId('assessment', doc.assessment, async (err, asse) => {
            if (err || !asse) {
              resolve(false)
            } else {
              resolve(asse)
            }
          })
        }).catch((err) => console.log(err))
        if (assessment) {
          var ProcessAssessments = await new Promise(resolve => {
            mongo.find('processAssessment', { assessment: mongo.toId(doc.assessment) }, async (err, pros) => {
              if (err || !pros) {
                resolve(false)
              } else {
                resolve(pros)
              }
            })
          })
          var divRI = 0
          var divRR = 0
          var sumRI = 0
          var sumRR = 0

          for (const z in ProcessAssessments) {
            var process2 = ProcessAssessments[z]
            if (process2) {
              if (process2.resultRisks) {
                sumRI = sumRI + Number(process2.resultRisks.split('%')[0])
                divRI++
              }
              if (process2.resultResidualRisks) {
                sumRR = sumRR + Number(process2.resultResidualRisks.split('%')[0])
                divRR++
              }
            }
          }
          if (sumRI) { assessment.RI = (sumRI / divRI).toFixed(2) + '%' }
          if (sumRR) { assessment.RR = (sumRR / divRR).toFixed(2) + '%' }

          await new Promise(resolve => {
            mongo.save('assessment', assessment, (err, result) => {
              if (err || !result) {
                resolve(false)
              } else {
                resolve(result)
              }
            })
          }).catch((err) => console.log(err))
        }
        send({ id: doc._id, parent: doc.parent, calification: doc.calificationControls })
      }
    })
  }
  /** get organogram for Unit and Process */
  this.getOrganogram = function (req, mongo, send) {
    var data = []
    var collectionAssessment
    if (req.query.collection === 'unit') {
      collectionAssessment = 'unitAssessment'
    } else {
      collectionAssessment = 'processAssessment'
    }
    mongo.find(req.query.collection, {}, {}, {}, (err, units) => {
      if (err) throw err
      for (const i in units) {
        units[i].parent = units[i].parent === '' ? 0 : units[i].parent.toString()
        data.push({ id: units[i]._id.toString(), value: units[i].name, parent: units[i].parent })
      }
      mongo.findId('assessment', req.query._id, (err, assessment) => {
        if (err) throw err
        mongo.find(collectionAssessment, { parent: mongo.toId(req.query._id) }, {}, {}, (err, collAssessments) => {
          if (err) throw err
          if (assessment && assessment.criticalityTable) {
            for (const i in collAssessments) {
              for (const j in data) {
                if (collAssessments[i].name === data[j].value) {
                  var color = this.getColor(assessment.criticalityTable, collAssessments[i].ImpactRisks, collAssessments[i].Probability)
                  data[j].$css = { background: color }
                  data[j].value = data[j].value + '</br>' + collAssessments[i].resultRisks
                }
              }
            }
          }
          send(data)
        })
      })
    })
  }
  /** get cellColor for Organogram */
  this.getColor = function (table, impact, probability) {
    var index = table[0].indexOf(impact)
    var color
    if (index !== -1) {
      for (const r in table[1]) {
        var doc = table[1]
        if (r === probability) {
          color = doc[r][index].color
          break
        }
      }
    }
    return color
  }
  /** get table for organogram */
  this.getTable = function (req, mongo, send) {
    var collectionAssessment
    if (req.query.collection === 'unit') { collectionAssessment = 'unitAssessment' } else { collectionAssessment = 'processAssessment' }

    mongo.findId('assessment', req.query._id, (err, assessment) => {
      if (err) throw err
      if (assessment && assessment.criticality) {
        var table = this.clearTable(assessment.criticality)
        mongo.find(collectionAssessment, { parent: mongo.toId(req.query._id) }, {}, {}, (err, collAssessments) => {
          if (err) throw err
          var Table = html2json(table)
          var rows = Table.child[0].child[0].child
          var impact
          for (const u in collAssessments) {
            for (const i in rows[0].child) {
              if (i > 0) {
                if (entities.decode(rows[0].child[i].child[0].text) === collAssessments[u].ImpactRisks) {
                  impact = i
                  break
                }
              }
            }
            if (impact) {
              for (const j in rows) {
                if (j > 0) {
                  if (entities.decode(rows[j].child[0].child[0].text) === collAssessments[u].Probability) {
                    if (!rows[j].child[impact].child) {
                      rows[j].child[impact].child = []
                      rows[j].child[impact].child.push({ node: 'text', text: 1 })
                    } else {
                      rows[j].child[impact].child[0].node = 'text'
                      rows[j].child[impact].child[0].text = rows[j].child[impact].child[0].text + 1
                    }
                    break
                  }
                }
              }
            }
          }

          var result = json2html(Table)
          send({ table: result })
        })
      } else {
        send()
      }
    })
  }
  /** load risk and calification */
  this.riskCalification = async function (req, mongo, send, recycle) {
    let result = await new Promise(resolve => {
      mongo.findId('processAssessment', mongo.toId(req.body.id) || mongo.toId(req.body._id), (err, res) => {
        if (err) throw err
        var riskFactors = []
        for (const i in res.risks) {
          var risk = res.risks[i]
          if (risk.type === 'riskFactor') {
            riskFactors.push(risk._id)
          }
        }
        mongo.aggregate('riskEvent', [
          { $match: { riskFactor: { $in: riskFactors } } },
          { $group: { _id: '$riskFactor', count: { $sum: 1 } } }
        ], {}, (err, events) => {
          if (err) console.log(err)
          for (const i in events) {
            res.risks.findIndex((it) => {
              if (it._id.toString() === events[i]._id.toString()) {
                it.events = events[i].count
                return true
              }
            })
          }
          resolve(res.risks)
        })
      })
    })
    if (recycle) {
      return result
    } else {
      send(result)
    }
  }
  /** delete  ProcessAssessment */
  this.delete = function (req, mongo, send) {
    var doc = req.query
    mongo.findId('processAssessment', mongo.toId(doc._id), (err, processAssessment) => {
      if (err) {
        send({ error: err })
      } else {
        mongo.deleteOne('processAssessment', { _id: mongo.toId(doc._id) }, (err, result) => {
          if (err) {
            req.logger.log(err)
          } else {
            req.app.routes.trash.insert(req, mongo, 'processAssessment', processAssessment, () => {
              send({ message: tags.savedChanges })
              doc.id = doc._id
              notification.send(req, req.session.context.room, 'dt_assessment', doc, null, true)
            })
          }
        })
      }
    })
  }

  this.saveRiskFactorChanges = async function (req, mongo, send) {
    var doc = req.body
    var control = doc.result
    var deletedControl = doc.deleted
    var calificationResult = []

    var processAssessment = await this.riskCalification(req, mongo, send, true)

    if (control === '[]') control = []
    if (deletedControl === '[]') deletedControl = []

    var resultadoProcess = await new Promise(resolve => {
      mongo.findId('process', mongo.toId(doc.process), async (err, process) => {
        if (err || !process) {
          resolve(false)
        } else {
          resolve(process)
        }
      })
    })

    if (control.length > 0) {
      for (const c in control) {
        var save = false
        var row = control[c]
        delete row.id
        delete row.ch1
        delete row.deleted
        var existRisk = await new Promise(resolve => {
          mongo.find('risk', { type: 'riskFactor', _id: mongo.toId(row._id), parent: mongo.toId(row.parent) }, {}, {}, async (err, risk) => {
            if (err) {
              resolve()
              console.log(err)
            } else {
              resolve(risk)
            }
          })
        })
        if (existRisk.length > 0) {
          const posNew = processAssessment.findIndex((x) => {
            return x._id.toString() === control[c]._id.toString()
          })

          var risksSelected = resultadoProcess.risks.selected
          const pos = risksSelected.findIndex((x) => {
            return x.toString() === control[c]._id.toString()
          })

          if (posNew === -1) {
            doc.risks.push(row)
            await new Promise(resolve => {
              mongo.find('risk', { type: 'control', parent: mongo.toId(row._id) }, {}, {}, async (err, controls) => {
                if (err) {
                  resolve()
                  console.log(err)
                } else {
                  for (let i in controls) {
                    doc.risks.push(controls[i])
                  }
                  resolve()
                }
              })
            })
            save = true
          } else {
            save = false
          }
          if (save) {
            if (pos === -1) {
              resultadoProcess.risks.selected.push(row._id)
            }
            await new Promise(resolve => {
              mongo.save('process', resultadoProcess, async (err, result) => {
                if (err) {
                  resolve()
                } else {
                  resolve()
                }
              })
            })
          }
        }
      }
    }

    if (deletedControl.length > 0) {
      for (const c in deletedControl) {
        save = false
        row = deletedControl[c]
        delete row.id
        delete row.ch1
        delete row.deleted
        var existRisk2 = await new Promise(resolve => {
          mongo.find('risk', { type: 'riskFactor', _id: mongo.toId(row._id), parent: mongo.toId(row.parent) }, {}, {}, async (err, risk) => {
            if (err) {
              resolve()
              console.log(err)
            } else {
              resolve(risk)
            }
          })
        })
        if (existRisk2.length > 0) {
          risksSelected = resultadoProcess.risks.selected
          var pos = risksSelected.findIndex((x) => {
            return x.toString() === deletedControl[c]._id.toString()
          })
          var posDeleted = processAssessment.findIndex((x) => {
            return (x._id.toString() === deletedControl[c]._id.toString())
          })

          if (posDeleted !== -1) {
            var posD = doc.risks.findIndex((x) => {
              return (x._id.toString() === deletedControl[c]._id.toString())
            })
            if (posD !== -1) {
              let volver = true
              var find = (array, pd) => {
                volver = false
                for (let i in array) {
                  if (array[i] && array[i].parent.toString() === array[pd]._id.toString()) {
                    array.splice(i, 1)
                    volver = true
                    break
                  }
                }
                if (volver) {
                  posD = array.findIndex((x) => {
                    return (x._id.toString() === deletedControl[c]._id.toString())
                  })
                  find(array, posD)
                }
              }
              find(doc.risks, posD)
              posD = doc.risks.findIndex((x) => {
                return (x._id.toString() === deletedControl[c]._id.toString())
              })
              doc.risks.splice(posD, 1)
              save = true
            }
          } else {
            save = false
          }

          if (save) {
            if (pos !== -1) {
              resultadoProcess.risks.selected.splice(pos, 1)
            }
            await new Promise(resolve => {
              mongo.save('process', resultadoProcess, async (err, result) => {
                if (err) {
                  resolve()
                } else {
                  resolve()
                }
              })
            })
          }
        }
      }
    }

    calificationResult = doc.risks
    delete doc.result
    delete doc.deleted
    delete doc.calification
    mongo.save('processAssessment', doc, async (err, result) => {
      if (err) {
        send({ error: err.toString() })
      } else {
        send({ calification: calificationResult })
      }
    })
  }

  this.saveRiskChanges = async function (req, mongo, send) {
    var doc = req.body
    var control = doc.result
    var deletedControl = doc.deleted
    var calificationResult = []

    var processAssessment = await this.riskCalification(req, mongo, send, true)

    if (control === '[]') control = []
    if (deletedControl === '[]') deletedControl = []

    var resultadoProcess = await new Promise(resolve => {
      mongo.findId('process', mongo.toId(doc.process), async (err, process) => {
        if (err || !process) {
          resolve(false)
        } else {
          resolve(process)
        }
      })
    })

    if (control.length > 0) {
      for (const c in control) {
        var save = false
        var row = control[c]
        delete row.id
        delete row.ch1
        delete row.deleted
        var existRisk = await new Promise(resolve => {
          mongo.find('risk', { type: 'risk', $or: [ { parent: '' }, { parent: 0 }, { parent: { $exists: 0} } ] }, {}, {}, async (err, risk) => {
            if (err) {
              resolve()
              console.log(err)
            } else {
              resolve(risk)
            }
          })
        })
        if (existRisk.length > 0) {
          const posNew = processAssessment.findIndex((x) => {
            return x._id.toString() === control[c]._id.toString()
          })

          var risksSelected = resultadoProcess.risks.selected
          const pos = risksSelected.findIndex((x) => {
            return x.toString() === control[c]._id.toString()
          })

          if (posNew === -1) {
            doc.risks.push(row)
            save = true
          } else {
            save = false
          }
          if (save) {
            if (pos === -1) {
              resultadoProcess.risks.selected.push(row._id)
            }
            await new Promise(resolve => {
              mongo.save('process', resultadoProcess, async (err, result) => {
                if (err) {
                  resolve()
                } else {
                  resolve()
                }
              })
            })
          }
        }
      }
    }

    if (deletedControl.length > 0) {
      for (const c in deletedControl) {
        save = false
        row = deletedControl[c]
        delete row.id
        delete row.ch1
        delete row.deleted
        var existRisk2 = await new Promise(resolve => {
          mongo.find('risk', { type: 'risk', $or: [ { parent: '' }, { parent: 0 }, { parent: { $exists: 0} } ] }, {}, {}, async (err, risk) => {
            if (err) {
              resolve()
              console.log(err)
            } else {
              resolve(risk)
            }
          })
        })
        if (existRisk2.length > 0) {
          risksSelected = resultadoProcess.risks.selected
          var pos = risksSelected.findIndex((x) => {
            return x.toString() === deletedControl[c]._id.toString()
          })
          var posDeleted = processAssessment.findIndex((x) => {
            return (x._id.toString() === deletedControl[c]._id.toString())
          })

          if (posDeleted !== -1) {
            var posD = doc.risks.findIndex((x) => {
              return (x._id.toString() === deletedControl[c]._id.toString())
            })
            if (posD !== -1) {
              let volver = true
              let parentDelete = []
              var find = (array, pd) => {
                volver = false
                for (let i in array) {
                  if (array[i] && array[i].parent.toString() === array[pd]._id.toString()) {
                    parentDelete.push(array[i]._id)
                    array.splice(i, 1)
                    volver = true
                    break
                  }
                }
                if (volver) {
                  posD = array.findIndex((x) => {
                    return (x._id.toString() === deletedControl[c]._id.toString())
                  })
                  find(array, posD)
                }
              }
              find(doc.risks, posD)
              var find2 = (array) => {
                volver = false
                for (let l in doc.risks) {
                  for (let d in parentDelete) {
                    if (doc.risks[l] && doc.risks[l].parent.toString() === parentDelete[d].toString()) {
                      doc.risks.splice(l, 1)
                      volver = true
                      break
                    }
                  }
                  if(volver) break
                }
                if (volver) {
                  posD = array.findIndex((x) => {
                    return (x._id.toString() === deletedControl[c]._id.toString())
                  })
                  find2(array)
                }
              }
              find2(doc.risks)
              posD = doc.risks.findIndex((x) => {
                return (x._id.toString() === deletedControl[c]._id.toString())
              })
              doc.risks.splice(posD, 1)
              save = true
            }
          } else {
            save = false
          }

          if (save) {
            if (pos !== -1) {
              resultadoProcess.risks.selected.splice(pos, 1)
            }
            await new Promise(resolve => {
              mongo.save('process', resultadoProcess, async (err, result) => {
                if (err) {
                  resolve()
                } else {
                  resolve()
                }
              })
            })
          }
        }
      }
    }

    calificationResult = doc.risks
    delete doc.result
    delete doc.deleted
    delete doc.calification
    mongo.save('processAssessment', doc, async (err, result) => {
      if (err) {
        send({ error: err.toString() })
      } else {
        send({ calification: calificationResult })
      }
    })
  }
}
