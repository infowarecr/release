var tags = require('../utils/tags').tags
/* exported */
exports.Activity = Activity

function Activity () {
  this.list = async function (req, mongo, send) {
    const query = {}
    let existFilter = false
    if (req.query.filter) {
      for (const name in req.query.filter) {
        if (req.query.filter[name].length > 0 && req.query.filter[name] !== 'null') {
          if (name === 'template') {
            query.template = mongo.toId(req.query.filter.template)
          } else if (name === 'name') {
            query.name = new RegExp(req.query.filter.name, 'i')
          } else if (name === 'tag') {
            query.tagActivity = mongo.toId(req.query.filter.tag)
          } else if (name === 'active') {
            query.active = req.query.filter.active === 'Si' ? '1' : '0'
          } else if (name === 'unitCode') {
            query.$or = [
              { units: mongo.toId(req.query.filter.unitCode) },
              { units: new RegExp(req.query.filter.unitCode, 'i') }
            ]
          }
          existFilter = true
        }
      }
    }
    var myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits)
    var myAndDependentUnits = req.session.context.dependentUnits.concat(myUnits)
    var pipeline = [
      { $match: req.query.active ? { active: '1' } : {} },
      { $lookup: { from: 'template', localField: 'template', foreignField: '_id', as: 'ttemplate' } },
      {
        $match: {
          $and: [
            {
              $or: [
                { units: { $in: req.session.context.managerUnits.concat(req.session.context.assistantUnits).concat(req.session.context.membersUnits) } },
                { 'units.0': { $exists: 0 } }
              ]
            }
          ]
        }
      },
      {
        $lookup: {
          from: 'unit',
          pipeline: [
              { $project: { _id: { $toString: '$_id' }, name: 1 } }
          ],
          as: 'tunits'
        }
      },
      {
        $lookup: {
          from: 'params',
          pipeline: [
            { $match: { $expr: { $and: [{ $eq: ['$name', 'tagActivity'] }] } } },
            { $project: { _id: 0, options: 1 } }
          ],
          as: 'params'
        }
      },
      {
        $addFields: {
          params: { $arrayElemAt: ['$params', 0] },
          units:{ $ifNull: [ { $split: [ { $toString: '$units' }, ',' ] }, []] },
        }
      }
    ]
    if (Object.keys(query).length) {
      pipeline.push({ $match: query })
    }
    pipeline.push({
      $addFields: {
        tag: {
          $filter: {
            input: '$params.options',
            as: 'item',
            cond: { $eq: ['$$item.id', '$tagActivity'] }
          }
        },
        units: {
          $filter: {
            input: '$tunits',
            as: 'option',
            cond: {$in: ['$$option._id', '$units']}
          }
        },
      }
    })
    pipeline.push({
      $addFields: {
        'units': {
          '$map': {
            'input': '$units',
            'as': 'u',
            'in': {
              '$concat': [ '$$u.name' ],
            }
          }
        }
      }
    })
    pipeline.push({
      $addFields: {
        units: {
          $reduce: {
            input: '$units',
            initialValue: '',
            in: {
              $concat: [
                '$$value',
                {
                  $cond: {
                    if: { $eq: [ '$$value', '' ] },
                    then: ' ',
                    else: ', '
                  }
                },
                '$$this'
              ]
            }
          }
        }
      }
    })
    pipeline.push({ $sort: { _id: -1 } })
    pipeline.push({
      $project: {
        id: '$_id',
        _id: 0,
        name: 1,
        unitCode: { $ifNull: ['$units', ''] },
        template: { $ifNull: [{ $arrayElemAt: ['$ttemplate.name', 0] }, ''] },
        tagName: { $ifNull: [{ $arrayElemAt: ['$tag.value', 0] }, ''] },
        tagColor: { $ifNull: [{ $arrayElemAt: ['$tag.color', 0] }, ''] },
        active: { $cond: { if: { $eq: ['$active', '1'] }, then: 'Si', else: 'No' } }
      }
    })
    pipeline.push({ $sort: { name: 1 } })
    mongo.aggregate('activity', pipeline, { allowDiskUse: true }, (err, activities) => {
      if (err) {
        throw err
      } else {
        send(activities)
      }
    })
  }

  this.get = function (req, mongo, send) {
    var id = req.query._id
    mongo.findId('activity', id, (err, activity) => {
      if (err) {
        throw err
      } else if (!activity) {
        activity = {
          _id: mongo.newId()
        }
        send(activity)
      } else {
        send(activity)
      }
    })
  }

  this.save = async function (req, mongo, send) {
    var doc = req.body
    mongo.save('activity', doc, (err) => {
      var reply
      if (err) {
        reply = { error: tags.savingProblema }
      } else {
        reply = { message: tags.savedChanges }
      }
      send(reply)
    })

  }
  this.collaborators = async (req, mongo, send) => {
    var pipeline = [
      { $match: { units: { $in: req.session.context.managerUnits.concat(req.session.context.assisstantUnits) } } },
      { $project: { id: '$_id', _id: 0, name: 1, position: 1 } },
      { $sort: { value: 1 } }
    ]
    mongo.aggregate('user', pipeline, {}, (err, users) => {
      if (err) {
        send({ error: err })
      } else {
        send(users)
      }
    })
  }
  this.activitiesUser = function (req, mongo, send) {
    var context = req.session.context
    var plan = req.query.plan ? req.query.plan : context.activePlan ? context.activePlan.id : ''
    var pipeline = [
      { $match: { _id: context.user } },
      {
        $lookup: {
          from: 'user', as: 'users', let: { parent: context.managerUnits.concat(context.assistantUnits) }, pipeline: [
            {
              $match: {
                
                $expr: {
                  $and: [
                    { $eq: ['$licensedUser', true] },
                    {
                      $gt: [{
                        $size: {
                          $filter: {
                            input: { $ifNull: ['$units', []] }, as: 'unit',
                            cond: { $in: ['$$unit', '$$parent'] }
                          }
                        }
                      }, 0]
                    }
                  ]
                }
              }
            },
            { $project: { _id: 0, id: '$_id', name: '$name', workDay: { $ifNull: ['$business.workDay',480]} } }
          ]
        }
      },
      {
        $lookup: {
          from: 'activityUser', let: { users: '$users.id' }, as: 'activities', pipeline: [
            { $match: { $expr: { $and: [{ $in: ['$_id.user', '$$users'] }, { $eq: ['$_id.plan', mongo.toId(plan)] }] } } },
            { $lookup: { from: 'activity', localField: '_id.activity', foreignField: '_id', as: 'activity' } },
            { $lookup: { from: 'user', localField: '_id.user', foreignField: '_id', as: 'user' } },
            {
              $lookup: {
                from: 'time', let: { activity: '$_id.activity', user: '$_id.user', plan: '$_id.plan'}, as: 'time',
                pipeline: [
                  { $match: { $expr: { $and: [{ $eq: ['$document', '$$activity'] }, { $eq: ['$user', '$$user'] }, { $eq: ['$plan', '$$plan'] }] } } },
                  {$project: {duration: '$duration'}}
                ]
              }
            },
            {
              $project: {
                _id: 0, workDay: {$arrayElemAt: ['$user.business.workDay',0]},user: '$_id.user', id: '$_id.activity', name: { $arrayElemAt: ['$activity.name', 0] }, planned: 1,
                real: { $sum: { $ifNull: ['$time.duration', 0] } }
              }
            },
            { $sort: { name: 1 } }
          ]
        }
      },
      { $project: { actors: 1, users: 1, activities: 1 } }
    ]
    mongo.aggregate('user', pipeline, { allowDiskUse: true }, async (err, data) => {
      if (err) {
        throw err
      } else {
        if (data.length && data[0].activities.length) {
          var activities = data[0].activities
          var name = ''
          var acts = []
          var act
          activities.forEach((activity) => {
            if (activity.name !== name) {
              name = activity.name
              if (act) {
                act.progress = act.real * 100 / act.planned
                acts.push(act)
              }
              act = { id: activity.id, name: activity.name, planned: activity.planned, real: activity.real }
            } else {
              if (act) {
                act.planned += activity.planned
                act.real += activity.real
              }
            }
            if (act) {
              act[activity.user.toString()] = activity.planned
              act['real' + activity.user.toString()] = activity.real
              act['workDay'+activity.user.toString()] = activity.workDay || context.workDay
            }
          })
          if (act) {
            act.progress = act.real * 100 / act.planned
            acts.push(act)
            data[0].activities = acts
          }
        }
        data[0].plan = plan
        let status = await new Promise(resolve => {
          mongo.findId('plan', plan, (err, plan) => {
            if (plan) resolve(plan.status)
            else resolve('')
          })
        })
        if (context.activePlan && context.activePlan.id) {
          data[0].editable = data[0].users.length > 0 && (plan == context.activePlan.id.toString() || status === 'draft')
        } else {
          data[0].editable=data[0].users.length > 0 && status === 'draft'
        }
        send(data[0])
      }
    })
  }

  this.activityUser = function (req, mongo, send) {
    var id = req.query._id
    var pipeline = [
      { $match: { _id: mongo.toId(id) } },
      { $lookup: { from: 'time', localField: 'activity', foreignField: 'doc_id', as: 'ttime' } },
      { $unwind: '$ttime' },
      {
        '$group': {
          '_id': {
            _id: '$_id',
            activity: '$activity',
            plan: '$plan',
            user: '$user',
            planned: '$planned',
          },
          'real': {
            '$sum': '$ttime.duration'
          }
        }
      },
      {
        $project: {
          '_id': 0,
          id: '$_id._id',
          activity: '$_id.activity',
          plan: '$_id.plan',
          user: '$_id.user',
          planned: '$_id.planned',
          real: 1
        }
      }
    ]
    mongo.aggregate('activityUser', pipeline, { allowDiskUse: true }, (err, activity) => {
      if (err) {
        throw err
      } else if (!activity.length) {
        activity = {
          _id: mongo.newId()
        }
        send(activity)
      } else {
        send(activity[0])
      }
    })
  }

  this.saveActivityUser = async function (req, mongo, send) {
    var doc = req.body
    doc.planned *= 1
    mongo.save('activityUser', doc, (err) => {
      if (err) {
        var reply = { error: tags.savingProblema }
      } else {
        reply = { message: tags.savedChanges }
      }
      send(reply)
    })
  }
  this.deleteActivityUser = async function (req, mongo, send) {
    let activity = req.body.activity
    if (activity && activity.length === 24) {
      activity = mongo.toId(req.body.activity)
    } else {
      activity = Number(activity)
    }
    mongo.deleteAll('activityUser', { '_id.plan': mongo.toId(req.body.plan), '_id.activity': activity }, (err) => {
      if (err) {
        var reply = { error: tags.savingProblema }
      } else {
        reply = { message: tags.savedChanges }
      }
      send(reply)
    })
  }
  this.reportsTimes = function (req, mongo, send) {
    let keys = {}
    const query = []
    for (const name in req.query.filter) {
      if (req.query.filter[name].length > 0 && req.query.filter[name] !== 'null') {
        if (name === 'user') {
          query.push( { userId: mongo.toId(req.query.filter.user) })
        } else if (name === 'project') {
          query.push( { projectId: mongo.toId(req.query.filter.project) })
        } else if (name === 'task') {
          query.push({ 'actividad/tarea': new RegExp(req.query.filter.task, 'i') })
        } else if (name === 'year') {
          query.push({ 'year': Number(req.query.filter.year) })
        } else if (name === 'month') {
          query.push({ 'month': Number(req.query.filter.month) })
        } else if (name === 'dayOfMonth') {
          query.push({ 'dayOfMonth': Number(req.query.filter.dayOfMonth) })
        } else if (name === 'week') {
          query.push({ 'week': Number(req.query.filter.week) })
        }
      }
    }
    if (query.length) {
      keys.$and = query
    }
    var pipeline = [
      { $limit: 1 },
      {
        $lookup: {
          from: 'activityUser',
          pipeline: [
            { $lookup: { from: 'user', localField: 'user', foreignField: '_id', as: 'tuser' } },
            { $lookup: { from: 'plan', localField: 'plan', foreignField: '_id', as: 'tplan' } },
            { $lookup: { from: 'activity', localField: 'activity', foreignField: '_id', as: 'tactivity' } },
            {
              $addFields: {
                units: { $arrayElemAt: ['$tuser.units', 0] },
              }
            },
            {
              $project: {
                _id: '$_id',
                fecha: { $arrayElemAt: ['$tplan.period.start', 0] },
                tipo: 'activity',
                usuario: { $arrayElemAt: ['$tuser.name', 0] },
                userId: { $arrayElemAt: ['$tuser._id', 0] },
                proyecto: 'Actividades',
                plan: { $arrayElemAt: ['$tplan.name', 0] },
                'actividad/tarea': { $arrayElemAt: ['$tactivity.name', 0] },
                duracionPlan: { $toDouble: '$planned' },
                costo: { $toDouble: '0' },
                projectId: 'activities',
                identify: 'actividadPlan'
              }
            },
          ],
          as: 'plan'
        }
      },
      {
        $lookup: {
          from: 'plan',
          pipeline: [
            {
              $lookup: {
                from: 'project',
                let: { id: '$_id' },
                pipeline: [{$match: {$expr: {$and: [{$eq: ['$plan', '$$id']}]}}}
                ],
                as: 'tproject'
              }
            },
            { $unwind: { path: '$tproject', preserveNullAndEmptyArrays: true } },
            { $unwind: { path: '$tproject.content.data', preserveNullAndEmptyArrays: true } },
            { $lookup: { from: 'user', localField: 'tproject.content.data.owner_id', foreignField: '_id', as: 'tuser'}},
            {
              $project: {
                _id: '$tproject.content.data.id',
                fecha: '$tproject.content.data.end_date',
                tipo: 'task',
                usuario: { $arrayElemAt: ['$tuser.name', 0] },
                userId: { $arrayElemAt: ['$tuser._id', 0] },
                proyecto: '$tproject.name',
                plan: '$name',
                'actividad/tarea': '$tproject.content.data.text',
                duracionPlan: { $toDouble: '$tproject.content.data.duration' },
                costo: { $toDouble: '0' },
                projectId: '$tproject._id',
                identify: 'tareaPlan'
              }
            }
          ],
          as: 'tasksPlan'
        }
      },
      {
        $lookup: {
          from: 'plan',
          pipeline: [
            {
              $lookup: {
                from: 'project',
                let: { id: '$_id' },
                pipeline: [{$match: {$expr: {$and: [{$eq: ['$plan', '$$id']}]}}}
                ],
                as: 'tproject'
              }
            },
            { $unwind: { path: '$tproject', preserveNullAndEmptyArrays: true } },
            { $unwind: { path: '$tproject.content.data', preserveNullAndEmptyArrays: true } },
            {
              $group: {
                _id: '$tproject.content.data.owner_id',
                plans: { $push: '$name' },
                projects: { $push: '$tproject.name' },
                tasks: { $push: '$tproject.content.data.text' },
                plansId: { $push: '$_id' },
                projectsId: { $push: '$tproject._id' },
                tasksId: { $push: '$tproject.content.data.id' }
              }
            },
            { $lookup: { from: 'user', localField: '_id', foreignField: '_id', as: 'tuser' } },
            { $unwind: '$tuser' },
            {
              $lookup: {
                from: 'time',
                let: { id: '$_id', plans: '$plansId' },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $and: [
                          { $eq: ['$user', '$$id'] },
                          { $in: ['$plan', '$$plans']}
                        ]
                      }
                    }
                  }
                ],
                as: 'ttime'
              }
            },
            { $unwind: '$ttime' },
            { $addFields: {
              jornada: { $cond: { if: { $eq: ['', '$tuser.business.workDay'] }, then: '480', else: '$tuser.business.workDay' } } } },
            {
              $project: {
                _id: '$ttime._id',
                fecha: '$ttime.date',
                tipo: '$ttime.type',
                usuario: '$tuser.name',
                userId: '$tuser._id',
                proyecto: {
                  $cond: {
                    if: { $eq: ['$ttime.type', 'task'] },
                    then: { $arrayElemAt: ['$projects', { $indexOfArray: ['$projectsId', '$ttime.project'] }] },
                    else: 'Actividades'
                  }
                },
                plan: { $arrayElemAt: ['$plans', { $indexOfArray: ['$plansId', '$ttime.plan'] }] },
                'actividad/tarea': { $ifNull: ['$ttime.activity', { $arrayElemAt: ['$tasks', { $indexOfArray: ['$tasksId', '$ttime.task'] }] }] },
                duracionReal: { $divide: [{ $toDouble: '$ttime.duration' }, { $toDouble: '$jornada' }] },
                costo: { $toDouble: '$ttime.cost' },
                projectId: '$ttime.project',
                identify: 'Reales'
              }
            }
          ],
          as: 'tasksReal'
        }
      },
      {
        $project: {
          union: {
            $concatArrays: [ '$tasksPlan', '$plan', '$tasksReal' ]
          }
        }
      },
      { $unwind: '$union' },
      { $replaceRoot: { newRoot: '$union' } },
      {
        $addFields: {
          year: {$year: { $toDate: '$fecha' }},
          month: {$month: { $toDate: '$fecha' }},
          dayOfMonth: {$dayOfMonth: { $toDate: '$fecha' }},
          week: {$week: { $toDate: '$fecha' }},
        }
      },
      { $match: keys },
      {
        '$project': {
          _id: 0,
          'task': '$actividad/tarea',
          projectId: 1,
          date: { $dateToString: { format: '%Y-%m-%d', date: { $toDate: '$fecha' }}},
          year: 1,
          month: 1,
          dayOfMonth: 1,
          week: 1,
          userName: '$usuario',
          projectName: '$proyecto',
          userId: '$userId',
          plan: '$plan',
          //planned: { $ifNull: ['$duracionPlan',0]} ,
          duration: { $ifNull: ['$duracionReal', 0] },
          //costo: { $ifNull: ['$costo', 0] }
        }
      }
    ]
    mongo.aggregate('plan', pipeline, { allowDiskUse: true }, (err, times) => {
      if (err) {
        throw err
      } else {
        send(times)
      }
    })
  }
}
