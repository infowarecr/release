
var url = process.argv[2]
var dbname = process.argv[3]
if ((!dbname || dbname.length === 0) || (!url || url.length === 0)) {
  console.log('Invalid parameters: type, database, [host] -> expected')
  process.exit()
}
var Mongo = require('../utils/mongo').Mongo
var mongo
// var url = 'mongodb://127.0.0.1:27017/';
mongo = new Mongo(url + dbname)
/// /////PROBAR CON UN SOLO REPOSITORY////////////////////
mongo.find('repository', { }, { _id: 1, description: 1 }, {}, async function (err, repositories) {
  if (err) throw err
  if (repositories && repositories.length > 0) {
    for (let i in repositories) {
      var doc = repositories[i]
      if (typeof doc.description === 'string') {
        var string = doc.description
        do {
          let i = string.indexOf('/api/file.get?_id=')
          if (i !== -1) {
            string = string.substring(i)
            let id = string.substring(18, 42)
            if (('' + id).toString().match(/^[0-9a-fA-F]{24}$/)) {
              var file = await new Promise(resolve => {
                mongo.findId('fs.files', id, (err, file) => {
                  if (err) {
                    resolve(false)
                  } else { resolve(file) }
                })
              })
              if (file) {
                await new Promise(resolve => {
                  mongo.deleteOne('fs.files', { _id: mongo.toId(id) }, (err, result) => {
                    if (err) {
                      resolve(false)
                    } else { resolve(result) }
                  })
                })
              }
            }
            string = string.substring(18)
          }
        } while (string.includes('/api/file.get?_id='))
      }
      await new Promise(resolve => {
        mongo.deleteOne('repository', { _id: doc._id }, (err, result) => {
          if (err) {
            resolve(false)
          } else { resolve(result) }
        })
      })
    }
    process.exit()
  }

  process.exit()
})
