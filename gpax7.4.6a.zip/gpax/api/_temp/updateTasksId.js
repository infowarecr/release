var url = process.argv[2]
var dbname = process.argv[3]
if ((!dbname || dbname.length === 0) || (!url || url.length === 0)) {
  console.log('Invalid parameters: type, database, [host] -> expected')
  process.exit()
}
var Mongo = require('../utils/mongo').Mongo
var mongo

mongo = new Mongo(url + dbname)

// Update task id in comments
mongo.aggregate('taskMigrated',[
  { $lookup: { from: 'comment', localField: 'oldId', foreignField: 'document', as: 'comment' } },
  { $match: { 'comment._id': { $exists: true } } },
  { $project: { _id: 1, ids: '$comment._id'} }
], {}, async (err, docs) => {
  if (err) console.log(err)
  else {
    console.log(docs.length + ' updates to do')
    var count = 0
    for (let i in docs) {
      let doc = docs[i]
      await new Promise(resolve => {
        mongo.updateAll('comment', { _id: { $in: doc.ids } }, { $set: { document: doc._id } }, (err, result) => {
          if (result) {
            count += result.modifiedCount
          }
          resolve()
        })
      })
    }
    console.log(count + ' comments updated')
  }
  // Update task id in trash (time & document)
  mongo.aggregate('taskMigrated', [
    {
      $lookup: {
        from: 'trash',
        localField: 'oldId',
        foreignField: 'document.task',
        as: 'trash'
      }
    },
    { $match: { 'trash.document._id': { $exists: true } } },
    { $project: { _id: 1, ids: '$trash._id' } }
  ], {}, async (err, docs) => {
    if (err) console.log(err)
    else {
      console.log(docs.length + ' updates to do')
      count = 0
      for (let i in docs) {
        let doc = docs[i]
        await new Promise(resolve => {
          mongo.updateAll('trash', { _id: { $in: doc.ids } }, { $set: { 'document.task': doc._id } }, (err, result) => {
            if (result) {
              count += result.modifiedCount
            }
            resolve()
          })
        })
      }
      console.log(count + ' trash updated')
    }

    // Update task id in notes
    mongo.aggregate('taskMigrated', [
      { $lookup: { from: 'note', localField: 'oldId', foreignField: 'task', as: 'note' } },
      { $match: { 'note._id': { $exists: true } } },
      { $project: { _id: 1, ids: '$note._id' } }
    ], {}, async (err, docs) => {
      if (err) console.log(err)
      else {
        console.log(docs.length + ' updates to do')
        var count = 0
        for (let i in docs) {
          let doc = docs[i]
          await new Promise(resolve => {
            mongo.updateAll('note', { _id: { $in: doc.ids } }, { $set: { task: doc._id } }, (err, result) => {
              if (result) {
                count += result.modifiedCount
              }
              resolve()
            })
          })
        }
        console.log(count + ' notes updated')
      }

      // Update task id in document
      mongo.aggregate('taskMigrated', [
        { $lookup: { from: 'time', localField: 'oldId', foreignField: 'document', as: 'time' } },
        { $match: { 'time._id': { $exists: true } } },
        { $project: { _id: 1, ids: '$time._id' } }
      ], {}, async (err, docs) => {
        if (err) console.log(err)
        else {
          console.log(docs.length + ' updates to do')
          var count = 0
          for (let i in docs) {
            let doc = docs[i]
            await new Promise(resolve => {
              mongo.updateAll('time', { _id: { $in: doc.ids } }, { $set: { document: doc._id } }, (err, result) => {
                count += result.modifiedCount
                resolve()
              })
            })
          }
          console.log(count + ' times updated')
        }
        process.exit()
      })
    })
  })
})