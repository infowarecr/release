/* Set planPeriod and realPeriod for projects */

var url = 'mongodb://127.0.0.1:27017/'

var Mongo = require('../utils/mongo').Mongo
var date
async function fixProjects (database, uri) {
  var mongo = new Mongo((uri || url) + database)
  var logs = new Mongo((uri || url) + 'logs')
  mongo.find('project', {}, async (err, projects) => {
    if (err) {
      console.log(err)
      process.exit(0)
    }
    for (const i in projects) {
      var project = projects[i]
      if (project.status !== 'draft') {
        var start = await new Promise(resolve => {
          logs.findN('log', 0, 1, { url: 'api/project.startProject', 'input._id': project._id, 'output.message': 'savedChanges' }, {}, { _id: 1 }, (err, log) => {
            if (err) console.log(err)
            resolve(log[0])
          })
        })
        var end = await new Promise(resolve => {
          logs.findN('log', 0, 1, { url: 'api/project.completeProject', 'input._id': project._id, 'output.message': 'savedChanges' }, {}, { _id: -1 }, (err, log) => {
            if (err) console.log(err)
            resolve(log[0])
          })
        })
        if (start) {
          date = new Date(start._id.getTimestamp())
          project.realPeriod = [date]
          if (start.input.content) {
            project.planPeriod = [getStartDate(start.input.content.data), getEndDate(start.input.content.data)]
          } else {
            var dates = project.startEnd.split(' / ')
            if (dates[0]) {
              project.planPeriod = [new Date(dates[0])]
            }
            if (dates[1]) {
              project.planPeriod.push(new Date(dates[1]))
            }
          }
        }
        if (end) {
          date = new Date(end._id.getTimestamp())
          if (project.realPeriod) project.realPeriod.push(date)
        }
        if (!project.planPeriod && project.startEnd) {
          dates = project.startEnd.split(' / ')
          if (dates[0]) {
            project.planPeriod = [new Date(dates[0])]
          }
          if (dates[1]) {
            project.planPeriod.push(new Date(dates[1]))
          }
          if (!project.realPeriod) project.realPeriod = project.planPeriod
        }
        await new Promise(resolve => {
          mongo.save('project', project, (err, result) => {
            if (err) console.log(err)
            resolve(result)
          })
        })
      }
    }
    process.exit(0)
  })
}

function getStartDate (tasks) {
  var date
  for (const i in tasks) {
    var taskDate = new Date(tasks[i].start_date.replace(/-/g, '/'))
    if (!date || taskDate < date) {
      date = taskDate
    }
  }
  return date
}
function getEndDate (tasks) {
  var date
  for (const i in tasks) {
    var taskDate = new Date(tasks[i].end_date.replace(/-/g, '/'))
    if (!date || taskDate > date) {
      date = taskDate
    }
  }
  return date
}

fixProjects(process.argv[2] ? process.argv[2] : 'gpa7', process.argv[3])
