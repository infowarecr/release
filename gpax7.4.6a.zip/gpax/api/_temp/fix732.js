/*
 * Inmediatamente después de actualizar a la version 7.3.2, se debe ejecutar este programa, este programa realiza verificación de la jornada
 * laboral y otros elementos que deben ajustarse para un correcto funcionamiento del Gantt
 * 1. El campo business.workDay de cada usuario con licencia debe ser entero y representará la cantidad de minutos que trabaja por día
 * 2. El campo workDay de cada proyecto debe tener la jornada del usuario director del proyecto
 * 3. Las tareas deben tener start_date y end_date como campos de tipo fecha, además para las tareas en proceso o pausadas se debe calcular
 *    su real_start_date y para las tareas terminadas, revisdas o suspendidas se les debe calcular su real_end_date
 *
*/
var mongo = require('mongodb')
var url = 'mongodb://127.0.0.1:27017/users'
if (process.argv.length === 3) {
  url = process.argv[2]
} 
console.log('url = ' + url)
class fix732 {
  start(url) {
    mongo.MongoClient.connect(url, { useUnifiedTopology: true, appname: 'gpax' }).then(client => {
      this.client = client
      let dbname = url
      dbname = dbname.substring(dbname.lastIndexOf('/') + 1)
      if (dbname.includes('?')) {
        dbname = dbname.substring(0, dbname.indexOf('?'))
      }
      this.users = client.db(dbname)
      this.users.collection('user').distinct('database').then(dbs => this.fixDbs(dbs))
    }).catch(err=>console.log(err))
  }
  fixDbs(dbs) {
    let dbname = dbs.shift()
    if (dbname) {
      dbname = dbname.substring(dbname.lastIndexOf('/') + 1)
      if (dbname.includes('?')) {
        dbname = dbname.substring(0, this.dbname.indexOf('?'))
      }
    console.log(' processing db "' + db.name + '"...')
    var db=this.client.db(dbname)
    return this.fixUsers(db).then(r=>this.fixProjects(db)).then(r=>this.fixTasks(db)).then(r=>this.fixDbs(dbs))
    } else {
      console.log('All dbs were processed!')
    }
  }
  fixUsers(db) {
    var c = db.collection('user')
      c.updateMany(
      { licensedUser: true, active: true },
      [{ $set: { 'business.workDay': { $multiply: [{ $toDouble: '$business.workDay' }, 60] } } }]).then(r => {
        console.log(r.modifiedCount+' '+c.namespace+' modifieds')
      })
  }
  fixProjects(db) {
    var c = db.collection('project')
    c.aggregate([{$lookup:{from:'user',localField:'actors.user',fore}}])
  }
mongo.find('user',{},)
mongo.find('user', {licensedUser: true,active: true}, async (err, users) => {
  if (err) {
    console.log(err)
  } else {
    for (let i in users) {
      let user = users[i]
      var wd = parseFloat(user.business.workDay || 8)
      if (wd < 24) {
        wd *= 60
      } else if (wd < 80) {
        wd = wd * 60 / 5
      }
      console.log(user.name+' '+user.business.workDay+' -> '+wd)
      await new Promise(resolve => {
        mongo.update('user', { _id: user._id }, { $set: { 'business.workDay': wd } }, (err, result) => {
          if (err) {
            console.log(err)
          }
          resolve(result)
        })
      })
    }
  }
})
}