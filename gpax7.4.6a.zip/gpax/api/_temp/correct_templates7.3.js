var url = process.argv[2]
var dbname = process.argv[3]
if ((!dbname || dbname.length === 0) || (!url || url.length === 0)) {
  console.log('Invalid parameters: type, database, [host] -> expected')
  process.exit()
}
var Mongo = require('../utils/mongo').Mongo
var mongo

mongo = new Mongo(url + dbname)

var tasksDurationDaysToHoursTemplates = async (mongo) => {
  return await new Promise(resolve => {
    mongo.find('template', { type: 'project' }, {}, {}, async function (err, templates) {
      if (err) {
        console.log(err)
        resolve(false)
      } else {
        console.log('modelos encontrados: ' + templates.length)
        console.log('iniciado tasksDurationDaysToHoursTemplates')
        for (var p in templates) {
          let salvar = false
          let template = templates[p]
          console.log(Number(p) + 1 + ' de ' + templates.length)
          if (template.template && template.template.data) {
            for (var d in template.template.data) {
              let task = template.template.data[d]
              if (task.start_date && (task.start_date === null || task.start_date.toString().length < 10)) {
                if (task.duration) {
                  task.duration = (Number(task.duration) * 8) * 60
                  salvar = true
                }
              }
            }
            if (salvar) {
              await new Promise(resolve => {
                mongo.save('template', template, (err, res) => {
                  resolve()
                })
              })
            }
          }
        }
        console.log('terminado tasksDurationDaysToHoursTemplates')
        resolve(true)
      }
    })
  })
}

//ejecutar en orden
var go = async () => {
  let result = await tasksDurationDaysToHoursTemplates(mongo)
  process.exit()
}
go()