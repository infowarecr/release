var url = process.argv[2]
var dbname = process.argv[3]
if ((!dbname || dbname.length === 0) || (!url || url.length === 0)) {
  console.log('Invalid parameters: type, database, [host] -> expected')
  process.exit()
}
var Mongo = require('../utils/mongo').Mongo
var mongo

mongo = new Mongo(url + dbname)
//Corregir la duracion de las activitiesUser que estan en horas a dias y luego a minutos,
var activityUserHouerCorrect = async (mongo) => {
  return await new Promise(resolve => {
    mongo.find('activityUser', { '_id.activity': { $lte: mongo.newId(new Date()) }, corrected: { $exists: 0 } }, {}, {}, async function (err, activityUsers) {
      if (err) {
        console.log(err)
        resolve(false)
      } else {
        console.log('actividades encontrados: ' + activityUsers.length)
        console.log('iniciado activityUserHouerCorrect')
        for (var p in activityUsers) {
          let activityUser = activityUsers[p]
          console.log(Number(p) + 1 + ' de ' + activityUsers.length)
          if (activityUser.planned && Number(activityUser.planned) > 0) {
            let jornada = await new Promise(resolve => {
              if (activityUser._id && activityUser._id.user) {
                mongo.findId('user', activityUser._id.user, (err, user) => {
                  if (user && user.business && user.business.workDay && Number(user.business.workDay).toString() !== 'NaN') {
                    resolve(Number(user.business.workDay))
                  } else {
                    resolve(8)
                  }
                })
              } else {
                resolve(8)
              }
            })
            let duration = activityUser.planned * jornada
            activityUser.planned = duration
            activityUser.corrected = true
            await new Promise(resolve => {
              mongo.save('activityUser', activityUser, (err, res) => {
                resolve()
              })
            })
          }
        }
        console.log('terminado activityUserHouerCorrect')
        resolve(true)
      }
    })
  })
}

//ejecutar en orden
var go = async () => {
  let result = await activityUserHouerCorrect(mongo)
  process.exit()
}
go()