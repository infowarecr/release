
var url = process.argv[2]
var dbname = process.argv[3]
if ((!dbname || dbname.length === 0) || (!url || url.length === 0)) {
  console.log('Invalid parameters: type, database, [host] -> expected')
  process.exit()
}
var Mongo = require('../utils/mongo').Mongo
var mongo
// var url = 'mongodb://127.0.0.1:27017/';
mongo = new Mongo(url + dbname)
mongo.find('note', { }, {}, {}, async function (err, documents) {
  if (err) { throw err }
  if (documents && documents.length > 0) {
    for (let d in documents) {
      var doc = documents[d]
      console.log('nota --> ' + d)
      var attacheds = await new Promise(resolve => {
        mongo.find('document', { reference: doc._id }, {}, {}, function (err, attacheds) {
          if (err) { resolve(false) } else { resolve(attacheds) }
        })
      })

      if (attacheds && attacheds.length > 0) {
        for (let a in attacheds) {
          var attac = attacheds[a]
          console.log('anexo --> ' + a)
          attac.requiredResponse = '1'
          attac.type = 'note'
          let deadline = doc.dates.findIndex((x) => {
            return x.type === 'deadline'
          })
          let deadline2 = attac.dates.findIndex((x) => {
            return x.type === 'deadline'
          })
          if (deadline !== -1 && deadline2 === -1) { attac.dates.push(doc.dates[deadline]) }
          if (doc.status === 'processing') {
            attac.status = 'processing'
          } else if (doc.status === 'draft') {
            attac.status = 'draft'
          }
          var commitments = await new Promise(resolve => {
            mongo.find('document', { reference: attac._id }, {}, {}, function (err, commitments) {
              if (err) { resolve(false) } else { resolve(commitments) }
            })
          })

          if (commitments && commitments.length > 0) {
            if (doc.status === 'draft') { doc.status = 'processing' }
            for (let c in commitments) {
              var commit = commitments[c]
              console.log('compromiso --> ' + c)
              commit.type = 'note'
              let actor = commit.actors.findIndex((x) => {
                return x.role === 'inCharge' && x.path === 'received'
              })
              if (actor !== -1) {
                attac.responsible = commit.actors[actor].user.toString() + '&unit=' + commit.actors[actor].unit.toString()
              }

              if (commit.status !== 'draft') {
                commit.dates.push({ type: 'answered', value: commit.dates[0].value })
                attac.dates.push({ type: 'answered', value: commit.dates[0].value })
                attac.status = 'answered'
              }
              if (commit.status === 'processing') {
                commit.status = 'accepted'
              }
              if (commit.status === 'done' || commit.status === 'incomplete' || commit.status === 'canceled') { attac.status = 'completed' }
              if (commit.status !== 'draft' && commit.status !== 'ready') {
                let deadline = commit.dates.findIndex((x) => {
                  return x.type === 'deadline'
                })
                if (deadline !== -1) { commit.dates.push({ type: 'trackingDate', value: commit.dates[deadline].value }) }

                attac.answered = '1'
                let attended = true
                for (let i in attacheds) {
                  if (attacheds[i].status !== 'completed') {
                    attended = false
                    break
                  }
                }
                if (attended) { doc.status = 'attended' }

                var evidences = await new Promise(resolve => {
                  mongo.find('document', { reference: commit._id }, {}, {}, function (err, evidences) {
                    if (err) { resolve(false) } else { resolve(evidences) }
                  })
                })

                if (evidences && evidences.length > 0) {
                  for (let e in evidences) {
                    var evid = evidences[e]
                    console.log('evidencia --> ' + e)
                    evid.type = 'note'
                    if (evid.status !== 'draft') {
                      evid.dates.push({ type: 'answered', value: commit.dates[0].value })
                    }

                    let evi = await new Promise(resolve => {
                      mongo.findId('evidence', evid._id, function (err, evi) {
                        if (err) { resolve(false) } else { resolve(evi) }
                      })
                    })
                    if (!evi || (evi && evi.length === 0)) {
                      await new Promise(resolve => {
                        mongo.save('evidence', evid, function (err, result) {
                          if (err) { resolve(false) } else { resolve(result) }
                        })
                      })
                    }
                  }
                }

                let comm = await new Promise(resolve => {
                  mongo.findId('commitment', commit._id, function (err, comm) {
                    if (err) { resolve(false) } else { resolve(comm) }
                  })
                })
                if (!comm || (comm && comm.length === 0)) {
                  await new Promise(resolve => {
                    mongo.save('commitment', commit, function (err, result) {
                      if (err) { resolve(false) } else { resolve(result) }
                    })
                  })
                }
              }
            }
          }

          let atta = await new Promise(resolve => {
            mongo.findId('attached', attac._id, function (err, atta) {
              if (err) { resolve(false) } else { resolve(atta) }
            })
          })
          if (!atta || (atta && atta.length === 0)) {
            await new Promise(resolve => {
              mongo.save('attached', attac, function (err, result) {
                if (err) { resolve(false) } else { resolve(result) }
              })
            })
          }
        }
      }
    }
    process.exit()
  } else {
    process.exit()
  }
})
