// Busca las notas con auditados que estan con el rol de revisores, para ponerlos como inCharge
var auditados = []
db.user.find({licensedUser: false}).forEach(u=>auditados.push(u._id))

db.note.aggregate([
  {$unwind: '$actors'},
  {$match: {$expr: {$and: [{$in: ['$actors.user',auditados]},{$eq: ['$actors.role','reviser']}]}}},
  {$project: {name: 1,actors: 1}}
])

path: 'referred', role: 'copy'

// Buscar las notas con auditores que estan como encargados, para ponerlos como revisores
auditados = []
db.user.find({licensedUser: true}).forEach(u=>auditados.push(u._id))

db.note.aggregate([
  {$unwind: '$actors'},
  {$match: {$expr: {$and: [{$in: ['$actors.user',auditados]},{$eq: ['$actors.role','inCharge']}]}}},
  {$project: {name: 1,actors: 1}}
])

path: 'referred', role: 'reviser'


En las colecciones: note, attached, commitment, evidence