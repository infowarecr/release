var tags = require('../utils/tags').tags

var user = process.argv[2]
var password = tags.util.crypto(process.argv[3])

console.log(Buffer.from(user + ':' + password).toString('base64'))
