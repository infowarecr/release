
var Mongo = require('../utils/mongo').Mongo
var mongo
var url = 'mongodb://127.0.0.1:27017/gpax'
mongo = new Mongo(url)
update()
async function update () {
  const times = await new Promise(resolve => {
    mongo.find('time', { $or: [{ cost: NaN }, { cost: { $exists: 0 } }, { cost: '' }, { cost: 0 }] }, (err, times) => {
      if (err) resolve(false)
      else resolve(times)
    })
  })
  if (times) {
    for (const t in times) {
      var time = times[t]
      const user = await new Promise(resolve => {
        mongo.findId('user', time.user, { bussiness: 1 }, (err, user) => {
          if (err) resolve(false)
          else resolve(user)
        })
      })
      if (user && user.bussiness && user.bussiness.hourCost) {
        if (user.bussiness.hourCost === 'string') {
          time.cost = time.duration * parseFloat(isNaN(Number(user.bussiness.hourCost)) ? 0 : Number(user.bussiness.hourCost))
        } else {
          time.cost = time.duration * parseFloat(user.bussiness.hourCost)
          await new Promise(resolve => {
            mongo.save('time', time, (err, res) => {
              if (err) console.log(err)
              resolve(res)
            })
          })
        }
      }
      process.exit(0)
    }
  }
}
