var a = [
  { '$limit': 1 },
  {
    '$lookup': {
      'from': 'plan', 'pipeline': [
        { '$match': { 'activities': { '$exists': 1 } } },
        { '$unwind': { 'path': '$activities.data', 'preserveNullAndEmptyArrays': true } },
        { '$lookup': { 'from': 'user', 'localField': 'activities.data.user', 'foreignField': '_id', 'as': 'tuser' } },
        {
          '$addFields': {
            'arrayAct': { '$objectToArray': '$activities.activities' },
            'units': { '$arrayElemAt': ['$tuser.units', 0] }
          }
        },
        { '$match': {} },
        {
          '$project': {
            '_id': '$activities.data.activity', 'fecha': '$period.start', 'tipo': 'activity',
            'usuario': { '$arrayElemAt': ['$tuser.name', 0] }, 'proyecto': 'Actividades', 'plan': '$name',
            'actividad/tarea': { '$arrayElemAt': ['$arrayAct.v', { '$indexOfArray': ['$arrayAct.k', '$activities.data.activity'] }] },
            'duracionPlan': { '$toDouble': '$activities.data.value' }, 'costo': { '$toDouble': '0' }, 'identify': 'actividadPlan'
          }
        }
      ], 'as': 'plan'
    }
  },
  {
    '$lookup': {
      'from': 'plan', 'pipeline': [
        {
          '$lookup': {
            'from': 'project', 'let': { 'id': '$_id' }, 'pipeline': [
              { '$match': { '$expr': { '$and': [{ '$eq': ['$plan', '$$id'] }] } } }], 'as': 'tproject'
          }
        },
        { '$unwind': { 'path': '$tproject', 'preserveNullAndEmptyArrays': true } },
        { '$unwind': { 'path': '$tproject.content.data', 'preserveNullAndEmptyArrays': true } },
        {
          '$match': {
            'tproject.content.data.type': { '$in': ['milestone', 'task'] },
            'tproject.content.data.start_date': { '$gte': '2020-01-01', '$lt': '2020-05-30' }
          }
        },
        { '$lookup': { 'from': 'user', 'localField': 'tproject.content.data.owner_id', 'foreignField': '_id', 'as': 'tuser' } },
        {
          '$project': {
            '_id': '$tproject.content.data.id', 'fecha': '$tproject.content.data.end_date', 'tipo': 'task',
            'usuario': { '$arrayElemAt': ['$tuser.name', 0] }, 'proyecto': '$tproject.name', 'plan': '$name',
            'actividad/tarea': '$tproject.content.data.text', 'duracionPlan': { '$toDouble': '$tproject.content.data.duration' },
            'costo': { '$toDouble': '0' }, 'identify': 'tareaPlan'
          }
        }], 'as': 'tasksPlan'
    }
  },
  {
    '$lookup': {
      'from': 'plan', 'pipeline': [
        {
          '$lookup': {
            'from': 'project', 'let': { 'id': '$_id' }, 'pipeline': [
              { '$match': { '$expr': { '$and': [{ '$eq': ['$plan', '$$id'] }] } } }], 'as': 'tproject'
          }
        },
        { '$unwind': { 'path': '$tproject', 'preserveNullAndEmptyArrays': true } },
        { '$unwind': { 'path': '$tproject.content.data', 'preserveNullAndEmptyArrays': true } },
        {
          '$match': {
            'tproject.content.data.type': { '$in': ['milestone', 'task'] },
            'tproject.content.data.start_date': { '$gte': '2020-01-01', '$lt': '2020-05-30' }
          }
        },
        {
          '$group': {
            '_id': '$tproject.content.data.owner_id', 'plans': { '$push': '$name' },
            'projects': { '$push': '$tproject.name' }, 'tasks': { '$push': '$tproject.content.data.text' },
            'plansId': { '$push': '$_id' }, 'projectsId': { '$push': '$tproject._id' },
            'tasksId': { '$push': '$tproject.content.data.id' }
          }
        },
        { '$lookup': { 'from': 'user', 'localField': '_id', 'foreignField': '_id', 'as': 'tuser' } },
        { '$unwind': '$tuser' },
        {
          '$lookup': {
            'from': 'time', 'let': { 'id': '$_id', 'plans': '$plansId' }, 'pipeline': [
              { '$match': { '$expr': { '$and': [{ '$eq': ['$user', '$$id'] }, { '$in': ['$plan', '$$plans'] }] } } }], 'as': 'ttime'
          }
        },
        { '$unwind': '$ttime' },
        {
          '$addFields': {
            'jornada': { '$cond': { 'if': { '$eq': ['', '$tuser.business.workDay'] }, 'then': '8', 'else': '$tuser.business.workDay' } }
          }
        },
        {
          '$project': {
            '_id': '$ttime._id', 'fecha': '$ttime.date', 'tipo': '$ttime.type', 'usuario': '$tuser.name',
            'proyecto': { '$cond': { 'if': { '$eq': ['$ttime.type', 'task'] }, 'then': { '$arrayElemAt': ['$projects', { '$indexOfArray': ['$projectsId', '$ttime.project'] }] }, 'else': 'Actividades' } },
            'plan': { '$arrayElemAt': ['$plans', { '$indexOfArray': ['$plansId', '$ttime.plan'] }] },
            'actividad/tarea': { '$ifNull': ['$ttime.activity', { '$arrayElemAt': ['$tasks', { '$indexOfArray': ['$tasksId', '$ttime.task'] }] }] },
            'duracionReal': { '$divide': [{ '$toDouble': '$ttime.duration' }, { '$toDouble': '$jornada' }] },
            'costo': { '$toDouble': '$ttime.cost' }, 'identify': 'Reales'
          }
        }], 'as': 'tasksReal'
    }
  },
  {'$project': {'union': { '$concatArrays': ['$tasksPlan', '$plan', '$tasksReal'] }}},
  { '$unwind': '$union' },
  { '$replaceRoot': { 'newRoot': '$union' } },
  {
    '$group': {
      '_id': {
        'tipo': '$tipo', 'usuario': '$usuario', 'proyecto': '$proyecto', 'plan': '$plan',
        'actividad/tarea': '$actividad/tarea'
      },
      'fechaInicio': { '$first': '$fecha' }, 'fechaFin': { '$last': '$fecha' },
      'planeado': { '$sum': { '$ifNull': ['$duracionPlan', 0] } }, 'real': { '$sum': { '$ifNull': ['$duracionReal', 0] } },
      'costo': { '$sum': { '$ifNull': ['$costo', 0] } }
    }
  },
  {
    '$project': {
      '_id': 0, 'actividad/tarea': '$_id.actividad/tarea', 'tipo': '$_id.tipo',
      'primerFecha': { '$cond': { 'if': { '$ne': ['$fechaInicio', ''] }, 'then': { '$dateToString': { 'format': '%Y-%m-%d', 'date': { '$toDate': '$fechaInicio' } } }, 'else': '' } },
      'ultimaFecha': { '$cond': { 'if': { '$ne': ['$fechaFin', ''] }, 'then': { '$dateToString': { 'format': '%Y-%m-%d', 'date': { '$toDate': '$fechaFin' } } }, 'else': '' } },
      'usuario': '$_id.usuario', 'proyecto': '$_id.proyecto', 'plan': '$_id.plan', 'planeado': '$planeado', 'real': '$real',
      'costo': '$costo'
    }
  }, { '$match': { 'ultimaFecha': { '$gte': '2020-01-01', '$lte': '2020-05-30' } } }]