var Mongo = require('../utils/mongo').Mongo
var url = 'mongodb://127.0.0.1:27017/gpax'
if (process.argv.length === 3) {
  url = process.argv[2]
} else {
  console.log('Debe indicar el url de la base de datos.')
  process.exit(0)
}
console.log('url = ' + url)
var mongo = new Mongo(url)
mongo.find('project', { 'content.data.id': { $type: 'string' } }, { content: 1 }, (err, docs) => {
  if (!err) {
    next(docs, 0)
  }
})

function next (docs, i) {
  if (docs.length > i) {
    mongo.save('project', docs[i], (err, result) => {
      if (!err) {
        next(docs, i + 1)
      }
    })
  } else {
    process.exit()
  }
}
