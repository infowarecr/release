var a = {"$REF":"DFCC87F6603C85E106258404007B714E",
  "FechaAprobada":"12/31/2020",
  "Form":"AnalisisRespuestaAnexo",
  "$Fonts":"",
  "Año":"2018",
  "Consecutivo":"0",
  "Nota":"Informe No. IEF-BE 20185020 RESULTADOS DE DEFINITIVOS DE VISITA DE INSPECCIÓN CON REFERENCIA AL 31 DE DICIEMBRE DE 2017",
  "Nombre":"3. Falta de avances en el plan de acción para fortalecer las medidas adoptadas en continuidad del negocio",
  "FechaCompromiso":"12/31/2020",
  "FechaSolicitada":"05/24/2019",
  "Descripcion":"3. Falta de avances en el plan de acción para fortalecer las medidas adoptadas 
en continuidad del negocio

Esta observación será objeto de “seguimiento posterior” por parte de la 
Dirección de riesgos de esta Superintendencia.
Por lo antes mencionado la observación se mantiene pendiente.
",
"Impacto":"",
"NImpacto":"",
"DesImpacto":"",
"Bitacora":"Genaro Alberto Mira Hernandez - 27/05/2019 04:06:43 p.m.
Envió analisis de respuesta  insatisfactoria a:Genaro Alberto Mira Hernandez
Esta observación será objeto de “seguimiento posterior” por parte de la Dirección de riesgos de esta Superintendencia.
----------------------------------------
Genaro Alberto Mira Hernandez - 27/05/2019 04:06:38 p.m.
Aprobó la prórroga
Esta observación será objeto de “seguimiento posterior” por parte de la Dirección de riesgos de esta Superintendencia.
----------------------------------------
Genaro Alberto Mira Hernandez - 27/05/2019 04:06:21 p.m.
Respuesta Analizada, estado de la Observación en proceso.
----------------------------------------
",
"Revisores":"",
"Revisor":"Genaro Alberto Mira Hernandez",
"LectorUniversal":"GPALectorUniversal",
"Autor":"Genaro Alberto Mira Hernandez",
"Calificacion":"2",
"NOTAID":"321556C1CCA433E20625836A0075C5C5",
"Rol":"[Ssf]",
"RolUnidadR":"Dinf",
"UnidadR":"Departamento de Informática",
"AnexoId":"B9D8A9B1FDF1C5F70625836A007FD5E4",
"EstadoAnexo":"7",
"Estado":"2",
"FechaCalificacion":"05/27/2019 12:00:00 AM",
"Lectores":"Inmer Antonio Avalos;[Ssf];Jefatura de Auditoria Interna;[Histórico];Presidencia;CD;Gof;Gint;Gad;Dinf;Csi;DRGE;OFI;Ana Delmy Ponce de Corpeño",
"ConAnalisis":"1",
"$UpdatedBy":"CN=Genaro Alberto Mira Hernandez/O=BCR",
"$Revisions":"05/27/2019 04:05:21 PM;05/27/2019 04:06:05 PM;05/27/2019 04:06:18 PM;05/27/2019 04:06:21 PM;05/27/2019 04:06:37 PM;05/27/2019 04:06:38 PM;05/27/2019 04:06:42 PM"
}