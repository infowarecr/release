
var url = process.argv[2]
var dbname = process.argv[3]
if ((!dbname || dbname.length === 0) || (!url || url.length === 0)) {
  console.log('Invalid parameters: type, database, [host] -> expected')
  process.exit()
}
var Mongo = require('../utils/mongo').Mongo
var mongo
// var url = 'mongodb://127.0.0.1:27017/';
mongo = new Mongo(url + dbname)
/// /////PROBAR CON UN SOLO PROYECTO////////////////////
mongo.find('project', { _id: mongo.toId('5b5a4f33de4b511af85d811a') }, { _id: 1, files: 1 }, {}, async function (err, projects) {
  if (err) throw err
  if (projects && projects.length > 0) {
    for (let i in projects) {
      var proj = projects[i]
      var documents = await new Promise(resolve => {
        mongo.find('document', { project: proj._id }, {}, {}, function (err, documents) {
          if (err) { resolve(false) } else { resolve(documents) }
        })
      })

      if (documents && documents.length > 0) {
        for (let i in documents) {
          var doc = documents[i]
          if (typeof doc.content === 'string') {
            var string = doc.content
            do {
              let i = string.indexOf('/api/file.get?_id=')
              if (i !== -1) {
                string = string.substring(i)
                let id = string.substring(18, 42)
                let type = string.substring(18).split('=')[1].split('"')[0]
                if (('' + id).toString().match(/^[0-9a-fA-F]{24}$/)) {
                  var file = await new Promise(resolve => {
                    mongo.findId('fs.files', id, (err, file) => {
                      if (err) {
                        resolve(false)
                      } else { resolve(file) }
                    })
                  })
                  if (file) {
                    var flag = false
                    if (proj.files) {
                      function index (data) {
                        for (let i in data) {
                          var doc = data[i]
                          if (doc.data) { index(doc.data) }
                          if (doc.id === ('/api/file.get?_id=' + file._id.toString() + '&type=' + (type === '' ? file.contentType.split('/')[1] : type))) {
                            flag = true
                            return
                          }
                        }
                      }
                      index(proj.files)
                    }
                    if (!flag) {
                      if (proj.files) {
                        proj.files[0].data.push({
                          id: '/api/file.get?_id=' + file._id.toString() + '&type=' + (type === '' ? file.contentType.split('/')[1] : type),
                          value: file.filename,
                          type: type === '' ? file.contentType.split('/')[1] : type,
                          size: file.chunkSize,
                          date: Number(new Date().getTime().toString().substring(0, 10)),
                          reference: '/api/file.get?_id=' + file._id.toString() + '&type=' + (type === '' ? file.contentType.split('/')[1] : type)
                        })
                      } else {
                        proj.files = [
                          {
                            value: '/',
                            open: true,
                            type: 'folder',
                            date: new Date(),
                            data: [{
                              id: '/api/file.get?_id=' + file._id.toString() + '&type=' + (type === '' ? file.contentType.split('/')[1] : type),
                              value: file.filename,
                              type: type === '' ? file.contentType.split('/')[1] : type,
                              size: file.chunkSize,
                              date: Number(new Date().getTime().toString().substring(0, 10)),
                              reference: '/api/file.get?_id=' + file._id.toString() + '&type=' + (type === '' ? file.contentType.split('/')[1] : type)
                            }]
                          }
                        ]
                      }
                      if (!file.metadata || file.metadata === null) { file.metadata = {} }
                      file.metadata.document = doc._id
                      if (doc.project) { file.metadata.project = doc.project }
                      if (doc.task) { file.metadata.task = doc.task }
                      if(doc.actors.length) {file.actors=[{user: doc.actors[0].user}]}
                      await new Promise(resolve => {
                        mongo.save('fs.files', file, (err, result) => {
                          if (err) {
                            resolve(false)
                          } else { resolve(result) }
                        })
                      })
                      await new Promise(resolve => {
                        mongo.save('project', proj, (err, result) => {
                          if (err) {
                            resolve(false)
                          } else { resolve(result) }
                        })
                      })
                    }
                  }
                }
                string = string.substring(18)
              }
            } while (string.includes('/api/file.get?_id='))

            // forDocuments(doc, proj);
          }
        }
      }

      // forProjects(proj);
    }
    process.exit()
  } else {
    process.exit()
  }
})

/* function forProjects(proj) {
  mongo.find("document", { project: proj._id }, {}, {}, function (err, documents) {
    if (documents && documents.length > 0) {
      for (let i in documents) {
        var doc = documents[i];
        if (typeof doc.content === 'string')
          forDocuments(doc, proj);
      }
    }
  });
} */

/* async function forDocuments(doc, proj) {
  var string = doc.content;
  do {
    let i = string.indexOf('/api/file.get?_id=');
    if (i !== -1) {
      string = string.substring(i);
      let id = string.substring(18, 42);
      let type = string.substring(18).split('=')[1].split('"')[0];
      if (("" + id).toString().match(/^[0-9a-fA-F]{24}$/)) {

        mongo.findId('fs.files', id, (err, file) => {
          if (err) {
            process.exit();
          } else
            if (file) {
              if (project.files) {
                project.files[0].data.push({
                  id: "/api/file.get?_id=" + file._id.toString() + "&type=" + type,
                  value: file.filename,
                  type: type,
                  size: file.chunkSize,
                  date: Number(new Date().getTime().toString().substring(0, 10)),
                  reference: "/api/file.get?_id=" + file._id.toString() + "&type=" + type,
                });
              }
              else {
                project.files = [
                  {
                    value: "/", open: true, type: "folder", date: new Date(), data: [{
                      id: "/api/file.get?_id=" + file._id.toString() + "&type=" + type,
                      value: file.filename,
                      type: type,
                      size: file.chunkSize,
                      date: Number(new Date().getTime().toString().substring(0, 10)),
                      reference: "/api/file.get?_id=" + file._id.toString() + "&type=" + type,
                    }]
                  }
                ];
              }
              if (!file.metaData || file.metaData === null)
                file.metaData = {};
              file.metaData.document = doc._id;
              if (doc.project)
                file.metaData.project = doc.project;
              if (doc.task)
                file.metaData.task = doc.task;
              mongo.save("fs.files", file, (err, result) => {
                if (err) {
                  process.exit();
                } else {
                  mongo.save("project", project, (err, result) => {
                    if (err) {
                      process.exit();
                    }
                  });
                }
              });
            }

        });
      }
    }
  } while (string.includes('/api/file.get?_id='));
} */
