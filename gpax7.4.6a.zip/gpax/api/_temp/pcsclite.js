// var pcsc = require('pcsclite')
var BigInteger = require('big-integer')
var fs = require('fs')
var dirname = __dirname.substring(0, __dirname.lastIndexOf('/'))
dirname = dirname.substring(0, dirname.lastIndexOf('/'))
var chilkat = require('@chilkat/ck-node8-linux64')
var signer = require('../engine/pdfSign/nodeSignPdf.js').default
var plainAddPlaceholder = require('../engine/pdfSign/helpers/plainAddPlaceholder').default
var pem = require('pem')

async function signPk11 () {
  const graphene = require('graphene-pk11')
  let Module = graphene.Module
  let module = Module.load('/usr/lib/x64-athena/libASEP11.so')

  module.initialize()
  let session = module.getSlots(0).open()
  session.login('1587')
  var pdfBuffer = fs.readFileSync(dirname + '/api/img/test.pdf')
  pdfBuffer = plainAddPlaceholder({
    pdfBuffer,
    reason: 'Revisado',
    name: 'info.commonName',
    email: 'info.emailAddress',
    locality: 'info.locality',
    signatureLength: 214662
  })
  pdfBuffer = await signer.signWithPkcs11(pdfBuffer, dirname, session, graphene)
  await new Promise(resolve => {
    fs.writeFile(dirname + '/api/img/testfir.pdf', pdfBuffer, 'binary', function (err) {
      if (err) {
        console.log(err)
        resolve()
        session.logout()
        module.finalize()
      } else {
        console.log('Created')
        session.logout()
        module.finalize()
        resolve()
      }
    })
  })
}
signPk11()
async function graphene () {
  try {
    var graphene = require('graphene-pk11')
    var Module = graphene.Module
    var mod = Module.load('/usr/lib/x64-athena/libASEP11.so')
    mod.initialize()
    //* ********** */
    chilkatUnlocked()
    var certChilkat = new chilkat.Cert()
    var privKeyChilkat = new chilkat.PrivateKey()
    // ********* */
    var slot = mod.getSlots(0)
    var session = slot.open() // (4)
    session.login('1587')

    var objects = session.find({ class: graphene.ObjectClass.CERTIFICATE })
    for (let i = 0; i < objects.length; i++) {
      var cert = objects.items(i).toType()
      var success = certChilkat.LoadFromBinary(cert.value)
      var pri = certChilkat.ExportPrivateKey()
      var pu = certChilkat.ExportPublicKey()
      var CertPem = certChilkat.ExportCertPem()
      // console.log(cert.value.toString('hex'))
    }

    var objects = session.find({ class: graphene.ObjectClass.PRIVATE_KEY })
    for (let i = 0; i < objects.length; i++) {
      var privKey = objects.items(i).toType()
      let pdf = fs.readFileSync(dirname + '/api/img/test.pdf')
      const lastChar = pdf.slice(pdf.length - 1).toString()
      if (lastChar === '\n') {
        // remove the trailing new line
        pdf = pdf.slice(0, pdf.length - 1)
      }
      var sign = session.createSign('SHA1_RSA_PKCS', privKey)
      sign.update(pdf.toString('binary'))
      var signature = sign.final()
      console.log('Signature RSA-SHA1:', signature.toString('hex'))
      // var sign = session.createSign('RSA_PKCS', privKey).once('1587')
    }

    //* ************ */
    /* var slot = mod.getSlots(0)
    if (slot.flags & graphene.SlotFlag.TOKEN_PRESENT) {
      var session = slot.open()
      session.login('1587')
      let pdf = fs.readFileSync(dirname + '/api/img/test.pdf')
      const lastChar = pdf.slice(pdf.length - 1).toString()
      if (lastChar === '\n') {
        // remove the trailing new line
        pdf = pdf.slice(0, pdf.length - 1)
      }
      console.log('12- PDF File: ', pdf)
      // console.log("13- PDF File: ",pdf.toString('binary'));

      // -- Signature --
      var sign = session.createSign('SHA256_RSA_PKCS', session.find({ class: graphene.ObjectClass.PRIVATE_KEY }).items(0))
      sign.update(pdf)
      var signature = sign.final()
      // fs.writeFileSync(dirname + '/api/img/testfir.pdf', pdf, 'binary')
      session.logout()
    } else {
      console.error('Slot is not initialized')
    } */
  } catch (e) {
    console.error(e)
  } finally {
    mod.finalize()
  }
}
// graphene()
async function pkcs11 () {
  try {
    var pkcs11js = require('pkcs11js')
    var pkcs11 = new pkcs11js.PKCS11()
    pkcs11.load('/usr/lib/x64-athena/libASEP11.so')
    pkcs11.C_Initialize()
    var certChilkat = new chilkat.Cert()
    var privKeyChilkat = new chilkat.PrivateKey()
    // Getting info about PKCS11 Module
    var module_info = pkcs11.C_GetInfo()

    // Getting list of slots
    var slots = pkcs11.C_GetSlotList(false)
    var slot = slots[0]

    // Getting info about slot
    var slot_info = pkcs11.C_GetSlotInfo(slot)
    // Getting info about token
    var token_info = pkcs11.C_GetTokenInfo(slot)

    // Getting info about Mechanism
    var mechs = pkcs11.C_GetMechanismList(slot)
    var mech_info = pkcs11.C_GetMechanismInfo(slot, mechs[0])

    var session = pkcs11.C_OpenSession(slot, pkcs11js.CKF_RW_SESSION | pkcs11js.CKF_SERIAL_SESSION)

    // Getting info about Session
    var info = pkcs11.C_GetSessionInfo(session)
    pkcs11.C_Login(session, 1, '1587')
    // code after login
    var priKey = getPrivateKey('LlaveDeFirma')
    function getPrivateKey (label) {
      let res = {}; let list = Array()
      pkcs11.C_FindObjectsInit(session, [{ type: pkcs11js.CKA_CLASS, value: pkcs11js.CKO_PRIVATE_KEY }])
      let hObject = pkcs11.C_FindObjects(session)
      while (hObject) {
        let attrs = pkcs11.C_GetAttributeValue(session, hObject, [
          { type: pkcs11js.CKA_CLASS },
          { type: pkcs11js.CKA_TOKEN },
          { type: pkcs11js.CKA_PRIVATE },
          { type: pkcs11js.CKA_LABEL },
          { type: pkcs11js.CKA_ID }
        ])
        if (attrs[3].value.toString() === label) {
          res.id = buf2hex(attrs[4].value)
          res.label = attrs[3].value.toString()
          res.privateKey = hObject
          break
        } else {
          list.push({
            id: buf2hex(attrs[4].value),
            lable: attrs[3].value.toString(),
            privateKey: hObject
          })
        }
        hObject = pkcs11.C_FindObjects(session)
      }
      pkcs11.C_FindObjectsFinal(session)
      if (res.privateKey) {
        return res
      } else {
        if (!label) {
          return list
        }
      }
      throw Error(`No se encontró la llave privada con etiqueta ${label}.`)
    }
    function buf2hex (buff) {
      let bits = BigInteger(1); let id = BigInteger(0)
      for (let i = buff.length - 1; i >= 0; i--) {
        id = id.add(bits.multiply(buff[i]))
        bits = bits.multiply(256)
      }
      let str = id.toString()
      let dec = str.split(''); let sum = []; let hex = []; let i; let s
      while (dec.length) {
        s = 1 * dec.shift()
        for (let i = 0; s || i < sum.length; i++) {
          s += (sum[i] || 0) * 10
          sum[i] = s % 16
          s = (s - sum[i]) / 16
        }
      }
      while (sum.length) {
        hex.push(sum.pop().toString(16))
      }
      return hex.join('')
    }

    // var h = privKeyChilkat.LoadAnyFormat(priKey.privateKey, '1587')
    var keys = { privateKey: null, publicKey: null }

    pkcs11.C_FindObjectsInit(session, [
      { type: pkcs11js.CKA_CLASS, value: pkcs11js.CKO_PRIVATE_KEY },
      { type: pkcs11js.CKA_LABEL, value: 'LlaveDeAutenticacion' }
    ])
    var hObject = pkcs11.C_FindObjects(session)
    console.log('10-1/ hObject Private BEFORE WHILE: ', hObject)

    while (hObject) {
      var attrs = pkcs11.C_GetAttributeValue(session, hObject, [
        { type: pkcs11js.CKA_CLASS },
        { type: pkcs11js.CKA_TOKEN },
        { type: pkcs11js.CKA_LABEL }
      ])
      keys.privateKey = hObject
      hObject = pkcs11.C_FindObjects(session)
    }

    console.log('10-2/ hObject Private AFTER WHILE: ', hObject)
    console.log('Private KEY: ', keys.privateKey)
    pkcs11.C_FindObjectsFinal(session)

    pkcs11.C_FindObjectsInit(session, [
      { type: pkcs11js.CKA_CLASS, value: pkcs11js.CKO_PUBLIC_KEY },
      { type: pkcs11js.CKA_LABEL, value: 'LlaveDeAutenticacion' }
    ])
    var hObject = pkcs11.C_FindObjects(session)
    console.log('11-1/ hObject Public BEFORE WHILE: ', hObject)

    while (hObject) {
      var attrs = pkcs11.C_GetAttributeValue(session, hObject, [
        { type: pkcs11js.CKA_CLASS },
        { type: pkcs11js.CKA_TOKEN },
        { type: pkcs11js.CKA_LABEL }
      ])

      keys.publicKey = hObject
      hObject = pkcs11.C_FindObjects(session)
    }
    console.log('11-1/ hObject Public AFTER WHILE: ', hObject)
    console.log('Public KEY: ', keys.publicKey)
    pkcs11.C_FindObjectsFinal(session)

    let pdf = fs.readFileSync(dirname + '/api/img/test.pdf')
    const lastChar = pdf.slice(pdf.length - 1).toString()
    if (lastChar === '\n') {
      // remove the trailing new line
      pdf = pdf.slice(0, pdf.length - 1)
    }
    console.log('12- PDF File: ', pdf)
    // console.log("13- PDF File: ",pdf.toString('binary'));

    // -- Signature --
    pkcs11.C_SignInit(session, { mechanism: pkcs11js.CKM_SHA256_RSA_PKCS }, keys.privateKey)
    pkcs11.C_SignUpdate(session, pdf)

    var signature = pkcs11.C_SignFinal(session, Buffer(256))
    console.log('14- Signature: ', signature.toString('hex'))

    // Vérification
    pkcs11.C_VerifyInit(session, { mechanism: pkcs11js.CKM_SHA256_RSA_PKCS }, keys.publicKey)
    pkcs11.C_VerifyUpdate(session, pdf)

    var verify = pkcs11.C_VerifyFinal(session, signature)
    console.log('15- Vérification: ', verify)
    //

    pkcs11.C_Logout(session)
    pkcs11.C_CloseSession(session)
  } catch (e) {
    console.error(e)
  } finally {
    pkcs11.C_Finalize()
  }
}
// pkcs11()
async function Crypto () {
  var { Crypto } = require('node-webcrypto-p11')
  var config = {
    library: '/usr/lib/x64-athena/libASEP11.so',
    slot: 0,
    readWrite: true,
    pin: '1587'
  }
  var crypto = new Crypto(config)
  const privateKey = await crypto.keyStorage.getItem('LlaveDeAutenticacion')
}
// Crypto()
async function forge () {
  var forge = require('node-forge')
  forge.options.usePureJavaScript = true
}
// forge()

function chilkatUnlocked () {
  var glob = new chilkat.Global()
  var success = glob.UnlockBundle('NFWJAQ.CB1042022_zJkF8zzt3K3e')
  //glob.UnlockBundle('INFOWA.CB1062020_V8xq8zKRD72n')
  if (success !== true) {
    console.log(glob.LastErrorText)
    return
  }
  var status = glob.UnlockStatus
  if (status !== 2) {
    console.log('Unlocked in trial mode.')
  }
}
/* var session = mod.getSlots(0).open()
session.login('1587')

// Get a number of private .key objects on token
console.log(session.find({ class: graphene.ObjectClass.PRIVATE_KEY }).length)

session.logout()
mod.finalize() */

/* pcsc = pcsc()
pcsc.on('reader', function (reader) {
  console.log('New reader detected', reader.name)

  reader.on('error', function (err) {
    console.log('Error(', this.name, '):', err.message)
  })

  reader.on('status', function (status) {
    console.log('Status(', this.name, '):', status)
    // check what has changed
    var changes = this.state ^ status.state
    if (changes) {
      if ((changes & this.SCARD_STATE_EMPTY) && (status.state & this.SCARD_STATE_EMPTY)) {
        console.log('card removed')// card removed
        reader.disconnect(reader.SCARD_LEAVE_CARD, function (err) {
          if (err) {
            console.log(err)
          } else {
            console.log('Disconnected')
          }
        })
      } else if ((changes & this.SCARD_STATE_PRESENT) && (status.state & this.SCARD_STATE_PRESENT)) {
        console.log('card inserted')// card inserted
        reader.connect({ share_mode: this.SCARD_SHARE_SHARED }, function (err, protocol) {
          if (err) {
            console.log(err)
          } else {
            console.log('Protocol(', reader.name, '):', protocol)
            var cmdCommand = Buffer.from('C02000010431353837', 'hex')
            reader.transmit(cmdCommand, 255, protocol, function (err, data) {
              if (err) {
                console.log(err)
              } else {
                reader.transmit(cmdCommand, 255, protocol, function (err, data) {
                  if (err) {
                    console.log(err)
                  } else {
                console.log('Data received', data)
                reader.close()
                pcsc.close()
                  }
                })
              }
            })
          }
        })
      }
    }
  })

  reader.on('end', function () {
    console.log('Reader', this.name, 'removed')
  })
})

pcsc.on('error', function (err) {
  console.log('PCSC error', err.message)
})
 */
