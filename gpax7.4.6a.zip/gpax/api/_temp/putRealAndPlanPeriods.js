
var Mongo = require('../utils/mongo').Mongo
var mongo, mongoLog
var url = 'mongodb://127.0.0.1:27017/gpax'
mongo = new Mongo(url)
mongoLog = new Mongo('mongodb://127.0.0.1:27017/logs')
update()
async function update () {
  const projects = await new Promise(resolve => {
    mongo.find('project', { status: { $ne: 'draft' } }, (err, projects) => {
      if (err) resolve(false)
      else resolve(projects)
    })
  })
  if (projects) {
    for (const p in projects) {
      var plan, real
      var project = projects[p]
      if (project.startEnd && project.startEnd.length) {
        if (!project.planPeriod || project.planPeriod[0] === null || project.planPeriod === '[null]') {
          const period = project.startEnd.split(' / ')
          plan = [period[0] ? new Date(period[0]) : null]
          if (period[1]) {
            plan.push(new Date(period[1]))
          }
        } else {
          plan = project.planPeriod
        }
      }
      if (!project.realPeriod || project.realPeriod[0] === null || project.realPeriod === '[null]') {
        const startProject = await new Promise(resolve => {
          mongoLog.find('log', { url: 'api/project.startProject', 'input._id': project._id }, (err, startProject) => {
            if (err) resolve(false)
            else resolve(startProject)
          })
        })
        if (startProject && startProject[0]) {
          real = [startProject[0]._id.getTimestamp()]
        }
        const completeProject = await new Promise(resolve => {
          mongoLog.find('log', { url: 'api/project.completeProject', 'input._id': project._id }, (err, completeProject) => {
            if (err) resolve(false)
            else resolve(completeProject)
          })
        })
        if (completeProject && completeProject[0]) {
          real.push(completeProject[0]._id.getTimestamp())
        }
      } else {
        real = project.realPeriod
      }
      await new Promise(resolve => {
        mongo.save('project', { _id: project._id, planPeriod: plan, realPeriod: real }, (err, res) => {
          if (err) console.log(err)
          resolve(res)
        })
      })
    }
  }

  process.exit(0)
}
