var url = 'mongodb://127.0.0.1:27017/'
var dbname = 'ebill'
var Mongo = require('../utils/mongo').Mongo
var mongo
// var url = 'mongodb://127.0.0.1:27017/';
mongo = new Mongo(url + dbname)
mongo.find('company', {}, {}, {}, async (err, companies) => {
  if (err) {
    process.exit()
  } else {
    for (var i in companies) {
      var company = companies[i]
      if (company.consecutive && company.consecutive.length > 0) {
        for (var c in company.consecutive) {
          var consecutive = company.consecutive[c]
          if (consecutive.consecutiveInvoice) consecutive.consecutiveInvoice = parseInt(consecutive.consecutiveInvoice)
          if (consecutive.consecutiveTicket) consecutive.consecutiveTicket = parseInt(consecutive.consecutiveTicket)
          if (consecutive.consecutiveDebit) consecutive.consecutiveDebit = parseInt(consecutive.consecutiveDebit)
          if (consecutive.consecutiveCredit) consecutive.consecutiveCredit = parseInt(consecutive.consecutiveCredit)
          if (consecutive.consecutiveReceiver05) consecutive.consecutiveReceiver05 = parseInt(consecutive.consecutiveReceiver05)
          if (consecutive.consecutiveReceiver06) consecutive.consecutiveReceiver06 = parseInt(consecutive.consecutiveReceiver06)
          if (consecutive.consecutiveReceiver07) consecutive.consecutiveReceiver07 = parseInt(consecutive.consecutiveReceiver07)
          var consecutivoFactura = await new Promise(resolve => {
            mongo.findN('invoice', 0, 1, { company: company.idNum, sucursal: consecutive.sucursal, terminal: consecutive.terminal, tipoDocumento: '01' }, { numeroConsecutivo: 1, _id: 1 }, { _id: -1 }, (err, data) => {
              if (err || !data || data.length === 0) {
                resolve(false)
              } else {
                data = data[0]
                if (data.numeroConsecutivo) {
                  var number = data.numeroConsecutivo.slice(10, 20)
                  number = parseInt(number) + 1
                  resolve(number)
                } else {
                  resolve(false)
                }
              }
            })
          })
          if (consecutivoFactura) {
            consecutive.consecutiveInvoice = consecutivoFactura
          }
          if (consecutive.consecutiveInvoice) {
            var documentoF = {
              _id: mongo.newId(),
              company: company.idNum,
              sucursal: consecutive.sucursal,
              terminal: consecutive.terminal,
              typeDocument: '01',
              value: consecutive.consecutiveInvoice
            }
            await new Promise(resolve => {
              mongo.save('consecutive', documentoF, () => {
                resolve()
              })
            })
          }
          var consecutivoTiquete = await new Promise(resolve => {
            mongo.findN('invoice', 0, 1, { company: company.idNum, sucursal: consecutive.sucursal, terminal: consecutive.terminal, tipoDocumento: '04' }, { numeroConsecutivo: 1, _id: 1 }, { _id: -1 }, (err, data) => {
              if (err || !data || data.length === 0) {
                resolve(false)
              } else {
                data = data[0]
                if (data.numeroConsecutivo) {
                  var number = data.numeroConsecutivo.slice(10, 20)
                  number = parseInt(number) + 1
                  resolve(number)
                } else {
                  resolve(false)
                }
              }
            })
          })
          if (consecutivoTiquete) {
            consecutive.consecutiveTicket = consecutivoTiquete
          }
          if (consecutive.consecutiveTicket) {
            var documentoT = {
              _id: mongo.newId(),
              company: company.idNum,
              sucursal: consecutive.sucursal,
              terminal: consecutive.terminal,
              typeDocument: '04',
              value: consecutive.consecutiveTicket
            }
            await new Promise(resolve => {
              mongo.save('consecutive', documentoT, () => {
                resolve()
              })
            })
          }
          var consecutivoCredito = await new Promise(resolve => {
            mongo.findN('invoiceCredit', 0, 1, { company: company.idNum, sucursal: consecutive.sucursal, terminal: consecutive.terminal, tipoDocumento: '03' }, { numeroConsecutivo: 1, _id: 1 }, { _id: -1 }, (err, data) => {
              if (err || !data || data.length === 0) {
                resolve(false)
              } else {
                data = data[0]
                if (data.numeroConsecutivo) {
                  var number = data.numeroConsecutivo.slice(10, 20)
                  number = parseInt(number) + 1
                  resolve(number)
                } else {
                  resolve(false)
                }
              }
            })
          })
          if (consecutivoCredito) {
            consecutive.consecutiveCredit = consecutivoCredito
          }
          if (consecutive.consecutiveCredit) {
            var documentoC = {
              _id: mongo.newId(),
              company: company.idNum,
              sucursal: consecutive.sucursal,
              terminal: consecutive.terminal,
              typeDocument: '03',
              value: consecutive.consecutiveCredit
            }
            await new Promise(resolve => {
              mongo.save('consecutive', documentoC, () => {
                resolve()
              })
            })
          }
          var consecutivoDebito = await new Promise(resolve => {
            mongo.findN('invoiceCredit', 0, 1, { company: company.idNum, sucursal: consecutive.sucursal, terminal: consecutive.terminal, tipoDocumento: '02' }, { numeroConsecutivo: 1, _id: 1 }, { _id: -1 }, (err, data) => {
              if (err || !data || data.length === 0) {
                resolve(false)
              } else {
                data = data[0]
                if (data.numeroConsecutivo) {
                  var number = data.numeroConsecutivo.slice(10, 20)
                  number = parseInt(number) + 1
                  resolve(number)
                } else {
                  resolve(false)
                }
              }
            })
          })
          if (consecutivoDebito) {
            consecutive.consecutiveDebit = consecutivoDebito
          }
          if (consecutive.consecutiveDebit) {
            var documentoD = {
              _id: mongo.newId(),
              company: company.idNum,
              sucursal: consecutive.sucursal,
              terminal: consecutive.terminal,
              typeDocument: '02',
              value: consecutive.consecutiveDebit
            }
            await new Promise(resolve => {
              mongo.save('consecutive', documentoD, () => {
                resolve()
              })
            })
          }
          var consecutivoCompras05 = await new Promise(resolve => {
            mongo.findN('invoice2pay', 0, 1, { company: company.idNum, sucursal: consecutive.sucursal, terminal: consecutive.terminal, tipoDocumento: '05' }, { consecutive: 1, _id: 1 }, { _id: -1 }, (err, data) => {
              if (err || !data || data.length === 0) {
                resolve(false)
              } else {
                data = data[0]
                if (data.consecutive) {
                  var number = data.consecutive.slice(10, 20)
                  number = parseInt(number) + 1
                  resolve(number)
                } else {
                  resolve(false)
                }
              }
            })
          })
          if (consecutivoCompras05) {
            consecutive.consecutiveReceiver05 = consecutivoCompras05
          }
          if (consecutive.consecutiveReceiver05) {
            var documentoC5 = {
              _id: mongo.newId(),
              company: company.idNum,
              sucursal: consecutive.sucursal,
              terminal: consecutive.terminal,
              typeDocument: '05',
              value: consecutive.consecutiveReceiver05
            }
            await new Promise(resolve => {
              mongo.save('consecutive', documentoC5, () => {
                resolve()
              })
            })
          }
          var consecutivoCompras06 = await new Promise(resolve => {
            mongo.findN('invoice2pay', 0, 1, { company: company.idNum, sucursal: consecutive.sucursal, terminal: consecutive.terminal, tipoDocumento: '06' }, { consecutive: 1, _id: 1 }, { _id: -1 }, (err, data) => {
              if (err || !data || data.length === 0) {
                resolve(false)
              } else {
                data = data[0]
                if (data.consecutive) {
                  var number = data.consecutive.slice(10, 20)
                  number = parseInt(number) + 1
                  resolve(number)
                } else {
                  resolve(false)
                }
              }
            })
          })
          if (consecutivoCompras06) {
            consecutive.consecutiveReceiver06 = consecutivoCompras06
          }
          if (consecutive.consecutiveReceiver06) {
            var documentoC6 = {
              _id: mongo.newId(),
              company: company.idNum,
              sucursal: consecutive.sucursal,
              terminal: consecutive.terminal,
              typeDocument: '06',
              value: consecutive.consecutiveReceiver06
            }
            await new Promise(resolve => {
              mongo.save('consecutive', documentoC6, () => {
                resolve()
              })
            })
          }
          var consecutivoCompras07 = await new Promise(resolve => {
            mongo.findN('invoice2pay', 0, 1, { company: company.idNum, sucursal: consecutive.sucursal, terminal: consecutive.terminal, tipoDocumento: '07' }, { consecutive: 1, _id: 1 }, { _id: -1 }, (err, data) => {
              if (err || !data || data.length === 0) {
                resolve(false)
              } else {
                data = data[0]
                if (data.consecutive) {
                  var number = data.consecutive.slice(10, 20)
                  number = parseInt(number) + 1
                  resolve(number)
                } else {
                  resolve(false)
                }
              }
            })
          })
          if (consecutivoCompras07) {
            consecutive.consecutiveReceiver07 = consecutivoCompras07
          }
          if (consecutive.consecutiveReceiver07) {
            var documentoC7 = {
              _id: mongo.newId(),
              company: company.idNum,
              sucursal: consecutive.sucursal,
              terminal: consecutive.terminal,
              typeDocument: '07',
              value: consecutive.consecutiveReceiver07
            }
            await new Promise(resolve => {
              mongo.save('consecutive', documentoC7, () => {
                resolve()
              })
            })
          }
        }
      }
    }
    process.exit()
  }
})
