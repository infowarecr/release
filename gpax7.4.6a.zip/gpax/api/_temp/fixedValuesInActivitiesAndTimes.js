var urlUsers = process.argv[2]
if (!urlUsers || urlUsers.length === 0) {
  console.log('Invalid parameters: urlUsers -> expected')
  process.exit()
}
var Mongo = require('./utils/mongo').Mongo
var mongoUsers
mongoUsers = new Mongo(urlUsers)

mongoUsers.distinct('user', 'database', { active: true }, async function (err, databases) {
  if (err) { throw err }
  // probar con gpa7
  databases = ['mongodb://127.0.0.1:27017/gpa7']
  for (const i in databases) {
    const mongoDb = new Mongo(databases[i])
    var plans = await new Promise(resolve => {
      mongoDb.find('plan', { $or: [{ 'activities.data.value': { $type: 2 } }, { 'activities.data.value': { $type: 10 } }] }, { _id: 1, activities: 1 }, async (err, plans) => {
        if (!err) {
          resolve(plans)
        } else {
          resolve(false)
        }
      })
    })
    if (plans) {
      for (const i in plans) {
        if (plans[i].activities) {
          for (const d in plans[i].activities.data) {
            if (plans[i].activities.data[d].value === null) {
              plans[i].activities.data[d].value = 0
            } else if (typeof plans[i].activities.data[d].value === 'string') {
              plans[i].activities.data[d].value = plans[i].activities.data[d].value.replace(/,/g, '.')
              if (Number.isNaN(Number(plans[i].activities.data[d].value))) {
                plans[i].activities.data[d].value = 0
              } else {
                plans[i].activities.data[d].value = Number(plans[i].activities.data[d].value)
              }
            }
          }
          await new Promise(resolve => {
            mongoDb.save('plan', plans[i], async (err, result) => {
              if (!err) {
                resolve(result)
              } else {
                resolve(false)
              }
            })
          })
        }
      }
    }

    var times = await new Promise(resolve => {
      mongoDb.find('time', { $or: [{ duration: { $type: 2 } }, { duration: { $type: 10 } }] }, { _id: 1, duration: 1 }, async (err, times) => {
        if (!err) {
          resolve(times)
        } else {
          resolve(false)
        }
      })
    })
    if (times) {
      for (const i in times) {
        if (times[i].duration) {
          if (times[i].duration === null) {
            times[i].duration = 0
          } else if (typeof times[i].duration === 'string') {
            times[i].duration = times[i].duration.replace(/,/g, '.')
            if (Number.isNaN(Number(times[i].duration))) {
              times[i].duration = 0
            } else {
              times[i].duration = Number(times[i].duration)
            }
          }

          await new Promise(resolve => {
            mongoDb.save('time', times[i], async (err, result) => {
              if (!err) {
                resolve(result)
              } else {
                resolve(false)
              }
            })
          })
        }
      }
    }
    process.exit()
  }
})
