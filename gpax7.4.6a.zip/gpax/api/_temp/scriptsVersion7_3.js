var url = process.argv[2]
var dbname = process.argv[3]
if ((!dbname || dbname.length === 0) || (!url || url.length === 0)) {
  console.log('Invalid parameters: type, database, [host] -> expected')
  process.exit()
}
var Mongo = require('../utils/mongo').Mongo
var mongo
// var url = 'mongodb://127.0.0.1:27017/';
mongo = new Mongo(url + dbname)
var tasksDurationDaysToHoursProjects = async (mongo) => {
  return await new Promise(resolve => {
    mongo.find('project', {}, {}, {}, async function (err, projects) {
      if (err) {
        console.log(err)
        resolve(false)
      } else {
        console.log('proyectos encontrados: ' + projects.length)
        console.log('iniciado tasksDurationDaysToHoursProjects')
        for (var p in projects) {
          let project = projects[p]
          console.log(Number(p) + 1 + ' de ' + projects.length)
          if (project.content && project.content.data) {
            for (var d in project.content.data) {
              let task = project.content.data[d]
              let findId = task.id
              if (task.id.length === 24) {
                findId = mongo.toId(task.id)
              }
              let exist = await new Promise(resolve => {
                mongo.findOne('taskMigrated', { oldId: findId, project: project._id }, {}, (err, doc) => {
                  if (doc) {
                    resolve(true)
                  } else {
                    resolve(false)
                  }
                })
              })
              if(!exist) {
                task._id = mongo.newId()
                task.project = project._id
                var links = []
                if (task.start_date && task.start_date.length < 10) {
                  let newStart = ''
                  let dat = task.start_date.split('-')
                  if (dat[1].length === 1) {
                    dat[1] = '0' + dat[1]
                  }
                  if (dat[2].length === 1) {
                    dat[2] = '0' + dat[2]
                  }
                  for (let i in dat) {
                    if (i === '0') newStart = newStart + dat[i]
                    else newStart = newStart + '-' + dat[i]
                  }
                  task.start_date = newStart
                }
                if (task.start_date && task.start_date.length === 10) {
                  task.start_date += ' 00:00'
                  if (task.end_date) {
                    task.end_date += ' 00:00'
                  } else {
                    task.end_date = task.start_date
                  }
                  if (!task.owner_id) {
                    task.duration = (task.duration * 8) * 60
                  } else {
                    let user = await new Promise(resolve => {
                      mongo.findId('user', task.owner_id, (err) => {
                        if (err) {
                          console.log(err)
                          resolve()
                        } else {
                          resolve()
                        }
                      })
                    })
                    if (user && user.business && user.business.workDay) {
                      task.duration = (task.duration * Number(user.business.workDay)) * 60
                    } else {
                      task.duration = (task.duration * 8) * 60
                    }
                  }
                }
                if (task.start_date && task.start_date.length === 10) {
                  task.start_date += ' 00:00'
                  if (task.end_date) {
                    task.end_date += ' 00:00'
                  } else {
                    task.end_date = task.start_date
                  }
                }
                if (project.content.links && project.content.links.length > 0) {
                  project.content.links.forEach(l => {
                    if (l.source.toString() === task.id.toString()) {
                      links.push(l)
                    }
                  })
                }
                task.links = links
                if (project.content.calendars && project.content.calendars.length > 0) {
                  project.content.calendars.forEach(c => {
                    if (c.id.includes && c.id.includes(task.id.toString())) {
                      task.calendar = c
                    }
                  })
                }
                let migrated = {
                  _id: task._id,
                  project: project._id,
                  oldId: task.id
                }
                await new Promise(resolve => {
                  mongo.save('taskMigrated', migrated, (err, res) => {
                    resolve()
                  })
                })
                await new Promise(resolve => {
                  mongo.save('task', task, (err, res) => {
                    resolve()
                  })
                })
              }
            }
          }
        }
        console.log('terminado tasksDurationDaysToHoursProjects')
        resolve(true)
      }
    })
  })
}

var tasksDurationDaysToHoursTemplates = async (mongo) => {
  return await new Promise(resolve => {
    mongo.find('template', { type: 'project', newVersion: { $exists: 0 } }, {}, {}, async function (err, templates) {
      if (err) {
        console.log(err)
        resolve(false)
      } else {
        console.log('modelos encontrados: ' + templates.length)
        console.log('iniciado tasksDurationDaysToHoursTemplates')
        for (var p in templates) {
          let template = templates[p]
          console.log(Number(p) + 1 + ' de ' + templates.length)
          if (template.template && template.template.data) {
            for (var d in template.template.data) {
              let task = template.template.data[d]
              if (task.start_date && task.start_date.length === 10) {
                task.start_date += ' 00:00'
                task.end_date += ' 00:00'
                task.duration = (task.duration * 8) * 60
              }
              template.newVersion = true
              await new Promise(resolve => {
                mongo.save('template', template, (err, res) => {
                  resolve()
                })
              })
            }
          }
        }
        console.log('terminado tasksDurationDaysToHoursTemplates')
        resolve(true)
      }
    })
  })
}

var oldActivitiesToNew = async (mongo) => {
  return await new Promise(resolve => {
    mongo.find('plan', {}, {}, {}, async (err, plans) => {
      if (err) {
        console.log(err)
        resolve(false)
      } else {
        console.log('corrigiendo ' + plans.length + ' planes')
        console.log('iniciado oldActivitiesToNew')
        if (plans && plans.length > 0) {
          for (var i in plans) {
            let plan = plans[i]
            console.log(Number(i) + 1 + ' de ' + plans.length)
            if (plan.activities && plan.activities.activities) {
              for (var a in plan.activities.activities) {
                let activity = plan.activities.activities[a]
                let activityId = mongo.newId()
                let objActivity = {
                  _id: activityId,
                  name: activity,
                  plan: plan._id,
                  doc_id: a,
                  description: '',
                  tagActivity: '',
                  template: '',
                  active: '1'
                }
                await new Promise(resolve => { mongo.save('activity', objActivity, (err, result) => { resolve() }) })
                if (plan.activities.data && plan.activities.data.length) {
                  for (var d in plan.activities.data) {
                    let data = plan.activities.data[d]
                    if (data.activity.toString() === a.toString()) {
                      let jornada = await new Promise(resolve => {
                        if (data.user) {
                          mongo.findId('user', data.user, (err, user) => {
                            if (user && user.business && user.business.workDay) {
                              resolve(Number(user.business.workDay))
                            } else {
                              resolve(8)
                            }
                          })
                        } else {
                          resolve(8)
                        }
                      })
                      let objActivityUser = {
                        _id: {
                          plan: plan._id,
                          activity: activityId,
                          user: data.user
                        },
                        planned: data.value ? (parseFloat(data.value) * 60) * jornada : 0
                      }
                      await new Promise(resolve => { mongo.save('activityUser', objActivityUser, (err, result) => { resolve() }) })
                    }
                  }
                }
              }
            }
          }
        }
        console.log('terminado oldActivitiesToNew')
        resolve(true)
      }
    })
  })
}

var timeReportsToNewView = async (mongo) => {
  return await new Promise(resolve => {
    mongo.find('time', { document: { $exists: 0 } }, {}, {}, async (err, times) => {
      if (err) {
        console.log(err)
        resolve(false)
      } else {
        console.log('corrigiendo ' + times.length + ' reportes de tiempo')
        console.log('iniciado timeReportsToNewView')
        if (times && times.length > 0) {
          for (var i in times) {
            let time = times[i]
            console.log(Number(i) + 1 + ' de ' + times.length)
            if (time.type === 'task') {
              time.document = time.task
              if (time.document) time.task = time.name
              if (time.duration) time.duration = parseFloat(time.duration) * 60
              await new Promise(resolve => { mongo.save('time', time, (err, result) => { resolve() }) })
            } else if (time.type === 'activity' && time.doc_id) {
              let document = await new Promise(resolve => {
                mongo.findOne('activity', { doc_id: time.doc_id, plan: time.plan }, {}, (err, act) => {
                  if (act) {
                    resolve(act)
                  } else {
                    resolve()
                  }
                })
              })
              if (document) {
                time.document = document._id
                if (time.duration) time.duration = parseFloat(time.duration) * 60
                await new Promise(resolve => { mongo.save('time', time, (err, result) => { resolve() }) })
              }
            }
          }
        }
        console.log('terminado timeReportsToNewView')
        resolve(true)
      }
    })
  })
}

var migratedTaskids = async (mongo) => {
  return await new Promise(resolve => {
    mongo.find('document', { task: { $exists: 1 }, project: { $exists: 1 } }, {}, {}, async (err, docs) => {
      if (err) {
        console.log(err)
        resolve(false)
      } else {
        console.log('corrigiendo ' + docs.length + ' documentos')
        console.log('iniciado migratedTaskids')
        if (docs && docs.length > 0) {
          for (let i in docs) {
            let doc = docs[i]
            console.log(Number(i) + 1 + ' de ' + docs.length)
            let findId = doc.task
            if (doc.task && doc.task.length === 24) {
              findId = mongo.toId(doc.task)
            }
            let exist = await new Promise(resolve => {
              mongo.findOne('taskMigrated', { oldId: findId, project: doc.project }, {}, (err, tk) => {
                if (tk) {
                  resolve(tk)
                } else {
                  resolve(false)
                }
              })
            })
            if (exist) {
              doc.task = exist._id
              await new Promise(resolve => {
                mongo.save('document', doc, (err, res) => {
                  resolve()
                })
              })
            }
          }
          mongo.find('time', { document: { $exists: 1 }, type: 'task' }, {}, {}, async (err, times) => {
            if (err) {
              console.log(err)
              resolve(false)
            } else {
              console.log('corrigiendo ' + times.length + ' tiempos')
              if (times && times.length > 0) {
                for (let i in times) {
                  let time = times[i]
                  console.log(Number(i) + 1 + ' de ' + times.length)
                  let findId = time.document
                  if (time.document && time.document.length === 24) {
                    findId = mongo.toId(time.document)
                  }
                  let exist = await new Promise(resolve => {
                    mongo.findOne('taskMigrated', { oldId: findId, project: time.project }, {}, (err, tk) => {
                      if (tk) {
                        resolve(tk)
                      } else {
                        resolve(false)
                      }
                    })
                  })
                  if (exist) {
                    time.document = exist._id
                    await new Promise(resolve => {
                      mongo.save('time', time, (err, res) => {
                        resolve()
                      })
                    })
                  }
                }
                console.log('terminado migratedTaskids')
                resolve(true)
              } else {
                console.log('terminado migratedTaskids')
                resolve(true)
              }
            }
          })
        } else {
          console.log('terminado migratedTaskids')
          resolve(true)
        }
      }
    })
  })
}

var tasks_idtoid = async (mongo) => {
  return await new Promise(resolve => {
    mongo.find('task', {}, {}, {}, async (err, tasks) => {
      if (err) {
        console.log(err)
        resolve(false)
      } else {
        console.log('corrigiendo ' + tasks.length + ' tareas')
        console.log('iniciado tasks_idtoid')
        if (tasks && tasks.length > 0) {
          for (let i in tasks) {
            console.log(Number(i) + 1 + ' de ' + tasks.length)
            let task = tasks[i]
            task.oldId = task.id
            task.id = task._id
            await new Promise(resolve => { mongo.save('task', task, (err, result) => { resolve() }) })
          }
          tasks = await new Promise(resolve => {
            mongo.find('task', {}, {}, {}, async (err, tasks) => {
              if (err) {
                console.log(err)
                resolve(false)
              } else {
                resolve(tasks)
              }
            })
          })
          if (tasks) {
            for (let i in tasks) {
              console.log(Number(i) + 1 + ' de ' + tasks.length)
              let task = tasks[i]
              let parents = await new Promise(resolve => {
                mongo.find('task', { parent: task.oldId, project: task.project }, {}, (err, tks) => {
                  if (tks && tks.length) {
                    resolve(tks)
                  } else {
                    resolve([])
                  }
                })
              })
              for (let t in parents) {
                console.log(Number(t) + 1 + ' parents de ' + parents.length)
                let parent = parents[t]
                parent.parent = task._id
                await new Promise(resolve => { mongo.save('task', parent, (err, result) => { resolve() }) })
              }
            }
            tasks = await new Promise(resolve => {
              mongo.find('task', {}, {}, {}, async (err, tasks) => {
                if (err) {
                  console.log(err)
                  resolve(false)
                } else {
                  resolve(tasks)
                }
              })
            })
            if (tasks) {
              for (let i in tasks) {
                console.log(Number(i) + 1 + ' de ' + tasks.length)
                let task = tasks[i]
                if (task.links && task.links.length) {
                  for (let l in task.links) {
                    let link = task.links[l]
                    if (link.source) {
                      let sourceTask = await new Promise(resolve => {
                        mongo.findOne('task', { oldId: link.source, project: task.project }, {}, (err, tks) => {
                          if (tks) {
                            resolve(tks)
                          } else {
                            resolve([])
                          }
                        })
                      })
                      link.source = sourceTask._id
                    }
                    if (link.target) {
                      let targetTask = await new Promise(resolve => {
                        mongo.findOne('task', { oldId: link.target, project: task.project }, {}, (err, tks) => {
                          if (tks) {
                            resolve(tks)
                          } else {
                            resolve([])
                          }
                        })
                      })
                      link.target = targetTask._id
                    }
                  }
                  await new Promise(resolve => { mongo.save('task', task, (err, result) => { resolve() }) })
                }
              }
            } else {
              resolve(false)
            }
          } else {
            resolve(false)
          }
        }
        console.log('terminado tasks_idtoid')
        resolve(true)
      }
    })
  })
}

//ejecutar en orden
var go = async () => {
  let result = await tasksDurationDaysToHoursProjects(mongo)
  if (result) {
    result = await timeReportsToNewView(mongo)
    if (result) {
      result = await migratedTaskids(mongo)
      if (result) {
        result = await tasks_idtoid(mongo)
        if (result) {
          process.exit()
          //await migratedTaskids(mongo)
        } else {
          process.exit()
        }
      } else {
        process.exit()
      }
    } else {
      process.exit()
    }
  } else {
    process.exit()
  }
}
go()