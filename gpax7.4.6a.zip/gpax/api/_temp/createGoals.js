 var goals = []
    var hash = {}
    mongo.find('project', { plan: mongo.toId(req.query._id) }, { unit: 1 }, async (err, projects) => { 
     for (var p in projects) {
      var unit = await new Promise(resolve => {
        mongo.findId('unit', projects[p].unit, { code: 1, name:1 }, async (err, unit) => {
          if (err || !unit) {
            resolve(false)
          } else {
            resolve(unit)
          }
        })
      })
       if (unit) {
         if (!hash[unit._id]) {
           hash[unit._id] = {
             "id": mongo.newId(),
             "status": "draft",
             "progress": 0,
             "open": true,
             "deleted": null,
             "objective": "",
             "sequence": unit.code,
             "name": "DESARROLLAR EL PLAN ANUAL DE " + unit.name.toUpperCase(),
             "description": "",
             "projects": [projects[p]._id],
           }
           goals.push(hash[unit._id])
         }
         else {
           hash[unit._id].projects.push(projects[p]._id)
         }
       }
       
     }
     await new Promise(resolve => {
        mongo.save('plan', { _id: mongo.toId(req.query._id), goals: goals }, () => { resolve() })
      })
    })