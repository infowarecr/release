var app = require('./utils/main')

app.init({
  session: 'mongodb://gpax1,gpax2/sessions',
  user: 'mongodb://gpax1,gpax2/users',
  notify: 'mongodb://gpax1,gpax2/notify',
  log: 'mongodb://gpax1,gpax2/logs',
  outlook: 'gpax.io',
  logger: 'full',
  host: '127.0.0.1',
  port: process.argv[2] || 8082,
  ebillEnvironment: 'Produccion'
})