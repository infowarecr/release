var app = require('./utils/main')
app.init({
  session: 'mongodb://127.0.0.1:27017/sessions',
  user: 'mongodb://127.0.0.1:27017/users_dev',
  notify: 'mongodb://127.0.0.1:27017/notify_dev',
  log: 'mongodb://127.0.0.1:27017/logs_dev',
  background: 'mongodb://127.0.0.1:27017/ebill_dev',
  outlook: 'dev.gpax.io',
  logger: 'basic',
  port: process.argv[2] || 8082,
  ebillEnvironment: 'Pruebas'
})
