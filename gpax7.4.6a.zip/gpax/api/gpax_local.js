var app = require('./utils/main')
var os = require('os')
app.init({
  session: 'mongodb://localhost/sessions',
  user: process.env.users,
  notify: 'mongodb://localhost/notify',
  log: 'mongodb://localhost/logs',
  outlook: os.hostname(),
  logger: 'full',
  port: 8082
})
