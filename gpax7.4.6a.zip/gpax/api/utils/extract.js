var parseHtml = require('node-html-parser')
var dateformat = require('dateformat')

var moment = require('moment')
/* exported */
exports.Extract = Extract

function Extract () {
  this.plan = async function (mongo, planId, html) {
    var plan = await new Promise(resolve => {
      mongo.findId('plan', planId, {}, (err, plan) => {
        if (!err) {
          resolve(plan)
        } else {
          resolve(false)
        }
      })
    })
    if (plan) {
      if (plan.strategy) {
        var strategy = await new Promise(resolve => {
          mongo.findId('strategy', plan.strategy, {}, (err, strategy) => {
            if (!err) {
              resolve(strategy)
            } else {
              resolve(false)
            }
          })
        })
        html = html.replace(new RegExp('{{#mision}}', 'g'), strategy.mission)
        html = html.replace(new RegExp('{{#vision}}', 'g'), strategy.vision)

        if (strategy.description.indexOf('id="valores"') !== -1) {
          const root = parseHtml.parse(strategy.description)
          html = html.replace(new RegExp('{{#valores}}', 'g'), root.querySelectorAll('#valores')[0].innerHTML)
        } else {
          html = html.replace(new RegExp('{{#valores}}', 'g'), strategy.description)
        }
      }
      if (plan.description.indexOf('id="objetivoEstrategico"') !== -1) {
        const root = parseHtml.parse(plan.description)
        html = html.replace(new RegExp('{{#objetivoEstrategico}}', 'g'), root.querySelectorAll('#objetivoEstrategico')[0].innerHTML)
      } else {
        html = html.replace(new RegExp('{{#objetivoEstrategico}}', 'g'), plan.description)
      }
      let seccion5 = '<table class="gpaxTable"   border="1"  cellspacing="0" cellpadding="5" style=" width: 100%">' +
        '<colgroup>' +
        '<col style="width: 10%">' +
        '<col style="width: 30%">' +
        '<col style="width: 30%">' +
        '<col style="width: 30%">' +
        '</colgroup>' +
        '<tr>' +
        '<th align="center"  colspan="2">Objetivos Estratégicos</th>' +
        '<th align="center">Análisis FODA Auditoría Interna (Fortalezas y Oportunidades)</th>' +
        '<th align="center">Objetivos Estratégicos Auditoría Interna</th>' +
        '</tr>'

      if (plan.strategy && strategy && strategy.objectives) {
        for (const o in strategy.objectives) {
          const objective = strategy.objectives[o]
          seccion5 += '<tr>'
          seccion5 += '<td >' + objective.sequence + '</td>'
          seccion5 += '<td >' + objective.name + '</td>'
          seccion5 += '<td ></td>'
          let goals = ''
          if (plan.goals && plan.goals.length) {
            plan.goals.forEach(x => {
              if (x.objective.toString() === objective.id.toString()) {
                goals += (x.sequence ? x.sequence + '. ' : '') + x.name + '</br>'
              }
            })
          }
          seccion5 += '<td >' + goals + '</td>'
          seccion5 += '</tr>'
        }
      }
      seccion5 += '</table>'
      html = html.replace(new RegExp('{{#objetivosEstrategicosAuditoria/BH}}', 'g'), seccion5)
      let seccion7 = ''

      if (plan.strategy && strategy && strategy.objectives) {
        for (const o in strategy.objectives) {
          const objective = strategy.objectives[o]
          if (objective.parent === '' || objective.parent === 0 || !objective.parent) {
            var num = 0
            num = numProjects(objective, num, strategy, plan)
            let table = '<table class="gpaxTable"  border="1"  cellspacing="0" cellpadding="5" style="width: 100%">' +
              '<colgroup>' +
              '<col style="width: 10%">' +
              '<col style="width: 60%">' +
              '<col style="width: 20%">' +
              '</colgroup>' +
              '<tr>' +
              '<th >' + objective.sequence + '</th>' +
              '<th >' + objective.name + '</th>' +
              '<td  rowspan="3">' + num + ' Actividades</td>' +
              '</tr>'
            strategy.objectives.forEach(x => {
              if (x.parent && x.parent.toString() === objective.id.toString()) {
                table += '<tr>' +
                  '<td >' + x.sequence + '</td>' +
                  '<td >' + x.name + '</td>' +
                  '</tr>'
              }
            })
            table += '</table></br>'
            seccion7 += table
          }
        }
      }
      html = html.replace(new RegExp('{{#numeroAuditorias}}', 'g'), seccion7)

      let seccion9 = '<table class="gpaxTable"  border="1"  cellspacing="0" cellpadding="5" style="width: 100%">' +
        '<colgroup>' +
        '<col style="width: 25%">' +
        '<col style="width: 25%">' +
        '<col style="width: 50%">' +
        '</colgroup>' +
        '<tr>' +
        '<th align="center" ><span style="font-weight:bold">Cargo</span></th>' +
        '<th align="center" ><span style="font-weight:bold">Nombre</span></th>' +
        '<th align="center" ><span style="font-weight:bold">Cualificación</span></th>' +
        '</tr>'
      var users = await new Promise(resolve => {
        mongo.find('user', { licensedUser: true }, {}, (err, users) => {
          if (!err) {
            resolve(users)
          } else {
            resolve(false)
          }
        })
      })
      if (users) {
        for (const u in users) {
          const user = users[u]
          seccion9 += '<tr>' +
            '<td >' + (user.position || '') + '</td>' +
            '<td >' + (user.name || '') + '</td>' +
            '<td >' + (user.competencies || '') + '</td>' +
            '</tr>'
        }
      }
      seccion9 += '</table>'
      html = html.replace(new RegExp('{{#capitalHumano}}', 'g'), seccion9)

      let seccion9_2 = '<table class="gpaxTable"  border="1"  cellspacing="0" cellpadding="5" style="width: 100%">' +
        '<colgroup>' +
        '<col style="width: 50%">' +
        '<col style="width: 16%">' +
        '<col style="width: 16%">' +
        '<col style="width: 16%">' +
        '</colgroup>' +
        '<tr>' +
        '<th align="center" ><span style="font-weight:bold">Usuario</span></th>' +
        '<th align="center" ><span style="font-weight:bold">horas hábiles</span></th>' +
        '<th align="center" ><span style="font-weight:bold">Horas en actividades</span></th>' +
        '<th align="center" ><span style="font-weight:bold">Horas disponibles</span></th>' +
        '</tr>'
      let holiday = false
      let days = 0
      let hoursTotal = 0
      let hoursHTotal = 0
      let hoursDTotal = 0
      let daysTotal = 0
      let daysHTotal = 0
      let daysDTotal = 0
      const start = moment(plan.period.start).startOf('day')
      const end = moment(plan.period.end).endOf('day')
      while (start._d < end._d) {
        start.add(1, 'days')
        if (plan && plan.holidays.length) {
          for (const x in plan.holidays) {
            if (start.format('YYYY/MM/DD') === plan.holidays[x]) {
              holiday = true
              break
            } else {
              holiday = false
            }
          }
        } else {
          holiday = false
        }
        if (start.isoWeekday() !== 6 && start.isoWeekday() !== 7 && !holiday) {
          days += 1
        }
      }
      if (users) {
        for (const u in users) {
          let daysH = 0
          const user = users[u]
          if (plan.activities && plan.activities.data) {
            plan.activities.data.forEach(a => {
              if (a.user.toString() === user._id.toString()) {
                daysH = daysH + (!isNaN(Number(a.value)) ? Number(a.value) : 0)
              }
            })
          }
          daysTotal = daysTotal + days
          daysHTotal = daysHTotal + daysH
          daysDTotal = daysDTotal + (days - daysH)
          hoursTotal = hoursTotal + (days * (!isNaN(Number(user.workDay)) ? Number(user.workDay) : 8))
          hoursHTotal = hoursHTotal + (daysH * (!isNaN(Number(user.workDay)) ? Number(user.workDay) : 8))
          hoursDTotal = hoursDTotal + ((days * (!isNaN(Number(user.workDay)) ? Number(user.workDay) : 8)) - (daysH * (!isNaN(Number(user.workDay)) ? Number(user.workDay) : 8)))
          seccion9_2 += '<tr>' +
          '<td >' + (user.name || '') + '</td>' +
          '<td >' + (days * (!isNaN(Number(user.workDay)) ? Number(user.workDay) : 8)) + ' (' + days + ' días)</td>' +
          '<td >' + (daysH * (!isNaN(Number(user.workDay)) ? Number(user.workDay) : 8)) + ' (' + daysH + ' días)</td>' +
          '<td >' + ((days * (!isNaN(Number(user.workDay)) ? Number(user.workDay) : 8)) - (daysH * (!isNaN(Number(user.workDay)) ? Number(user.workDay) : 8))) + ' (' + (days - daysH) + ' días)</td>' +
          '</tr>'
        }

        seccion9_2 += '<tr>' +
          '<td ><span style="font-weight:bold">Total: </span></td>' +
          '<td ><span style="font-weight:bold">' + hoursTotal + ' (' + daysTotal + ' días)</span></td>' +
          '<td ><span style="font-weight:bold">' + hoursHTotal + ' (' + daysHTotal + ' días)</span></td>' +
          '<td ><span style="font-weight:bold">' + hoursDTotal + ' (' + daysDTotal + ' días)</span></td>' +
          '</tr>' +
          '</table>'
        html = html.replace(new RegExp('{{#horasDisponibles}}', 'g'), seccion9_2)

        let seccion10 = '<table class="gpaxTable"  border="1"  cellspacing="0" cellpadding="5"style="width: 100%">' +
        '<colgroup>' +
        '<col style="width: 70%">' +
        '<col style="width: 20%">' +
        '<col style="width: 10%">' +
        '</colgroup>' +
        '<tr>' +
        '<th align="center" ><span style="font-weight:bold">Detalles Horas Asignadas</span></th>' +
        '<th align="center" ><span style="font-weight:bold">Horas</span></th>' +
        '<th align="center" ><span style="font-weight:bold">%</span></th>' +
        '</tr>'

        var projects = await new Promise(resolve => {
          mongo.aggregate('project', [
            { $match: { plan: plan._id } },
            {
              $lookup: {
                from: 'template',
                let: { id: '$project' },
                pipeline: [
                  {
                    $match: {
                      $expr:
                    {
                      $and:
                        [
                          { $eq: ['$_id', '$$id'] }
                        ]
                    }
                    }
                  },
                  { $project: { templateName: '$name', template_id: '$_id' } }
                ],
                as: 'fromTemplate'
              }
            },
            {
              $replaceRoot: { newRoot: { $mergeObjects: [{ $arrayElemAt: ['$fromTemplate', 0] }, '$$ROOT'] } }
            },
            { $project: { fromTemplate: 0 } },
            {
              $group: { _id: '$type', projects: { $push: '$$ROOT' } }
            }
          ], {}, (err, projects) => {
            if (!err) {
              resolve(projects)
            } else {
              resolve(false)
            }
          })
        })
        if (projects) {
          const sumHours = {}
          let total = 0
          for (const t in projects) {
            const doc = projects[t]
            switch (doc._id) {
            case 'mandatory':
            case 'byRisk':
              for (const p in doc.projects) {
                const project = doc.projects[p]
                if (project.planPeriod) {
                  let days = 0
                  const start = moment(project.planPeriod[0]).startOf('day')
                  const end = moment(project.planPeriod[1]).endOf('day')
                  while (start._d < end._d) {
                    start.add(1, 'days')
                    if (plan && plan.holidays.length) {
                      for (const x in plan.holidays) {
                        if (start.format('YYYY/MM/DD') === plan.holidays[x]) {
                          holiday = true
                          break
                        } else {
                          holiday = false
                        }
                      }
                    } else {
                      holiday = false
                    }
                    if (start.isoWeekday() !== 6 && start.isoWeekday() !== 7 && !holiday) {
                      days += 1
                    }
                  }
                  total = total + days
                  if (!sumHours.Auditorias) {
                    sumHours.Auditorias = { name: 'Auditorías', days: days }
                  } else {
                    sumHours.Auditorias.days = sumHours.Auditorias.days + days
                  }
                }
              }
              break
            case 'recurrent':
              for (const p in doc.projects) {
                const project = doc.projects[p]
                if (project.planPeriod) {
                  let days = 0
                  const start = moment(project.planPeriod[0]).startOf('day')
                  const end = moment(project.planPeriod[1]).endOf('day')
                  while (start._d < end._d) {
                    start.add(1, 'days')
                    if (plan && plan.holidays.length) {
                      for (const x in plan.holidays) {
                        if (start.format('YYYY/MM/DD') === plan.holidays[x]) {
                          holiday = true
                          break
                        } else {
                          holiday = false
                        }
                      }
                    } else {
                      holiday = false
                    }
                    if (start.isoWeekday() !== 6 && start.isoWeekday() !== 7 && !holiday) {
                      days += 1
                    }
                  }
                  total = total + days
                  if (!sumHours[project.template_id.toString()]) {
                    sumHours[project.template_id.toString()] = { name: project.templateName, days: days }
                  } else {
                    sumHours[project.template_id.toString()].days = sumHours[project.template_id.toString()].days + days
                  }
                }
              }
              break
            }
          }
          for (const prop in sumHours) {
            seccion10 += '<tr>' +
              `<td >${sumHours[prop].name}</td>` +
              `<td >${(sumHours[prop].days * 8)}</td>` +
              `<td >${((100 * (sumHours[prop].days * 8)) / (total * 8))} %</td>` +
              '</tr>'
          }
          seccion10 += '<tr>' +
            '<td ><span style="font-weight:bold">Total Horas Hábiles - Año</span></td>' +
            `<td >${(total * 8)}</td>` +
            '<td >100 %</td>' +
            '</tr>' +
          '</table>'
          html = html.replace(new RegExp('{{#distribucionHoras}}', 'g'), seccion10)

          let seccion11 = `<table class="gpaxTable"  border="1"  cellspacing="0" cellpadding="5" style="width: 911px">
            <colgroup>
            <col style="width: 299px">
            <col style="width: 51px">
            <col style="width: 51px">
            <col style="width: 51px">
            <col style="width: 51px">
            <col style="width: 51px">
            <col style="width: 51px">
            <col style="width: 51px">
            <col style="width: 51px">
            <col style="width: 51px">
            <col style="width: 51px">
            <col style="width: 51px">
            <col style="width: 51px">
            </colgroup>
              <tr>
                <th align="center" ><span style="font-weight:bold">Proyecto</span></th>
                <th align="center" ><span style="font-weight:bold">ENE</span></th>
                <th align="center" ><span style="font-weight:bold">FEB</span></th>
                <th align="center" ><span style="font-weight:bold">MAR</span></th>
                <th align="center" ><span style="font-weight:bold">ABR</span></th>
                <th align="center" ><span style="font-weight:bold">MAY</span></th>
                <th align="center" ><span style="font-weight:bold">JUN</span></th>
                <th align="center" ><span style="font-weight:bold">JUL</span></th>
                <th align="center" ><span style="font-weight:bold">AGO</span></th>
                <th align="center" ><span style="font-weight:bold">SEP</span></th>
                <th align="center" ><span style="font-weight:bold">OCT</span></th>
                <th align="center" ><span style="font-weight:bold">NOV</span></th>
                <th align="center" ><span style="font-weight:bold">DIC</span></th>
              </tr>`
          if (projects) {
            const m1 = moment(plan.period.start).month(0).date(1).startOf('day')
            const m2 = moment(plan.period.start).month(1).date(1).startOf('day')
            const m3 = moment(plan.period.start).month(2).date(1).startOf('day')
            const m4 = moment(plan.period.start).month(3).date(1).startOf('day')
            const m5 = moment(plan.period.start).month(4).date(1).startOf('day')
            const m6 = moment(plan.period.start).month(5).date(1).startOf('day')
            const m7 = moment(plan.period.start).month(6).date(1).startOf('day')
            const m8 = moment(plan.period.start).month(7).date(1).startOf('day')
            const m9 = moment(plan.period.start).month(8).date(1).startOf('day')
            const m10 = moment(plan.period.start).month(9).date(1).startOf('day')
            const m11 = moment(plan.period.start).month(10).date(1).startOf('day')
            const m12 = moment(plan.period.start).month(11).date(1).startOf('day')
            for (const t in projects) {
              const doc = projects[t]
              for (const p in doc.projects) {
                const project = doc.projects[p]
                let start, end
                if (project.planPeriod) {
                  start = moment(project.planPeriod[0]).date(1).startOf('day')
                  end = moment(project.planPeriod[1]).date(31).endOf('day')
                } else if (project.startEnd) {
                  start = moment(project.startEnd.split(' / ')[0]).date(1).startOf('day')
                  end = moment(project.startEnd.split(' / ')[1]).date(31).endOf('day')
                }

                seccion11 += `<tr>
      
    <td >${project.name}</td>
    <td bgcolor="${start && end ? (start._d <= m1._d && m1._d <= end._d ? '#72D122' : '') : ''}"></td>
    <td bgcolor="${start && end ? (start._d <= m2._d && m2._d <= end._d ? '#72D122' : '') : ''}"></td>
    <td bgcolor="${start && end ? (start._d <= m3._d && m3._d <= end._d ? '#72D122' : '') : ''}"></td>
    <td bgcolor="${start && end ? (start._d <= m4._d && m4._d <= end._d ? '#72D122' : '') : ''}"></td>
    <td bgcolor="${start && end ? (start._d <= m5._d && m5._d <= end._d ? '#72D122' : '') : ''}"></td>
    <td bgcolor="${start && end ? (start._d <= m6._d && m6._d <= end._d ? '#72D122' : '') : ''}"></td>
    <td bgcolor="${start && end ? (start._d <= m7._d && m7._d <= end._d ? '#72D122' : '') : ''}"></td>
    <td bgcolor="${start && end ? (start._d <= m8._d && m8._d <= end._d ? '#72D122' : '') : ''}"></td>
    <td bgcolor="${start && end ? (start._d <= m9._d && m9._d <= end._d ? '#72D122' : '') : ''}"></td>
    <td bgcolor="${start && end ? (start._d <= m10._d && m10._d <= end._d ? '#72D122' : '') : ''}"></td>
    <td bgcolor="${start && end ? (start._d <= m11._d && m11._d <= end._d ? '#72D122' : '') : ''}"></td>
    <td bgcolor="${start && end ? (start._d <= m12._d && m12._d <= end._d ? '#72D122' : '') : ''}"></td>
    </tr>`
              }
            }
          }
          seccion11 += '</table>'
          html = html.replace(new RegExp('{{#auditoriasRealizadas}}', 'g'), seccion11)

          let seccion12 = `<table class="gpaxTable"  border="1"  cellspacing="0" cellpadding="5" style="width: 804px">
      <colgroup>
      <col style="width: 201px">
      <col style="width: 201px">
      <col style="width: 201px">
      <col style="width: 201px">
      </colgroup>
      <tr>
      <th align="center" ><span style="font-weight:bold">Proyecto</span></th>
      <th align="center" ><span style="font-weight:bold">Objetivo</span></th>
      <th align="center" ><span style="font-weight:bold">Alcance</span></th>
      <th align="center" ><span style="font-weight:bold">Objetivo Estratégico</span></th>
      </tr>`
          if (projects) {
            for (const t in projects) {
              const doc = projects[t]
              for (const p in doc.projects) {
                const project = doc.projects[p]
                let objective
                if (plan.goals && plan.goals.length) {
                  plan.goals.forEach(g => {
                    g.projects.forEach(x => {
                      if (x.toString() === project._id.toString()) {
                        objective = g.objective
                      }
                    })
                  })
                  let fathersNames = []
                  let childsNames = []
                  let names = []
                  if (objective && strategy && strategy.objectives && strategy.objectives.length) {
                    const o = strategy.objectives.findIndex((x) => {
                      return x.id.toString() === objective.toString()
                    })
                    if (o !== -1) {
                      objective = strategy.objectives[o]
                      if (objective.parent && objective.parent !== '0' && objective.parent !== '' && objective.parent !== 0) {
                        fathersNames = fathersObjective(objective, fathersNames, strategy)
                      }
                      childsNames = childsObjective(objective, childsNames, strategy)
                      names = fathersNames.reverse().concat(childsNames)
                    }
                  }
                  let alcance = ''
                  let objetivo = ''
                  if (project.description && project.description.indexOf('id="objetivo"') !== -1) {
                    const root = parseHtml.parse(project.description)
                    objetivo = root.querySelectorAll('#objetivos')[0].innerHTML + '<br>'
                  }
                  if (project.description && project.description.indexOf('id="alcance"') !== -1) {
                    const root = parseHtml.parse(project.description)
                    alcance = root.querySelectorAll('#alcance')[0].innerHTML + '<br>'
                  }
                  seccion12 += `<tr>
        <td VALIGN="TOP" >${project.name}</td>
        <td VALIGN="TOP" >${objetivo}</td>
        <td VALIGN="TOP" >${alcance}</td>
        <td >${names.join('</br>')}</td>
        </tr>`
                }
              }
            }
            seccion12 += '</table>'
            html = html.replace(new RegExp('{{#objetivoAlcance}}', 'g'), seccion12)

            let seccion13 = `<table class="gpaxTable"  border="1"  cellspacing="0" cellpadding="5" style="width: 516px">
    <colgroup>
    <col style="width: 401px">
    <col style="width: 115px">
    </colgroup>
    <tr>
    <th align="center"  colspan="2"><span style="font-weight:bold">Universos Auditables</span></th>
    </tr>
    <tr>
    <td align="center" ><span style="font-weight:bold">Nombre</span></td>
    <td align="center" ><span style="font-weight:700">Tipo</span></td>
    </tr>`
            var auditables = await new Promise(resolve => {
              mongo.find('auditable', {}, {}, (err, auditables) => {
                if (!err) {
                  resolve(auditables)
                } else {
                  resolve(false)
                }
              })
            })
            if (auditables) {
              for (const a in auditables) {
                const auditable = auditables[a]
                const types = {
                  byRisk: 'Por riesgo',
                  mandatory: 'Obligatorio',
                  recurrent: 'Recurrente'
                }
                seccion13 += `<tr>
       <td >${auditable.name}</td>
       <td >${types[auditable.type]}</td>
       </tr>`
              }
            }
            seccion13 += '</table></br>'

            seccion13 += 'INSERTE AQUI IMAGEN EVALUACIÓN DE RIESGOS POR FACTORES</br></br></br>'

            seccion13 += `<table class="gpaxTable"  border="1"  cellspacing="0" cellpadding="5" style="width: 563px">
    <colgroup>
    <col style="width: 401px">
    <col style="width: 81px">
    <col style="width: 81px">
    </colgroup>
    <tr>
    <th align="center"  colspan="3"><span style="font-weight:bold">Procesos</span></th>
    </tr>
    <tr>
    <td align="center" ><span style="font-weight:bold">Nombre</span></td>
    <td align="center" ><span style="font-weight:700">RI</span></td>
    <td align="center" ><span style="font-weight:bold">RR</span></td>
    </tr>`
            var processes = await new Promise(resolve => {
              mongo.find('process', {}, {}, (err, processes) => {
                if (!err) {
                  resolve(processes)
                } else {
                  resolve(false)
                }
              })
            })
            if (processes) {
              for (const p in processes) {
                const process = processes[p]
                seccion13 += `<tr>
      <td >${process.name}</td>
      <td >${process.RI || ''}</td>
      <td >${process.RR || ''}</td>
      </tr>`
              }
            }
            seccion13 += '</table></br>'

            seccion13 += `<table class="gpaxTable"  border="1"  cellspacing="0" cellpadding="5" style="width: 563px">
    <colgroup>
    <col style="width: 401px">
    <col style="width: 81px">
    <col style="width: 81px">
    </colgroup>
    <tr>
    <th align="center"  colspan="3"><span style="font-weight:bold">Proyectos</span></th>
    </tr>
    <tr>
    <td align="center" ><span style="font-weight:bold">Nombre</span></td>
    <td align="center" ><span style="font-weight:700">Inicio</span></td>
    <td align="center" ><span style="font-weight:bold">Fin</span></td>
    </tr>`

            if (projects) {
              for (const t in projects) {
                const doc = projects[t]
                for (const p in doc.projects) {
                  const project = doc.projects[p]
                  seccion13 += `<tr>
      <td >${project.name}</td>
      <td >${(project.planPeriod ? (project.planPeriod.start ? moment(project.planPeriod.start).format('YYYY-MM-DD') : '') : '')}</td>
      <td >${(project.planPeriod ? (project.planPeriod.start ? moment(project.planPeriod.start).format('YYYY-MM-DD') : '') : '')}</td>
      </tr>`
                }
              }
            }
            seccion13 += '</table></br>'
            html = html.replace(new RegExp('{{#matriz}}', 'g'), seccion13)
          }
        }
      }
    }
    html = html.replace(new RegExp('<p data-f-id="pbf" style="text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;">Powered by <a href="https://www.froala.com/wysiwyg-editor?pb=1" title="Froala Editor">Froala Editor</a></p>', 'g'), '')
    return html
  }
  function numProjects (obj, num, strategy, plan) {
    if (plan.goals && plan.goals.length) {
      plan.goals.forEach(x => {
        if (x.objective.toString() === obj.id.toString()) {
          if (x.projects && x.projects.length) {
            num = num + x.projects.length
          }
        }
      })
    }
    for (const a in strategy.objectives) {
      if (strategy.objectives[a].parent && strategy.objectives[a].parent.toString() === obj.id.toString()) {
        numProjects(strategy.objectives[a], num, strategy, plan)
      }
    }
    return num
  }
  function childsObjective (obj, names, strategy) {
    names.push(obj.name)
    for (const a in strategy.objectives) {
      if (strategy.objectives[a].parent && strategy.objectives[a].parent.toString() === obj.id.toString()) {
        childsObjective(strategy.objectives[a], names, strategy)
      }
    }
    return names
  }
  function fathersObjective (obj, names, strategy) {
    names.push(obj.name)
    for (const a in strategy.objectives) {
      if (strategy.objectives[a].id && obj.parent && strategy.objectives[a].id.toString() === obj.parent.toString()) {
        fathersObjective(strategy.objectives[a], names, strategy)
      }
    }
    return names
  }
  this.fields = async function (mongo, project, html) {
    var i = 0
    var ids = []
    var clases = []
    var keys = { project: mongo.toId(project), content: { $in: [] } }
    var fields = {}
    while (html.indexOf('{{', i) !== -1 && html.substring(html.indexOf('{{', i), html.indexOf('{{', i) + 1) === '{') {
      i = html.indexOf('{{', i)
      const f = html.indexOf('}}', i)
      const word = html.substring(i + 2, f)
      if (word.charAt(0) === '#') {
        keys.content.$in.push(new RegExp('id="' + word.substring(1) + '"'))
        ids.push(word)
      }
      if (word.charAt(0) === '.') {
        keys.content.$in.push(new RegExp('' + word.substring(1) + '"'))
        clases.push(word)
      }
      i = f + 2
    }
    var docs = await new Promise(resolve => {
      mongo.find('document', keys, { _id: 1, name: 1, content: 1 }, (err, docs) => {
        if (!err) {
          resolve(docs)
        } else {
          resolve(false)
        }
      })
    })
    var notes = await new Promise(resolve => {
      mongo.find('note', keys, { _id: 1, name: 1, content: 1 }, (err, notes) => {
        if (!err) {
          resolve(notes)
        } else {
          resolve(false)
        }
      })
    })
    if (docs && notes) {
      docs = docs.concat(notes)
      if (docs.length) {
        for (const d in docs) {
          const doc = docs[d]
          ids.forEach((v, i) => {
            if (doc.content.indexOf('id="' + v.substring(1) + '"') !== -1) {
              const root = parseHtml.parse(doc.content)
              fields[v] = fields[v] ? fields[v] + root.querySelectorAll(v)[0].innerHTML + (ids.length - 1 !== i ? '' : '<br>') : root.querySelectorAll(v)[0].innerHTML + (ids.length - 1 !== i ? '' : '<br>')
            }
          })
          clases.forEach((c, i) => {
            if (doc.content.indexOf('' + c.substring(1) + '"') !== -1) {
              const root = parseHtml.parse(doc.content)
              fields[c] = fields[c] ? fields[c] + root.querySelectorAll(c)[0].innerHTML + (clases.length - 1 !== i ? '' : '<br>') : root.querySelectorAll(c)[0].innerHTML + (clases.length - 1 !== i ? '' : '<br>')
            }
          })
        }
        i = 0
        while (html.indexOf('{{', i) !== -1 && html.substring(html.indexOf('{{', i), html.indexOf('{{', i) + 1) === '{') {
          i = html.indexOf('{{', i)
          const f = html.indexOf('}}', i)
          const word = html.substring(i + 2, f)
          html = html.replace(new RegExp('{{' + word + '}}', 'g'), fields[word])
          i = f + 2
        }
      }
    }
    return html
  }
  this.projects = async function (mongo, planId, data) {
    var settings = await new Promise(resolve => {
      mongo.findOne('settings', { _id: 'settings' }, (err, sett) => {
        if (err) {
          resolve(false)
        } else {
          resolve(sett)
        }
      })
    })
    const period = data.period
    const ids = []
    var attachedSection = ''
    var indice = `<ol style="list-style-type: upper-roman;">
      <li><b>INTRODUCCI&Oacute;N</b></li>
      <li><strong>GRADO DE CUMPLIMIENTO DEL PLAN ANUAL DE TRABAJO, CRONOGRAMA DE TRABAJOS PREVISTOS Y REALIZADOS</strong></li>
      <li><b>RESUMEN DELOS INFORMES DE DIRECCI&Oacute;N DE AUDITORIA INTERNA EMITIDOS EN EL PERIODO</b></li>`
    data.units = data.units.split(',')
    for (const u in data.units) {
      ids.push(mongo.toId(data.units[u]))
    }
    data.attachedTag = data.attachedTag.split(',')
    for (const a in data.attachedTag) {
      data.attachedTag[a] = mongo.toId(data.attachedTag[a])
    }
    data.noteTag = data.noteTag.split(',')
    for (const a in data.noteTag) {
      data.noteTag[a] = mongo.toId(data.noteTag[a])
    }
    var html = '<p style="text-align: center;"><strong>' + settings.title + '</strong></p>' +
    `<p style="text-align: center;"><strong>DIRECCI&Oacute;N DE AUDITORIA INTERNA</strong></p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;"><strong>INFORME DE EVALUACI&Oacute;N DEL PLAN DE TRABAJO DE AUDITORIA INTERNA</strong></p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
     <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: left;"><strong>TABLA DE CONTENIDO</strong></p>
    {{campoIndice}}
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p style="text-align: center;">
      <br>
    </p>
    <p><details  ><summary><strong>Introducción</strong></summary></p>

    <p>El documento contiene el resultado de evaluar el grado de cumplimiento del plan anual de trabajo de Auditor&iacute;a Interna, correspondiente al ; el cual es conforme a los requerimientos definidos en el art&iacute;culo 18 de las Normas T&eacute;cnicas de Auditor&iacute;a Interna para los Integrantes del Sistema Financiero (NRP-15), emitido por el Banco Central de Reserva de El Salvador por medio del Comit&eacute; de Normas, con vigencia a partir del tres de abril de dos mil diecisiete.&nbsp;</p>

    <p><strong>A.Contenido del Informe: </strong></p>

    <p>&nbsp; &nbsp;1.El grado de cumplimiento del plan anual de trabajo en los meses de XXXX, XXXX y XXXX.&nbsp;</p>

    <p>&nbsp; &nbsp;2.El cronograma de las actividades previstas y las realizadas en el XXXX trimestre.&nbsp;</p>

    <p>&nbsp; &nbsp;3.El resumen de los informes emitidos en el cuarto trimestre, que incluye entre otros:&nbsp;</p>

    <p>&nbsp; &nbsp; &nbsp; a.Referencia de informe.&nbsp;</p>

    <p>&nbsp; &nbsp; &nbsp; b.Nombre del informe.&nbsp;</p>

    <p>&nbsp; &nbsp; &nbsp; c.Fecha de emisi&oacute;n.&nbsp;</p>

    <p>&nbsp; &nbsp; &nbsp; d.Distribuci&oacute;n de informe.&nbsp;</p>

    <p>&nbsp; &nbsp; &nbsp; e.El Objetivo y alcance.&nbsp;</p>

    <p>&nbsp; &nbsp; &nbsp; f.Principales hallazgos, incluye: condici&oacute;n, causa, efecto y medidas recomendadas.&nbsp;</p>

    <p>&nbsp; &nbsp;4.Hallazgos de Auditor&iacute;a Interna pendientes de resoluci&oacute;n y en proceso, incluye: condici&oacute;n, fecha del hallazgo, acciones implementadas o proyectadas, responsable y fecha prevista para soluci&oacute;n.&nbsp;</p>

    <p>&nbsp; &nbsp;5.Observaciones de los informes emitidos por la SSF.&nbsp;</p>

    <p>&nbsp; &nbsp;6.Observaciones de los informes emitidos por los Auditores Externos.&nbsp;</p>

    <p>&nbsp; &nbsp;7.Capacitaci&oacute;n al personal de Auditor&iacute;a Interna, en el XXXXX trimestre 20XX.&nbsp;</p>

    <p><strong>B.Evaluaciones desarrolladas conforme lo define:</strong>&nbsp;</p>

    <p>&nbsp; &nbsp;1.El Estatuto de Auditor&iacute;a Interna, aprobado por la Junta Directiva del ` + settings.title + `, en sesi&oacute;n No. 31/2017 de fecha 01 de agosto de 2017.&nbsp;</p>

    <p>&nbsp; &nbsp;2.El Plan de Trabajo de Auditor&iacute;a Interna a&ntilde;o 2018, aprobado por el Comit&eacute; de Auditor&iacute;a y Junta Directiva, seg&uacute;n consta en actas 23/2017 y 50/2017, de fechas 12 y 13 de diciembre de 2017, respectivamente.&nbsp;</p>

    <p><strong>C.Objetivos del Informe </strong></p>

    <p>&nbsp; &nbsp;I.Informar al Comit&eacute; de Auditor&iacute;a y Junta Directiva del ` + settings.title + `, el resultado de evaluar el grado de cumplimiento del plan de trabajo de Auditor&iacute;a Interna correspondiente al XXXX trimestre de 20XX.&nbsp;</p>

    <p>&nbsp; &nbsp;II.Cumplir con lo definido en el art&iacute;culo 18 de las Normas T&eacute;cnicas de Auditor&iacute;a Interna para los Integrantes del Sistema Financiero (NRP-15).</p></details><br>`

    html += '<details  ><summary><strong><span >El grado de cumplimiento del plan anual de trabajo, cronograma de trabajos previstos y realizados</span></strong></summary><br>'
    html += '<span>Conforme a la evaluación practicada al grado de cumplimiento del plan anual de trabajo de Auditoría Interna del ' + settings.title + ' , correspondiente al XXXX trimestre de 20XX, corresponde el XX.X%</span>'
    html += '<table class="gpaxTable" style="width: 100%;"border="1" cellspacing="0" cellpadding="5">'
    html += '<thead>'
    html += '<tr>'
    html += '<th><span style="font-family:Calibri,sans-serif;color:#000000;background-color:transparent;font-weight:400;font-style:normal;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;">Auditoria Planificada</span>'
    html += '<br>'
    html += '</th>'
    html += '<th><span style="font-family:Calibri,sans-serif;color:#000000;background-color:transparent;font-weight:400;font-style:normal;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;">Estado</span>'
    html += '<br>'
    html += '</th>'
    html += '<th><span style="font-family:Calibri,sans-serif;color:#000000;background-color:transparent;font-weight:400;font-style:normal;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;">Progreso</span>'
    html += '<br>'
    html += '</th>'
    html += '<th><span style="font-family:Calibri,sans-serif;color:#000000;background-color:transparent;font-weight:400;font-style:normal;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;">Informe</span>'
    html += '<br>'
    html += '</th>'
    html += '<th><span style="font-family:Calibri,sans-serif;color:#000000;background-color:transparent;font-weight:400;font-style:normal;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;">Comentario</span>'
    html += '<br>'
    html += '</th>'
    html += '</tr>'
    html += '</thead>'
    html += '<tbody>'
    var users = await new Promise(resolve => {
      mongo.toHash('user', {}, { _id: 1, name: 1 }, (err, users) => {
        if (!err) {
          resolve(users)
        } else {
          resolve(false)
        }
      })
    })
    var units = await new Promise(resolve => {
      mongo.toHash('unit', {}, { _id: 1, name: 1 }, (err, units) => {
        if (!err) {
          resolve(units)
        } else {
          resolve(false)
        }
      })
    })
    var plan = await new Promise(resolve => {
      mongo.findId('plan', planId, {}, (err, plan) => {
        if (!err) {
          resolve(plan)
        } else {
          resolve(false)
        }
      })
    })
    if (plan) {
      if (period.start) {
        var start = moment(period.start)
        // let from = moment(date)
        start.set('hour', 0)
        start.set('minute', 0)
        start.set('second', 0)
        start.set('millisecond', 0)
      }
      if (period.end) {
        var end = moment(period.end)
        end.set('hour', 23)
        end.set('minute', 59)
        end.set('second', 59)
        end.set('millisecond', 999)
      }
      if (data.cutoffDate) {
        var cutoffDate = moment(data.cutoffDate)
        cutoffDate.set('hour', 23)
        cutoffDate.set('minute', 59)
        cutoffDate.set('second', 59)
        cutoffDate.set('millisecond', 999)
      }
      var keys = {
        $and: [
          {
            $or: [
              {
                $and: [
                  { 'planPeriod.0': { $lte: new Date(end.format('YYYY-MM-DD HH:mm')) } },
                  { 'planPeriod.1': { $gte: new Date(start.format('YYYY-MM-DD HH:mm')) } },
                  { status: { $nin: ['draft', 'archived'] } }
                ]
              },
              {
                $and: [
                  { 'realPeriod.1': { $lte: new Date(end.format('YYYY-MM-DD HH:mm')), $gte: new Date(start.format('YYYY-MM-DD HH:mm')) } },
                  { status: { $in: ['completed', 'archived'] } }
                ]
              }
            ]
          },
          { plan: plan._id }
        ]
      }
      var pipeline = []
      pipeline.push({ $match: keys })
      pipeline.push({ $lookup: { from: 'plan', localField: 'plan', foreignField: '_id', as: 'plan' } })
      pipeline.push({
        $lookup: {
          from: 'project',
          let: { find: '$_id' },
          pipeline: [
            { $match: { $expr: { $and: [{ $eq: ['$_id', '$$find'] }] } } },
            { $unwind: { path: '$content.data', preserveNullAndEmptyArrays: true } },
            { $match: { 'content.data.type': 'task', 'content.data.status': { $in: ['done', 'reviewed', 'completed'] } } },
            { $group: { _id: null, durationReal: { $sum: { $toDouble: '$content.data.duration' } } } },
            { $project: { tiempo: '$durationReal' } }
          ],
          as: 'completedTime'
        }
      })
      pipeline.push({
        $lookup: {
          from: 'project',
          let: { find: '$_id' },
          pipeline: [
            { $match: { $expr: { $and: [{ $eq: ['$_id', '$$find'] }] } } },
            { $unwind: { path: '$content.data', preserveNullAndEmptyArrays: true } },
            { $match: { 'content.data.type': 'task' } },
            { $group: { _id: null, durationReal: { $sum: { $toDouble: '$content.data.duration' } } } },
            { $project: { tiempo: '$durationReal' } }
          ],
          as: 'totalTime'
        }
      })
      pipeline.push({
        $lookup: {
          from: 'project',
          let: { find: '$_id' },
          pipeline: [
            {$match: {$expr: {$and: [{ $eq: ['$_id', '$$find'] }]}}},
            { $unwind: { path: '$content.data', preserveNullAndEmptyArrays: true } },
            { $match: { 'content.data.type': 'task', 'content.data.status': { $in: ['suspended'] } } },
            { $group: { _id: null, durationReal: { $sum: { $toDouble: '$content.data.duration' } } } },
            {$project: {tiempo: '$durationReal'}}
          ],
          as: 'suspendedTime'
        }
      })
      pipeline.push({
        $lookup: {
          from: 'note',
          let: { find: '$_id' },
          pipeline: [
            {$match: {$expr: {$and: [{ $eq: ['$project', '$$find'] }]}}},
            {$project: {sequence: 1, dates: 1}}
          ],
          as: 'note'
        }
      })
      pipeline.push({
        $project: {
          id: '$_id',
          name: 1,
          status: 1,
          suspendedTime: '$suspendedTime',
          totalTime: '$totalTime',
          completedTime: '$completedTime',
          duration: 1,
          note: 1
        }
      })
      pipeline.push({ $sort: { name: 1 } })
      var projects = await new Promise(resolve => {
        mongo.aggregate('project', pipeline, {}, (err, projects) => {
          if (!err) {
            resolve(projects)
          } else {
            resolve(false)
          }
        })
      })
      if (projects) {
        for (const p in projects) {
          const project = projects[p]
          if ((data.onlyPeriod === 1) && (project.note && project.note.length)) {
            let news = []
            for (let i in project.note) {
              let note = project.note[i]
              if (note.dates && note.dates[0] && note.dates[0].type === 'issue') {
                if ((note.dates[0].value >= new Date(start.format('YYYY-MM-DD HH:mm'))) && (note.dates[0].value <= new Date(end.format('YYYY-MM-DD HH:mm')))) {
                  news.push(note)
                }
              }
            }
            project.note = news
          }
          project.duration = project.duration ? project.duration : project.totalTime[0] ? project.totalTime[0].tiempo : 0
          project.suspendedTime = project.suspendedTime[0] ? project.suspendedTime[0].tiempo : 0
          project.completedTime = project.completedTime[0] ? project.completedTime[0].tiempo : 0
          project.duration = project.duration - project.suspendedTime
          project.progress = project.completedTime / parseFloat(project.duration)
          project.progress = project.progress ? ((project.progress * 100).toFixed(2) + '%') : 0
          html += '<tr>'
          html += '<td style="width: 33.3333%;">' + project.name + '</td>'
          html += '<td style="width: 10%;">' + project.status + '</td>'
          html += '<td style="width: 10%;">' + project.progress + '</td>'
          html += '<td style="width: 14%;">' + (project.note.length ? project.note[0].sequence.text : '') + '</td>'
          html += '<td style="width: 33.3333%;">...</td>'
          html += '</tr>'
        }
      }
      html += '</tbody>'
      html += '</table></details>'
      html += '<br><details  ><summary><strong><span >Resumen de los informes de ' + units[data.unit].name + ' emitidos en el periodo</span></strong></summary><br>'
      attachedSection += '<br><details  ><summary><strong><span >Resumen de los informes de ' + units[data.unit].name + ' emitidos en el periodo</span></strong></summary><br>'
      var unitAndChilds = [mongo.toId(data.unit)].concat(this.childUnits(data.unit, units))
      var notes = await new Promise(resolve => {
        mongo.aggregate('note', [
          {
            $match: {
              $and: [
                {
                  $or: [
                    { 'dates.0.value': { $lte: new Date(end.format('YYYY-MM-DD HH:mm')), $gte: new Date(start.format('YYYY-MM-DD HH:mm')) } }
                    // { 'dates.0.value': { $lte: new Date(start.format('YYYY-MM-DD HH:mm')) }, status: 'processing' }
                  ]
                },
                { status: { $ne: 'draft' } },
                { actors: { $elemMatch: { unit: { $in: unitAndChilds }, role: 'from' } } },
                { tags: { $nin: data.noteTag } }
              ]
            }
          },
          { $lookup: { from: 'attached', localField: '_id', foreignField: 'reference', as: 'attacheds' } },
          { $project: { _id: 1, status: 1, name: 1, content: 1, sequence: 1, dates: 1, attacheds: 1 } },
          { $sort: { 'sequence.text': 1 } }
        ], {}, (err, notes) => {
          if (!err) {
            resolve(notes)
          } else {
            resolve(false)
          }
        })
      })
      if (notes && notes.length) {
        for (const n in notes) {
          const note = notes[n]
          html += '<br><strong>' + note.sequence.text + '</strong>' + ' - ' + note.name + '<br>'
          attachedSection += '<br><details  ><summary>' + note.name + '</summary><br>'
          attachedSection += note.sequence.text + '<br>'
          attachedSection += moment(note.dates[0].value).format('YYYY-MM-DD') + '<br>'
          if (note.content.indexOf('id="objetivos"') !== -1) {
            attachedSection += '<span style=""><strong>Objetivos</strong></span><br>'
            const root = parseHtml.parse(note.content)
            attachedSection += root.querySelectorAll('#objetivos')[0].innerHTML + '<br>'
            if (note.content.indexOf('id="alcance"') !== -1) {
              attachedSection += '<span style=""><strong>Alcance</strong></span><br>'
              const root = parseHtml.parse(note.content)
              attachedSection += root.querySelectorAll('#alcance')[0].innerHTML + '<br>'
            }
          } else {
            attachedSection += note.content + '<br>'
          }

          var attacheds = note.attacheds
          if (attacheds && attacheds.length) {
            attachedSection += '<span style=""><strong>Hallazgos</strong></span><br>'
            for (const a in attacheds) {
              const attached = attacheds[a]
              attachedSection += '<br><details  ><summary><strong>Asunto: </strong>' + attached.name + '</summary><br>'
              if (attached.content.indexOf('id="condicion"') !== -1) {
                attachedSection += '<span style=""><strong>Condición</strong></span><br>'
                const root = parseHtml.parse(attached.content)
                attachedSection += root.querySelectorAll('#condicion')[0].innerHTML + '<br>'
                if (attached.content.indexOf('id="causas"') !== -1) {
                  attachedSection += '<span style=""><strong>Causas</strong></span><br>'
                  const root = parseHtml.parse(attached.content)
                  attachedSection += root.querySelectorAll('#causas')[0].innerHTML + '<br>'
                }
                if (attached.content.indexOf('id="efectos"') !== -1) {
                  attachedSection += '<span style=""><strong>Efectos</strong></span><br>'
                  const root = parseHtml.parse(attached.content)
                  attachedSection += root.querySelectorAll('#efectos')[0].innerHTML + '<br>'
                }
                if (attached.content.indexOf('id="recomendacion"') !== -1) {
                  attachedSection += '<span style=""><strong>Recomendación</strong></span><br>'
                  const root = parseHtml.parse(attached.content)
                  attachedSection += root.querySelectorAll('#recomendacion')[0].innerHTML + '<br>'
                }
              } else {
                attachedSection += attached.content + '<br>'
              }
              attachedSection += '</details>'
            }
          }
          attachedSection += '</details>'
        }
      }
      html += '</details><br><details  ><summary><strong><span >Hallazgos pendientes y en proceso emitidas por ' + units[data.unit].name + '</span></strong></summary><br>'
      attachedSection += '</details><br><details  ><summary><strong><span >Hallazgos pendientes y en proceso emitidas por ' + units[data.unit].name + '</span></strong></summary><br>'
      var attachedsAI = await new Promise(resolve => {
        mongo.aggregate('attached', [{
          $match: {
            $and: [
              { 'dates.0.value': { $lte: new Date(cutoffDate.format('YYYY-MM-DD HH:mm')) } },
              { actors: { $elemMatch: { role: 'from', unit: { $in: unitAndChilds } } } },
              { status: { $nin: ['draft', 'prepared', 'completed'] } },
              { attachedTag: { $nin: data.attachedTag } }
            ]
          }
        },
        {
          $lookup: {
            from: 'commitment',
            let: { id: '$_id' },
            pipeline: [
              {$match: {$expr: {$and: [{ $eq: ['$reference', '$$id'] }]}}}
            ],
            as: 'commitments'
          }
        },
        { $unwind: { path: '$commitments', preserveNullAndEmptyArrays: true } },
        {
          $lookup: {
            from: 'evidence',
            let: { id2: '$commitments._id' },
            pipeline: [
              { $match: { $and: [{ $expr: { $eq: ['$reference', '$$id2'] } }, { status: { $ne: 'draft' } }] } },
              { $project: { name: 1, content: 1 } }
            ],
            as: 'evidences'
          }
        },
        { $lookup: { from: 'note', localField: 'reference', foreignField: '_id', as: 'note' } },
        { $project: { _id: 1, status: 1, name: 1, content: 1, dates: 1, responsible: {$filter: {input: '$actors',as: 'actor',cond: {$eq: ['$$actor.role','responsible']}}}, note: 1, evidences: 1 } },
        { $sort: { 'sequence.text': 1 } }], {}, (err, attacheds) => {
          if (!err) {
            resolve(attacheds)
          } else {
            resolve(false)
          }
        })
      })
      if (attachedsAI && attachedsAI.length) {
        for (const a in attachedsAI) {
          const attached = attachedsAI[a]
          html += '<br><strong>Asunto: </strong>' + attached.name + (attached.note[0] && attached.note[0].sequence ? ' - ' + attached.note[0].sequence.text : '') + '<br>'
          attachedSection += '<br><details  ><summary><strong>Asunto: </strong>' + attached.name + (attached.note[0] && attached.note[0].sequence ? ' - ' + attached.note[0].sequence.text : '') + '</summary><br>'
          attachedSection += '<strong>Informe: </strong>' + attached.note[0].name + '<br>'
          if (attached.dates && attached.dates[0]) {
            attachedSection += `<strong>Fecha: </strong>${moment(attached.dates[0].value).format('YYYY-MM-DD')}</br>`
          }
          if (attached.responsible && attached.responsible[0]) {
            attachedSection += '<strong>Responsable: </strong>' + (users[attached.responsible[0].user] ? users[attached.responsible[0].user].name : '') + '/' + (units[attached.responsible[0].unit] ? units[attached.responsible[0].unit].name : '') + '<br>'
          }
          if (attached.evidences && attached.evidences.length) {
            const evidence = attached.evidences[attached.evidences.length - 1]
            attachedSection += `<strong>Último Seguimiento: </strong>${evidence.name}</br>`
            attachedSection += evidence.content
          }
          attachedSection += '</details>'
        }
      }
      for (const u in ids) {
        const unit = ids[u]
        const nameIndice = `Observaciones de los informes emitidos por ${units[unit.toString()].name}`
        indice += `<li><b>${nameIndice.toUpperCase()}</b></li>`
        html += '</details><br><details  ><summary><strong><span >Observaciones de los informes emitidos por ' + units[unit.toString()].name + '</span></strong></summary><br>'
        attachedSection += '</details><br><details  ><summary><strong><span >Observaciones de los informes emitidos por ' + units[unit.toString()].name + '</span></strong></summary><br>'
        var attacheds2 = await new Promise(resolve => {
          mongo.aggregate('attached', [{
            $match: {
              $and: [
                { 'dates.0.value': { $lte: new Date(cutoffDate.format('YYYY-MM-DD HH:mm')) } },
                { actors: { $elemMatch: { role: 'from', unit: unit } } },
                { status: { $nin: ['draft', 'prepared', 'completed'] } }
              ]
            }
          },
          {
            $lookup: {
              from: 'commitment',
              let: { id: '$_id' },
              pipeline: [{ $match: { $expr: { $eq: ['$reference', '$$id'] } } }],
              as: 'commitments'
            }
          },
          { $unwind: { path: '$commitments', preserveNullAndEmptyArrays: true } },
          {
            $lookup: {
              from: 'evidence',
              let: { id2: '$commitments._id' },
              pipeline: [
                { $match: { $and: [{ $expr: { $eq: ['$reference', '$$id2'] } }, { status: { $ne: 'draft' } }] } },
                { $project: { name: 1, content: 1 } }
              ],
              as: 'evidences'
            }
          },
          { $lookup: { from: 'note', localField: 'reference', foreignField: '_id', as: 'note' } },
          { $project: { _id: 1, status: 1, name: 1, content: 1, dates: 1, responsible: {$filter: {input: '$actors',as: 'actor',cond: {$eq: ['$$actor.role','responsible']}}}, note: 1, evidences: 1 } }], {}, (err, attacheds) => {
            if (!err) {
              resolve(attacheds)
            } else {
              resolve(false)
            }
          })
        })
        if (attacheds2 && attacheds2.length) {
          for (const a in attacheds2) {
            const attached = attacheds2[a]
            html += '<br><strong>Asunto: </strong>' + attached.name + (attached.note[0] && attached.note[0].sequence ? ' - ' + attached.note[0].sequence.text : '') + '<br>'
            attachedSection += '<br><details  ><summary><strong>Asunto: </strong>' + attached.name + (attached.note[0] && attached.note[0].sequence ? ' - ' + attached.note[0].sequence.text : '') + '</summary><br>'
            attachedSection += '<strong>Informe: </strong>' + attached.note[0].name + '<br>'
            if (attached.dates && attached.dates[0]) {
              attachedSection += `<strong>Fecha: </strong>${moment(attached.dates[0].value).format('YYYY-MM-DD')}</br>`
            }
            if (attached.responsible && attached.responsible[0]) {
              attachedSection += '<strong>Responsable: </strong>' + (users[attached.responsible[0].user] ? users[attached.responsible[0].user].name : '') + '/' + (units[attached.responsible[0].unit] ? units[attached.responsible[0].unit].name : '') + '<br>'
            }
            if (attached.content.indexOf('id="condicion"') !== -1) {
              attachedSection += '<span style=""><strong>Condición</strong></span><br>'
              const root = parseHtml.parse(attached.content)
              attachedSection += root.querySelectorAll('#condicion')[0].innerHTML + '<br>'
            } else {
              attachedSection += attached.content + '<br>'
            }
            if (attached.evidences && attached.evidences.length) {
              const evidence = attached.evidences[attached.evidences.length - 1]
              attachedSection += `<strong>Último Seguimiento: </strong>${evidence.name}</br>`
              attachedSection += evidence.content
            }
            attachedSection += '</details>'
          }
        }
      }
    }
    indice += '</ol>'
    html = html.replace('{{campoIndice}}', indice)
    html += '</details><br><details  ><summary><strong>Anexos</strong></summary><br>'
    html += attachedSection

    return '</details>' + html
  }

  this.attachedsOfUnit = async function (mongo, data) {
    var settings = await new Promise(resolve => {
      mongo.findOne('settings', { _id: 'settings' }, (err, sett) => {
        if (err) {
          resolve(false)
        } else {
          resolve(sett)
        }
      })
    })
    var html = `<table  style="width: 100%;"  >
                    <tbody>
                      <tr>
                        <td style="width: 9.2346%; vertical-align: middle;">
                          <div>${settings.photo ? (`<img src="/api/file.get?_id=${settings.photo.toString()}&type=jpg"  class="fr-fic fr-fil fr-dib"></div>`) : ''}
                        </td>
                        <td style="width: 8.3195%; text-align: right; vertical-align: middle;">
                        </td>
                      </tr>
                    </tbody>
                  </table>`
    data.attachedTag = data.attachedTag.split(',')
    for (const a in data.attachedTag) {
      data.attachedTag[a] = mongo.toId(data.attachedTag[a])
    }
    var users = await new Promise(resolve => {
      mongo.toHash('user', {}, { _id: 1, name: 1 }, (err, users) => {
        if (!err) {
          resolve(users)
        } else {
          resolve(false)
        }
      })
    })
    var units = await new Promise(resolve => {
      mongo.toHash('unit', {}, { _id: 1, name: 1 }, (err, units) => {
        if (!err) {
          resolve(units)
        } else {
          resolve(false)
        }
      })
    })
    if (data.cutoffDate) {
      var cutoffDate = moment(data.cutoffDate)
      cutoffDate.set('hour', 23)
      cutoffDate.set('minute', 59)
      cutoffDate.set('second', 59)
      cutoffDate.set('millisecond', 999)
    }
    html += '</details><br><details  ><summary><strong><span >Observaciones de los informes emitidos por ' + units[data.unit].name + '</span></strong></summary><br>'
    var attacheds2 = await new Promise(resolve => {
      mongo.aggregate('attached', [{
        $match: {
          $and: [
            { 'dates.0.value': { $lte: new Date(cutoffDate.format('YYYY-MM-DD HH:mm')) } },
            { actors: { $elemMatch: { role: 'from', unit: mongo.toId(data.unit) } } },
            { status: { $nin: ['draft', 'prepared', 'completed'] } }
          ]
        }
      },
      { $lookup: { from: 'note', localField: 'reference', foreignField: '_id', as: 'note' } },
      { $project: { _id: 1, status: 1, name: 1, content: 1, responsible: 1, note: 1 } }], {}, (err, attacheds) => {
        if (!err) {
          resolve(attacheds)
        } else {
          resolve(false)
        }
      })
    })
    if (attacheds2 && attacheds2.length) {
      for (const a in attacheds2) {
        const attached = attacheds2[a]
        html += '<br><details  ><summary><strong>Asunto: </strong>' + attached.name + (attached.note[0] && attached.note[0].sequence ? ' - ' + attached.note[0].sequence.text : '') + '</summary><br>'
        html += '<strong>Informe: </strong>' + attached.note[0].name + '<br>'
        if (attached.dates && attached.dates[0]) {
          html += moment(attached.dates[0].value).format('YYYY-MM-DD') + '<br>'
        }
        if (attached.responsible) {
          html += '<strong>Responsable: </strong>' + users[attached.responsible.split('&unit=')[0]].name + '/' + units[attached.responsible.split('&unit=')[1]].name + '<br>'
        }
        if (attached.content.indexOf('id="condicion"') !== -1) {
          html += '<span style=""><strong>Condición</strong></span><br>'
          const root = parseHtml.parse(attached.content)
          html += root.querySelectorAll('#condicion')[0].innerHTML + '<br>'
        } else {
          html += attached.content + '<br>'
        }
        html += '</details>'
      }
    }

    return '</details>' + html
  }
  this.notesForPeriod = async function (mongo, data) {
    var settings = await new Promise(resolve => {
      mongo.findOne('settings', { _id: 'settings' }, (err, sett) => {
        if (err) {
          resolve(false)
        } else {
          resolve(sett)
        }
      })
    })
    var html = `<table  style="width: 100%;"  >
                    <tbody>
                      <tr>
                        <td style="width: 9.2346%; vertical-align: middle;">
                          <div>${settings.photo ? (`<img src="/api/file.get?_id=${settings.photo.toString()}&type=jpg"  class="fr-fic fr-fil fr-dib"></div>`) : ''}
                        </td>
                        <td style="width: 8.3195%; text-align: right; vertical-align: middle;">
                        </td>
                      </tr>
                    </tbody>
                  </table>`
    const period = data.period
    data.noteTag = data.noteTag.split(',')
    for (const a in data.noteTag) {
      data.noteTag[a] = mongo.toId(data.noteTag[a])
    }
    var units = await new Promise(resolve => {
      mongo.toHash('unit', {}, { _id: 1, name: 1 }, (err, units) => {
        if (!err) {
          resolve(units)
        } else {
          resolve(false)
        }
      })
    })

    if (period.start) {
      var start = moment(period.start)
      // let from = moment(date)
      start.set('hour', 0)
      start.set('minute', 0)
      start.set('second', 0)
      start.set('millisecond', 0)
    }
    if (period.end) {
      var end = moment(period.end)
      end.set('hour', 23)
      end.set('minute', 59)
      end.set('second', 59)
      end.set('millisecond', 999)
    }
    html += '<br><details  ><summary><strong><span >Resumen de los informes de ' + units[data.unit].name + ' emitidos en el periodo</span></strong></summary><br>'
    var unitAndChilds = [mongo.toId(data.unit)].concat(this.childUnits(data.unit, units))
    var notes = await new Promise(resolve => {
      mongo.aggregate('note', [
        {
          $match: {
            $and: [
              {
                $or: [
                  { 'dates.0.value': { $lte: new Date(end.format('YYYY-MM-DD HH:mm')), $gte: new Date(start.format('YYYY-MM-DD HH:mm')) } }
                  // { 'dates.0.value': { $lte: new Date(start.format('YYYY-MM-DD HH:mm')) }, status: 'processing' }
                ]
              },
              { status: { $ne: 'draft' } },
              { actors: { $elemMatch: { unit: { $in: unitAndChilds }, role: 'from' } } },
              { tags: { $nin: data.noteTag } }
            ]
          }
        },
        { $lookup: { from: 'attached', localField: '_id', foreignField: 'reference', as: 'attacheds' } },
        { $project: { _id: 1, status: 1, name: 1, content: 1, sequence: 1, dates: 1, attacheds: 1 } },
        { $sort: { 'sequence.text': 1 } }
      ], {}, (err, notes) => {
        if (!err) {
          resolve(notes)
        } else {
          resolve(false)
        }
      })
    })
    if (notes && notes.length) {
      for (const n in notes) {
        const note = notes[n]
        html += '<br><details  ><summary>' + note.name + '</summary><br>'
        html += note.sequence.text + '<br>'
        html += moment(note.dates[0].value).format('YYYY-MM-DD') + '<br>'
        if (note.content.indexOf('id="objetivos"') !== -1) {
          html += '<span style=""><strong>Objetivos</strong></span><br>'
          const root = parseHtml.parse(note.content)
          html += root.querySelectorAll('#objetivos')[0].innerHTML + '<br>'
          if (note.content.indexOf('id="alcance"') !== -1) {
            html += '<span style=""><strong>Alcance</strong></span><br>'
            const root = parseHtml.parse(note.content)
            html += root.querySelectorAll('#alcance')[0].innerHTML + '<br>'
          }
        } else {
          html += note.content + '<br>'
        }

        var attacheds = note.attacheds
        if (attacheds && attacheds.length) {
          html += '<span style=""><strong>Hallazgos</strong></span><br>'
          for (const a in attacheds) {
            const attached = attacheds[a]
            html += '<br><details  ><summary><strong>Asunto: </strong>' + attached.name + '</summary><br>'
            if (attached.content.indexOf('id="condicion"') !== -1) {
              html += '<span style=""><strong>Condición</strong></span><br>'
              const root = parseHtml.parse(attached.content)
              html += root.querySelectorAll('#condicion')[0].innerHTML + '<br>'
              if (attached.content.indexOf('id="causas"') !== -1) {
                html += '<span style=""><strong>Causas</strong></span><br>'
                const root = parseHtml.parse(attached.content)
                html += root.querySelectorAll('#causas')[0].innerHTML + '<br>'
              }
              if (attached.content.indexOf('id="efectos"') !== -1) {
                html += '<span style=""><strong>Efectos</strong></span><br>'
                const root = parseHtml.parse(attached.content)
                html += root.querySelectorAll('#efectos')[0].innerHTML + '<br>'
              }
              if (attached.content.indexOf('id="recomendacion"') !== -1) {
                html += '<span style=""><strong>Recomendación</strong></span><br>'
                const root = parseHtml.parse(attached.content)
                html += root.querySelectorAll('#recomendacion')[0].innerHTML + '<br>'
              }
            } else {
              html += attached.content + '<br>'
            }
            html += '</details>'
          }
        }
        html += '</details>'
      }
    }
    return html
  }
  this.extension = async function (mongo) {
    var settings = await new Promise(resolve => {
      mongo.findOne('settings', { _id: 'settings' }, (err, sett) => {
        if (err) {
          resolve(false)
        } else {
          resolve(sett)
        }
      })
    })
    var html = `<table  style="width: 100%;"  >
                    <tbody>
                      <tr>
                        <td style="width: 9.2346%; vertical-align: middle;">
                          <div>${settings.photo ? (`<img src="/api/file.get?_id=${settings.photo.toString()}&type=jpg"  class="fr-fic fr-fil fr-dib"></div>`) : ''}
                        </td>
                        <td style="width: 8.3195%; text-align: right; vertical-align: middle;">
                          <strong>ANEXO No. #</strong>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <p style="text-align: center;"><strong>OBSERVACIONES DE AUDITORÍA INTERNA CON PRÓRROGA AUTORIZADA POR EL COMITÉ DE AUDITORÍA</strong></p>`
    var users = await new Promise(resolve => {
      mongo.toHash('user', {}, { _id: 1, name: 1 }, (err, users) => {
        if (!err) {
          resolve(users)
        } else {
          resolve(false)
        }
      })
    })
    var units = await new Promise(resolve => {
      mongo.toHash('unit', {}, { _id: 1, name: 1 }, (err, units) => {
        if (!err) {
          resolve(units)
        } else {
          resolve(false)
        }
      })
    })
    var commitments = await new Promise(resolve => {
      mongo.aggregate('commitment', [
        {
          $match: {
            extension: { $exists: 1 },
            status: { $nin: ['draft', 'done', 'canceled', 'incomplete'] }
          }
        },
        {
          $lookup: {
            from: 'evidence',
            let: { id: '$_id' },
            pipeline: [
              {
                $match: {
                  $and: [
                    {
                      $expr:
                    {
                      $and:
                       [
                         { $eq: ['$reference', '$$id'] }
                       ]
                    }
                    },
                    { status: { $ne: 'draft' } }
                  ]
                }
              }
            ],
            as: 'evidences'
          }
        },
        { $lookup: { from: 'attached', localField: 'reference', foreignField: '_id', as: 'attached' } },
        { $lookup: { from: 'note', localField: 'attached.0.reference', foreignField: '_id', as: 'note' } },
        {
          $lookup: {
            from: 'params',
            pipeline: [
              { $match: { $expr: { $and: [{ $eq: ['$name', 'riskLevel'] }] } } },
              { $project: { _id: 0, options: 1 } }
            ],
            as: 'risks'
          }
        },
        {
          $addFields: {
            risk: { $arrayElemAt: ['$risks', 0] }
          }
        },
        {
          $project: {
            _id: 1,
            name: 1,
            content: 1,
            responsible: 1,
            note: 1,
            attached: 1,
            evidences: 1,
            extension: 1,
            risk: { $ifNull: [{ $arrayElemAt: ['$risk.options.value', { $indexOfArray: ['$risk.options.id', '$risk'] }] }, ''] },
            dates: 1
          }
        }
      ], {}, (err, commitments) => {
        if (!err) {
          resolve(commitments)
        } else {
          resolve(false)
        }
      })
    })
    if (commitments && commitments.length) {
      for (const a in commitments) {
        var responsible
        html += '<br><table style="  width: 1000px" class="gpaxTable" border="1" cellspacing="0" cellpadding="5" ><colgroup><col style="width: 80px"><col style="width: 108px"><col style="width: 128px"><col style="width: 115px"><col style="width: 102px"><col style="width: 112px"><col style="width: 121px"><col style="width: 234px"></colgroup><tr><th style="background-color:#9b9b9b;text-align:center;vertical-align:middle"><span style="font-weight:bold">Secuencia</span></th><th style="background-color:#9b9b9b;text-align:center;vertical-align:middle" colspan="3"><span style="font-weight:bold">Informe</span></th><th style="background-color:#9b9b9b;text-align:center;vertical-align:middle" colspan="4"><span style="font-weight:bold">Anexo</span></th></tr><tr><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top">{{secuencia}}</td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top" colspan="3">{{asunto}}</td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top" colspan="4">{{contenido}}</td></tr><tr><td style="background-color:#9b9b9b;font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;text-align:center;vertical-align:middle"><span style="font-weight:bold">Riesgo</span></td><td style="background-color:#9b9b9b;font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;text-align:center;vertical-align:middle"><span style="font-weight:700">Fecha</span></td><td style="background-color:#9b9b9b;font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:center;vertical-align:top"><span style="font-weight:bold">Días Acumulados</span></td><td style="background-color:#9b9b9b;font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:center;vertical-align:top"><span style="font-weight:bold">Estado</span></td><td style="background-color:#9b9b9b;font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;text-align:center;vertical-align:middle"><span style="font-weight:bold">Vencimiento</span></td><td style="background-color:#9b9b9b;font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:center;vertical-align:top"><span style="font-weight:bold">Original</span></td><td style="background-color:#9b9b9b;font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:center;vertical-align:top"><span style="font-weight:bold">Área Responsable</span></td><td style="background-color:#9b9b9b;font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:center;vertical-align:top"><span style="font-weight:bold">Auditor Responsable</span></td></tr><tr><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top">{{riesgo}}</td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top">{{fecha}}</td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top">{{dias}}</td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top">{{status}}</td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top">{{vencimiento}}</td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top">{{original}}</td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top">{{area}}</td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top">{{responsable}}</td></tr><tr><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top" colspan="8">Seguimiento: {{asunSeguimiento}}<br><br>{{contSeguimiento}}<br></td></tr><tr><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top" colspan="8">Prorrogas: <br>{{cantidad}}<br></td></tr></table>'
        // html += '<br><table style="border-collapse:collapse;border-spacing:0;table-layout: fixed; width: 100%" class="gpaxTable"><colgroup><col style="width: 8%"><col style="width: 10.8%"><col style="width: 12.8%"><col style="width: 11.5%"><col style="width: 10.2%"><col style="width: 11.2%"><col style="width: 12.1%"><col style="width: 23.4%"></colgroup><tr><th style="text-align:center;vertical-align:middle"><span style="font-weight:bold">Secuencia</span></th><th style="text-align:center;vertical-align:middle" colspan="3"><span style="font-weight:bold">Informe</span></th><th style="text-align:center;vertical-align:middle" colspan="4"><span style="font-weight:bold">Anexo</span></th></tr><tr><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top">{{secuencia}}</td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top" colspan="3">{{asunto}}</td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top" colspan="4">{{contenido}}</td></tr><tr><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;text-align:center;vertical-align:middle"><span style="font-weight:bold">Riesgo</span></td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;text-align:center;vertical-align:middle"><span style="font-weight:700">Fecha</span></td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:center;vertical-align:top"><span style="font-weight:bold">Días Acumulados</span></td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:center;vertical-align:top"><span style="font-weight:bold">Estado</span></td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;text-align:center;vertical-align:middle"><span style="font-weight:bold">Vencimiento</span></td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:center;vertical-align:top"><span style="font-weight:bold">Original</span></td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:center;vertical-align:top"><span style="font-weight:bold">Área Responsable</span></td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:center;vertical-align:top"><span style="font-weight:bold">Auditor Responsable</span></td></tr><tr><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top">{{riesgo}}</td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top">{{fecha}}</td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top">{{dias}}</td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top">{{status}}</td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top">{{vencimiento}}</td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top">{{original}}</td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top">{{area}}</td><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top">{{responsable}}</td></tr><tr><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top" colspan="8">Seguimiento: {{asunSeguimiento}}<br><br>{{contSeguimiento}}<br></td></tr><tr><td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top" colspan="8">Prorrogas: <br>{{cantidad}}<br></td></tr></table>'

        const commitment = commitments[a]
        if (commitment.note && commitment.note[0]) {
          html = html.replace('{{asunto}}', commitment.note[0].name)
          html = html.replace('{{secuencia}}', commitment.note[0].sequence.text)
          html = html.replace('{{status}}', changeStatus(commitment.note[0].status))
          html = html.replace('{{fecha}}', commitment.note[0].dates[0] ? moment(commitment.note[0].dates[0].value).format('YYYY-MM-DD') : '')
        }
        let supervisor
        for (const a in commitment.attached[0].actors) {
          if (commitment.attached[0].actors[a].supervisor === '1') {
            supervisor = commitment.attached[0].actors[a].user
            break
          }
          if (commitment.attached[0].actors[a].path === 'sent') {
            supervisor = commitment.attached[0].actors[a].user
          }
        }
        if (commitment.attached && commitment.attached[0]) {
          commitment.attached[0].actors.findIndex((a) => {
            if (a.role === 'responsible') {
              responsible = a
            }
          })
          html = html.replace('{{riesgo}}', commitment.risk)
          html = html.replace('{{area}}', responsible && responsible.unit ? (units[responsible.unit.toString()] ? units[responsible.unit.toString()].name : ' ') : '')
          html = html.replace('{{responsable}}', supervisor ? users[supervisor].name : '')
          html = html.replace('{{contenido}}', commitment.attached[0].name)
        }

        html = html.replace('{{vencimiento}}', (commitment.extension.length && commitment.extension[commitment.extension.length - 1].deadline ? moment(commitment.extension[commitment.extension.length - 1].deadline).format('YYYY-MM-DD') : ''))

        html = html.replace('{{original}}', (commitment.extension.length && commitment.extension[0].deadline ? moment(commitment.extension[0].deadline).format('YYYY-MM-DD') : ''))

        html = html.replace('{{dias}}', (commitment.extension.length && commitment.extension[commitment.extension.length - 1].deadline && commitment.extension[0].deadline ? moment(commitment.extension[commitment.extension.length - 1].deadline).diff(moment(commitment.extension[0].deadline), 'days'): ''))

        if (commitment.evidences && commitment.evidences.length) {
          const evidence = commitment.evidences[commitment.evidences.length - 1]
          html = html.replace('{{asunSeguimiento}}', evidence.name)
          html = html.replace('{{contSeguimiento}}', evidence.content)
        } else {
          html = html.replace('{{asunSeguimiento}}', '')
          html = html.replace('{{contSeguimiento}}', '')
        }
        let prorroga = ''
        for (const e in commitment.extension) {
          const extension = commitment.extension[e]
          prorroga += ( extension.deadline ? moment(extension.deadline).format('YYYY-MM-DD') : '') + '<br>'
        }
        html = html.replace('{{cantidad}}', prorroga)
      }
    }

    return html
  }
  this.forUnit = async function (mongo) {
    var settings = await new Promise(resolve => {
      mongo.findOne('settings', { _id: 'settings' }, (err, sett) => {
        if (err) {
          resolve(false)
        } else {
          resolve(sett)
        }
      })
    })
    var html = `<table style="width: 100%;" border="1" cellspacing="0" cellpadding="5">
                    <tbody>
                      <tr>
                        <td style="width: 9.2346%; vertical-align: middle;">
                          <div>${settings.photo ? (`<img src="/api/file.get?_id=${settings.photo.toString()}&type=jpg"  class="fr-fic fr-fil fr-dib"></div>`) : ''}
                        </td>
                        <td style="width: 8.3195%; text-align: right; vertical-align: middle;">
                        </td>
                      </tr>
                    </tbody>
                  </table>`
    var units = await new Promise(resolve => {
      mongo.toHash('unit', {}, { _id: 1, name: 1 }, (err, units) => {
        if (!err) {
          resolve(units)
        } else {
          resolve(false)
        }
      })
    })
    var attacheds = await new Promise(resolve => {
      mongo.aggregate('attached', [
        {
          $match: {
            responsible: {
              $not: { $type: 10 },
              $exists: true
            },
            status: { $in: ['processing', 'answered'] }
          }
        },
        {
          $lookup: {
            from: 'commitment',
            let: { id: '$_id' },
            pipeline: [
              {
                $match: {
                  $and: [
                    {
                      $expr:
                    {
                      $and:
                       [
                         { $eq: ['$reference', '$$id'] }
                       ]
                    }
                    },
                    { status: { $ne: 'draft' } }
                  ]
                }
              },
              { $project: { dates: 1 } }
            ],
            as: 'commitment'
          }
        },
        { $unwind: { path: '$commitment', preserveNullAndEmptyArrays: true } },
        {
          $lookup: {
            from: 'evidence',
            let: { id2: '$commitment._id' },
            pipeline: [
              {
                $match: {
                  $and: [
                    {
                      $expr:
                    {
                      $and:
                       [
                         { $eq: ['$reference', '$$id2'] }
                       ]
                    }
                    },
                    { status: { $ne: 'draft' } }
                  ]
                }
              },
              { $project: { name: 1, content: 1 } }
            ],
            as: 'evidences'
          }
        },
        { $lookup: { from: 'note', localField: 'reference', foreignField: '_id', as: 'note' } },
        { $unwind: { path: '$note', preserveNullAndEmptyArrays: true } },
        {
          $addFields: {
            responsibleSplit: { $split: ['$responsible', '&unit='] }
          }
        },
        {
          $addFields: {
            unit: { $arrayElemAt: ['$responsibleSplit', 1] }
          }
        },
        {
          $project: {
            _id: 1,
            content: 1,
            name: 1,
            status: 1,
            commitment: 1,
            evidences: 1,
            note: 1,
            unit: 1
          }
        },
        {
          $group: { _id: '$unit', attacheds: { $push: '$$ROOT' } }
        }
      ], {}, (err, attacheds) => {
        if (!err) {
          resolve(attacheds)
        } else {
          resolve(false)
        }
      })
    })

    if (attacheds && attacheds.length) {
      for (const u in attacheds) {
        const unit = attacheds[u]
        html += '<strong>' + units[unit._id].name + '</strong>'
        for (const a in unit.attacheds) {
          const attached = unit.attacheds[a]
          html += '<br><table border="1"  cellspacing="0" cellpadding="5"style="table-layout: fixed; width: 100%" ><colgroup><col style="width: 12%"><col style=""></colgroup><tr><th style="font-family:Arial, sans-serif;font-weight:normal;padding:10px 5px;background-color:#9b9b9b;text-align:center;vertical-align:top" colspan="2"><span style="font-weight:bold">Informe</span></th></tr><tr><td style="font-family:Arial, sans-serif;padding:10px 5px;text-align:left;vertical-align:top"><span style="font-weight:bold">Asunto:</span></td><td style="font-family:Arial, sans-serif;padding:10px 5px;text-align:left;vertical-align:top">{{asunto}}</td></tr><tr><td style="font-family:Arial, sans-serif;padding:10px 5px;text-align:left;vertical-align:top"><span style="font-weight:bold">Secuencia:</span></td><td style="font-family:Arial, sans-serif;padding:10px 5px;text-align:left;vertical-align:top">{{secuencia}}</td></tr><tr><td style="font-family:Arial, sans-serif;padding:10px 5px;text-align:left;vertical-align:top"><span style="font-weight:bold">Fecha:</span></td><td style="font-family:Arial, sans-serif;padding:10px 5px;text-align:left;vertical-align:top">{{fecha}}</td></tr><tr><td style="font-family:Arial, sans-serif;padding:10px 5px;background-color:#9b9b9b;text-align:center;vertical-align:top" colspan="2"><span style="font-weight:bold">Anexo</span></td></tr><tr><td style="font-family:Arial, sans-serif;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top"><span style="font-weight:bold">Asunto:</span></td><td style="font-family:Arial, sans-serif;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;text-align:left;vertical-align:top">{{asunAnexo}}</td></tr><tr><td style="font-family:Arial, sans-serif;padding:10px 5px;text-align:left;vertical-align:top"><span style="font-weight:bold">Estado:</span></td><td style="font-family:Arial, sans-serif;padding:10px 5px;text-align:left;vertical-align:top">{{estado}}</td></tr><tr><td style="font-family:Arial, sans-serif;padding:10px 5px;text-align:left;vertical-align:top"><span style="font-weight:bold">Fecha de compromiso:</span></td><td style="font-family:Arial, sans-serif;padding:10px 5px;text-align:left;vertical-align:top">{{vencimiento}}</td></tr><tr><td style="font-family:Arial, sans-serif;padding:10px 5px;text-align:left;vertical-align:top"><span style="font-weight:bold">Área </span><br><span style="font-weight:bold">Responsable:</span></td><td style="font-family:Arial, sans-serif;padding:10px 5px;text-align:left;vertical-align:top">{{area}}</td></tr><tr><td style="font-family:Arial, sans-serif;padding:10px 5px;text-align:left;vertical-align:top" colspan="2">{{contenido}}</td></tr><tr><td style="font-family:Arial, sans-serif;padding:10px 5px;background-color:#9b9b9b;text-align:center;vertical-align:top" colspan="2"><span style="font-weight:bold">Ultimo Seguimiento</span></td></tr><tr><td style="font-family:Arial, sans-serif;padding:10px 5px;text-align:left;vertical-align:top"><span style="font-weight:bold">Asunto:</span></td><td style="font-family:Arial, sans-serif;padding:10px 5px;text-align:left;vertical-align:top">{{asunSeguimiento}}</td></tr><tr><td style="font-family:Arial, sans-serif;padding:10px 5px;text-align:left;vertical-align:top" colspan="2">{{contSeguimiento}}</td></tr></table>'
          if (attached.note) {
            html = html.replace('{{asunto}}', attached.note.name)
            html = html.replace('{{secuencia}}', attached.note.sequence.text)
            html = html.replace('{{fecha}}', moment(attached.note.dates[0].value).format('YYYY-MM-DD'))
          }
          html = html.replace('{{asunAnexo}}', attached.name)
          html = html.replace('{{estado}}', changeStatus(attached.status))
          html = html.replace('{{area}}', units[unit._id].name)
          if (attached.content.indexOf('id="condicion"') !== -1) {
            let content = ''
            content += '<span style=""><strong>Condición</strong></span><br>'
            const root = parseHtml.parse(attached.content)
            content += root.querySelectorAll('#condicion')[0].innerHTML + '<br>'
            if (attached.content.indexOf('id="causas"') !== -1) {
              content += '<span style=""><strong>Causas</strong></span><br>'
              const root = parseHtml.parse(attached.content)
              content += root.querySelectorAll('#causas')[0].innerHTML + '<br>'
            }
            if (attached.content.indexOf('id="efectos"') !== -1) {
              content += '<span style=""><strong>Efectos</strong></span><br>'
              const root = parseHtml.parse(attached.content)
              content += root.querySelectorAll('#efectos')[0].innerHTML + '<br>'
            }
            if (attached.content.indexOf('id="recomendacion"') !== -1) {
              content += '<span style=""><strong>Recomendación</strong></span><br>'
              const root = parseHtml.parse(attached.content)
              content += root.querySelectorAll('#recomendacion')[0].innerHTML + '<br>'
            }
            html = html.replace('{{contenido}}', content)
          } else {
            html = html.replace('{{contenido}}', attached.content)
          }

          if (attached.commitment) {
            const d = attached.commitment.dates.findIndex((d) => {
              return d.type === 'deadline'
            })
            if (d !== -1) {
              html = html.replace('{{vencimiento}}', moment(attached.commitment.dates[d].value).format('YYYY-MM-DD'))
            } else {
              html = html.replace('{{vencimiento}}', '')
            }
          }
          if (attached.evidences && attached.evidences.length) {
            const evidence = attached.evidences[attached.evidences.length - 1]
            html = html.replace('{{asunSeguimiento}}', evidence.name)
            html = html.replace('{{contSeguimiento}}', evidence.content)
          } else {
            html = html.replace('{{asunSeguimiento}}', '')
            html = html.replace('{{contSeguimiento}}', '')
          }
        }
      }
    }

    return html
  }
  this.childUnits = (id, allUnits) => {
    var childs = []
    if (allUnits[id]) {
      for (const i in allUnits) {
        if (allUnits[i].parent && allUnits[i].parent.toString() === id) {
          if (childs.findIndex((x) => { return x.toString() === allUnits[i]._id.toString() }) === -1) {
            childs.push(allUnits[i]._id)
          }
          this.childUnits(allUnits[i]._id.toString(), allUnits)
        }
      }
    }
    return childs
  }
  this.auditCommitteeAgreements = async function (req, mongo, send) {
    var html = ''
    // TODO generate html
    var settings = await new Promise(resolve => {
      mongo.findOne('settings', { _id: 'settings' }, (err, sett) => {
        if (err) {
          resolve(false)
        } else {
          resolve(sett)
        }
      })
    })
    html += `<table  style="width: 100%;">
                    <tbody>
                      <tr>
                        <td style="width: 9.2346%; vertical-align: middle;">
                          <div>${settings.photo ? (`<img src="/api/file.get?_id=${settings.photo.toString()}&type=jpg"  class="fr-fic fr-fil fr-dib"></div>`) : ''}
                        </td>
                        <td style="width: 8.3195%; text-align: right; vertical-align: middle;">
                          Anexo N. #
                        </td>
                      </tr>
                    </tbody>
                  </table>`
    let auditCommitee = []
    if (settings.auditCommittee) {
      if (Array.isArray(settings.auditCommittee)) {
        auditCommitee = settings.auditCommittee
      } else {
        auditCommitee.push(settings.auditCommittee)
      }
    } else {
      if (Array.isArray(settings.auditCommitee)) {
        auditCommitee = settings.auditCommitee
      } else {
        auditCommitee.push(settings.auditCommitee)
      }
    }
    var unit = await new Promise(resolve => {
      mongo.find('unit', { _id: { $in: auditCommitee } }, (err, units) => {
        if (!err) {
          resolve(units)
        } else {
          resolve(false)
        }
      })
    })
    for (let u in unit) {
      var notes = await new Promise(resolve => {
        mongo.aggregate('note', [
          {
            $match: {
              actors: { $elemMatch: { role: 'from', unit: unit[u]._id } },
              status: { $ne: 'draft' }
            }
          },
          {
            $lookup: {
              from: 'attached',
              let: { id: '$_id' },
              pipeline: [
                {
                  $match: {
                    $expr:
                    {
                      $and:
                        [
                          { $eq: ['$reference', '$$id'] }
                        ]
                    }
                  }
                }
              ],
              as: 'attacheds'
            }
          },
          { $unwind: { path: '$attacheds', preserveNullAndEmptyArrays: true } },
          {
            $addFields:
            {
              'attacheds.datesNote': '$dates',
              'attacheds.sequenceNote': '$sequence'
            }
          },
          {
            $lookup: {
              from: 'commitment',
              let: { id: '$attacheds._id' },
              pipeline: [
                {
                  $match: {
                    $expr:
                    {
                      $and:
                        [
                          { $eq: ['$reference', '$$id'] }
                        ]
                    }
                  }
                }
              ],
              as: 'attacheds.commitment'
            }
          },
          { $unwind: { path: '$attacheds.commitment', preserveNullAndEmptyArrays: true } },
          {
            $addFields: {
              'attacheds.deadlineField': {
                $cond: {
                  if: { $or: [{ $eq: ['completed', '$attacheds.status'] }, { $eq: ['answered', '$attacheds.status'] }] },
                  then: '$attacheds.commitment.dates',
                  else: '$attacheds.dates'
                }
              }
            }
          },
          {
            $lookup: {
              from: 'evidence',
              let: { id: '$attacheds.commitment._id' },
              pipeline: [
                { $match: { $expr: { $and: [{ $eq: ['$reference', '$$id'] }] }, status: { $ne: 'draft' } } },
                { $project: { _id: 0, dates: 1, name: 1, responsible: 1, status: 1 } }
              ],
              as: 'attacheds.commitment.evidence'
            }
          },
          { $group: { _id: '$_id', attacheds: { $push: '$attacheds' } } },
          { $sort: { _id: -1 } }
        ], {}, async (err, note) => {
          if (err) {
            resolve()
            console.log(err)
          } else {
            resolve(note)
          }
        })
      })
      if (notes && notes.length) {
        var users = await new Promise(resolve => {
          mongo.toHash('user', {}, { _id: 1, name: 1 }, (err, users) => {
            if (!err) {
              resolve(users)
            } else {
              resolve(false)
            }
          })
        })
        html += '</br></br><span style="font-size: 18px;"><strong>Registro de los Acuerdos de "' + unit[u].name + '" al ' + dateformat(new Date(), 'dd/mm/yyyy') + '. Sesión No.' + notes[0].attacheds[0].sequenceNote.text + '</strong></span><br>'
        html += '{{tableGlobal}}'
        var cT = 0
        var pT = 0
        var aT = 0
        var tT = 0
        var totalG = 0
        // for(let note in notes) {
        let i = 0
        while (i !== notes.length - 1) { // notes.length-1
          const note = i
          var newHtmlCompleted = '<h3><strong>Acuerdos Solventados</strong></h3></br>'
          var newHtmlProcessing = '<h3><strong>Acuerdos Vencidos Sin Respuesta</strong></h3></br>'
          var newHtmlAnswered = '<h3><strong>Acuerdos Vencidos Con Respuesta</strong></h3></br>'
          var newHtmlTermAgreements = '<h3><strong>Acuerdos En Plazo</strong></h3></br>'

          var pipeline = []
          var completed = 0
          var processing = 0
          var answered = 0
          var termAgreements = 0
          var totalAgreements = 0
          var c = 0
          var p = 0
          var a = 0
          var t = 0

          const posNoteIssueDate = notes[note].attacheds[0].datesNote.findIndex((x) => {
            return x.type === 'issue'
          })

          var noteIssueDate = dateformat(notes[note].attacheds[0].datesNote[posNoteIssueDate].value, 'dd/mm/yyyy')

          pipeline.push({ $match: { reference: mongo.toId(notes[note]._id.toString()) } })

          if (notes[note].attacheds.length && notes[note].attacheds[0]._id) {
            for (const at in notes[note].attacheds) {
              var responsibleName = ''
              var seguimiento = ''
              var evidence = ''
              var existPos = false
              var existPos2 = false
              if (notes[note].attacheds[at].deadlineField) {
                const pos = notes[note].attacheds[at].deadlineField.findIndex((x) => {
                  return x.type === 'deadline'
                })

                if (pos !== -1) {
                  if (moment(notes[note].attacheds[at].deadlineField[pos].value).startOf('day')._d < moment(new Date()).startOf('day')._d) {
                    existPos = true
                  }
                  if (moment(notes[note].attacheds[at].deadlineField[pos].value).startOf('day')._d >= moment(new Date()).startOf('day')._d) {
                    existPos2 = true
                  }
                }
              } else {
                const pos = notes[note].attacheds[at].dates.findIndex((x) => {
                  return x.type === 'deadline'
                })

                if (pos !== -1) {
                  if (moment(notes[note].attacheds[at].dates[pos].value).startOf('day')._d < moment(new Date()).startOf('day')._d) {
                    existPos = true
                  }
                  if (moment(notes[note].attacheds[at].dates[pos].value).startOf('day')._d >= moment(new Date()).startOf('day')._d) {
                    existPos2 = true
                  }
                }
              }

              if (notes[note].attacheds[at].responsible && notes[note].attacheds[at].responsible.length) {
                responsibleName = users[notes[note].attacheds[at].responsible.split('&unit=')[0]].name
              }

              if (notes[note].attacheds[at].commitment._id) {
                if (notes[note].attacheds[at].commitment.evidences && notes[note].attacheds[at].commitment.evidences.length) {
                  notes[note].attacheds[at].commitment.evidences[0].content ? seguimiento += notes[note].attacheds[at].commitment.evidences[0].content : seguimiento += ''
                } else {
                  notes[note].attacheds[at].commitment.content ? seguimiento += notes[note].attacheds[at].commitment.content : seguimiento += ''
                }
              }

              if (notes[note].attacheds[at].status === 'completed') {
                completed++
                c += 1
                cT += 1

                newHtmlCompleted += '<table style="width:100%" border="1" cellspacing="0" cellpadding="5"> <tr> <th>Sesión</th> <th>Fecha</th> <th>Referencia</th> <th>Funcionario Responsable</th> <th>Estatus del Acuerdo</th> <th>No.</th> </tr> <tr> <td>' + notes[note].attacheds[0].sequenceNote.text + '</td> <td>' + noteIssueDate + '</td> <td>' + notes[note].attacheds[at].name + '</td> <td>' + responsibleName + '</td> <td>' + changeStatus(notes[note].attacheds[at].status) + '</td> <td>' + c + '</td> </tr> <table style="width:100%" border="1" cellspacing="0" cellpadding="5"> <tr> <td>' + notes[note].attacheds[at].content + '</td> </tr> <tr> <td>Último seguimiento<br><br>' + seguimiento + '</td> </tr> </table> </table></br>'
              } else if (notes[note].attacheds[at].status === 'processing' && existPos) {
                processing++
                p += 1
                pT += 1

                newHtmlProcessing += '<table style="width:100%" border="1" cellspacing="0" cellpadding="5"> <tr> <th>Sesión</th> <th>Fecha</th> <th>Referencia</th> <th>Funcionario Responsable</th> <th>Estatus del Acuerdo</th> <th>No.</th> </tr> <tr> <td>' + notes[note].attacheds[0].sequenceNote.text + '</td> <td>' + noteIssueDate + '</td> <td>' + notes[note].attacheds[at].name + '</td> <td>' + responsibleName + '</td> <td>' + changeStatus(notes[note].attacheds[at].status) + '</td> <td>' + p + '</td> </tr> <table style="width:100%" border="1" cellspacing="0" cellpadding="5"> <tr> <td>' + notes[note].attacheds[at].content + '</td> </tr> <tr> <td>Último seguimiento<br><br>' + seguimiento + '</td> </tr> </table> </table></br>'
              } else if (notes[note].attacheds[at].status === 'answered' && existPos) {
                answered++
                a += 1
                aT += 1

                newHtmlAnswered += '<table style="width:100%" border="1" cellspacing="0" cellpadding="5"> <tr> <th>Sesión</th> <th>Fecha</th> <th>Referencia</th> <th>Funcionario Responsable</th> <th>Estatus del Acuerdo</th> <th>No.</th> </tr> <tr> <td>' + notes[note].attacheds[0].sequenceNote.text + '</td> <td>' + noteIssueDate + '</td> <td>' + notes[note].attacheds[at].name + '</td> <td>' + responsibleName + '</td> <td>' + changeStatus(notes[note].attacheds[at].status) + '</td> <td>' + a + '</td> </tr> <table style="width:100%" border="1" cellspacing="0" cellpadding="5"> <tr> <td>' + notes[note].attacheds[at].content + '</td> </tr> <tr> <td>Último seguimiento<br><br>' + seguimiento + '</td> </tr> </table> </table></br>'
              } else if (existPos2 && ((notes[note].attacheds[at].status === 'processing') || (notes[note].attacheds[at].status === 'answered'))) {
                termAgreements++
                t += 1
                tT += 1
                newHtmlTermAgreements += '<style> table, th, td { border: 1px solid black;  } th, td { padding: 10px;}  </style>'
                newHtmlTermAgreements += '<table style="width:100%" border="1" cellspacing="0" cellpadding="5"> <tr> <th>Sesión</th> <th>Fecha</th> <th>Referencia</th> <th>Funcionario Responsable</th> <th>Estatus del Acuerdo</th> <th>No.</th> </tr> <tr> <td>' + notes[note].attacheds[0].sequenceNote.text + '</td> <td>' + noteIssueDate + '</td> <td>' + notes[note].attacheds[at].name + '</td> <td>' + responsibleName + '</td> <td>' + changeStatus(notes[note].attacheds[at].status) + '</td> <td>' + t + '</td> </tr> <table style="width:100%" border="1" cellspacing="0" cellpadding="5"> <tr> <td>' + notes[note].attacheds[at].content + '</td> </tr> <tr> <td>Último seguimiento<br><br>' + seguimiento + '</td> </tr> </table> </table></br>'
              }
            }
            totalAgreements = completed + processing + answered + termAgreements
            totalG = cT + pT + aT + tT
            html += '</br>'
            html += '<table style="width:100%" border="1" cellspacing="0" cellpadding="5">	<tr>  <th>Resumen</th>	</tr> <table style="width:100%" border="1" cellspacing="0" cellpadding="5">  <tr>  <td>Acuerdos Solventados</td><td>' + completed + '</td> </tr><tr> <td>Acuerdos Vencidos Con Respuesta</td>  <td>' + answered + '</td>  </tr>  <tr>  <td>Acuerdos Vencidos Sin Respuesta</td>  <td>' + processing + '</td> </tr> <tr> <td>Acuerdos En Plazo</td> <td>' + termAgreements + '</td> </tr> <tr> <td><strong>Total de Acuerdos</strong></td> <td><strong>' + totalAgreements + '</strong></td> </tr> </table> </table></br>'
            html += completed !== 0 ? newHtmlCompleted : ''
            html += answered !== 0 ? newHtmlAnswered : ''
            html += processing !== 0 ? newHtmlProcessing : ''
            html += termAgreements !== 0 ? newHtmlTermAgreements : ''
          }
          i++
        }
        html = html.replace('{{tableGlobal}}', '<table style="width:100%" border="1" cellspacing="0" cellpadding="5">	<tr>  <th>Resumen</th>	</tr> <table style="width:100%" border="1" cellspacing="0" cellpadding="5">  <tr>  <td>Acuerdos Solventados</td><td>' + cT + '</td> </tr><tr> <td>Acuerdos Vencidos Con Respuesta</td>  <td>' + aT + '</td>  </tr>  <tr>  <td>Acuerdos Vencidos Sin Respuesta</td>  <td>' + pT + '</td> </tr> <tr> <td>Acuerdos En Plazo</td> <td>' + tT + '</td> </tr> <tr> <td><strong>Total de Acuerdos</strong></td> <td><strong>' + totalG + '</strong></td> </tr> </table> </table></br>')
      }
    }
    send(html)
  }

  function changeStatus (status) {
    switch (status) {
    case 'processing':
      return 'En proceso'
    case 'answered':
      return 'respondido'
    case 'completed':
      return 'completado'
    default:
      return status
    }
  }

  this.auditCommitteeAgreements2 = async function (req, mongo, data, send) {
    var html = ''
    // TODO generate html
    var settings = await new Promise(resolve => {
      mongo.findOne('settings', { _id: 'settings' }, (err, sett) => {
        if (err) {
          resolve(false)
        } else {
          resolve(sett)
        }
      })
    })
    html += `<table  style="width: 100%;"  >
                    <tbody>
                      <tr>
                        <td style="width: 9.2346%; vertical-align: middle;">
                          <div>${settings.photo ? (`<img src="/api/file.get?_id=${settings.photo.toString()}&type=jpg"  class="fr-fic fr-fil fr-dib"></div>`) : ''}
                        </td>
                        <td style="width: 8.3195%; text-align: right; vertical-align: middle;">
                          <strong>ANEXO No 1</strong>
                        </td>
                      </tr>
                    </tbody>
                  </table>`
    let auditCommitee = []
    if (settings.auditCommittee) {
      if (Array.isArray(settings.auditCommittee)) {
        auditCommitee = settings.auditCommittee
      } else {
        auditCommitee.push(settings.auditCommittee)
      }
    } else {
      if (Array.isArray(settings.auditCommitee)) {
        auditCommitee = settings.auditCommitee
      } else {
        auditCommitee.push(settings.auditCommitee)
      }
    }
    var unit = await new Promise(resolve => {
      mongo.find('unit', { _id: { $in: auditCommitee } }, (err, units) => {
        if (!err) {
          resolve(units)
        } else {
          resolve(false)
        }
      })
    })
    var period = data.period
    if (period.start) {
      var start = moment(period.start).startOf('day')
    }
    if (period.end) {
      var end = moment(period.end).endOf('day')
    }
    if (data.cutoffDate) {
      var date = moment(data.cutoffDate).endOf('day')
    }
    for (let u in unit) {
      var compromisosSolventados = await new Promise(resolve => {
        mongo.aggregate('commitment', [
          {
            $match: {
              $and: [
                { actors: { $elemMatch: { role: 'supervisor', unit: mongo.toId(unit[u]._id) } } },
                { 'dates.0.value': { $lte: new Date(end.format('YYYY-MM-DD HH:mm')), $gte: new Date(start.format('YYYY-MM-DD HH:mm')) } },
                { status: { $in: ['done', 'incomplete', 'canceled'] } }
              ]
            }
          },
          {
            $lookup: {
              from: 'attached',
              let: { reference: '$reference' },
              pipeline: [
                {
                  $match: {
                    $expr:
                    {
                      $and:
                        [
                          { $eq: ['$_id', '$$reference'] }
                        ]
                    }
                  }
                }
              ],
              as: 'attached'
            }
          },
          { $unwind: { path: '$attached', preserveNullAndEmptyArrays: true } },
          {
            $lookup: {
              from: 'note',
              let: { reference: '$attached.reference' },
              pipeline: [
                {
                  $match: {
                    $expr:
                    {
                      $and:
                        [
                          { $eq: ['$_id', '$$reference'] }
                        ]
                    }
                  }
                }
              ],
              as: 'note'
            }
          },
          { $unwind: { path: '$note', preserveNullAndEmptyArrays: true } },
          {
            $lookup: {
              from: 'evidence',
              let: { id: '$_id' },
              pipeline: [
                { $match: { $expr: { $and: [{ $eq: ['$reference', '$$id'] }] }, status: { $ne: 'draft' } } },
                { $project: { _id: 0, dates: 1, name: 1, status: 1, content: 1 } }
              ],
              as: 'evidences'
            }
          },
          { $sort: { _id: -1 } }
        ], {}, async (err, commitment) => {
          if (err) {
            resolve()
            console.log(err)
          } else {
            resolve(commitment)
          }
        })
      })
      var vencidosSinRes = await new Promise(resolve => {
        mongo.aggregate('attached', [
          {
            $match: {
              $and: [
                { actors: { $elemMatch: { role: 'from', unit: mongo.toId(unit[u]._id) } } },
                { 'dates.1.value': { $lte: new Date(date.format('YYYY-MM-DD HH:mm')) } },
                { status: 'processing' }
              ]
            }
          },
          {
            $lookup: {
              from: 'note',
              let: { reference: '$reference' },
              pipeline: [
                {
                  $match: {
                    $expr:
                    {
                      $and:
                        [
                          { $eq: ['$_id', '$$reference'] }
                        ]
                    }
                  }
                }
              ],
              as: 'note'
            }
          },
          { $unwind: { path: '$note', preserveNullAndEmptyArrays: true } },
          { $sort: { _id: -1 } }
        ], {}, async (err, commitment) => {
          if (err) {
            resolve()
            console.log(err)
          } else {
            resolve(commitment)
          }
        })
      })
      var vencidosConRes = await new Promise(resolve => {
        mongo.aggregate('attached', [
          {
            $match: {
              $and: [
                { actors: { $elemMatch: { role: 'from', unit: mongo.toId(unit[u]._id) } } },
                // { 'dates.1.value': { $lte: new Date(date.format('YYYY-MM-DD HH:mm')) } },
                { status: 'answered' }
              ]
            }
          },
          {
            $lookup: {
              from: 'note',
              let: { reference: '$reference' },
              pipeline: [
                {
                  $match: {
                    $expr:
                    {
                      $and:
                        [
                          { $eq: ['$_id', '$$reference'] }
                        ]
                    }
                  }
                }
              ],
              as: 'note'
            }
          },
          { $unwind: { path: '$note', preserveNullAndEmptyArrays: true } },
          {
            $lookup: {
              from: 'commitment',
              let: { id: '$_id' },
              pipeline: [
                {
                  $match: {
                    $expr:
                    {
                      $and:
                        [
                          { $eq: ['$reference', '$$id'] }
                        ]
                    }
                  }
                }
              ],
              as: 'commitment'
            }
          },
          { $unwind: { path: '$commitment', preserveNullAndEmptyArrays: true } },
          {
            $addFields: {
              deadlineField: '$commitment.dates'
            }
          },
          {
            $match: { 'deadlineField.1.value': { $lte: new Date(date.format('YYYY-MM-DD HH:mm')) } }
          },
          {
            $lookup: {
              from: 'evidence',
              let: { id: '$commitment._id' },
              pipeline: [
                { $match: { $expr: { $and: [{ $eq: ['$reference', '$$id'] }] }, status: { $ne: 'draft' } } },
                { $project: { _id: 0, dates: 1, name: 1, status: 1, content: 1 } }
              ],
              as: 'evidences'
            }
          },
          { $sort: { _id: -1 } }
        ], {}, async (err, commitment) => {
          if (err) {
            resolve()
            console.log(err)
          } else {
            resolve(commitment)
          }
        })
      })
      var enPlazo = await new Promise(resolve => {
        mongo.aggregate('attached', [
          {
            $match: {
              $and: [
                { actors: { $elemMatch: { path: 'sent', unit: mongo.toId(unit[u]._id) } } },
                // { 'dates.1.value': { $gte: new Date(date.format('YYYY-MM-DD HH:mm')) } },
                { status: { $nin: ['draft', 'prepared', 'completed'] } }
              ]
            }
          },
          {
            $lookup: {
              from: 'note',
              let: { reference: '$reference' },
              pipeline: [
                {
                  $match: {
                    $expr:
                    {
                      $and:
                        [
                          { $eq: ['$_id', '$$reference'] }
                        ]
                    }
                  }
                }
              ],
              as: 'note'
            }
          },
          { $unwind: { path: '$note', preserveNullAndEmptyArrays: true } },
          {
            $lookup: {
              from: 'commitment',
              let: { id: '$_id' },
              pipeline: [
                {
                  $match: {
                    $expr:
                    {
                      $and:
                        [
                          { $eq: ['$reference', '$$id'] }
                        ]
                    }
                  }
                }
              ],
              as: 'commitment'
            }
          },
          { $unwind: { path: '$commitment', preserveNullAndEmptyArrays: true } },
          {
            $addFields: {
              deadlineField: {
                $cond: {
                  if: { $eq: ['answered', '$status'] },
                  // then: { $arrayElemAt: ['$commitment.dates', 0] },
                  then: '$commitment.dates',
                  else: '$dates'
                }
              }
            }
          },
          {
            $match: { 'deadlineField.1.value': { $gte: new Date(date.format('YYYY-MM-DD HH:mm')) } }
          },
          {
            $lookup: {
              from: 'evidence',
              let: { id: '$commitment._id' },
              pipeline: [
                { $match: { $expr: { $and: [{ $eq: ['$reference', '$$id'] }] }, status: { $ne: 'draft' } } },
                { $project: { _id: 0, dates: 1, name: 1, status: 1, content: 1 } }
              ],
              as: 'evidences'
            }
          },
          { $sort: { _id: -1 } }
        ], {}, async (err, commitment) => {
          if (err) {
            resolve()
            console.log(err)
          } else {
            resolve(commitment)
          }
        })
      })
      var users = await new Promise(resolve => {
        mongo.toHash('user', {}, { _id: 1, name: 1 }, (err, users) => {
          if (!err) {
            resolve(users)
          } else {
            resolve(false)
          }
        })
      })
      let totalG = 0
      html += '<p style="text-align: center;"><strong>Registro de los Acuerdos de ' + unit[u].name + ' al ' + dateformat(new Date(), 'dd/mm/yyyy') + '. Sesión No.' + data.name + '</strong></p>'
      html += '{{tableGlobal}}'
      if (compromisosSolventados && compromisosSolventados.length) {
        totalG += compromisosSolventados.length
        html += '<h3><strong>Acuerdos Solventados</strong></h3></br>'
        for (const a in compromisosSolventados) {
          const commitment = compromisosSolventados[a]
          let responsibleName = ''
          let seguimiento = ''
          const posNoteIssueDate = commitment.note.dates.findIndex((x) => {
            return x.type === 'issue'
          })
          const noteIssueDate = dateformat(commitment.note.dates[posNoteIssueDate].value, 'dd/mm/yyyy')
          if (commitment.attached.responsible && commitment.attached.responsible.length) {
            responsibleName = users[commitment.attached.responsible.split('&unit=')[0]].name
          }
          if (commitment.evidences && commitment.evidences.length) {
            seguimiento = commitment.evidences[commitment.evidences.length - 1].content
          }
          html += '<table style="width:100%" border="1" cellspacing="0" cellpadding="5"> <tr> <th>Sesión</th> <th>Fecha</th> <th>Referencia</th> <th>Funcionario Responsable</th> <th>Estatus del Acuerdo</th> <th>No.</th> </tr> <tr> <td>' + commitment.note.sequence.text + '</td> <td>' + noteIssueDate + '</td> <td>' + commitment.attached.name + '</td> <td>' + responsibleName + '</td> <td>' + changeStatus(commitment.attached.status) + '</td> <td>' + (Number(a) + 1) + '</td> </tr> <table style="width:100%" border="1" cellspacing="0" cellpadding="5"> <tr> <td>' + commitment.attached.content + '</td> </tr> <tr> <td>Último seguimiento<br><br>' + seguimiento + '</td> </tr> </table> </table></br>'
        }
      }
      if (vencidosSinRes && vencidosSinRes.length) {
        totalG += vencidosSinRes.length
        html += '<h3><strong>Acuerdos Vencidos Sin Respuesta</strong></h3></br>'
        for (const a in vencidosSinRes) {
          const attached = vencidosSinRes[a]
          let responsibleName = ''
          const posNoteIssueDate = attached.note.dates.findIndex((x) => {
            return x.type === 'issue'
          })
          const noteIssueDate = dateformat(attached.note.dates[posNoteIssueDate].value, 'dd/mm/yyyy')
          if (attached.responsible && attached.responsible.length) {
            responsibleName = users[attached.responsible.split('&unit=')[0]].name
          }
          html += '<table style="width:100%" border="1" cellspacing="0" cellpadding="5"> <tr> <th>Sesión</th> <th>Fecha</th> <th>Referencia</th> <th>Funcionario Responsable</th> <th>Estatus del Acuerdo</th> <th>No.</th> </tr> <tr> <td>' + attached.note.sequence.text + '</td> <td>' + noteIssueDate + '</td> <td>' + attached.name + '</td> <td>' + responsibleName + '</td> <td>' + changeStatus(attached.status) + '</td> <td>' + (Number(a) + 1) + '</td> </tr> <table style="width:100%" border="1" cellspacing="0" cellpadding="5"> <tr> <td>' + attached.content + '</td> </tr></table> </table></br>'
        }
      }
      if (vencidosConRes && vencidosConRes.length) {
        totalG += vencidosConRes.length
        html += '<h3><strong>Acuerdos Vencidos Con Respuesta</strong></h3></br>'
        for (const a in vencidosConRes) {
          const attached = vencidosConRes[a]
          let responsibleName = ''
          let seguimiento = ''
          const posNoteIssueDate = attached.note.dates.findIndex((x) => {
            return x.type === 'issue'
          })
          const noteIssueDate = dateformat(attached.note.dates[posNoteIssueDate].value, 'dd/mm/yyyy')
          if (attached.responsible && attached.responsible.length) {
            responsibleName = users[attached.responsible.split('&unit=')[0]].name
          }
          if (attached.evidences && attached.evidences.length) {
            seguimiento = attached.evidences[attached.evidences.length - 1].content
          }
          html += '<table style="width:100%" border="1" cellspacing="0" cellpadding="5"> <tr> <th>Sesión</th> <th>Fecha</th> <th>Referencia</th> <th>Funcionario Responsable</th> <th>Estatus del Acuerdo</th> <th>No.</th> </tr> <tr> <td>' + attached.note.sequence.text + '</td> <td>' + noteIssueDate + '</td> <td>' + attached.name + '</td> <td>' + responsibleName + '</td> <td>' + changeStatus(attached.status) + '</td> <td>' + (Number(a) + 1) + '</td> </tr> <table style="width:100%" border="1" cellspacing="0" cellpadding="5"> <tr> <td>' + attached.content + '</td> </tr> <tr> <td>Último seguimiento<br><br>' + seguimiento + '</td> </tr> </table> </table></br>'
        }
      }
      if (enPlazo && enPlazo.length) {
        totalG += enPlazo.length
        html += '<h3><strong>Acuerdos En Plazo</strong></h3></br>'
        for (const a in enPlazo) {
          const attached = enPlazo[a]
          let responsibleName = ''
          let seguimiento = ''
          const posNoteIssueDate = attached.note.dates.findIndex((x) => {
            return x.type === 'issue'
          })
          const noteIssueDate = dateformat(attached.note.dates[posNoteIssueDate].value, 'dd/mm/yyyy')
          if (attached.responsible && attached.responsible.length) {
            responsibleName = users[attached.responsible.split('&unit=')[0]].name
          }
          if (attached.evidences && attached.evidences.length) {
            seguimiento = attached.evidences[attached.evidences.length - 1].content
          }
          html += '<table style="width:100%" border="1" cellspacing="0" cellpadding="5"> <tr> <th>Sesión</th> <th>Fecha</th> <th>Referencia</th> <th>Funcionario Responsable</th> <th>Estatus del Acuerdo</th> <th>No.</th> </tr> <tr> <td>' + attached.note.sequence.text + '</td> <td>' + noteIssueDate + '</td> <td>' + attached.name + '</td> <td>' + responsibleName + '</td> <td>' + changeStatus(attached.status) + '</td> <td>' + (Number(a) + 1) + '</td> </tr> <table style="width:100%" border="1" cellspacing="0" cellpadding="5"> <tr> <td>' + attached.content + '</td> </tr> <tr> <td>Último seguimiento<br><br>' + seguimiento + '</td> </tr> </table> </table></br>'
        }
      }

      html = html.replace('{{tableGlobal}}', '<table style="width:100%" border="1" cellspacing="0" cellpadding="5">	<tr>  <th>Resumen</th>	</tr> <table style="width:100%" border="1" cellspacing="0" cellpadding="5">  <tr>  <td>Acuerdos Solventados</td><td>' + compromisosSolventados.length + '</td> </tr><tr> <td>Acuerdos Vencidos Con Respuesta</td>  <td>' + vencidosConRes.length + '</td>  </tr>  <tr>  <td>Acuerdos Vencidos Sin Respuesta</td>  <td>' + vencidosSinRes.length + '</td> </tr> <tr> <td>Acuerdos En Plazo</td> <td>' + enPlazo.length + '</td> </tr> <tr> <td><strong>Total de Acuerdos</strong></td> <td><strong>' + totalG + '</strong></td> </tr> </table> </table></br>')
    }
    send(html)
  }
}
