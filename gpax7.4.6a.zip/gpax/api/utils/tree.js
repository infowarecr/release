function Tree () {
  this.hash = (data) => {
    var obj = {}
    for (var i = 0; i < data.length; i++) {
      var pid = data[i].parent || 0
      if (!obj[pid]) obj[pid] = []
      obj[pid].push(data[i])
    }
    return obj
  }
  this.toTree = (data) => {
    return this.tree(this.hash(data), 0)
  }
  this.tree = (hash, level) => {
    var top = hash[level]
    if (top) {
      for (var i = 0; i < top.length; i++) {
        var branch = top[i].id
        if (hash[branch]) { top[i].data = this.tree(hash, branch) }
      }
    }
    return top
  }
}

exports.Tree=Tree