var Common = require('./common').Common
var common = new Common()
var vm = require('vm')

class Script {

  fixImgs (req, mongo, next) {
    if (req.query.collection && req.query.field) {
      var fields = {name: 1}
      fields[req.query.field] = 1
      var keys = {}
      keys[req.query.field]= new RegExp('png;base64')
      mongo.find(req.query.collection, keys, fields, async (err, docs) => {
        if (err) {
          next(err.toString())
        } else {
          next('Se encontraron '+docs.length+' documentos con imágenes en base64.')
          for (let i in docs) {
            var doc = docs[i]
            await new Promise(resolve => {
              mongo.save(req.query.collection, doc, (err) => {
                resolve(err)
              })
            })
          }
        }
      })
    } else {
      next('Debe incluir la "collection" y el "field" como parámetros')
    }
  }
  fixTimes (req, mongo, next) {
    mongo.aggregate('time', [
      { $lookup: { from: 'project', localField: 'project', foreignField: '_id', as: 'prj' } },
      { $unwind: '$prj' },
      { $match: { $expr: { $ne: ['$plan', '$prj.plan'] } } },
      { $group: { _id: '$prj.plan', reports: { $push: '$_id' } } }
    ], {}, (err, docs) => {
      for (let it in docs) {
        mongo.updateAll('time', { _id: { $in: docs[it].reports } }, { $set: { plan: docs[it]._id } }, () => {})
      }
      next(`Se encontraron reportes de tiempo inconsistentes de ${docs.length} planes`)
    })
  }

  oldActivitiesToNew (req, mongo, send) {
    mongo.find('plan', {}, {}, {}, async (err, plans) => {
      if (err) {
        console.log(err)
        send({ mensaje: err })
      } else {
        send({ mensaje: 'corrigiendo ' + plans.length + ' planes' })
        if (plans && plans.length > 0) {
          for (var i in plans) {
            let plan = plans[i]
            if (plan.activities && plan.activities.activities) {
              for (var a in plan.activities.activities) {
                let activity = plan.activities.activities[a]
                let activityId = mongo.newId()
                let objActivity = {
                  _id: activityId,
                  name: activity,
                  plan: plan._id,
                  doc_id: a,
                  description: '',
                  tagActivity: '',
                  template: ''
                }
                await new Promise(resolve => { mongo.save('activity', objActivity, ()=>{ resolve() })})
                if (plan.activities.data && plan.activities.data.length) {
                  for (var d in plan.activities.data) {
                    let data = plan.activities.data[d]
                    if (data.activity.toString() === a.toString()) {
                      let objActivityUser = {
                        _id: {
                          plan: plan._id,
                          activity: activityId,
                          user: data.user
                        },
                        planned: data.value ? parseFloat(data.value) * 60 : 0
                      }
                      await new Promise(resolve => { mongo.save('activityUser', objActivityUser, ()=>{ resolve() })})
                    }
                  }
                }
              }
            }
          }
          console.log('termino')
        }
      }
    })
  }

  tasksDurationDaysToHoursProjects (req, mongo, send) {
    mongo.find('project', {}, {}, {}, async function (err, projects) {
      if (err) {
        console.log(err)
        send(err)
      } else {
        send({ mensaje: 'proyectos encontrados: ' + projects.length })
        for (var p in projects) {
          let project = projects[p]
          console.log(Number(p) + 1 + 'de' + projects.length)
          if (project.content && project.content.data) {
            for (var d in project.content.data) {
              let task = project.content.data[d]
              let exist = await new Promise(resolve => {
                mongo.findId('task', task.id, (err, doc) => {
                  if (doc) {
                    resolve(true)
                  } else {
                    resolve(false)
                  }
                })
              })
              if(!exist) {
                task._id = task.id
                task.project = project._id
                var links = []
                if (task.start_date && task.start_date.length < 10) {
                  let newStart = ''
                  let dat = task.start_date.split('-')
                  if (dat[1].length === 1) {
                    dat[1] = '0' + dat[1]
                  }
                  if (dat[2].length === 1) {
                    dat[2] = '0' + dat[2]
                  }
                  for (let i in dat) {
                    if (i === '0') newStart = newStart + dat[i]
                    else newStart = newStart + '-' + dat[i]
                  }
                  task.start_date = newStart
                }
                if (task.type === 'task' && task.start_date && task.start_date.length === 10) {
                  task.start_date += ' 00:00'
                  if (task.end_date) {
                    task.end_date += ' 00:00'
                  } else {
                    task.end_date = task.start_date
                  }
                  if (!task.owner_id) {
                    task.duration = (task.duration * 8) * 60
                  } else {
                    let user = await new Promise(resolve => {
                      mongo.findId('user', task.owner_id, (err) => {
                        if (err) {
                          console.log(err)
                          resolve()
                        } else {
                          resolve()
                        }
                      })
                    })
                    if (user && user.business && user.business.workday) {
                      task.duration = (task.duration * Number(user.business.workday)) * 60
                    } else {
                      task.duration = (task.duration * 8) * 60
                    }
                  }
                }
                if (task.start_date.length === 10) {
                  task.start_date += ' 00:00'
                  if (task.end_date) {
                    task.end_date += ' 00:00'
                  } else {
                    task.end_date = task.start_date
                  }
                }
                if (project.content.links && project.content.links.length > 0) {
                  project.content.links.forEach(l => {
                    if (l.source.toString() === task.id.toString()) {
                      links.push(l)
                    }
                  })
                }
                task.links = links
                if (project.content.calendars && project.content.calendars.length > 0) {
                  project.content.calendars.forEach(c => {
                    if (c.id.includes(task.id.toString())) {
                      task.calendar = c
                    }
                  })
                }
                await new Promise(resolve => {
                  mongo.save('task', task, () => {
                    resolve()
                  })
                })
              }
            }
          }
        }
      }
    })
  }

  tasksDurationDaysToHoursTemplates (req, mongo, send) {
    mongo.find('template', { type: 'project', newVersion: { $exists: 0 } }, {}, {}, async function (err, templates) {
      if (err) {
        console.log(err)
        send(err)
      } else {
        send({ mensaje: 'modelos encontrados: ' + templates.length })
        for (var p in templates) {
          let template = templates[p]
          console.log(Number(p) + 1 + 'de' + templates.length)
          if (template.template && template.template.data) {
            for (var d in template.template.data) {
              let task = template.template.data[d]
              if (task.start_date.length === 10) {
                task.start_date += ' 00:00'
                task.end_date += ' 00:00'
                task.duration = (task.duration * 8) * 60
              }
              template.newVersion = true
              await new Promise(resolve => {
                mongo.save('template', template, () => {
                  resolve()
                })
              })
            }
          }
        }
      }
    })
  }

  async correctHtmlNameProject (req, mongo, send) {
    var { fromString } = require('html-to-text');
    send({ mensaje: 'script en curso' })
    let projects = await new Promise(resolve => {
      mongo.find('project', {}, {}, (err, result) => {
        if (err) {
          resolve([])
        } else {
          resolve(result)
        }
      })
    })
    for (let i in projects) {
      let project = projects[i]
      if (project.name) {
        project.name = fromString(project.name)
        project.name = project.name.replace(/\n/g, ' ')
        await new Promise(resolve => { mongo.save('project', project, ()=>{resolve()}) })
      }
    }
    let plans = await new Promise(resolve => {
      mongo.find('plan', {}, {}, (err, result) => {
        if (err) {
          resolve([])
        } else {
          resolve(result)
        }
      })
    })
    for (let p in plans) {
      let plan = plans[p]
      if (plan.name) {
        plan.name = fromString(plan.name)
        plan.name = plan.name.replace(/\n/g, ' ')
        await new Promise(resolve => { mongo.save('plan', plan, ()=>{resolve()}) })
      }
    }
    let strategies = await new Promise(resolve => {
      mongo.find('strategy', {}, {}, (err, result) => {
        if (err) {
          resolve([])
        } else {
          resolve(result)
        }
      })
    })
    for (let s in strategies) {
      let strategy = strategies[s]
      if (strategy.name) {
        strategy.name = fromString(strategy.name)
        strategy.name = strategy.name.replace(/\n/g, ' ')
        await new Promise(resolve => { mongo.save('strategy', strategy, ()=>{resolve()}) })
      }
    }
    console.log('Terminó correctHtmlNameProject')
  }

  // Reindexa todas las colleciones de la base de datos
  async reindex (req, mongo, send) {
    mongo.createIndexes('alarm', [
      { key: { 'actors.user': 1 }, name: 'users' },
      { key: { 'document.id': 1 }, name: 'docs' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('assessment', [
      { key: { process: 1 }, name: 'processes' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('attached', [
      { key: { 'actors.user': 1 }, name: 'users' },
      { key: { 'actors.unit': 1 }, name: 'units' },
      { key: { reference: 1 }, name: 'notes' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('auditable', [
      { key: { unit: 1 }, name: 'department' },
      { key: { units: 1 }, name: 'units' },
      { key: { project: 1 }, name: 'project' },
      { key: { plans: 1 }, name: 'plans' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('auditableAssessment', [
      { key: { auditables: 1 }, name: 'auditables' },
      { key: { assessment: 1 }, name: 'assessment' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('bpi', [
      { key: { bpd: 1 }, name: 'bpd' },
      { key: { key: 1 }, name: 'entryPoit' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('comment', [
      { key: { document: 1 }, name: 'document' },
      { key: { involved: 1 }, name: 'involveds' },
      { key: { mentions: 1 }, name: 'mentions' },
      { key: { unread: 1 }, name: 'unread' },
      { key: { user: 1 }, name: 'user' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('commitment', [
      { key: { 'actors.user': 1 }, name: 'users' },
      { key: { 'actors.unit': 1 }, name: 'units' },
      { key: { reference: 1 }, name: 'notes' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('condition', [
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('controlAssessment', [
      { key: { user: 1 }, name: 'users' },
      { key: { process: 1 }, name: 'process' },
      { key: { assessment: 1 }, name: 'assessment' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('document', [
      { key: { 'actors.user': 1 }, name: 'users' },
      { key: { 'actors.unit': 1 }, name: 'units' },
      { key: { project: 1 }, name: 'project' },
      { key: { task: 1 }, name: 'task' },
      { key: { template: 1 }, name: 'template' },
      { key: { tags: 1 }, name: 'tags' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('evidence', [
      { key: { 'actors.user': 1 }, name: 'users' },
      { key: { 'actors.unit': 1 }, name: 'units' },
      { key: { reference: 1 }, name: 'commitments' },
      { key: { template: 1 }, name: 'template' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('factor', [
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('form', [
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('message', [
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('note', [
      { key: { 'actors.user': 1 }, name: 'users' },
      { key: { 'actors.unit': 1 }, name: 'units' },
      { key: { reference: 1 }, name: 'notes' },
      { key: { project: 1 }, name: 'project' },
      { key: { task: 1 }, name: 'task' },
      { key: { template: 1 }, name: 'template' },
      { key: { tags: 1 }, name: 'tags' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('notification', [
      { key: { 'actors.user': 1 }, name: 'users' },
      { key: { 'document.id': 1 }, name: 'docs' },
      { key: { user: 1 }, name: 'user' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('params', [
      { key: { name: 1 }, name: 'tag' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('plan', [
      { key: { 'goals.projects': 1 }, name: 'projects' },
      { key: { 'goals.objective': 1 }, name: 'objetive' },
      { key: { 'budget.name': 1 }, name: 'budget' },
      { key: { strategy: 1 }, name: 'strategy' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('process', [
      { key: { 'risks.selected': 1 }, name: 'risks' },
      { key: { assessment: 1 }, name: 'assessment' },
      { key: { parent: 1 }, name: 'parents' },
      { key: { units: 1 }, name: 'units' },
      { key: { processTag: 1 }, name: 'tags' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('processAssessment', [
      { key: { user: 1 }, name: 'user' },
      { key: { process: 1 }, name: 'process' },
      { key: { assessment: 1 }, name: 'assessment' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('project', [
      { key: { 'actors.user': 1, 'actors.type': 1 }, name: 'users' },
      { key: { unit: 1 }, name: 'deparment' },
      { key: { units: 1 }, name: 'units' },
      { key: { plan: 1 }, name: 'plan' },
      { key: { auditable: 1 }, name: 'auditable' },
      { key: { 'content.data.id': 1 }, name: 'tasks' },
      { key: { processes: 1 }, name: 'processes' },
      { key: { tag: 1 }, name: 'tags' },
      { key: { risk: 1 }, name: 'risk' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('report', [
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('repository', [
      { key: { category: 1 }, name: 'category' },
      { key: { source: 1 }, name: 'source' },
      { key: { type: 1 }, name: 'type' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('risk', [
      { key: { parent: 1 }, name: 'parents' },
      { key: { type: 1 }, name: 'types' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('riskEvent', [
      { key: { process: 1 }, name: 'process' },
      { key: { riskFactor: 1 }, name: 'riskFactor' },
      { key: { unit: 1 }, name: 'units' },
      { key: { user: 1 }, name: 'user' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('rule', [
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('sequence', [
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('server', [
      { key: { name: 1 }, name: 'names' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('signal', [
      { key: { name: 1 }, name: 'names' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('strategy', [
      { key: { 'objectives.id': 1 }, name: 'objectives' },
      { key: { plans: 1 }, name: 'plans' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('template', [
      { key: { units: 1 }, name: 'units' },
      { key: { type: 1 }, name: 'types' },
      { key: { tags: 1 }, name: 'tags' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('time', [
      { key: { user: 1 }, name: 'users' },
      { key: { type: 1 }, name: 'types' },
      { key: { plan: 1 }, name: 'plans' },
      { key: { project: 1 }, name: 'project' },
      { key: { task: 1 }, name: 'task' },
      { key: { activity: 1 }, name: 'activity' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('token', [
      { key: { company: 1 }, name: 'company' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('trash', [
      { key: { user: 1 }, name: 'users' },
      { key: { type: 1 }, name: 'types' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('unit', [
      { key: { 'actors.user': 1, 'actors.type': 1 }, name: 'users' },
      { key: { code: 1 }, name: 'codes' },
      { key: { 'sequences._id': 1 }, name: 'sequences' },
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.createIndexes('unitAssessment', [
      { key: { '$**': 'text' }, name: 'text' }
    ])
    mongo.updateAll('user', {}, [{ $set: { lang: '$language' } }], () => {
      mongo.updateAll('user', {}, { $unset: { language: 1 } }, () => {
        mongo.createIndexes('user', [
          { key: { units: 1 }, name: 'units' },
          { key: { '$**': 'text' }, name: 'text' }
        ])
      })
    })
    send({ message: 'Reindexing...' })
  }

  // Run script on mongodb
  async run (req, mongo, next) {
    var collection = req.query.collection
    var params = { keys: {}, script: '', project: '' }
    try {
      const context = vm.createContext(params)
      if (req.query.script) {
        const runnable = new vm.Script('script=' + req.query.script)
        runnable.runInContext(context)
        params.script = JSON.parse(JSON.stringify(params.script))
      }
      if (req.query.keys) {
        const runnable = new vm.Script('keys=' + req.query.keys)
        runnable.runInContext(context)
        params.keys = JSON.parse(JSON.stringify(params.keys))
      }
      if (req.query.project) {
        const runnable = new vm.Script('project=' + req.query.project)
        runnable.runInContext(context)
        params.keys = JSON.parse(JSON.stringify(params.keys))
      }
      if (collection && params.keys) {
        params = mongo.switchIds(params)
        if (params.script) {
          mongo.updateAll(collection, params.keys, params.script, (err, result) => {
            if (err) next({ error: err })
            else next(result)
          })
        } else if (params.project) {
          mongo.aggregate(collection, [{ $match: params.keys }, { $project: params.project }], {}, (err, result) => {
            if (err) next({ error: err })
            else next(result)
          })
        } else {
          mongo.find(collection, params.keys, params.project, (err, docs) => {
            if (err) next({ error: err })
            else next(docs)
          })
        }
      } else {
        next({ error: 'Faltan parámetros' })
      }
    } catch (err) {
      next({ error: err.message })
    }
  }

  // Run shell commands in server
  async cmd (req, mongo, next) {
    var sh = req.query.sh
    try {
      sh = sh.join ? sh.join(' && ') : sh
      const { exec } = require('child_process')
      exec(sh, (err, stdout, stderr) => {
        if (err) {
          next({ error: err.toString(), out: stdout, errors: stderr })
        } else {
          next(stdout)
        }
      })
    } catch (err) {
      next({ error: err })
    }
  }


  // agregar AnalisisRespuestaAnexo a compromisos
  async analysisToCommitments (req, mongo, send) {
    var commitments = await common.findMongo('commitment', {}, {}, {})
    if (!commitments) {
      console.log('Not notes found')
      send({ mensaje: 'Not commitments found' })
    } else {
      send({ mensaje: 'commitments encontrados: ' + commitments.length })
      for (var i in commitments) {
        const commitment = commitments[i]
        const commitmentMigration = await common.findOne('migration', { _id: commitment._id }, {})
        const Analisis = await common.children(commitmentMigration.id, 'AnalisisRespuestaAnexo')
        for (const a in Analisis) {
          var id = Analisis[a]['@unid']
          var lotus = await common.document(id, 'Anexo')
          var bitacora = lotus.Bitacora.replace(/,/g, '<br>')
          var user = await common.getUser(lotus.Autor)
          user = user._id
          var span = lotus.Calificacion === '1'
            ? '<span class=\'spanTags accepted\'>Aceptado</span>'
            : lotus.Calificacion === '2'
              ? '<span class=\'spanTags canceled\'>Cancelado</span>'
              : ''
          var Desc = lotus.Descripcion && lotus.Descripcion !== '' ? await common.field(id, 'Descripcion') : ''
          var text = span + '<br>' +
            bitacora + '<br>' +
            'FechaAprobada: ' + lotus.FechaAprobada + '<br>' +
            'Nombre: ' + lotus.Nombre + '<br>' +
            'FechaCompromiso: ' + lotus.FechaCompromiso + '<br>' +
            'FechaSolicitada: ' + lotus.FechaSolicitada + '<br>' +
            'Descripcion: ' + Desc
          var comment = {
            _id: mongo.newId(),
            collection: 'commitment',
            document: commitment._id,
            comment: text,
            dateTime: new Date(lotus.FechaCalificacion),
            involved: [],
            mentions: [],
            migrated: 1,
            unread: [],
            user: user
          }
          await new Promise(resolve => {
            mongo.save('comment', comment, (err) => {
              if (err) console.log(err)
              resolve()
            })
          })
        }
      }
    }
  }
  // Genera el resumer de facturas del mes
  async invoiceDay (req, mongo, send) {
    var agents = []
    var agentsName = []
    await new Promise(resolve => {
      mongo.find('params', { name: 'agent' }, { _id: 1, name: 1, options: 1 }, (err, tagsDoc) => {
        if (!err) {
          for (const i in tagsDoc[0].options) {
            agents.push(tagsDoc[0].options[i].id)
            agentsName.push(tagsDoc[0].options[i].value)
          }
          resolve()
        } else throw err
        send()
      })
    })
    var typesDoc = ['Factura Electrónica', 'Nota Débito', 'Nota Crédito', 'Tiquete Electrónico', 'Compras aceptadas', 'Compras rechazadas', 'Compras aceptadas parcialemnte', 'Factura Electrócia de Compra', 'Factura Electrónica de Exportación']
    var codesDoc = ['01', '02', '03', '04', '05', '06', '07', '08', '09']
    var today = new Date().getTime()
    var nextDate
    var initialDate = await new Promise(resolve => {
      mongo.findN('invoiceDay', 0, 1, { '_id.tipo': { $in: ['01', '04', '08', '09'] } }, {}, { _id: -1 }, (err, doc) => {
        if (err || !doc.length) resolve(new Date(2019, 3, 28))
        else resolve(doc[0]._id.fecha)
      })
    })
    while (initialDate.getTime() < today) {
      initialDate.setDate(initialDate.getDate() + 1)
      nextDate = new Date(initialDate.getTime())
      nextDate.setDate(nextDate.getDate() + 1)
      await new Promise(resolve => {
        mongo.aggregate('invoice', [
          { $match: { _id: { $gte: mongo.newId(initialDate), $lt: mongo.newId(nextDate) } } },
          {
            $group: {
              _id: {
                fecha: {
                  $dateFromParts: {
                    year: { $year: { date: '$_id', timezone: '-06' } },
                    month: { $month: { date: '$_id', timezone: '-06' } },
                    day: { $dayOfMonth: { date: '$_id', timezone: '-06' } },
                    timezone: '-06'
                  }
                },
                compañia: '$company', tipo: '$tipoDocumento', estado: '$statusHacienda',
              },
              count: { $sum: 1 }
            }
          },
          { $lookup: { from: 'company', localField: '_id.compañia', foreignField: 'idNum', as: 'co' } },
          { $unwind: '$co' },
          {
            $project: {
              _id: 1,
              compañia: '$co.name',
              tipo: { $arrayElemAt: [typesDoc, { $indexOfArray: [codesDoc, '$_id.tipo'] }] },
              agente: { $arrayElemAt: [agentsName, { $indexOfArray: [agents, '$co.agent'] }] },
              contador: '$count'
            }
          }], {}, async (err, invoices) => {
          if (err) resolve(err)
          else {
            var cont = 0
            invoices.forEach((r) => { cont += r.contador })
            console.log('fecha ' + new Date(initialDate).toISOString())
            console.log('Procesando ' + cont)
            if (invoices.length) {
              await new Promise(resolve => {
                mongo.insertMany('invoiceDay', invoices, (err) => {
                  if (err) console.log(err)
                  resolve()
                })
              })
            }
            resolve()
          }
        })
      })
    }
    console.log('Proceso finalizado')
  }
  // Genera el resumen de facturas recibidas del mes
  async invoice2Day (req, mongo, send) {
    var agents = []
    var agentsName = []
    await new Promise(resolve => {
      mongo.find('params', { name: 'agent' }, { _id: 1, name: 1, options: 1 }, (err, tagsDoc) => {
        if (!err) {
          for (const i in tagsDoc[0].options) {
            agents.push(tagsDoc[0].options[i].id)
            agentsName.push(tagsDoc[0].options[i].value)
          }
          resolve()
        } else throw err
        send()
      })
    })
    var typesDoc = ['Factura Electrónica', 'Nota Débito', 'Nota Crédito', 'Tiquete Electrónico', 'Compras aceptadas', 'Compras rechazadas', 'Compras aceptadas parcialemnte', 'Factura Electrócia de Compra', 'Factura Electrónica de Exportación']
    var codesDoc = ['01', '02', '03', '04', '05', '06', '07', '08', '09']
    var today = new Date().getTime()
    var nextDate
    var initialDate = await new Promise(resolve => {
      mongo.findN('invoiceDay', 0, 1, { '_id.tipo': { $in: ['05', '07'] } }, {}, { '_id.fecha': -1 }, (err, doc) => {
        if (err || !doc.length) resolve(new Date(2019, 3, 28))
        else resolve(doc[0]._id.fecha)
      })
    })
    while (initialDate < today) {
      nextDate = new Date(initialDate.getTime())
      nextDate.setDate(nextDate.getDate() + 1)
      await new Promise(resolve => {
        mongo.aggregate('invoice2pay', [
          { $match: { _id: { $gte: mongo.newId(initialDate), $lt: mongo.newId(nextDate) } } },
          {
            $group: {
              _id: {
                fecha: {
                  $dateFromParts: {
                    year: { $year: { date: '$_id', timezone: '-06' } },
                    month: { $month: { date: '$_id', timezone: '-06' } },
                    day: { $dayOfMonth: { date: '$_id', timezone: '-06' } },
                    timezone: '-06'
                  }
                },
                compañia: '$company', tipo: '$tipoDocumento', estado: '$statusHacienda',
              },
              count: { $sum: 1 }
            }
          },
          { $lookup: { from: 'company', localField: '_id.compañia', foreignField: 'idNum', as: 'co' } },
          { $unwind: '$co' },
          {
            $project: {
              _id: 1,
              compañia: '$co.name',
              tipo: { $arrayElemAt: [typesDoc, { $indexOfArray: [codesDoc, '$_id.tipo'] }] },
              agente: { $arrayElemAt: [agentsName, { $indexOfArray: [agents, '$co.agent'] }] },
              contador: '$count'
            }
          }], {}, async (err, invoices) => {
          if (err) resolve(err)
          else {
            console.log('fecha ' + new Date(initialDate).toISOString())
            console.log('Procesando ' + invoices.length)
            if (invoices.length) {
              await new Promise(resolve => {
                mongo.insertMany('invoiceDay', invoices, (err) => {
                  if (err) console.log(err)
                  resolve()
                })
              })
            }
            resolve()
          }
        })
      })
      initialDate = new Date(nextDate.getTime())
    }
    console.log('Proceso finalizado')
  }
  // Genera el resumen de notas de credito del mes
  async invoiceNCDay (req, mongo, send) {
    var agents = []
    var agentsName = []
    await new Promise(resolve => {
      mongo.find('params', { name: 'agent' }, { _id: 1, name: 1, options: 1 }, (err, tagsDoc) => {
        if (!err) {
          for (const i in tagsDoc[0].options) {
            agents.push(tagsDoc[0].options[i].id)
            agentsName.push(tagsDoc[0].options[i].value)
          }
          resolve()
        } else throw err
        send()
      })
    })
    var typesDoc = ['Factura Electrónica', 'Nota Débito', 'Nota Crédito', 'Tiquete Electrónico', 'Compras aceptadas', 'Compras rechazadas', 'Compras aceptadas parcialemnte', 'Factura Electrócia de Compra', 'Factura Electrónica de Exportación']
    var codesDoc = ['01', '02', '03', '04', '05', '06', '07', '08', '09']
    var today = new Date().getTime()
    var nextDate
    var initialDate = await new Promise(resolve => {
      mongo.findN('invoiceDay', 0, 1, { '_id.tipo': { $in: ['02', '03'] } }, {}, { _id: -1 }, (err, doc) => {
        if (err || !doc.length) resolve(new Date(2019, 3, 28))
        else resolve(doc[0]._id.fecha)
      })
    })
    while (initialDate < today) {
      nextDate = new Date(initialDate.getTime())
      nextDate.setDate(nextDate.getDate() + 1)
      await new Promise(resolve => {
        mongo.aggregate('invoiceCredit', [
          { $match: { _id: { $gte: mongo.newId(initialDate), $lt: mongo.newId(nextDate) } } },
          {
            $group: {
              _id: {
                fecha: {
                  $dateFromParts: {
                    year: { $year: { date: '$_id', timezone: '-06' } },
                    month: { $month: { date: '$_id', timezone: '-06' } },
                    day: { $dayOfMonth: { date: '$_id', timezone: '-06' } },
                    timezone: '-06'
                  }
                },
                compañia: '$company', tipo: '$tipoDocumento', estado: '$statusHacienda',
              },
              count: { $sum: 1 }
            }
          },
          { $lookup: { from: 'company', localField: '_id.compañia', foreignField: 'idNum', as: 'co' } },
          { $unwind: '$co' },
          {
            $project: {
              _id: 1,
              compañia: '$co.name',
              tipo: { $arrayElemAt: [typesDoc, { $indexOfArray: [codesDoc, '$_id.tipo'] }] },
              agente: { $arrayElemAt: [agentsName, { $indexOfArray: [agents, '$co.agent'] }] },
              contador: '$count'
            }
          }], {}, async (err, invoices) => {
          if (err) resolve(err)
          else {
            console.log('fecha ' + new Date(initialDate).toISOString())
            console.log('Procesando ' + invoices.length)
            if (invoices.length) {
              await new Promise(resolve => {
                mongo.insertMany('invoiceDay', invoices, (err) => {
                  if (err) console.log(err)
                  resolve()
                })
              })
            }
            resolve()
          }
        })
      })
      initialDate = new Date(nextDate.getTime())
    }
    console.log('Proceso finalizado')
  }

  async taskNumberIdToMongoIdCreateTable (req, mongo, send) {
    mongo.aggregate('task', [
      {
        $match: {
          $or: [
            {'_id': {$type: 2}},
            { '_id': { $type: 1 } },],
          configColumnsDocuments: {$exists: 0}
        }
      }
    ], {}, async (err, tasks) => {
      if (err) {
        send({message: 'error ' + err})
      } else {
        for (let i in tasks) {
          let continuar = await new Promise(resolve => {
            mongo.find('taskMigrated', { oldId: tasks[i]._id, project: tasks[i].project }, {}, (err, tks) => {
              if (err) {
                console.log(err)
                resolve(false)
              } else {
                if (tks && tks.length) {
                  resolve(false)
                } else {
                  resolve(true)
                }
              }
            })
          })
          if (continuar) {
            let obj = {}
            obj._id = mongo.newId()
            obj.oldId = tasks[i]._id
            obj.project = tasks[i].project
            await new Promise(resolve => {
              mongo.save('taskMigrated', obj, (err) => {
                if (err) console.log(err)
                resolve()
              })
            })
          }
        }
        console.log('Total ' + tasks.length)
        send({ message: 'Termino taskNumberIdToMongoIdCreateTable' })
      }
    })
  }

  async taskNumberIdToMongoIdMigrated (req, mongo, send) {
    mongo.find('taskMigrated', {}, {}, async (err, table) => {
      if (err) {
        send({message: 'error ' + err})
      } else {
        if (table.length) {
          for (let i in table) {
            console.log('tabla ' + Number(i))
            let doc = table[i]
            //tareas
            await new Promise(resolve => {
              console.log('recorriendo tareas')
              mongo.find('task', { _id: doc.oldId, project: doc.project }, {}, async (err, tasks) => {
                if (err) {
                  console.log(err)
                  resolve()
                } else {
                  if (tasks.length) {
                    for (let t in tasks) {
                      console.log(Number(t))
                      let task = tasks[t]
                      task._id = doc._id
                      task.id = doc._id
                      await new Promise(resolve => {
                        mongo.save('task', task, (err) => {
                          if (err) console.log(err)
                          resolve()
                        })
                      })
                      await new Promise(resolve => {
                        mongo.deleteOne('task', { _id: doc.oldId, project: doc.project }, (err) => {
                          if (err) console.log(err)
                          resolve()
                        })
                      })
                    }
                  }
                  resolve()
                }
              })
            })
          }
          for (let i in table) {
            console.log('tabla ' + Number(i))
            let doc = table[i]
            //parent tareas*/
            await new Promise(resolve => {
              console.log('recorriendo tareas parent')
              mongo.find('task', { parent: doc.oldId, project: doc.project }, {}, async (err, tasks) => {
                if (err) {
                  console.log(err)
                  resolve()
                } else {
                  if (tasks.length) {
                    for (let t in tasks) {
                      console.log(Number(t))
                      let task = tasks[t]
                      task.parent = doc._id
                      await new Promise(resolve => {
                        mongo.save('task', task, (err) => {
                          if (err) console.log(err)
                          resolve()
                        })
                      })
                    }
                  }
                  resolve()
                }
              })
            })
            //tiempos
            await new Promise(resolve => {
              console.log('recorriendo tiempos')
              mongo.find('time', { $or: [{document: doc.oldId.toString() },{document: doc.oldId}], project: doc.project }, {}, async (err, times) => {
                if (err) {
                  console.log(err)
                  resolve()
                } else {
                  if (times.length) {
                    for (let t in times) {
                      console.log(Number(t))
                      let time = times[t]
                      time.document = doc._id
                      await new Promise(resolve => {
                        mongo.save('time', time, (err) => {
                          if (err) console.log(err)
                          resolve()
                        })
                      })
                    }
                  }
                  resolve()
                }
              })
            })
            //notas
            await new Promise(resolve => {
              console.log('recorriendo notas')
              mongo.find('note', { $or: [{task: doc.oldId.toString() },{task: doc.oldId}], project: doc.project }, {}, async (err, notes) => {
                if (err) {
                  console.log(err)
                  resolve()
                } else {
                  if (notes.length) {
                    for (let t in notes) {
                      console.log(Number(t))
                      let note = notes[t]
                      note.task = doc._id
                      await new Promise(resolve => {
                        mongo.save('note', note, (err) => {
                          if (err) console.log(err)
                          resolve()
                        })
                      })
                    }
                  }
                  resolve()
                }
              })
            })
            //documentos
            await new Promise(resolve => {
              console.log('recorriendo documentos')
              mongo.find('document', { $or: [{task: doc.oldId.toString() },{task: doc.oldId}], project: doc.project }, {}, async (err, documents) => {
                if (err) {
                  console.log(err)
                  resolve()
                } else {
                  if (documents.length) {
                    for (let t in documents) {
                      console.log(Number(t))
                      let document = documents[t]
                      document.task = doc._id
                      await new Promise(resolve => {
                        mongo.save('document', document, (err) => {
                          if (err) console.log(err)
                          resolve()
                        })
                      })
                    }
                  }
                  resolve()
                }
              })
            })
            //comentarios
            await new Promise(resolve => {
              console.log('recorriendo comentarios')
              mongo.find('comment', { $or: [{document: doc.oldId.toString() },{document: doc.oldId}], project: doc.project }, {}, async (err, comments) => {
                if (err) {
                  console.log(err)
                  resolve()
                } else {
                  if (comments.length) {
                    for (let t in comments) {
                      console.log(Number(t))
                      let comment = comments[t]
                      comment.document = doc._id
                      await new Promise(resolve => {
                        mongo.save('comment', comment, (err) => {
                          if (err) console.log(err)
                          resolve()
                        })
                      })
                    }
                  }
                  resolve()
                }
              })
            })
            //eventos tareas
            await new Promise(resolve => {
              console.log('recorriendo eventos de tareas')
              mongo.find('eventTask', { $or: [{docId: doc.oldId.toString() },{docId: doc.oldId}], project: doc.project }, {}, async (err, eventTasks) => {
                if (err) {
                  console.log(err)
                  resolve()
                } else {
                  if (eventTasks.length) {
                    for (let t in eventTasks) {
                      console.log(Number(t))
                      let eventTask = eventTasks[t]
                      eventTask.docId = doc._id
                      await new Promise(resolve => {
                        mongo.save('eventTask', eventTask, (err) => {
                          if (err) console.log(err)
                          resolve()
                        })
                      })
                    }
                  }
                  resolve()
                }
              })
            })
            //versiones
            await new Promise(resolve => {
              console.log('recorriendo versiones')
              mongo.find('version', { $or: [{'data._id': doc.oldId.toString() },{'data._id': doc.oldId}], 'data.project': doc.project, type: 'task' }, {}, async (err, versions) => {
                if (err) {
                  console.log(err)
                  resolve()
                } else {
                  if (versions.length) {
                    for (let t in versions) {
                      console.log(Number(t))
                      let version = versions[t]
                      if (version.data._id) version.data._id = doc._id
                      await new Promise(resolve => {
                        mongo.save('version', version, (err) => {
                          if (err) console.log(err)
                          resolve()
                        })
                      })
                    }
                  }
                  resolve()
                }
              })
            })

            // logs trace.ref
            await new Promise(resolve => {
              var logs = req.app.getMongo(req.app.params.log)
              console.log('recorriendo log')
              logs.find('trace', { $or: [{ref: doc.oldId.toString() },{ref: doc.oldId}] }, {}, async (err, traces) => {
                if (err) {
                  console.log(err)
                  resolve()
                } else {
                  if (traces.length) {
                    for (let t in traces) {
                      console.log(Number(t))
                      let trace = traces[t]
                      trace.ref = doc._id
                      await new Promise(resolve => {
                        logs.save('trace', trace, (err) => {
                          if (err) console.log(err)
                          resolve()
                        })
                      })
                    }
                  }
                  resolve()
                }
              })
            })

          }
          for (let i in table) {
            console.log('tabla ' + Number(i))
            let doc = table[i]
            // links tareas
            await new Promise(resolve => {
              console.log('recorriendo links tareas')
              mongo.find('task', {
                $and: [
                  { project: doc.project },
                  {
                    $or: [
                      {'links.target': {$type: 2}},
                      {'links.target': {$type: 1}},
                      {'links.source': {$type: 2}},
                      {'links.source': {$type: 1}},
                    ]
                  }
                ]}, {}, async (err, tasks) => {
                if (err) {
                  console.log(err)
                  resolve()
                } else {
                  if (tasks.length) {
                    for (let t in tasks) {
                      console.log(Number(t))
                      let task = tasks[t]
                      if (task.links && task.links.length) {
                        for (var o in task.links) {
                          var link = task.links[o]
                          if (link.source) {
                            let index = table.findIndex(x => {
                              return x.oldId.toString() === link.source.toString()
                            })
                            if (index !== -1) {
                              link.source = table[index]._id
                            }
                          }
                          if (link.target) {
                            let index = table.findIndex(x => {
                              return x.oldId.toString() === link.target.toString()
                            })
                            if (index !== -1) {
                              link.target = table[index]._id
                            }
                          }
                        }
                      }
                      await new Promise(resolve => {
                        mongo.save('task', task, (err) => {
                          if (err) console.log(err)
                          resolve()
                        })
                      })
                    }
                  }
                  resolve()
                }
              })
            })
          }
        }
        send({ message: 'Termino taskNumberIdToMongoIdMigrated' })
      }
    })
  }

}

exports.Script = Script
