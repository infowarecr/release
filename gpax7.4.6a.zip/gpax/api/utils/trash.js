var Notification = require('../utils/notification').Notification
var notification = new Notification()

exports.Trash = Trash

function Trash () {
  this.insert = function (req, mongo, collection, doc, next) {
    if (doc) {
      var id = mongo.newId()
      var user = req.session.context.user
      var timestamp = id.getTimestamp()
      doc = {
        _id: id,
        user: user,
        type: collection,
        document: doc,
        timestamp: timestamp
      }
      mongo.save('trash', doc, (err, result) => {
        if (err) {
          next({ error: err })
        } else {
          next()
        }
      })
    } else {
      next()
    }
  }

  this.list = function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    var keys = { user: req.session.context.user, document: { $ne: null }, 'document.hidden': { $exists: 0 } }
    if (req.session.context.adminTrash) { keys = { document: { $ne: null }, 'document.hidden': { $exists: 0 } } }
    mongo.toHash('project', {}, { name: 1 }, {}, (err, projects) => {
      if (err) throw err
      mongo.toHash('user', {}, {}, {}, (err, users) => {
        if (err) {
          send({ error: err })
        } else {
          mongo.findN('trash', skip, limit, keys, {}, { _id: -1 }, (err, trashs) => {
            if (!err && trashs) {
              for (let i in trashs) {
                trashs[i].document=trashs[i].document[0] || trashs[i].document
                trashs[i].id = trashs[i]._id
                /** if */
                if (users[trashs[i].user]) {
                  trashs[i].userName = users[trashs[i].user].name
                } else {
                  trashs[i].userName = 'No existe'
                }
                /** fin */
                /** if */
                if (trashs[i].document.text) {
                  trashs[i].name = trashs[i].document.text
                } else if (trashs[i].document.activity) {
                  trashs[i].name = trashs[i].document.activity
                } else {
                  trashs[i].name = trashs[i].document.name
                }
                /** fin */
                /** if */
                if (trashs[i].document.project && projects[trashs[i].document.project.toString()]) {
                  trashs[i].projectName = projects[trashs[i].document.project.toString()].name
                } else {
                  trashs[i].projectName = ''
                }
                /** fin */
                trashs[i].status = trashs[i].document.status
                // trashs[i].timestamp = tags.util.date2str(trashs[i].timestamp, 'yyyy-mm-dd', tags);
                reply.data.push(trashs[i])
              }
              if (skip) {
                send(reply)
              } else {
                mongo.count('trash', keys, (err, count) => {
                  if (!err && count) {
                    reply.total_count = count
                  }
                  send(reply)
                })
              }
            } else {
              reply.total_count = 0
              send(reply)
            }
          })
        }
      })
    })
  }

  this.recover = function (req, mongo, send) {
    var id = req.query._id
    var msj = 'restoreError'
    mongo.findId('trash', mongo.toId(id), async (err, doc) => {
      if (err) {
        send({ error: err })
      } else if (doc) {
        var ok = true
        if (doc.type === 'project') {
          ok = await new Promise(resolve => {
            if (doc.document.plan) {
              mongo.findId('plan', doc.document.plan, (err, plan) => {
                if (err || !plan) {
                  resolve(false)
                } else {
                  for (var g in plan.goals) {
                    if (plan.goals[g].id.toString() === doc.document.idGoal.toString()) {
                      plan.goals[g].projects.push(doc.document._id)
                      break
                    }
                  }
                  mongo.save('plan', { _id: plan._id, goals: plan.goals }, async (err, result) => {
                    if (err) {
                      resolve(false)
                    } else {
                      let tasks = await new Promise(resolve => {
                        mongo.find('trash', { type: 'task', 'document.project': doc.document._id }, (err, tasks) => {
                          if (err) { resolve([]) } else { resolve(tasks) }
                        })
                      })
                      for (let i in tasks) {
                        let task = tasks[i]
                        delete task.document.hidden
                        await new Promise(resolve => {
                          mongo.save('task', task.document, (err, result) => {
                            if (err) {
                              resolve()
                            } else {
                              mongo.deleteOne('trash', { _id: task._id }, () => {resolve()})
                            }
                          })
                        })
                      }
                      resolve(true)
                    }
                  })
                }
              })
            }
          })
          delete doc.document.id_Goal
        } else if (doc.type === 'strategy') {
          if (doc.document.strategy && doc.type === 'strategy') {
            ok = false
            await new Promise(resolve => {
              mongo.findId('strategy', mongo.toId(doc.document.strategy), (err, strategyDoc) => {
                if (err) {
                  resolve()
                } else {
                  delete doc.document.strategy
                  strategyDoc.objectives.push(doc.document)
                  mongo.save('strategy', { _id: strategyDoc._id, objectives: strategyDoc.objectives }, (err, result) => {
                    if (err) {
                      resolve()
                    } else {
                      mongo.deleteOne('trash', { _id: mongo.toId(id) }, (err, result) => {
                        if (err) {
                          resolve()
                        } else {
                          notification.send(req, req.session.context.room, 'dt_trash', { id: id }, null, true)
                          resolve()
                        }
                      })
                    }
                  })
                }
              })
            })
          }
        } else if (doc.type === 'plan') {
          if (doc.document.plan && doc.type === 'plan') {
            ok = false
            await new Promise(resolve => {
              mongo.findId('plan', mongo.toId(doc.document.plan), (err, planDoc) => {
                if (err) {
                  resolve()
                } else {
                  delete doc.document.plan
                  planDoc.goals.push(doc.document)
                  mongo.save('plan', { _id: planDoc._id, goals: planDoc.goals }, (err, result) => {
                    if (err) {
                      resolve()
                    } else {
                      mongo.deleteOne('trash', { _id: mongo.toId(id) }, (err, result) => {
                        if (err) {
                          resolve()
                        } else {
                          notification.send(req, req.session.context.room, 'dt_trash', { id: id }, null, true)
                          resolve()
                        }
                      })
                    }
                  })
                }
              })
            })
          }
        } else if (doc.document.project && !doc.document.model) {
          ok = await new Promise(resolve => {
            mongo.findId('project', doc.document.project, (err, project) => {
              if (err) {
                console.log(err)
                resolve(false)
              } else {
                if (project && project.status !== 'completed' && project.status !== 'archived') {
                  resolve(true)
                } else {
                  msj = 'locked file'
                  resolve(false)
                }
              }
            })
          })
        }
        if (doc.type === 'task' && doc.document.model) {
          mongo.findId('template', doc.document.model, (err, temp) => {
            if (err) {
              send({ err: msj })
            } else {
              if (!temp) {
                send({ err: 'El modelo de esta tarea no existe' })
              } else if (temp.template && temp.template.data) {
                let exist = false
                for (let i in temp.template.data) {
                  let task = temp.template.data[i]
                  if (task.id.toString() === doc.document.id.toString()) {
                    exist = true
                    break
                  }
                }
                if (exist) {
                  mongo.deleteOne('trash', { _id: mongo.toId(id) }, () => {
                    notification.send(req, req.session.context.room, 'dt_trash', { id: id }, null, true)
                    send({ err: 'Esta tarea ya existe en el modelo' })
                  })
                } else {
                  temp.template.data.push(doc.document)
                  mongo.save('template', temp, () => {
                    mongo.deleteOne('trash', { _id: mongo.toId(id) }, () => {
                      notification.send(req, req.session.context.room, 'dt_trash', { id: id }, null, true)
                      send()
                    })
                  })
                }
              }
            }
          })
        } else if (ok) {
          mongo.save(doc.type, doc.document, (err, result) => {
            if (err) {
              send({ error: err })
            } else {
              mongo.deleteOne('trash', { _id: mongo.toId(id) }, (err, result) => {
                if (err) {
                  send({ error: err })
                } else {
                  notification.send(req, req.session.context.room, 'dt_trash', { id: id }, null, true)
                  send()
                }
              })
            }
          })
        } else {
          send({ err: msj })
        }
      } else {
        send({ err: msj })
      }
    })
  }
}
