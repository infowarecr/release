/*
 * file operations
 */
var fs = require('fs')
var streamifier = require('streamifier')
var mimeTypes = require('mime-types')
var numeral = require('numeral')

/* exported */
exports.File = File

function File () {
  this.save = function (req, mongo, send) {
    mongo.savefile(req, (err, result) => {
      if (!err) {
        send(result)
      } else {
        send()
      }
    })
  }

  this.savePdfSign = function (req, mongo, send) {
    var base64_arraybuffer = require('base64-arraybuffer')
    let pdfSignedBase64 = req.body.fileBase64
    let fileId = req.query._id
    let pdf = base64_arraybuffer.decode(pdfSignedBase64)
    send('done')
  }

  this.getBase64 = function (req, mongo, send) {
    if (!req.query) {
      req.query = {}
      req.query._id = req._id
    }
    mongo.getfileBase64(req.query._id || req.query._Id, (err, result) => {
      if (!err) {
        send(result)
      } else {
        send()
      }
    })
  }

  this.get = function (req, mongo, send) {
    // BH migration problem with (._Id)
    if (req._Id) {
      req._id = req._Id
    }
    if (!req.query) {
      req.query = {}
      req.query._id = req._id
    }
    mongo.getfile(req.query._id || req.query._Id, (err, result, file) => {
      if (!err) {
        var ext = file.filename
        ext = ext.split('.')
        ext = ext[ext.length - 1]
        result.contentType = mimeTypes.contentType(ext)
        result.filename = file.filename
        if (!req.query.froala) {
          result.mongo = mongo
          result.id = req.query._id || req.query._Id
        }
        if (req.query.toSign) {
          let tmp = '/tmp/' + result.filename
          let ftemp = fs.createWriteStream(tmp)
          ftemp.on('finish', async function () {
            var pdfBuffer = fs.readFileSync(tmp)
            send(pdfBuffer)
          })
          result.pipe(ftemp)
        } else {
          send(result)
        }
      } else {
        send()
      }
    })
  }

  this.delete = function (req, mongo, send) {
    mongo.removefile(req.query._id, (err, result) => {
      if (!err) {
        send(result)
      } else {
        send()
      }
    })
  }

  this.list = function (req, mongo, send) {
    if (!req.query) {
      req.query = {}
      req.query._id = req._id
    }
    var pos = req.query._id ? req.query._id.indexOf('?') : -1
    if (pos !== -1) {
      req.query._id = req.query._id.substring(0, pos)
    }
    mongo.files(req, (err, files) => {
      if (!err) {
        var reply = []
        for (const i in files) {
          var file = files[i]
          if (req.query.imgs) {
            if (file.contentType.indexOf('image') !== -1) {
              reply.push({
                thumb: '/file.get?_id=' + file._id.toString(),
                url: '/file.get?_id=' + file._id.toString(),
                title: file.filename.split('/')[1],
                id: file._id.toString()
              })
            }
          } else {
            var data = {
              id: file._id.toString(),
              title: file.filename.split('/')[1],
              name: file.filename.split('/')[1],
              contentType: file.contentType,
              size: numeral(file.length / 1000).format('0,0.00') + ' kb',
              url: 'file.get?_id=' + file._id.toString()
            }
            var ext = file.filename.split('.').pop()
            if (ext === 'pdf') { /* if pdf open witth viewer */
              data.url = '/viewer/#..' + data.url
            } else if (['doc', 'docx', 'xls', 'xlsx', 'ods', 'odt', 'odp', 'ppt', 'xps'].indexOf(ext) !== -1) {
              /* if office or open document open transform to pdf and show with viewer */
              data.url = '/viewer/#..' + data.url + '&format=pdf'
            }
            reply.push(data)
          }
        }
        send(reply)
      } else {
        send(err)
      }
    })
  }
}
