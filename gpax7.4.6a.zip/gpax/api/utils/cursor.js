var dateformat = require('dateformat')
var moment = require('moment')
var Notification = require('../utils/notification').Notification
var notification = new Notification()

class Cursor {

  async dependentUnits (mongo, parent, dependents) {
    let units = await new Promise(resolve => {
      mongo.find('unit', { parent: { $in: parent} }, { _id: 1 }, (err, units) => {
        if (err) resolve(false)
        else {
          resolve(units)
        }
      })
    })
    if (units && units.length > 0) {
      const ids = []
      for (const i in units) {
        ids.push(units[i]._id)
        if (dependents.indexOf(units[i]._id) === -1) {
          dependents.push(units[i]._id)
        }
      }
      await this.dependentUnits(mongo, ids, dependents)
    }
    return dependents
  }
  invoice (req, mongo, send) {
    mongo.aggregate('invoiceDay', [
      // { $match: keys },
      {
        $project: {
          _id: 0,
          estado: '$_id.estado',
          compañia: '$compañia',
          cedula: '$_id.compañia',
          año: { $year: '$_id.fecha' },
          mes: { $month: '$_id.fecha' },
          día: {$dayOfMonth: '$_id.fecha'},
          tipo: 1,
          agente: 1,
          facturas: '$contador'
        }
      }], {}, (err, invoices) => {
      if (err) {
        send({ type: 'error', message: err })
      } else {
        send(invoices)
      }
    })
  }
  invoice2pay (req, mongo, send) {
    this.invoiceCredit(req, mongo, send, 'invoice2pay')
  }
  invoiceCredit (req, mongo, send,collection) {
    collection=collection||'invoiceCredit'
    var agentsName
    var agents
    var from = new Date(req.query.start)
    var to = new Date(req.query.end)
    to.setDate(to.getDate() + 1)
    var keys = {
      _id: { $gte: mongo.newId(from), $lt: mongo.newId(to) }
    }
    mongo.find('params', { name: 'agent' }, { _id: 1, name: 1, options: 1 }, (err, tagsDoc) => {
      if (!err) {
        for (const i in tagsDoc[0].options) {
          agents.push(tagsDoc[0].options[i].id)
          agentsName.push(tagsDoc[0].options[i].value)
        }
      }
      var typesDoc = ['FE', 'ND', 'NC', 'TE', 'Compras', 'Compras', 'Compras', 'FEC', 'FEE']
      var codesDoc = ['01', '02', '03', '04', '05', '06', '07', '08', '09']
      mongo.aggregate(collection, [
        { $match: keys },
        { $group: { _id: { compañia: '$company', tipo: '$tipoDocumento', estado: '$statusHacienda' }, count: { $sum: 1 } } },
        { $lookup: { from: 'company', localField: '_id.compañia', foreignField: 'idNum', as: 'co' } },
        { $unwind: '$co' },
        {
          $project: {
            _id: 0,
            estado: '$_id.estado',
            compañia: '$co.name',
            cedula: '$_id.compañia',
            tipo: { $arrayElemAt: [typesDoc, { $indexOfArray: [codesDoc, '$_id.tipo'] }] },
            agente: { $arrayElemAt: [agentsName, { $indexOfArray: [agents, '$co.agent'] }] },
            facturas: '$count'
          }
        }], {}, (err, invoices) => {
        if (err) {
          send({ type: 'error', message: err })
        } else {
          send(invoices)
        }
      })
    })
  }
  ///for unit
  async projects (req, mongo, send) {
    let initialMatch = {}
    var dependents = []
    if (req.query.plans) {
      let plans = req.query.plans.split(',')
      let plansIds = []
      for (let p in plans) {
        plansIds.push(mongo.toId(plans[p]))
      }
      initialMatch['plan'] = { $in: plansIds }
    }
    if(req.query.dateRange) {
      initialMatch['_id'] = { $gte: mongo.newId(new Date(req.query.dateRange.split(' - ')[0])), $lt: mongo.newId(new Date(req.query.dateRange.split(' - ')[1])) }
    }
    if (req.query.unit) {
      let units = req.query.unit.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      await this.dependentUnits(mongo, units, dependents)
      dependents = dependents.concat(units)
      initialMatch['unit'] = { $in: dependents }
    }
    if (req.query.unitsFilter) {
      let units = req.query.unitsFilter.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      initialMatch['units'] = { $in: units }
    }
    var pipeline = [
      { $match: initialMatch },
      {
        $lookup: {
          from: 'plan',
          let: { find: '$plan' },
          pipeline: [
            { $match: { $expr: { $and: [{ $eq: ['$_id', '$$find'] }] } } },
            { $project: { _id: 1, name: 1 } }
          ],
          as: 'tplan'
        }
      },
      {
        $lookup: {
          from: 'unit',
          let: { find: '$unit' },
          pipeline: [
            { $match: { $expr: { $and: [{ $eq: ['$_id', '$$find'] }] } } },
            { $project: { _id: 1, name: 1 } }
          ],
          as: 'tunit'
        }
      },
      {
        $lookup: {
          from: 'process',
          let: { find: { $cond: [{ $isArray: '$processes' }, '$processes', ['$processes']] } },
          pipeline: [
            { $match: { $expr: { $and: [{ $in: ['$_id', '$$find'] }] } } },
            { $project: { _id: 1, name: 1 } }
          ],
          as: 'procesos'
        }
      },
      {
        $lookup: {
          from: 'unit',
          let: { find: { $cond: [{ $isArray: '$units' }, '$units', ['$units']] } },
          pipeline: [
            { $match: { $expr: { $and: [{ $in: ['$_id', '$$find'] }] } } },
            { $project: { _id: 1, name: 1 } }
          ],
          as: 'unidades'
        }
      },
      {
        $lookup: {
          from: 'params',
          let: { tag: 'riskLevel' },
          pipeline: [
            { $match: { $expr: { $eq: ['$name', '$$tag'] } } },
            { $project: { _id: 0, options: 1 } }
          ],
          as: 'riskLevels'
        }
      },
      { $unwind: { preserveNullAndEmptyArrays: true, path: '$riskLevels' } },
      {
        $lookup: {
          from: 'params',
          let: { tag: 'projectTag' },
          pipeline: [
            { $match: { $expr: { $eq: ['$name', '$$tag'] } } },
            { $project: { _id: 0, options: 1 } }
          ],
          as: 'projectTags'
        }
      },
      { $unwind: { preserveNullAndEmptyArrays: true, path: '$projectTags' } },
      {
        $lookup: {
          from: 'params',
          let: { tag: 'area' },
          pipeline: [
            { $match: { $expr: { $eq: ['$name', '$$tag'] } } },
            { $project: { _id: 0, options: 1 } }
          ],
          as: 'areas'
        }
      },
      {
        $lookup: {
          from: 'task',
          let: { find: '$_id' },
          pipeline: [
            { $match: { $expr: { $and: [ { $eq: ['$project', '$$find'] }, { $in: ['$type', ['task','milestone']] }, { $ne: ['$status', 'suspended'] } ] } } },
            { $project: { _id: 0 } }
          ],
          as: 'tasks'
        }
      },
      {
        $lookup: {
          from: 'time',
          let: { find: '$_id' },
          pipeline: [
            { $match: { $expr: { $and: [ { $eq: ['$project', '$$find'] }, { $gt: ['$user', null] }, { $gt: ['$duration', null] } ] } } },
            { $project: { _id: 0 } }
          ],
          as: 'time'
        }
      },
      { $unwind: { preserveNullAndEmptyArrays: true, path: '$areas' } },
      //{ $lookup: { from: 'time', localField: '_id', foreignField: 'project', as: 'time' } },
      { $lookup: { from: 'auditable', localField: 'template', foreignField: '_id', as: 'auditable' } },
      { $lookup: { from: 'plan', localField: 'autitable.plans', foreignField: '_id', as: 'plans' } },
      {
        $addFields: {
          tasksCompleted: { $filter: { input: '$tasks', as: 'task', cond: { $in: ['$$task.status', ['done', 'reviewed', 'completed']] } } },
          gerente: { $arrayElemAt: [{ $filter: { input: '$actors', as: 'data', cond: { $in: ['manager', '$$data.type'] } } }, 0] },
          nivelRiesgo: { $arrayElemAt: [{ $filter: { input: '$riskLevels.options', as: 'opt', cond: { $eq: ['$$opt.id', '$risk'] } } }, 0] },
          etiquetas: { $filter: { input: '$projectTags.options', as: 'opt', cond: { $in: ['$$opt.id', { $cond: [{ $isArray: '$tag' }, '$tag', ['$tag']] }] } } },
          area: { $arrayElemAt: [{ $filter: { input: '$areas.options', as: 'opt', cond: { $eq: ['$$opt.id', '$area'] } } }, 0] },
          duracionPlaneada: { $sum: '$tasks.duration' },
          duracionReal: { $sum: '$time.duration' },
          jornada: { $cond: { if: { $eq: ['', '$workDay'] }, then: 480, else: '$workDay' } }
        }
      },
      { $addFields: { jornada: { $toInt: { $ifNull: ['$jornada', 480] } } } },
      {
        $lookup: {
          from: 'user',
          localField: 'gerente.user',
          foreignField: '_id',
          as: 'gerente'
        }
      },
      {
        $addFields: {
          gerente: { $arrayElemAt: ['$gerente.name', 0] },
          progress: { $cond: [{ $eq: ['$duracionPlaneada', 0] }, 0, { $round: [{ $divide: [{ $sum: '$tasksCompleted.duration' }, '$duracionPlaneada'] }, 2] }] },
          duracionPlaneadaHoras: { $round: [ { $divide: [ '$duracionPlaneada', 60] }, 2 ] },
          duracionPlaneadaDias: { $round: [ { $divide: [ '$duracionPlaneada', '$jornada' ] }, 2 ] },
          duracionRealHoras: { $round: [ { $divide: [ '$duracionReal', 60] }, 2 ] },
          duracionRealDias: { $round: [ { $divide: [ '$duracionReal', '$jornada' ] }, 2 ] }
        }
      },
      {
        $sort: { _id: 1, tipo: 1 }
      },
      {
        $project: {
          nombre: '$name',
          auditable: '$pPlans',
          gerente: '$gerente',
          nivelRiesgo: { $ifNull: ['$nivelRiesgo.value', ''] },
          dias: '$diasRequeridos',
          duracionPlaneadaHoras: '$duracionPlaneadaHoras',
          duracionPlaneadaDias: '$duracionPlaneadaDias',
          duracionRealHoras: '$duracionRealHoras',
          duracionRealDias: '$duracionRealDias',
          progreso: { $toInt: { $multiply: ['$progress', 100] } },
          fechaInicio: { $cond: { if: { $isArray: ['$planPeriod'] } , then: { $ifNull: [{ $arrayElemAt: ['$planPeriod', 0] }, ''] }, else: '' } },
          fechaFin: { $cond: { if: { $isArray: ['$planPeriod'] } , then: { $ifNull: [{ $arrayElemAt: ['$planPeriod', 1] }, ''] }, else: '' } },
          fechaInicioReal: { $cond: { if: { $isArray: ['$realPeriod'] } , then: { $ifNull: [{ $arrayElemAt: ['$realPeriod', 0] }, ''] }, else: '' } },
          fechaFinReal: { $cond: { if: { $isArray: ['$realPeriod'] } , then: { $ifNull: [{ $arrayElemAt: ['$realPeriod', 1] }, ''] }, else: '' } },
          estado: '$status',
          unidades: '$unidades.name',
          procesos: '$procesos.name',
          plans: { $ifNull: ['$plans.name', []] },
          etiquetas: { $ifNull: ['$etiquetas.value', []] },
          area: { $ifNull: ['$area.value', ''] },
          plan: { $arrayElemAt: ['$tplan.name', 0] },
          departamento: { $arrayElemAt: ['$tunit.name', 0] },
          tipo: '$type'
        }
      }
    ]
    mongo.aggregate('project', pipeline, {allowDiskUse: true}, async (err, projects) => {
      if (err) {
        send({ type: 'error', message: err })
      } else {
        send(projects)
      }
    })
  }
  async statisticsAttacheds (req, mongo, send) {
    let initialMatch = { requiredResponse: '1' }
    let responsibleMatch = {}
    if (req.query.dateRange) {
      initialMatch['_id'] = { $gte: mongo.newId(new Date(req.query.dateRange.split(' - ')[0])), $lt: mongo.newId(new Date(req.query.dateRange.split(' - ')[1])) }
    }
    if (req.query.unitsFilter) {
      let units = req.query.unitsFilter.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      responsibleMatch = { responsibleUnit: { $in: units } }
    }
    var pipeline = [
      {
        $match: initialMatch
      },
      {
        $lookup: {
          from: 'note',
          let: { ref: '$reference' },
          pipeline: [
            { $match: { $expr: { $eq: ['$_id', '$$ref'] } } },
            { $project: { _id: 1, name: 1, sequence: 1, status: 1, tags: 1, dates: 1 } }
          ],
          as: 'note'
        }
      },
      {
        $lookup: {
          from: 'params',
          pipeline: [
            { $match: { $expr: { $and: [{ $eq: ['$name', 'attachedTag'] }] } } },
            { $project: { _id: 0, options: 1 } }
          ],
          as: 'params'
        }
      },
      {
        $lookup: {
          from: 'params',
          pipeline: [
            { $match: { $expr: { $and: [{ $eq: ['$name', 'tag'] }] } } },
            { $project: { _id: 0, options: 1 } }
          ],
          as: 'paramsNote'
        }
      },
      {
        $addFields: {
          issueDate: {
            $filter: {
              input: '$dates',
              as: 'date',
              cond: { $eq: ['$$date.type', 'issue'] }
            }
          },
          actorReviser: {
            $filter: {
              input: '$actors',
              as: 'actor',
              cond: { $eq: ['$$actor.role', 'reviser'] }
            }
          },
          actorResponsible: {
            $filter: {
              input: '$actors',
              as: 'actor',
              cond: { $eq: ['$$actor.role', 'responsible'] }
            }
          },
          note: { $ifNull: [{ $arrayElemAt: ['$note', 0] }, '' ] },
          etiquetaHallazgo: { $cond: { if: { $isArray: '$attachedTag' }, then: { $arrayElemAt: ['$attachedTag', 0] }, else: '$attachedTag' } } ,
          param: { $arrayElemAt: ['$params', 0] },
          paramsNote: { $arrayElemAt: ['$paramsNote', 0] },
        }
      },
      {
        $lookup: {
          from: 'event',
          let: { id: '$note._id' },
          pipeline: [
            { $match: { $expr: { $and: [ { $eq: ['$collection', 'note'] }, { $eq: ['$data', 'attended'] }, { $eq: ['$docId', '$$id'] } ] } } },
            { $project: { _id: 0, date: 1 } }
          ],
          as: 'event'
        }
      },
      {
        $lookup: {
          from: 'process',
          let: { id: '$process' },
          pipeline: [
            { $match: { $expr: { $eq: ['$_id', '$$id'] } } },
            { $project: { _id: 1, name: 1 } }
          ],
          as: 'process'
        }
      },
      {
        $lookup: {
          from: 'unit',
          let: { id: { $ifNull: [{ $arrayElemAt: ['$actorReviser.unit', 0] }, '' ] } },
          pipeline: [
            { $match: { $expr: { $eq: ['$_id', '$$id'] } } },
            { $project: { _id: 1, name: 1 } }
          ],
          as: 'unidadEmisoraHallazgo'
        }
      },
      {
        $addFields: {
          responsibleUnit: { $arrayElemAt: ['$actorResponsible.unit', 0] }
        }
      },
      { $match: responsibleMatch },
      {
        $lookup: {
          from: 'unit',
          let: { id: { $ifNull: [{ $arrayElemAt: ['$actorResponsible.unit', 0] }, '' ] } },
          pipeline: [
            { $match: { $expr: { $eq: ['$_id', '$$id'] } } },
            { $project: { _id: 1, name: 1 } }
          ],
          as: 'unidadResponsable'
        }
      },
      {
        $addFields: {
          fechaPublicacionInforme: {
            $filter: {
              input: '$note.dates',
              as: 'date',
              cond: { $eq: ['$$date.type', 'issue'] }
            }
          },
          fechaCumplimientoInforme: {
            $filter: {
              input: '$note.dates',
              as: 'date',
              cond: { $eq: ['$$date.type', 'deadline'] }
            }
          },
          añoEmisionHallazgo: { $ifNull: [{ $arrayElemAt: ['$issueDate.value', 0] }, '' ] },
          etiquetaHallazgo: { $ifNull: ['$etiquetaHallazgo', ''] },
          param: { $ifNull: [{ $arrayElemAt: ['$params.options', 0] }, []] },
          paramsNote: { $ifNull: ['$paramsNote.options', []] },
          tagsNote: { $cond: { if: { $isArray: '$note.tags' }, then: '$note.tags', else: ['$note.tags'] } },
        }
      },
      {
        $addFields: {
          tagsNote: {
            $filter: {
              input: '$paramsNote',
              as: 'option',
              cond: {$in: ['$$option.id', '$tagsNote']}
            }
          },
        }
      },
      {
        $addFields: {
          'tagsNote': {
            '$map': {
              'input': '$tagsNote',
              'as': 'u',
              'in': {
                '$concat': [{ $toString: '$$u.value' }],
              }
            }
          }
        }
      },
      {
        $addFields: {
          tagsNote: {
            $reduce: {
              input: '$tagsNote',
              initialValue: '',
              in: {
                $concat: [
                  { $toString: '$$value' },
                  {
                    $cond: {
                      if: { $eq: [ '$$value', '' ] },
                      then: ' ',
                      else: ', '
                    }
                  },
                  { $toString: '$$this'}
                ]
              }
            }
          }
        }
      },
      {
        $project: {
          nombreInforme: { $ifNull: [{ $concat: [{ $toString: '$note.sequence.text' }, ' ', { $toString: '$note.name' }] }, '' ] },
          añoEmisionHallazgo: { $ifNull: [{ $cond: { if: { $eq: ['', '$añoEmisionHallazgo'] }, then: '', else: { $year: '$añoEmisionHallazgo' } } }, '' ] },
          unidadEmisoraHallazgo: { $ifNull: [{ $arrayElemAt: ['$unidadEmisoraHallazgo.name', 0] }, '' ] },
          estadoInforme: { $ifNull: ['$note.status', '' ] },
          etiquetasInforme: { $ifNull: ['$tagsNote', '' ] },
          fechaPublicacionInforme: { $ifNull: [{ $arrayElemAt: ['$fechaPublicacionInforme.value', 0] }, ''] },
          fechaCumplimientoInforme: { $ifNull: [{ $arrayElemAt: ['$fechaCumplimientoInforme.value', 0] }, '' ] },
          fechaAtendidoInforme: { $ifNull: [{ $arrayElemAt: ['$event.date', 0] }, '' ] },
          nombreHallazgo: { $ifNull: ['$name', '' ] },
          unidadResponsable: { $ifNull: [{ $arrayElemAt: ['$unidadResponsable.name', 0] }, '' ] },
          etiquetaHallazgo: { $cond: { if: { $ne: [ '$etiquetaHallazgo', '' ] }, then: { $ifNull: [{ $arrayElemAt: ['$param.value', { $indexOfArray: ['$param.id', '$etiquetaHallazgo'] }] }, ''] }, else: '' } } ,
          procesoHallazgo: { $ifNull: [{ $arrayElemAt: ['$process.name', 0] }, '' ] }
        }
      }
    ]
    mongo.aggregate('attached', pipeline, { allowDiskUse: true, cursor: { batchSize: 0 } }, async (err, atts) => {
      if (err || !atts) {
        send({ error: err })
      } else {
        /* var tagsDoc = []
        await new Promise(resolve => {
          mongo.find('params', { name: { $in: ['tag'] } }, { _id: 1, name: 1, options: 1 }, (err, tgsDs) => {
            if (err) {
              console.log(err)
              resolve()
            } else {
              if (tgsDs.length > 0) {
                for (var i in tgsDs) {
                  tagsDoc = tagsDoc.concat(tgsDs[i].options)
                }
              }
              resolve()
            }
          })
        })
        for (let n in atts) {
          let tags = ''
          if (atts[n].etiquetasInforme && atts[n].etiquetasInforme.length) {
            for (let t in atts[n].etiquetasInforme) {
              tagsDoc.forEach(x => {
                if (atts[n].etiquetasInforme[t] && (x.id.toString() === atts[n].etiquetasInforme[t].toString())) {
                  if (!tags) tags = tags + x.value
                  else tags = tags + ', ' + x.value
                }
              })
            }
          }
          atts[n].etiquetasInforme = tags
        } */
        send(atts)
      }
    })
  }
  ///for unit
  async notes (req, mongo, send) {
    var dependents = []
    let initialMatch = {}
    if(req.query.dateRange) {
      initialMatch['_id'] = { $gte: mongo.newId(new Date(req.query.dateRange.split(' - ')[0])), $lt: mongo.newId(new Date(req.query.dateRange.split(' - ')[1])) }
    }
    if (req.query.unit) {
      let units = req.query.unit.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      await this.dependentUnits(mongo, units, dependents)
      dependents = dependents.concat(units)
      initialMatch['actors'] = { $elemMatch: { unit: { $in: dependents }, role: 'from', path: { $ne: 'hidden' } } }
    }
    if (req.query.unitsFilter) {
      let units = req.query.unitsFilter.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      initialMatch['actors'] = { $elemMatch: { unit: { $in: units }, role: 'to', path: { $ne: 'hidden' } } }
    }
    var pipeline = []
    pipeline.push({ $match: initialMatch })
    pipeline.push({
      $lookup: {
        from: 'note',
        let: { id: '$_id' },
        pipeline: [
          { $match: { $expr: { $and: [{ $eq: ['$reference', '$$id'] }] } } },
          { $project: { dates: 1 } }
        ],
        as: 'response'
      }
    })
    pipeline.push({
      $addFields: {
        actorsTo: {
          $filter: {
            input: '$actors',
            as: 'actor',
            cond: { $eq: ['$$actor.role', 'to'] }
          }
        },
        actorsFrom: {
          $filter: {
            input: '$actors',
            as: 'actor',
            cond: { $eq: ['$$actor.role', 'from'] }
          }
        },
        copy: {
          $filter: {
            input: '$actors',
            as: 'actor',
            cond: { $eq: ['$$actor.role', 'copy'] }
          }
        },
        issueDate: {
          $filter: {
            input: '$dates',
            as: 'date',
            cond: { $eq: ['$$date.type', 'issue'] }
          }
        },
        deadlineDate: {
          $filter: {
            input: '$dates',
            as: 'date',
            cond: { $eq: ['$$date.type', 'deadline'] }
          }
        },
        id: '$_id'
      }
    })

    pipeline.push({ $lookup: { from: 'user', localField: 'actorsTo.user', foreignField: '_id', as: 'userTo' } })
    pipeline.push({ $lookup: { from: 'user', localField: 'actorsFrom.user', foreignField: '_id', as: 'userFrom' } })
    pipeline.push({ $lookup: { from: 'user', localField: 'copy.user', foreignField: '_id', as: 'userCopy' } })

    pipeline.push({ $lookup: { from: 'unit', localField: 'actorsTo.unit', foreignField: '_id', as: 'userToUnit' } })
    pipeline.push({ $lookup: { from: 'unit', localField: 'actorsFrom.unit', foreignField: '_id', as: 'userFromUnit' } })
    pipeline.push({ $lookup: { from: 'unit', localField: 'copy.unit', foreignField: '_id', as: 'userCopyUnit' } })

    pipeline.push({
      $project: {
        id: 1,
        _id: 1,
        name: 1,
        estado: '$status',
        response: 1,
        tags: 1,
        consecutivo: { $ifNull: ['$sequence.text', ''] },
        fechaEmision: '$issueDate.value',
        fechaRespuesta: '',
        days: '',
        fechaVencimiento: '$deadlineDate.value',
        de: '$userFrom.name',
        UnidadDe: '$userFromUnit.name',
        para: '$userTo.name',
        UnidadPara: '$userToUnit.name',
        Copia: '$userCopy.name',
        UnidadCopia: '$userCopyUnit.name'

      }
    })
    mongo.aggregate('note', pipeline, { allowDiskUse: true, cursor: { batchSize: 0 } }, async (err, notes) => {
      if (err || !notes) {
        send({ error: err })
      } else {
        var tagsDoc = []
        await new Promise(resolve => {
          mongo.find('params', { name: { $in: ['tag'] } }, { _id: 1, name: 1, options: 1 }, (err, tgsDs) => {
            if (err) {
              console.log(err)
              resolve()
            } else {
              if (tgsDs.length > 0) {
                for (var i in tgsDs) {
                  tagsDoc = tagsDoc.concat(tgsDs[i].options)
                }
              }
              resolve()
            }
          })
        })
        for (const n in notes) {
          let days = 0
          let issue, answer
          let tags = ''
          if (notes[n].tags && notes[n].tags.length) {
            for (const t in notes[n].tags) {
              tagsDoc.forEach(x => {
                if (notes[n].tags[t] && (x.id.toString() === notes[n].tags[t].toString())) {
                  if (!tags) tags = tags + x.value
                  else tags = tags + ', ' + x.value
                }
              })
            }
          }
          notes[n].etiquetas = tags
          if (notes[n].fechaEmision && notes[n].fechaEmision.length !== 0) {
            issue = notes[n].fechaEmision[0]
            notes[n].año = notes[n].fechaEmision[0].getFullYear() ? notes[n].fechaEmision[0].getFullYear() : ''
            notes[n].fechaEmision = notes[n].fechaEmision[0]

            // notes[n].fechaEmision = formatDateAndTime(notes[n].fechaEmision, true)
          } else {
            notes[n].fechaEmision = ''
            notes[n].año = ''
          }
          if (notes[n].fechaVencimiento && notes[n].fechaVencimiento.length !== 0) {
            notes[n].fechaVencimiento = notes[n].fechaVencimiento[0]
            // notes[n].fechaVencimiento = formatDateAndTime(notes[n].fechaVencimiento, true)
          } else {
            notes[n].fechaVencimiento = ''
          }
          if (notes[n].response && notes[n].response.length) {
            const index = notes[n].response[0].dates.findIndex((x) => {
              return x.type === 'issue'
            })
            if (index !== -1) {
              // notes[n].fechaRespuesta = formatDateAndTime(noteResponseResult.dates[index].value, false)
              answer = notes[n].response[0].dates[index].value
              notes[n].fechaRespuesta = notes[n].response[0].dates[index].value
              delete notes[n].response
              notes[n].respondida = 'Si'
            } else {
              delete notes[n].response
              notes[n].respondida = 'No'
              notes[n].fechaRespuesta = ''
            }
          } else {
            delete notes[n].response
            notes[n].respondida = 'No'
            notes[n].fechaRespuesta = ''
          }
          if (issue && answer) {
            let plan
            if (req.session.context.activePlan) {
              plan = await new Promise(resolve => {
                mongo.findId('plan', req.session.context.activePlan.id, (err, plan) => {
                  if (!err && plan) {
                    resolve(plan)
                  } else {
                    resolve(false)
                  }
                })
              })
            } else {
              plan = false
            }
            let holiday = false
            issue = moment(issue).startOf('day')
            answer = moment(answer).startOf('day')
            while (issue._d < answer._d) {
              issue.add(1, 'days')
              if (plan && plan.holidays.length) {
                plan.holidays.forEach(x => {
                  if (issue.format('YYYY/MM/DD') === x) {
                    holiday = true
                  } else {
                    holiday = false
                  }
                })
              } else {
                holiday = false
              }
              if (issue.isoWeekday() !== 6 && issue.isoWeekday() !== 7 && !holiday) {
                days += 1
              }
            }
            notes[n].days = days
          }
          delete notes[n].tags
          delete notes[n]._id
        }
        send(notes)
      }
    })
  }

  formatDateAndTime (obj, array) {
    if (array && array !== false) {
      obj = obj[0]
    }
    var date = obj.getFullYear() + '/' + (obj.getMonth() + 1) + '/' + obj.getDate()
    var time = obj.getHours() + ':' + obj.getMinutes() + ':' + obj.getSeconds()
    return date + ' ' + time
  }

  ///for unit
  async time (req, mongo, send) {
    var dependents = []
    let initialMatch = { $match: { 'Ttask.type': { $in: ['milestone', 'task', ''] } } }
    var plans=[]
    if (req.query.plans) {
      plans=req.query.plans.split(',')
      for (let i in plans) {
        plans[i]=mongo.toId(plans[i])
      }
      initialMatch['$match']['plan'] = { $in: plans }
    }
    if (req.query.unit) {
      let units = req.query.unit.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      await this.dependentUnits(mongo, units, dependents)
      dependents= dependents.concat(units)
    }
    var pipeline = [
      { $limit: 1 },
      {
        $lookup: {
          from: 'activityUser',
          pipeline: [
            { $lookup: { from: 'user', localField: '_id.user', foreignField: '_id', as: 'tuser' } },
            { $lookup: { from: 'plan', localField: '_id.plan', foreignField: '_id', as: 'tplan' } },
            { $lookup: { from: 'activity', localField: '_id.activity', foreignField: '_id', as: 'tactivity' } },
            {
              $addFields: {
                tuser: { $arrayElemAt: ['$tuser', 0] },
                tplan: { $arrayElemAt: ['$tplan', 0] },
                tactivity: { $arrayElemAt: ['$tactivity', 0] },
              }
            },
            { $match: plans.length ? { '_id.plan': { $in: plans } } : {} },
            {
              $match:
                dependents.length ? { 'tplan.units': { $elemMatch: { $in: dependents } } } :{}
            },
            {
              $project: {
                _id: '$_id.activity',
                fecha: '$tplan.period.start',
                tipo: 'activity',
                usuario: '$tuser.name',
                proyecto: 'Actividades',
                plan: '$tplan.name',
                'actividad/tarea': '$tactivity.name',
                duracionPlan: { $toDouble: '$planned' },
                costo: { $toDouble: '0' },
                identify: 'actividadPlan',
              }
            },
          ],
          as: 'activityPlan'
        }
      },
      {
        $lookup: {
          from: 'activity',
          pipeline: [
            {
              $lookup: {
                from: 'time',
                let: { id: '$_id' },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $and: [
                          { $eq: ['$document', '$$id'] },
                        ]
                      }
                    }
                  }
                ],
                as: 'ttime'
              }
            },
            { $unwind: { path: '$ttime', preserveNullAndEmptyArrays: true } },
            { $lookup: { from: 'user', localField: 'ttime.user', foreignField: '_id', as: 'tuser' } },
            { $unwind: '$tuser' },
            { $lookup: { from: 'plan', localField: 'ttime.plan', foreignField: '_id', as: 'tplan' } },
            { $unwind: '$tplan' },
            {
              $project: {
                _id: '$ttime._id',
                fecha: '$ttime.date',
                tipo: 'activity',
                usuario: '$tuser.name',
                proyecto: 'Actividades',
                plan: '$tplan.name',
                'actividad/tarea': '$name',
                duracionReal: { $toDouble: '$ttime.duration' },
                costo: { $toDouble: '0' },
                identify: 'actividadReal',
              }
            },
          ],
          as: 'activityReal'
        }
      },
      {
        $lookup: {
          from: 'project',
          pipeline: [
            plans.length ? { $match: { plan: { $in: plans } } } : { $match: {}},
            dependents.length
              ? { $match: { unit: { $in: dependents } } }
              : { $match: {} },
            { $lookup: { from: 'task', localField: '_id', foreignField: 'project', as: 'Ttask' } },
            { $unwind: { path: '$Ttask', preserveNullAndEmptyArrays: true } },
            initialMatch,
            { $lookup: { from: 'plan', localField: 'plan', foreignField: '_id', as: 'tplan' } },
            { $unwind: '$tplan' },
            {
              $group: {
                _id: '$Ttask.project',
                plans: { $push: '$tplan.name' },
                tasks: { $push: '$Ttask.text' },
                plansId: { $push: '$tplan._id' },
                tasksId: { $push: '$Ttask._id' }
              }
            },
            { $lookup: { from: 'project', localField: '_id', foreignField: '_id', as: 'tproject' } },
            { $unwind: '$tproject' },
            {
              $lookup: {
                from: 'time',
                let: { id: '$_id' },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $and: [
                          { $eq: ['$project', '$$id'] },
                          //{ $in: ['$project', '$$projects']}
                        ]
                      }
                    }
                  }
                ],
                as: 'ttime'
              }
            },
            { $unwind: '$ttime' },
            { $lookup: { from: 'user', localField: 'ttime.user', foreignField: '_id', as: 'tuser' } },
            { $unwind: '$tuser' },
            {
              $project: {
                _id: '$ttime._id',
                fecha: '$ttime.date',
                tipo: '$ttime.type',
                usuario: '$tuser.name',
                proyecto: {
                  $cond: {
                    if: { $or: [{ $eq: ['$ttime.type', 'task'] }, { $eq: ['$ttime.type', ''] }] },
                    then: '$tproject.name',
                    else: 'Actividades'
                  }
                },
                plan: { $arrayElemAt: ['$plans', { $indexOfArray: ['$plansId', { $ifNull: ['$ttime.plan', '$tproject.plan'] }] }] },
                'actividad/tarea': { $ifNull: ['$ttime.activity', { $arrayElemAt: ['$tasks', { $indexOfArray: ['$tasksId', '$ttime.document'] }] }] },
                duracionReal: { $toDouble: { $ifNull: ['$ttime.duration', 0] } },
                costo: { $ifNull: [{ $toDouble: '$ttime.cost' }, 0 ] },
                document: '$ttime.document',
                identify: 'Reales'
              }
            }
          ],
          as: 'tasksReal'
        }
      },
      {
        $project: {
          union: {
            $concatArrays: [ '$tasksReal', '$activityPlan', '$activityReal']
          }
        }
      },
      { $unwind: '$union' },
      { $replaceRoot: { newRoot: '$union' } },
      {
        '$group': {
          '_id': {
            tipo: '$tipo',
            usuario: '$usuario',
            proyecto: '$proyecto',
            plan: '$plan',
            'actividad/tarea': '$actividad/tarea'
          },
          idTask: { $first: {$ifNull: ['$document','$_id']}},
          fechaInicio: { $first: '$fecha' },
          fechaFin: {$last: '$fecha'},
          planeado: { $sum: { $ifNull: ['$duracionPlan',0]} },
          real: {$sum: {$ifNull: ['$duracionReal',0]} },
          costo: { $sum: { $ifNull: ['$costo', 0] }},
        }
      },
      { $lookup: { from: 'task', localField: 'idTask', foreignField: '_id', as: 'tableTask' } },
      {
        '$project': {
          _id: 0,
          'actividad/tarea': '$_id.actividad/tarea',
          tipo: '$_id.tipo',
          fechaInicio: '$fechaInicio',
          fechaFin: '$fechaFin',
          semanaInicio: {$week: { $toDate: '$fechaInicio' }},
          semanaFin: {$week: { $toDate: '$fechaFin' }},
          usuario: '$_id.usuario',
          proyecto: '$_id.proyecto',
          plan: '$_id.plan',
          'planeado(horas)': { $round: [{$divide: [{ $ifNull: [{ $arrayElemAt: ['$tableTask.duration',0]}, '$planeado']} , 60]},4]},
          'real(horas)': { $round: [{$divide: ['$real', 60]},4]},
          costo: { $ifNull: ['$costo', 0] }
        }
      }
    ]
    mongo.aggregate('plan', pipeline, { allowDiskUse: true}, (err, times) => {
      if (err) {
        send({ type: 'error', message: err.message })
      } else {
        send(times)
      }
    })
  }
  async taskProjects(req, mongo, send) {

    var plans=[]
    if (req.query.plans) {
      plans = req.query.plans.split(',')
      for (let i in plans) {
        plans[i] = mongo.toId(plans[i])
      }
    }

    var pipeline = [
      {
        $match: { plan:{ $in: plans } }
      },
      {
        $lookup: {
            from: 'task',
            let: { project: '$_id' },
            pipeline: [
              { $match: { $expr: { $and: [{ $eq: ['$project', '$$project'] },{ $eq: ['$type', 'task'] }] } } },
              { $project: { _id:1, text:1, owner_id:1, duration:1, status:1 } }
            ],
            as: 'Ttask'
          }
      },
      {
          $unwind: "$Ttask"
      },
      {
          $project: {
              _id: '$Ttask._id',
              proyecto: '$name',
              plan: '$plan',
              estado: '$status',
              tarea: '$Ttask.text',
              estadoTarea: '$Ttask.status',
              owner_id: { $ifNull: ['$Ttask.owner_id', ''] },
              duration: '$Ttask.duration',
          }
      },
      {
          $lookup: {
              from: 'user',
              let: { owner: '$owner_id' },
              pipeline: [
                { $match: { $expr: { $and: [{ $eq: ['$_id', '$$owner'] }] } } },
                { $project: { name: 1, workDay: '$business.workDay' } }
              ],
              as: 'owner'
            }
      },
      {
        $lookup: {
            from: 'plan',
            let: { plan: '$plan' },
            pipeline: [
              { $match: { $expr: { $and: [{ $eq: ['$_id', '$$plan'] }] } } },
              { $project: { name: 1 } }
            ],
            as: 'Tplan'
          }
      },
      {
          $lookup: {
              from: 'time',
              let: { id: '$_id' },
              pipeline: [
                { $match: { $expr: { $and: [{ $eq: ['$document', '$$id'] }] } } },
                { $project: { duration: 1 } }
              ],
              as: 'Ttimer'
            }
      },
      {
        $project: {
            _id: 0,
            plan: { $ifNull: [{ $arrayElemAt: ['$Tplan.name', 0] }, '' ] },
            proyecto: 1,
            tarea: { $ifNull: ['$tarea', '' ] },
            estado:1,
            estadoTarea:1,
            responsable: { $ifNull: [{ $arrayElemAt: ['$owner.name', 0] }, '' ] },
            duracionPlaneada: { $ifNull: [{ $cond: [ { $isNumber : '$duration' },{ $round: [{ $divide: [ '$duration', { $ifNull: [{ $arrayElemAt: ['$owner.workDay', 0] }, 480 ] } ] }, 2 ] }, 0 ] }, 0 ] },
            duracionReal: { $ifNull: [{ $round: [{ $divide: [ { $sum: { $arrayElemAt: ['$Ttimer.duration', 0] }}, { $ifNull: [{ $arrayElemAt: ['$owner.workDay', 0] }, 480 ] } ] }, 2 ] }, 0 ] },
          }
      }
    ]
    mongo.aggregate('project', pipeline, { allowDiskUse: true}, (err, tasks) => {
      if (err) {
        send({ type: 'error', message: err.message })
      } else {
        send(tasks)
      }
    })
  }

  ///for unit
  async timePerformance (req, mongo, send) {
    let initialMatch = { $match: { 'Ttask.type': { $in: ['milestone', 'task'] }} }
    if(req.query.dateRange) {
      initialMatch['$match']['Ttask.start_date'] = { $gte: new Date(req.query.dateRange.split(' - ')[0].split('T')[0]), $lt: new Date(req.query.dateRange.split(' - ')[1].split('T')[0]) }
    }
    var dependents = []
    if (req.query.unit) {
      let units = req.query.unit.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      await this.dependentUnits(mongo, units, dependents)
      dependents= dependents.concat(units)
    }
    var pipeline = [
      {
        $lookup: {
          from: 'project',
          let: { id: '$_id' },
          pipeline: [
            dependents.length ?{
              $match: {
                unit: {
                  $in: dependents
                },
                $expr: {
                  $and: [
                    {
                      $eq: ['$plan', '$$id']
                    }
                  ]
                }
              }
            } :
              {
                $match: {
                  $expr: {
                    $and: [
                      {
                        $eq: ['$plan', '$$id']
                      }
                    ]
                  }
                }
              }
          ],
          as: 'tproject'
        }
      },
      { $unwind: { path: '$tproject', preserveNullAndEmptyArrays: true } },
      { $lookup: { from: 'task', localField: 'tproject._id', foreignField: 'project', as: 'Ttask' } },
      { $unwind: { path: '$Ttask', preserveNullAndEmptyArrays: true } },
      initialMatch,
      {
        $group: {
          _id: '$Ttask.owner_id',
          plans: { $push: '$name' },
          projects: { $push: '$tproject.name' },
          tasks: { $push: '$Ttask.text' },
          plansId: { $push: '$_id' },
          unitId: { $push: '$unit' },
          projectsId: { $push: '$tproject._id' },
          tasksId: { $push: '$Ttask.id' }
        }
      },
      { $lookup: { from: 'user', localField: '_id', foreignField: '_id', as: 'tuser' } },
      { $unwind: '$tuser' },
      {
        $addFields: {
          units: '$tuser.units',
        }
      },
      {
        $match:
          dependents.length ? { units: { $elemMatch: { $in: dependents } } } :{}
      },
      {
        $lookup: {
          from: 'time',
          let: { id: '$_id', plans: '$plansId' },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ['$user', '$$id'] },
                    { $in: ['$plan', '$$plans']}
                  ]
                }
              }
            }
          ],
          as: 'ttime'
        }
      },
      { $unwind: '$ttime' },
      {
        $addFields: {
          unit: { $arrayElemAt: ['$unitId', { $indexOfArray: ['$plansId', '$ttime.plan'] }] },
          fechaActividadRealizada: '$ttime.date',
          fechaCreacion: {$toDate: '$ttime._id'},
        }
      },
      {
        $addFields: {
          dayssince: {
            $trunc: {
              $divide: [{ $subtract: ['$fechaCreacion', '$fechaActividadRealizada'] }, 1000 * 60 * 60 * 24]
            }
          }
        }
      },
      {
        $addFields: {
          dosDiasDespues: { $cond: { if: { $or: [ { $gte: [ '$dayssince', 2 ] }, { $lte: [ '$dayssince', -2 ] } ] }, then: 1, else: 0} },
          mismoDia: { $cond: { if: { $and: [ { $lt: [ '$dayssince', 2 ] }, { $gt: [ '$dayssince', -2 ] } ] }, then: 1, else: 0} }
        }
      },
      { $lookup: { from: 'unit', localField: 'unit', foreignField: '_id', as: 'tunit' } },
      { $unwind: { path: '$tunit', preserveNullAndEmptyArrays: true } },
      {
        $project: {
          _id: '$ttime._id',
          diasDiferencia: '$dayssince',
          fechaActividadRealizada: '$fechaActividadRealizada',
          fechaCreacion: '$fechaCreacion',
          dosDiasDespues: '$dosDiasDespues',
          mismoDia: '$mismoDia',
          tipo: '$ttime.type',
          usuario: '$tuser.name',
          unidad: '$tunit.name',
          proyecto: {
            $cond: {
              if: { $eq: ['$ttime.type', 'task'] },
              then: { $arrayElemAt: ['$projects', { $indexOfArray: ['$projectsId', '$ttime.project'] }] },
              else: 'Actividades'
            }
          },
          plan: { $arrayElemAt: ['$plans', { $indexOfArray: ['$plansId', '$ttime.plan'] }] },
        }
      }
    ]
    mongo.aggregate('plan', pipeline, { allowDiskUse: true }, (err, times) => {
      if (err) {
        send({ type: 'error', message: err })
      } else {
        send(times)
      }
    })
  }
  ///for unit
  async trainnings (req, mongo, send) {
    var dependents = []
    if (req.query.unit) {
      let units = req.query.unit.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      await this.dependentUnits(mongo, units, dependents)
      dependents= dependents.concat(units)
    }
    var pipeline = [
      { $match: { trainnings: { $exists: true }, /* units: { $in: dependents} */ } },
      { $unwind: { path: '$trainnings', preserveNullAndEmptyArrays: true } },
      {
        $lookup: {
          from: 'params',
          pipeline: [
            { $match: { $expr: { $and: [{ $eq: ['$name', 'topics'] }] } } },
            { $project: { _id: 0, options: 1 } }
          ],
          as: 'topics'
        }
      },
      {
        $lookup: {
          from: 'params',
          pipeline: [
            { $match: { $expr: { $and: [{ $eq: ['$name', 'degrees'] }] } } },
            { $project: { _id: 0, options: 1 } }
          ],
          as: 'degrees'
        }
      },
      {
        $addFields: {
          topics: { $arrayElemAt: ['$topics', 0] },
        }
      },
      {
        $addFields: {
          topics: { $ifNull: ['$topics.options', []] },
        }
      },
      {
        $addFields: {
          topic: { $arrayElemAt: ['$topics', 0] },
          tagsTopic: { $cond: { if: { $isArray: '$trainnings.topic' }, then: '$trainnings.topic', else: ['$trainnings.topic'] } },
        }
      },
      {
        $addFields: {
          tagsTopic: {
            $filter: {
              input: '$topics',
              as: 'option',
              cond: {$in: ['$$option.id', '$tagsTopic']}
            }
          },
        }
      },
      {
        $addFields: {
          'tagsTopic': {
            '$map': {
              'input': '$tagsTopic',
              'as': 'u',
              'in': {
                '$concat': [ '$$u.value' ],
              }
            }
          }
        }
      },
      {
        $addFields: {
          tagsTopic: {
            $reduce: {
              input: '$tagsTopic',
              initialValue: '',
              in: {
                $concat: [
                  '$$value',
                  {
                    $cond: {
                      if: { $eq: [ '$$value', '' ] },
                      then: ' ',
                      else: ', '
                    }
                  },
                  '$$this'
                ]
              }
            }
          }
        }
      },
      {
        $addFields: {
          degree: { $arrayElemAt: ['$degrees', 0] },
          period: { $ifNull: ['$trainnings.period.end', ''] },
          trainningId: '$trainnings.id',
          trainningName: '$trainnings.name',
          trainningDate: { $ifNull: ['$trainnings.date', null]},
          hourTrainning: '$trainnings.hourTrainning',
          detail: '$trainnings.detail'
        }
      },
      {
        $project: {
          _id: 1,
          trainningId: '$trainningId',
          Usuario: { $ifNull: ['$name', '']},
          duración: { $ifNull: ['$hourTrainning', '']},
          'Nombre de la capacitación': { $ifNull: ['$trainningName', '']},
          fecha: { $cond: { if: { $and: [{ $ne: ['$trainningDate', null] }, { $eq: [{ $type: '$trainningDate' }, 'date'] }] }, then: { $ifNull: ['$trainningDate', ''] }, else: { $cond: { if: { $and: [{ $ne: ['$period', ''] }, { $eq: [{ $type: '$period' }, 'date'] }] }, then: { $ifNull: ['$period', ''] }, else: '' } } } },
          año: { $cond: { if: { $and: [{ $ne: ['$trainningDate', null] }, { $eq: [{ $type: '$trainningDate' }, 'date'] }] }, then: { $ifNull: [{ $year: '$trainningDate' }, ''] }, else: { $cond: { if: { $and: [{ $ne: ['$period', ''] }, { $eq: [{ $type: '$period' }, 'date'] }] }, then: { $ifNull: [{ $year: '$period' }, ''] }, else: '' } } } },
          detalle: { $ifNull: ['$detail', '']},
          'etiquetas tema': '$tagsTopic',
          'etiqueta grado': { $ifNull: [{ $arrayElemAt: ['$degree.options.value', { $indexOfArray: ['$degree.options.id', '$trainnings.degree'] }] }, ''] }
        }
      }
    ]
    mongo.aggregate('user', pipeline, {}, (err, result) => {
      if (err) {
        send({ type: 'error', message: err })
      } else {
        send(result)
      }
    })
  }

  attachedConsolidated (req, mongo, send) {
    let responsableMatch = {}
    if (req.query.unitsFilter) {
      let units = req.query.unitsFilter.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      responsableMatch = { unidadResponsable: { $in: units } }
    }
    let pipeline = [
      {
        $lookup: {
          from: 'commitment',
          let: { ref: '$_id' },
          pipeline: [{ $match: { $expr: { $and: [{ $eq: ['$reference', '$$ref'] }] } } }, { $project: { _id: 1, dates: 1, name: 1, actors: 1, reference: 1, tags: 1, sequence: 1, status: 1 } }],
          as: 'comm'
        }
      },
      {
        $addFields: {
          commitment: { $arrayElemAt: ['$comm', 0] },
        }
      },
      {
        $lookup: {
          from: 'user',
          pipeline: [{ $project: { _id: { $toString: '$_id' }, name: 1, licensedUser: 1 } }],
          as: 'tuser'
        }
      },
      {
        $lookup: {
          from: 'unit',
          pipeline: [{ $project: { _id: 1, name: 1 } }],
          as: 'tunit'
        }
      },
      {
        $lookup: {
          from: 'note',
          let: { id: '$reference' },
          pipeline: [{ $match: { $expr: { $and: [{ $eq: ['$_id', '$$id'] }] } } }, { $project: { _id: 1, dates: 1, name: 1, actors: 1, tags: 1, sequence: 1 } }],
          as: 'note'
        }
      },
      {
        $addFields: {
          note: { $arrayElemAt: ['$note', 0] },
          trimestreAnexo: { $filter: { input: { $ifNull: ['$dates', []] }, as: 'data', cond: { $eq: ['$$data.type', 'issue'] } } },
          auditado: { $filter: { input: { $ifNull: ['$actors', []] }, as: 'data', cond: { $eq: ['$$data.role', 'responsible'] } } }
        }
      },
      {
        $lookup: {
          from: 'params',
          pipeline: [
            { $match: { $expr: { $and: [{ $eq: ['$name', 'attachedTag'] }] } } },
            { $project: { _id: 0, options: 1 } }
          ],
          as: 'params'
        }
      },
      {
        $addFields: {
          auditado: { $arrayElemAt: ['$auditado.user', 0] },
          unidadResponsable: { $arrayElemAt: ['$auditado.unit', 0] },
          trimestreAnexo: { $ifNull: [{ $arrayElemAt: ['$trimestreAnexo', 0] }, ''] },
          param: { $arrayElemAt: ['$params', 0] },
          tags: { $cond: { if: { $isArray: '$attachedTag' }, then: { $arrayElemAt: ['$attachedTag', 0] }, else: '$attachedTag' } } ,
          dateNote: { $filter: { input: { $ifNull: ['$note.dates', []] }, as: 'data', cond: { $eq: ['$$data.type', 'issue'] } } },
        }
      },
      { $match: responsableMatch },
      {
        $addFields: {
          trimestreAnexo: { $ifNull: [{ $month: '$trimestreAnexo.value' }, ''] },
          param: { $ifNull: [{ $arrayElemAt: ['$params.options', 0] }, []] },
          tags: { $ifNull: ['$tags', ''] },
          dateNote: { $ifNull: [{ $arrayElemAt: ['$dateNote', 0] }, ''] },
        }
      },
      {
        $addFields: {
          trimestreAnexo: { $cond: { if: { $lte: [ '$trimestreAnexo', 3 ] }, then: 'I', else: { $cond: { if: { $lte: [ '$trimestreAnexo', 6 ] }, then: 'II', else: { $cond: { if: { $lte: [ '$trimestreAnexo', 9 ] }, then: 'III', else: { $cond: { if: { $lte: [ '$trimestreAnexo', 12 ] }, then: 'IV', else: '' } } } } } } } },
          semestreAnexo: { $cond: { if: { $lte: [ '$trimestreAnexo', 3 ] }, then: 'I', else: { $cond: { if: { $lte: [ '$trimestreAnexo', 6 ] }, then: 'I', else: { $cond: { if: { $lte: [ '$trimestreAnexo', 9 ] }, then: 'II', else: { $cond: { if: { $lte: [ '$trimestreAnexo', 12 ] }, then: 'II', else: '' } } } } } } } },
          tags: { $cond: { if: { $ne: [ '$tags', '' ] }, then: { $ifNull: [{ $arrayElemAt: ['$param.value', { $indexOfArray: ['$param.id', '$tags'] }] }, ''] }, else: '' } } ,
          mesAnexo: { $ifNull: [{ $month: '$dateNote.value' }, ''] },
        }
      },
      {
        $project: {
          auditado: { $ifNull: [{ $arrayElemAt: ['$tuser.name', { $indexOfArray: ['$tuser._id', { $toString: '$auditado' }] }] }, ''] },
          unidadResponsable: { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', { $ifNull: ['$unidadResponsable', ''] }] }] }, ''] },
          nombre: '$name',
          secuencia: '$sequence.text',
          etiquetaAnexo: '$tags',
          mesAnexo: { $cond: { if: { $eq: [ '$mesAnexo', 1 ] }, then: 'Enero', else: { $cond: { if: { $eq: [ '$mesAnexo', 2 ] }, then: 'Febrero', else: { $cond: { if: { $eq: [ '$mesAnexo', 3 ] }, then: 'Marzo', else: { $cond: { if: { $eq: [ '$mesAnexo', 4 ] }, then: 'Abril', else: { $cond: { if: { $eq: [ '$mesAnexo', 5 ] }, then: 'Mayo', else: { $cond: { if: { $eq: [ '$mesAnexo', 6 ] }, then: 'Junio',else: { $cond: { if: { $eq: [ '$mesAnexo', 7 ] }, then: 'Julio', else: { $cond: { if: { $eq: [ '$mesAnexo', 8 ] }, then: 'Agosto', else: { $cond: { if: { $eq: [ '$mesAnexo', 9 ] }, then: 'Septiembre', else: { $cond: { if: { $eq: [ '$mesAnexo', 10 ] }, then: 'Octubre', else: { $cond: { if: { $eq: [ '$mesAnexo', 11 ] }, then: 'Noviembre', else: { $cond: { if: { $eq: [ '$mesAnexo', 12 ] }, then: 'Diciembre', else: '' } } } } } } } } } } } } } } } } } } } } } } } },
          trimestreAnexo: { $ifNull: ['$trimestreAnexo', ''] },
          semestreAnexo: { $ifNull: ['$semestreAnexo', ''] },
          estadoAnexo: { $ifNull: ['$status', ''] },
          estadoCompromiso: { $ifNull: ['$commitment.status', ''] },
        }
      }
    ]
    mongo.aggregate('attached', pipeline, {}, (err, result) => {
      if (err) {
        send({ type: 'error', message: err })
      } else {
        send(result)
      }
    })
  }

  ///for unit
  async responseTimeNote (req, mongo, send) {
    let initialMatch = { task: { $exists: 1 } }
    let areaMatch = {}
    let deparmentsProjectMatch = {}
    let planMatch = {}
    if (req.query.plans) {
      let plans = req.query.plans.split(',')
      let plansIds = []
      for (let p in plans) {
        plansIds.push(mongo.toId(plans[p]))
      }
      planMatch = { plan: { $in: plansIds } }
      //initialMatch['plan'] = { $in: plansIds }
    }
    if(req.query.dateRange) {
      initialMatch['_id'] = { $gte: mongo.newId(new Date(req.query.dateRange.split(' - ')[0])), $lt: mongo.newId(new Date(req.query.dateRange.split(' - ')[1])) }
    }
    var dependents = []
    if (req.query.unit) {
      let units = req.query.unit.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      await this.dependentUnits(mongo, units, dependents)
      dependents = dependents.concat(units)
      initialMatch['actors'] = { $elemMatch: { unit: { $in: dependents }, role: 'from', path: { $ne: 'hidden' } } }
    }
    if (req.query.unitsFilter) {
      let units = req.query.unitsFilter.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      areaMatch = { areaMatch: { $in: units } }
    }
    if (req.query.deparmentsProjectFilter) {
      let units = req.query.deparmentsProjectFilter.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      deparmentsProjectMatch = { deparmentProject: { $in: units } }
    }
    var pipeline = [
      { $match: initialMatch },
      {
        $lookup: {
          from: 'unit',
          pipeline: [{ $project: { _id: { $toString: '$_id' }, name: 1 } }],
          as: 'tunit'
        }
      },
      {
        $lookup: {
          from: 'user',
          pipeline: [{ $project: { _id: { $toString: '$_id' }, name: 1 } }],
          as: 'tuser'
        }
      },
      {
        $lookup: {
          from: 'project',
          pipeline: [{ $project: { _id: { $toString: '$_id' }, name: 1, plan: 1, unit: 1 } }],
          as: 'tproject'
        }
      },
      {
        $lookup: {
          from: 'plan',
          pipeline: [{ $project: { _id: { $toString: '$_id' }, name: 1 } }],
          as: 'tplan'
        }
      },
      {
        $lookup: {
          from: 'event',
          let: { id: '$_id' },
          pipeline: [{ $match: { $expr: { $and: [{ $eq: ['$docId', '$$id'] }] } } }, { $project: { _id: 1, data: 1, date: 1 } }],
          as: 'event'
        }
      },
      {
        $lookup: {
          from: 'params',
          pipeline: [
            { $match: { $expr: { $and: [{ $eq: ['$name', 'tag'] }] } } },
            { $project: { _id: 0, options: 1 } }
          ],
          as: 'params'
        }
      },
      {
        $addFields: {
          fechaPublicacion: { $filter: { input: '$dates', as: 'data', cond: { $eq: ['$$data.type', 'issue'] } } },
          area: { $filter: { input: '$actors', as: 'data', cond: { $eq: ['$$data.path', 'sent'] } } },
          //plan: { $ifNull: ['$plan', 0] },
          project: { $ifNull: ['$project', 0] },
          param: { $arrayElemAt: ['$params', 0] },
        }
      },
      {
        $lookup: {
          from: 'time',
          let: { p: '$project', t: '$task' },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ['$project', '$$p'] },
                    { $eq: ['$task', '$$t']}
                  ]
                }
              }
            },
            { $sort: { _id: -1 } },
            { $limit: 1}
          ],
          as: 'ttime'
        }
      },
      {
        $addFields: {
          plan: { $cond: { if: { $eq: ['$project', 0] }, then: '', else: { $arrayElemAt: ['$tproject.plan', { $indexOfArray: ['$tproject._id', { $toString: '$project' }] }] } } },
          project: { $cond: { if: { $eq: ['$project', 0] }, then: '', else: { $arrayElemAt: ['$tproject.name', { $indexOfArray: ['$tproject._id', { $toString: '$project' }] }] } } },
          deparmentProject: { $cond: { if: { $eq: ['$project', 0] }, then: '', else: { $arrayElemAt: ['$tproject.unit', { $indexOfArray: ['$tproject._id', { $toString: '$project' }] }] } } },
          fechaFinal: { $arrayElemAt: ['$ttime', 0] },
          areaMatch: { $arrayElemAt: ['$area.unit', 0] }
        }
      },
      { $match: planMatch },
      { $match: areaMatch },
      { $match: deparmentsProjectMatch },
      {
        $project: {
          tags: { $ifNull: ['$tags', []] },
          param: { $ifNull: [{ $arrayElemAt: ['$params.options', 0] }, []] },
          asunto: { $concat: [{ $toUpper: '$sequence.text' }, ' ', '$name'] },
          evento: { $ifNull: ['$event', ''] },
          area: { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', { $ifNull: [{ $toString: { $arrayElemAt: ['$area.unit', 0] } }, ''] }] }] }, ''] },
          trimestre: { $ifNull: [{ $month: { $arrayElemAt: ['$fechaPublicacion.value', 0] } }, ''] },
          proyecto: '$project',
          'departamento proyecto': { $cond: { if: { $eq: ['$deparmentProject', 0] }, then: '', else: { $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', { $toString: '$deparmentProject' }] }] } } },
          plan: { $cond: { if: { $eq: ['$plan', 0] }, then: '', else: { $arrayElemAt: ['$tplan.name', { $indexOfArray: ['$tplan._id', { $toString: '$plan' }] }] } } },
          estado: '$status',
          fechaPublicacion: { $ifNull: [{ $arrayElemAt: ['$fechaPublicacion.value', 0] }, ''] },
          fechaFinal: { $ifNull: ['$fechaFinal.date', ''] },
        }
      }
    ]
    mongo.aggregate('note', pipeline, { allowDiskUse: true }, (err, result) => {
      if (err) {
        send({ type: 'error', message: err })
      } else {
        for (var i in result) {
          let doc = result[i]
          if (doc.trimestre <= 3) {
            doc.trimestre = 'I'
          } else if (doc.trimestre <= 6) {
            doc.trimestre = 'II'
          } else if (doc.trimestre <= 9) {
            doc.trimestre = 'III'
          } else if (doc.trimestre <= 12) {
            doc.trimestre = 'IV'
          }
          if(doc.fechaPublicacion && doc.fechaFinal)
            doc.diasHabiles = moment(new Date(doc.fechaPublicacion)).isValid() && moment(new Date(doc.fechaFinal)).isValid() ? moment(new Date(doc.fechaFinal)).diff(moment(new Date(doc.fechaPublicacion)), 'days') : ''
          else
            doc.diasHabiles = ''
          doc.etiqueta = ''
          if(doc.tags.length > 0) {
            for (let g in doc.param) {
              if (doc.tags[0] && (doc.param[g].id.toString() === doc.tags[0].toString())) {
                doc.etiqueta = doc.param[g].value
              }
            }
          }
          delete doc.evento
          delete doc.param
          delete doc.tags
        }
        send(result)
      }
    })
  }
  ///for unit
  async commitmentByRisk (req, mongo, send) {
    let initialMatch = {}
    let responsibleMatch = {}
    if (req.query.dateRange) {
      initialMatch['_id'] = { $gte: mongo.newId(new Date(req.query.dateRange.split(' - ')[0])), $lt: mongo.newId(new Date(req.query.dateRange.split(' - ')[1])) }
    }
    var dependents = []
    if (req.query.unit) {
      let units = req.query.unit.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      await this.dependentUnits(mongo, units, dependents)
      dependents = dependents.concat(units)
      initialMatch['actors'] = { $elemMatch: { unit: { $in: dependents }, role: 'supervisor', path: { $ne: 'hidden' } } }
    }
    if (req.query.unitsFilter) {
      let units = req.query.unitsFilter.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      responsibleMatch = { responsibleUnit: { $in: units } }
    }
    var pipeline = [
      {
        $lookup: {
          from: 'unit',
          pipeline: [{ $project: { _id: 1, name: 1 } }],
          as: 'tunit'
        }
      },
      {
        $lookup: {
          from: 'params',
          pipeline: [
            { $match: { $expr: { $and: [{ $eq: ['$name', 'riskLevel'] }] } } },
            { $project: { _id: 0, options: 1 } }
          ],
          as: 'params'
        }
      },
      {
        $lookup: {
          from: 'attached',
          let: { id: '$reference' },
          pipeline: [{ $match: { $expr: { $and: [{ $eq: ['$_id', '$$id'] }] } } }, { $project: { _id: 1, dates: 1, name: 1, actors: 1, reference: 1, tags: 1, sequence: 1, attachedTag: 1 } }],
          as: 'attached'
        }
      },
      {
        $lookup: {
          from: 'note',
          let: { id: { $ifNull: [{ $arrayElemAt: ['$attached.reference', 0] }, ''] } },
          pipeline: [{ $match: { $expr: { $and: [{ $eq: ['$_id', '$$id'] }] } } }, { $project: { _id: 1, name: 1, actors: 1 } }],
          as: 'note'
        }
      },
      {
        $addFields: {
          note: { $arrayElemAt: ['$note', 0] },
          attached: { $arrayElemAt: ['$attached', 0] },
          params: { $arrayElemAt: ['$params', 0] },
        }
      },
      {
        $addFields: {
          tag: { $arrayElemAt: ['$attached.tags', 0] },
          UnidadDe: { $filter: { input: { $ifNull: ['$note.actors', []] }, as: 'data', cond: { $eq: ['$$data.role', 'from'] } } },
          UnidadPara: { $filter: { input: { $ifNull: ['$note.actors', []] }, as: 'data', cond: { $eq: ['$$data.role', 'to'] } } },
          UnidadCopia: { $filter: { input: { $ifNull: ['$note.actors', []] }, as: 'data', cond: { $eq: ['$$data.role', 'copy'] } } },
          responsibleUnit: { $filter: { input: { $ifNull: ['$attached.actors', []] }, as: 'data', cond: { $eq: ['$$data.role', 'responsible'] } } },
        }
      },
      {
        $addFields: {
          UnidadDe: { $ifNull: [{ $arrayElemAt: ['$UnidadDe.unit', 0] } ,0 ]},
          UnidadPara: { $ifNull: [{ $arrayElemAt: ['$UnidadPara.unit', 0] },0]},
          UnidadCopia: { $ifNull: [{ $arrayElemAt: ['$UnidadCopia.unit', 0] },0]},
          responsibleUnit: { $ifNull: [{ $arrayElemAt: ['$responsibleUnit.unit', 0] },0]},
          etiqueta: { $filter: { input: { $ifNull: ['$params.options', []] }, as: 'data', cond: { $eq: [{ toString: '$$data.id'}, { toString: '$tag'}] } } },
        }
      },
      { $match: responsibleMatch },
      {
        $addFields: {
          etiqueta: { $arrayElemAt: ['$etiqueta',0] }
        }
      },
      {
        $project: {
          UnidadDe: { $cond: { if: { $eq: ['$UnidadDe', 0] }, then: '', else: { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', '$UnidadDe' ] }] }, ''] } } },//,
          UnidadPara: { $cond: { if: { $eq: ['$UnidadPara', 0] }, then: '', else: { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', '$UnidadPara' ] }]}, ''] } } },//,
          UnidadCopia: { $cond: { if: { $eq: ['$UnidadCopia', 0] }, then: '', else: { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', '$UnidadCopia' ] }] }, ''] } } },//,
          responsibleUnit: { $cond: { if: { $eq: ['$responsibleUnit', 0] }, then: '', else: { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', '$responsibleUnit' ] }] }, ''] } } },//,
          etiqueta: { $ifNull: ['$etiqueta.value','']}
        }
      },
      {
        $group:
                {
                  _id: { etiqueta: '$etiqueta', UnidadDe: '$UnidadDe', UnidadPara: '$UnidadPara', responsibleUnit: '$responsibleUnit' },
                  count: { $sum: 1 }

                }
      },
      {
        $project: {
          _id: 0,
          etiqueta: '$_id.etiqueta',
          UnidadDe: '$_id.UnidadDe',//,
          UnidadPara: '$_id.UnidadPara',//,
          UnidadResponsable: '$_id.responsibleUnit',//,
          total: '$count'
        }
      }
    ]
    mongo.aggregate('commitment', pipeline, { allowDiskUse: true }, (err, result) => {
      if (err) {
        send({ type: 'error', message: err })
      } else {
        send(result)
      }
    })
  }
  ///for unit
  async commitmentExpired (req, mongo, send) {
    let initialMatch = { }
    let responsibleMatch = {}
    if (req.query.dateRange) {
      initialMatch['_id'] = { $gte: mongo.newId(new Date(req.query.dateRange.split(' - ')[0])), $lt: mongo.newId(new Date(req.query.dateRange.split(' - ')[1])) }
    }
    var dependents = []
    if (req.query.unit) {
      let units = req.query.unit.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      await this.dependentUnits(mongo, units, dependents)
      dependents = dependents.concat(units)
      initialMatch['actors'] = { $elemMatch: { unit: { $in: dependents }, role: 'supervisor', path: { $ne: 'hidden' } } }
    }
    if (req.query.unitsFilter) {
      let units = req.query.unitsFilter.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      responsibleMatch = { UnidadResponsable: { $in: units } }
    }
    var pipeline = [
      {
        $lookup: {
          from: 'unit',
          pipeline: [{ $project: { _id: 1, name: 1 } }],
          as: 'tunit'
        }
      },
      {
        $lookup: {
          from: 'params',
          pipeline: [
            { $match: { $expr: { $and: [{ $eq: ['$name', 'riskLevel'] }] } } },
            { $project: { _id: 0, options: 1 } }
          ],
          as: 'params'
        }
      },
      {
        $lookup: {
          from: 'attached',
          let: { id: '$reference' },
          pipeline: [{ $match: { $expr: { $and: [{ $eq: ['$_id', '$$id'] }] } } }, { $project: { _id: 1, dates: 1, name: 1, actors: 1, reference: 1, tags: 1, sequence: 1, attachedTag: 1 } }],
          as: 'attached'
        }
      },
      {
        $lookup: {
          from: 'note',
          let: { id: { $ifNull: [{ $arrayElemAt: ['$attached.reference', 0] }, ''] } },
          pipeline: [{ $match: { $expr: { $and: [{ $eq: ['$_id', '$$id'] }] } } }, { $project: { _id: 1, name: 1, actors: 1 } }],
          as: 'note'
        }
      },
      {
        $addFields: {
          note: { $arrayElemAt: ['$note', 0] },
          attached: { $arrayElemAt: ['$attached', 0] },
          params: { $arrayElemAt: ['$params', 0] },
          fechaVencimiento: { $filter: { input: { $ifNull: ['$dates', []] }, as: 'data', cond: { $eq: ['$$data.type', 'deadline'] } } },
          fechaCreacion: { $filter: { input: { $ifNull: ['$dates', []] }, as: 'data', cond: { $eq: ['$$data.type', 'issue'] } } },
          fechaSeguimiento: { $filter: { input: { $ifNull: ['$dates', []] }, as: 'data', cond: { $eq: ['$$data.type', 'trackingDate'] } } },
        }
      },
      {
        $addFields: {
          fechaVencimiento: { $ifNull: [{ $arrayElemAt: ['$fechaVencimiento.value', 0] } ,'' ]},
          fechaCreacion: { $ifNull: [{ $arrayElemAt: ['$fechaCreacion.value', 0] } ,'' ]},
          fechaSeguimiento: { $ifNull: [{ $arrayElemAt: ['$fechaSeguimiento.value', 0] } ,'' ]},
          tag: { $arrayElemAt: ['$attached.tags', 0] },
          UnidadResponsable: { $filter: { input: { $ifNull: ['$actors', []] }, as: 'data', cond: { $eq: ['$$data.role', 'inCharge'] } } },
          UnidadDe: { $filter: { input: { $ifNull: ['$note.actors', []] }, as: 'data', cond: { $eq: ['$$data.role', 'from'] } } },
          UnidadRevisora: { $filter: { input: { $ifNull: ['$note.actors', []] }, as: 'data', cond: { $eq: ['$$data.role', 'reviser'] } } },
        }
      },
      {
        $addFields: {
          UnidadResponsable: { $ifNull: [{ $arrayElemAt: ['$UnidadResponsable.unit', 0] } ,0 ]},
          UnidadDe: { $ifNull: [{ $arrayElemAt: ['$UnidadDe.unit', 0] }, 0] },
          UnidadRevisora: { $ifNull: [{ $arrayElemAt: ['$UnidadRevisora.unit', 0] },0]},
          etiqueta: { $filter: { input: { $ifNull: ['$params.options', []] }, as: 'data', cond: { $eq: [{ toString: '$$data.id'}, { toString: '$tag'}] } } },
        }
      },
      { $match: responsibleMatch },
      {
        $addFields: {
          etiqueta: { $arrayElemAt: ['$etiqueta',0] }
        }
      },
      {
        $project: {
          Asunto: '$name',
          fechaCreacion: '$fechaCreacion',
          fechaVencimiento: '$fechaVencimiento',
          fechaSeguimiento: '$fechaSeguimiento',
          UnidadDe: { $cond: { if: { $eq: ['$UnidadDe', 0] }, then: '', else: { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', '$UnidadDe'] }] }, ''] } } },
          UnidadRevisora: { $cond: { if: { $eq: ['$UnidadRevisora', 0] }, then: '', else: { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', '$UnidadRevisora' ] }] }, ''] } } },
          UnidadResponsable: { $cond: { if: { $eq: ['$UnidadResponsable', 0] }, then: '', else: { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', '$UnidadResponsable' ] }]}, ''] } } },
          etiqueta: { $ifNull: ['$etiqueta.value','']}
        }
      }
    ]
    mongo.aggregate('commitment', pipeline, { allowDiskUse: true }, (err, result) => {
      if (err) {
        send({ type: 'error', message: err })
      } else {
        var data = []
        for (let i in result) {
          if ((result[i].fechaCreacion && result[i].fechaVencimiento) && result[i].fechaCreacion > result[i].fechaVencimiento) {
            data.push(result[i])
          }
        }
        send(data)
      }
    })
  }
  ///for unit
  async responseTimeCommitment (req, mongo, send) {
    let initialMatch = {}
    let responsibleMatch = {}
    var dependents = []
    if (req.query.plans) {
      let plans = req.query.plans.split(',')
      let plansIds = []
      for (let p in plans) {
        plansIds.push(mongo.toId(plans[p]))
      }
      initialMatch['plan'] = { $in: plansIds }
    }
    if(req.query.dateRange) {
      initialMatch['_id'] = { $gte: mongo.newId(new Date(req.query.dateRange.split(' - ')[0])), $lt: mongo.newId(new Date(req.query.dateRange.split(' - ')[1])) }
    }
    if (req.query.unit) {
      let units = req.query.unit.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      await this.dependentUnits(mongo, units, dependents)
      dependents = dependents.concat(units)
      initialMatch['actors'] = { $elemMatch: { unit: { $in: dependents }, role: 'supervisor', path: { $ne: 'hidden' } } }
    }
    if (req.query.unitsFilter) {
      let units = req.query.unitsFilter.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      responsibleMatch = { areaResponsableCompromiso: { $in: units } }
    }
    var pipeline = [
      { $match: initialMatch },
      {
        $lookup: {
          from: 'unit',
          pipeline: [{ $project: { _id: 1, name: 1 } }],
          as: 'tunit'
        }
      },
      {
        $lookup: {
          from: 'user',
          pipeline: [{ $project: { _id: { $toString: '$_id' }, name: 1 } }],
          as: 'tuser'
        }
      },
      {
        $lookup: {
          from: 'params',
          pipeline: [
            { $match: { $expr: { $and: [{ $eq: ['$name', 'attachedTag'] }] } } },
            { $project: { _id: 0, options: 1 } }
          ],
          as: 'params'
        }
      },
      {
        $lookup: {
          from: 'plan',
          pipeline: [{ $project: { _id: { $toString: '$_id' }, name: 1 } }],
          as: 'tplan'
        }
      },
      {
        $lookup: {
          from: 'event',
          let: { id: '$_id' },
          pipeline: [{ $match: { $expr: { $and: [{ $eq: ['$docId', '$$id'] }, { $eq: ['$data', 'ready'] }] } } }, { $project: { _id: 1, data: 1, date: 1 } }],
          as: 'fechaRegistro'
        }
      },
      {
        $lookup: {
          from: 'event',
          let: { id: '$_id' },
          pipeline: [{ $match: { $expr: { $and: [{ $eq: ['$docId', '$$id'] }, { $eq: ['$data', 'completed'] }] } } }, { $project: { _id: 1, data: 1, date: 1 } }],
          as: 'fechaCalificacion'
        }
      },
      {
        $lookup: {
          from: 'attached',
          let: { id: '$reference' },
          pipeline: [{ $match: { $expr: { $and: [{ $eq: ['$_id', '$$id'] }] } } }, { $project: { _id: 1, dates: 1, name: 1, actors: 1, reference: 1, tags: 1, sequence: 1, attachedTag: 1 } }],
          as: 'attached'
        }
      },
      {
        $lookup: {
          from: 'note',
          let: { id: { $ifNull: [{ $arrayElemAt: ['$attached.reference', 0] }, ''] } },
          pipeline: [{ $match: { $expr: { $and: [{ $eq: ['$_id', '$$id'] }] } } }, { $project: { _id: 1, name: 1, plan: 1 } }],
          as: 'note'
        }
      },
      {
        $addFields: {
          enteFiscalizador: { $filter: { input: { $ifNull: [{ $arrayElemAt: ['$attached.actors', 0] }, []] }, as: 'data', cond: { $eq: ['$$data.path', 'sent'] } } },
          auditor: { $filter: { input: '$actors', as: 'data', cond: { $eq: ['$$data.role', 'supervisor'] } } },
          auditado: { $filter: { input: '$actors', as: 'data', cond: { $eq: ['$$data.role', 'inCharge'] } } },
          actorsAtt: { $ifNull: [{ $arrayElemAt: ['$attached.actors', 0] }, []] },
          trimestreCompromiso: { $filter: { input: '$dates', as: 'data', cond: { $eq: ['$$data.type', 'issue'] } } },
          trimestreAnexo: { $filter: { input: { $ifNull: [{ $arrayElemAt: ['$attached.dates', 0] }, []] }, as: 'data', cond: { $eq: ['$$data.type', 'issue'] } } },
          param: { $arrayElemAt: ['$params', 0] },
          tags: { $ifNull: [{ $arrayElemAt: ['$attached.attachedTag', 0] }, ''] },
        }
      },
      {
        $addFields: {
          auditor: { $arrayElemAt: ['$auditor.user', 0] },
          enteFiscalizador: { $arrayElemAt: ['$enteFiscalizador.unit', 0] },
          auditado: { $arrayElemAt: ['$auditado.user', 0] },
          areaAnexo: { $filter: { input: '$actorsAtt', as: 'data', cond: { $eq: ['$$data.path', 'sent'] } } },
          areaResponsableCompromiso: { $arrayElemAt: ['$auditado.unit', 0] },
          notePlan: { $ifNull: [{ $arrayElemAt: ['$note.plan', 0] }, 0] },
          trimestreCompromiso: { $ifNull: [{ $arrayElemAt: ['$trimestreCompromiso', 0] }, ''] },
          trimestreAnexo: { $ifNull: [{ $arrayElemAt: ['$trimestreAnexo', 0] }, ''] },
          param: { $ifNull: [{ $arrayElemAt: ['$params.options', 0] }, []] },
          tags: { $ifNull: ['$tags', ''] },
        }
      },
      { $match: responsibleMatch },
      {
        $addFields: {
          trimestreCompromiso: { $cond: [{ $eq: [{ $type: '$trimestreCompromiso.value' }, 'string'] }, '', { $ifNull: [{ $month: '$trimestreCompromiso.value' }, ''] }] },
          añoCompromiso: { $cond: [ { $eq: [ { $type: '$trimestreCompromiso.value' }, 'string' ] }, '', { $ifNull: [{ $year: '$trimestreCompromiso.value' }, ''] } ] } ,
          añoAnexo: { $cond: [ { $eq: [ { $type: '$trimestreAnexo.value' }, 'string' ] }, '', { $ifNull: [{ $year: '$trimestreAnexo.value' }, ''] } ] } ,
          trimestreAnexo: { $cond: [ { $eq: [ { $type: '$trimestreAnexo.value' }, 'string' ] }, '', { $ifNull: [{ $month: '$trimestreAnexo.value' }, ''] } ] } ,
          //añoCompromiso: { $ifNull: [{ $year: '$trimestreCompromiso.value' }, ''] },
          //añoAnexo: { $ifNull: [{ $year: '$trimestreAnexo.value' }, ''] },
          //trimestreAnexo: { $ifNull: [{ $month: '$trimestreAnexo.value' }, ''] },
          tags: { $cond: { if: { $ne: [ '$tags', '' ] }, then: { $ifNull: [{ $arrayElemAt: ['$param.value', { $indexOfArray: ['$param.id', '$tags'] }] }, ''] }, else: '' } } ,
        }
      },
      {
        $addFields: {
          trimestreAnexo: { $cond: { if: { $lte: [ '$trimestreAnexo', 3 ] }, then: 'I', else: { $cond: { if: { $lte: [ '$trimestreAnexo', 6 ] }, then: 'II', else: { $cond: { if: { $lte: [ '$trimestreAnexo', 9 ] }, then: 'III', else: { $cond: { if: { $lte: [ '$trimestreAnexo', 12 ] }, then: 'IV', else: '' } } } } } } } },
          trimestreCompromiso: { $cond: { if: { $lte: [ '$trimestreCompromiso', 3 ] }, then: 'I', else: { $cond: { if: { $lte: [ '$trimestreCompromiso', 6 ] }, then: 'II', else: { $cond: { if: { $lte: [ '$trimestreCompromiso', 9 ] }, then: 'III', else: { $cond: { if: { $lte: [ '$trimestreCompromiso', 12 ] }, then: 'IV', else: '' } } } } } } } },
          anexosEnProceso: { $cond: { if: { $in: [ '$status', ['processing', 'answered'] ] }, then: 1, else: 0 } },
          anexosCompletados: { $cond: { if: { $in: ['$status', ['completed', 'done', 'archived']] }, then: 1, else: 0 } },
          compromisosProgramados: { $cond: { if: { $ne: ['$status', 'draft'] }, then: 1, else: 0 } },
          compromisosPendientes: { $cond: { if: { $eq: ['$status', 'ready'] }, then: 1, else: 0 } },
          compromisosCumplidos: { $cond: { if: { $in: ['$status', ['done', 'incomplete']] }, then: 1, else: 0 } },
        }
      },
      {
        $addFields: {
          anexosProgramados: { $cond: { if: { $or: [ { $eq: ['$anexosEnProceso', 1] }, { $eq: ['$anexosCompletados', 1] } ] }, then: 1, else: 0 } },
          fechaRegistro: { $ifNull: [{ $arrayElemAt: ['$fechaRegistro.date',0]}, ''] },
          fechaCalificacion: { $ifNull: [{ $arrayElemAt: ['$fechaCalificacion.date',0]}, ''] },
        }
      },
      {
        $addFields: {
          dayssince: { $cond: { if: { $and: [ { $ne: [ '$fechaRegistro', '' ] }, { $ne: [ '$fechaCalificacion', '' ] }] }, then: {
            $trunc: {
              $divide: [{ $subtract: ['$fechaCalificacion', '$fechaRegistro'] }, 1000 * 60 * 60 * 24]
            }
          }, else: 0 } }
        }
      },
      {
        $project: {
          etiquetaAnexo: '$tags',
          auditor: { $ifNull: [{ $arrayElemAt: ['$tuser.name', { $indexOfArray: ['$tuser._id', { $toString: '$auditor' }] }] }, ''] },
          auditado: { $ifNull: [{ $arrayElemAt: ['$tuser.name', { $indexOfArray: ['$tuser._id', { $toString: '$auditado' }] }] }, ''] },
          evento: { $ifNull: ['$event', ''] },
          anexo: {$concat: [{ $ifNull: [{ $toString: { $arrayElemAt: ['$attached.sequence.text', 0] }}, ''] }, ' - ', { $ifNull: [{ $toString: { $arrayElemAt: ['$attached.name', 0] }}, ''] }]},
          areaResponsableCompromiso: { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', { $ifNull: ['$areaResponsableCompromiso', ''] }] }] }, ''] },
          areaAnexo: { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', { $ifNull: [{ $arrayElemAt: ['$areaAnexo.unit', 0] }, ''] }] }] }, ''] },
          enteFiscalizador: { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', '$enteFiscalizador' ] }] }, ''] },
          trimestreCompromiso: { $ifNull: ['$trimestreCompromiso', ''] },
          añoCompromiso: { $ifNull: ['$añoCompromiso', ''] },
          trimestreAnexo: { $ifNull: ['$trimestreAnexo', ''] },
          añoAnexo: { $ifNull: ['$añoAnexo', ''] },
          plan: { $cond: { if: { $eq: ['$notePlan', 0] }, then: '', else: { $arrayElemAt: ['$tplan.name', { $indexOfArray: ['$tplan._id', { $toString: '$notePlan' }] }] } } },
          estado: '$status',
          anexosProgramados: '$anexosProgramados',
          anexosEnProceso: '$anexosEnProceso',
          anexosCompletados: '$anexosCompletados',
          compromisosProgramados: '$compromisosProgramados',
          compromisosPendientes: '$compromisosPendientes',
          compromisosCumplidos: '$compromisosCumplidos',
          diasHabiles: { $ifNull: ['$dayssince','']}
        }
      }
    ]
    mongo.aggregate('commitment', pipeline, { allowDiskUse: true }, (err, result) => {
      if (err) {
        send({ type: 'error', message: err })
      } else {
        send(result)
      }
    })
  }
  ///for unit
  async historyAttached (req, mongo, send) {
    let initialMatch = { status: { $ne: 'prepared' } }
    let responsibleMatch = {}
    var dependents = []
    if (req.query.dateRange) {
      initialMatch['_id'] = { $gte: mongo.newId(new Date(req.query.dateRange.split(' - ')[0])), $lt: mongo.newId(new Date(req.query.dateRange.split(' - ')[1])) }
    }
    if (req.query.unit) {
      let units = req.query.unit.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      await this.dependentUnits(mongo, units, dependents)
      dependents = dependents.concat(units)
      initialMatch['actors'] = { $elemMatch: { unit: { $in: dependents }, role: 'from', path: { $ne: 'hidden' } } }
    }
    if (req.query.unitsFilter) {
      let units = req.query.unitsFilter.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      responsibleMatch = { responsable: { $in: units } }
    }
    var pipeline = [
      {
        $lookup: {
          from: 'unit',
          pipeline: [{ $project: { _id: 1, name: 1 } }],
          as: 'tunit'
        }
      },
      {
        $lookup: {
          from: 'params',
          pipeline: [
            { $match: { $expr: { $and: [{ $eq: ['$name', 'attachedTag'] }] } } },
            { $project: { _id: 0, options: 1 } }
          ],
          as: 'params'
        }
      },
      {
        $addFields: {
          auditor: { $filter: { input: '$actors', as: 'data', cond: { $eq: ['$$data.path', 'sent'] } } },
          responsable: { $filter: { input: '$actors', as: 'data', cond: { $eq: ['$$data.role', 'responsible'] } } },
          trimestreAnexo: { $filter: { input: { $ifNull: ['$dates', []] }, as: 'data', cond: { $eq: ['$$data.type', 'deadline'] } } },
          param: { $arrayElemAt: ['$params', 0] },
          tags: { $ifNull: ['$attachedTag', ''] },
        }
      },
      {
        $addFields: {
          auditor: { $arrayElemAt: ['$auditor.unit', 0] },
          responsable: { $arrayElemAt: ['$responsable.unit', 0] },
          trimestreAnexo: { $ifNull: [{ $arrayElemAt: ['$trimestreAnexo', 0] }, ''] },
          anexosEnProceso: { $cond: { if: { $in: [ '$status', ['processing', 'answered'] ] }, then: 1, else: 0 } },
          anexosCompletados: { $cond: { if: { $in: [ '$status', ['completed', 'done', 'archived'] ] }, then: 1, else: 0 } },
          param: { $ifNull: [{ $arrayElemAt: ['$params.options', 0] }, []] },
          tags: { $ifNull: ['$tags', ''] },
        }
      },
      { $match: responsibleMatch },
      {
        $addFields: {
          anexosProgramados: { $cond: { if: { $or: [ { $eq: ['$anexosEnProceso', 1] }, { $eq: ['$anexosCompletados', 1] } ] }, then: 1, else: 0 } },
          trimestreAnexo: { $ifNull: [{ $month: '$trimestreAnexo.value' }, ''] },
          añoAnexo: { $ifNull: [{ $year: '$trimestreAnexo.value' }, ''] },
          tags: { $cond: { if: { $ne: [ '$tags', '' ] }, then: { $ifNull: [{ $arrayElemAt: ['$param.value', { $indexOfArray: ['$param.id', '$tags'] }] }, ''] }, else: '' } } ,
        }
      },
      {
        $addFields: {
          trimestreAnexo: { $cond: { if: { $lte: [ '$trimestreAnexo', 3 ] }, then: 'I', else: { $cond: { if: { $lte: [ '$trimestreAnexo', 6 ] }, then: 'II', else: { $cond: { if: { $lte: [ '$trimestreAnexo', 9 ] }, then: 'III', else: { $cond: { if: { $lte: [ '$trimestreAnexo', 12 ] }, then: 'IV', else: '' } } } } } } } }
        }
      },
      {
        $project: {
          etiquetaAnexo: '$tags',
          enteFiscalizador: { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', '$auditor'] }] }, ''] },
          unidadResponsable: { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', '$responsable' ] }] }, ''] },
          trimestreAnexo: '$trimestreAnexo',
          añoAnexo: '$añoAnexo',
          estado: '$status',
          nombre: '$name',
          anexosProgramados: '$anexosProgramados',
          anexosEnProceso: '$anexosEnProceso',
          anexosCompletados: '$anexosCompletados'
        }
      }
    ]
    mongo.aggregate('attached', pipeline, { allowDiskUse: true }, (err, result) => {
      if (err) {
        send({ type: 'error', message: err })
      } else {
        send(result)
      }
    })
  }
  // por ejecutor
  async attachedByEjecutor (req, mongo, send) {
    let initialMatch = { status: { $ne: 'prepared' } }
    let ejecutorMatch = {}
    if (req.query.dateRange) {
      initialMatch['_id'] = { $gte: mongo.newId(new Date(req.query.dateRange.split(' - ')[0])), $lt: mongo.newId(new Date(req.query.dateRange.split(' - ')[1])) }
    }
    if (req.query.unitsFilter) {
      let units = req.query.unitsFilter.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      ejecutorMatch = { ejecutor: { $in: units } }
    }
    var pipeline = [
      { $match: initialMatch },
      {
        $lookup: {
          from: 'unit',
          pipeline: [{ $project: { _id: 1, name: 1 } }],
          as: 'tunit'
        }
      },
      {
        $addFields: {
          ejecutor: { $filter: { input: '$actors', as: 'data', cond: { $eq: ['$$data.role', 'from'] } } }
        }
      },
      {
        $addFields: {
          ejecutor: { $arrayElemAt: ['$ejecutor.unit', 0] },
          anexosEnProceso: { $cond: { if: { $in: [ '$status', ['processing', 'answered'] ] }, then: 1, else: 0 } },
          anexosCompletados: { $cond: { if: { $in: [ '$status', ['completed', 'done', 'archived'] ] }, then: 1, else: 0 } }
        }
      },
      { $match: ejecutorMatch },
      {
        $addFields: {
          anexosProgramados: { $cond: { if: { $or: [ { $eq: ['$anexosEnProceso', 1] }, { $eq: ['$anexosCompletados', 1] } ] }, then: 1, else: 0 } }
        }
      },
      {
        $project: {
          enteFiscalizador: { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', '$ejecutor'] }] }, ''] },
          estado: '$status',
          nombre: '$name',
          anexosProgramados: '$anexosProgramados',
          anexosEnProceso: '$anexosEnProceso',
          anexosCompletados: '$anexosCompletados'
        }
      }
    ]
    mongo.aggregate('attached', pipeline, { allowDiskUse: true }, (err, result) => {
      if (err) {
        send({ type: 'error', message: err })
      } else {
        send(result)
      }
    })
  }
  ///for unit
  async recommendations (req, mongo, send) {
    var dependents = []
    let initialMatch = {}
    if(req.query.dateRange) {
      //initialMatch['_id'] = { $gte: mongo.newId(new Date(req.query.dateRange.split(' - ')[0])), $lt: mongo.newId(new Date(req.query.dateRange.split(' - ')[1])) }
      initialMatch['dates.0.value'] = { $gte: new Date(req.query.dateRange.split(' - ')[0]), $lt: new Date(req.query.dateRange.split(' - ')[1]) }
    }
    if (req.query.unit) {
      let units = req.query.unit.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      await this.dependentUnits(mongo, units, dependents)
      dependents = dependents.concat(units)
      initialMatch['actors'] = { $elemMatch: { unit: { $in: dependents }, role: 'from', path: { $ne: 'hidden' } } }
    }
    if (req.query.unitsFilter) {
      let units = req.query.unitsFilter.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      initialMatch['actors'] = { $elemMatch: { unit: { $in: units }, role: 'responsible', path: { $ne: 'hidden' } } }
    }
    var pipeline = [
      { $match: initialMatch },
      { $lookup: { from: 'unit', pipeline: [{ $project: { _id: { $toString: '$_id' }, name: 1 } }], as: 'tunit' } },
      { $lookup: { from: 'user', pipeline: [{ $project: { _id: { $toString: '$_id' }, name: 1 } }], as: 'tuser' } },
      {
        $lookup: {
          from: 'params', let: {risk: '$risk'},
          pipeline: [
            { $match: { $expr: { $eq: ['$name', 'riskLevel'] } } },
            { $unwind: '$options' },
            { $replaceRoot: {newRoot: '$options'}},
            { $match: { $expr: { $eq: ['$id', '$$risk'] } } }
          ],
          as: 'params'
        }
      },
      { $lookup: { from: 'note', localField: 'reference', foreignField: '_id', as: 'tnote' } },
      {
        $addFields: {
          nameN: { $ifNull: [{ $arrayElemAt: ['$tnote.name', 0] }, ''] },
          actorsN: { $ifNull: [{ $arrayElemAt: ['$tnote.actors', 0] }, []] },
          datesN: { $ifNull: [{ $arrayElemAt: ['$tnote.dates', 0] }, []] },
          statusN: { $ifNull: [{ $arrayElemAt: ['$tnote.status', 0] }, ''] }
        }
      },
      {
        $lookup: {
          from: 'commitment',
          let: { id: '$_id' },
          pipeline: [
            { $match: { $expr: { $and: [{ $eq: ['$reference', '$$id'] }] } } },
            { $project: { _id: 0, dates: 1, extension: 1 } }
          ],
          as: 'commitments'
        }
      },
      {
        $lookup: {
          from: 'event',
          let: { id: '$_id' },
          pipeline: [
            { $match: { $expr: { $and: [{ $eq: ['$docId', '$$id'] }, { $eq: ['$data', 'completed'] }] } } },
            { $limit: 1 },
            { $sort: { _id: -1 } },
            { $project: { _id: 0, date: 1 } }
          ],
          as: 'eventAtt'
        }
      },
      { $unwind: { path: '$commitments', preserveNullAndEmptyArrays: true } },
      {
        $addFields: {
          actors: { $filter: { input: '$actorsN', as: 'data', cond: { $eq: ['$$data.role', 'to'] } } },
          from: { $filter: { input: '$actorsN', as: 'data', cond: { $eq: ['$$data.path', 'sent'] } } },
          reviser: { $filter: { input: '$actors', as: 'data', cond: { $eq: ['$$data.role', 'reviser'] } } },
          responsible: { $filter: { input: '$actors', as: 'data', cond: { $eq: ['$$data.role', 'responsible'] } } },
          supervisor: { $filter: { input: '$actors', as: 'data', cond: { $or: [{ $eq: ['$$data.path', 'sent'] }, { $eq: ['$$data.supervisor', '1'] }] } } },
          path: { $filter: { input: '$actors', as: 'data', cond: { $eq: ['$$data.role', 'from'] } } },
          issue: { $filter: { input: '$datesN', as: 'data', cond: { $eq: ['$$data.type', 'issue'] } } },
          deadlineNote: { $filter: { input: '$datesN', as: 'data', cond: { $eq: ['$$data.type', 'deadline'] } } },
          deadline: { $filter: { input: '$commitments.dates', as: 'data', cond: { $eq: ['$$data.type', 'deadline'] } } },
          answer: { $filter: { input: '$commitments.dates', as: 'data', cond: { $eq: ['$$data.type', 'answered'] } } },
          firstCommitment: { $ifNull: [{ $arrayElemAt: ['$commitments.extension.deadline', 0] }, ''] },
          eventAtt: { $ifNull: [{ $arrayElemAt: ['$eventAtt.date', 0] }, ''] }
        }
      },
      {
        $addFields: {
          risk: { $ifNull: [{ $arrayElemAt: ['$tags', 0] }, ''] },
          param: { $arrayElemAt: ['$params', 0] },
          reviserUser: { $arrayElemAt: ['$supervisor.user', 0] },
          reviserUnit: { $arrayElemAt: ['$supervisor.unit', 0] },
          //responsible: { $ifNull: [{ $arrayElemAt: [{ $split: ['$responsible', '&unit='] }, 0] }, ''] },
          //responsibleUnit: { $ifNull: [{ $arrayElemAt: [{ $split: ['$responsible', '&unit='] }, 1] }, ''] },
          responsibleUser: { $arrayElemAt: ['$responsible.user', 0] },
          responsibleUnit: { $arrayElemAt: ['$responsible.unit', 0] },
          toUser: { $arrayElemAt: ['$actors.user', 0] },
          toUnit: { $arrayElemAt: ['$actors.unit', 0] },
          fromUser: { $arrayElemAt: ['$from.user', 0] },
          fromUnit: { $arrayElemAt: ['$from.unit', 0] }
        }
      },
      {
        $project: {
          asuntoAnexo: { $ifNull: ['$name', ''] },
          estadoAnexo: { $ifNull: ['$status', ''] },
          asuntoNota: { $ifNull: ['$nameN', ''] },
          estadoNota: { $ifNull: ['$statusN', ''] },
          de: { $ifNull: [{ $arrayElemAt: ['$tuser.name', { $indexOfArray: ['$tuser._id', { $toString: '$fromUser' }] }] }, ''] },
          unidadDe: { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', { $toString: '$fromUnit' }] }] }, ''] },
          para: { $ifNull: [{ $arrayElemAt: ['$tuser.name', { $indexOfArray: ['$tuser._id', { $toString: '$toUser' }] }] }, ''] },
          unidadPara: { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', { $toString: '$toUnit' }] }] }, ''] },
          supervisor: { $ifNull: [{ $arrayElemAt: ['$tuser.name', { $indexOfArray: ['$tuser._id', { $toString: '$reviserUser' }] }] }, ''] },
          unidadSupervisor: { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', { $toString: '$reviserUnit' }] }] }, ''] },
          //responsable: { $ifNull: [{ $arrayElemAt: ['$tuser.name', { $indexOfArray: ['$tuser._id', { $toString: '$responsibleUser' }] }] }, ''] },
          //unidadResponsable: { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', { $toString: '$responsibleUnit' }] }] }, ''] },
          responsable: { $cond: [{ $eq: [{ $indexOfArray: ['$tuser._id', { $toString: '$responsibleUser' } ] }, -1] }, '', { $ifNull: [{ $arrayElemAt: ['$tuser.name', { $indexOfArray: ['$tuser._id', { $toString: '$responsibleUser' } ] }] }, ''] }] },
          unidadResponsable: { $cond: [{ $eq: [{ $indexOfArray: ['$tunit._id', { $toString: '$responsibleUnit' } ] }, -1] }, '', { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', { $toString: '$responsibleUnit' }] }] }, ''] }] },
          seleccione: { $ifNull: [{ $arrayElemAt: ['$path.path', 0] }, ''] },
          consecutivo: { $ifNull: ['$sequence.text', ''] },
          fechaPrimerCompromiso: '$firstCommitment',
          fechaPublicacionNota: { $ifNull: [{ $arrayElemAt: ['$issue.value', 0] }, ''] },
          fechaVencimientoNota: { $ifNull: [{ $arrayElemAt: ['$deadlineNote.value', 0] }, ''] },
          fechaVencimiento: { $ifNull: [{ $arrayElemAt: ['$deadline.value', 0] }, ''] },
          fechaRespuesta: { $ifNull: [{ $arrayElemAt: ['$answer.value', 0] }, ''] },
          fechaCompletado: '$eventAtt',
          riesgo: { $ifNull: [{ $arrayElemAt: ['$param.options.value', { $indexOfArray: ['$param.options.id', '$risk'] }] }, ''] },
          //contenido: { $cond: { if: { $eq: [{ $type: '$content' }, 'string' ]}, then: '$content', else: '' } }
        }
      }
    ]
    mongo.aggregate('attached', pipeline, { allowDiskUse: true }, (err, result) => {
      if (err) {
        send({ type: 'error', message: err })
      } else {
        if (req.query.asObject) {
          send(result)
        } else {
          send(result)
        }
      }
    })
  }

  ///for unit
  async commitmentTracking (req, mongo, send) {
    var dependents = []
    let initialMatch = {}
    let responsibleMatch = {}
    if(req.query.dateRange) {
      initialMatch['_id'] = { $gte: mongo.newId(new Date(req.query.dateRange.split(' - ')[0])), $lt: mongo.newId(new Date(req.query.dateRange.split(' - ')[1])) }
    }
    if (req.query.unit) {
      let units = req.query.unit.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      await this.dependentUnits(mongo, units, dependents)
      dependents = dependents.concat(units)
      initialMatch['actors'] = { $elemMatch: { unit: { $in: dependents }, role: 'from', path: { $ne: 'hidden' } } }
    }
    if (req.query.unitsFilter) {
      let units = req.query.unitsFilter.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      responsibleMatch = { responsibleUnit: { $in: units } }
    }
    var pipeline = [
      { $match: initialMatch },
      { $lookup: { from: 'unit', pipeline: [{ $project: { _id: { $toString: '$_id' }, name: 1 } }], as: 'tunit' } },
      { $lookup: { from: 'user', pipeline: [{ $project: { _id: { $toString: '$_id' }, name: 1 } }], as: 'tuser' } },
      { $lookup: { from: 'attached', localField: '_id', foreignField: 'reference', as: 'tattached' } },
      { $unwind: { path: '$tattached' } },
      { $lookup: { from: 'commitment', localField: 'tattached._id', foreignField: 'reference', as: 'tcommitment' } },
      { $unwind: { path: '$tcommitment' } },
      { $lookup: { from: 'evidence', localField: 'tcommitment._id', foreignField: 'reference', as: 'tevidence' } },
      { $lookup: { from: 'comment', localField: 'tcommitment._id', foreignField: 'document', as: 'tcomment' } },
      {
        $lookup: {
          from: 'params',
          pipeline: [
            { $match: { $expr: { $and: [{ $eq: ['$name', 'riskLevel'] }] } } },
            { $project: { _id: 0, options: 1 } }
          ],
          as: 'params'
        }
      },
      {
        $addFields: {
          responsible: { $filter: { input: '$tattached.actors', as: 'data', cond: { $eq: ['$$data.role', 'responsible'] } } },
          auditors: { $filter: { input: '$tcommitment.actors', as: 'data', cond: { $or: [ { $eq: ['$$data.role', 'reviser'] }, { $eq: ['$$data.role', 'supervisor'] } ]} } },
          deadline: { $filter: { input: '$tcommitment.dates', as: 'data', cond: { $eq: ['$$data.type', 'deadline'] } } },
          trackingDate: { $filter: { input: '$tcommitment.dates', as: 'data', cond: { $eq: ['$$data.type', 'trackingDate'] } } },
          risk: { $ifNull: [{ $arrayElemAt: ['$tattached.tags', 0] }, ''] },
          param: { $arrayElemAt: ['$params', 0] },
        }
      },
      {
        $addFields: {
          responsibleUnit: { $arrayElemAt: ['$responsible.unit', 0] },
          responsibleUser: { $arrayElemAt: ['$responsible.user', 0] },
          fechaVencimiento: { $ifNull: [{ $arrayElemAt: ['$deadline.value', 0] }, ''] },
          fechaSeguimiento: { $ifNull: [{ $arrayElemAt: ['$trackingDate.value', 0] }, ''] },
        }
      },
      { $match: responsibleMatch },
      {
        $project: {
          DependenciaAuditada: { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', { $toString: '$responsibleUnit' }] }] }, ''] },
          responsable: { $ifNull: [{ $arrayElemAt: ['$tuser.name', { $indexOfArray: ['$tuser._id', { $toString: '$responsibleUser' }] }] }, ''] },
          Informe: '$name',
          Hallazgo: '$tattached.name',
          Compromiso: '$tcommitment.name',
          estadoCompromiso: '$tcommitment.status',
          cantidadEvidencias: { $size: '$tevidence' },
          Terminado: { $cond: [{ $eq: ['$tcommitment.status', 'done'] }, 'x', ''] },
          Anulado: { $cond: [ { $eq: [ '$tcommitment.status', 'annulled' ] }, 'x', '' ] },
          Vencido: { $cond: [ { $and: [ { $lt: [ '$fechaVencimiento', '$$NOW' ] }, { $ne: [ '$tcommitment.status', 'annulled' ] }, { $ne: [ '$tcommitment.status', 'done' ] }] }, 'x', '' ] },
          NoVencido: { $cond: [ { $and: [ { $gt: [ '$fechaVencimiento', '$$NOW' ] }, { $ne: [ '$tcommitment.status', 'annulled' ] }, { $ne: [ '$tcommitment.status', 'done' ] } ] }, 'x', '' ] },
          fechaVencimiento: '$fechaVencimiento',
          fechaSeguimiento: '$fechaSeguimiento',
          riesgo: { $ifNull: [{ $arrayElemAt: ['$param.options.value', { $indexOfArray: ['$param.options.id', '$risk'] }] }, ''] },
          comentarioAuditor: { $ifNull: [{ $arrayElemAt: ['$tcomment.comment', { $indexOfArray: ['$tunit.user', '$auditors.user'] }] }, ''] },
          contenido: '$tcommitment.content',
        }
      }
    ]
    mongo.aggregate('note', pipeline, { allowDiskUse: true }, (err, result) => {
      if (err) {
        send({ type: 'error', message: err })
      } else {
        if (req.query.asObject) {
          send(result)
        } else {
          send(result)
        }
      }
    })
  }
  ///for unit
  async deadlineRecommendations (req, mongo, send) {
    let initialMatch = {}
    var dependents = []
    if(req.query.dateRange) {
      initialMatch['_id'] = { $gte: mongo.newId(new Date(req.query.dateRange.split(' - ')[0])), $lt: mongo.newId(new Date(req.query.dateRange.split(' - ')[1])) }
    }
    if (req.query.unit) {
      let units = req.query.unit.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      await this.dependentUnits(mongo, units, dependents)
      dependents = dependents.concat(units)
      initialMatch['actors'] = { $elemMatch: { unit: { $in: dependents }, role: 'from', path: { $ne: 'hidden' } } }
    }
    if (req.query.unitsFilter) {
      let units = req.query.unitsFilter.split(',')
      for (let u in units) {
        units[u] = mongo.toId(units[u])
      }
      initialMatch['actors'] = { $elemMatch: { unit: { $in: units }, role: 'responsible', path: { $ne: 'hidden' } } }
    }
    var hoy = new Date()
    var pipeline = [
      { $match: initialMatch },
      {
        $lookup: {
          from: 'commitment',
          let: { id: '$_id' },
          pipeline: [
            { $match: { $expr: { $and: [{ $eq: ['$reference', '$$id'] }] } } },
            { $project: { _id: 0, dates: 1, extension: 1 } }
          ],
          as: 'commitments'
        }
      },
      { $unwind: { path: '$commitments', preserveNullAndEmptyArrays: true } },
      {
        $addFields: {
          deadlineField: {
            $cond: {
              if: { $or: [{ $eq: ['$status', 'completed'] }, { $eq: ['$status', 'answered' ] }] },
              then: '$commitments.dates',
              else: '$dates'
            }
          }
        }
      },
      /* {
        $addFields: {
          deadlines: { $ifNull: [{ $arrayElemAt: ['$dates.value', { $indexOfArray: ['$dates.type', '$deadline'] }] }, ''] }
        }
      }, */
      { $match: { $and: [{ 'deadlineField.1.value': { $lt: hoy } }, { $or: [{ status: { $eq: 'processing' } }, { status: { $eq: 'answered' } } ] }] } },
      { $lookup: { from: 'unit', pipeline: [{ $project: { _id: 1, name: 1 } }], as: 'tunit' } },
      { $lookup: { from: 'user', pipeline: [{ $project: { _id: { $toString: '$_id' }, name: 1 } }], as: 'tuser' } },
      {
        $lookup: {
          from: 'params',
          pipeline: [
            { $match: { $expr: { $and: [{ $eq: ['$name', 'riskLevel'] }] } } },
            { $project: { _id: 0, options: 1 } }
          ],
          as: 'params'
        }
      },
      { $lookup: { from: 'note', localField: 'reference', foreignField: '_id', as: 'tnote' } },
      {
        $addFields: {
          responsible: { $filter: { input: '$actors', as: 'data', cond: { $eq: ['$$data.role', 'responsible'] } } },
          nameN: { $ifNull: [{ $arrayElemAt: ['$tnote.name', 0] }, ''] },
          actors: { $ifNull: [{ $arrayElemAt: ['$tnote.actors', 0] }, []] },
          dates: { $ifNull: [{ $arrayElemAt: ['$tnote.dates', 0] }, []] },
          statusN: { $ifNull: [{ $arrayElemAt: ['$tnote.status', 0] }, ''] },
          sequenceN: { $ifNull: [{ $arrayElemAt: ['$tnote.sequence.text', 0] }, ''] }
        }
      },

      {
        $addFields: {
          actors: { $filter: { input: '$actors', as: 'data', cond: { $eq: ['$$data.role', 'to'] } } },
          from: { $filter: { input: '$actors', as: 'data', cond: { $eq: ['$$data.path', 'sent'] } } },
          reviser: { $filter: { input: '$actors', as: 'data', cond: { $eq: ['$$data.role', 'reviser'] } } },
          supervisor: { $filter: { input: '$actors', as: 'data', cond: { $or: [{ $eq: ['$$data.path', 'sent'] }, { $eq: ['$$data.supervisor', '1'] }] } } },
          path: { $filter: { input: '$actors', as: 'data', cond: { $eq: ['$$data.role', 'from'] } } },
          issue: { $filter: { input: '$dates', as: 'data', cond: { $eq: ['$$data.type', 'issue'] } } },
          deadlineNote: { $filter: { input: '$dates', as: 'data', cond: { $eq: ['$$data.type', 'deadline'] } } },
          deadline: { $filter: { input: '$deadlineField', as: 'data', cond: { $eq: ['$$data.type', 'deadline'] } } },
          answer: { $filter: { input: '$commitments.dates', as: 'data', cond: { $eq: ['$$data.type', 'answered'] } } },
          firstCommitment: { $ifNull: [{ $arrayElemAt: ['$commitments.extension.deadline', 0] }, ''] },
          consecutivo: { $ifNull: ['$sequenceN', ''] },
        }
      },
      {
        $addFields: {
          by: {
            $cond: {
              if: {
                $gt: [{ $size: { $ifNull: ['$reviser', []] } }, 0]
              },
              then: '$reviser',
              else: { $ifNull: ['$path', []] }
            }
          }
        }
      },
      {
        $addFields: {
          consecutivo: { $cond: { if: { $eq: [ '$consecutivo', '' ] }, then: '$sequence.text', else: '$consecutivo' } },
          risk: { $ifNull: [{ $arrayElemAt: ['$tags', 0] }, ''] },
          param: { $arrayElemAt: ['$params', 0] },
          reviserIds: { $filter: { input: '$supervisor.user', as: 'sup', cond: [{ $ne: ['$sup.user', ''] }, '$sup.user', ''] } },
          reviserUnitsIds: { $filter: { input: '$supervisor.unit', as: 'sup', cond: [{ $ne: ['$sup.unit', ''] }, '$sup.unit', ''] } },
          // reviserUser: { $arrayElemAt: ['$supervisor.user', 0] },
          // reviserUser: { $filter: { input: '$supervisor.user', as: 'sup', $cond: [{ $ne: ['$sup.user', ''] }, '$sup.user', ''] /* cond: { $ne: ['$supervisor.user', ''] } */ } },
          // reviserUnit: { $arrayElemAt: ['$supervisor.unit', 0] },
          toUser: { $arrayElemAt: ['$actors.user', 0] },
          toUnit: { $arrayElemAt: ['$actors.unit', 0] },
          fromUser: { $arrayElemAt: ['$from.user', 0] },
          fromUnit: { $arrayElemAt: ['$from.unit', 0] },
          responsibleUser: { $arrayElemAt: ['$responsible.user', 0] },
          responsibleUnit: { $arrayElemAt: ['$responsible.unit', 0] },
        }
      },
      {
        $addFields: {
          revUsers: { $filter: { input: '$tuser', as: 'opt', cond: { $in: [{ $toObjectId: '$$opt._id' }, '$reviserIds'] } } },
          revUnits: { $filter: { input: '$tunit', as: 'opt', cond: { $in: [{ $toObjectId: '$$opt._id' }, '$reviserUnitsIds'] } } }
        }
      },
      {
        $project: {
          asuntoAnexo: { $ifNull: ['$name', ''] },
          estadoAnexo: { $ifNull: ['$status', ''] },
          asuntoNota: { $ifNull: ['$nameN', ''] },
          estadoNota: { $ifNull: ['$statusN', ''] },
          de: { $ifNull: [{ $arrayElemAt: ['$tuser.name', { $indexOfArray: ['$tuser._id', { $toString: '$fromUser' }] }] }, ''] },
          unidadDe: { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', '$fromUnit'] }] }, ''] },
          para: { $ifNull: [{ $arrayElemAt: ['$tuser.name', { $indexOfArray: ['$tuser._id', { $toString: '$toUser' }] }] }, ''] },
          unidadPara: { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', '$toUnit'] }] }, ''] },
          supervisor: { $ifNull: ['$revUsers.name', []] },
          unidadSupervisor: { $ifNull: ['$revUnits.name', []] },
          // supervisor: { $filter: { input: '$reviserUser', as: 'sup', $cond: [{ $ne: ['$sup', ''] }, { $arrayElemAt: ['$tuser.name', { $indexOfArray: ['sup', { $toString: 'sup' }] }] }, ''] } },
          // supervisor: { $ifNull: [{ $arrayElemAt: ['$tuser.name', { $indexOfArray: ['$tuser._id', { $toString: '$reviserUser' }] }] }, ''] },
          responsable: { $ifNull: [{ $arrayElemAt: ['$tuser.name', { $indexOfArray: ['$tuser._id', { $toString: '$responsibleUser' }] }] }, ''] },
          unidadResponsable: { $ifNull: [{ $arrayElemAt: ['$tunit.name', { $indexOfArray: ['$tunit._id', '$responsibleUnit'] }] }, ''] },
          seleccione: { $ifNull: [{ $arrayElemAt: ['$path.path', 0] }, ''] },
          consecutivo: { $ifNull: ['$consecutivo', ''] },
          fechaPrimerCompromiso: '$firstCommitment',
          fechaPublicacionNota: { $ifNull: [{ $arrayElemAt: ['$issue.value', 0] }, ''] },
          fechaVencimientoNota: { $ifNull: [{ $arrayElemAt: ['$deadlineNote.value', 0] }, ''] },
          fechaVencimiento: { $ifNull: [{ $arrayElemAt: ['$deadline.value', 0] }, ''] },
          fechaRespuesta: { $ifNull: [{ $arrayElemAt: ['$answer.value', 0] }, ''] },
          riesgo: { $ifNull: [{ $arrayElemAt: ['$param.options.value', { $indexOfArray: ['$param.options.id', '$risk'] }] }, ''] }
        }
      }
    ]
    mongo.aggregate('attached', pipeline, { allowDiskUse: true }, (err, result) => {
      if (err) {
        send({ type: 'error', message: err })
      } else {
        if (req.query.asObject) {
          send(result)
        } else {
          send(result)
        }
      }
    })
  }

  list (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    var keys = {}
    if (req.query.filter) {
      const query = {}
      for (const name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          if (name === 'units') {
            query.units = { $in: [mongo.toId(req.query.filter.units)] }
          } else if (name === 'name') {
            query.name = new RegExp(req.query.filter.name, 'i')
          } else if (name === 'type') {
            query.type = req.query.filter.type
          }
        }
      }
      keys = query
    }
    if (!req.session.context.licensedUser) {
      keys = { $and: [keys, { units: { $in: req.session.context.managerUnits.concat(req.session.context.assistantUnits.concat(req.session.context.memberUnits)) } }] }
    }
    mongo.find('unit', {}, { _id: 1, name: 1 }, (er, units) => {
      mongo.findN('report', skip, limit, keys, {}, {}, (err, reports) => {
        if (err) {
          send(err)
        } else {
          for (const i in reports) {
            const report = reports[i]
            const unitsname = []
            for (let t = 0; t < units.length; t++) {
              for (const i in report.units) {
                if (units[t]._id.toString() === report.units[i].toString()) {
                  unitsname.push(units[t].name)
                }
              }
            }
            report.id = report._id
            report.unitsname = unitsname
            reply.data.push(report)
          }
          if (skip) {
            send(reply)
          } else {
            mongo.count('report', keys, (err, count) => {
              if (!err && count) {
                reply.total_count = count
              }
              send(reply)
            })
          }
        }
      })
    })
  }

  save (req, mongo, send) {
    var doc = req.body
    mongo.findId('report', req.body._id, (err, report) => {
      if (err) send(err)
      else {
        if (doc.units) {
          doc.units = doc.units.split ? doc.units.split(',') : []
        }
        if (report) {
          report.content = doc.content
          report.name = doc.name
          report.url = doc.url
          report.units = doc.units
          report.initialDate = doc.initialDate
          report.endDate = doc.endDate
          report.plans = doc.plans
          report.type = doc.type
          report.unitsFilter = doc.unitsFilter || ''
          report.deparmentsProjectFilter = doc.deparmentsProjectFilter || ''
          doc = report
        } else {
          if (doc.id) {
            doc._id = mongo.isNativeId(doc.id) ? mongo.toId(doc.id) : mongo.newId()
          }
        }
        mongo.save('report', doc, (err) => {
          if (err) {
            send({ error: err })
          } else {
            send()
            doc.id = doc._id
            notification.send(req, req.session.context.room, 'editors', doc, null, null)
          }
        })
      }
    })
  }

  get (req, mongo, send) {
    var id = req.query._id
    mongo.findId('report', id, (err, report) => {
      if (err) {
        send(err)
      } else {
        send(report)
      }
    })
  }

  duplicate (req, mongo, send) {
    var doc = req.query
    mongo.findId('report', mongo.toId(doc._id), (err, report) => {
      if (err || !report) {
        return send({ error: err })
      } else {
        report._id = mongo.newId()
        report.name = report.name + ' - copy'
        report.duplicated = true
        mongo.save('report', report, (err, result) => {
          send()
          report.id = report._id
          notification.send(req, req.session.context.room, 'editors', report, null, null)
        })
      }
    })
  }

  delete (req, mongo, send) {
    var id = req.query._id
    mongo.findId('report', id, (err, report) => {
      if (err) {
        send({ error: err })
      } else {
        mongo.deleteOne('report', { _id: mongo.toId(id) }, (err) => {
          if (err) {
            req.logger.log(err)
          } else {
            req.app.routes.trash.insert(req, mongo, 'report', report, () => {
              send({})
            })
          }
        })
      }
    })
  }

  async urls (req, mongo, send) {
    var host = 'https://' + req.hostname + '/api/'
    var pipeline = [{ $match: { type: 'form' } }]
    pipeline.push({
      $lookup: {
        from: 'document',
        let: { id: '$_id' },
        pipeline: [
          { $match: { $expr: { $and: [{ $eq: ['$template', '$$id'] }] } } },
          { $project: { _id: 1 } }
        ],
        as: 'doc'
      }
    })
    pipeline.push({
      $match: { 'doc.0': { $exists: 1 } }
    })
    var urls = []
    urls = await new Promise(resolve => {
      mongo.aggregate('template', pipeline, { allowDiskUse: true }, (err, docs) => {
        if (err) console.log(err)
        if (docs && docs.length) {
          for (const i in docs) {
            var url = 'cursor.listData?template=' + docs[i]._id + '&dateRange=# - #'
            urls.push({ id: url, value: '<b>' + docs[i].name + '- </b>' + host + url })
          }
        }
        resolve(urls)
      })
    })
    pipeline = [{ $match: { type: 'form' } }]
    pipeline.push({
      $lookup: {
        from: 'time',
        let: { id: '$_id' },
        pipeline: [
          { $match: { $expr: { $and: [{ $eq: ['$template', '$$id'] }] } } },
          { $project: { _id: 1 } }
        ],
        as: 'doc'
      }
    })
    pipeline.push({
      $match: { 'doc.0': { $exists: 1 } }
    })
    if (!urls) {
      urls=[]
    }
    var urlsTime= await new Promise(resolve => {
      mongo.aggregate('template', pipeline, {}, (err, docs) => {
        if (err) console.log(err)
        if (docs && docs.length) {
          for (const i in docs) {
            var url = 'cursor.listTime?template=' + docs[i]._id + '&dateRange=# - #'
            urls.push({ id: url, value: '<b>' + docs[i].name + '- </b>' + host + url })
          }
        }
        resolve(urls)
      })
    })
    if (urlsTime) {
      urls=urls.concat(urlsTime)
    }
    urls.push(
      { id: 'cursor.time?plans=#', value: '<b>' + 'Tiempo' + '</b> - ' + host + 'cursor.time?plans=#' },
      { id: 'cursor.timeReported?dateRange=# - #', value: '<b>' + 'Tiempos reportados' + ' - </b>' + host + 'cursor.timeReported?dateRange=# - #' },
      { id: 'cursor.timePerformance?dateRange=# - #', value: '<b>' + 'Control registro de horas' + ' - </b>' + host + 'cursor.timePerformance?dateRange=# - #' },
      { id: 'cursor.recommendations?unitsFilter=#&dateRange=# - #', value: '<b>' + 'Recomendaciones' + ' - </b>' + host + 'cursor.recommendations?unitsFilter=#&dateRange=# - #' },
      { id: 'cursor.commitmentTracking?unitsFilter=#&dateRange=# - #', value: '<b>' + 'Seguimiento de Compromisos' + ' - </b>' + host + 'cursor.commitmentTracking?unitsFilter=#&dateRange=# - #' },
      { id: 'cursor.responseTimeCommitment?unitsFilter=#&plans=#&dateRange=# - #', value: '<b>' + 'Tiempo Respuesta Compromisos' + ' - </b>' + host + 'cursor.responseTimeCommitment?unitsFilter=#&plans=#&dateRange=# - #' },
      { id: 'cursor.responseTimeNote?unitsFilter=#&plans=#&deparmentsProjectFilter=#&dateRange=# - #', value: '<b>' + 'Dias Habiles Notas' + ' - </b>' + host + 'cursor.responseTimeNote?unitsFilter=#&plans=#&deparmentsProjectFilter=#&dateRange=# - #' },
      { id: 'cursor.deadlineRecommendations?unitsFilter=#&dateRange=# - #', value: '<b>' + 'Recomendaciones vencidas' + ' - </b>' + host + 'cursor.deadlineRecommendations?unitsFilter=#&dateRange=# - #' },
      { id: 'cursor.historyAttached?unitsFilter=#&dateRange=# - #', value: '<b>' + 'Historico de Anexos' + ' - </b>' + host + 'cursor.historyAttached?unitsFilter=#&dateRange=# - #' },
      { id: 'cursor.attachedByEjecutor?unitsFilter=#&dateRange=# - #', value: '<b>' + 'Anexos por Ejecutor' + ' - </b>' + host + 'cursor.attachedByEjecutor?unitsFilter=#&dateRange=# - #' },
      { id: 'cursor.attachedConsolidated?unitsFilter=#', value: '<b>' + 'Anexos consolidados' + ' - </b>' + host + 'cursor.attachedConsolidated?unitsFilter=#' },
      { id: 'cursor.statisticsAttacheds?unitsFilter=#&dateRange=# - #', value: '<b>' + 'Estadísticas de Anexos' + ' - </b>' + host + 'cursor.statisticsAttacheds?unitsFilter=#&dateRange=# - #' },
      { id: 'cursor.commitmentByRisk?unitsFilter=#&dateRange=# - #', value: '<b>' + 'Compromisos por riesgo' + ' - </b>' + host + 'cursor.commitmentByRisk?unitsFilter=#&dateRange=# - #' },
      { id: 'cursor.commitmentExpired?unitsFilter=#&dateRange=# - #', value: '<b>' + 'Compromisos vencidos por riesgo' + ' - </b>' + host + 'cursor.commitmentExpired?unitsFilter=#&dateRange=# - #' },
      { id: 'cursor.projects?unitsFilter=#&plans=#&dateRange=# - #', value: '<b>' + 'Proyectos' + ' - </b>' + host + 'cursor.projects?unitsFilter=#&plans=#&dateRange=# - #' },
      { id: 'cursor.taskProjects?plans=#', value: '<b>' + 'Tareas de proyectos' + ' - </b>' + host + 'cursor.taskProjects?plans=#' },
      { id: 'cursor.notes?unitsFilter=#&dateRange=# - #', value: '<b>' + 'Notas' + ' - </b>' + host + 'cursor.notes?unitsFilter=#&dateRange=# - #' },
      { id: 'cursor.trainnings?', value: '<b>' + 'Capacitaciones' + ' - </b>' + host + 'cursor.trainnings?' },
      { id: 'cursor.C910?dateRange=# - #', value: '<b>' + 'Reporte para Verificar las fechas de inicio y ejecución de procedimientos #910' + ' - </b>' + host + 'cursor.C910?dateRange=# - #' },
      //facturas
      { id: 'cursor.invoice', value: '<b>' + 'Facturas' + ' - </b>' + host + 'cursor.invoices' },
      { id: 'cursor.invoiceCredit', value: '<b>' + 'Notas de crédito' + ' - </b>' + host + 'cursor.invoiceCredit' },
      { id: 'cursor.invoice2pay', value: '<b>' + 'Facturas de compra' + ' - </b>' + host + 'cursor.invoice2pay' },
      { id: 'event.list', value: '<b>' + 'Eventos de riesgo' + ' - </b>' + host + 'event.list' },
      //indicadores
      // se eliminan porqeu se usan en los dashboards
      /* { id: 'indicator.plannedReal', value: '<b>' + 'Proyectos ejecutados/planeados' + ' - </b>' + host + 'indicator.plannedReal' },
      { id: 'indicator.departmentHours', value: '<b>' + 'Proyectos horas por unidad' + ' - </b>' + host + 'indicator.departmentHours' },
      { id: 'indicator.auditorHours', value: '<b>' + 'Horas por recurso' + ' - </b>' + host + 'indicator.auditorHours' },
      { id: 'indicator.recommendations', value: '<b>' + 'Acuerdos/recomendaciones implementados' + ' - </b>' + host + 'indicator.recommendations' },
      { id: 'indicator.trainningHours', value: '<b>' + 'Horas de capacitación' + ' - </b>' + host + 'indicator.trainningHours' },
      { id: 'indicator.observations', value: '<b>' + 'Tiempo de respuesta promedio' + ' - </b>' + host + 'indicator.observations' },
      { id: 'indicator.projectLate', value: '<b>' + 'Proyectos retrasados' + ' - </b>' + host + 'indicator.projectLate' },
      { id: 'indicator.countAttachedPending', value: '<b>' + 'Recomendaciones pendientes' + ' - </b>' + host + 'indicator.countAttachedPending' },
      { id: 'indicator.countCommitmentPending', value: '<b>' + 'Compromisos pendientes' + ' - </b>' + host + 'indicator.countCommitmentPending' },
      { id: 'indicator.count', value: '<b>' + 'Proyectos activos' + ' - </b>' + host + 'indicator.count' },
      { id: 'indicator.countDocumentsFinds', value: '<b>' + 'Hallazgos u observaciones detectados' + ' - </b>' + host + 'indicator.countDocumentsFinds' },
      { id: 'indicator.projectChartDuration', value: '<b>' + 'Proyectos por etiquetas' + ' - </b>' + host + 'indicator.projectChartDuration' },
      { id: 'indicator.commitmentByRisk', value: '<b>' + 'Compromisos por riesgo' + ' - </b>' + host + 'indicator.commitmentByRisk' },
      { id: 'indicator.commitmentByUnit', value: '<b>' + 'Compromisos por gerencia y riesgo' + ' - </b>' + host + 'indicator.commitmentByUnit' },
      { id: 'indicator.commitmentByEjecutor', value: '<b>' + 'Compromisos por emisor y riesgo' + ' - </b>' + host + 'indicator.commitmentByEjecutor' } */
    )
    send(urls)
  }

  collections (req, mongo, send) {
    mongo.getCollections((err, result) => {
      if (err) {
        console.log(err)
        send()
      } else {
        const data = []
        for (var i in result) {
          if (!result[i].name.includes('fs.')) { data.push({ id: result[i].name, value: result[i].name }) }
        }
        send(data)
      }
    })
  }

  async listData (req, mongo, send) {
    var initialMatch = { template: mongo.toId(req.query.template) }
    if(req.query.dateRange) {
      initialMatch['_id'] = { $gte: mongo.newId(new Date(req.query.dateRange.split(' - ')[0])), $lt: mongo.newId(new Date(req.query.dateRange.split(' - ')[1])) }
    }
    var project = {
      $project: {
        user: { $arrayElemAt: ['$tuser.name', 0] },
        unit: { $arrayElemAt: ['$tunit.name', 0] },
        project: { $arrayElemAt: ['$tproject.name', 0] },
        fecha: { $arrayElemAt: ['$dates.value', 0] },
        sequence: '$sequence.text'
      }
    }
    await new Promise(resolve => {
      mongo.findId('template', mongo.toId(req.query.template), { template: 1 }, (err, doc) => {
        if (!err && doc) {
          doc.template.forEach((field) => {
            if (field.name) {
              project.$project[field.name] = { $ifNull: ['$' + field.name, ''] }
            }
          })
        }
        resolve()
      })
    })
    var pipeline = [
      { $match: initialMatch },
      { $unwind: '$actors' },
      { $match: { 'actors.path': 'sent', 'actors.role': 'reviser' } },
      {
        $lookup: {
          from: 'user',
          localField: 'actors.user',
          foreignField: '_id',
          as: 'tuser'
        }
      },
      { $lookup: { from: 'unit', localField: 'actors.unit', foreignField: '_id', as: 'tunit' } },
      { $lookup: { from: 'project', localField: 'project', foreignField: '_id', as: 'tproject' } },
      project
    ]
    mongo.aggregate('document', pipeline, {}, (err, docs) => {
      if (err)console.log(err)
      send(docs)
    })
  }
  async listTime (req, mongo, send) {
    var match = { template: mongo.toId(req.query.template) }
    if (req.query.dateRange) {
      match['_id'] = { $gte: mongo.newId(new Date(req.query.dateRange.split(' - ')[0])), $lt: mongo.newId(new Date(req.query.dateRange.split(' - ')[1])) }
    }
    var project = {
      $project: {
        plan: { $arrayElemAt: ['$tplan.name', 0] },
        user: { $arrayElemAt: ['$tuser.name', 0] },
        activity: { $arrayElemAt: ['$tactivity.name', 0] },
        unit: { $arrayElemAt: ['$tunit.name', 0] },
        project: { $arrayElemAt: ['$tproject.name', 0] },
        task: { $arrayElemAt: ['$ttask.name', 0] },
        type: 1,
        duration: 1,
        cost: 1,
        date: 1,
      }
    }
    await new Promise(resolve => {
      mongo.findId('template', mongo.toId(req.query.template), { template: 1 }, (err, doc) => {
        if (!err && doc) {
          doc.template.forEach((field) => {
            if (field.name) {
              project.$project[field.name] = { $ifNull: ['$' + field.name, ''] }
            }
          })
        }
        resolve()
      })
    })
    match['unit'] = { $in: req.session.context.managerUnits.concat(req.session.context.assistantUnits) }
    var pipeline = [
      { $match: match },
      { $lookup: { from: 'user', localField: 'actors.user', foreignField: '_id', as: 'tuser' } },
      { $lookup: { from: 'unit', localField: 'unit', foreignField: '_id', as: 'tunit' } },
      { $lookup: { from: 'project', localField: 'project', foreignField: '_id', as: 'tproject' } },
      { $lookup: { from: 'activity', localField: 'document', foreignField: '_id', as: 'tactivity' } },
      { $lookup: { from: 'activityUser', localField: 'document', foreignField: '_id.activity', as: 'tactivityUser' } },
      {
        $addFields: {
          idPlan: { $arrayElemAt: ['$tactivityUser', 0] }
        }
      },
      { $lookup: { from: 'plan', localField: 'idPlan._id.plan', foreignField: '_id', as: 'tplan' } },

      project
    ]
    mongo.aggregate('time', pipeline, {}, (err, docs) => {
      if (err) console.log(err)
      send(docs)
    })
  }

  fields (req, mongo, send) {
    var url = req.query._id.split('&')
    var template
    if (url.length === 2) template = mongo.toId(url[1])
    url = url[0]
    if (url === 'cursor.listData') {
      mongo.findId('template', template, (err, doc) => {
        if (err) {
          send({ type: 'error', message: err })
        } else if (doc) {
          send(doc.template)
        } else {
          send([])
        }
      })
    } else {
      var method = url.split('.')[1]
      if (this[method]) {
        req.query.asObject = true
        this[method](req, mongo, (reply) => {
          var fields = []
          var row = reply.data ? reply.data[0] : reply[0]
          for (const i in row) {
            var type = typeof row[i]
            fields.push({ name: i, view: type })
          }
          send(fields)
        })
      } else {
        send([])
      }
    }
  }
  listPlanned (req, mongo, send) {
    var pipeline = [
      { $limit: 1 },
      {
        $lookup: {
          from: 'task',
          pipeline: [
            { $lookup: { from: 'user', localField: 'owner_id', foreignField: '_id', as: 'tuser' } },
            { $unwind: '$tuser' },
            { $lookup: { from: 'project', localField: 'project', foreignField: '_id', as: 'tproject' } },
            { $unwind: '$tproject' },
            { $lookup: { from: 'plan', localField: 'tproject.plan', foreignField: '_id', as: 'tplan' } },
            { $unwind: '$tplan' },
            { $lookup: { from: 'unit', localField: 'tproject.unit', foreignField: '_id', as: 'tunit' } },
            { $unwind: '$tunit' },
            { $addFields: { jornada: { $cond: { if: { $eq: ['', '$tuser.business.workDay'] }, then: 480, else: '$tuser.business.workDay' } } } },
            { $addFields: { jornada: { $toInt: '$jornada' } } },
            { $addFields: { duracionPlan: { $divide: [{ $ifNull: [{ $toInt: '$duration' }, 0] }, 60] }, goals: '$tplan.goals' } },
            {
              $addFields: {
                idProject: '$tproject._id'
              }
            },
            {
              $addFields: {
                goal: {
                  $function: {
                    body: `function (goals, id) {
                        try {
                            let name = ''
                            if (goals && id) {
                                let exists = false
                                var doc = hex_md5(id.toString())
                                for (var i in goals) {
                                    var goal = goals[i]
                                    if (goal.projects && goal.projects.length){
                                        for (var p in goal.projects) {
                                          if (hex_md5(goal.projects[p].toString()) === doc) {
                                              name = goal.name
                                              exists = true
                                              break
                                          }
                                        }
                                    }
                                    if(exists) break
                                }
                            }
                            return name
                        } catch (err) {
                            return ''
                        }
                      }`,
                    args: ['$goals', '$idProject'],
                    lang: 'js'
                  }
                }
              }
            },
            {
              $project: {
                _id: 0,
                plan: { $ifNull: ['$tplan.name', ''] },
                proyecto: { $ifNull: ['$tproject.name', ''] },
                'actividad/tarea': { $ifNull: ['$text', ''] },
                estado: { $ifNull: ['$status', ''] },
                usuario: { $ifNull: ['$tuser.name', ''] },
                unidad: { $ifNull: ['$tunit.name', ''] },
                duracionPlan: { $ifNull: [{ $round: [ { $toDouble: '$duracionPlan' }, 1 ] }, 0] },
                meta: { $ifNull: ['$goal', ''] },
              }
            }
          ],
          as: 'tasksPlanned'
        }
      },
      {
        $lookup: {
          from: 'activityUser',
          pipeline: [
            { $lookup: { from: 'user', localField: '_id.user', foreignField: '_id', as: 'tuser' } },
            { $unwind: '$tuser' },
            { $lookup: { from: 'plan', localField: '_id.plan', foreignField: '_id', as: 'tplan' } },
            { $unwind: '$tplan' },
            { $lookup: { from: 'activity', localField: '_id.activity', foreignField: '_id', as: 'tactivity' } },
            { $unwind: '$tactivity' },
            { $addFields: { jornada: { $cond: { if: { $eq: ['', '$tuser.business.workDay'] }, then: 480, else: '$tuser.business.workDay' } } } },
            { $addFields: { jornada: { $toInt: '$jornada' } } },
            { $addFields: { duracionPlan: { $divide: [{ $ifNull: [{ $toInt: '$planned' }, 0] }, 60] } } },
            {
              $project: {
                _id: 0,
                plan: { $ifNull: ['$tplan.name', ''] },
                proyecto: { $ifNull: ['', ''] },
                'actividad/tarea': { $ifNull: ['$tactivity.name', ''] },
                estado: { $ifNull: ['', ''] },
                usuario: { $ifNull: ['$tuser.name', ''] },
                unidad: { $ifNull: ['', ''] },
                duracionPlan: { $ifNull: [{ $round: [ { $toDouble: '$duracionPlan' }, 1 ] }, 0] },
                meta: { $ifNull: ['', ''] },
              }
            }
          ],
          as: 'ActsPlanned'
        }
      },
      {
        $project: {
          union: {
            $concatArrays: ['$tasksPlanned', '$ActsPlanned']
          }
        }
      },
      { $unwind: '$union' },
      { $replaceRoot: { newRoot: '$union' } }
    ]
    mongo.aggregate('plan', pipeline, {}, (err, docs) => {
      if (err) {
        send({error: err})
      } else send(docs)
    })
  }
  listReal (req, mongo, send) {
    var start = req.query.start
    var end = req.query.end
    var pipeline = [
      {
        $match: {
          date: { $gte: new Date(start), $lt: new Date(end) }
        }
      },
      { $lookup: { from: 'user', localField: 'user', foreignField: '_id', as: 'tuser' } },
      { $lookup: { from: 'project', localField: 'project', foreignField: '_id', as: 'tproject' } },
      { $unwind: { path: '$tproject', preserveNullAndEmptyArrays: true } },
      { $lookup: { from: 'plan', localField: 'tproject.plan', foreignField: '_id', as: 'tplanProject' } },
      { $lookup: { from: 'plan', localField: 'plan', foreignField: '_id', as: 'tplanAct' } },
      { $lookup: { from: 'task', localField: 'document', foreignField: '_id', as: 'tTask' } },
      { $lookup: { from: 'activity', localField: 'document', foreignField: '_id', as: 'tActivity' } },
      {
        $addFields: {
          minutes: { $cond: { if: { $ne: ['$duration', ''] }, then: { $mod: [{ $toInt: '$duration' }, 60] }, else: '00' } }
        }
      },
      {
        $addFields: {
          hours: { $cond: { if: { $ne: ['$duration', ''] }, then: { $divide: [{ $subtract: [{ $toInt: '$duration' }, '$minutes'] }, 60] }, else: '00' } }
        }
      },
      {
        $addFields: {
          minutes: { $cond: { if: { $ne: ['$minutes', null] }, then: { $cond: { if: { $gt: [{ $strLenCP: { $toString: '$minutes' } }, 1] }, then: '$minutes', else: { $concat: ['0', { $toString: '$minutes' }] } } }, else: '00' } }
        }
      },
      {
        $addFields: {
          hours: { $cond: { if: { $ne: ['$hours', null] }, then: { $cond: { if: { $gt: [{ $strLenCP: { $toString: '$hours' } }, 1] }, then: '$hours', else: { $concat: ['0', { $toString: '$hours' }] } } }, else: '00' } }
        }
      },
      {
        $project: {
          usuario: { $ifNull: [{ $arrayElemAt: ['$tuser.name', 0] }, ''] },
          plan: { $ifNull: [{ $arrayElemAt: ['$tplanProject.name', 0] }, { $ifNull: [{ $arrayElemAt: ['$tplanAct.name', 0] }, ''] }] },
          proyecto: { $ifNull: ['$tproject.name', ''] },
          fecha: { $toDate: { $concat: [{ $dateToString: { format: '%Y-%m-%d', date: '$date', timezone: '-06:00' } }, 'T00:00:00-06:00']} },
          //task: '$task',
          horas: { $concat: [{ $toString: '$hours' }, ':', { $toString: '$minutes' }] },
          'actividad/tarea': { $ifNull: [{ $arrayElemAt: ['$tTask.text', 0] }, { $ifNull: [{ $arrayElemAt: ['$tActivity.name', 0] }, { $ifNull: ['$activity','']}] }] },
          comentarios: '$comment'
        }
      }
    ]
    mongo.aggregate('time', pipeline, {}, (err, docs) => {
      send(docs)
    })
  }

  timeReported (req, mongo, send) {
    var dateRange = {}
    if (req.query.dateRange) {
      dateRange = { 'ttime.date': { $gte: new Date(req.query.dateRange.split(' - ')[0]), $lte: new Date(req.query.dateRange.split(' - ')[1]) } }
    }
    var pipeline = [
      { $lookup: { from: 'time', localField: '_id', foreignField: 'user', as: 'ttime' } },
      { $unwind: '$ttime'},
      { $match: dateRange },
      { $lookup: { from: 'project', localField: 'ttime.project', foreignField: '_id', as: 'tproject' } },
      { $lookup: { from: 'plan', localField: 'ttime.plan', foreignField: '_id', as: 'tplan' } },
      { $lookup: { from: 'unit', localField: 'tproject.unit', foreignField: '_id', as: 'tunitProj' } },
      { $lookup: { from: 'unit', localField: 'tplan.unit', foreignField: '_id', as: 'tunitPlan' } },
      { $lookup: { from: 'task', localField: 'ttime.document', foreignField: '_id', as: 'ttask' } },
      { $lookup: { from: 'activity', localField: 'ttime.document', foreignField: '_id', as: 'tactivity' } },
      {
        $addFields: {
          duracion: { $ifNull: [{ $divide: [{ $toDouble: '$ttime.duration' }, 60] }, 0] },
          hourCost: { $cond: { if: { $eq: ['$ttime.cost', ''] }, then: '', else: '$ttime.cost' } }
        }
      },
      {
        $addFields: {
          hourCost: {
            $cond: {
              if: { $eq: ['$hourCost', ''] },
              then: { $multiply: [{ $toDouble: { $ifNull: ['$duracion', 0] } }, { $toDouble: { $ifNull: ['$business.hourCost', 0] } }] },
              else: '$hourCost'
            }
          }
        }
      },
      {
        $project: { _id: 0,
          proyecto: {
            $cond: {
              if: { $or: [{ $eq: ['$ttime.type', 'task'] }, { $eq: ['$ttime.type', ''] }] },
              then: { $arrayElemAt: ['$tproject.name',0]},
              else: 'Actividades'
            }
          },
          'actividad/tarea': { $ifNull: [{ $arrayElemAt: ['$tactivity.name',0]}, { $ifNull: ['$activity', { $ifNull: [{ $arrayElemAt: ['$ttask.text',0]}, '' ] } ] } ] },
          fecha: { $ifNull: ['$ttime.date', '' ] },
          usuario: { $ifNull: ['$name', '' ] },
          áreaAuditoria: { $ifNull: [{ $arrayElemAt: ['$tunitProj.name',0]}, { $ifNull: [{ $arrayElemAt: ['$tunitPlan.name',0]}, '' ] } ] },
          plan: { $ifNull: [{ $arrayElemAt: ['$tplan.name', 0]}, '' ] },
          'duración(horas)': { $round: ['$duracion', 4 ] },
          'costo(horas)': { $ifNull: [{ $round: ['$hourCost', 2 ] }, 0 ] },
          comentario: { $ifNull: ['$ttime.comment', '' ] },
        }
      }
    ]
    mongo.aggregate('user', pipeline, {}, (err, docs) => {
      send(docs)
    })
  }

  C910 (req, mongo, send) {
    var match = {}
    if (req.query.dateRange) {
      match = { _id: { $gte: mongo.newId(new Date(req.query.dateRange.split(' - ')[0])), $lt: mongo.newId(new Date(req.query.dateRange.split(' - ')[1])) } }
    }
    var pipeline = [
      { $match: match },
      { $lookup: { from: 'plan', localField: 'plan', foreignField: '_id', as: 'tplan' } },
      { $unwind: { path: '$tplan', preserveNullAndEmptyArrays: true } },
      { $lookup: { from: 'task', localField: '_id', foreignField: 'project', as: 'Ttask' } },
      { $unwind: { path: '$Ttask', preserveNullAndEmptyArrays: true } },
      { $match: { 'Ttask.type': { $in: ['milestone', 'task'] }} },
      {
        $addFields: {
          task: '$Ttask'
        }
      },
      { $lookup: { from: 'user', localField: 'task.owner_id', foreignField: '_id', as: 'tuser' } },
      { $unwind: { path: '$tuser', preserveNullAndEmptyArrays: true } },
      {
        $lookup: {
          from: 'time',
          let: { id: '$task._id' },
          pipeline: [
            { $match: { $expr: { $and: [{ $eq: ['$document', '$$id'] }] } } },
            { $sort: { _id: 1 } },
            { $limit: 1 }
          ],
          as: 'tevent' }
      },
      { $unwind: { path: '$tevent', preserveNullAndEmptyArrays: true } },
      {
        $addFields: {
          'task.userName': '$tuser.name',
          'task.projectName': '$name',
          'task.planName': '$tplan.name',
          'task.real_start': '$tevent.date'
        }
      },
      /* {
        $addFields: {
          'task.projectName': '$name'
        }
      }, */
      {
        $project: {
          task: 1
        }
      },
      { $replaceRoot: { newRoot: '$task' } },
      {
        $match: {
          'start_date': {$exists: 1 }
        }
      },
      {
        $sort: {
          _id: -1
        }
      },
      {
        $project: {
          _id: 0,
          tarea: { $ifNull: ['$text', ''] },
          usuario: { $ifNull: ['$userName', ''] },
          proyecto: { $ifNull: ['$projectName', ''] },
          plan: { $ifNull: ['$planName', ''] },
          fechaInicio: { $ifNull: ['$start_date', ''] },
          fechaPrimeraVez: { $ifNull: ['$real_start', ''] }
        }
      }
    ]
    mongo.aggregate('project', pipeline, {}, (err, docs) => {
      send(docs)
    })
  }
}

exports.Cursor = Cursor
