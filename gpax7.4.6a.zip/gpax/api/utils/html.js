/* global Buffer process */
var tags = require('../utils/tags').tags
var mimeTypes = require('mime-types')
var toArray = require('stream-to-array')
var mformats = require('microformat-node')

exports.Html = Html

function Html () {
  this.print = function (html, baseUri) {
    var r = '<!DOCTYPE html>'
    r += '<html>'
    r += '  <head>'
    r += '    <title>Collaborative WEB</title>'
    r += '    <meta name="viewport" content="width=device-width, initial-scale=1"/>'
    r += '    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>'
    r += '    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>'
    r += '    <meta name="format-detection" content="telephone=no">'
    r += '    <meta name="format-detection" content="address=no">'
    r += '    <link rel="shortcut icon" href="img/gpax.ico"/>'
    r += '    <link rel="stylesheet" type="text/css" href="common.css"/>'
    r += '    <link rel="stylesheet" type="text/css" href="dhx/dhtmlx.css"/>'
    r += '    <link rel="stylesheet" type="text/css" href="dhx/dhtmlxgantt.css"/>'
    r += '    <link rel="stylesheet" type="text/css" href="form/dhtmlxfbext.css"/>'
    r += '    <link rel="stylesheet" type="text/css" href="form/formbuilder.css"/>'
    r += '  </head>'
    r += '  <body class="printable" onload="window.print();window.close();">'
    r += html.replace(/file.get/, baseUri + 'file.get')
    r += '  </body>'
    r += '</html>'
    return r
  }

  this.serializeImgs = function (mongo, html, next) {
    this.serializeImg = function (pos) {
      if (pos !== -1) {
        var skip = html.indexOf('src', pos) + 5
        if (skip > pos) {
          var src = html.substring(skip, html.indexOf('"', skip))
          var id = src.substring(src.indexOf('id=') + 3)
          id = id.split('&')[0]
          mongo.getfile(id, (err, stream) => {
            if (!err && stream) {
              toArray(stream, (err, data) => {
                if (!err) {
                  var serializedImg = 'data:' + stream.contentType + ';base64,' + Buffer.from(data[0], 'binary').toString('base64')
                  html = html.replace(src, serializedImg)
                }
                this.serializeImg(html.indexOf('<img ', skip))
              })
            } else {
              this.serializeImg(html.indexOf('<img ', skip))
            }
          })
        } else {
          next(html)
        }
      } else {
        next(html)
      }
    }
    this.serializeImg(html.indexOf('<img'))
  }

  this.pdf = function (mongo, req, htmlSrc, pageType, send) {
    var urlbase = process.cwd()
    if (urlbase.includes('api')) {
      urlbase = 'file://' + urlbase.replace('api', 'ui/codebase/')
    } else {
      urlbase = 'file://' + urlbase + '/ui/codebase/'
    }
    mongo.findOne('settings', { _id: 'settings' }, (err, sett) => {
      if (err) throw err
      var ops
      if (sett && sett.photo && sett.photo.toString && htmlSrc.includes('settings.image')) {
        htmlSrc = htmlSrc.replace(/settings.image/g, 'file.get?_id=' + sett.photo.toString())
      }
      htmlSrc = htmlSrc.replace(/<details >/g, '<details open>')
      htmlSrc = htmlSrc.replace(/<details>/g, '<details open>')
      if (sett && sett.pageFormat) {
        ops = sett.pageFormat
        ops.directory = '/tmp'
        ops.base = urlbase
      } else {
        ops = {
          directory: '/tmp',
          base: urlbase,
          format: 'Letter',
          border: {
            right: '15mm',
            left: '15mm',
            top: '5mm'
          },
          header: { height: '3cm' },
          footer: { height: '3cm' },
          'footer-last': { height: '3cm' }
        }
      }
      if (pageType === 'sticker') {
        ops = {
          width: '99mm', // allowed units: mm, cm, in, px
          height: '49mm',
          border: 0,
          header: { height: '0mm' },
          footer: { height: '0mm' }
        }
      } else if (pageType === 'office') {
        ops.width = '212mm'
        ops.height = '317mm'
        delete ops.format
      } else if (pageType) {
        ops.format = pageType.charAt(0).toUpperCase() + pageType.substr(1).toLowerCase()
      }
      htmlSrc = '<link href="' + urlbase + 'gpax.css" rel="stylesheet" type="text/css">' +
        '<div style="font-size:9px;"><style>.h-card button{visibility:hidden;}</style>' + htmlSrc.replace(/<var/g, '<span').replace(/var>/, 'span>') + '</div>'
      this.serializeImgs(mongo, htmlSrc, function (html) {
        var pdf = require('html-pdf')
        pdf.create(html, ops).toStream((err, stream) => {
          if (!err) {
            stream.contentType = mimeTypes.contentType('file.pdf')
          }
          send(err, stream)
        })
      })
    })
  }
  this.create = function (element) {
    var r = '<!DOCTYPE html>'
    r += '<html>'
    r += '  <head>'
    r += '    <title>Collaborative WEB</title>'
    r += '    <meta name="viewport" content="width=device-width, initial-scale=1"/>'
    r += '    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>'
    r += '    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>'
    r += '    <meta name="format-detection" content="telephone=no">'
    r += '    <meta name="format-detection" content="address=no">'
    r += '    <link rel="shortcut icon" href="img/gpax.ico"/>'
    r += '    <link rel="stylesheet" type="text/css" href="common.css"/>'
    r += '    <link rel="stylesheet" type="text/css" href="dhx/dhtmlx.css"/>'
    r += '    <link rel="stylesheet" type="text/css" href="dhx/dhtmlxgantt.css"/>'
    r += '    <link rel="stylesheet" type="text/css" href="form/dhtmlxfbext.css"/>'
    r += '    <link rel="stylesheet" type="text/css" href="form/formbuilder.css"/>'
    r += '    <link rel="stylesheet" href="jquery/jquery-ui.min.css" />'
    r += '    <script type="text/javascript" src="dhx/dhtmlx.js"></script>'
    r += '    <script type="text/javascript" src="dhx/dhtmlxgantt.js"></script>'
    r += '    <script type="text/javascript" src="redactor/redactor.js"></script>'
    r += '    <script type="text/javascript" src="gojs/go-debug.js"></script>'
    r += '    <script type="text/javascript" src="gojs/BPMNClasses.js"></script>'
    r += '    <script type="text/javascript" src="gojs/bpmn.js"></script>'
    r += '    <script type="text/javascript" src="gojs/DrawCommandHandler.js"></script>'
    r += '    <script type="text/javascript" src="common.js"></script>'
    r += '    <script type="text/javascript" src="dhxform.js"></script>'
    r += '    <script type="text/javascript" src="util/orgchart.js"></script>'
    r += '    <script type="text/javascript" src="util/prochart.js"></script>'
    r += '    <script type="text/javascript" src="form/dhtmlxfbext.js"></script>'
    r += '    <script type="text/javascript" src="form/formbuilder.js"></script>'
    r += '    <script src="jquery/jquery.min.js"></script>'
    r += '    <script src="jquery/jquery-ui.min.js"></script>'
    r += '    <script type="text/javascript">'
    r += '      var obj=' + JSON.stringify(element) + ';'
    r += '      go.licenseKey = "2bf845e0b66e58c511895a2540383bbe5aa16f23c8864ef70d5146a6ba0d6a122391e17854d283c8d2f848fd1a2ec7dccfd56f28c74a043eb43487db43e586fabb6776b61d0d4287a20027c49ea828f5ac7171f595b574a0dd2f9ee2edfd939a5cbaa3d55ada0dba297e1931497da8";'
    r += '    </script>'
    r += '  </head>'
    r += '  <body style="background-color: #ecf7f9;" onload="create(obj,document.body);">'
    r += '  </body>'
    r += '</html>'
    return r
  }

  this.getData = function (html, next) {
    const options = {}
    let word = false
    if (html.compatibilityMode) {
      word = true
    }
    if (word) {
      delete html.next
      delete html.parent
      delete html.prev
      delete html.root
      delete html.parentNode
      html = JSON.stringify(html)
    }
    options.html = html
    options.filter = ['h-card', 'h-entry']
    mformats.get(options, (err, data) => {
      let actors = []

      let links = []
      if (!err && data) {
        actors = getHCards(data)
        links = getLinks(data)
      }
      next({ actors: actors, links: links })
    })

    function getHCards (data) {
      const actors = []

      let user; let unit; let role; let item
      for (const i in data.items) {
        item = data.items[i]
        if (item.type[0] === 'h-card') {
          role = item.properties.role ? item.properties.role[0] : ''
          if (role.indexOf(tags.from) !== -1) {
            role = tags.from
          } else if (role.indexOf(tags.to) !== -1) {
            role = tags.to
          } else if (role.indexOf(tags.copy) !== -1) {
            role = tags.copy
          }
          if (item.properties.org) {
            unit = item.properties.org[0].properties.uid ? item.properties.org[0].properties.uid[0].replace('#', '') : ''
          } else {
            unit = null
          }
          if (item.properties.uid && item.properties.uid.length > 0) {
            user = item.properties.uid[0].replace('#', '')
            const dataUser = user.split('&unit=')
            user = dataUser[0]
            if (dataUser[1]) {
              unit = dataUser[1]
            }
            const j = actors.findIndex(function (u) { return u.user === user })
            if (j === -1) {
              const actor = {
                user: user,
                path: role === tags.from ? tags.sent : tags.received,
                role: role
              }
              if (unit) {
                actor.unit = unit
              }
              actors.push(actor)
            }
          }
        }
      }
      return actors
    }

    function getLinks (data) {
      var links = []
      for (const i in data.items) {
        var item = data.items[i]
        if (item.type && item.type[0] === 'h-entry' && item.properties && item.properties.url && item.properties.url[0] && item.properties.url[0].includes('?')) {
          var clase = item.properties.url[0].split('?')[0].split('.')
          const uid = item.properties.uid ? item.properties.uid[0] : item.properties.url[0].split('?_id=')[1]
          links.push({ _id: uid, clase: clase[0], type: clase[1] })
        }
      }
      return links
    }
  }

  this.timer = function (options) {
    var pos = ''
    if (options.top !== undefined) {
      pos += 'top:' + options.top + 'px;'
    }
    if (options.left !== undefined) {
      pos += 'left:' + options.left + 'px;'
    }
    if (options.bottom !== undefined) {
      pos += 'bottom:' + options.bottom + 'px;'
    }
    if (options.right !== undefined) {
      pos += 'right:' + options.right + 'px;'
    }

    var r = ''
    r += '<div class="drawer" style="' + pos + '">'
    r += ' <img src="/img/reloj.png" id="icon" />'
    r += ' <span id="timer">...</span>'
    r += ' <script>'
    r += ' var myVar = setInterval(myTimer, 1000);'
    r += ' function myTimer() {'
    r += '   var timer=document.getElementById("timer");'
    r += '   if(!timer.initial) timer.initial=new Date();'
    r += '   timer.final=new Date();'
    r += '   timer.innerHTML = new Date(timer.final-timer.initial).toUTCString().split(" ")[4];'
    r += ' }'
    r += ' </script>'
    r += '</div>'
    return {
      floating: r
    }
  }
}
