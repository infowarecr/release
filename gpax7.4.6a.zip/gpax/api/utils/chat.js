/* exported */

exports.Chat = Chat
var HTMLParser = require('node-html-parser');

function Chat () {

  this.get = async function (req, mongo, send) {
    var users = await new Promise(resolve => {
      mongo.toHash('user', { }, { _id: 1, name: 1 }, (er, users) => {
        if (er || !users) {
          resolve()
        } else {
          resolve(users)
        }
      })
    })
    mongo.findId('chat', req.query._id, (err, doc) => {
      if (err) {
        send({ error: err })
      } else {
        if (!doc) {
          doc = {
            _id: mongo.newId(),
            isNew: true,
            actors: [
              {
                user: req.session.context.user,
                role: 'from'
              },
              {
                user: req.query.user,
                role: 'to'
              }
            ],
            lastDate: new Date(),
            messages: []
          }
        }
        for (let m in doc.messages) {
          doc.messages[m].name = users[doc.messages[m].user.toString()].name
        }
        send(doc)
      }
    })
  }

  this.newTeam = async function (req, mongo, send) {
    let doc = {}
    if(req.body.project) {
      let project = await new Promise(resolve => {
        mongo.findId('project', req.body.project, {name: 1, actors: 1}, (err, project) => {
          if (!err) { resolve(project) } else { resolve(false) }
        })
      })
      doc = {
        _id: mongo.newId(),
        name: project.name,
        project: req.body.project,
        isNew: true,
        team: '1',
        actors: [
          {
            user: req.session.context.user,
            role: 'from',
            color: generarColor()
          }
        ],
        lastDate: new Date(),
        messages: []
      }
      for (let i in project.actors) {
        if(project.actors[i].user.toString() !== req.session.context.user.toString()) {
          doc.actors.push({
            user: project.actors[i].user,
            role: 'to',
            color: generarColor()
          })
        }
      }
    } else {
      let ids = req.body.team
      doc = {
        _id: mongo.newId(),
        name: req.body.name,
        isNew: true,
        team: '1',
        actors: [
          {
            user: req.session.context.user,
            role: 'from',
            color: generarColor()
          }
        ],
        lastDate: new Date(),
        messages: []
      }
      for (let i in ids) {
        doc.actors.push({
          user: ids[i],
          role: 'to',
          color: generarColor()
        })
      }
    }
    send(doc)
  }


  this.getReviewers = function (req, mongo, send) {
    var users = []
    var data = []
    let ids = req.query.ids.split(',')
    for (const a in ids) {
      users.push(mongo.toId(ids[a]))
    }
    mongo.toHash('user', { _id: { $in: users } }, { _id: 1, name: 1 }, (_er, users) => {
      for (let u in users) {
        data.push({
          id: users[u]._id,
          name: users[u].name
        })
      }
      send(data)
    })
  }


  function generarColor () {
    return '#000000'.replace(/0/g, function () {
      return (~~(Math.random() * 16)).toString(16);
    })
  }

  this.file = function (req, mongo, send) {
    mongo.savefile(req, async (err, result) => {
      if (!err) {
        var id = result.link
        id = id.split('_id=')[1].split('&')[0]
        result.status = 'server'
        result.id = id
        send(result)
      } else {
        send()
      }
    })
  }

  this.addFileToProject = async function (req, mongo, send) {
    var doc = req.body
    if (doc.project) {
      let proj = await new Promise(resolve => {
        mongo.findId('project', doc.project, { name: 1, actors: 1, files: 1 }, (err, project) => {
          if (!err) { resolve(project) } else { resolve(false) }
        })
      })
      var file = await new Promise(resolve => {
        mongo.findId('fs.files', doc.idFile, (err, file) => {
          if (err) {
            resolve(false)
          } else { resolve(file) }
        })
      })
      if (proj && file) {
        var flag = false
        let type = ''
        if (proj.files) {
          function index (data) {
            for (let i in data) {
              var doc = data[i]
              if (doc.data) { index(doc.data) }
              if (doc.id === ('/api/file.get?_id=' + file._id.toString() + '&type=' + (type === '' ? file.contentType.split('/')[1] : type))) {
                flag = true
                return
              }
            }
          }
          index(proj.files)
        }
        if (!flag) {
          if (proj.files) {
            let f = proj.files[0].data.findIndex((x) => {
              return x.value === 'Archivos del chat'
            })
            if (f !== -1) {
              proj.files[0].data[f].data.push({
                id: '/api/file.get?_id=' + file._id.toString() + '&type=' + (type === '' ? file.contentType.split('/')[1] : type),
                value: file.filename,
                type: type === '' ? file.contentType.split('/')[1] : type,
                size: file.chunkSize,
                date: Number(new Date().getTime().toString().substring(0, 10)),
                reference: '/api/file.get?_id=' + file._id.toString() + '&type=' + (type === '' ? file.contentType.split('/')[1] : type)
              })
            } else {
              proj.files = [
                {
                  value: '/',
                  open: true,
                  type: 'folder',
                  date: new Date(),
                  data: [{
                    value: 'Archivos del chat',
                    open: true,
                    type: 'folder',
                    date: new Date(),
                    data: [{
                      id: '/api/file.get?_id=' + file._id.toString() + '&type=' + (type === '' ? file.contentType.split('/')[1] : type),
                      value: file.filename,
                      type: type === '' ? file.contentType.split('/')[1] : type,
                      size: file.chunkSize,
                      date: Number(new Date().getTime().toString().substring(0, 10)),
                      reference: '/api/file.get?_id=' + file._id.toString() + '&type=' + (type === '' ? file.contentType.split('/')[1] : type)
                    }]
                  }]
                }
              ]
            }
          } else {
            proj.files = [
              {
                value: '/',
                open: true,
                type: 'folder',
                date: new Date(),
                data: [{
                  value: 'Archivos del chat ',
                  open: true,
                  type: 'folder',
                  date: new Date(),
                  data: [{
                    id: '/api/file.get?_id=' + file._id.toString() + '&type=' + (type === '' ? file.contentType.split('/')[1] : type),
                    value: file.filename,
                    type: type === '' ? file.contentType.split('/')[1] : type,
                    size: file.chunkSize,
                    date: Number(new Date().getTime().toString().substring(0, 10)),
                    reference: '/api/file.get?_id=' + file._id.toString() + '&type=' + (type === '' ? file.contentType.split('/')[1] : type)
                  }]
                }]
              }
            ]
          }
          if (!file.metadata || file.metadata === null) { file.metadata = {} }
          file.metadata.document = doc._id
          if (doc.project) { file.metadata.project = doc.project }
          if (doc.task) { file.metadata.task = doc.task }
          if(doc.actors.length) {file.actors=[{user: doc.actors[0].user}]}
          await new Promise(resolve => {
            mongo.save('fs.files', file, (err, result) => {
              if (err) {
                resolve(false)
              } else { resolve(result) }
            })
          })
          await new Promise(resolve => {
            mongo.save('project', proj, (err, result) => {
              if (err) {
                resolve(false)
              } else { resolve(result) }
            })
          })
        }
      }
    }
    send({})
  }

  this.findChat = function (req, mongo, send) {
    let keys = req.body.user1 ? { $and: [ {'actors': { $elemMatch: { user: mongo.toId(req.body.user1) } }},{'actors': { $elemMatch: { user: mongo.toId(req.body.user2) } }}, {'actors': { $size: 2 }}]} : {project: mongo.toId(req.body.project)}
    mongo.find('chat', keys, (err, doc) => {
      if (err) {
        send({ error: err })
      } else {
        send(doc? doc[0] : false)
      }
    })
  }

  this.list = function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    var keys = { actors: { $elemMatch: { user: req.session.context.user } } }
    mongo.findN('chat', skip, limit, keys, {}, { lastDate: -1 }, async (err, chats) => {
      if (!err && chats) {
        /*  var userIds = []
        for (let i in chats) {
          userIds.push(chats[i].user)
        } */
        mongo.toHash('user', { /* _id: { $in: userIds } */ }, { name: 1 }, (err, users) => {
          if (err) throw err
          for (let i in chats) {
            let cht = chats[i]
            let from = false
            cht.id = cht._id
            let index = cht.actors.findIndex((x) => {
              return x.user.toString() !== req.session.context.user.toString()
            })
              
            if(cht.messages.length && cht.messages[cht.messages.length -1].user.toString() === req.session.context.user.toString()) {
                from = true
              }
            //if (cht.actors[index].seen) { cht.class = '' } else { cht.class = 'bold' }
            /* cht.username = cht.name || users[cht.actors[index].user.toString()].name
            cht.user = cht.actors[index].user */
            cht.username = cht.name || (cht.actors[index] ? users[cht.actors[index].user.toString()].name : 'Usuario')
            let root = HTMLParser.parse('<div>' + cht.username + '</div>')
            cht.username = root.text.length > 25 ? root.text.substring(0,25) + '...' :  root.text
            cht.user = cht.actors[index] ? cht.actors[index].user : ''
            root = HTMLParser.parse(cht.messages[cht.messages.length -1].message);
            //cht.lastMsg = root.firstChild && root.firstChild !== undefined? (from ? 'Has enviado un mensaje': 'Te ha enviado un mensaje'): cht.messages[cht.messages.length -1].message
             cht.lastMsg = (root.childNodes  && root.childNodes[0].childNodes && root.childNodes[0].childNodes.length || root.childNodes[0].classNames && root.childNodes[0].classNames.length ? (from ? 'Has enviado un mensaje': 'Te ha enviado un mensaje'): cht.messages[cht.messages.length -1].message)
            cht.date = cht.messages[cht.messages.length -1].date
            if(req.session.context.user.toString() === cht.messages[cht.messages.length -1].user.toString()) {
              cht.seen = '1'
            } else {
              let y = cht.messages[cht.messages.length -1].actors.findIndex((a)=>{
                return a.user.toString() === req.session.context.user.toString()
              })
              cht.seen = cht.messages[cht.messages.length -1].actors[y].seen || '1'
            }
            reply.data.push(cht)
          }
          mongo.count('chat', keys, (err, count) => {
            if (!err && count) {
              reply.total_count = count
            }
            send(reply)
          })
        })
      }
    })
  }

  this.read = async function (req, mongo, send) {

    await new Promise(resolve => {
      mongo.saveWithFilter('chat', {_id: mongo.toId(req.query._id), 'messages.actors.user': req.session.context.user},
        {'messages.$[elem].actors.$[ele].seen': '1'},
        {
          multi: true,
          upsert: false,
          arrayFilters: [ { 'elem.actors.user': req.session.context.user}, {'ele.user': req.session.context.user} ]
          // [ { "element": {"element.user": ObjectId("5b103aa45089b30fd853a2b7")} } ]
        },
        (err, result) => {
          if (err) {
            console.log(err)
            resolve()
          } else {
            resolve()
          }
        })
    })
    send({})
  }

  this.count = function (req, mongo, send) {
    var keys = { unread: mongo.toId(req.session.context.user) }
    mongo.count('comment', keys, (err, count) => {
      if (!err && count) {
        send({ count: count })
      }
    })
  }
}
