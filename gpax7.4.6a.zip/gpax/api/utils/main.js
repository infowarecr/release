var os = require('os')
var express = require('express')
var assert = require('assert')
var path = require('path')
var session = require('express-session')
var MongoStore = require('connect-mongo')(session)
var errorHandler = require('errorhandler')
// var upload = require("express-fileupload")();
var helmet = require('helmet')
// GPAX classes
var Mongo = require('./mongo').Mongo
var caller = require('./caller')
var Broadcast = require('./broadcast').Broadcast
var Logger = require('./logger').Logger
var BPD = require('../x/design/bpd').BPD
var Debugger = require('../x/design/debugger').Debugger
var GUI = require('../x/design/gui').GUI
var Channel = require('../x/design/channel').Channel
var Service = require('../x/user/service').Service
// GPAX routes
var Alarms = require('../utils/alarms').Alarms
var Assessment = require('../routes/assessment').Assessment
var Auditable = require('../routes/auditable').Auditable
var Condition = require('../routes/condition').Condition
var Document = require('../routes/document').Document
var Note = require('../routes/note').Note
var NoteReceived = require('../routes/noteReceived').NoteReceived
var NoteSent = require('../routes/noteSent').NoteSent
var NoteDraft = require('../routes/noteDraft').NoteDraft
var Attached = require('../routes/attached').Attached
var Commitment = require('../routes/commitment').Commitment
var Evidence = require('../routes/evidence').Evidence
var Plan = require('../routes/plan').Plan
var Activity = require('../routes/activity').Activity
var Client = require('../routes/client').Client
var Comment = require('../utils/comment').Comment
var Chat = require('../utils/chat').Chat
var Entry = require('../routes/entry').Entry
var Factor = require('../routes/factor').Factor
var Event = require('../routes/event').Event
var Files = require('../routes/files').Files
var File = require('../utils/file').File
var Script = require('../utils/script').Script
var Cursor = require('../utils/cursor').Cursor
var EventUtil = require('../utils/event').EventUtil
var Indicator = require('../utils/indicator').Indicator
var Extract = require('../utils/extract').Extract
var Locale = require('../utils/locale').Locale
var Log = require('../utils/log').Log
var Message = require('../x/design/message').Message
var Movil = require('../routes/movil').Movil
var Notification = require('../utils/notification').Notification
var Params = require('../utils/params').Params
var Process = require('../routes/process').Process
var ProcessAssessment = require('../routes/processAssessment').ProcessAssessment
var AuditableAssessment = require('../routes/auditableAssessment').AuditableAssessment
var ControlAssessment = require('../routes/controlAssessment').ControlAssessment
var Project = require('../routes/project').Project
var Report = require('../utils/report').Report
var Reply = require('../routes/reply').Reply
var Repository = require('../routes/repository').Repository
var Calendar = require('../routes/calendar').Calendar
var Reminder = require('../utils/reminder').Reminder
var Risk = require('../routes/risk').Risk
var Rule = require('../x/design/rule').Rule
var RPA = require('../x/rpa').RPA
var Sequence = require('../routes/sequence').Sequence
var Server = require('../x/design/server').Server
var Signal = require('../x/design/signal').Signal
var Strategy = require('../routes/strategy').Strategy
var Settings = require('../routes/settings').Settings
var Template = require('../routes/template').Template
var Task = require('../routes/task').Task
var Trash = require('../utils/trash').Trash
var TimeReport = require('../routes/timeReport').TimeReport
var Unit = require('../routes/unit').Unit
var User = require('../routes/user').User
var Company = require('../routes/company').Company
var Consecutive = require('../routes/consecutive').Consecutive

/* exported */
exports.init = function (params) {
  var broadcast
  var app = express()
  if (!params.session) {
    params.session='mongodb://'+os.hostname()+'/session?replicaSet=gpaxio'
    params.user='mongodb://'+os.hostname()+'/user?replicaSet=gpaxio'
    params.notify='mongodb://'+os.hostname()+'/notify?replicaSet=gpaxio'
    params.log='mongodb://'+os.hostname()+'/log?replicaSet=gpaxio'
  }
  app.params = params
  app.mongos = {}
  app.getMongo = function (url) {
    var room = url.substring(url.lastIndexOf('/') + 1)
    room = room.split('?')[0]
    if (!app.mongos[room]) {
      app.mongos[room] = new Mongo(url)
      console.log('Connections: ' + Object.keys(app.mongos).length + ' (' + room + ')')
    }
    return app.mongos[room]
  }
  var logger = new Logger(app.getMongo(params.log), params.logger)
  var dirname = __dirname.substring(0, __dirname.lastIndexOf('/'))
  if (process.env.PORT) {
    params.port = 8082 // * process.env.PORT;
  } else {
    process.env.PORT = params.port
  }
  var http = require('http')
  // Session handler
  var store = new MongoStore({
    url: params.session,
    collection: 'active',
    stringify: false,
    ttl: 2 * 60 * 60
  })
  store.on('error', (error) => {
    assert.ifError(error)
    assert.ok(false)
  })
  app.disable('x-powered-by')
  app.use(helmet())
  var sessionMiddleware = session({
    key: 'gpax.user',
    resave: false,
    saveUninitialized: false,
    store: store,
    sameSite: 'strinct',
    secret: 'HakunaMatata'
  })
  app.set('trust proxy', 1)
  app.use(sessionMiddleware)
  // Middleware functions
  app.use('/viewer', express.static(path.join(dirname, 'node_modules/node-viewerjs/release')))
  app.use(function (req, res, next) {
    req.broadcast = broadcast
    req.logger = logger
    next()
  })
  app.use(express.json({ limit: '200MB' }))
  app.use(express.urlencoded({ limit: '200MB', extended: true }))
  app.use(express.static(path.join(dirname, 'public'), { index: 'www/gpax.html' }))

  // development only
  if (app.get('env') === 'development') {
    app.use(errorHandler())
  }

  // Virtual path handler for GPAX classes
  app.routes = {
    assessment: new Assessment(),
    alarms: new Alarms(),
    auditable: new Auditable(),
    condition: new Condition(),
    document: new Document(),
    note: new Note(),
    noteReceived: new NoteReceived(),
    noteSent: new NoteSent(),
    noteDraft: new NoteDraft(),
    attached: new Attached(),
    commitment: new Commitment(),
    evidence: new Evidence(),
    xs: {},
    entry: new Entry(),
    factor: new Factor(),
    event: new Event(),
    file: new File(),
    script: new Script(),
    cursor: new Cursor(),
    eventUtil: new EventUtil(),
    indicator: new Indicator(),
    extract: new Extract(),
    locale: new Locale(),
    log: new Log(),
    logger: logger,
    message: new Message(),
    bpd: new BPD(),
    debugger: new Debugger(),
    gui: new GUI(),
    channel: new Channel(),
    service: new Service(),
    movil: new Movil(),
    notification: new Notification(),
    plan: new Plan(),
    activity: new Activity(),
    params: new Params(),
    process: new Process(),
    project: new Project(),
    processAssessment: new ProcessAssessment(),
    auditableAssessment: new AuditableAssessment(),
    controlAssessment: new ControlAssessment(),
    report: new Report(),
    reply: new Reply(),
    repository: new Repository(),
    calendar: new Calendar(),
    reminder: new Reminder(),
    risk: new Risk(),
    rule: new Rule(),
    rpa: new RPA(),
    sequence: new Sequence(),
    server: new Server(),
    signal: new Signal(),
    strategy: new Strategy(),
    settings: new Settings(),
    template: new Template(),
    task: new Task(),
    trash: new Trash(),
    timeReport: new TimeReport(),
    unit: new Unit(),
    user: new User(),
    // x routes
    client: new Client(),
    comment: new Comment(),
    chat: new Chat(),
    files: new Files(),
    company: new Company(),
    consecutive: new Consecutive()
  }
  if (os.platform() !== 'win32') {
    var Invoice = require('../routes/invoice').Invoice
    var InvoiceNote = require('../routes/invoiceNote').InvoiceNote
    var Invoice2pay = require('../routes/invoice2pay').Invoice2pay
    app.routes.invoice = new Invoice()
    app.routes.invoiceNote = new InvoiceNote()
    app.routes.invoice2pay = new Invoice2pay()
  }
  // Outlook autnetication context
  if (app.params.outlook) {
    var passport = require('passport')
    var OutlookStrategy = require('passport-outlook').Strategy
    var OUTLOOK_CLIENT = '234aa191-e27e-44f2-b7b7-ebaa934050c1' // 'wej8Q~p8m78Roh3DLI-kVVIk~hBkDnOFBnKIVb8q'
    var OUTLOOK_SECRET = 'wej8Q~p8m78Roh3DLI-kVVIk~hBkDnOFBnKIVb8q' //'4dd6bd88-e6b6-4a2a-8e91-4982dbd647ad'
    // '5cJ7vaPLvk6~Q-pr5we_4GJT_J23plwdl6' //'12W7B4_Pc3Q~gkm_ea85yG.1FvpS-7~arB'
    passport.serializeUser((user, done) => { done(null, user) })
    passport.deserializeUser((obj, done) => { done(null, obj) })
    var hostname = app.params.outlook || os.hostname()
    passport.use(
      new OutlookStrategy({ clientID: OUTLOOK_CLIENT, clientSecret: OUTLOOK_SECRET, callbackURL: 'https://'+hostname+'/api/user.auth' },
        (accessToken, refreshToken, profile, done) => {
          var email = profile.EmailAddress || (profile._json ? profile._json.EmailAddress : profile._raw.EmailAddress)
          process.nextTick(function () { return done(null, email) })
        })
    )
    app.use(passport.initialize())
    app.get('/api/outlook',passport.authenticate('windowslive', { scope: ['openid', 'profile', 'offline_access', 'https://outlook.office.com/User.Read'] }),() => { })
    app.get('/api/user.auth', passport.authenticate('windowslive', { failureRedirect: '/' }))
    console.log('Enable federade Microsof autentication for https://'+hostname)
  }
  app.get('/api/link', (req, res,next) => {
    if (req.session.authenticated) {
      req.session.context.initUrl = req.url.substr(10)
      res.send('<script>window.location="/"</script>')
    } else {
      req.session.initUrl = req.url.substr(10)
      res.send('<script>window.location="/login.html"</script>')
    }
  })
  app.all('/api/*.*', caller.go)
  app.all('/*.*', caller.go)
  if (app.params.ebillEnvironment) {
    var EBill = require('../routes/ebill').EBill
    app.routes.ebill = new EBill()
  }
  if (app.params.background) {
    var Background = require('../x/background').Background
    app.routes.background= new Background('invoice', { app: app }),
    app.routes.backgroundCredit= new Background('invoiceCredit', { app: app }),
    app.routes.backgroundInvoice2pay= new Background('invoice2pay', { app: app })
    const mongo = app.getMongo(app.params.background)
    app.routes.background.setDatabase(mongo, { app: app })
    app.routes.backgroundCredit.setDatabase(mongo, { app: app })
    app.routes.backgroundInvoice2pay.setDatabase(mongo, { app: app })
  }

  var server = http.createServer(app)
  if (params.host) {
    server.listen(params.port, params.host, () => {
      logger.log('GPAx: ' + params.user + ' [bind ' + params.host + ':' + params.port + ']')
    })
  } else {
    server.listen(params.port, () => {
      logger.log('GPAx: ' + params.user + ' [bind *:' + params.port + ']')
    })
  }
  broadcast = new Broadcast(server, app)
}
