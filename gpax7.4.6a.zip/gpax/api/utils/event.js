class EventUtil {
  save (req, mongo, event, data, id, description, collection, next) {
    var doc = {
      _id: mongo.newId(),
      user: req.session.context.user,
      date: new Date(),
      event: event,
      collection: collection,
      docId: id,
      data: data,
      description: description
    }
    mongo.save('event', doc, (err, result) => {
      if (err) {
        console.log(err)
        next()
      } else {
        next()
      }
    })
  }

  list (req, mongo, send) {
    mongo.find('event', { docId: mongo.toId(req.query._id) },{}, {_id: -1}, async (err, list) => {
      if (err) {
        console.log(err)
        send()
      } else {
        var data = []
        let user = ''
        for (let i in list) {
          user = await new Promise(resolve=> { mongo.findId('user', list[i].user, { name: 1 }, (e, u) => {resolve(u)})})
          data.push({
            user: list[i].user,
            username: user ? user.name : '',
            dateTime: list[i].date,
            status: list[i].data,
            description: list[i].description
          })
        }
        send(data)
      }
    })
  }
}

exports.EventUtil = EventUtil