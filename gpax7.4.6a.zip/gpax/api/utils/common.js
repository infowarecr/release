var Mongo = require('./mongo').Mongo
var linkUrl = '="/gpa/bcrdai.nsf/'
var hostUrl = 'http://bcr.local'
var user = 'MINFOWARE'; var password = 'migracion'
var view2json = 'http://bcr.local/gpa/bcrdai.nsf/all?ReadViewEntries&outputformat=JSON&charset=utf-8&count=1000&restrictToCategory='
var children2json = 'http://bcr.local/gpa/bcrdai.nsf/children?ReadViewEntries&outputformat=JSON&charset=utf-8&start=1&count=1000&restrictToCategory='
var doc2json = 'http://bcr.local/gpa/bcrdai.nsf/doc2json?OpenAgent&charset=utf-8&id='
var field2html = 'http://bcr.local/gpa/bcrdai.nsf/0/'
var database = 'mongodb://localhost:27017/auditoria'
var usersDb = 'mongodb://localhost:27017/users'
/*
var Mongo = require('./mongo').Mongo
var linkUrl = '="/gpa/bcrdai.nsf/'
var hostUrl = 'http://bcr.local'
var user = 'jorge'; var password = 'Aes.719508'
var view2json = 'http://bcr.local/gpa/bcrdai.nsf/all?ReadViewEntries&outputformat=JSON&charset=utf-8&count=1000&restrictToCategory='
var children2json = 'http://bcr.local/gpa/bcrdai.nsf/children?ReadViewEntries&outputformat=JSON&charset=utf-8&start=1&count=1000&restrictToCategory='
var doc2json = 'http://bcr.local/gpa/bcrdai.nsf/doc2json?OpenAgent&charset=utf-8&id='
var field2html = 'http://bcr.local/gpa/bcrdai.nsf/0/'
var database = 'mongodb://localhost:27017/bcr'
var usersDb = 'mongodb://localhost:27017/users'
*/
exports.Common = Common

function Common () {
  this.mongo = new Mongo(database)
  this.users = new Mongo(usersDb)
  this.request = require('request')
  this.view = async (form, start) => {
    var docs = await new Promise(resolve => {
      this.request.get(view2json + form + '&start=' + start, (er, res, jbody) => {
        if (er) {
          console.log('er: ' + er)
        } else if (jbody !== '') {
          var docs = JSON.parse(this.decode(jbody, 'view'))
          resolve(docs)
        } else {
          resolve([])
        }
      }).auth(user, password, true)
    })
    var data = docs.viewentry ? docs.viewentry : []
    for (const i in data) {
      if (!data[i]['@unid']) {
        delete data[i]
      }
    }
    return {
      docs: data,
      total: docs['@toplevelentries']
    }
  }
  this.findOne = async (collection, keys, fields) => {
    const data = await new Promise(resolve => {
      this.mongo.findOne(collection, keys, fields, (err, doc) => {
        if (err || !doc) resolve({})
        else resolve(doc)
      })
    })
    return data
  }

  this.saveOnly = async (collection, doc) => {
    await new Promise(resolve => {
      this.mongo.save(collection, doc, (err, result) => {
        if (err) {
          console.log(err)
          resolve()
        } else resolve()
      })
    })
  }

  this.decode = (jbody, route, form) => {
    if (!jbody.includes('Agent done')) {
      if (
        form === 'Persona' ||
        form === 'DetalleAuditor' ||
        form === 'Criterio' ||
        form === 'Subcriterio' ||
        form === 'Formulario' ||
        form === 'Informe' ||
        form === 'Observacion' ||
        form === 'Anexo' ||
        form === 'Anexo2' ||
        form === 'Tarea' ||
        form === 'Comentario' ||
        form === 'EvaluacionRiesgo' ||
        form === 'NotaEmitida' ||
        form === 'NotaRecibida'
      ) jbody = jbody.replace(/[\\]/g, '/') // para persona
      // jbody = jbody.replace(/[/]"/g, '\"')
      jbody = jbody.replace(/[\u001f]/g, ' ') // problema JSON.parse con simbolo u001f
      jbody = jbody.replace(/[	]/g, ' ')
      jbody = jbody.replace(/[\\]!°/g, '/')
      jbody = jbody.replace(/[\\]>=/g, '')
      jbody = jbody.replace(/=[\\]>/g, '')
      jbody = jbody.replace(/[\\]>/g, '')
      return jbody
    } else {
      return '{}'
    }
  }
  this.tohash = async (collection, keys, fields) => {
    const hash = await new Promise(resolve => {
      this.mongo.toHash(collection, keys, fields, (err, hash) => {
        if (err) {
          console.log(err)
          resolve([])
        } else {
          resolve(hash)
        }
      })
    })
    return hash
  }
  this.children = async (parentId, collection) => {
    var docs = await new Promise(resolve => {
      this.request.get(children2json + parentId + collection, (er, res, jbody) => {
        if (jbody !== '') {
          var docs = JSON.parse(this.decode(jbody, 'children'))
          resolve(docs)
        } else {
          resolve([])
        }
      }).auth(user, password, true)
    })
    docs = docs.viewentry ? docs.viewentry : []
    for (const i in docs) {
      if (!docs[i]['@unid']) {
        delete docs[i]
      }
    }
    return docs
  }
  this.comments = async (lotusId, mongoId, collection) => {
    var docs = await this.children(lotusId, 'Comentario')
    docs = await this.createComments(docs, mongoId, collection)
    return docs
  }
  this.createComments = async (cmts, mongoId, collection) => {
    var comments = []
    for (const i in cmts) {
      var lotus = await this.document(cmts[i]['@unid'], 'Comentario')
      let date = new Date()
      if (lotus.FechaCreacion && lotus.FechaCreacion !== '') date = new Date(lotus.FechaCreacion)
      var mdoc = {
        _id: this.mongo.newId(date),
        collection: collection,
        document: mongoId,
        comment: '<p><strong>' + lotus.Nombre + '</strong></p>' + await this.field(lotus.id, 'Comentario') +
          '<details open=""><summary>Otros datos</summary>' +
          (lotus.Respuesta !== '' ? '<br>Respuesta: ' + lotus.Respuesta : '') +
          (lotus.RolAuditoria !== '' ? '<br>Rol auditoria: ' + lotus.RolAuditoria : '') +
          (lotus.Lectores !== '' ? '<br>Lectores: ' + lotus.Lectores : '') +
          (lotus.Historico !== '' ? '<br>Historico: ' + lotus.Historico : '') +
          '</details>',
        dateTime: date,
        user: await this.getUser(lotus.Autor)._id,
        involved: [],
        mentions: [],
        unread: [],
        migrated: 1
      }
      await new Promise(resolve => {
        this.mongo.save('comment', mdoc, (err, result) => {
          if (err) console.log(err)
          resolve()
        })
      })
      comments.push(mdoc)
    }
    return comments
  }
  this.log2comment = async (bitacora, mongoId, collection, actors) => {
    const involved = []
    const mentions = []
    if (actors && actors.length > 0) {
      for (const i in actors) {
        involved.push(actors[i].user)
      }
    }
    var mdoc = {
      _id: this.mongo.newId(),
      collection: collection,
      document: mongoId,
      comment: bitacora,
      dateTime: new Date(),
      user: await this.getUser('adminbcr'),
      involved: involved,
      mentions: mentions,
      unread: [],
      migrated: 1
    }
    await new Promise(resolve => {
      this.mongo.save('comment', mdoc, (err, result) => {
        if (err) console.log(err)
        resolve()
      })
    })
    return mdoc
  }
  this.bitacora2comment = async (collection, id, bitacora) => {
    if (bitacora) {
      var user = await this.getUser(bitacora.substring(0, bitacora.indexOf(' -')))
      user = user._id
      let datetime = ''
      const arrayDatetime = bitacora.substring(bitacora.indexOf(' - '), bitacora.indexOf(',')).split('/')
      if (arrayDatetime.length === 3) {
        const day = arrayDatetime[0].substring(3, 5)
        const month = arrayDatetime[1]
        const year = arrayDatetime[2].substring(0, 4)
        datetime = new Date(year + '/' + month + '/' + day)
      }
      bitacora = bitacora.replace(/,/g, '<br>')
      await new Promise(resolve => {
        this.mongo.save('comment', { _id: this.mongo.newId(), collection: collection, document: id, comment: bitacora, dateTime: datetime, involved: [], mentions: [], migrated: 1, unread: [], user: user }, (err, result) => {
          if (err) {
            console.log(err)
            resolve()
          } else {
            resolve()
          }
        })
      })
    }
  }
  this.getTag = async (data, name) => {
    if (data) {
      data = data.split(';')
      const array = []
      for (const a in data) {
        const value = data[a]
        await new Promise(resolve => {
          this.mongo.find('params', { name: name }, async (err, params) => {
            var i = -1
            var _id = this.mongo.newId()
            var option = { id: this.mongo.newId(), value: value, color: '#00abcc' }
            var options = [option]
            if (!err) {
              if (params && params.length) {
                _id = params[0]._id
                options = params[0].options || []
                i = options.findIndex((opt) => { return opt.value === value })
                if (i !== -1) {
                  option = options[i]
                } else {
                  options.push(option)
                }
              }
            }
            if (i === -1) {
              await new Promise(resolve => {
                this.mongo.save('params', { _id: _id, name: name, options: options }, (err, result) => {
                  if (err) console.log(err)
                  resolve()
                })
              })
            }
            array.push(option.id)
            resolve()
          })
        })
      }
      return array
    } else return ''
  }
  this.document = async (lotusId, form, database) => {
    var doc = {}
    if (!lotusId) {
      console.log(lotusId)
    } else {
      var url = doc2json
      if (database) {
        url = url.replace(/bcrdai/g, database)
      }
      lotusId = lotusId.split(';')
      doc = await new Promise(resolve => {
        this.request.get(url + lotusId[0], (err, res, json) => {
          if (err) resolve(false)
          else {
            try {
              resolve(JSON.parse(this.decode(json, 'document', form)))
            } catch (err) {
              console.log(err)
              console.log(lotusId)
              // process.exit(0)
              resolve(false)
            }
          }
        }).auth(user, password, true)
      })
    }
    return doc
  }
  this.field = async (lotusId, fieldName) => {
    var field = await new Promise(resolve => {
      this.request.get(field2html + lotusId + '/' + fieldName + '?openfield&charset=utf-8', (err, res, html) => {
        if (err) console.log(err + ' getting curriculum')
        resolve(html)
      }).auth(user, password, true)
    })
    var html = await this.url2mongo(field)
    html = html.replace(/ alt=/g, ' title=')
    return html
  }
  this.fieldAttach = async (lotusId, fieldName, nameFile) => {
    var field = '/gpa/bcrdai.nsf/0/' + lotusId + '/' + fieldName + '/' + nameFile
    var html = await this.mongoUrl(field)
    html = html.replace(/ alt=/g, ' title=')
    return html
  }
  this.migrated = async (id) => {
    var doc = await new Promise(resolve => {
      this.mongo.findOne('migration', { id: id }, (err, doc) => {
        if (err || !doc) resolve(false)
        else resolve(doc)
      })
    })
    return doc
  }
  this.getLotusId = async (table, _id) => {
    var doc = await new Promise(resolve => {
      this.mongo.find('migration', { _id: _id }, (err, docs) => {
        if (err || !docs || docs.length === 0) resolve()
        else resolve(docs[0])
      })
    })
    return doc
  }
  this.getActivity = async (plan, name) => {
    let doc = ''
    const id = await new Promise(resolve => {
      this.mongo.findOne('plan', { name: plan }, {}, (err, plan) => {
        if (err || !plan) {
          console.log(err)
          resolve(doc)
        } else {
          for (const i in plan.activities.activities) {
            const activity = plan.activities.activities[i]
            if (activity === name) {
              doc = i
              break
            }
          }
          resolve(doc)
        }
      })
    })
    return id
  }
  this.getMigratedDoc = async (lotusId, collection) => {
    if (lotusId) {
      const data = await new Promise(resolve => {
        this.mongo.findOne('migration', { table: collection, id: lotusId }, {}, async (err, doc) => {
          if (err) {
            console.log(err)
            resolve({ _id: '' })
          } else if (doc) {
            const aud = await new Promise(resolve => {
              this.mongo.findId(collection, doc._id, (err, result) => {
                if (err || !result) {
                  console.log(err)
                  resolve({ _id: '' })
                } else {
                  resolve(result)
                }
              })
            })
            resolve(aud)
          } else resolve({ _id: '' })
        })
      })
      return data
    } else return { _id: '' }
  }
  this.getMongoDocument = async (collection, id) => {
    const doc = await new Promise(resolve => {
      this.mongo.findId(collection, id, (err, data) => {
        if (err) {
          console.log(err)
          resolve('')
        } else {
          resolve(data)
        }
      })
    })
    return doc
  }
  this.findMongo = async (collection, keys, fields, sort) => {
    const doc = await new Promise(resolve => {
      this.mongo.find(collection, keys, fields, sort, (err, data) => {
        if (err) {
          console.log(err)
          resolve('')
        } else if (data.length === 0) {
          resolve('')
        } else {
          resolve(data)
        }
      })
    })
    return doc
  }
  this.getUser = async (name) => {
    var user = ''
    if (name) {
      let n = name.indexOf(';')
      if (n !== -1) {
        name = name.split(';')
        name = name[name.length - 1]
      } else {
        n = name.indexOf(',')
        if (n !== -1) {
          name = name.split(',')
          name = name[name.length - 1]
        } else {
          n = name.indexOf(' - ')
          if (n !== -1) {
            name = name.split(' - ')
            name = name[name.length - 1]
          } else {
            n = name.indexOf(' -')
            if (n !== -1) {
              name = name.split(' -')
              name = name[name.length - 1]
            } else {
              n = name.indexOf('- ')
              if (n !== -1) {
                name = name.split('- ')
                name = name[name.length - 1]
              } else {
                n = name.indexOf('-')
                if (n !== -1) {
                  name = name.split('-')
                  name = name[name.length - 1]
                } else {
                  n = name.indexOf(' y ')
                  if (n !== -1) {
                    name = name.split(' y ')
                    name = name[name.length - 1]
                  }
                }
              }
            }
          }
        }
      }
      var login = this.toLogin(name)
      user = await new Promise(resolve => {
        this.mongo.find('user', { login: login }, async (err, docs) => {
          if (err) {
            console.log(err)
            resolve({})
          } else if (docs.length === 1) {
            resolve(docs[0])
          } else {
            const newUser = {
              _id: this.mongo.newId(),
              active: true,
              email: login,
              licensedUser: false,
              login: login,
              name: name,
              roles: {
                createUsers: false,
                createUnits: false,
                createTemplates: false,
                createSequences: false,
                createRepositories: false,
                createProcesses: false,
                createTags: false,
                createProcedures: false,
                adminTrash: false,
                risk: false,
                createReports: false
              },
              units: []
            }
            await new Promise(resolve => {
              this.mongo.save('user', newUser, (err, result) => {
                if (err) console.log(err)
                resolve()
              })
            })
            await this.credentials(newUser._id, newUser.login, newUser.licensedUser, ' riesgos')
            resolve(newUser)
          }
        })
      })
    }
    return user
  }
  this.exists = async (collection, keys) => {
    var docs = await new Promise(resolve => {
      this.mongo.find(collection, keys, (err, docs) => {
        if (err) console.log(err)
        resolve(docs)
      })
    })
    return docs && docs.length > 0
  }
  this.getUnits = async (unidades) => {
    unidades = unidades.split(';')
    const units = []
    for (const i in unidades) {
      const unidad = unidades[i]
      await new Promise(resolve => {
        this.mongo.find('unit', { name: unidad }, async (err, docs) => {
          if (err || docs.length === 0) {
            console.log(err)
            resolve()
          } else if (docs.length === 1) {
            units.push(docs[0]._id)
            resolve()
          }
        })
      })
    }
    return units
  }
  this.getUnit = async (unidad) => {
    var unit = await new Promise(resolve => {
      this.mongo.find('unit', { name: unidad }, async (err, docs) => {
        if (err || docs.length === 0) {
          console.log(err)
          resolve({})
        } else if (docs.length === 1) {
          resolve(docs[0])
        }
      })
    })
    return unit
  }
  this.getActor = async (user, unit, role, path, defaultUnit) => {
    let defaultActor = ''
    if (defaultUnit) {
      defaultActor = await new Promise(resolve => {
        this.mongo.findOne('unit', { name: defaultUnit }, async (err, doc) => {
          if (err) {
            console.log(err)
            resolve({})
          } else {
            let docR
            for (const i in doc.actors) {
              if (doc.actors[i].type[0] === 'manager') {
                docR = {
                  user: doc.actors[i].user,
                  path: path,
                  role: role,
                  unit: doc._id
                }
              }
              break
            }
            resolve(docR)
          }
        })
      })
    }
    const actor = await new Promise(resolve => {
      this.mongo.findOne('unit', { name: unit }, async (err, doc) => {
        if (err) {
          console.log(err)
          resolve({})
        } else if (!doc) {
          resolve(defaultActor)
        } else {
          let docR
          for (const i in doc.actors) {
            if (doc.actors[i].type[0] === 'manager') {
              let gUser
              if (user) {
                gUser = await this.getUser(user)
                gUser = gUser._id
              } else {
                gUser = doc.actors[i].user
              }
              docR = {
                user: gUser,
                path: path,
                role: role,
                unit: doc._id
              }
              break
            }
          }
          resolve(docR || defaultActor)
        }
      })
    })
    return actor
  }
  this.pushUnit = async (id, unit, collection) => {
    const r = await new Promise(resolve => {
      this.mongo.findId(collection, id, async (err, doc) => {
        if (err) {
          console.log(err)
          resolve({ error: err })
        } else if (doc) {
          doc.units.push(unit)
          this.mongo.save(collection, doc, (err, result) => {
            if (err) {
              console.log(err)
              resolve({ error: err })
            } else resolve(result)
          })
        } else resolve({})
      })
    })
    if (r.error) {
      console.log(r.error)
      return (false)
    }
    return (true)
  }
  this.getPlan = async (name) => {
    const plan = await new Promise(resolve => {
      this.mongo.find('plan', { name: name }, (err, doc) => {
        if (err) {
          console.log(err)
          resolve({})
        } else if (doc.length === 1) {
          resolve(doc[0])
        } else resolve({})
      })
    })
    return plan
  }
  this.getProcess = async (name) => {
    var process = await new Promise(resolve => {
      this.mongo.findOne('process', { name: name }, async (err, doc) => {
        if (err || !doc) {
          console.log(err)
          resolve({})
        } else {
          resolve(doc)
        }
      })
    })
    return process
  }
  this.setStatusNote = (mdoc, estado) => {
    switch (estado * 1) {
      case 1:
        mdoc.status = 'draft'
        break
      case 2:
        mdoc.status = 'processing'
        break
      case 3:
        mdoc.status = 'attended'
        break
      default:
        mdoc.status = 'draft'
        break
    }
  }
  this.setStatusAttached = (mdoc, estado) => {
    switch (estado * 1) {
      case 1:
        mdoc.status = 'prepared'
        break
      case 2:
        mdoc.status = 'processing'
        break
      case 3:
        mdoc.status = 'completed'
        break
      case 4:
        mdoc.status = 'answered'
        break
      case 6:
        mdoc.status = 'canceled'
        break
      default:
        mdoc.status = 'prepared'
        break
    }
  }
  this.setStatusCommitment = (mdoc, estado, estadoA) => {
    estado = estado * 1
    estadoA = estadoA * 1
    if (estado === 3) {
      mdoc.status = 'completed'
    } else if (estado === 2) {
      mdoc.status = 'incomplete'
    } else if (estado === 1 && estadoA === 0) {
      mdoc.status = 'draft'
    } else if (estado === 1 && (estadoA === 1 || estadoA === 2 || estadoA === 3 || estadoA === 4 || estadoA === 5)) {
      mdoc.status = 'ready'
    } else if (estadoA === 6) {
      mdoc.status = 'canceled'
    } else if (estadoA === 7) {
      mdoc.status = 'incomplete'
    } else if (estadoA === 8) {
      mdoc.status = 'completed'
    } else {
      mdoc.status = estadoA + '.' + estado
    }
  }
  this.setStatus = (mdoc, estado, flag) => {
    if (mdoc.papelOk === '2') {
      mdoc.status = 'ready'
      mdoc.color = '#529B00'
    } else {
      switch (estado * 1) {
        case 2: // En proceso
          mdoc.status = 'processing'
          mdoc.color = '#3c4dc4'
          break
        case 3: // Para revisar
        case 8: // Ejecutado
          mdoc.status = 'done'
          mdoc.color = '#529B00'
          break
        case 5: // Revisado
          mdoc.status = 'reviewed'
          mdoc.color = '#529B00'
          break
        case 4: // Concluido
        case 10: // Aprobado
          mdoc.status = 'completed'
          mdoc.color = '#529B00'
          break
        case 7: // Pendiente
          mdoc.status = 'paused'
          mdoc.color = '#FF963E'
          break
        case 6: // NoAplicado
          mdoc.status = 'suspended'
          mdoc.color = '#FF413E'
          break
        case 11: // archived
          mdoc.status = flag && flag === 'Task' ? 'reviewed' : 'archived'
          break
        default: // 0 SinEmitir, 1 Emitido, 9 Borrador, otros
          mdoc.status = 'draft'
          break
      }
    }
  }
  this.save = async (collection, doc, lotusId) => {
    var r = await new Promise(resolve => {
      this.mongo.save(collection, doc, async (err, result) => {
        if (err) resolve({ error: err })
        else {
          await this.comments(lotusId, doc._id, collection)
          this.mongo.save('migration', { table: collection, _id: doc._id, id: lotusId }, (err, result) => {
            if (err) console.log(err)
            else resolve(result)
          })
        }
      })
    })
    if (r.error) {
      console.log(r.error)
      return (false)
    }
    return (true)
  }
  this.update = async (collection, doc) => {
    var r = await new Promise(resolve => {
      this.mongo.save(collection, doc, async (err, result) => {
        if (err) resolve({ error: err })
        else {
          resolve(result)
        }
      })
    })
    if (r.error) {
      console.log(r.error)
      return (false)
    }
    return (true)
  }
  this.credentials = async (_id, login, licensedUser, rute) => {
    if (!rute) rute = ''
    var r = await new Promise(resolve => {
      this.users.find('user', { login: login }, (err, docs) => {
        if (err) console.log(err)
        var user = {
          _id: _id,
          active: true,
          database: database,
          login: login + rute,
          menu: licensedUser ? 'projects' : 'auditor',
          password: 'lxc/heQEQcxj9kMWKnVu2PYVUC4='
        }
        this.users.save('user', user, (err, result) => {
          if (err) resolve({ error: err })
          else resolve(result)
        })
      })
    })
    if (r.error) {
      console.log(r.error)
      return (false)
    }
    return (true)
  }
  this.toLogin = (email) => {
    if (email.indexOf('O=BCR') !== -1) {
      var x = email.split('/')[0]
      return x.replace('CN=', '')
    } else {
      return '' + email
    }
  }
  this.toDate = (txt) => {
    var date = null
    if (txt.length === 10) {
      const year = txt.substr(6, 4)
      const mes = 1 * txt.substr(0, 2)
      const dia = txt.substr(3, 2)
      date = new Date(year, mes - 1, dia)
    }
    return date
  }
  this.toNumber = (txt) => {
    return 1.0 * ('0' + txt)
  }
  this.url2mongo = async (html) => {
    var pos = html.indexOf(linkUrl)
    while (pos !== -1) {
      var url = html.substring(pos + 2, html.indexOf('"', pos + (linkUrl.length)))
      if (!url.includes('OpenDocument')) {
        html = html.replace(url, await this.mongoUrl(url))
      }
      pos = html.indexOf(linkUrl, pos + url.length)
    }
    return html
  }
  this.mongoUrl = async (url) => {
    var stream = this.request.get(hostUrl + url).auth(user, password, true)
    var filename = decodeURIComponent(url)
    if (filename.includes('/')) {
      filename = filename.split('/')
      filename = filename[filename.length - 1]
    }
    var newUrl = await new Promise(resolve => {
      this.mongo.putFile(filename, stream, (err, url) => {
        if (err) {
          console.log(err)
          resolve()
        } else {
          resolve(url)
        }
      })
    })
    return newUrl
  }
}
