
var tags = require('../utils/tags').tags
var fs = require('fs')
/* exported */
exports.Log = Log

function Log () {
  this.list = async function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 500
    var reply = { data: [], pos: skip }
    var users = await new Promise(resolve => {
      mongo.toHash('user', {}, { _id: 1, name: 1 }, (err, users) => {
        if (!err) {
          resolve(users)
        }
      })
    })
    var logdb = req.app.getMongo(req.app.params.log)
    var db = mongo.url.split('/')
    db = db[db.length - 1].split('?')[0]
    var keys = { db: db }
    var dateFilter
    if (req.query.filter) {
      const query = {}
      for (const name in req.query.filter) {
        if (req.query.filter[name].length > 0) {
          if (name === 'user') {
            query.user = mongo.toId(req.query.filter.user)
          } else if (name === 'url') {
            query.url = new RegExp(req.query.filter.url)
          } else if (name === 'ip') {
            query.ip = req.query.filter.ip
          }
        }
      }
      if (query.user || query.url || query.ip) {
        keys = { $and: [query, keys] }
      }
      if (req.query.filter.date) {
        var c = req.query.filter.date.condition
        var start, end
        if (c.filter && c.filter.start && c.filter.end) {
          start = c.filter.start
          end = c.filter.end
          end.setDate(end.getDate() + 1)
        } else if (c.filter instanceof Date) {
          start = c.filter
          end = new Date(start.getTime())
          end.setDate(end.getDate() + 1)
        }
        var filter
        switch (c.type) {
        case 'greater':
          if (start) filter = { $gt: start }
          break
        case 'less':
          if (start) filter = { $lt: start }
          break
        case 'greaterOrEqual':
          if (start) filter = { $gte: start }
          break
        case 'lessOrEqual':
          if (start) filter = { $lte: start }
          break
        case 'equal':
          if (start) filter = { $gte: start, $lt: end }
          break
        case 'notEqual':
        case 'notBetween':
          if (start) filter = { $lt: start, $gt: end }
          break
        case 'between':
          if (start) filter = { $gte: start, $lt: end }
          break
        }
        if (filter) {
          dateFilter = { date: filter }
        }
      }
    }
    var pipe = [
      { $match: keys },
      { $addFields: { id: '$_id', date: { $toDate: '$_id' } } }
    ]
    if (dateFilter) {
      pipe.push({ $match: dateFilter })
    }
    pipe.push({ $sort: { _id: -1 } })
    pipe.push({ $skip: skip })
    pipe.push({ $limit: limit })
    logdb.aggregate('trace', pipe, {}, (err, docs) => {
      if (!err && docs && docs.length > 0) {
        for (const i in docs) {
          var doc = docs[i]
          doc.user = {
            _id: doc.user,
            name: doc.user ? users[doc.user.toString()].name : ''
          }
        }
      }
      reply.data = docs
      if (skip) {
        send(reply)
      } else {
        pipe = [
          { $match: keys },
          { $addFields: { date: { $toDate: '$_id' } } }
        ]
        if (dateFilter) {
          pipe.push({ $match: dateFilter })
        }
        pipe.push({ $group: { _id: null, count: { $sum: 1 } } })
        logdb.aggregate('trace', pipe, {}, (err, docs) => {
          if (err) throw err
          reply.total_count = docs && docs[0] ? docs[0].count : 0
          send(reply)
        })
      }
    })
  }

  this.get = function (req, mongo, send) {
    // Buscar el _id en mongo db y obtener el input, para pintar el documento correspondiente si es un documento
    mongo.findId('log', req.query._id, (err, log) => {
      if (err) {
        send({ error: err })
      } else {
        var url = log.url.replace('save', 'get')
        mongo.findN('log', 0, 1, { 'input._id': log.input._id, _id: { $gt: log._id }, url: url }, {}, { _id: 1 }, (err, logGet) => {
          if (!err) {
            var dialog = logGet[0].output.dialog
            dialog.width = req.session.screen.w
            dialog.height = req.session.screen.h
            if (dialog.form && dialog.form.toolbar) {
              delete dialog.form.toolbar
            }
            if (dialog.formTabbar && dialog.formTabbar.toolbar) {
              delete dialog.formTabbar.toolbar
            }
            send({ dialog })
          } else {
            send({ error: err })
          }
        })
      }
    })
  }

  this.backupInfo = function (req, mongo, send) {
    var fileBackup = '/ftp/' + mongo.dbname + '.gz'
    fs.stat(fileBackup, function (err, stats) {
      if (err || !stats) {
        send({ name: fileBackup, message: 'backup not found' })
      } else {
        send({ date: stats.birthtime, name: mongo.dbname + '.gz', size: stats.size })
      }
    })
  }

  this.backup = function (req, mongo, send) {
    var fileBackup = '/ftp/' + mongo.dbname + '.gz'
    fs.access(fileBackup, fs.F_OK, (err) => {
      if (err) {
        send({ message: 'backup not found' })
      } else {
        send({ download: fileBackup })
      }
    })
  }

  this.getActor = function (users, user) {
    let actor
    if (users.findIndex) {
      const x = users.findIndex(function (u) {
        return u.user.equals(user)
      })
      if (x !== -1) {
        actor = users[x]
      }
    } else {
      if (users.user.equals(user)) {
        actor = users
      }
    }
    return actor
  }

  this.recover = function (req, mongo, send) {
    var _id = req.query._id
    var logdb = req.app.getMongo(req.app.params.log)
    logdb.findId('log', _id, (err, doc) => {
      if (err || !doc) {
        if (err) console.log(err)
        send({ err: err || 'Error al recuperar' })
      } else {
        if (doc.input) {
          mongo.save('template', doc.input, () => {send(doc.input)})
        } else {
          send({ err: 'Error al recuperar' })
        }
      }
    })
  }
}
