/* exported */
var tags = require('../utils/tags').tags
var Notification = require('../utils/notification').Notification
var notification = new Notification()
var moment = require('moment')

exports.Alarms = Alarms

function Alarms () {
  this.alarm = async function (req, mongo, send) {
    mongo.findOne('settings', { _id: 'settings' }, (err, sett) => {
      if (err) send({ err: err })
      else if (sett && sett.user && sett.password) {
        mongo.find('user', {}, { _id: 1, name: 1, email: 1 }, {}, async (err, users) => {
          if (err) send({ err: err })
          else {
            for (let u in users) {
              req.query.user = users[u]._id
              req.query.filter = 'overdue'
              await new Promise(resolve => {
                this.list(req, mongo, (overdue) => {
                  req.query.filter = 'today'
                  this.list(req, mongo, (today) => {
                    req.query.filter = 'next'
                    this.list(req, mongo, (next) => {
                      var count = overdue.length + today.length + next.length
                      if (count === 0) { resolve() } else {
                        var body = 'Tienes:<br>\n' + overdue.length + ' documento(s) vencidos,<br>' +
                                                    '\n' + today.length + ' documento(s) para hoy,<br>' +
                                                    '\n' + next.length + ' documento(s) para la próxima semana'
                        var id = mongo.newId()
                        var doc = {
                          _id: id,
                          body: body,
                          count: count,
                          date: new Date(),
                          unread: [users[u]._id],
                          involved: [users[u]._id]
                        }
                        mongo.save('alarm', doc, (err, result) => {
                          if (err) throw err
                          if (sett.checkNotification === '1') {
                            notification.sendAlarm(req, body, users[u]._id, count, doc._id)
                          }
                          resolve()
                        })
                      }
                    })
                  })
                })
              })
            }
          }
        })
      }
    })
  }

  this.listOld = function (req, mongo, send) {
    try {
      if (!req.query.user) req.query.user = req.session.context.user
      mongo.find('document', {}, { name: 1, dates: 1, status: 1, actors: 1 }, {}, (err, docs) => {
        if (err) { send({ err: err }) } else {
          mongo.find('project', { status: 'processing' }, {}, {}, (err, projs) => {
            if (err) { send({ err: err }) } else {
              var reply = []
              if (req.query.filter === 'overdue') {
                for (let i in docs) {
                  docs[i].id = docs[i]._id
                  docs[i].type = 'document'
                  let deadline
                  if (docs[i].dates) {
                    docs[i].dates.findIndex((x) => {
                      if (x.type === 'deadline') deadline = x.value
                    })
                  }
                  for (let a in docs[i].actors) {
                    if (docs[i].actors[a].role === 'to' && docs[i].actors[a].user.toString() === req.query.user.toString()) {
                      if (deadline &&
                                                docs[i].status === tags.processing &&
                                                deadline.setHours(0, 0, 0, 0, 0) < new Date().setHours(0, 0, 0, 0, 0) &&
                                                deadline.setHours(0, 0, 0, 0, 0) !== new Date().setHours(0, 0, 0, 0, 0)) {
                        reply.push(docs[i])
                      }
                    }
                  }
                }
                for (let p in projs) {
                  for (let pa in projs[p].actors) {
                    var actor = projs[p].actors[pa]
                    if (actor.user.toString() === req.query.user.toString()) {
                      for (let c in projs[p].content.data) {
                        var data = projs[p].content.data[c]
                        try {
                          if (data.owner_id && data.owner_id.toString() === req.query.user.toString() && data.status === 'processing' && data.type === 'task' && new Date(data.end_date).setHours(0, 0, 0, 0, 0) < new Date().setHours(0, 0, 0, 0, 0) && new Date(data.end_date).setHours(0, 0, 0, 0, 0) !== new Date().setHours(0, 0, 0, 0, 0)) {
                            reply.push({
                              id: data.id,
                              project: projs[p]._id,
                              type: 'task',
                              name: data.text,
                              nameProj: projs[p].name
                            })
                          }
                        } catch (error) {
                          console.log(error)
                        }
                      }
                    }
                  }
                }
              } else if (req.query.filter === 'today') {
                for (let i in docs) {
                  docs[i].id = docs[i]._id
                  docs[i].type = 'document'
                  let deadline
                  if (docs[i].dates) {
                    docs[i].dates.findIndex((x) => {
                      if (x.type === 'deadline') deadline = x.value
                    })
                  }
                  for (let a in docs[i].actors) {
                    if (docs[i].actors[a].role === 'to' && docs[i].actors[a].user.toString() === req.query.user.toString()) {
                      if (deadline && docs[i].status === tags.processing && deadline.setHours(0, 0, 0, 0, 0) === new Date().setHours(0, 0, 0, 0, 0)) {
                        reply.push(docs[i])
                      }
                    }
                  }
                }
                for (let p in projs) {
                  for (let pa in projs[p].actors) {
                    actor = projs[p].actors[pa]
                    if (actor.user.toString() === req.query.user.toString()) {
                      for (let c in projs[p].content.data) {
                        data = projs[p].content.data[c]
                        try {
                          if (data.owner_id && data.owner_id.toString() === req.query.user.toString() && data.status === 'processing' && data.type === 'task' && new Date(data.end_date).setHours(0, 0, 0, 0, 0) === new Date().setHours(0, 0, 0, 0, 0)) {
                            reply.push({
                              id: data.id,
                              project: projs[p]._id,
                              type: 'task',
                              name: data.text,
                              nameProj: projs[p].name
                            })
                          }
                        } catch (error) {
                          console.log(error)
                        }
                      }
                    }
                  }
                }
              } else if (req.query.filter === 'next') {
                var suma7dias = 7 * 24 * 60 * 60 * 1000
                for (let i in docs) {
                  docs[i].id = docs[i]._id
                  docs[i].type = 'document'
                  let deadline
                  if (docs[i].dates) {
                    docs[i].dates.findIndex((x) => {
                      if (x.type === 'deadline') deadline = x.value
                    })
                  }
                  for (let a in docs[i].actors) {
                    if (docs[i].actors[a].role === 'to' && docs[i].actors[a].user.toString() === req.query.user.toString()) {
                      if (deadline && docs[i].status === tags.processing && deadline.setHours(0, 0, 0, 0, 0) > new Date().setHours(0, 0, 0, 0, 0) && deadline.setHours(0, 0, 0, 0, 0) < new Date().setHours(0, 0, 0, 0, 0) + suma7dias) {
                        reply.push(docs[i])
                      }
                    }
                  }
                }
                for (let p in projs) {
                  for (let pa in projs[p].actors) {
                    actor = projs[p].actors[pa]
                    if (actor.user.toString() === req.query.user.toString()) {
                      for (let c in projs[p].content.data) {
                        data = projs[p].content.data[c]
                        try {
                          if (data.owner_id && data.owner_id.toString() === req.query.user.toString() && !['done', 'reviewed', 'review', 'paused', 'suspended'].includes(data.status) && data.type === 'task' && new Date(data.end_date).setHours(0, 0, 0, 0, 0) > new Date().setHours(0, 0, 0, 0, 0) && new Date(data.end_date).setHours(0, 0, 0, 0, 0) < new Date().setHours(0, 0, 0, 0, 0) + suma7dias) {
                            reply.push({
                              id: data.id,
                              project: projs[p]._id,
                              type: 'task',
                              name: data.text,
                              nameProj: projs[p].name
                            })
                          }
                        } catch (error) {
                          console.log(error)
                        }
                      }
                    }
                  }
                }
              }
              mongo.find('alarm', { unread: mongo.toId(req.session.context.user) }, {}, {}, async (err, alarms) => {
                if (err) throw err
                for (let f in alarms) {
                  try {
                    var index = alarms[f].unread.findIndex((x) => { return x.toString() === req.session.context.user.toString() })
                  } catch (error) {
                    send({ err: error })
                  }
                  alarms[f].unread.splice(index, 1)
                  await new Promise(resolve => {
                    mongo.save('alarm', alarms[f], (err, result) => {
                      if (err) { send({ err: err }) } else { resolve() }
                    })
                  })
                }
                send(reply)
              })
            }
          })
        }
      })
    } catch (error) {
      console.log(error)
    }
  }

  this.list2 = function (req, mongo, send) {
    var skip = parseInt(req.query.start) || 0
    var limit = parseInt(req.query.count) || 50
    var reply = { data: [], pos: skip }
    var keys = { actors: { $elemMatch: { user: req.session.context.user } } }
    if (req.query.date) {
      keys = {}
      keys.document = req.query.document
      keys.date = req.query.date
    }
    mongo.findN('alarm', skip, limit, keys, {}, { _id: -1 }, async (err, alarms) => {
      if (!err && alarms) {
        var userIds = []
        var docIds = []
        var collections = []
        var returnedDocs = {}
        for (let i in alarms) {
          userIds.push(alarms[i].user)
          docIds.push(alarms[i].document.id)
          collections.push(alarms[i].collection)
        }

        for (let u in collections) {
          var findDocs = await new Promise(resolve => {
            mongo.toHash(collections[u], { _id: { $in: docIds } }, {}, (err, docs) => {
              if (!err) {
                resolve(docs)
              }
            })
          })
          returnedDocs = Object.assign(returnedDocs, findDocs)
        }

        mongo.toHash('user', { _id: { $in: userIds } }, { name: 1 }, (err, users) => {
          if (err) throw err
          for (let i in alarms) {
            let alarm = alarms[i]
            alarm.id = alarm._id
            alarm.username = alarm.user ? users[alarm.user.toString()].name : ''
            let index = alarm.actors.findIndex((x) => {
              return x.user.toString() === req.session.context.user.toString() && x.seen === 0
            })
            if (index === -1) {
              alarm.class = ''
            } else {
              alarm.class = 'bold'
            }
            if (returnedDocs[alarm.document.id.toString()]) {
              alarm.docname = returnedDocs[alarm.document.id.toString()].name || returnedDocs[alarm.document.id.toString()].comment
              reply.data.push(alarm)
            }
          }
          mongo.count('alarm', keys, (err, count) => {
            if (!err && count) {
              reply.total_count = count
            }
            send(reply)
          })
        })
      }
    })
  }

  this.list = async function (req, mongo, send) {
    let data = []
    let Today = []
    let SettDays = []
    let Deadline = []

    var ids = []

    if (req.body.user && req.body.user.length) {
      for (var j in req.body.user) {
        ids[j] = mongo.toId(req.body.user[j])
      }
    }

    var sett = await new Promise(resolve => {
      mongo.findOne('settings', { _id: 'settings' }, async (err, sett) => {
        if (!err) {
          resolve(sett)
        } else {
          resolve(false)
        }
      })
    })

    let keys = { 'owner.user': { $in: ids }, status: 'active', date: {$ne: ''} }
    let filterName = ''
    if (req.body.filter) {
      let filter = req.body.filter
      if (filter.type) {
        keys.type = filter.type
      }
      if (filter.name) {
        filterName = filter.name
      }
      if (filter.responsibleName) {
        if (req.body.user.includes(filter.responsibleName)) {
          keys['owner.user'] = { $in: [mongo.toId(filter.responsibleName)] }
        } else {
          keys['owner.user'] = ''
        }
      }
      if (filter.unitName) {
        if (req.body.unit.includes(filter.unitName)) {
          keys['owner.unit'] = { $in: [mongo.toId(filter.unitName)] }
        } else {
          keys['owner.unit'] = ''
        }
      }
      if (filter.dateCreate && filter.dateCreate.start && filter.dateCreate.end) {
        keys._id =  { $gte: mongo.newId(new Date(new Date(filter.dateCreate.start.setHours(00, 00, 00)))), $lt: mongo.newId(new Date(new Date(filter.dateCreate.end.setHours(23, 59, 59)))) }
      }
    }

    let rems = await new Promise(resolve => {
      mongo.find('reminders', keys, {}, async (err, rems) => {
        if (rems && rems.length) {
          resolve(rems)
        } else {
          resolve([])
        }
      })
    })
    for (let i in rems) {
      let rem = rems[i]
      let responsibleName = ''
      let unitName = ''
      let countResponsible = 0
      let countUnit = 0
      if (rem.owner && rem.owner.length) {
        for (var o in rem.owner) {
          let owner = rem.owner[o]
          let name = await new Promise(resolve => {
            mongo.findId('user', owner.user, {name:1}, (err, user) => {
              if (err || !user) {
                resolve('')
              } else {
                resolve(user.name)
              }
            })
          })
          if (Number(o) === 0) responsibleName += name
          else countResponsible++
          let unit = await new Promise(resolve => {
            mongo.findId('unit', owner.unit, {name:1}, (err, unit) => {
              if (err || !unit) {
                resolve('')
              } else {
                resolve(unit.name)
              }
            })
          })
          if (Number(o) === 0) unitName += unit
          else countUnit++
        }
        if(countResponsible) responsibleName = responsibleName + '...+' + countResponsible
        if(countUnit) unitName = unitName + '...+' + countUnit
      }
      if (rem.type === 'commitment') {
        let keys = { _id: rem.document}
        if(filterName) keys.name = new RegExp(filterName, 'i')
        let comm = await new Promise(resolve => {
          mongo.findOne('commitment', keys, {name:1,status:1, template: 1}, (err, docu) => {
            if (err || (!docu)) {
              resolve('')
            } else {
              resolve(docu)
            }
          })
        })
        if (comm) {
          /*let att = await new Promise(resolve => {
            mongo.findId('attached', comm.reference, {name:1}, (err, docu) => {
              if (err || !docu) {
                resolve('')
              } else {
                resolve(docu)
              }
            })
          })*/
          let type2 = await new Promise(resolve => {
            mongo.findId('template', comm.template, { type: 1 }, (err, d) => {
              if (err || !d) resolve('')
              else resolve(d.type)
            })
          })
          data.push({
            id: rem._id,
            idDoc: rem.document,
            responsibleName: responsibleName,
            unitName: unitName,
            name: comm.name,
            //name2: att ? att.name : '',
            date: rem.date,
            dateCreate: tags.util.date2str(rem._id.getTimestamp(), 'DD/MM/YYYY', tags),
            type: rem.type,
            type2: type2,
            status: comm.status
          })
        }
      } else if (rem.type === 'attached') {
        let keys = { _id: rem.document}
        if(filterName) keys.name = new RegExp(filterName, 'i')
        let att = await new Promise(resolve => {
          mongo.findOne('attached', keys, {name:1,status:1, template: 1}, (err, docu) => {
            if (err || !docu) {
              resolve('')
            } else {
              resolve(docu)
            }
          })
        })
        if (att) {
          /*let not = await new Promise(resolve => {
            mongo.findId('note', att.reference, {name:1}, (err, docu) => {
              if (err || !docu) {
                resolve('')
              } else {
                resolve(docu)
              }
            })
          })*/
          let type2 = await new Promise(resolve => {
            mongo.findId('template', att.template, { type: 1 }, (err, d) => {
              if (err || !d) resolve('')
              else resolve(d.type)
            })
          })
          data.push({
            id: rem._id,
            idDoc: rem.document,
            responsibleName: responsibleName,
            unitName: unitName,
            name: att.name,
            //name2: not ? not.name : '',
            date: rem.date,
            dateCreate: tags.util.date2str(rem._id.getTimestamp(), 'DD/MM/YYYY', tags),
            type: rem.type,
            type2: type2,
            status: att.status
          })
        }
      } else if (rem.type === 'note') {
        let keys = { _id: rem.document}
        if(filterName) keys.name = new RegExp(filterName, 'i')
        let note = await new Promise(resolve => {
          mongo.findOne('note', keys, {name:1,status:1, template: 1}, (err, docu) => {
            if (err || !docu) {
              resolve('')
            } else {
              resolve(docu)
            }
          })
        })
        if (note) {
          /*let proj = await new Promise(resolve => {
            mongo.findId('project', note.project, {name:1}, (err, docu) => {
              if (err || !docu) {
                resolve('')
              } else {
                resolve(docu)
              }
            })
          })*/
          let type2 = await new Promise(resolve => {
            mongo.findId('template', note.template, { type: 1 }, (err, d) => {
              if (err || !d) resolve('')
              else resolve(d.type)
            })
          })
          data.push({
            id: rem._id,
            idDoc: rem.document,
            responsibleName: responsibleName,
            unitName: unitName,
            name: note.name,
            //name2: proj ? proj.name : '',
            date: rem.date,
            dateCreate: tags.util.date2str(rem._id.getTimestamp(), 'DD/MM/YYYY', tags),
            type: rem.type,
            type2: type2,
            status: note.status
          })
        }
      }
    }
    for (let i in data) {
      let reminder = data[i]
      if (reminder.date) {
        let now = new Date()
        let diff = ''
        if (sett && sett.days) {
          diff = moment(reminder.date).diff(now, 'days')
        }
        if ((reminder.date.setHours(0, 0, 0) <= now.getTime()) && (reminder.date.setHours(23, 59, 59) >= now.getTime())) {
          Today.push(reminder)
        } else if (sett && (diff <= sett.days) && (diff >= 0)) {
          SettDays.push(reminder)
        } else if (now.getTime() > reminder.date.setHours(23, 59, 59)) {
          Deadline.push(reminder)
        }
      }
    }


    send([Today, SettDays, Deadline])
  }

  this.userList = function (req, mongo, send) {
    let data = []
    let dataUnit = []
    let user = req.session.context ? req.session.context.user : req.body.userAlarm
    mongo.find('reminders', {'supervisor.user': user, status: 'active', date: {$ne: ''} }, {}, async (err, rems) => {
      if (err) {
        send({})
      } else {
        for (let i in rems) {
          let rem = rems[i]
          if (rem.owner && rem.owner.length) {
            for (let o in rem.owner) {
              let owner = rem.owner[o]
              let index = data.findIndex(x => {
                return x.id.toString() === owner.user.toString()
              })
              if (index === -1) {
                await new Promise(resolve => {
                  mongo.findId('user', owner.user, {units:1}, (err, us) => {
                    if (err || !us) {
                      resolve('')
                    } else {
                      if (us.units && us.units.length) {
                        for (let y in us.units) {
                          let index2 = dataUnit.findIndex(x => {
                            return x.toString() === us.units[y].toString()
                          })
                          if(index2 === -1) dataUnit.push(us.units[y])
                        }
                      }
                      resolve()
                    }
                  })
                })
                if (owner.user.toString() !== user.toString()) {
                  let index1 = data.findIndex(x => {
                    return x.toString() === owner.user.toString()
                  })
                  if(index1 === -1) data.push(owner.user)

                  let index2 = dataUnit.findIndex(x => {
                    return x.toString() === owner.unit.toString()
                  })
                  if(index2 === -1) dataUnit.push(owner.unit)
                }
              }
            }
          }
        }
        send([data, dataUnit])
      }
    })
  }

  this.seen = function (req, mongo, send) {
    mongo.findId('alarm', req.body._id, (err, alarm) => {
      if (!err && alarm) {
        var procesar = () => {
          let index = alarm.actors.findIndex((x) => {
            return x.user.toString() === req.session.context.user.toString() && x.seen === 0
          })
          if (index !== -1) {
            alarm.actors[index].seen = 1
            procesar()
          }
        }
        procesar()
        mongo.save('alarm', alarm, (err, result) => {
          if (err) {
            send({ error: tags.savingProblema })
          }
          send({})
        })
      }
    })
  }

  this.seenAll = async function (req, mongo, send) {

    await new Promise(resolve => {
      mongo.saveWithFilter('alarm', {'actors.user': req.session.context.user},
        {'actors.$[ele].seen': 1},
        {
          multi: true,
          upsert: false,
          arrayFilters: [ {'ele.user': req.session.context.user} ]
          // [ { "element": {"element.user": ObjectId("5b103aa45089b30fd853a2b7")} } ]
        },
        (err, result) => {
          if (err) {
            console.log(err)
            resolve()
          } else {
            resolve()
          }
        })
    })
    send({})
  }
}
