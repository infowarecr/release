var tags = require('../utils/tags').tags
exports.Logger = Logger

function Logger (mongo, level) {
  this.mongo = mongo
  this.level = level || 'full'
  this.withoutTrace = [
    'api/params.options',
    'api/user.image',
    'api/user.status',
    'api/user.disconnect',
    'api/document.ofTask',
    'api/comment.comments',
    'api/timeReport.show',
    'api/note.listTree',
    'api/document.ofProject'
  ]

  this.log = (text) => {
    let time = new Date()
    console.log(tags.util.date2str(time, 'dd HH:MM:ss', tags) + ' ' + text)
  }
  this.put = (req, text) => {
    var header = tags.util.date2str(new Date(), 'dd HH:MM:ss', tags)
    if (req && req.session && req.context) {
      let db = req.session.database
      db = db.substring(db.lastIndexOf('/') + 1)
      header += ' [' + db + ':' + req.session.context.user + ']'
    }
    let time = new Date()
    console.log(header + ' ' + text)
  }
  this.firstAuthor = async (mongo, id, typeDoc) => {
    return await new Promise(resolve => {
      mongo.aggregate('trace', [
        { $match: { ref: mongo.toId(id), type: typeDoc, err: false } },
        { $project: { id: 1, user: 1 } },
        { $sort: { _id: 1 } },
        { $limit: 1 },
        { $lookup: { from: 'user', localField: 'user', foreignField: '_id', as: 'us' } },
        { $project: { _id: '$user', name: { $arrayElemAt: ['$us.name', 0] }, when: { $toDate: '$_id' } } }
      ], {}, (err, log) => {
        var r = {}
        if (!err && log.length) {
          r = log[0]
        }
        resolve(r)
      })
    })
  }
  this.lastAuthor = async (mongo, id, typeDoc) => {
    return await new Promise(resolve => {
      mongo.aggregate('trace', [
        { $match: { ref: mongo.toId(id), type: typeDoc, err: false } },
        { $project: { id: 1, user: 1 } },
        { $sort: { _id: -1 } },
        { $limit: 1 },
        { $lookup: { from: 'user', localField: 'user', foreignField: '_id', as: 'us' } },
        { $project: { _id: '$user', name: { $arrayElemAt: ['$us.name', 0] }, when: { $toDate: '$_id' } } }
      ], {}, (err, log) => {
        var r = {}
        if (!err && log.length) {
          r = log[0]
        }
        resolve(r)
      })
    })
  }
  this.save = (log, mongo) => {
    var id = this.mongo.newId()
    var db = log.origin || ''
    if (db) {
      db = db.split('/')
      db = db[db.length - 1]
      db = db.split('?')[0]
    }
    var trace = { _id: id, ip: log.ip, user: log.user, db: db, url: log.url, ms: log.duration }
    if (log.input) {
      var x = log.input
      var ref = x._id || x.id || x.plan || x.planId || x.document || x.project || x.projectId || x.note || x.noteId || x.reference || x.task || x.taskId || x.attached || x.commitment || x.doc || x.docId || x.user || x.userId || x.name || x.tag || x.template
      if (!ref && Object.keys(x).length) {
        ref = x[Object.keys(x)[0]]
      }
      if (ref) {
        if (this.mongo.isNativeId(ref)) {
          trace.ref = ref
        } else {
          var doc = log.url.split('.')[0].split('/')
          doc = doc[doc.length - 1]
          if (this.mongo.isNativeId(ref[doc])) {
            trace.ref = ref[doc]
          }
        }
      }
    }
    if (log.output && !(this.withoutTrace.includes(log.url))) {
      if (log.status) {
        trace.err = log.status
      } else if (log.output.message && log.output.message !== 'savedChanges') {
        trace.err = log.output.message
      } else if (log.output.error) {
        trace.err = log.output.error.message || log.output.error
      } else if (typeof log.output === 'string') {
        trace.err = log.output
      }
      this.mongo.save('trace', trace, (err) => {
        if (err) console.log(err)
      })
    }
    var type = log.url.split('/')[1]
    type = type.split('.')[0]
    if (!trace.err && (log.url.includes('.save') || log.url.includes('.changeProgress'))) {
      var mdb = mongo || this.mongo
      var data = { ...log.input }
      if (log.url.includes('.changeProgress')) {
        data = log.output.doc
      }
      this.filter(data)
      if (type === 'file') {
        data.file = log.output.link.split('id=')[1].split('&')[0]
      }
      mdb.save('version', { _id: id, ip: log.ip, user: log.user, type: type, data: data }, (err) => {
        if (err) console.log(err)
      })
    }
  }
  this.filter = (data) => {
    if (data) {
      for (let x in data) {
        if (x !== 'content') {
          if (typeof x === 'string' && (x.indexOf('dhx') !== -1 || x.indexOf('$') !== -1 || ['pass', 'password'].includes(x))) {
            delete data[x]
          } else if (['object', 'array'].includes(typeof data[x])) {
            this.filter(data[x])
          }
        }
      }
    }
  }
  this.versions = function (req, mongo, send) {
    var pipeline = [
      { $match: { 'data._id': mongo.toId(req.query.document) } },
      { $lookup: { from: 'user', localField: 'user', foreignField: '_id', as: 'us' } },
      { $project: { id: '$_id', _id: '$$REMOVE', user: 1, username: { $arrayElemAt: ['$us.name', 0] }, status: { $ifNull: ['$data.status', '$$REMOVE'] }, progress: { $ifNull: ['$data.realProgress', '$$REMOVE'] }, sequence: { $ifNull: ['$data.sequence.text', '$$REMOVE'] }, dateTime: { $toDate: '$_id' } } },
      { $sort: { id: -1 } }
    ]
    mongo.aggregate('version', pipeline, {}, (err, logs) => {
      if (err) {
        send({ error: err })
      } else {
        send(logs)
      }
    })
  }

  this.get = function (req, mongo, send) {
  mongo.find('version', { _id: mongo.toId(req.query._id) }, async (err, log) => {
      if (err) {
        send({ error: err })
      } else if (log.length) {
        let doc = await new Promise(resolve => {
          mongo.findId(log[0].type, log[0].data._id, { content: 0, template: 0 }, (err, result) => {
            if (!err && result) resolve(result)
            else resolve('')
          })
        })
        let canRestore = false
        if (doc.actors) {
          let index = doc.actors.findIndex(x => {
            return (x.role === 'reviser' || x.role === 'responsible') && (x.user.toString() === req.session.context.user.toString())
          })
          if (index !== -1) canRestore = true
        }
        if (log[0].type === 'note') {
          let document = log[0].data

          var users = []; var units = []
          for (const i in document.actors) {
            users.push(document.actors[i].user)
            units.push(document.actors[i].unit)
          }
          var hashUsers = await new Promise(resolve => {
            mongo.toHash('user', { _id: { $in: users } }, { _id: 1, name: 1 }, (err, result) => {
              if (err) resolve()
              else resolve(result)
            })
          })
          var hashUnits = await new Promise(resolve => {
            mongo.toHash('unit', { _id: { $in: units } }, { _id: 1, name: 1, active: 1, offline: 1 }, (err, result) => {
              if (err) resolve()
              else resolve(result)
            })
          })
          log[0].data.to = []
          log[0].data.copy = []
          for (let i in document.actors) {
            if (document.actors[i] && hashUsers[document.actors[i].user.toString()]) {
              var unit = '/[error]'

              if (document.actors[i].unit && hashUnits[document.actors[i].unit.toString()]) {
                unit = '/' + hashUnits[document.actors[i].unit.toString()].name
              }
              switch (document.actors[i].role) {
              case 'from':
                log[0].data.from = {
                  id: document.actors[i].user.toString(),
                  user: hashUsers[document.actors[i].user.toString()].name + unit
                }
                break
              case 'to':
                log[0].data.to.push({
                  id: document.actors[i].user.toString(),
                  user: hashUsers[document.actors[i].user.toString()].name + unit
                })
                break
              case 'copy':
                log[0].data.copy.push({
                  id: document.actors[i].user.toString(),
                  user: hashUsers[document.actors[i].user.toString()].name + unit
                })
                break
              default:
                break
              }
            }
          }
        } else if (log[0].type === 'attached') {
          let document = log[0].data
          if (document.actors) {
            for (let i in document.actors) {
              if (document.actors[i].role === 'responsible') {
                document.responsible = document.actors[i].user.toString() + '&unit=' + document.actors[i].unit.toString()
                let user = await new Promise(resolve => {
                  mongo.findId('user', document.actors[i].user, { name: 1 }, (err, user) => {
                    if (!err && user) {
                      resolve(user)
                    } else {
                      resolve('')
                    }
                  })
                })
                let unit = await new Promise(resolve => {
                  mongo.findId('unit', document.actors[i].unit, { name: 1 }, (err, unit) => {
                    if (!err && unit) {
                      resolve(unit)
                    } else {
                      resolve('')
                    }
                  })
                })
                document.readResponsible = user.name + '/' + unit.name
                break
              }
            }
          }
        }
        send({ _id: log[0]._id, json: log[0].data, type: log[0].type, status: doc.status, canRestore: canRestore })
      } else {
        send({ json: { key: req.query._id + ' ' + (req.query.ref || ''), message: 'versionNotFound' } })
      }
    })
  }

  this.recover = function (req, mongo, send) {
    var _id = req.query._id
    mongo.findId('version', _id, {'data.actors': 0, 'data.status': 0, 'data.sequence': 0,  'data.answered': 0, 'data.name': 0, 'data.tags': 0, 'data.dates': 0, 'data.data': 0, }, (err, doc) => {
      if (err || !doc) {
        if (err) console.log(err)
        send({ err: 'Error al recuperar' })
      } else {
        if (doc.data) {
          mongo.save(doc.type, doc.data, () => {send(doc.data)})
        } else {
          send({ err: 'Error al recuperar' })
        }
      }
    })
  }
}
