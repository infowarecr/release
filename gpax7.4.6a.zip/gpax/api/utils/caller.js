/**
 * Created by jorge on 29/04/17.
 */
var tags = require('../utils/tags').tags

var X = require('../x/x').X
exports.go = go

function go (req, res) {
  var routes = req.app.routes
  var request = req; var log
  // process response
  async function response (reply) {
    if (request.session && request.session.context && request.session.context.user) {
      log.user = request.session.context.user
      log.origin = req.session.database
    }
    log.output = reply
    log.duration = new Date().getTime() - request.start
    if (log.duration > 3000) {
      req.logger.log(log.origin+':' + request.url + ' -> ' + (log.duration / 1000) + ' segundos')
    }
    if (reply && reply.download) {
      res.download(reply.download)
      // Stream have be piped to reponse stream
    } else if (reply && reply.pipe) {
      if (reply.contentType && reply.filename) {
        if (reply.mongo) {
          res.set('Content-Type', reply.contentType)
          res.set('Content-Disposition', 'attachment; filename="' + encodeURI(reply.filename) + '"')
          if (reply.contentLength) {
            res.set('Content-Length', reply.contentLength)
          }
          res.once('finish', function () {
            log.output = { state: true, filename: request.query.filename, action: 'downloaded' }
            req.logger.save(log,req.mongo)
            res.end()
          })
          res.on('error', (err) => {
            log.output = err
            req.logger.save(log,req.mongo)
          })
          reply.pipe(res)
        } else {
          res.set('Content-Type', reply.contentType)
          res.set('File-name', encodeURI(reply.filename))
          if (reply.contentLength) {
            res.set('Content-Length', reply.contentLength)
          }
          res.once('finish', function () {
            log.output = { state: true, filename: request.query.filename, action: 'downloaded' }
            req.logger.save(log,req.mongo)
            res.end()
          })
          res.on('error', (err) => {
            log.output = err
            req.logger.save(log,req.mongo)
          })
          reply.pipe(res)
        }
      } else {
        if (reply.contentType) res.type(reply.contentType)
        reply.pipe(res)
      }
    } else {
      if (reply) {
        if (reply.error) {
          log.error = 1
        }
        log.output = reply
        if (req.statusCode) {
          if (req.statusCode === 401 && req.headers.cookie && req.headers.cookie.includes('sso=1')) res.set('WWW-Authenticate', 'Negotiate')
          else res.set('WWW-Authenticate', null)
          res.status(req.statusCode).send(reply)
          log.status = req.statusCode
        } else {
          res.send(reply)
        }
      } else {
        log.error = 1
        log.output = { type: 'error', message: tags.msgNotReply }
        if (req.statusCode) {
          if (req.statusCode === 401 && req.headers.cookie && req.headers.cookie.includes('sso=1')) res.set('WWW-Authenticate', 'Negotiate')
          res.status(req.statusCode).send(req.statusText || '')
          log.status = req.statusCode
        } else {
          res.send()
        }
      }
      res.end()
      req.logger.save(log,req.mongo)
    }
  }
  // Prepare special data
  function prepare (json) {
    if (typeof (json) === 'object') {
      for (const property in json) {
        const data = json[property]
        if (/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2}(?:\.\d*)?)(Z|([+-])(\d{2}):(\d{2}))$/.exec(data) ||
          /^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})/.exec(data)) {
          json[property] = new Date(data)
        } else {
          if (/\["|\[{|{"/.exec(data)) {
            try { json[property] = JSON.parse(data) } catch (e) { }
          }
          prepare(json[property])
        }
      }
    }
    return json
  }
  // get or create x
  function getX (cmds, next) {
    if (cmds[0] === 'x') {
      var mongo = request.app.getMongo(request.session.database)
      routes.x = routes.xs[mongo.dbname]
      if (!routes.x) {
        routes.x = new X(request.app)
        routes.xs[mongo.dbname] = routes.x
        routes.x.start(mongo, mongo, next)
      } else {
        next()
      }
    } else {
      next()
    }
  }
  // Call respective 'cmds' method
  async function call (cmds) {
    getX(cmds, () => {
      var obj = routes[cmds[0]]
      if (obj) {
        if (obj[cmds[1]]) {
          request.body = prepare(request.body)
          request.query = prepare(request.query)
          var mongo
          if (request.session && request.session.database) {
            mongo = request.app.getMongo(request.session.database)
          } else {
            mongo = request.app.getMongo(request.app.params.user)
          }
          req.mongo=mongo
          request.start = new Date().getTime()
          try {
            obj[cmds[1]](request, mongo, response)
          } catch (err) {
            req.logger.log(' -> ' + request.path)
            var stack = err.stack
            stack = stack.substr(0, stack.indexOf('gpax/api/utils/caller.js')) + ' ...'
            req.logger.log(stack)
            req.statusCode = 502
            response({ error: 'Error inesperado, por favor reintente, si persiste el error reportelo' })
          }
        } else {
          response({ error: tags.msgNotMethod })
        }
      } else {
        response({ error: tags.msgNotClass })
      }
    })
  }
  log = {ip: request.ip, url: request.path.substring(1), input: request.body && Object.keys(request.body).length ? request.body : request.query }
  // process request normaly
  var cmds = request.path
  cmds = cmds.substring(cmds.lastIndexOf('/') + 1).split('.')
  if (cmds.length === 2) {
    // If are not authenticate user continue...
    if (!request.session.authenticated) {
      if (cmds[0] === 'user' && ['crtAuth','auth'].includes(cmds[1])) {
        call(cmds)
      } else if (req.query.token || req.headers.authorization) {
        routes.user.validate(request, null, (reply) => {
          if (req.statusCode || (cmds[0] === 'user' && cmds[1] === 'connect')) {
            response(reply)
          } else {
            call(cmds)
          }
        })
      } else if (req.headers['x-client-subject']) {
        req.clientSerial = req.headers['x-client-subject'].split('serialNumber=')[1]
        req.clientSerial = req.clientSerial.split(',')[0]
        routes.user.clientSerial(request, null, (reply) => {
          if (req.statusCode || (cmds[0] === 'user' && cmds[1] === 'connect')) {
            response(reply)
          } else {
            call(cmds)
          }
        })
      } else {
        // ...else, left pass to 'user.login' or 'user.connect' or 'user.crtAuth'
        if (cmds[0] === 'user' && ['spConnect','connect','disconnect','sendEmailPassword','pwreset','goURL'].includes(cmds[1])) {
          call(cmds)
        } else {
          req.session.destroy(() => {
            req.statusCode = 401
            response()
          })
        }
      }
    } else {
      call(cmds)
    }
  } else {
    response({ error: tags.msgNotClass })
  }
}
