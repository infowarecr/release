/* exported */
var tags = require('../utils/tags').tags
var Html = require('../utils/html').Html
var html = new Html()
var moment = require('moment')
var Notification = require('../utils/notification').Notification
var notification = new Notification()
exports.Comment = Comment

function Comment () {
  this.removeUnread = async function (req, mongo, send) {
    mongo.findId('comment', req.body._id, (err, comment) => {
      if (!err && comment) {
        const index = comment.unread.findIndex((x) => {
          return x.toString() === req.session.context.user.toString()
        })
        if (index !== -1) {
          comment.unread.splice(index, 1)
        }
        mongo.save('comment', comment, (err, result) => {
          if (err) {
            send({ error: tags.savingProblema })
          } else {
            mongo.findOne('alarm', { 'document._id': mongo.toId(req.body._id) }, {}, async (err, alarm) => {
              if (!err && alarm) {
                const index = alarm.actors.findIndex((x) => {
                  return x.user.toString() === req.session.context.user.toString()
                })
                if (index !== -1) {
                  if (alarm.actors[index].seen === 0) {
                    alarm.actors[index].seen = 1
                    await new Promise(resolve => {
                      mongo.save('alarm', alarm, () => { resolve() })
                    })
                  }
                }
                send({})
              } else send({})
            })
          }
        })
      }
    })
  }

  this.users = function (req, mongo, send) {
    mongo.aggregate('user', [{ $project: { id: '$_id', _id: 0, value: '$name', image: { $concat: ['api/user.image?_id=', { $toString: '$_id' }] } } }], {}, (err, reply) => {
      if (err) {
        send({ error: err })
      } else {
        send(reply)
      }
    })
  }
  this.comments = function (req, mongo, send) {
    var skip = Number(req.query.pos || 0)
    var limit = Number(req.query.more || 50)
    var user = req.query.user
    var mention = req.query.mention
    var option = req.query.option
    var typeDate = req.query.typeDate
    limit = limit>50?50:limit
    var myUnits = req.session.context.managerUnits.concat(req.session.context.assistantUnits)
    var pipeline = [{ $match: { _id: req.session.context.user } }]

    function getWeekNumber (d, week) {
      var thisYear = (d).getFullYear();
      var start = new Date('1/1/' + thisYear);
      var yearStart = moment(start.valueOf());
      var weekNo = moment().isoWeek() - week
      var day = 1 - yearStart._d.getUTCDay()
      if (yearStart._d.getUTCDay() === 6) {
        day = 3 - yearStart._d.getUTCDay()
      } else if (yearStart._d.getUTCDay() === 7) {
        day = 2 - yearStart._d.getUTCDay()
      }
      day = (day < 0) ? day * -1 : day
      return [d.getUTCFullYear(), weekNo, day - 1]
    }

    pipeline.push({
      $lookup: {
        from: 'project',
        pipeline: [
          user ?
            { $match: { $expr: { $or: [{ $in: [mongo.toId(user), { $ifNull: ['$actors.user', []] }] }] } } }
            : { $match: { $expr: { $or: [{ $in: [req.session.context.user, { $ifNull: ['$actors.user', []] }] }, { $in: ['$unit', myUnits] }] } } },
          {
            $project: {
              _id: 1
            }
          }
        ],
        as: 'projects'
      }
    })
    var or = { $or: [] }
    var and = { $and: [] }
    if (user && user.length === 24) and.$and.push({ $eq: [mongo.toId(user), '$user'] })
    if (mention && mention.length === 24) and.$and.push({ $regexMatch: { input: '$comment', regex: new RegExp(mention, 'i') } })
    if (!and.$and.length) {
      or.$or = [
        { $in: ['$$user', { $ifNull: ['$involved', []] }] },
        { $in: ['$$user', { $ifNull: ['$mentions', []] }] },
        { $eq: ['$$user', '$user'] },
        { $in: ['$project', { $ifNull: ['$$projects', []] }] }
      ]
    }
    let expr = {
      $expr: {
        $and: [
          and.$and.length ? and : or
        ]
      }
    }
    if (req.query.today) {
      expr.$expr.$and.push({ $gte: [{ $toDouble: { '$toDate': '$_id' } }, { $toDouble: new Date(new Date().setHours(0, 0, 0)) }] })
    } else if (req.query.thisWeek) {
      var result = getWeekNumber(new Date(), 0)
      var primer = new Date(result[0], 0, (result[1] - 1) * 7 + 1 + result[2])
      var ultimo = new Date(new Date().setDate(new Date().getDate() - 1))
      if (ultimo.getTime() >= primer.getTime()) {
        expr.$expr.$and.push({ $gte: [{ $toDouble: { '$toDate': '$_id' } }, { $toDouble: primer.setHours(0, 0, 0) }] })
        expr.$expr.$and.push({ $lte: [{ $toDouble: { '$toDate': '$_id' } }, { $toDouble: ultimo.setHours(23, 59, 59) }] })
      } else {
        send({data: []})
        return
      }
    } else if (req.query.lastWeek) {
      var result = getWeekNumber(new Date(), 1)
      var primer = new Date(result[0], 0, (result[1] - 1) * 7 + 1 + result[2])
      var ultimo = new Date(result[0], 0, (result[1] - 1) * 7 + 7 + result[2])
      expr.$expr.$and.push({ $gte: [{ $toDouble: { '$toDate': '$_id' } }, { $toDouble: primer.setHours(0, 0, 0) }] })
      expr.$expr.$and.push({ $lte: [{ $toDouble: { '$toDate': '$_id' } }, { $toDouble: ultimo.setHours(23, 59, 59) }] })
    } else if (req.query.previous) {
      var result = getWeekNumber(new Date(), 2)
      var ultimo = new Date(result[0], 0, (result[1] - 1) * 7 + 7 + result[2])
      expr.$expr.$and.push({ $lte: [{ $toDouble: { '$toDate': '$_id' } }, { $toDouble: ultimo.setHours(23, 59, 59) }] })
    } else {
      return
    }

    let sort = ''
    if (option === 'notSeen') {
      expr.$expr.$and.push({ $and: [{ $in: ['$$user', '$unread'] }, { $ne: ['$$user', '$user'] }] })
    } else if (option === 'urgent') {
      expr.$expr.$and.push({ $eq: ['1', '$type'] })
    } else if (option === 'important') {
      expr.$expr.$and.push({ $eq: ['2', '$type'] })
    } else if (option === 'normal') {
      expr.$expr.$and.push({ $or: [{ $eq: ['3', '$type'] }, { $eq: ['', '$type'] }, { $eq: [null, '$type'] }] })
    }

    if (typeDate === 'new') {
      sort = { $sort: { _id: -1 } }
    } else if (typeDate === 'old') {
      sort = { $sort: { _id: 1 } }
    }
    pipeline.push({
      $lookup: {
        from: 'comment',
        let: { user: '$_id', projects: '$projects._id' },
        pipeline: [
          {
            $match: expr
          },
          { $group: { _id: null, comments: { $sum: 1 } } }
        ],
        as: 'total'
      }
    })
    pipeline.push({
      $lookup: {
        from: 'comment',
        let: { user: '$_id', projects: '$projects._id' },
        pipeline: [
          {
            $match: expr
          },
          sort ? sort : { $sort: { _id: -1, } },
          { $skip: skip },
          { $limit: limit },
          {
            $lookup: {
              from: 'note',
              let: { document: '$document' },
              pipeline: [
                { $match: { $expr: { $eq: ['$$document', '$_id'] } } },
                { $project: { name: 1 } }
              ],
              as: 'tnote'
            }
          },
          {
            $lookup: {
              from: 'attached',
              let: { document: '$document' },
              pipeline: [
                { $match: { $expr: { $eq: ['$$document', '$_id'] } } },
                { $project: { name: 1 } }
              ],
              as: 'tattached'
            }
          },
          {
            $lookup: {
              from: 'commitment',
              let: { document: '$document' },
              pipeline: [
                { $match: { $expr: { $eq: ['$$document', '$_id'] } } },
                { $project: { name: 1 } }
              ],
              as: 'tcommitment'
            }
          },
          {
            $lookup: {
              from: 'evidence',
              let: { document: '$document' },
              pipeline: [
                { $match: { $expr: { $eq: ['$$document', '$_id'] } } },
                { $project: { name: 1 } }
              ],
              as: 'tevidence'
            }
          },
          {
            $lookup: {
              from: 'document',
              let: { document: '$document' },
              pipeline: [
                { $match: { $expr: { $eq: ['$$document', '$_id'] } } },
                { $project: { name: 1 } }
              ],
              as: 'tdocument'
            }
          },
          {
            $lookup: {
              from: 'task',
              let: { document: '$document' },
              pipeline: [
                { $match: { $expr: { $eq: ['$$document', '$_id'] } } },
                { $project: { text: 1 } }
              ],
              as: 'ttask'
            }
          },
          {
            $lookup: {
              from: 'project',
              let: { project: '$project' },
              pipeline: [
                { $match: { $expr: { $eq: ['$$project', '$_id'] } } },
                { $project: { name: 1 } }
              ],
              as: 'tprojectTask'
            }
          },
          {
            $lookup: {
              from: 'plan',
              let: { document: '$document' },
              pipeline: [
                { $match: { $expr: { $eq: ['$$document', '$_id'] } } },
                { $project: { name: 1 } }
              ],
              as: 'tplan'
            }
          },
          {
            $lookup: {
              from: 'strategy',
              let: { document: '$document' },
              pipeline: [
                { $match: { $expr: { $eq: ['$$document', '$_id'] } } },
                { $project: { name: 1 } }
              ],
              as: 'tstrategy'
            }
          },
          {
            $lookup: {
              from: 'project',
              let: { document: '$document' },
              pipeline: [
                { $match: { $expr: { $eq: ['$$document', '$_id'] } } },
                { $project: { name: 1 } }
              ],
              as: 'tproject'
            }
          },
          {
            $lookup: {
              from: 'time',
              let: { document: '$document' },
              pipeline: [
                { $match: { $expr: { $eq: ['$$document', '$_id'] } } },
                {
                  $lookup: {
                    from: 'task',
                    let: { document: '$document' },
                    pipeline: [
                      { $match: { $expr: { $eq: ['$$document', '$_id'] } } },
                      {
                        $project: { text: 1 }
                      }
                    ],
                    as: 'ttask'
                  }
                },
                { $unwind: { path: '$ttask', preserveNullAndEmptyArrays: true } },
                {
                  $lookup: {
                    from: 'project',
                    let: { document: '$project' },
                    pipeline: [
                      { $match: { $expr: { $eq: ['$$document', '$_id'] } } },
                      {
                        $project: { name: 1 }
                      }
                    ],
                    as: 'tproject'
                  }
                },
                { $unwind: { path: '$tproject', preserveNullAndEmptyArrays: true } },
                {
                  $lookup: {
                    from: 'plan',
                    let: { document: '$plan' },
                    pipeline: [
                      { $match: { $expr: { $eq: ['$$document', '$_id'] } } },
                      {
                        $project: { name: 1 }
                      }
                    ],
                    as: 'tplan'
                  }
                },
                { $unwind: { path: '$tplan', preserveNullAndEmptyArrays: true } },
                {
                  $lookup: {
                    from: 'activity',
                    let: { document: '$document' },
                    pipeline: [
                      { $match: { $expr: { $eq: ['$$document', '$_id'] } } },
                      {
                        $project: { name: 1 }
                      }
                    ],
                    as: 'tactivity'
                  }
                },
                { $unwind: { path: '$tactivity', preserveNullAndEmptyArrays: true } }
              ],
              as: 'ttime'
            }
          },
          {
            $project: {
              id: '$_id', _id: 0, user_id: '$user', type: { $ifNull: ['$type', '3'] }, document: 1, collection: 1, documentType: 1, project: 1, text: '$comment',
              date: { $dateToString: { format: '%Y-%m-%d %H:%M', date: { $ifNull: ['$dateTime', '$_id'] }, timezone: 'America/Costa_Rica' } },
              tnote: 1,
              tattached: 1,
              tcommitment: 1,
              tevidence: 1,
              tdocument: 1,
              ttask: 1,
              tprojectTask: 1,
              tproject: 1,
              tplan: 1,
              tstrategy: 1,
              ttime: 1,
              unread: 1,
              read: {
                $ifNull: [{
                  $filter: {
                    input: { $setUnion: ['$involved', '$mentions', ['$user']] }, as: 'user',
                    cond: { $or: [{ $not: [{ $in: ['$$user', '$unread'] }] }, { $eq: ['$$user', '$user'] }] }
                  }
                }, []]
              },
              seen: { $cond: { if: { $and: [{ $in: ['$$user', '$unread'] }, { $ne: ['$$user', '$user'] }] }, then: false, else: true } }
            }
          },
          sort ? { $sort: { seen: 1 } } : { $sort: { seen: 1, type: 1, } },
        ],
        as: 'comments'
      }
    })
    pipeline.push({ $project: { data: '$comments', more: { $ifNull: [{ $subtract: [{ $arrayElemAt: ['$total.comments', 0] }, skip + limit] }, 0] } } })
    mongo.aggregate('user', pipeline, {allowDiskUse: true}, (err, comments) => {
      if (err) {
        send({ error: err })
      } else {
        if (comments[0] && comments[0].more < 0) comments[0].more = 0
        if (comments[0] && comments[0].data) {
          let allComments = comments[0].data
          for (let i in allComments) {
            var documentName = ''
            var projectName = ''
            var typeDocument = ''
            allComments[i].all = comments[0].more
            if (allComments[i].text.includes('//')) {
              var linkReg = /(<[Aa]\s(.*)<\/[Aa]>)/g
              var linksInText = allComments[i].text.match(linkReg)
              for (let l in linksInText) {
                if (linksInText[l].includes('//')) {
                  let link = linksInText[l]
                  link = link.split('href=')[1].split('"')[1]
                  allComments[i].text = allComments[i].text.replace(linksInText[l], link)
                }
              }
            }
            //allComments[i].text = allComments[i].text.replace(new RegExp('//', 'g'),'&#2f;&#2f;')
            if (allComments[i].text.includes('class="u-url"')) {
              allComments[i].text = allComments[i].text.replace(/class="u-url"/g, 'class="u-url" onclick="return false;"')
            }
            if (allComments[i].tnote.length && allComments[i].tnote[0].name) {
              documentName = allComments[i].tnote[0].name
              typeDocument = 'Nota'
            } else if (allComments[i].tattached.length && allComments[i].tattached[0].name) {
              documentName = allComments[i].tattached[0].name
              typeDocument = 'Anexo'
            } else if (allComments[i].tcommitment.length && allComments[i].tcommitment[0].name) {
              documentName = allComments[i].tcommitment[0].name
              typeDocument = 'Compromiso'
            } else if (allComments[i].tevidence.length && allComments[i].tevidence[0].name) {
              documentName = allComments[i].tevidence[0].name
              typeDocument = 'Evidencia'
            } else if (allComments[i].tdocument.length &&allComments[i].tdocument[0].name) {
              documentName = allComments[i].tdocument[0].name
              typeDocument = 'Documento'
            } else if (allComments[i].ttask.length && allComments[i].ttask[0].text) {
              documentName = allComments[i].ttask[0].text
              typeDocument = 'Tarea'
            } else if (allComments[i].tproject.length && allComments[i].tproject[0].name) {
              documentName = allComments[i].tproject[0].name
              typeDocument = 'Proyecto'
            } else if (allComments[i].tplan.length && allComments[i].tplan[0].name) {
              documentName = allComments[i].tplan[0].name
              typeDocument = 'Plan Operativo'
            } else if (allComments[i].tstrategy.length && allComments[i].tstrategy[0].name) {
              documentName = allComments[i].tstrategy[0].name
              typeDocument = 'Plan Estratégico'
            } else if (allComments[i].ttime.length) {
              if (allComments[i].ttime[0].tproject) {
                documentName = 'Proyecto: ' + (allComments[i].ttime[0].tproject ? allComments[i].ttime[0].tproject.name : '') + '/Tarea: ' + (allComments[i].ttime[0].ttask ? allComments[i].ttime[0].ttask.text : '')
                allComments[i].taskName = (allComments[i].ttime[0].ttask ?allComments[i].ttime[0].ttask.text: '')
              } else {
                documentName = 'Plan: ' + (allComments[i].ttime[0].tplan ? allComments[i].ttime[0].tplan.name : '') + '/Actividad: ' + (allComments[i].ttime[0].tactivity ? allComments[i].ttime[0].tactivity.name : '')
                allComments[i].activityName = (allComments[i].ttime[0].tactivity ? allComments[i].ttime[0].tactivity.name: '')
              }
              typeDocument = 'Reporte de tiempo'
            }
            if (allComments[i].tprojectTask.length && allComments[i].tprojectTask[0].name) {
              projectName = allComments[i].tprojectTask[0].name
            }

            let firstComment = ''
            if (projectName) {
              firstComment = projectName +'/'+ typeDocument+ ': '+ documentName
            } else {
              firstComment = typeDocument+ ': '+ documentName
            }
            firstComment += '</br>'
            allComments[i].text = firstComment + allComments[i].text
          }
        }
        var reply = comments[0]
        send(reply)
      }
    })
  }
  this.listAll = function (req, mongo, send) {
    var skip = Number(req.query.skip ||0)
    var limit = Number(req.query.limit || 100)
    var keys = { $or: [{ involved: mongo.toId(req.session.context.user) }, { mentions: mongo.toId(req.session.context.user) }, { user: req.session.context.user }] }
    if (req.query.idComment) {
      keys = { _id: mongo.toId(req.query.idComment) }
    }
    mongo.findN('comment', skip, limit, keys, {}, { _id: -1 }, (err, comments) => {
      let read = []
      let unread =[]
      if (!err && comments) {
        var userIds = []
        var idsDocument = []
        for (const i in comments) {
          userIds.push(comments[i].user)
          for (const j in comments[i].involved) {
            userIds.push(comments[i].involved[j])
          }
          idsDocument.push(comments[i].document)
        }
        mongo.find('time', { _id: { $in: idsDocument } }, {}, {}, (err, times) => {
          if (err) throw err
          mongo.find('note', { _id: { $in: idsDocument } }, {}, {}, (err, notes) => {
            if (err) throw err
            mongo.find('attached', { _id: { $in: idsDocument } }, {}, {}, (err, attacheds) => {
              if (err) throw err
              mongo.find('commitment', { _id: { $in: idsDocument } }, {}, {}, (err, commitments) => {
                if (err) throw err
                mongo.find('evidence', { _id: { $in: idsDocument } }, {}, {}, (err, evidences) => {
                  if (err) throw err
                  mongo.find('document', { _id: { $in: idsDocument } }, {}, {}, (err, documents) => {
                    if (err) throw err
                    var idsProj = []
                    for (const i in documents) {
                      if (documents[i].project) {
                        idsProj.push(documents[i].project)
                      }
                    }
                    mongo.find('project', { _id: { $in: idsDocument } }, {}, {}, (err, projects) => {
                      if (err) throw err
                      mongo.toHash('user', { _id: { $in: userIds } }, { name: 1 }, (err, users) => {
                        if (err) throw err
                        mongo.toHash('project', { _id: { $in: idsProj } }, { }, async (err, projs) => {
                          if (err) throw err
                          for (const i in comments) {
                            const seenActors = []
                            const deliveredActors = []
                            const comment = comments[i]
                            comment.dateTime = comment._id.getTimestamp()
                            comment.username = users[comment.user.toString()] ? users[comment.user.toString()].name : '@error'
                            if (comment.unread && comment.unread.length > 0) {
                              comment.class = comment.unread.findIndex((x) => { return x.toString() === req.session.context.user.toString() }) === -1 ? '' : 'bold'
                            } else {
                              comment.class = ''
                            }
                            for (const j in comment.involved) {
                              const exists = comment.unread.findIndex((x) => {
                                return x.toString() === comment.involved[j].toString()
                              })
                              const user = users[comment.involved[j].toString()]
                              if (exists === -1 && user) {
                                seenActors.push({ id: comment.involved[j], name: user ? user.name : '' })
                              } else if (comment.involved[j] !== '[]') {
                                deliveredActors.push({ id: comment.involved[j], name: user ? user.name : '' })
                              }
                            }

                            comment.seenActors = seenActors
                            comment.deliveredActors = deliveredActors
                            if (comment.unread.length === 0) { comment.seen = 'seen' } else { comment.seen = 'notseen' }

                            if (comment.documentType === 'task') {
                              if (!comment.project) {
                                comment.project = await new Promise(resolve => {
                                  mongo.findOne('project', { 'content.data.id': comment.document }, { _id: 1 }, (err, result) => {
                                    if (err) {
                                      console.log(err)
                                      resolve('')
                                    } else {
                                      resolve(result._id)
                                    }
                                  })
                                })
                              }
                              let r = comment.unread.findIndex((x) => {
                                return x.toString() === req.session.context.user.toString()
                              })
                              if (r !== -1) {
                                unread.push(comment)
                              } else {
                                read.push(comment)
                              }
                            }
                            for (const j in times) {
                              if (comment.document.toString() === times[j]._id.toString()) {
                                let r = comment.unread.findIndex((x) => {
                                  return x.toString() === req.session.context.user.toString()
                                })
                                if (r !== -1) {
                                  unread.push(comment)
                                } else {
                                  read.push(comment)
                                }
                              }
                            }
                            for (const j in notes) {
                              if (comment.document.toString() === notes[j]._id.toString()) {
                                comment.documentType = notes[j].type
                                comment.issued = notes[j].issued
                                let r = comment.unread.findIndex((x) => {
                                  return x.toString() === req.session.context.user.toString()
                                })
                                if (r !== -1) {
                                  unread.push(comment)
                                } else {
                                  read.push(comment)
                                }
                              }
                            }
                            for (const j in documents) {
                              if (comment.document.toString() === documents[j]._id.toString()) {
                                comment.documentType = documents[j].type
                                comment.issued = documents[j].issued
                                if (documents[j].project) { comment.project = projs[documents[j].project.toString()] }
                                let r = comment.unread.findIndex((x) => {
                                  return x.toString() === req.session.context.user.toString()
                                })
                                if (r !== -1) {
                                  unread.push(comment)
                                } else {
                                  read.push(comment)
                                }
                              }
                            }
                            for (const j in attacheds) {
                              if (comment.document.toString() === attacheds[j]._id.toString()) {
                                comment.documentType = 'attached'
                                comment.issued = attacheds[j].issued
                                let r = comment.unread.findIndex((x) => {
                                  return x.toString() === req.session.context.user.toString()
                                })
                                if (r !== -1) {
                                  unread.push(comment)
                                } else {
                                  read.push(comment)
                                }
                              }
                            }
                            for (const j in commitments) {
                              if (comment.document.toString() === commitments[j]._id.toString()) {
                                comment.documentType = 'commitment'
                                comment.issued = commitments[j].issued
                                let r = comment.unread.findIndex((x) => {
                                  return x.toString() === req.session.context.user.toString()
                                })
                                if (r !== -1) {
                                  unread.push(comment)
                                } else {
                                  read.push(comment)
                                }
                              }
                            }
                            for (const j in evidences) {
                              if (comment.document.toString() === evidences[j]._id.toString()) {
                                comment.documentType = 'evidence'
                                comment.issued = evidences[j].issued
                                let r = comment.unread.findIndex((x) => {
                                  return x.toString() === req.session.context.user.toString()
                                })
                                if (r !== -1) {
                                  unread.push(comment)
                                } else {
                                  read.push(comment)
                                }
                              }
                            }
                            for (const x in projects) {
                              if (comment.document.toString() === projects[x]._id.toString()) {
                                comment.documentType = 'project'
                                comment.name = projects[x].name
                                let r = comment.unread.findIndex((x) => {
                                  return x.toString() === req.session.context.user.toString()
                                })
                                if (r !== -1) {
                                  unread.push(comment)
                                } else {
                                  read.push(comment)
                                }
                              }
                            }
                          }
                          send(unread.concat(read))
                        })
                      })
                    })
                  })
                })
              })
            })
          })
        })
      }
    })
  }

  this.readComments = function (req, mongo, send) {
    var keys = { document: mongo.toId(req.body.document), $or: [{ migrated: 1 }, { involved: { $in: [req.session.context.user] } }, { mentions: { $in: [req.session.context.user] } }, { user: req.session.context.user }] }
    mongo.find('comment', keys, {}, {}, async (err, comments) => {
      if (err) { throw err } else {
        for (const c in comments) {
          const comment = comments[c]
          const index = comment.unread.findIndex((x) => {
            return x.toString() === req.session.context.user.toString()
          })
          if (index !== -1) {
            comment.unread.splice(index, 1)
          }
          await new Promise(resolve => {
            mongo.save('comment', comment, (err, result) => {
              if (!err) {
                resolve(result)
              }
            })
          })
        }
        send({})
      }
    })
  }

  this.seenAll = async function (req, mongo, send) {

    await new Promise(resolve => {
      mongo.updateAll('comment', {'unread': req.session.context.user},
        { $pull: {unread: req.session.context.user}},
        (err, result) => {
          if (err) {
            console.log(err)
            resolve()
          } else {
            resolve()
          }
        })
    })
    send({})
  }

  this.list = async function (req, mongo, send) {
    var pipeline = [{ $match: { _id: req.session.context.user } }]
    pipeline.push({
      $lookup: {
        from: 'comment',
        let: { user: '$_id', document: mongo.toId(req.query.document) },
        pipeline: [
          { $match: { $expr: { $eq: ['$$document', '$document'] } } },
          {
            $addFields: {
              unread: { $cond: { if: { $isArray: ['$unread'] }, then: '$unread', else: [] } }
            }
          },
          {
            $project: {
              id: '$_id', _id: 0, user_id: '$user', type: 1, document: 1, collection: 1, documentType: 1, project: 1, text: '$comment',
              date: { $dateToString: { format: '%Y-%m-%d %H:%M', date: { $ifNull: ['$dateTime', '$_id'] }, timezone: 'America/Costa_Rica' } },
              read: { $ifNull: [{
                $filter: {
                  input: { $setUnion: ['$involved', '$mentions', ['$user']] }, as: 'user',
                  cond: { $or: [{ $not: [{ $in: ['$$user', '$unread'] }] }, {$eq: ['$$user','$user']}] }
                }
              }, []] },
              unread: 1,
              seen: { $cond: { if: { $and: [{ $in: ['$$user', '$unread'] }, { $ne: ['$$user', '$user'] }] }, then: false, else: true } }
            }
          },
          { $sort: { date: 1 } }
        ],
        as: 'comments'
      }
    })
    pipeline.push({
      $lookup: {
        from: 'user',
        let: {
          users: {
            $reduce: {
              input: { $concatArrays: ['$comments.read', '$comments.unread'] }, initialValue: [], in: { $setUnion: ['$$value', '$$this'] }
            }
          }
        },
        pipeline: [
          { $match: { $expr: { $in: ['$_id', '$$users'] } } },
          { $project: { id: '$_id', _id: 0, value: '$name', image: { $concat: ['api/user.image?_id=', { $toString: '$_id' }] } } }
        ],
        as: 'users'
      }
    })
    pipeline.push({$project: {users: 1,comments: 1}})
    mongo.aggregate('user', pipeline, {}, (err, comments) => {
      if (err) {
        send({ error: err })
      } else {
        if (comments[0] && comments[0].comments) {
          let allComments = comments[0].comments
          for (let i in allComments) {
            if (allComments[i].text.includes('//')) {
              var linkReg = /(<[Aa]\s(.*)<\/[Aa]>)/g
              var linksInText = allComments[i].text.match(linkReg)
              for (let l in linksInText) {
                if (linksInText[l].includes('//')) {
                  let link = linksInText[l]
                  link = link.split('href=')[1].split('"')[1]
                  allComments[i].text = allComments[i].text.replace(linksInText[l], link)
                }
              }
            }
            if (allComments[i].text.includes('class="u-url"')) {
              allComments[i].text = allComments[i].text.replace(/class="u-url"/g, 'class="u-url" onclick="return false;"')
              /* let split1 = allComments[i].text.split('class="u-url"')[0]
              let split2 = allComments[i].text.split('class="u-url"')[1]
              if (allComments[i].text && !split2.includes('onclick="return false')) {
                allComments[i].text = split1 + ' class="u-url" onclick="return false; "' + split2
              } */
            }
          }
        }
        send(comments[0])
      }
    })
  }

  this.save = function (req, mongo, send, data) {
    var comment = data || req.body
    comment.dateTime = new Date() // set server datetime to comment
    comment.dateAlarm = new Date()
    var project
    html.getData(comment.comment, async (data) => {
      comment.mentions = []
      if (comment.document) {
        var document
        if (comment.document.length > 0 && comment.document.length === 24) {
          document = mongo.toId(comment.document)
        } else {
          document = comment.document
        }
      }
      if (data.actors && data.actors.length > 0) {
        let checkUserLicense = await new Promise(resolve=>{
          mongo.findId('user', req.session.context.user, (err, user) => {
            if (user && user.licensedUser) {
              resolve(true)
            } else {
              resolve(false)
            }
          })
        })
        await new Promise(resolve => {
          mongo.find('comment', { document: document }, {}, async (err, comms) => {
            for (const i in data.actors) {
              data.actors[i].path = 'referred'
              comment.mentions.push(mongo.toId(data.actors[i].user))
              if (checkUserLicense) {
                let checkActorLicense = await new Promise(resolve=>{
                  mongo.findId('user', data.actors[i].user, (err, user) => {
                    if (user && user.licensedUser) {
                      resolve(true)
                    } else {
                      resolve(false)
                    }
                  })
                })
                if (checkActorLicense) {
                  data.actors[i].role = 'reviser'
                } else {
                  data.actors[i].role = 'copy'
                }
              } else {
                data.actors[i].role = 'copy'
              }
              if (comms && comms.length) {
                for(let c in comms) {
                  let index = comms[c].involved.findIndex((x) => {
                    return x.toString() === data.actors[i].user.toString()
                  })
                  if (index === -1) {
                    comms[c].involved.push(mongo.toId(data.actors[i].user))
                    await new Promise(resolve => {
                      mongo.findId('unit', data.actors[i].unit || '', (err, unit) => {
                        if (unit) {
                          if (unit.actors && unit.actors.length) {
                            for (let a in unit.actors) {
                              if (unit.actors[a].type && unit.actors[a].type[0] === 'assistant') {
                                comms[c].involved.push(unit.actors[a].user)
                              }
                            }
                          }
                        }
                        mongo.save('comment', comms[c], async () => {
                          resolve()
                        })
                      })
                    })
                  }
                }
              }
            }
            resolve()
          })
        })
      }
      var collection = comment.documentType || comment.collection
      comment._id = mongo.newId()
      comment.user = req.session.context.user
      comment.unread = []
      comment.involved = comment.involved || []
      if (req.query.taskOwnerId) {
        comment.involved.push(req.query.taskOwnerId)
        comment.unread.push(req.query.taskOwnerId)
      }
      delete comment.username
      delete comment.webix_operation
      if (req.query.project) {
        project = await new Promise(resolve => {
          mongo.find('project', { _id: mongo.toId(req.query.project) }, {}, (err, project) => {
            if (!err && project.length) {
              resolve(project[0])
            } else {
              resolve(false)
            }
          })
        })
      }
      // email notification
      if (['note', 'attached', 'commitment', 'evidence'].includes(comment.collection)) {
        var doc = {}
        doc._id = comment.document
        doc.type = comment.documentType
        doc.collection = comment.collection
        doc.actors = data.actors
        doc.message = 'Fue mencionado en un comentario  '
        await new Promise(resolve => {
          notification.notifyMention(req, doc, mongo, send)
          resolve()
        })
      }
      let route = ''
      if (req.app.routes[comment.collection] && req.app.routes[comment.collection].addActors) route = comment.collection
      if (req.app.routes[comment.documentType] && req.app.routes[comment.documentType].addActors) route = comment.documentType
      if (req.app.routes[route] && req.app.routes[route].addActors) {
        req.app.routes[route].addActors(req, document, data.actors, mongo, async (err, doc) => {
          if (err) throw err
          if (doc) {
            if (collection === 'attached') {
              await new Promise(resolve => {
                mongo.findId('note', doc.reference, (err, not) => {
                  if (not) {
                    for (let i in not.actors) {
                      let index = doc.actors.findIndex((x) => {
                        return x.user.toString() === not.actors[i].user.toString()
                      })
                      if (index === -1) {
                        doc.actors.push(not.actors[i])
                      }
                    }
                    resolve()
                  } else resolve()
                })
              })
            }
            if (collection === 'commitment') {
              await new Promise(resolve => {
                mongo.findId('attached', doc.reference, (err, att) => {
                  if (att) {
                    mongo.findId('note', att.reference, (err, not) => {
                      if (not) {
                        for (let i in not.actors) {
                          let index = doc.actors.findIndex((x) => {
                            return x.user.toString() === not.actors[i].user.toString()
                          })
                          if (index === -1) {
                            doc.actors.push(not.actors[i])
                          }
                        }
                        resolve()
                      } else resolve()
                    })
                  } else resolve()
                })
              })
            }
            if (collection === 'evidence') {
              await new Promise(resolve => {
                mongo.findId('commitment', doc.reference, (err, comm) => {
                  if (comm) {
                    mongo.findId('attached', comm.reference, (err, att) => {
                      if (att) {
                        mongo.findId('note', att.reference, (err, not) => {
                          if (not) {
                            for (let i in not.actors) {
                              let index = doc.actors.findIndex((x) => {
                                return x.user.toString() === not.actors[i].user.toString()
                              })
                              if (index === -1) {
                                doc.actors.push(not.actors[i])
                              }
                            }
                            resolve()
                          } else resolve()
                        })
                      } else resolve()
                    })
                  } else resolve()
                })
              })
            }
            for (const i in doc.actors) {
              if (doc.actors[i].user.toString() !== req.session.context.user.toString() && doc.actors[i].path !== 'hidden') {
                comment.unread.push(doc.actors[i].user)
                comment.involved.push(doc.actors[i].user)
              }
              await new Promise(resolve => {
                mongo.findId('unit', doc.actors[i].unit || '', (err, unit) => {
                  if (unit) {
                    if (unit.actors && unit.actors.length) {
                      for (let a in unit.actors) {
                        if (unit.actors[a].type && unit.actors[a].type[0] === 'assistant') {
                          let index = comment.involved.findIndex((x) => {
                            return x.toString() === unit.actors[a].user.toString()
                          })
                          if (index === -1) {
                            comment.unread.push(unit.actors[a].user)
                            comment.involved.push(unit.actors[a].user)
                          }
                        }
                      }
                    }
                  }
                  resolve()
                })
              })
            }
            // Preguntar si se agrega manager al comentario////

            if (project && project.actors) {
              for (const a in project.actors) {
                if (project.actors[a].user && project.actors[a].type[0] === 'manager') {
                  comment.involved.push(project.actors[a].user)
                }
              }
            }
          }
          let uniqueUnread = []
          for (let u in comment.unread) {
            let index = uniqueUnread.findIndex(x => {
              return x.toString() === comment.unread[u].toString()
            })
            if (index === -1) {
              uniqueUnread.push(comment.unread[u])
            }
          }
          comment.unread = uniqueUnread
          mongo.save('comment', comment, (err, result) => {
            if (err) {
              send({ error: tags.savingProblema })
            } else {
              if (doc) { comment.issued = doc.issued }
              send(comment)
              req.query.idComment = comment._id
              this.listAll(req, mongo, async (data) => {
                notification.send(req, req.session.context.room, 'viewComments', data, comment.involved.concat(comment.mentions.concat([req.session.context.user])), null)
                notification.mention(req, req.session.context.name, comment.mentions, comment.involved, comment)
              })
            }
          })
        })
      } else {
        comment.unread = comment.mentions
        if (comment.userTo) {
          comment.involved.push(comment.userTo)
          comment.unread.push(comment.userTo)
          delete comment.userTo
        }
        // si es un reporte de tiempo
        if (comment.collection === 'timeReport') {
          let time = await new Promise(resolve => {
            mongo.find('time', { _id: mongo.toId(comment.document) }, {}, (err, time) => {
              if (!err && time.length) {
                resolve(time[0])
              } else {
                resolve(false)
              }
            })
          })
          if (time) {
            //agrega al gerente y asistente de la unidad del proyecto////

            /* let projectOfTime = await new Promise(resolve => {
              mongo.find('project', { _id: time.project }, {}, (err, project) => {
                if (!err && project.length) {
                  resolve(project[0])
                } else {
                  resolve(false)
                }
              })
            })
            if (projectOfTime) {
              let unit = await new Promise(resolve => {
                mongo.find('unit', { _id: projectOfTime.unit }, {}, (err, unit) => {
                  if (!err && unit.length) {
                    resolve(unit[0])
                  } else {
                    resolve(false)
                  }
                })
              })
              if (unit) {
                for (let a in unit.actors) {
                  if (unit.actors[a].type[0] === 'manager' || unit.actors[a].type[0] === 'assistant') {
                    comment.involved.push(unit.actors[a].user)
                    comment.unread.push(unit.actors[a].user)
                  }
                }
              }
            } */
            if (time.user.toString() !== comment.user.toString()) {
              comment.involved.push(time.user)
              comment.unread.push(time.user)
            }
          }
        }
        // Preguntar si se agrega manager al comentario////

        if (project && project.actors) {
          for (const a in project.actors) {
            if (project.actors[a].user && project.actors[a].type[0] === 'manager') {
              comment.involved.push(project.actors[a].user)
              comment.unread.push(project.actors[a].user)
            }
          }
        }
        comment.unread=comment.unread.filter(u=>{return !u.equals(req.session.context.user)})
        mongo.save('comment', comment, async (err, result) => {
          if (err) {
            send({ error: tags.savingProblema })
          } else {
            if (comment.collection === 'timeReport') {
              var sendData = { id: comment._id.getTimestamp(), user: req.session.context.user, username: req.session.context.name, document: comment.document, comment: comment.comment, dateTime: comment._id.getTimestamp() }
              notification.send(req, req.session.context.room, 'viewComments', sendData, comment.involved.concat(comment.mentions.concat([req.session.context.user])), null)
              notification.mention(req, req.session.context.name, comment.mentions, comment.involved, comment)
              notification.send(req, req.session.context.room, 'comments' + comment.document, sendData, [comment.involved[0]], null)
              notification.send(req, req.session.context.room, 'comments2' + comment.document, sendData, [comment.involved[0]], null)
            }
            // notification.mention(req, req.session.context.name, comment.mentions, comment.involved, comment);
            send(comment)
          }
        })
      }
    })
  }
  this.count = function (req, mongo, send) {
    var keys = { unread: mongo.toId(req.session.context.user) }
    mongo.count('comment', keys, (err, count) => {
      if (!err && count) {
        send({ count: count })
      }
    })
  }
}