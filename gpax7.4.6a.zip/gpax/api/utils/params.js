var parseHtml = require('node-html-parser')
exports.Params = Params
const Entities = require('html-entities').AllHtmlEntities
const entities = new Entities()
var Notification = require('../utils/notification').Notification
var notification = new Notification()
var os = require('os')

// ** signer pdf **
var base64 = require('base-64')
var tags = require('./tags').tags
var fs = require('fs')
var dirname = __dirname.substring(0, __dirname.lastIndexOf('/'))
dirname = dirname.substring(0, dirname.lastIndexOf('/'))

function Params () {
  this.sendMail=function (req, mongo, send) {
    mongo.findOne('settings', { _id: 'settings' }, (err, sett) => {
      var secure = true
      var password = ''
      var transporter
      try { password = tags.util.Decipher(sett.password) }
      catch (err) { password = '' }
      if (sett.security === '') { secure = false }
      var nodemailer = require('nodemailer')
      transporter = nodemailer.createTransport({
        host: sett.smtp,
        port: sett.port,
        secure: secure,
        debug: true,
        logger: true,
        auth: {
          user: sett.user,
          pass: password
        },
        tls: {
          rejectUnauthorized: false
        }
      })
      let message = {
        from: sett.user, // sender address
        to: req.body.to, // list of receivers
        cc: req.body.copy, // list of receivers
        subject: req.body.subject, // Subject line
        text: req.body.subject, // plain text body
      }
      // send mail with defined transport object
      transporter.sendMail(message, (error, info) => {
        if (error) {
          send({ error: 1, text: error.toString()})
          notification.saveSystemNotification(req, mongo, null, "Error al enviar correo: " + error.message)
        } else {
          send({ text: 'Mensaje enviado: ' + info.messageId })
        }
      })
    })
  }
  this.options = function (req, mongo, send) {
    var name = req.query.name
    if (this[name]) {
      this[name](req, mongo, send)
    } else {
      mongo.findOne('params', { name: name }, (err, param) => {
        if (param && !err) {
          param.options.sort(function (a, b) {
            var n = a.value.toLocaleLowerCase().localeCompare(b.value.toLocaleLowerCase())
            return n === 0 && a.value !== b.value ? b.value.localeCompare(a.value) : n
          })
          if (req.query.empty === 'onlyEmpty') param.options.splice(0, 0, { id: 'onlyEmpty', value: 'Sin etiqueta' })
          if (req.query.only === 'onlyEmpty') param.options.splice(0, 0, { id: 'onlyEmpty', value: 'Sin etiqueta' })
          if (req.query.empty === '1') param.options.splice(0, 0, { id: '', value: '' })
          if (req.query.empty === '10') {
            param.options.forEach(x => {
              x.id = x.value
            })
          }
          send(param.options)
        } else {
          send([])
        }
      })
    }
  }
  this.externalControls = function (req, mongo, send) {
    mongo.findOne('settings', { _id: 'settings' }, { _id: 1, externalControls: 1 }, (err, sett) => {
      if (err) {
        console.log(err)
        send('')
      } else if (sett && sett.externalControls) {
        var request = require('request')
        request.post({
          url: 'https://demo.sar360.co/gestion/webservice/matrizProceso',
          formData: {
            token: 'eyJpc3MiOiJPbmxpbmUgSldUIEJ1aWxkZXIiLCJpYXQiOjE2MjA2MTE1'
          }
        }, (err, httpResponse, data) => {
          var ctrls=[]
          var risks = JSON.parse(data)
          risks.forEach((rsk) => {
            rsk.controles.forEach((ctr) => {
              ctrls.push({id: ctr.id, value: ctr.nombre})
            })
          })
          send(ctrls)
        })
      } else {
        send({})
      }
    })
  }
  this.riskTagNames = function (req, mongo, send) {
    mongo.findOne('params', { name: req.query.name }, (err, param) => {
      if (param && !err) {
        let data = []
        for (let i in param.options) {
          data.push({id: param.options[i].value, value: param.options[i].value})
        }
        data.sort(function (a, b) {
          var n = a.value.toLocaleLowerCase().localeCompare(b.value.toLocaleLowerCase())
          return n === 0 && a.value !== b.value ? b.value.localeCompare(a.value) : n
        })
        send(data)
      } else {
        send([])
      }
    })
  }

  this.save = function (req, mongo, send) {
    var data = { id: mongo.newId() }
    for (const x in req.body) {
      if (x !== 'name') {
        data[x] = req.body[x]
      }
    }
    if (mongo.isNativeId(data.id) ||(''+data.id).length<4) {
      mongo.update('params', { name: req.body.name, 'options.id': data.id }, { $set: { 'options.$': data } }, (err, result) => {
        if (err) {
          req.statusCode = 404
          send()
        } else {
          send(data)
        }
      })
    } else {
      data.id = mongo.newId()
      mongo.update('params', { name: req.body.name }, { $push: { options: { $each: [data], $sort: { value: 1 } } } }, (err, result) => {
        if (err || result.modifiedCount === 0) {
          mongo.save('params', { _id: mongo.newId(), name: req.body.name, options: [data] }, (err, result) => {
            if (err) {
              req.statusCode = 404
              send()
            } else {
              send(data)
            }
          })
        } else {
          send(data)
        }
      })
    }
  }
  this.delete = function (req, mongo, send) {
    var data = req.body
    mongo.update('params', { name: req.body.name }, { $pull: { options: { id: data.options.id } } }, (err, result) => {
      if (err || result.modifiedCount === 0) {
        req.statusCode = 404
        send()
      } else {
        send(data)
      }
    })
  }
  this.files = function (req, mongo, send) {
    mongo.findId('project', req.query.project, (err, project) => {
      if (err || !project) {
        send()
      } else {
        if (project.files) {
          var doc = []
          create(doc, '', project.files, '')
          if (req.query.empty === '1') doc.splice(0, 0, { id: '', value: '' })
          send(doc)
        } else {
          send([])
        }
      }
    })

    function create (doc, name, data, preview) {
      for (const i in data) {
        const row = data[i]
        if (row.data) {
          if (preview) row.value = preview.value + row.value + '/'
          create(doc, row.value, row.data, row)
        }
        if (typeof row.id === 'string') {
          doc.push({ id: row.id, value: row.value, folder: name })
        }
      }
    }
  }
  this.signPdfWithNewCertificate = async function (req, mongo, send) {
    var chilkat = require('@chilkat/ck-node14-linux64')
    var pem = require('pem')
    var signer = require('node-signpdf').default
    var plainAddPlaceholder = require('../x/pdfSign/helpers/plainAddPlaceholder').default
    chilkatUnlocked(chilkat)
    var cert = new chilkat.Cert()
    var file = await new Promise(resolve => {
      pem.createCertificate({
        days: 1,
        selfSigned: true,
        country: 'CR',
        organization: 'GPAX',
        commonName: 'Wilson RE',
        locality: 'Alajuela',
        emailAddress: 'wil512on@gmail.com'
      }, async function (err, keys) {
        if (err) {
          throw err
        } else {
          var success = cert.LoadFromBase64(base64.encode(keys.certificate))
          if (success !== true) {
            console.log(cert.LastErrorText)
            return
          }
          var certChain = cert.GetCertChain()
          if (cert.LastMethodSuccess !== true) {
            console.log(cert.LastErrorText)
            return
          }
          var privKey = new chilkat.PrivateKey()
          success = privKey.LoadPem(keys.clientKey)
          if (success !== true) {
            console.log(privKey.LastErrorText)
            return
          }
          var pfx = new chilkat.Pfx()
          success = pfx.AddPrivateKey(privKey, certChain)
          if (success !== true) {
            console.log(pfx.LastErrorText)
            return
          }
          var p12Buffer = pfx.ToBinary('12345')
          let pdfBuffer
          await new Promise(resolve => {
            req.app.routes.file.get({ _id: req.query._id, type: 'pdf' }, mongo, (result) => {
              var tmp = '/tmp/' + result.filename
              var file = fs.createWriteStream(tmp)
              file.on('finish', async function () {
                pdfBuffer = await fs.readFileSync(tmp)
                pem.readCertificateInfo(keys.certificate, function (err, info) {
                  if (err) throw err
                  pdfBuffer = plainAddPlaceholder({
                    pdfBuffer,
                    reason: 'Revisado',
                    name: info.commonName,
                    email: info.emailAddress,
                    locality: info.locality,
                    signatureLength: 214662
                  })
                  pdfBuffer = signer.sign(pdfBuffer, p12Buffer, { passphrase: '12345' })
                  resolve(pdfBuffer)
                })
              })
              result.pipe(file)
            })
          })
          resolve(pdfBuffer)
        }
      })
    })
    if (file) {
      fs.writeFile(dirname + '/api/img/test.pdf', file, 'binary', function (err) {
        if (err) {
          console.log(err)
          send()
        } else {
          console.log('Created')
        }
      })
    } else {
      send()
    }
  }
  this.signPdf = async function (req, mongo, send) {
    var chilkat = require('@chilkat/ck-node14-linux64')
    chilkatUnlocked(chilkat)
    var cert = new chilkat.Cert()
    var smartCard = await new Promise(resolve => {
      var cspName = ''
      var success = cert.LoadFromSmartcard(cspName)
      if (success == false) {
        console.log(cert.LastErrorText)
      }
      console.log('Cert loaded from smartcard: ' + cert.SubjectCN)
      cspName = 'Athena ASECard Crypto CSP'
      success = cert.LoadFromSmartcard(cspName)
      if (success == false) {
        console.log(cert.LastErrorText)
      }
      resolve()
    })
    if (smartCard) {
      fs.writeFile(dirname + '/api/img/test.pdf', smartCard, 'binary', function (err) {
        if (err) {
          console.log(err)
          send()
        } else {
          console.log('Created')
        }
      })
    } else {
      send()
    }
  }
  this.smartCardLogin = async function (req, mongo, send) {
    var chilkat = require('@chilkat/ck-node14-linux64')
    var body = req.body
    var cert = body.cert
    var key = body.key
    chilkatUnlocked(chilkat)
    var loadCert = new chilkat.Cert()
    var success = loadCert.LoadFromBase64(cert)
    loadCert
  }
  this.riskAssessment = async function (req, mongo, send) {
    let keys = {}
    try {
      if (req.query.key) {
        keys = {
          $and: []
        }
        keys.$and.push({ $or: [{ name: new RegExp(req.query.key, 'i') }] })
      }
    } catch (err) {
      console.log(err)
    }
    var limit = req.query.limit * 1
    mongo.findN('assessment', 0, limit, keys, { _id: 1, name: 1, type: 1, status: 1 }, { name: 1 }, (err, assessments) => {
      var array = []
      for (let i in assessments) {
        array.push({
          value: assessments[i].name,
          id: assessments[i]._id,
          type: assessments[i].type,
          status: assessments[i].status
        })
      }
      send(array)
    })
  }
  this.project = function (req, mongo, send) {
    var reply = []
    var user = req.session.context.user
    mongo.find('project', { 'actors.user': user, status: 'processing' }, {}, {}, (err, projects) => {
      if (err || !projects) {
        send({ error: err })
      } else {
        for (const i in projects) {
          if (projects[i].status !== 'draft') {
            var data = projects[i].activities
            if (!data) {
              data = projects[i].content
            }
            if (data) {
              if (data.data && data.data.length > 0) {
                for (const j in data.data) {
                  if (data.data[j].owner_id) {
                    if ((data.data[j].type === 'task' || data.data[j].type === 'milestone') && data.data[j].owner_id.toString() === user.toString()) {
                      if (projects[i].name) projects[i].name = entities.decode(projects[i].name)
                      reply.push({
                        id: data.data[j].id + ',&,' + projects[i]._id + ',&,' + projects[i].plan + ',&,' + data.data[j].text,
                        task: data.data[j].text,
                        project: projects[i].name
                      })
                    }
                  }
                }
              }
            }
          }
        }
        send(reply)
      }
    })
  }
  this.tasks = function (req, mongo, send) {
    var reply = []
    var user = req.session.context.user
    mongo.findId('project', req.query._id , {}, {}, async (err, project) => {
      if (err || !project) {
        send({ error: err })
      } else {
        let tasks = await new Promise(resolve => {
          mongo.find('task', { project: project._id }, {}, { text: 1 }, async (err, tasks) => {
            if (err) {
              console.log(err)
              resolve([])
            } else {
              resolve(tasks)
            }
          })
        })
        var data = tasks
        if (data) {
          if (data && data.length > 0) {
            for (const j in data) {
              if (data[j].owner_id) {
                if ((data[j].type === 'task' || data[j].type === 'milestone') && (data[j].owner_id.toString() === user.toString() || req.query.all === 'true')) {
                  reply.push({
                    id: data[j]._id,
                    value: data[j].text,
                  })
                }
              }
            }
          }
        }
        if (req.query.empty === '1') reply.splice(0, 0, { id: '', value: '' })
        send(reply)
      }
    })
  }
  this.tasksWithParents = function (req, mongo, send) {
    var pipeline=[
      {$match: {project: mongo.toId(req.query.project)}},
      {$graphLookup: {from: 'task',startWith: '$_id',connectFromField: 'parent',connectToField: 'parent',as: 'childs'}},
      {$match: {childs: {$size: 0}}},
      {$lookup: {from: 'task',localField: 'parent',foreignField: '_id',as: 'parents'}},
      {$project: {id: '$_id',value: {$concat: [{$ifNull: [ {$arrayElemAt: ['$parents.text',0]},'']},' / ','$text']},_id: 0}},
      {$sort: {value: 1}}
    ]
    mongo.aggregate('task', pipeline, {},async (err, tasks) => {
      if (err) {
        console.log(err)
        send([])
      } else {
        if (req.query.empty === '1') tasks.splice(0, 0, { id: '', value: '' })
        send(tasks)
      }
    })
  }
  this.projectList = function (req, mongo, send) {
    var reply = []
    var user = req.session.context.user
    var keys = { 'actors.user': user, status: 'processing' }
    if (req.query.activity) {
      reply.push({id: 'activity', value: 'Actividad'})
    }
    if (req.query.plan) {
      keys.plan = mongo.toId(req.query.plan)
    }
    mongo.find('project', keys, {}, {}, (err, projects) => {
      if (err || !projects) {
        send({ error: err })
      } else {
        for (const i in projects) {
          if (projects[i].status !== 'draft') {
            const root = parseHtml.parse('<div>' + projects[i].name + '</div>')
            reply.push({ id: projects[i]._id, value: '<span title="'+root.text+'">' + root.text + '</span>' })
          }
        }
        send(reply)
      }
    })
  }
  this.projectListAll = function (req, mongo, send) {
    var reply = []
    var keys = {
      status: 'processing',
      $or: [
        { 'actors.user': req.session.context.user }
      ]
    }
    if (req.session.context.managerUnits.length > 0) {
      keys.$or.push({ unit: { $in: req.session.context.managerUnits } })
    }
    if (req.session.context.assistantUnits.length > 0) {
      keys.$or.push({ unit: { $in: req.session.context.assistantUnits } })
    }
    /* if (req.session.context.memberUnits.length > 0) {
      keys.$or.push({ unit: { $in: req.session.context.memberUnits } })
    } */
    if (req.session.context.dependentUnits.length > 0) {
      keys.$or.push({ unit: { $in: req.session.context.dependentUnits } })
    }
    mongo.find('project', keys, {}, {}, (err, projects) => {
      if (err || !projects) {
        send({ error: err })
      } else {
        for (const i in projects) {
          if (projects[i].status !== 'draft') {
            const root = parseHtml.parse('<div>' + projects[i].name + '</div>')
            reply.push({ id: projects[i]._id, value: root.text })
          }
        }
        send(reply)
      }
    })
  }
  this.plan = function (req, mongo, send) {
    var pipeline=[]
    if (req.query.status) {
      pipeline.push({
        $lookup: {
          from: 'project', pipeline: [
            { $match: { status: req.query.status } },
            { $group: { _id: '$plan' } }
          ],
          as: 'prj'
        }
      })
      pipeline.push({
        $match: {
          $expr: {
            $or: [
              { $eq: ['$status', req.query.status] },
              { $in: ['$_id', '$prj._id'] }
            ]
          }
        }
      })
    }
    pipeline.push({ $project: { id: '$_id', value: '$name' } })
    pipeline.push({ $addFields: { _id: '$$REMOVE' } })
    mongo.aggregate('plan', pipeline, {}, (err, plans) => {
      if (err || !plans.length) {
        send()
      } else {
        var doc = plans
        if (req.query.empty === '1') doc.splice(0, 0, { id: '', value: '' })
        if (req.query.empty === 'empty') doc.splice(0, 0, { id: 'empty', value: '' })
        send(doc)
      }
    })
  }
  this.projects = function (req, mongo, send) {
    mongo.find('project', {}, { name: 1 }, { name: 1 }, (err, projects) => {
      if (err || !projects.length) {
        send()
      } else {
        var doc = []
        for (const i in projects) {
          const root = parseHtml.parse('<div>' + projects[i].name + '</div>')
          projects[i].name = root.text
          doc.push({ id: projects[i]._id, value: projects[i].name })
        }
        if (req.query.empty === '1') doc.splice(0, 0, { id: '', value: '' })
        send(doc)
      }
    })
  }
  this.plans = function (req, mongo, send) {
    mongo.find(
      'plan',
      {
        $or: [
          { unit: { $exists: 0 } },
          { unit: '' },
          { unit: { $in: req.session.context.managerUnits } },
          { unit: { $in: req.session.context.assistantUnits } },
          { unit: { $in: req.session.context.memberUnits } },
          { unit: { $in: req.session.context.dependentUnits } }
        ]
      },
      { name: 1 },
      { _id: 1 },
      (err, plans) => {
        if (err || !plans.length) {
          send()
        } else {
          var doc = []
          for (const i in plans) {
            doc.push({ id: plans[i]._id, value: plans[i].name })
          }
          if (req.query.empty === '1') doc.splice(0, 0, { id: '', value: '' })
          send(doc)
        }
      }
    )
  }
  this.plansActivities = function (req, mongo, send) {
    var keys = { $or: [{ unit: { $exists: 0 } }, { unit: '' }, { unit: { $in: req.session.context.managerUnits } }, { unit: { $in: req.session.context.assistantUnits } }, { unit: { $in: req.session.context.memberUnits } }] }
    var reply = []
    mongo.find('plan', keys, { _id: 1, name: 1, activities: 1 }, {}, (err, plans) => {
      if (err || !plans) {
        send({ error: err })
      } else {
        for (const i in plans) {
          if (plans[i].status !== 'draft') {
            var data = plans[i].activities
            if (data) {
              if (data.data && data.data.length > 0) {
                var activities = plans[i].activities.activities
                for (const act in activities) {
                  reply.push({
                    activity: activities[act],
                    plan: plans[i].name,
                    id: act,
                    planId: plans[i]._id
                  })
                }
              }
            }
          }
        }
        send(reply)
      }
    })
  }

  this.activity = function (req, mongo, send) {
    var plan = req.session.context.activePlan.id
    if (req.query._id) {
      plan = mongo.toId(req.query._id)
    }
    var pipeline = [
      { $match: { '_id.plan': plan, '_id.user': req.session.context.user, planned: { $gt: 0 } } },
      { $lookup: { from: 'activity', localField: '_id.activity', foreignField: '_id', as: 'tactivity' } },
      { $unwind: '$tactivity' },
      {
        $project: {
          _id: 0,
          id: '$tactivity._id',
          value: '$tactivity.name'
        }
      },
      { $sort: { value: 1 } }
    ]
    mongo.aggregate('activityUser', pipeline, { allowDiskUse: true }, (err, activities) => {
      if (err || !activities.length) {
        send()
      } else {
        send(activities)
      }
    })
  }

  this.activityByPlan = function (req, mongo, send) {
    var ID = req.query._id ? mongo.toId(req.query._id) : ''
    mongo.find('activity', { plan: ID }, {}, { name: 1 }, (err, activities) => {
      if (err || !activities.length) {
        send()
      } else {
        var doc = []
        for (const i in activities) {
          doc.push({ id: activities[i]._id, value: activities[i].name})
        }
        doc.sort((a, b) => {
          if (a.value > b.value) {
            return 1
          }
          if (a.value < b.value) {
            return -1
          }
          // a must be equal to b
          return 0
        })
        send(doc)
      }
    })
  }

  this.repositoryTag = function (req, mongo, send) {
    var reply = []
    mongo.distinct('repository', 'category', {}, (err, docs) => {
      if (err || !docs) {
        send({ error: err })
      } else {
        /* hash user actors of the documents set */
        for (const i in docs) {
          reply.push({ id: docs[i], value: docs[i] })
        }
        send(reply)
      }
    })
  }

  this.client = function (req, mongo, send) {
    mongo.find('client', {}, { _id: 1, name: 1 }, { name: 1 }, (err, clients) => {
      if (err) {
        req.logger.log('Error reading clients:' + err)
      }
      var clientOpts = []
      for (let i = 0; i < clients.length; ++i) {
        clientOpts.push({ value: clients[i].name, id: clients[i]._id.toString() })
      }
      send(clientOpts)
    })
  }

  this.company = function (req, mongo, send) {
    mongo.find('company', {}, { _id: 1, idNum: 1, name: 1 }, {name: 1}, (err, companies) => {
      if (err) {
        req.logger.log('Error reading companies:' + err)
      } else {
        var CompOpts = []
        for (let i = 0; i < companies.length; ++i) {
          CompOpts.push({ value: companies[i].name, id: companies[i].idNum })
        }
        send(CompOpts)
      }
    })
  }
  this.product = function (req, mongo, send) {
    mongo.find('product', {}, { _id: 1, name: 1 }, { name: 1 }, (err, products) => {
      if (err) {
        req.logger.log('Error reading products:' + err)
      }
      var prodOpts = []
      for (let i = 0; i < products.length; ++i) {
        prodOpts.push({ value: products[i].name, id: products[i]._id.toString() })
      }
      send(prodOpts)
    })
  }
  this.sequence = function (req, mongo, send) {
    var reply = []
    mongo.find('sequence', {}, { _id: 1, name: 1, code: 1 }, { name: 1 }, (err, docs) => {
      if (err || !docs) {
        send({ error: err })
      } else {
        /* hash user actors of the documents set */
        if (req.query.empty === '1') reply.push({ id: '', value: '' })
        docs.forEach(doc => {
          reply.push({
            id: doc._id.toString(),
            value: doc.code + ' ' + doc.name
          })
        })
        send(reply)
      }
    })
  }
  this.language = function (req, mongo, send) {
    var reply = []
    mongo.find('language', {}, { _id: 1, language: 1 }, { language: 1 }, (err, docs) => {
      if (err || !docs) {
        send({ error: err })
      } else {
        docs.forEach(doc => {
          reply.push({
            id: doc._id.toString(),
            value: doc.language
          })
        })
        send(reply)
      }
    })
  }
  this.repository = function (req, mongo, send) {
    var keys = {}
    var fields = { _id: 1, name: 1, type: 1, category: 1 }
    if (req.query.key) {
      keys.name = new RegExp(req.query.key, 'i')
    }
    if (req.query._id) {
      keys._id = mongo.toId(req.query._id)
    }
    if (req.query.limit) {
      var limit = 1 * req.query.limit
      mongo.findN('repository', 0, limit, keys, fields, { name: 1 }, (err, repos) => {
        if (err) {
          send({ erro: err })
        } else {
          if (req.query.empty === '1') repos.splice(0, 0, { _id: '', name: '' })
          sendData(repos)
        }
      })
    } else {
      mongo.find('repository', keys, fields, { name: 1 }, (err, repos) => {
        if (err) {
          send({ erro: err })
        } else {
          if (req.query.empty === '1') repos.splice(0, 0, { _id: '', name: '' })
          sendData(repos)
        }
      })
    }
    function sendData (repos) {
      mongo.find('params', { name: 'repositoryTags' }, (err, categs) => {
        if (err) console.log(err)
        categs = categs[0]
        mongo.find('params', { name: 'type' }, (err, types) => {
          if (err) console.log(err)
          var combo = []
          for (let i in repos) {
            let value = repos[i].name
            if (repos[i].type && repos[i].type.length > 0) {
              for (const i in types.options) {
                if (types.options[i].id && types.options[i].id.equals(repos[i].type[0])) {
                  const type = types.options[i]
                  value += ' <span style="background-color:' + type.color + '">' + type.value + '</span>'
                  break
                }
              }
            }
            if (repos[i].category && repos[i].category.length > 0) {
              for (let c in categs.options) {
                for (let k in repos[i].category) {
                  if (categs.options[c].id && categs.options[c].id.equals(repos[i].category[k])) {
                    let categ = categs.options[c]
                    value += ' <span style="background-color:' + categ.color + '">' + categ.value + '</span>'
                    break
                  }
                }
              }
            }
            combo.push({
              value: value,
              id: repos[i]._id,
              path: 'repository'
            })
          }
          send(combo)
        })
      })
    }
  }
  this.unit = async function (req, mongo, send) {
    var keys = { }
    var fields = { _id: 1, name: 1, offline: 1, active: 1 }
    if (req.query.key) {
      keys.name = new RegExp(req.query.key, 'i')
    }
    if (req.query.unitsAlarms) {
      req.query.unitsAlarms = req.query.unitsAlarms.split(',')
      for (let j in req.query.unitsAlarms) {
        req.query.unitsAlarms[j] = mongo.toId(req.query.unitsAlarms[j])
      }
      keys._id = { $in: req.query.unitsAlarms }
    }
    if (req.query.licensedUser) {
      var users = await new Promise(resolve => {
        mongo.find('user', {}, { _id: 1, units: 1, licensedUser: 1 }, (err, users) => {
          if (!err) {
            resolve(users)
          }
        })
      })
      let units = []
      for (const u in users) {
        if (users[u].licensedUser === true && users[u].units) {
          units = units.concat(users[u].units)
        }
      }
      keys._id = { $in: units }
    }
    if (req.query.limit) {
      var limit = 1 * req.query.limit
      mongo.findN('unit', 0, limit, keys, fields, { name: 1 }, (err, units) => {
        if (err) {
          send({ erro: err })
        } else {
          if (req.query.empty === '1') units.splice(0, 0, { _id: '', name: '' })
          if (req.query.empty === 'empty') units.splice(0, 0, { _id: 'empty', name: '' })
          sendData(units)
        }
      })
    } else {
      mongo.find('unit', keys, fields, { name: 1 }, (err, units) => {
        if (err) {
          send({ erro: err })
        } else {
          if (req.query.empty === '1') units.splice(0, 0, { _id: '', name: '' })
          if (req.query.empty === 'empty') units.splice(0, 0, { _id: 'empty', name: '' })
          units.forEach(x => {
            while (x.name && x.name.charAt(0) === ' ') {
              x.name = x.name.slice(1)
            }
          })
          units.sort((a, b) => (a.name < b.name ? -1 : 1))
          sendData(units)
        }
      })
    }
    function sendData (units) {
      var combounits = []
      for (const i in units) {
        var name=''
        if (units[i].name) {
          name = units[i].name.replace(/(<([^>]+)>)/g, '')
        }
        combounits.push({
          value: name,
          id: units[i]._id
        })
      }
      send(combounits)
    }
  }
  this.department = function (req, mongo, send) {
    mongo.find('unit', { createProjects: '1', active: { $ne: false } }, { _id: 1, code: 1, name: 1 }, { name: 1 }, (err, units) => {
      if (err) {
        send({ erro: err })
      } else {
        var combounits = []
        if (req.query.empty === '1') combounits.push({ id: '', value: '' })
        for (const i in units) {
          combounits.push({
            value: units[i].code + ' ' + units[i].name,
            id: units[i]._id
          })
        }
        send(combounits)
      }
    })
  }

  this.template = function (req, mongo, send) {
    var reply = []
    var keys = {}
    if (req.query.filter) {
      keys = { type: { $in: req.query.filter.split(',') } }
    }
    mongo.find('template', keys, { _id: 1, name: 1 }, { name: 1 }, (err, docs) => {
      if (err || !docs) {
        send({ error: err })
      } else {
        if (req.query.empty === '1') reply.push({ id: '', value: '' })
        for (const i in docs) {
          const doc = docs[i]
          reply.push({
            id: doc._id.toString(),
            value: doc.name
          })
        }
        send(reply)
      }
    })
  }

  this.templateAuditable = function (req, mongo, send) {
    var reply = []
    mongo.find('template', { type: 'project' }, { _id: 1, name: 1 }, { name: 1 }, (err, docs) => {
      if (err || !docs) {
        send({ error: err })
      } else {
        for (const i in docs) {
          const doc = docs[i]
          reply.push({
            id: doc._id.toString(),
            value: doc.name
          })
        }
        send(reply)
      }
    })
  }

  this.responsible = function (req, mongo, send) {
    var usrs = []
    var unts = []
    mongo.findId('note', req.query.reference, (err, doc) => {
      if (err) {
        send({ error: err })
      } else {
        if (doc) {
          for (const i in doc.actors) {
            if (doc.actors[i]) {
              switch (doc.actors[i].role) {
              case 'to':
                if (doc.actors[i].unit) {
                  usrs.push(doc.actors[i].user)
                  unts.push(doc.actors[i].unit)
                }
                break
              case 'copy':
                if (doc.actors[i].unit) {
                  usrs.push(doc.actors[i].user)
                  unts.push(doc.actors[i].unit)
                }
                break
              }
            }
          }
        }
        mongo.find(
          'user',
          (req.query.reference !== 'undefined' ? { $and: [{ 'units.0': { $exists: true } }, { _id: { $in: usrs } }, { active: true }] } : {}),
          { _id: 1, name: 1, units: 1 },
          { name: 1 },
          (err, users) => {
            if (err) {
              send({ erro: err })
            } else {
              mongo.toHash('unit', (req.query.reference !== 'undefined' ? { _id: { $in: unts } } : {}), { _id: 1, name: 1 }, (er, units) => {
                var combousers = []
                for (const i in users) {
                  for (const j in users[i].units) {
                    if (
                      units[users[i].units[j].toString()] &&
                      combousers.findIndex(x => {
                        return x.id === users[i]._id + '&unit=' + users[i].units[j]
                      }) === -1
                    ) {
                      combousers.push({
                        value: users[i].name + '/' + units[users[i].units[j].toString()].name,
                        id: users[i]._id + '&unit=' + users[i].units[j]
                      })
                    }
                  }
                }
                send(combousers)
              })
            }
          }
        )
      }
    })
  }

  this.process = function (req, mongo, send) {
    var reply = []
    mongo.find('process', {}, { _id: 1, name: 1, active: 1, parent: 1 }, { name: 1 }, (err, docs) => {
      if (err || !docs) {
        send({ error: err })
      } else {
        for (const i in docs) {
          const doc = docs[i]
          reply.push({
            id: doc._id,
            value: (doc.name || '').replace(/(<([^>]+)>)/g, ''),
            parent: doc.parent ? doc.parent : 0
          })
        }
        send(reply)
      }
    })
  }

  this.processActive = function (req, mongo, send) {
    var reply = []
    mongo.find('process', {}, { _id: 1, name: 1, active: 1, parent: 1 }, { name: 1 }, (err, proc) => {
      if (err || !proc) {
        send({ error: err })
      } else {
        for (const i in proc) {
          var proces = proc[i]
          delete proces.webix_kids
          proces.risks = proces.risks || { selected: [], added: [] }
          if (!proces.processTag) { proces.processTag = [] }
          proces.id = proces._id.toString()
          if (proces.units) {
            var units = []
            proces.units.forEach((unt, idx) => {
              units.push(proces.units[idx]._id ? proces.units[idx]._id : proces.units[idx])
            })
            proces.units = units
          }
          //puede que el campo venga con 1 o true o que no exista y el resultado sería activo
          if (proces.active === true) {
            reply.push(proces)
          } else if (!proces.active && proces.active !== false && proces.active !== '0') {
            reply.push(proces)
          }
        }
        send(reply)
      }
    })
  }

  this.processAuditable = function (req, mongo, send) {
    mongo.aggregate('process', [
      {
        $graphLookup: {
          from: 'process',
          startWith: '$parent',
          connectFromField: 'parent',
          connectToField: '_id',
          as: 'ancestors',
          depthField: 'seq'
        }
      },
      { $unwind: { path: '$ancestors', preserveNullAndEmptyArrays: true } },
      { $sort: { 'ancestors.seq': -1 } },
      { $group: { _id: '$_id', name: { $first: '$name' }, ancestors: { $push: '$ancestors.name' } } },
      {
        $addFields: {
          parents: {
            $cond: {
              if: { $eq: ['$ancestors', null] }, then: '', else: {
                $reduce: {
                  input: '$ancestors',
                  initialValue: '',
                  in: { $concat: ['$$value', ' / ', '$$this'] }
                }
              }
            }
          }
        }
      },
      { $project: { _id: 0, id: '$_id', value: { $substr: [{ $concat: ['$parents', ' / ', '$name'] }, 3, -1] } } },
      { $sort: { value: 1 } }
    ], { allowDiskUse: true }, (err, docs) => {
      if (err || !docs) {
        send({ error: err })
      } else {
        send(docs)
      }
    })
  }

  this.user = function (req, mongo, send) {
    var keys = { }
    var fields = { _id: 1, name: 1, licensedUser: 1 }
    if (req.query.withLicense === '1') {
      keys.licensedUser = true
    }
    if (req.query.notLicense === '1') {
      keys.licensedUser = false
    }
    if (req.query.usersAlarms) {
      req.query.usersAlarms = req.query.usersAlarms.split(',')
      for (let j in req.query.usersAlarms) {
        req.query.usersAlarms[j] = mongo.toId(req.query.usersAlarms[j])
      }
      keys._id = { $in: req.query.usersAlarms }
    }
    if (req.query.key) {
      keys.name = new RegExp(req.query.key, 'i')
    }
    if (req.query.signature === '1') fields.signature = 1
    if (req.query.limit) {
      var limit = 1 * req.query.limit
      mongo.findN('user', 0, limit, keys, fields, { name: 1 }, (err, users) => {
        if (err) {
          send({ erro: err })
        } else {
          if (req.query.empty === '1') users.splice(0, 0, { id: '', value: '' })
          if (req.query.empty === 'empty') users.splice(0, 0, { id: 'empty', value: '' })
          sendData(users)
        }
      })
    } else if (req.query.company) {
      mongo.find('user', { 'roles.createUsers': false }, fields, { name: 1 }, (err, users) => {
        if (err) {
          send({ erro: err })
        } else {
          sendData(users)
        }
      })
    } else {
      mongo.find('user', keys, fields, { name: 1 }, (err, users) => {
        if (err) {
          send({ erro: err })
        } else {
          if (req.query.empty === '1') users.splice(0, 0, { _id: '', name: '' })
          sendData(users)
        }
      })
    }
    function sendData (users) {
      var row
      var combousers = []
      for (const i in users) {
        var name = users[i]._id !== 'empty' && users[i]._id !== '' ? users[i].name + (users[i].licensedUser ? '' : ' @') : ''
        if (users[i].signature) {
          row = {
            signature: users[i].signature,
            value: name.replace(/(<([^>]+)>)/g, ''),
            id: users[i]._id
          }
        } else if (req.query.onlyValue) {
          row = {
            value: name.replace(/(<([^>]+)>)/g, ''),
            id: name.replace(/(<([^>]+)>)/g, '')
          }
        } else {
          row = {
            value: name.replace(/(<([^>]+)>)/g, ''),
            id: users[i]._id
          }
        }
        combousers.push(row)
      }
      send(combousers)
    }
  }

  this.noteAndAttac = async function (req, mongo, send) {
    const keys = {
      $and: [
        {
          $or: [
            { actors: { $elemMatch: { user: req.session.context.user, path: { $ne: 'hidden' } } } },
            {
              $and: [
                { actors: { $elemMatch: { unit: { $in: req.session.context.memberUnits }, path: { $ne: 'hidden' } } } },
                { status: { $ne: 'draft' } },
                { confidential: { $ne: '1' } }
              ]
            }
          ]
        }
      ]
    }
    if (req.query.key) {
      keys.$and.push({ $or: [ ] })
      keys.$and[1].$or.push({name: new RegExp(req.query.key, 'i')})
      keys.$and[1].$or.push({'sequence.text': new RegExp(req.query.key, 'i')})
    }

    if (req.query._id) {
      keys.$and.push({ _id: mongo.toId(req.query._id) })
    }

    var limit = req.query.limit * 1

    // LLAMAR LOS DOS CALLBACK EN PARALELO PARA AUMENTAR EL TIEMPO DE EJECUCION///
    /* 1- */
    var attachs = []
    var notes = await new Promise(resolve => {
      mongo.findN('note', 0, limit, keys, { _id: 1, name: 1, sequence: 1, type: 1, template: 1 }, { 'sequence.text': 1, name: 1 }, async (err, notes) => {
        if (!err) {
          /* for (let i in notes) {
            await new Promise(resolve => {
              mongo.find('attached', { reference: notes[i]._id }, {}, (err, atts) => {
                if (atts && atts.length) {
                  for (let a in atts) {
                    attachs.push(atts[a])
                  }
                }
                resolve()
              })
            })
          } */
          resolve(notes)
        } else {
          resolve([])
        }
      })
    })
    /* 2- */
    var attachs = await new Promise(resolve => {
      mongo.findN(
        'attached',
        0,
        limit,
        keys,
        { _id: 1, name: 1, sequence: 1, type: 1, responsible: 1, reference: 1, status: 1, template: 1 },
        { 'sequence.text': 1, name: 1 },
        (err, attachs) => {
          if (!err) {
            resolve(attachs)
          } else {
            resolve([])
          }
        }
      )
    })
    notes = notes.concat(attachs)
    var options = []
    for (const i in notes) {
      let type2 = await new Promise(resolve => {
        mongo.findId('template', notes[i].template, { type: 1 }, (err, d) => {
          if (err || !d) resolve('')
          else resolve(d.type)
        })
      })
      type2 = type2 || 'note'
      options.push({
        type: notes[i].responsible || notes[i].reference/*  && notes[i].status === 'draft') */ ? 'attached' : 'note',
        type2: type2,
        value: notes[i].name,
        sequence: (notes[i].sequence && notes[i].sequence.text ? notes[i].sequence.text + ' ' : ''),
        id: notes[i]._id,
        path: notes[i].responsible || notes[i].reference/*  && notes[i].status === 'draft') */ ? 'note.attached' : 'note.note'
      })
    }
    send(options)
  }

  this.commAndEviden = async function (req, mongo, send) {
    const keys = {
      $and: []
    }

    if (req.query._id) {
      keys.$and.push({ _id: mongo.toId(req.query._id) })
    }

    var limit = req.query.limit * 1

    // LLAMAR LOS DOS CALLBACK EN PARALELO PARA AUMENTAR EL TIEMPO DE EJECUCION///
    /* 1- */
    var comms = await new Promise(resolve => {
      mongo.findN('commitment', 0, limit, keys, { _id: 1, name: 1, sequence: 1, type: 1, template: 1 }, { 'sequence.text': 1, name: 1 }, async (err, comms) => {
        if (!err) {
          resolve(comms)
        } else {
          resolve([])
        }
      })
    })
    /* 2- */
    var evidens = await new Promise(resolve => {
      mongo.findN(
        'evidence',
        0,
        limit,
        keys,
        { _id: 1, name: 1, sequence: 1, type: 1, responsible: 1, reference: 1, status: 1, template: 1 },
        { 'sequence.text': 1, name: 1 },
        (err, evidens) => {
          if (!err) {
            resolve(evidens)
          } else {
            resolve([])
          }
        }
      )
    })
    var options = []
    // for commitment
    for (const i in comms) {
      let type2 = await new Promise(resolve => {
        mongo.findId('template', comms[i].template, { type: 1 }, (err, d) => {
          if (err || !d) resolve('')
          else resolve(d.type)
        })
      })
      type2 = type2 || 'note'
      options.push({
        type: 'commitment',
        type2: type2,
        value: comms[i].name,
        sequence: (comms[i].sequence && comms[i].sequence.text ? comms[i].sequence.text + ' ' : ''),
        id: comms[i]._id,
        path: 'note.commitment'
      })
    }
    // for evidence
    for (const i in evidens) {
      let type2 = await new Promise(resolve => {
        mongo.findId('template', evidens[i].template, { type: 1 }, (err, d) => {
          if (err || !d) resolve('')
          else resolve(d.type)
        })
      })
      type2 = type2 || 'note'
      options.push({
        type: 'evidence',
        type2: type2,
        value: evidens[i].name,
        sequence: (evidens[i].sequence && evidens[i].sequence.text ? evidens[i].sequence.text + ' ' : ''),
        id: evidens[i]._id,
        path: 'note.evidence'
      })
    }
    send(options)
  }

  this.reference = function (req, mongo, send) {
    mongo.find(
      req.query.collection,
      { _id: mongo.toId(req.query.id) },
      { _id: 1, name: 1, sequence: 1 },
      { 'sequence.text': 1, name: 1 },
      (err, doc) => {
        if (err) {
          send({ erro: err })
        } else {
          var options = {
            id: doc[0]._id,
            value: doc[0].sequence && doc[0].sequence.text ? '<b>[' + doc[0].sequence.text + ']</b> ' + doc[0].name : doc[0].name
          }
          send(options)
        }
      }
    )
  }

  this.document = function (req, mongo, send) {
    let keys = {
      $and: [
        {
          $or: [
            { actors: { $elemMatch: { user: req.session.context.user, path: { $ne: 'hidden' } } } },
            {
              $and: [
                { actors: { $elemMatch: { unit: { $in: req.session.context.memberUnits }, path: { $ne: 'hidden' } } } },
                { confidential: { $ne: '1' } }
              ]
            }
          ]
        }
      ]
    }
    if (req.query.project) {
      // If filter by project, override filter
      keys = { $and: [{ project: mongo.toId(req.query.project) }] }
    }
    if (req.query.key) {
      keys.$and.push({ $or: [{ name: new RegExp(req.query.key, 'i') }, { 'sequence.text': new RegExp(req.query.key, 'i') }] })
    }
    if (req.query._id) {
      keys.$and.push({ _id: mongo.toId(req.query._id) })
    }
    if (req.query.issued === 'false') {
      keys.$and.push({ issued: { $exists: false } })
    }
    var limit = req.query.limit * 1
    mongo.findN('document', 0, limit, keys, { _id: 1, name: 1, sequence: 1, type: 1, project: 1 }, { 'sequence.text': 1, name: 1 }, (err, docs) => {
      if (err) {
        send({ erro: err })
      } else {
        var options = []
        for (const i in docs) {
          options.push({
            type: docs[i].type,
            project: docs[i].project,
            value: (docs[i].sequence && docs[i].sequence.text ? docs[i].sequence.text + ' ' : '') + docs[i].name,
            id: docs[i]._id,
            path: docs[i].type === 'redactor' ? 'document.document' : docs[i].type === 'expense' ? 'expense' : 'document.' + docs[i].type
          })
        }
        send(options)
      }
    })
  }

  this.employees = function (req, mongo, send) {
    mongo.find('user', { $and: [{ 'units.0': { $exists: true } }] }, { _id: 1, name: 1, units: 1 }, { name: 1 }, (err, users) => {
      if (err) {
        send({ erro: err })
      } else {
        var ids = []
        for (const i in users) {
          for (const j in users[i].units) {
            ids.push(users[i].units[j])
          }
        }
        mongo.toHash('unit', { _id: { $in: ids } }, { _id: 1, name: 1, offline: 1 }, (er, units) => {
          var combousers = []
          for (const i in users) {
            for (const j in users[i].units) {
              if (
                units[users[i].units[j].toString()] &&
                combousers.findIndex(x => {
                  return x.id === users[i]._id + '&unit=' + users[i].units[j]
                }) === -1
              ) {
                combousers.push({
                  value: users[i].name + '/' + units[users[i].units[j].toString()].name,
                  id: users[i]._id + '&unit=' + users[i].units[j]
                })
              }
            }
          }
          send(combousers)
        })
      }
    }
    )
  }

  this.userFroala = function (req, mongo, send) {
    var keys = { _id: { $ne: req.session.context.user }, $and: [{ 'units.0': { $exists: true } }, { active: true }] }
    var fields = { _id: 1, name: 1, units: 1, signature: 1 }
    if (req.query.withLicense === '1') {
      keys.licensedUser = true
    }
    if (req.query.key) {
      keys.name = new RegExp(req.query.key, 'i')
    }
    if (req.query.limit) {
      var limit = 1 * req.query.limit
      mongo.findN('user', 0, limit, keys, fields, { name: 1 }, (err, users) => {
        if (err) {
          send({ erro: err })
        } else {
          var ids = []
          for (const i in users) {
            for (const j in users[i].units) {
              ids.push(users[i].units[j])
            }
          }
          mongo.toHash('unit', { _id: { $in: ids } }, { _id: 1, name: 1 }, (er, units) => {
            var combousers = []
            for (const i in users) {
              for (const j in users[i].units) {
                if (
                  units[users[i].units[j].toString()] &&
                  combousers.findIndex(x => {
                    return x.id === users[i]._id + '&unit=' + users[i].units[j]
                  }) === -1
                ) {
                  const user = {
                    value: users[i].name + '/' + units[users[i].units[j].toString()].name,
                    id: users[i]._id + '&unit=' + users[i].units[j]
                  }
                  if (users[i].signature || users[i].signature !== '') {
                    user.signature = users[i].signature + '/' + units[users[i].units[j].toString()].name
                  }
                  if (req.session.context.unitsMention && req.session.context.unitsMention.length) {
                    let u = req.session.context.unitsMention.findIndex((x) => {
                      return x.toString() === users[i].units[j].toString()
                    })
                    if (u !== -1) {
                      combousers.push(user)
                    }
                  } else {
                    combousers.push(user)
                  }

                  // let name = '<span title="' + users[i].name + '">' + users[i].name + '</span>' + (users[i].licensedUser ? '' : ' <span title="communicationOnly">@</span>')
                }
              }
            }
            send(combousers)
          })
        }
      })
    }
  }

  this.unitsScheduler = async function (req, mongo, send) {
    let units
    if (req.query.unit && req.query.unit !== 'empty') {
      units = await this.$unitDependents(mongo, [mongo.toId(req.query.unit)])
    } else {
      units = await this.$unitDependents(mongo, req.session.context.managerUnits.concat(req.session.context.assistantUnits))
    }
    mongo.find(
      'unit',
      { _id: { $in: units } },
      { actors: 1 },
      { actors: 1 },
      (err, units) => {
        mongo.find(
          'project',
          { actors: { $elemMatch: { user: req.session.context.user, type: 'manager' } }, status: 'processing' },
          { actors: 1 },
          { actors: 1 },
          (err2, projs) => {
            var users = []
            if (!err && units.length !== 0) {
              for (const i in units) {
                if (units[i].actors) {
                  for (const j in units[i].actors) {
                    users.push(units[i].actors[j].user)
                  }
                }
              }
              for (const i in projs) {
                if (projs[i].actors) {
                  for (const j in projs[i].actors) {
                    users.push(projs[i].actors[j].user)
                  }
                }
              }
            }
            mongo.find('user', { _id: { $in: users } }, { name: 1 }, { name: 1 }, (err, users) => {
              if (err || users.length === 0) {
                users = []
                send(users)
              } else {
                var hash = []
                for (const i in users) {
                  /* if (users[i]._id.toString() !== req.session.context.user.toString()) */ hash.push({ value: users[i].name, id: users[i]._id })
                }
                users = hash
                send(users)
              }
            })
          }
        )
      }
    )
  }

  this.$unitDependents = async function (mongo, id) {
    if (!id.forEach) {
      id=[id]
    }
    var units = await new Promise(resolve => {
      mongo.find('unit', {}, { parent: 1 }, (err, all) => {
        if (err) console.log(err)
        resolve(all)
      })
    })
    var dependents = []
    id.forEach((i) => {
      dependents.push(i)
      this.$dependents(i, dependents, units)
    })
    return dependents
  }

  this.$dependents = function (parent, dependents,units) {
    units.forEach((u) => {
      if (u.parent && u.parent.equals && u.parent.equals(parent)) {
        dependents.push(u._id)
        this.$dependents(u._id,dependents,units)
      }
    })
  }

  this.templateNotes = function (req, mongo, send) {
    mongo.find('template', { type: { $in: ['note', 'editor'] } }, { _id: 1, name: 1, type: 1 }, { name: 1 }, (err, template) => {
      if (err || !template) {
        send()
      } else {
        var templates = []
        for (const i in template) {
          templates.push({
            value: template[i].name,
            id: template[i]._id
          })
        }
        send(templates)
      }
    })
  }

  this.commitmentTemplate = function (req, mongo, send) {
    mongo.findOne('settings', { _id: 'settings' }, { _id: 1, commitmentTemplate: 1 }, (err, sett) => {
      if (err) {
        console.log(err)
        send('')
      } else {
        if (sett.commitmentTemplate && sett.commitmentTemplate.length) {
          mongo.find('params', { name: 'tag' }, { _id: 1, name: 1, options: 1 }, async (err, tgs) => {
            let data = []
            for (let i in sett.commitmentTemplate) {
              await new Promise(resolve => {
                mongo.findId('template', sett.commitmentTemplate[i], async (err, temp) => {
                  if (temp) {
                    let doc = await req.app.routes.template.getItem(temp, tgs, [], [])
                    // buscar tipo de modelo con el que se creo editor, note...
                    let type2 = await new Promise(resolve => {
                      mongo.findId('template', doc.template, { type: 1 }, (err, d) => {
                        if (err || !d) resolve('')
                        else resolve(d.type)
                      })
                    })
                    doc.type2 = type2 || 'note'
                    data.push(doc)
                  }
                  resolve()
                })
              })
            }
            send(data)
          })
        } else {
          send('')
        }
      }
    })
  }
  this.evidenceTemplate = function (req, mongo, send) {
    mongo.findOne('settings', { _id: 'settings' }, { _id: 1, evidenceTemplate: 1 }, (err, sett) => {
      if (err) {
        console.log(err)
        send('')
      } else {
        if (sett.evidenceTemplate && sett.evidenceTemplate.length) {
          mongo.find('params', { name: 'tag' }, { _id: 1, name: 1, options: 1 }, async (err, tgs) => {
            let data = []
            for (let i in sett.evidenceTemplate) {
              await new Promise(resolve => {
                mongo.findId('template', sett.evidenceTemplate[i], async (err, temp) => {
                  if (temp) {
                    let doc = await req.app.routes.template.getItem(temp, tgs, [], [])
                    // buscar tipo de modelo con el que se creo editor, note...
                    let type2 = await new Promise(resolve => {
                      mongo.findId('template', doc.template, { type: 1 }, (err, d) => {
                        if (err || !d) resolve('')
                        else resolve(d.type)
                      })
                    })
                    doc.type2 = type2 || 'note'
                    data.push(doc)
                  }
                  resolve()
                })
              })
            }
            send(data)
          })
        } else {
          send('')
        }
      }
    })
  }

  this.listAuditable = function (req, mongo, send) {
    var idAuditable = mongo.toId(req.query.id)
    mongo.find('auditable', { $or: [{copyFrom: ''}, {copyFrom: {$exists: false}}], _id: {$ne: idAuditable} }, {_id: 1, name: 1 }, (err, temp) => {
      if (err) {
        console.log(err)
        send()
      } else {
        let data = []
        if (req.query.empty === '1') data.push({ id: idAuditable, value: '' })
        for (let i in temp) {
          data.push({id: temp[i]._id, value: temp[i].name})
        }
        send(data)
      }
    })
  }

  this.performanceForms = function (req, mongo, send) {
    mongo.find('template', { type: 'form' }, { _id: 1, name: 1, type: 1 }, { name: 1 }, (err, template) => {
      if (err || !template) {
        send()
      } else {
        var templates = []
        for (const i in template) {
          templates.push({
            value: template[i].name,
            id: template[i]._id
          })
        }
        send(templates)
      }
    })
  }

  this.calendars = function (req, mongo,send) {
    mongo.find('calendar', {}, { _id: 1, name: 1 }, { name: 1 }, (err, calendar) => {
      if (err || !calendar) {
        send()
      } else {
        var calendars = []
        for (const i in calendar) {
          calendars.push({
            value: calendar[i].name,
            id: calendar[i]._id
          })
        }
        send(calendars)
      }
    })
  }

  function chilkatUnlocked (chilkat) {
    var glob = new chilkat.Global()
    var success = glob.UnlockBundle('NFWJAQ.CB1042022_zJkF8zzt3K3e')
    //glob.UnlockBundle('INFOWA.CB1062020_V8xq8zKRD72n')
    if (success !== true) {
      console.log(glob.LastErrorText)
      return
    }
    var status = glob.UnlockStatus
    if (status !== 2) {
      console.log('Unlocked in trial mode.')
    }
  }
}