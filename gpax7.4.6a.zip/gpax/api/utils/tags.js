/**
 * Created by jorge on 28/04/17.
 */
var moment = require('moment')
var zlib = require('zlib')
var crypto = require('crypto')

var algorithm = 'aes-256-ctr'

var password = 'i8G7Cjle'
// Tags values can not be changed, this is database and form field names
exports.tags = {
  action: 'action',
  active: 'active',
  addLink: 'addLink',
  alarms: 'alarms',
  annual: 'annual',
  all: 'all',
  alreadySaved: 'alreadySaved',
  app: 'app',
  archived: 'archived',
  assistant: 'assistant',
  assignment: 'assignment',
  assigned: 'assigned',
  attachments: 'attachments',
  attended: 'attended',
  autoTimer: 'autoTimer',
  available: 'available',
  beginHiring: 'beginHiring',
  bpd: 'bpd',
  budget: 'budget',
  bye: 'bye',
  calendar: 'calendar',
  cancel: 'cancel',
  category: 'category',
  calc: 'calc',
  cited: 'cited',
  channel: 'channel',
  charset: 'charset',
  class: 'class',
  click2delete: 'click2delete',
  click2open: 'click2open',
  client: 'client',
  clients: 'clients',
  close: 'close',
  closeEditor: 'closeEditor',
  closeOrganigramEditor: 'closeOrganigramEditor',
  closeProcessEditor: 'closeProcessEditor',
  closeSesion: 'closeSesion',
  code: 'code',
  collection: 'collection',
  combo: 'combo',
  comment: 'comment',
  comments: 'comments',
  committed: 'committed',
  commitment: 'commitment',
  completed: 'completed',
  condition: 'condition',
  confirmDelete: 'confirmDelete',
  confirmSave: 'confirmSave',
  constants: 'constants',
  content: 'content',
  copy: 'copy',
  countryCode: 'countryCode',
  create: 'create',
  correspondence: 'correspondence',
  createLanguages: 'createLanguages',
  createPlans: 'createPlans',
  createProcedures: 'createProcedures',
  createProcesses: 'createProcesses',
  createProjects: 'createProjects',
  createTemplates: 'createTemplates',
  createSequences: 'createSequences',
  createUnits: 'createUnits',
  createUsers: 'createUsers',
  dates: 'dates',
  dateTime: 'dateTime',
  dashboard: 'dashboard',
  days: 'days',
  dblClick2AddChild: 'dblClick2AddChild',
  deadline: 'deadline',
  device: 'device',
  dayNames: 'Sun,Mon,Tue,Wed,Thu,Fri,Sat,Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday',
  delete: 'delete',
  description: 'description',
  details: 'details',
  detectedChanges: 'detectedChanges',
  discart: 'discart',
  discartChanges: 'discartChanges',
  discardedEntry: 'discardedEntry',
  discarded: 'discarded',
  docsPend: 'docsPend',
  document: 'document',
  documents: 'documents',
  draft: 'draft',
  drag2upload: 'drag2upload',
  dropHere: 'dropHere',
  duration: 'duration',
  edit: 'edit',
  email: 'email',
  end: 'end',
  endDate: 'endDate',
  endHiring: 'endHiring',
  enter: 'enter',
  entry: 'entry',
  entries: 'entries',
  error: 'error',
  externalUnit: 'externalUnit',
  expenseReports: 'expenseReports',
  expired: 'expired',
  expiredPassword: 'expiredPassword',
  favorites: 'favorites',
  fields: 'fields',
  files: 'files',
  filter: 'filter',
  floating: 'floating',
  format: 'format',
  form: 'form',
  from: 'from',
  gantt: 'gantt',
  gateway: 'gateway',
  gateways: 'gateways',
  header: 'header',
  hidden: 'hidden',
  high: 'high',
  highlights: 'highlights',
  history: 'history',
  holidays: 'holidays',
  host: 'host',
  hourCost: 'hourCost',
  hours: 'hours',
  identification: 'identification',
  in: 'in',
  inactiveuser: 'inactiveuser',
  includeSignature: 'includeSignature',
  invalid: 'invalid',
  invalidCredentials: 'invalidCredentials',
  input: 'input',
  inprocessentry: 'inprocessentry',
  interval: 'interval',
  issue: 'issue',
  item: 'item',
  items: 'items',
  justification: 'justification',
  laborData: 'laborData',
  language: 'language',
  languages: 'languages',
  level: 'level',
  licenseduser: 'licenseduser',
  lifeCycle: 'lifeCycle',
  limitUseTo: 'limitUseTo',
  links: 'links',
  loading: 'loading',
  locale: 'locale',
  log: 'log',
  login: 'login',
  low: 'low',
  manager: 'manager',
  me: 'me',
  medium: 'medium',
  members: 'members',
  member: 'member',
  methods: 'methods',
  minutes: 'minutes',
  mission: 'mission',
  monthNames: 'Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec,January,February,March,April,May,June,July,August,September,October,November,December',
  msgNotClass: 'msgNotClass',
  msgNotMethod: 'msgNotMethod',
  msgNotReply: 'msgNotReply',
  msgSeelog: 'msgSeelog',
  myEntries: 'myEntries',
  myProfile: 'myProfile',
  myScheduler: 'myScheduler',
  name: 'name',
  nameSurname: 'nameSurname',
  new: 'new',
  newTransaction: 'newTransaction',
  no: 'no',
  notSaved: 'notSaved',
  objective: 'objective',
  objectives: 'objectives',
  opeConnection: 'openConnection',
  organizationChart: 'organizationChart',
  organizationChartMaintenanace: 'organizationChartMaintenanace',
  others: 'others',
  output: 'output',
  owner: 'owner',
  path: 'path',
  pause: 'pause',
  processing: 'processing',
  period: 'period',
  photo: 'photo',
  plan: 'plan',
  plans: 'plans',
  placeholder: 'placeholder',
  passTo: 'passTo',
  password: 'password',
  port: 'port',
  preview: 'preview',
  print: 'print',
  priority: 'priority',
  processes: 'processes',
  processChart: 'processChart',
  processChartMaintenanace: 'processChartMaintenanace',
  processType: 'processType',
  progress: 'progress',
  project: 'project',
  projects: 'projects',
  properties: 'properties',
  received: 'received',
  recipients: 'recipients',
  redactor: 'redactor',
  referredBy: 'referredBy',
  referred: 'referred',
  relationship: 'relationship',
  repeatPassword: 'repeatPassword',
  replied: 'replied',
  reply: 'reply',
  replyTo: 'replyTo',
  repository: 'repository',
  requiredBy: 'requiredBy',
  reset: 'reset',
  restrict2units: 'restrcit2units',
  resolvedentry: 'resolvedentry',
  resolved: 'resolved',
  reviser: 'reviser',
  reviewedSchedulers: 'reviewedSchedulers',
  roles: 'roles',
  save: 'save',
  savedChanges: 'savedChanges',
  savingProblem: 'savingProblem',
  scaleHour: 'scaleHour',
  scaleDay: 'scaleDay',
  scaleWeek: 'scaleWeek',
  scaleMonth: 'scaleMonth',
  scaleYear: 'scaleYear',
  search: 'search',
  seconds: 'secounds',
  sections: 'sections',
  security: 'security',
  send: 'send',
  sent: 'sent',
  sequence: 'sequence',
  sequences: 'sequences',
  server: 'server',
  settings: 'settings',
  signature: 'signature',
  signOff: 'signOff',
  similarTo: 'similarTo',
  size: 'size',
  slogan: 'slogan',
  source: 'source',
  solution: 'solution',
  specific: 'specific',
  spreadsheet: 'spreadsheet',
  start: 'start',
  startDate: 'startDate',
  statistics: 'statistics',
  strategy: 'strategy',
  status: 'status',
  stx: 'stx',
  subject: 'subject',
  suspended: 'suspended',
  tags: 'tags',
  template: 'template',
  templateName: 'templateName',
  templates: 'templates',
  templateType: 'templateType',
  text: 'text',
  time: 'time',
  timeNames: 'a,p,am,pm,A,P,AM,PM',
  timeReports: 'timeReports',
  to: 'to',
  today: 'today',
  todo: 'todo',
  total: 'total',
  toPDF: 'toPDF',
  tools: 'tools',
  transaction: 'transaction',
  txt2search: 'txt2search',
  type: 'type',
  types: 'types',
  unitName: 'unitName',
  unitNameRequired: 'unitNameRequired',
  unit: 'unit',
  units: 'units',
  unitType: 'unitType',
  url: 'url',
  unsave: 'unsave',
  user: 'user',
  userCode: 'userCode',
  userLanguage: 'userLanguage',
  users: 'users',
  validEmail: 'validEmail',
  value: 'value',
  versions: 'versions',
  vigency: 'vigency',
  vision: 'vision',
  wantSave: 'wantSave',
  warning: 'warning',
  wellcome: 'wellcome',
  window: 'window',
  withoutStarting: 'withoutStarting',
  workDay: 'workDay',
  workLoad: 'workLoad',
  workflow: 'workflow',
  workingDays: 'workingDays',
  workGuide: 'workGuide',
  yes: 'yes',
  yesterday: 'yesterday',
  util: {
    redactorBasic: function (doc) {
      return {
        toolbar: false,
        styles: true,
        source: false,
        imageUpload: 'file.save?_id=' + doc._id,
        imageManagerJson: 'file.list?imgs=1&_id=' + doc._id,
        fileUpload: 'file.save?_id=' + doc._id,
        fileManagerJson: 'file.list?_id=' + doc._id,
        plugins: ['imagemanager', 'filemanager']
      }
    },
    redactorNormal: function (doc, height) {
      return {
        air: true,
        clickToEdit: true,
        styles: true,
        imageUpload: 'file.save?_id=' + doc._id,
        imageManagerJson: 'file.list?imgs=1&_id=' + doc._id,
        fileUpload: 'file.save?_id=' + doc._id,
        fileManagerJson: 'file.list?_id=' + doc._id,
        imageResizable: true,
        imagePosition: true,
        removeScript: false,
        source: false,
        buttonsHide: ['format', 'image', 'sub', 'sup', 'del', 'blockquote', 'file', 'line', 'link', 'horizontalrule'],
        plugins: ['imagemanager', 'filemanager', 'alignment', 'fontsize', 'fontcolor', 'fontfamily']
      }
    },
    redactorFull: function (doc) {
      return {
        toolbar: true,
        imageUpload: 'file.save?_id=' + doc._id,
        imageManagerJson: 'file.list?imgs=1&_id=' + doc._id,
        fileUpload: 'file.save?_id=' + doc._id,
        fileManagerJson: 'file.list?_id=' + doc._id,
        imageResizable: true,
        imagePosition: true,
        styles: true,
        removeScript: false,
        cleanInlineOnEnter: false,
        placeholder: '>>..._',
        replaceTags: false,
        source: false,
        buttons: ['source', 'format', 'bold', 'italic', 'underline', 'sup', 'sub', 'line', 'deleted', 'lists', 'image', 'file', 'link', 'horizontalrule'],
        formatting: ['p', 'blockquote', 'pre'],
        formattingAdd: {
          'space-normal': {
            title: 'Espaciado normal',
            api: 'module.block.format',
            args: { tag: 'p', style: { 'line-height': 'normal' }, type: 'toggle' }
          },
          'space-and-half': {
            title: 'Espacio y medio',
            api: 'module.block.toggle',
            args: { style: { 'line-height': '180%' }, type: 'toggle' },
            tags: ['p']
          },
          'double-space': {
            title: 'Doble espacio',
            api: 'module.block.format',
            args: { tag: 'p', style: { 'line-height': '250%' }, type: 'toggle' }
          }
        },
        plugins: ['alignment', 'fontfamily', 'fontsize', 'fontcolor', 'imagemanager', 'filemanager', 'table', 'indent', 'properties', 'specialchars']
      }
    },
    redactorDev: function (doc) {
      return {
        toolbar: true,
        imageUpload: 'file.save?_id=' + doc._id,
        imageManagerJson: 'file.list?imgs=1&_id=' + doc._id,
        fileUpload: 'file.save?_id=' + doc._id,
        fileManagerJson: 'file.list?_id=' + doc._id,
        imageResizable: true,
        imagePosition: true,
        styles: true,
        removeScript: false,
        cleanInlineOnEnter: false,
        placeholder: '>>..._',
        replaceTags: false,
        buttons: ['source', 'format', 'bold', 'italic', 'underline', 'sup', 'sub', 'line', 'deleted', 'lists', 'image', 'file', 'link', 'horizontalrule'],
        formatting: ['p', 'blockquote', 'pre'],
        formattingAdd: {
          'space-normal': {
            title: 'Espaciado normal',
            args: ['p', 'class', 'space-mormal']
          },
          'space-and-half': {
            title: 'Espacio y medio',
            args: ['p', 'class', 'space-and-half']
          },
          'double-space': {
            title: 'Doble espacio',
            args: ['p', 'class', 'double-space']
          }
        },
        plugins: ['alignment', 'fontfamily', 'fontsize', 'fontcolor', 'imagemanager', 'filemanager', 'table', 'indent', 'properties', 'specialchars']
      }
    },
    str2date: function (text) {
      var d = new Date(text)
      d = new Date(d.getTime() + d.getTimezoneOffset() * 60000)
      return d
    },
    timelog: function (ms) {
      var seconds = Math.floor(ms / 1000)
      var hours = Math.floor(seconds / 3600)
      seconds = seconds % 3600
      var minutes = Math.floor(seconds / 60)
      seconds = seconds % 60
      return (hours < 10 ? '0' : '') + hours + ':' + (minutes < 10 ? '0' : '') + minutes + ':' + (seconds < 10 ? '0' : '') + seconds
    },
    date2str: function (date, format) {
      return moment(date).format(format)
    },
    dateTime2human: function (date, tags) {
      let r
      let now = new Date()
      if (typeof date === 'string') { date = new Date(date) }
      let elapsed = (now.getTime() - date.getTime()) / 1000
      if (elapsed < (24 * 60 * 60)) { // menos de 24 horas
        if (now.getDay() - date.getDay() !== 0) {
          r = tags.yesterday + moment(date, ', h:MM:ss TT')
        } else {
          r = moment(date).format('h:MM:ss TT')
        }
      } else if (elapsed < (6 * 24 * 60 * 60)) { // menos de 6 días
        if (now.getDay() - date.getDay() === 1) {
          r = tags.yesterday + moment(date).format(' h:MM:ss TT')
        } else {
          r = moment(date).format('dddd, h:MM:ss TT')
        }
      } else {
        r = moment(date).format('dddd, dd mmmm, yyyy, h:MM:ss TT')
      }

      return r
    },
    crypto: function (psswd) {
      return crypto.createHash('sha1').update(psswd).digest('base64')
    },
    Cipher: function (psswd) {
      var cipher = crypto.createCipher(algorithm, password)
      var crypted = cipher.update(psswd, 'utf8', 'hex')
      crypted += cipher.final('hex')
      return crypted
    },
    Decipher: function (psswd) {
      var decipher = crypto.createDecipher(algorithm, password)
      var dec = decipher.update(psswd.toString(), 'hex', 'utf8')
      dec += decipher.final('utf8')
      return dec
    },
    encrypt: function (psswd) {
      let r = '' + new Date().getTime()
      while (psswd.length > r.length) {
        r += new Date().getTime()
      }
      var pos = 1
      for (let i = 0; i < psswd.length; i++) {
        r = r.substr(0, pos) + psswd[i] + r.substr(pos)
        pos += 2
      }
      return zlib.deflateSync(r + '#' + psswd.length).toString('base64')
    },
    decrypt: function (psswd) {
      psswd = zlib.inflateSync(Buffer.from(psswd, 'base64')).toString()
      let length = 1 * psswd.substring(psswd.lastIndexOf('#') + 1)
      var pos = 1
      var r = ''
      for (let i = 0; i < length; i++) {
        r += psswd[pos]
        pos += 2
      }
      return r
    },
    bool: function (val) {
      var num = +val
      return !isNaN(num) ? !!num : !!String(val).toLowerCase().replace(!!0, '')
    }
  }
}
