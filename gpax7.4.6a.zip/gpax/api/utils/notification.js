/* exported */
var tags = require('../utils/tags').tags

exports.Notification = Notification
var nodemailer = require('nodemailer')

function Notification () {
  this.seen = function (req, mongo, send) {
    mongo.findId('notification', req.body._id, (err, notification) => {
      if (!err && notification) {
        let index = notification.actors.findIndex((x) => {
          return x.user.toString() === req.session.context.user.toString()
        })
        if (index !== -1) {
          notification.actors[index].seen = 1
        }
        mongo.save('notification', notification, (err, result) => {
          if (err) {
            send({
              error: tags.savingProblema
            })
          }
          send({})
        })
      }
    })
  }
  this.saveSystemNotification = async function (req, mongo, send, message) {
    let users = await new Promise(resolve => {
      mongo.find('user', {'roles.adminTrash': true}, {_id: 1}, {},(err, users) => {
        if (!err) {
          resolve(users)
        }
      })
    })
    var noti = {
      _id: mongo.newId(),
      actors: [],
      collection: 'settings',
      document: { id: 'settings'},
      path: 'security.settings',
      type: 5,
      message: message || ''
    }
    noti.createdAt = noti._id.getTimestamp()
    if (users.length) {
      for (var i in users) {
        noti.actors.push({
          user: users[i]._id,
          seen: 0
        })
      }
      await new Promise(resolve => {
        mongo.save('notification', noti, (err, result) => {
          if (!err) {
            resolve(result)
          }
        })
      })
    }
    if (send) {
      send()
    }
  }
  this.seenAll = async function (req, mongo, send) {

    await new Promise(resolve => {
      mongo.saveWithFilter('notification', {
        'actors.user': req.session.context.user
      }, {
        'actors.$[ele].seen': 1
      }, {
        multi: true,
        upsert: false,
        arrayFilters: [{
          'ele.user': req.session.context.user
        }]
        // [ { "element": {"element.user": ObjectId("5b103aa45089b30fd853a2b7")} } ]
      },
      (err, result) => {
        if (err) {
          console.log(err)
          resolve()
        } else {
          resolve()
        }
      })
    })
    send({})
  }

  this.list = function (req, mongo, send) {
    var skip = Number(req.query.skip || 0)
    var limit = 50
    var keys = {
      actors: {
        $elemMatch: {
          user: req.session.context.user
        }
      }
    }
    if (req.query.date) {
      keys = {}
      keys.document = req.query.document
      keys.date = req.query.date
    }
    mongo.findN('notification', skip, limit, keys, {}, {
      _id: -1
    }, async (err, notifications) => {
      if (!err && notifications) {
        let read = []
        let unread = []
        var userIds = []
        var docIds = []
        var collections = []
        var returnedDocs = {}
        for (let i in notifications) {
          if(notifications[i].user)
            userIds.push(notifications[i].user)
          docIds.push(notifications[i].document.id)
          if (!collections.includes(notifications[i].collection)) {
            collections.push(notifications[i].collection)
          }
        }

        for (let u in collections) {
          var findDocs = await new Promise(resolve => {
            mongo.toHash(collections[u], {
              _id: {
                $in: docIds
              }
            }, {}, (err, docs) => {
              if (!err) {
                resolve(docs)
              }
            })
          })
          returnedDocs = Object.assign(returnedDocs, findDocs)
        }

        mongo.toHash('user', {
          _id: {
            $in: userIds
          }
        }, {
          name: 1
        }, async (err, users) => {
          if (err) throw err
          for (let i in notifications) {
            let noti = notifications[i]
            noti.id = noti._id
            if(noti.user)
              noti.username = users[noti.user.toString()].name
            let index = noti.actors.findIndex((x) => {
              return x.user.toString() === req.session.context.user.toString()
            })
            if (returnedDocs[noti.document.id.toString()]) {
              noti.docname = returnedDocs[noti.document.id.toString()].name
              // buscar tipo de modelo con el que se creo editor, note...
              noti.type2 = await new Promise(resolve => {
                mongo.findId('template', returnedDocs[noti.document.id.toString()].template, { type: 1 }, (err, d) => {
                  if (err || !d) resolve('')
                  else resolve(d.type)
                })
              })
              noti.type2 = noti.type2 || 'note'
            }
            if (noti.actors[index].seen) {
              noti.class = ''
              read.push(noti)
            } else {
              noti.class = 'bold'
              unread.push(noti)
            }
          }
          send(unread.concat(read))
        })
      }
    })
  }

  this.count = function (req, mongo, send) {
    var keys = {
      unread: mongo.toId(req.session.context.user)
    }
    mongo.count('comment', keys, (err, count) => {
      if (!err && count) {
        send({
          count: count
        })
      }
    })
  }

  this.notifyMention = function (req, doc, mongo, send) {
    var users = []
    var usersToURL = []
    for (const i in doc.actors) {
      users.push(mongo.toId(doc.actors[i].user))
    }
    mongo.find('user', {
      _id: {
        $in: users
      }
    }, {}, {}, (err, usr) => {
      if (err) throw err
      var unlicensedTo = [];
      var usersCopy = []
      for (const i in usr) {
        for (const j in users) {
          if (usr[i]._id.toString() === users[j].toString()) {
            if (req.session.context.user.toString() === usr[i]._id.toString() && usersCopy.indexOf(usr[i].email) === -1) {
              usersCopy.push(usr[i].email)
              //usersToURL.push(usr[i]._id.toString())
            } else {
              if (usr[i].licensedUser === false) {
                unlicensedTo.push(usr[i].email)
                usersToURL.push(usr[i]._id.toString())
              }
            }
          }
        }
      }
      mongo.findOne('settings', {
        _id: 'settings'
      }, async (err, sett) => {
        if (err) throw err
        if (sett && sett.user && (unlicensedTo.length > 0 || usersCopy.length > 0) && Number(sett.checkEmail)) {
          var secure = false
          var password
          var transporter
          var copies = []
          var emailCopies = []
          try {
            password = tags.util.Decipher(sett.password)
          } catch (err) {
            password = ''
          }
          if (sett.security === 'ssl') {
            secure = true
          }

          if (sett.copies && sett.copies.length > 0) {
            for (const i in sett.copies) {
              copies.push(sett.copies[i])
            }
          }
          var usersCopies = await new Promise(resolve => {
            mongo.find('user', {
              _id: {
                $in: copies
              }
            }, {}, {}, (err, usersCopies) => {
              if (err || !usersCopies) {
                resolve()
              } else {
                resolve(usersCopies)
              }
            })
          })
          for (const i in usersCopies) {
            emailCopies.push(usersCopies[i].email)
            //usersToURL.push(usersCopies[i]._id.toString())
          }
          const config = {
            host: sett.smtp,
            port: sett.port,
            secure: secure, // true for 465, false for other ports
            tls: {
              rejectUnauthorized: false
            }
          }
          if (sett.password || !sett.password === '') {
            config.auth = {
              user: sett.user,
              pass: password
            }
          }
          transporter = nodemailer.createTransport(config)

          // setup email data with unicode symbols
          var sendMessage = doc.message
          /* if (sett.sendMessage && sett.sendMessage.length > 0) {
                                                                        sendMessage = sett.sendMessage
                                                                      } */
          var usersTo = []
          usersTo = unlicensedTo
          let attachments = []
          await new Promise(resolve => {
            procesar()
            async function procesar () {
              let file = sendMessage.split('/api/file.get?_id=')[1]
              if (file && (file.includes('type=png') || file.includes('type=jpg'))) {
                let ext = file.includes('type=png') ? '&type=png' : '&type=jpg'
                file = file.split('&type')[0]
                let result = await new Promise(resolve => {
                  /* attachments.push({
                                                                                                                                filename: 'image.png',
                                                                                                                                path: 'api/img/photo.png',
                                                                                                                                cid: file + ext //same cid value as in the html img src
                                                                                                                              })
                                                                                                                              sendMessage = sendMessage.replace('/api/file.get?_id=' + file + ext, 'cid:' + file + ext)
                                                                                                                              resolve(true) */
                  mongo.getfileBase64(file, (err, result) => {
                    if (!err) {
                      //let img = 'data:image/png;base64,' + result
                      attachments.push({
                        filename: 'image.png',
                        content: Buffer.from(
                          result, 'base64'
                        ),
                        cid: file //same cid value as in the html img src
                      })
                      sendMessage = sendMessage.replace('/api/file.get?_id=' + file + ext, 'cid:' + file)
                      resolve(true)
                    } else {
                      resolve(false)
                    }
                  })
                })
                if (result) {
                  let file = sendMessage.split('/api/file.get?_id=')[1]
                  if (file && (file.includes('type=png') || file.includes('type=jpg'))) {
                    await procesar()
                  }
                }
              }
              resolve()
            }
          })
          if (usersTo.length > 0) {
            const message = {
              from: sett.user, // sender address
              to: usersTo, // list of receivers
              //cc: usersCopy.concat(emailCopies), // list of receivers
              subject: doc.name || 'Notificación Gpax', // Subject line
              // text: 'Hello world?', // plain text body
              html: sendMessage + '<br></br><span class="h-entry p-name"><a class="u-uid" href="' + doc._id + '" style="display:none">' +
                                '</a><br></br><a class="u-url" href="' + req.headers.referer + 'api/user.goURL?users='+usersToURL+'&url='+doc.collection +'.' + (doc.documentType || doc.collection) + '?_id=' + doc._id + '$issued=' + doc.issued + '$status=' + doc.status +'">Click aquí</a></span>⁠&nbsp;<br></br>' // html body
            }

            // send mail with defined transport object
            transporter.sendMail(message, (error, info) => {
              if (error) {
                console.log(error)
                console.log('No se pudo enviar el correo')
                this.saveSystemNotification(req, mongo, null, 'Error al enviar correo: ' + error.message)
              } else {
                console.log('Message sent: %s', info.messageId)
                console.log('Mensaje enviado')
              }
            })
          }
        }
      })
    })
  }

  this.notify = function (req, doc, mongo, send) {
    var users = []
    var messageCommitmentOrEvidence
    if (req.query.someone) {
      for (const i in doc.actors) {
        if ((i == 0 && doc.actors[i].role === 'reviser') || doc.actors[i].role === 'supervisor' || doc.actors[i].role === 'responsible') {
          if (doc.actors[i].user.toString() !== req.session.context.user.toString()) users.push(doc.actors[i].user)
          if (doc.type === 'commitment') {
            messageCommitmentOrEvidence = 'Compromiso ' + doc.name
            if (doc.sequence && doc.sequence.text) {
              messageCommitmentOrEvidence = messageCommitmentOrEvidence + ' del consecutivo de la nota ' + doc.sequence.text
            }
            messageCommitmentOrEvidence = messageCommitmentOrEvidence + ' ha cambiado de estado'
          }
          if (doc.type === 'evidence') {
            messageCommitmentOrEvidence = 'Evidencia ' + doc.name + 'ha cambiado de estado'
          }
        }
        if (doc.actors[i].role === 'reviser' && doc.type === 'commitment' && (doc.status === 'ready' || doc.status === 'completed')) {
          let e = users.findIndex((x) => {
            return x.toString() === doc.actors[i].user.toString()
          })
          if (e === -1) {
            users.push(doc.actors[i].user)
            messageCommitmentOrEvidence = 'Compromiso ' + doc.name
            if (doc.sequence && doc.sequence.text) {
              messageCommitmentOrEvidence = messageCommitmentOrEvidence + ' del consecutivo de la nota ' + doc.sequence.text
            }
            messageCommitmentOrEvidence = messageCommitmentOrEvidence + ' ha cambiado de estado'
          }
        }
        if (doc.actors[i].role === 'reviser' && doc.type === 'evidence' && doc.status === 'ready') {
          let e = users.findIndex((x) => {
            return x.toString() === doc.actors[i].user.toString()
          })
          if (e === -1) {
            users.push(doc.actors[i].user)
            messageCommitmentOrEvidence = 'Evidencia ' + doc.name + 'ha cambiado de estado'
          }
        }
      }
    } else {
      for (const i in doc.actors) {
        users.push(doc.actors[i].user)
      }
    }
    mongo.find('user', {
      _id: {
        $in: users
      }
    }, {}, {}, (err, usr) => {
      if (err) throw err
      var unlicensedTo = [];
      var usersCopy = [];
      var licensedTo = []
      var usersToURL = []
      for (const j in users) {
        var userIndex = usr.findIndex((x) => {
          return ((x._id.toString() === users[j].toString()) && (x.active === true))
        })
        if (userIndex !== -1) {
          if (req.session.context.user.toString() === usr[userIndex]._id.toString() && usersCopy.indexOf(usr[userIndex].email) === -1) {
            usersCopy.push(usr[userIndex].email)
            usersToURL.push(usr[userIndex]._id.toString())
          } else {
            if (usr[userIndex].licensedUser === false) {
              unlicensedTo.push(usr[userIndex].email)
              usersToURL.push(usr[userIndex]._id.toString())
            } else {
              licensedTo.push(usr[userIndex].email)
              usersToURL.push(usr[userIndex]._id.toString())
            }
          }
        }
      }

      mongo.findOne('settings', {
        _id: 'settings'
      }, async (err, sett) => {
        if (err) throw err
        if (sett && sett.user && (unlicensedTo.length > 0 || usersCopy.length > 0 || licensedTo.length > 0) && Number(sett.checkEmail)) {
          var secure = false
          var password
          var transporter
          var copies = []
          var emailCopies = []
          try {
            password = tags.util.Decipher(sett.password)
          } catch (err) {
            password = ''
          }
          if (sett.security === 'ssl') {
            secure = true
          }

          if (sett.copies && sett.copies.length > 0) {
            for (const i in sett.copies) {
              copies.push(sett.copies[i])
            }
          }
          var usersCopies = await new Promise(resolve => {
            mongo.find('user', {
              _id: {
                $in: copies
              }
            }, {}, {}, (err, usersCopies) => {
              if (err || !usersCopies) {
                resolve()
              } else {
                resolve(usersCopies)
              }
            })
          })
          for (const i in usersCopies) {
            emailCopies.push(usersCopies[i].email)
            usersToURL.push(usersCopies[i]._id.toString())
          }
          const config = {
            host: sett.smtp,
            port: sett.port,
            secure: secure, // true for 465, false for other ports
            tls: {
              rejectUnauthorized: false
            }
          }
          if (sett.password || !sett.password === '') {
            config.auth = {
              user: sett.user,
              pass: password
            }
          }
          transporter = nodemailer.createTransport(config)

          // setup email data with unicode symbols
          var sendMessage = 'Para ver su correspondencia haga click aqui '
          if (sett.sendMessage && sett.sendMessage.length > 0) {
            sendMessage = sett.sendMessage
          }
          if (messageCommitmentOrEvidence) {
            sendMessage = messageCommitmentOrEvidence
          }
          var usersTo = []
          if (Number(sett.checkEmail)) {
            usersTo = licensedTo.concat(unlicensedTo)
          } else {
            usersTo = unlicensedTo
          }
          let attachments = []
          await new Promise(resolve => {
            procesar()
            async function procesar () {
              let file = sendMessage.split('/api/file.get?_id=')[1]
              if (file && (file.includes('type=png') || file.includes('type=jpg'))) {
                let ext = file.includes('type=png') ? '&type=png' : '&type=jpg'
                file = file.split('&type')[0]
                let result = await new Promise(resolve => {
                  /* attachments.push({
                                                                                                                                filename: 'image.png',
                                                                                                                                path: 'api/img/photo.png',
                                                                                                                                cid: file + ext //same cid value as in the html img src
                                                                                                                              })
                                                                                                                              sendMessage = sendMessage.replace('/api/file.get?_id=' + file + ext, 'cid:' + file + ext)
                                                                                                                              resolve(true) */
                  mongo.getfileBase64(file, (err, result) => {
                    if (!err) {
                      //let img = 'data:image/png;base64,' + result
                      attachments.push({
                        filename: 'image.png',
                        content: Buffer.from(
                          result, 'base64'
                        ),
                        cid: file //same cid value as in the html img src
                      })
                      sendMessage = sendMessage.replace('/api/file.get?_id=' + file + ext, 'cid:' + file)
                      resolve(true)
                    } else {
                      resolve(false)
                    }
                  })
                })
                if (result) {
                  let file = sendMessage.split('/api/file.get?_id=')[1]
                  if (file && (file.includes('type=png') || file.includes('type=jpg'))) {
                    await procesar()
                  }
                }
              }
              resolve()
            }
          })
          if (usersTo.length > 0) {
            const message = {
              from: sett.user, // sender address
              to: usersTo, // list of receivers
              cc: usersCopy.concat(emailCopies), // list of receivers
              subject: doc.name, // Subject line
              // text: 'Hello world?', // plain text body
              html: sendMessage + '<br></br><span class="h-entry p-name"><a class="u-uid" href="' + doc._id + '" style="display:none">' +
                                '</a><br></br><a class="u-url" href="' + req.headers.referer + 'api/user.goURL?users='+usersToURL+'&url=note.' + doc.type + '?_id=' + doc._id + '$issued=' + doc.issued + '$status=' + doc.status +'">' + doc.name + '</a></span>⁠&nbsp;<br></br>Revisar estado del documento</html></body>', // html body
              attachments: attachments
            }

            // send mail with defined transport object
            transporter.sendMail(message, (error, info) => {
              if (error) {
                console.log(error)
                console.log('No se pudo enviar el correo')
                this.saveSystemNotification(req, mongo, null, 'Error al enviar correo: ' + error.message)
              } else {
                console.log('Message sent: %s', info.messageId)
                console.log('Mensaje enviado')
              }
            })
          }
        }
      })
    })
  }

  this.notifyStart = function (req, mongo, project, users) {
    mongo.findOne('settings', {
      _id: 'settings'
    }, async (err, sett) => {
      if (err) throw err
      if (sett && sett.user && Number(sett.checkEmail)) {
        var secure = false
        var password
        var transporter
        var emailsTo = []
        var usersToURL = []
        try {
          password = tags.util.Decipher(sett.password)
        } catch (err) {
          password = ''
        }
        if (sett.security === 'ssl') {
          secure = true
        }

        await new Promise(resolve => {
          mongo.findId('unit', project.unit, {}, {}, (err, unit) => {
            if (err || !unit) {
              resolve()
            } else {
              let user
              for (let i in unit.actors) {
                if (unit.actors[i].type && (unit.actors[i].type[0] === 'manager' || unit.actors[i].type[0] === 'assistant') && unit.actors[i].user) {
                  user = unit.actors[i].user
                  users.push(user)
                }
              }
              resolve()
            }
          })
        })

        var usersTo = await new Promise(resolve => {
          mongo.find('user', {
            _id: {
              $in: users
            }
          }, {}, {}, (err, usersTo) => {
            if (err || !usersTo) {
              resolve([])
            } else {
              resolve(usersTo)
            }
          })
        })
        for (const i in usersTo) {
          if (usersTo[i].email) {
            emailsTo.push(usersTo[i].email)
            usersToURL.push(usersTo[i]._id.toString())
          }
        }
        const config = {
          host: sett.smtp,
          port: sett.port,
          secure: secure, // true for 465, false for other ports
          tls: {
            rejectUnauthorized: false
          }
        }
        if (sett.password || !sett.password === '') {
          config.auth = {
            user: sett.user,
            pass: password
          }
        }
        transporter = nodemailer.createTransport(config)

        // setup email data with unicode symbols
        let attachments = []
        if (emailsTo.length > 0) {
          var context = req.session.context
          req.query._id = project._id
          req.app.routes.project.details(req, mongo, (resDet) => {
            if (!resDet) throw err
            else {
              const projectData = resDet
              var department = false
              var manager = false
              var member = false
              var projectStatus = projectData.status
              var canCompleted = false
              var canArchived = false
              var departmentContext = false
              if (projectData.manager && context.user.toString() === projectData.manager.toString()) {
                manager = true
              }
              if (projectData.members && projectData.members.length) {
                for (var m in projectData.members) {
                  if (context.user.toString() === projectData.members[m].toString()) {
                    member = true
                    break
                  }
                }
              }
              if (context.managerUnits && projectData.unit) {
                for (var i in context.managerUnits) {
                  if (context.managerUnits[i] === projectData.unit) {
                    departmentContext = true
                    if (projectData.status === 'draft') {
                      department = true
                    } else {
                      department = false
                    }
                    if (projectData.status === 'processing' || projectData.status === 'reviewed') {
                      canCompleted = true
                    }
                    if (projectData.status === 'completed') {
                      canArchived = true
                    }
                    break
                  }
                }
              }
              // comentario de prueba//

              if (context.assistantUnits && projectData.unit && !departmentContext) {
                for (var u in context.assistantUnits) {
                  if (context.assistantUnits[u] === projectData.unit) {
                    departmentContext = true
                    if (projectData.status === 'draft') {
                      department = true
                    } else {
                      department = false
                    }
                    if (projectData.status === 'processing' || projectData.status === 'reviewed') {
                      canCompleted = true
                    }
                    if (projectData.status === 'completed') {
                      canArchived = true
                    }
                    break
                  }
                }
              }
              if (projectData.unit === '' && projectData.status === 'draft') {
                department = true
                departmentContext = true
              }
              req.app.routes.project.gantt(req, mongo, (resGantt) => {
                var owners = true
                const ganttData = resGantt
                if (ganttData.content) {
                  var data = ganttData.content.gantt.data
                  for (var d in data) {
                    if ((data[d].type === 'task' && !data[d].owner_id) || (data[d].type === 'task' && data[d].owner_id === '')) {
                      owners = false
                    }
                    if (data[d].type === 'task' && (data[d].status !== 'reviewed' && data[d].status !== 'suspended')) {
                      canCompleted = false
                    }
                  }
                }
                var sendMessage = 'Se ha iniciado el proyecto <a href="' + req.headers.referer + 'api/user.goURL?users='+usersToURL+'&url=project.project?_id=' + project._id + '$department=' + department + '$owners=' + owners + '$manager=' + manager + '$departmentContext=' + departmentContext + '$projectStatus=' + projectStatus + '$member=' + member + '$canCompleted=' + canCompleted + '$canArchived=' + canArchived + '">' + project.name + '</a>'
                const message = {
                  from: sett.user, // sender address
                  to: emailsTo, // list of receivers
                  subject: 'Nuevo proyecto iniciado', // Subject line
                  // text: 'Hello world?', // plain text body
                  html: sendMessage, // html body
                }

                // send mail with defined transport object
                transporter.sendMail(message, (error, info) => {
                  if (error) {
                    console.log(error)
                    console.log('No se pudo enviar el correo')
                    this.saveSystemNotification(req, mongo, null, 'Error al enviar correo: ' + error.message)
                  } else {
                    console.log('Message sent: %s', info.messageId)
                    console.log('Mensaje enviado')
                  }
                })
              })
            }
          })
        }
      }
    })
  }

  this.pushNotification = function (req, doc, noti, users) {
    req.broadcast.pushNotification(doc, noti, users)
  }

  this.send = function (req, room, event, data, users, deleted) {
    req.broadcast.send(room, event, data, users, deleted)
  }
  this.newEmail = function (req, subject, from, users, id) {
    req.broadcast.newEmail(subject, from, users, id)
  }

  this.sendAlarm = function (req, body, user, count, id) {
    req.broadcast.sendAlarm(body, user, count, id)
  }

  this.mention = function (req, name, mentions, involved, comment) {
    req.broadcast.mention(name, mentions, involved, comment)
  }

  this.Okcompromise = function (req, name, status, users, id) {
    req.broadcast.Okcompromise(name, status, users, id)
  }
}