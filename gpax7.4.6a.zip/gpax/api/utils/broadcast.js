/* exported */
exports.Broadcast = Broadcast

/* Broadcast server, emit notification for users */
var socketio = require('socket.io')
var redisAdapter = require('socket.io-redis')
var os = require('os')
var moment = require('moment')

function Broadcast (server, app) {

  this.app = app
  var hostname = os.hostname()
  if (['gpax','gpax1','gpax2'].includes(hostname)) {
    this.io = socketio()
    this.io.listen(7780)
    console.log('ws port:'+7780)
  } else {
    this.io = socketio(server)
  }
  if (os.platform() !== 'win32') {
    this.io.adapter(redisAdapter({ host: 'localhost', port: 6379 }))
  }
  this.io.on('connection', (socket) => {
    socket.on('init', (data) => {
      socket.join([data.user, data.room]) // Id is a private room for each user,// Room is a public room for each user group in same database
      socket.userId = data.user
      socket.roomName = data.room;
      if (data.room !== 'smartcard') {
        // eslint-disable-next-line no-undef
        this.url = Buffer.from(data.room, 'base64').toString()
        this.mongo = this.app.getMongo(this.url)
        this.mongo.find('notification', { actors: { $elemMatch: { user: this.mongo.toId(data.user), seen: 0 } } }, async (err, notifications) => {
          var notis = 0
          if (notifications && notifications.length > 0) {
            var userIds = []
            var docIds = []
            var collections = []
            var returnedDocs = {}
            for (let i in notifications) {
              userIds.push(notifications[i].user)
              docIds.push(notifications[i].document.id)
              collections.push(notifications[i].collection)
            }
            for (let u in collections) {
              var findDocs = await new Promise(resolve => {
                this.mongo.toHash(collections[u], { _id: { $in: docIds } }, {}, (err, docs) => {
                  if (err) {
                    resolve([])
                  } else {
                    resolve(docs)
                  }
                })
              })
              returnedDocs = Object.assign(returnedDocs, findDocs)
            }
            for (let i in notifications) {
              let noti = notifications[i]
              if (returnedDocs[noti.document.id.toString()]) {
                notis++
              }
            }
          }
          if (err) throw err
          this.mongo.aggregate('chat', [
            { $match: { 'messages.actors': { $elemMatch: { user: this.mongo.toId(data.user), seen: '0' } } } },
            { $unwind: '$messages' },
            {
              $addFields: {
                'actorsMsg': '$messages.actors'
              }
            },
            { $unwind: '$actorsMsg' },
            { $match: { 'actorsMsg.user': this.mongo.toId(data.user), 'actorsMsg.seen': '0' } },
            { $group: { _id: '$_id', list: { $push: '$messages.id' } } },
          ], {}, (err, chats) => {
            let chatCountMsg = 0
            if (err) throw err
            if (chats.length) {
              for (let c in chats) {
                chatCountMsg = chatCountMsg + chats[c].list.length
              }
            }
            var reminder = new Date().getDay()
            this.mongo.count('comment', { unread: this.mongo.toId(data.user), reminder: { $ne: reminder } }, (err, comments) => {
              if (err) throw err
              this.mongo.count('alarm', { actors: { $elemMatch: { user: this.mongo.toId(data.user), seen: 0 } } }, (err, alarms) => {
                if (err) throw err
                if (comments > 0) {
                  this.io.to(data.user.toString()).emit('reminder', { message: 'Tienes ' + comments + ' comentario(s) sin leer', comment: comments })
                }
                if (notis > 0) {
                  this.io.to(data.user.toString()).emit('notifications', notis)
                }
                if (alarms > 0) {
                  this.io.to(data.user.toString()).emit('alarms', alarms)
                }
                if (chatCountMsg > 0) {
                  this.io.to(data.user.toString()).emit('chats', chatCountMsg)
                }
              })
            })
          })
        })
      }
    })
    //mantener conexion
    socket.on('keep-alive', (data) => {
      socket.emit('keep-alive', null)
      // eslint-disable-next-line no-undef
      if (socket.roomName && data && data.user) {
        let today = moment(new Date())
        if ((today.hour() >= 6 && today.hour() <= 17) && (today.isoWeekday() !== 6 && today.isoWeekday() !== 7)) {
          this.url = Buffer.from(socket.roomName, 'base64').toString()
          this.mongo = this.app.getMongo(this.url)
          this.mongo.count('alarm', { actors: { $elemMatch: { user: this.mongo.toId(data.user), seen: 0 } } }, (err, alarms) => {
            if (err) throw err
            this.mongo.find('comment', { type: '1', unread: { $in: [this.mongo.toId(data.user)] } }, async (err, results) => {
              if (err) throw err
              if (results && results.length > 0) {
                var sett = await new Promise(resolve => {
                  this.mongo.findOne('settings', { _id: 'settings' }, async (err, sett) => {
                    if (!err) {
                      resolve(sett)
                    } else {
                      resolve(false)
                    }
                  })
                })
                if (sett && sett.checkNotification === '1') {
                  let minutesAlarm = 30
                  let commentUnread = 0
                  if (sett.alarmComment && sett.alarmComment !== '0') minutesAlarm = Number(sett.alarmComment)
                  for (let i in results) {
                    let alarm = results[i]
                    var date = moment(alarm.dateAlarm)
                    let today = new Date().getTime()
                    date.add(minutesAlarm, 'minutes')
                    if ((today > new Date(date).getTime()) && (date.hour() >= 6 && date.hour() <= 17) && (date.isoWeekday() !== 6 && date.isoWeekday() !== 7)) {
                      commentUnread += 1
                    }
                  }
                  results = [alarms, commentUnread]
                  this.io.to(data.user.toString()).emit('alarms', results)
                }
              }
            })
          })
        }
      }
    })
    socket.on('comment', (data) => {
      this.comment(socket, data)
    })
    socket.on('email', (data) => {
      this.email(socket, data)
    })
    socket.on('alarm', (data) => {
      this.alarm(socket, data)
    })
    socket.on('start', (data) => {
      this.start(socket, data)
    })
    socket.on('notification', (data) => {
      this.notification(socket, data)
    })
    socket.on('chat message', async (data) => {
      // eslint-disable-next-line no-undef
      this.url = Buffer.from(socket.roomName, 'base64').toString()
      this.mongo = this.app.getMongo(this.url)
      let user = data.to
      var ct
      var isNew = !!data.chat.isNew
      if (!data.chat.isNew) {
        ct = await new Promise(resolve => {
          this.mongo.findId('chat', data.chat._id, (err, chat) => {
            if (!err) { resolve(chat) } else { resolve(false) }
          })
        })
      } else {
        ct = data.chat
      }
      if (ct) {
        if (!ct.isNew) {
          this.mongo.$replace(data.message)
          ct.messages.push(data.message)
        }
        ct.lastDate = new Date()
        delete ct.isNew
        await new Promise(resolve => {
          this.mongo.save('chat', ct, (err, result) => {
            if (!err) { resolve(result) } else { resolve(false) }
          })
        })
      }
      let idChat = ct._id
      //broadcast message to everyone in port:5000 except yourself.
      this.io.emit('received', { message: data.message, to: user, from: data.from, idChat: idChat, isNew: isNew })
      for (let i in ct.actors) {
        if (ct.actors[i].user.toString() !== data.from.toString()) {
          this.io.to(ct.actors[i].user.toString()).emit('chat', data)
        }
      }
    });
    socket.on('typing', async (data) => {
      socket.broadcast.emit('typing', data);
    });
    socket.on('stopTyping', async (data) => {
      socket.broadcast.emit('stopTyping', data);
    });
    socket.on('seenMsg', async (data) => {
      socket.broadcast.emit('seenMsg', data);
    });
    socket.on('usersConnected', async (userConnected) => {
      // eslint-disable-next-line no-undef
      this.url = Buffer.from(socket.roomName, 'base64').toString()
      this.mongo = this.app.getMongo(this.url)
      this.mongoSession = this.app.getMongo(this.app.params.session)
      var clients = await new Promise(resolve => {
        this.mongoSession.find('active', { 'session.context.room': socket.roomName }, {}, (err, users) => {
          if (!err) { resolve(users) } else { resolve(false) }
        })
      })
      let usersConnectedMongoId = []
      for (let x in clients) {
        usersConnectedMongoId.push(clients[x].session.context.user)
      }
      var usersConnected = await new Promise(resolve => {
        this.mongo.find('user', { $and: [{ _id: { $in: usersConnectedMongoId } }, { _id: { $ne: this.mongo.toId(userConnected) } }] }, { _id: 1, name: 1 }, { name: 1 }, (err, users) => {
          if (!err) { resolve(users) } else { resolve(false) }
        })
      })
      var usersDisconnected = await new Promise(resolve => {
        this.mongo.find('user', { $and: [{ _id: { $nin: usersConnectedMongoId } }, { _id: { $ne: this.mongo.toId(userConnected) } }] }, {/*  _id: 1, name: 1, position: 1 */ }, { active: -1, name: 1 }, (err, users) => {
          if (!err) { resolve(users) } else { resolve(false) }
        })
      })
      for (let u in usersConnected) {
        usersConnected[u].id = usersConnected[u]._id
        usersConnected[u].online = true
      }
      for (let u in usersDisconnected) {
        usersDisconnected[u].id = usersDisconnected[u]._id
      }
      socket.emit('returnUsersConnected', { users: usersConnected.concat(usersDisconnected) || [] });
    });
    socket.on('refreshUserConnected', async () => {
      this.mongoSession = this.app.getMongo(this.app.params.session)
      var clients = await new Promise(resolve => {
        this.mongoSession.find('active', { 'session.context.room': socket.roomName }, {}, (err, users) => {
          if (!err) { resolve(users) } else { resolve(false) }
        })
      })
      let usersConnected = []
      for (let x in clients) {
        usersConnected.push(clients[x].session.context.user)
      }
      socket.emit('returnRefreshUserConnected', { users: usersConnected || [] });
    });
  })

  this.comment = function (socket, data) {
    socket.emit('comment', data)
  }

  this.alarm = function (socket, data) {
    socket.emit('alarm', data)
  }

  this.email = function (socket, data) {
    socket.emit('email', data)
  }

  this.start = function (socket, data) {
    socket.emit('start', data)
  }
  this.notification = function (socket, data) {
    socket.emit('notification', data)
  }

  this.newEmail = function (subject, from, users, id) {
    if (users && users.length > 0) {
      for (let i in users) {
        this.io.to(users[i].user.toString()).emit('email', { message: 'De: ' + from + '\n Asunto: ' + subject, id: id })
      }
    }
  }

  this.sendAlarm = function (body, user, count, id) {
    this.io.to(user.toString()).emit('alarm', { message: body, count: count, id: id })
  }

  this.startProject = function (subject, users, id) {
    if (users && users.length > 0) {
      for (let i in users) {
        this.io.to(users[i].user.toString()).emit('start', { message: 'Se inicio el projecto ' + subject, id: id, subject: subject })
      }
    }
  }

  this.pushNotification = function (doc, noti, users) {
    if (users && users.length > 0) {
      for (let i in users) {
        this.io.to(users[i].toString()).emit('notification', { doc: doc, noti: noti })
      }
    }
  }

  this.mention = function (name, mentions, involved, comment) {
    var objectInvolved = {}
    for (let i in involved) {
      objectInvolved[involved[i].toString()] = involved[i].toString()
    }
    for (let i in mentions) {
      this.io.to(mentions[i].toString()).emit('comment', { message: name + ' te ha mencionado en un comentario', comment: comment })
    }
    for (let i in objectInvolved) {
      if (mentions) {
        if (mentions.findIndex((x) => { return x.toString() === objectInvolved[i] }) === -1) { this.io.to(objectInvolved[i]).emit('comment', { message: name + ' ha hecho un comentario a un documento', comment: comment }) }
      } else {
        this.io.to(objectInvolved[i]).emit('comment', { message: name + ' ha hecho un comentario a un documento', comment: comment })
      }
    }
  }

  this.send = function (room, event, data, users, deleted) {
    if (data) { data.deleted = deleted }
    if (users && users.length > 0) {
      for (let i in users) {
        if (users[i]) {
          this.io.to(users[i].toString()).emit(event, data)
        }
      }
    } else {
      this.io.to(room).emit(event, data)
    }
  }
}