/* exported */

exports.Reminder = Reminder
var moment = require('moment')
var CronJob = require('cron').CronJob

function Reminder () {
  this.get = function (req, mongo, send) {
    mongo.find('reminder', { document: mongo.toId(req.query.document) }, (err, reminder) => {
      if(err) throw err
      if (reminder.length) {
        send(reminder[0])
      } else {
        let doc = {
          _id: mongo.newId(),
          document: req.query.document,
          collection: req.query.collection,
          checkDate: 1
        }
        send(doc)
      }
    })
  }

  this.save = function (req, mongo, send) {
    let doc = req.body
    doc.user = req.session.context.user
    mongo.save('reminder', req.body, (err, result) => {
      if(err) throw err
      send(result)
    })
  }
}
