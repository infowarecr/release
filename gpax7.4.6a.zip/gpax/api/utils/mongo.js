/* global Buffer */
/**
 * Created by jorge on 28/04/17.
 */
var mongodb = require('mongodb')
var mimeTypes = require('mime-types')

var { Readable } = require('stream')
var sharp = require('sharp');
var base64Img = require('base64-img')
var formidable = require('formidable')
var maxWait = 20000
exports.Mongo = Mongo

function Mongo (urlConnect) {
  this.ObjectId = mongodb.ObjectId
  this.Binary = mongodb.Binary
  this.url = urlConnect
  this.dbname = this.url
  this.dbname = this.dbname.substring(this.dbname.lastIndexOf('/') + 1)
  if (this.dbname.includes('?')) {
    this.dbname = this.dbname.substring(0, this.dbname.indexOf('?'))
  }
  this.timestamp = function (a,b) {
    return mongodb.Timestamp.fromBits(a,b)
  }
  this.newId = function (date) {
    var _id = new this.ObjectId()
    if (date) {
      var timestamp = Math.floor(date.getTime() / 1000)
      var hex = timestamp.toString(16) + '0000000000000000'
      _id = new this.ObjectId(hex)
    }
    return _id
  }

  this.binary = function (buffer, subtype) {
    return new this.Binary(buffer, subtype)
  }

  this.getCollections = function (next) {
    this.connect(next, (db) => {
      db.listCollections().toArray(next)
      /* db.collections(function (err, result) {
        next(err, result)
      }) */
    })
  }

  this.toId = function (base) {
    return this.isNativeId(base) ? new this.ObjectId(base) : Number(base) || base
  }

  this.isNativeId = function (id) {
    var r = false
    if (id && ('' + id).toString().match(/^[0-9a-fA-F]{24}$/)) {
      r = true
    }
    return r
  }
  this.connect = function (onError, onSuccess) {
    if (this.client && this.client.isConnected) {
      onSuccess(this.client.db(this.dbname))
    } else {
      mongodb.MongoClient.connect(this.url, { useUnifiedTopology: true, appname: 'gpax' }, (err, client) => {
        if (err) {
          onError({ error: err })
        } else {
          this.client = client
          onSuccess(this.client.db(this.dbname))
        }
      })
    }
  }

  this.disconnect = function () {
    if (this.client) {
      this.client.close()
      this.client = null
    }
  }

  this.copyTo = function (collection, collectionTarget, next) {
    this.connect(next, (db) => {
      db.collection(collection).copyTo(collectionTarget, next)
    })
  }
  this.aggregate = function (collection, pipeline, options, next) {
    this.connect(next, (db) => {
      var cursor
      cursor = db.collection(collection).aggregate(pipeline, options)
      cursor.maxTimeMS(maxWait)
      if (cursor) {
        cursor.toArray((err, array) => {
          next(err, array)
        })
      } else {
        next('not found', [])
      }
    })
  }
  this.aggregate2cursor = function (collection, pipeline, options, next) {
    this.connect(next, (db) => {
      var cursor
      cursor = db.collection(collection).aggregate(pipeline, options)
      cursor.maxTimeMS(maxWait)
      next(null, cursor)
    })
  }
  this.docs = function (collection, fields, sort, next) {
    if (arguments.length === 3 && sort instanceof Function) {
      next = sort
      sort = undefined
    } else if (arguments.length === 2 && fields instanceof Function) {
      next = fields
      fields = {}
    }
    this.connect(next, (db) => {
      var cursor
      if (sort && Object.keys(sort).length > 0) {
        cursor = db.collection(collection).find({}, { projection: fields, sort: sort })
      } else {
        cursor = db.collection(collection).find({}, { projection: fields })
      }
      if (cursor) {
        cursor.maxTimeMS(maxWait)
        cursor.toArray((err, array) => {
          next(err, array)
        })
      } else {
        next('not found', [])
      }
    })
  }

  this.toHash = function (collection, keys, fields, sort, next) {
    if (arguments.length === 4 && sort instanceof Function) {
      next = sort
      sort = undefined
    } else if (arguments.length === 3 && fields instanceof Function) {
      next = fields
      fields = {}
    }
    this.connect(next, (db) => {
      var cursor
      if (sort && Object.keys(sort).length > 0) {
        cursor = db.collection(collection).find(keys, { projection: fields, sort: sort })
      } else {
        cursor = db.collection(collection).find(keys, { projection: fields })
      }
      if (cursor) {
        cursor.maxTimeMS(maxWait)
        cursor.toArray((err, array) => {
          var hash = {}
          if (!err) {
            for (let i = 0; i < array.length; ++i) {
              var doc = array[i]
              if (doc._id) { hash[doc._id.toString()] = doc }
            }
          }
          next(err, hash)
        })
      } else {
        next('not found', [])
      }
    })
  }

  this.distinct = function (collection, field, keys, next) {
    this.connect(next, (db) => {
      db.collection(collection).distinct(field, keys, {}, (err, array) => {
        next(err, array)
      })
    })
  }

  this.find = function (collection, keys, fields, sort, next) {
    if (arguments.length === 4 && sort instanceof Function) {
      next = sort
      sort = undefined
    } else if (arguments.length === 3 && fields instanceof Function) {
      next = fields
      fields = {}
    }
    this.connect(next, (db) => {
      var cursor
      if (sort && Object.keys(sort).length > 0) {
        cursor = db.collection(collection).find(keys, { projection: fields, sort: sort })
      } else {
        cursor = db.collection(collection).find(keys, { projection: fields })
      }
      if (cursor) {
        cursor.maxTimeMS(maxWait)
        cursor.toArray(next)
      } else {
        next('not found', [])
      }
    })
  }
  this.findOne = function (collection, keys, fields, next) {
    if (arguments.length === 3 && fields instanceof Function) {
      next = fields
      fields = null
    }
    this.connect(next, (db) => {
      if (fields) {
        db.collection(collection).findOne(keys, { projection: fields }, next)
      } else {
        db.collection(collection).findOne(keys, next)
      }
    })
  }

  this.findN = function (collection, skip, limit, keys, fields, sort, next) {
    if (arguments.length === 6 && sort instanceof Function) {
      next = sort
      sort = undefined
    } else if (arguments.length === 5 && fields instanceof Function) {
      next = fields
      fields = null
    }
    this.connect(next, (db) => {
      var cursor = db.collection(collection).find(keys)
      cursor.maxTimeMS(maxWait)
      if (fields && Object.keys(fields).length > 0) cursor.project(fields)
      if (skip) cursor.skip(skip)
      if (limit) cursor.limit(limit)
      if (sort && Object.keys(sort).length > 0) cursor.sort(sort)
      cursor.toArray(next)
    })
  }
  this.findOneAndUpdate = function (collection, keys, update, fields, next) {
    this.connect(next, (db) => {
      db.collection(collection).findOneAndUpdate(keys, update, { projection: fields }, next)
    })
  }

  this.cursor = function (collection, keys, fields, sort, next) {
    if (arguments.length === 4 && sort instanceof Function) {
      next = sort
      sort = undefined
    } else if (arguments.length === 3 && fields instanceof Function) {
      next = fields
      fields = {}
    }
    this.connect(next, (db) => {
      var cursor
      if (sort && Object.keys(sort).length > 0) {
        cursor = db.collection(collection).find(keys, { projection: fields, sort: sort })
        cursor.maxTimeMS(maxWait)
        next(null, cursor)
      } else {
        cursor = db.collection(collection).find(keys, { projection: fields })
        cursor.maxTimeMS(maxWait)
        next(null, cursor)
      }
    })
  }
  this.createIndexes = function (collection, indexes, next) {
    this.connect(next, (db) => {
      db.collection(collection).dropIndexes({}, (err) => {
        if (err) console.log(err)
        db.collection(collection).createIndexes(indexes, {}, next)
      })
    })
  }

  this.findId = function (collection, id, fields, sort, next) {
    if (arguments.length === 4 && sort instanceof Function) {
      next = sort
      sort = undefined
    }
    if (arguments.length === 3 && fields instanceof Function) {
      next = fields
      fields = undefined
    }
    var oid = ''
    if (id) {
      oid = this.isNativeId(id) ? new this.ObjectId(id) : id
    }
    this.connect(next, (db) => {
      if (sort && Object.keys(sort).length > 0) {
        db.collection(collection).findOne({ _id: oid }, { projection: fields, sort: sort }, next)
      } else {
        db.collection(collection).findOne({ _id: oid }, { projection: fields }, next)
      }
    })
  }

  this.str2id = function (value) {
    var r = value
    if (value.match(/^[0-9a-fA-F]{24}$/)) {
      r = new this.ObjectId(value)
    }
    return r
  }

  this.switchIds = function (field) {
    var type = typeof (field)
    if (!this.queue) {
      this.queue=[]
    }
    if (type === 'object') {
      if (this.queue.indexOf(field) === -1) {
        this.queue.push(field)
        for (const key in field) {
          if (field[key]) {
            if (!(Buffer.isBuffer(field) && field[key] instanceof Function)) {
              field[key] = this.switchIds(field[key])
            }
          }
        }
      }
    } else if (type === 'array') {
      for (let i = 0; i < field.length; ++i) {
        field[i] = this.switchIds(field[i])
      }
    } else if (type === 'string' && field.length === 24) {
      field = this.str2id(field)
    }
    return field
  }
  this.switchImgBase64ToLink = async function (doc, id, next) {
    for (let key in doc) {
      var type = typeof (doc[key])
      var docCopy = JSON.parse(JSON.stringify(doc))
      if (type === 'string' && doc[key].indexOf('data-fr-image-pasted') !== -1) {
        var i = 0
        while (doc[key].indexOf('data-fr-image-pasted', i) !== -1) {
          i = doc[key].indexOf('data-fr-image-pasted', i)
          let f = doc[key].indexOf('"', i + 36)
          let data = doc[key].substring(i, f)
          let base64String = data.replace('data-fr-image-pasted="true" src="', '')
          var nameFile = this.newId()
          try {
            var filepath = base64Img.imgSync(base64String, '/tmp/', nameFile)
            var compressIMG = await sharp(filepath)
              //.rotate()
              .webp({ quality: 20 })
              //.resize(200)
              .jpeg({ mozjpeg: true })
              .toBuffer()
            var stream = new Readable()
            stream.push(compressIMG)
            stream.push(null)
            let link = await new Promise(resolve => {
              this.putFile(nameFile + '.jpeg', stream, { document: this.str2id(id) }, (err, res) => {
                resolve(res.link)
              })
            })
            docCopy[key] = docCopy[key].replace(base64String, link)
          } catch (err) {}
          i = f + 1
        }
        docCopy[key] = docCopy[key].replace(new RegExp('data-fr-image-pasted="true"', 'g'), '')
        doc[key] = docCopy[key]
      }
    }
    next(doc)
  }
  this.$replace = (field) => {
    var type = typeof (field)
    if (!this.queue) {
      this.queue=[]
    }
    if (type === 'object') {
      if (this.queue.indexOf(field) === -1) {
        this.queue.push(field)
        for (const key in field) {
          if (key !== 'content') {
            if (key.indexOf('$') === 0 || Buffer.isBuffer(field) || field[key] instanceof Function) {
              delete field[key]
            } else if (field[key]) {
              field[key] = this.$replace(field[key])
            }
          }
        }
      }
    } else if (type === 'array') {
      for (let i = 0; i < field.length; ++i) {
        field[i] = this.$replace(field[i])
      }
    }
    return field
  }

  this.save = async function (collection, doc, next) {
    this.queue = []
    this.switchIds(doc)
    this.switchImgBase64ToLink(doc, doc._id ? doc._id.toString() : this.newId().toString(), (doc) => {
      this.connect(next, (db) => {
        this.queue = []
        this.$replace(doc)
        db.collection(collection).updateOne({ _id: doc._id }, { $set: doc }, { upsert: true }, next)
      })
    })
  }

  this.saveWithFilter = function (collection, filter, set, options, next) {
    this.queue = []
    this.switchIds(set)
    this.switchImgBase64ToLink(set, set._id ? set._id.toString() : this.newId().toString(), (set) => {
      this.connect(next, (db) => {
        this.queue = []
        this.$replace(set)
        db.collection(collection).update(filter, { $set: set }, options, next)
      })
    })
  }

  this.insertMany = function (collection, doc, next) {
    this.connect(next, (db) => {
      db.collection(collection).insertMany(doc, next)
    })
  }

  this.update = function (collection, filter, doc, next) {
    this.queue = []
    this.switchIds(doc)
    this.queue = []
    this.switchIds(filter)
    this.switchImgBase64ToLink(doc, doc._id ? doc._id.toString() : this.newId().toString(), (doc) => {
      this.connect(next, (db) => {
        db.collection(collection).updateOne(filter, doc, { upsert: false }, next)
      })
    })
  }

  this.updateAll = function (collection, filter, doc, next) {
    this.connect(next, (db) => {
      db.collection(collection).updateMany(filter, doc, { upsert: false }, next)
    })
  }

  this.deleteOne = function (collection, keys, next) {
    this.connect(next, (db) => {
      db.collection(collection).deleteOne(keys, next)
    })
  }

  this.deleteAll = function (collection, keys, next) {
    this.connect(next, (db) => {
      db.collection(collection).deleteMany(keys, next)
    })
  }

  this.count = function (collection, keys, next) {
    this.connect(next, (db) => {
      var cursor = db.collection(collection).find(keys)
      cursor.maxTimeMS(maxWait)
      cursor.count(next)
    })
  }

  this.savefile = function (req, next) {
    this.connect(next, (db) => {
      var gfs = new mongodb.GridFSBucket(db, { bucketName: 'fs', writeConcern: { w: 1 } })
      var form = formidable({ multiples: true })
      form.onPart = (file) => {
        if (file.filename) {
          var id = this.newId()
          var contentType = file.mime
          var filename = file.filename
          var ext = filename.split('.')
          if (ext.length) {
            ext = ext[ext.length - 1]
          }
          var metadata = { ...req.query, ...req.body }
          this.switchIds(metadata)
          if (!metadata.actors) {
            metadata.actors = [{ user: req.session.context.user }]
          } else {
            metadata.actos.push({ user: req.session.context.user })
          }
          var cf = gfs.openUploadStreamWithId(id, filename, { metadata: metadata, contentType: contentType })
          file.on('data', (buf) => {
            cf.write(buf)
          })
          file.on('end', () => {
            cf.end()
          })
          cf.on('finish', async (file) => {
            if (metadata && metadata.attached) {
              let pipeline, collection
              if (metadata.reference) {
                collection = 'note'
                pipeline = [{ $match: { _id: this.toId(metadata.reference) } }]
              } else {
                collection = 'attached'
                pipeline = [
                  { $match: { _id: this.toId(metadata.attached) } },
                  { $lookup: { from: 'note', localField: 'reference', foreignField: '_id', as: 'note' } },
                  { $unwind: '$note' },
                  { $project: { note: 1 } }]
              }
              await new Promise(resolve => {
                this.aggregate(collection, pipeline, {}, (err, attached) => {
                  if (!err) {
                    if (collection === 'attached' && attached.length && attached[0] && attached[0].note.project) {
                      metadata.project = attached[0].note.project
                    } else if (attached.length && attached[0] && attached[0].project) {
                      metadata.project = attached[0].project
                    }
                    resolve(true)
                  } else {
                    resolve(false)
                  }
                })
              })
            }
            if (metadata && metadata.commitment) {
              let pipeline
              if (metadata.reference) {
                pipeline = [
                  { $match: { _id: this.toId(metadata.reference) } },
                  { $lookup: { from: 'note', localField: 'reference', foreignField: '_id', as: 'note' } },
                  { $unwind: '$note' },
                  { $project: { note: 1 } }]
              } else {
                pipeline = [
                  { $match: { _id: this.toId(metadata.commitment) } },
                  { $lookup: { from: 'attached', localField: 'reference', foreignField: '_id', as: 'att' } },
                  { $unwind: '$att' },
                  { $lookup: { from: 'note', localField: 'att.reference', foreignField: '_id', as: 'note' } },
                  { $unwind: '$note' },
                  { $project: { note: 1 } }]
              }
              await new Promise(resolve => {
                this.aggregate('commitment', pipeline, {}, (err, commitment) => {
                  if (!err) {
                    if (commitment.length && commitment[0] && commitment[0].note.project) {
                      metadata.project = commitment[0].note.project
                    }
                    resolve(true)
                  } else {
                    resolve(false)
                  }
                })
              })
            }
            if (metadata && metadata.evidence) {
              let pipeline
              if (metadata.reference) {
                pipeline = [
                  { $match: { _id: this.toId(metadata.reference) } },
                  { $lookup: { from: 'attached', localField: 'reference', foreignField: '_id', as: 'att' } },
                  { $unwind: '$att' },
                  { $lookup: { from: 'note', localField: 'att.reference', foreignField: '_id', as: 'note' } },
                  { $unwind: '$note' },
                  { $project: { note: 1 } }]
              } else {
                pipeline = [
                  { $match: { _id: this.toId(metadata.evidence) } },
                  { $lookup: { from: 'commitment', localField: 'reference', foreignField: '_id', as: 'comm' } },
                  { $unwind: '$comm' },
                  { $lookup: { from: 'attached', localField: 'comm.reference', foreignField: '_id', as: 'att' } },
                  { $unwind: '$att' },
                  { $lookup: { from: 'note', localField: 'att.reference', foreignField: '_id', as: 'note' } },
                  { $unwind: '$note' },
                  { $project: { note: 1 } }]
              }
              await new Promise(resolve => {
                this.aggregate('evidence', pipeline, {}, (err, evidence) => {
                  if (!err) {
                    if (evidence.length && evidence[0] && evidence[0].note.project) {
                      metadata.project = evidence[0].note.project
                    }
                    resolve(true)
                  } else {
                    resolve(false)
                  }
                })
              })
            }
            if (metadata && metadata.project) {
              this.findId('project', this.toId(metadata.project.toString()), { files: 1 },(err, project) => {
                if (!err && project) {
                  if (project.files && project.files.length > 0 && project.files[0].data) {
                    project.files[0].data.push({
                      id: '/api/file.get?_id=' + id + '&type=' + ext,
                      value: filename,
                      type: ext,
                      size: file.chunkSize,
                      date: Number(new Date().getTime().toString().substring(0, 10)),
                      reference: '/api/file.get?_id=' + id + '&type=' + ext,
                      metadata: metadata
                    })
                  } else {
                    project.files = [
                      {
                        value: '/',
                        open: true,
                        type: 'folder',
                        date: new Date(),
                        data: [
                          {
                            id: '/api/file.get?_id=' + id + '&type=' + ext,
                            value: filename,
                            type: ext,
                            size: file.chunkSize,
                            date: Number(new Date().getTime().toString().substring(0, 10)),
                            reference: '/api/file.get?_id=' + id + '&type=' + ext,
                            metadata: metadata
                          }
                        ]
                      }
                    ]
                  }
                  this.save('project', project, (err) => {
                    if (!err) {
                      next(null, { link: '/api/file.get?_id=' + id + '&type=' + ext })
                    } else {
                      next(null, { link: '/api/file.get?_id=' + id + '&type=' + ext })
                    }
                  })
                } else {
                  next(null, { link: '/api/file.get?_id=' + id + '&type=' + ext })
                }
              })
            } else {
              next(null, { link: '/api/file.get?_id=' + id + '&type=' + ext })
            }
          })
          cf.on('error', (err) => {
            console.log(err)
          })
        }
      }
      form.parse(req)
    })
  }

  this.putFile = function (filename, stream, meta, next, _id) {
    if (stream.pipe) {
      this.connect(next, (db) => {
        var gfs = new mongodb.GridFSBucket(db, { bucketName: 'fs', writeConcern: { w: 1 } })
        var doc = {
          content_type: mimeTypes.lookup(filename)
        }
        _id = _id || this.newId()
        if(meta) doc.metadata=this.switchIds(meta)
        var writer = gfs.openUploadStreamWithId(_id, filename, doc)
        writer.on('close', () => {
          next(null, { link: '/api/file.get?_id=' + _id.toString(), _id: _id })
        })
        stream.pipe(writer)
      })
    } else {
      next({ error: 'Archivo no encontrado' })
    }
  }

  this.getfile = function (id, next) {
    this.connect(next, (db) => {
      var gfs = new mongodb.GridFSBucket(db)
      var _id = this.isNativeId(id) ? this.toId(id) : id
      var cursor = gfs.find({ _id: _id })
      cursor.toArray().then((files) => {
        if (files && files.length > 0) {
          var mongoStream = gfs.openDownloadStream(_id)
          mongoStream.contentType=files[0].contentType
          next(null, mongoStream, files[0])
        } else {
          next('Not found', [])
        }
      })
    })
  }

  this.getfileBase64 = async function (id, next) {
    this.connect(next, (db) => {
      let objectID = new mongodb.ObjectID(id)
      let bucket = new mongodb.GridFSBucket(db)
      //temporary variable to hold image
      var data = []
      // create the download stream
      let downloadStream = bucket.openDownloadStream(objectID)
      downloadStream.on('data', (chunk) => {
        data.push(chunk);
      });
      downloadStream.on('error', async () => {
        next('Not found', [])
      });
      downloadStream.on('end', async () => {
        // convert from base64 and write to file system
        let bufferBase64 = Buffer.concat(data)
        bufferBase64 = bufferBase64.toString('base64')
        next(null, bufferBase64)
      })
    })
  }

  this.copyfile = function (id, newId, next) {
    this.connect(next, (db) => {
      var gfs = new mongodb.GridFSBucket(db)
      var _id = this.isNativeId(id) ? this.toId(id) : id
      var cursor = gfs.find({ _id: _id })
      cursor.toArray().then((files) => {
        if (files && files.length > 0) {
          var part = files[0]
          var mongoStream = gfs.openDownloadStream(_id)
          if (part.filename) {
            //  ++count
            var doc = {
              filename: part.filename,
              mode: 'w',
              content_type: mimeTypes.contentType(part.filename),
              _id: newId,
              metadata: part.metadata
            }
            var ext = part.filename.split('.')
            if (ext.length) {
              ext = ext[ext.length - 1]
            }
            const writable = gfs.openUploadStreamWithId(newId, part.filename, doc)

            writable.once('finish', (file) => {
              next(null, mongoStream, file)
            })
            mongoStream.pipe(writable)
          }
        } else {
          next('Not found', [])
        }
      })
    })
  }

  this.removefile = function (id, next) {
    this.connect(next, (db) => {
      var gfs = new mongodb.GridFSBucket(db)
      gfs.delete(this.toId(id), (err) => {
        if (err) {
          next(err)
        } else {
          next(null, { removed: true })
        }
      })
    })
  }

  this.files = function (req, next) {
    this.connect(next, (db) => {
      var doc
      if (req.query.project) {
        doc = { root: req.query.project }
      } else {
        doc = { filename: new RegExp(req.query._id) }
      }
      var gfs = new mongodb.GridFSBucket(db)
      var cursor = gfs.find(doc)
      if (cursor) {
        cursor.toArray(next)
      } else {
        next(null, [])
      }
    })
  }

  // Security & util functions
  this.userUnits = function (user, roles, keys, next) {
    if (user && roles && keys) {
      this.find('unit', { $and: [{ actors: { $elemMatch: { user: user, type: { $in: roles } } } }, keys] }, {}, {}, next)
    } else if (user && roles) {
      this.find('unit', { actors: { $elemMatch: { user: user, type: { $in: roles } } } }, {}, {}, next)
    } else {
      next({ error: 'paramsFail' })
    }
  }

  this.sessionUnits = function (session, roles, keys, next) {
    if (roles && keys) {
      this.find('unit', { $and: [{ _id: { $in: session.units }, 'actors.type': { $in: roles } }, keys] }, {}, {}, next)
    } else if (roles) {
      this.find('unit', { _id: { $in: session.units }, 'actors.type': { $in: roles } }, {}, {}, next)
    } else {
      this.find('unit', { _id: { $in: session.units } }, {}, {}, next)
    }
  }

  this.userRoles = function (user, keys, next) {
    if (user && keys) {
      this.find('user', { $and: [{ _id: user }, keys] }, {}, {}, next)
    } else {
      next({ error: 'paramsFail' })
    }
  }


  this.hasIndex = async function (collection, index) {
    return new Promise(resolve => {
      this.connect(() => { resolve(false) }, (db) => {
        db.collection(collection).indexExists(index, (err, result) => {
          if (err) console.log(err)
          resolve(result)
        })
      })
    })
  }
  this.changes = function (pipeline, options, next) {
    this.connect(next, (db) => {
      next(db.watch(pipeline, options))
    })
  }
  this.bulk = function (collection, cursor, next) {
    var async = require('async')
    this.connect(next, (db) => {
      db.collection(collection, async (err, target) => {
        var batch = target.initializeOrderedBulkOp()
        var counter = 0
        var current = null
        async.whilst(
          async function () {
            var continuar = await new Promise(resolve => {
              cursor.next(function (err, doc) {
                if (err) throw err
                // .nextObject() returns null when the cursor is depleted
                if (doc != null) {
                  current = doc
                  resolve(true)
                } else {
                  resolve(false)
                }
              })
            })
            return continuar
          },
          async function (callback) {
            batch.insert(current)
            counter++

            if (counter % 1000 === 0) {
              batch.execute(function (err) {
                if (err) throw err
                batch = target.initializeOrderedBulkOp()
                callback()
              })
            }
          },
          function (err) {
            if (err) throw err
            if (counter % 1000 !== 0) {
              batch.execute(function (err) {
                if (err) next(err)
                else next(null, { inserts: counter })
              })
            }
          }
        )
      })
    })
  }
}