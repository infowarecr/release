var app = require('./utils/main')
app.init({
  session: 'mongodb://dev/sessions',
  user: 'mongodb://dev/users_dev',
  notify: 'mongodb://dev/notify',
  log: 'mongodb://dev/logs',
  background: 'mongodb://dev/ebill_dev',
  outlook: 'dev.gpax.io',
  logger: 'basic',
  port: process.argv[2] || 8082,
  ebillEnvironment: 'Pruebas'
})
