var app = require('./utils/main')
app.init({
  session: 'mongodb://atv,atv2/sessions',
  user: 'mongodb://atv,atv2/users',
  notify: 'mongodb://atv,atv2/notify',
  log: 'mongodb://atv,atv2/logs',
  background: 'mongodb://atv,atv2/ebill',
  logger: 'basic',
  port: 8082,
  ebillEnvironment: 'Produccion'
})
