var Mongo = require('./utils/mongo').Mongo
var mongo
var url = 'mongodb://dev/gpax'
mongo = new Mongo(url)
var fs = require('fs')
var { Readable } = require('stream')
var sharp = require('sharp');
var base64Img = require('base64-img')

var doc = fs.readFileSync('/home/jorge/gpax/api/note.json')
var html = JSON.parse(doc.toString()).content
async function run (html) {
  var i = 0
  var htmlCopy = html
  while (html.indexOf('data-fr-image-pasted', i) !== -1) {
    i = html.indexOf('data-fr-image-pasted', i)
    let f = html.indexOf('"', i + 36)
    let data = html.substring(i, f)
    let base64String = data.replace('data-fr-image-pasted="true" src="', '')
    var nameFile = 'iddoc'
    var tmp = '/tmp/' + nameFile

    let link = await new Promise(async resolve => {
      var filepath = base64Img.imgSync(base64String, '/tmp/', nameFile)
      var compressIMG = await sharp(filepath)
        //.rotate()
        .webp({ quality: 20 })
        //.resize(200)
        .jpeg({ mozjpeg: true })
        .toBuffer()
      var stream = new Readable()
      stream.push(compressIMG)
      stream.push(null)
      //fs.writeFileSync(tmp + '.jpeg', output)
      mongo.putFile(nameFile + '.jpeg', stream, { document: 'prueba' }, (err, res) => {
        resolve(res.link)
      })
    })
    htmlCopy = htmlCopy.replace(base64String, link)
    i = f + 1
  }
  htmlCopy = htmlCopy.replace(new RegExp('data-fr-image-pasted="true"', 'g'), '')
}
run(html)

let u = 1








