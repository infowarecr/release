pm2 delete all
cd ~/gpax/api
pm2 start gpax_dev.js --node-args="--inspect=9221"  --watch --ignore-watch="node_modules" -- $1
pm2 flush
pm2 logs
