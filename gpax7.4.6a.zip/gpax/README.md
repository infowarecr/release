# gpax
Plataforma de gestión de proyectos y automatización de procesos
